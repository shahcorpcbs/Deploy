#!/bin/bash
java -jar cbs_cust_updater-1.0.0.jar