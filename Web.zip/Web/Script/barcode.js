
function BarcodeEncoder() {
	this.TicketNumber = '';
	this.Store = '';
	this.Missing = [];
	this.Alphabit = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';


	this.ResetBarcode = function() {
		this.TicketNumber = "";
		this.Store = "";
		this.ResetMissingGarments();
	}

	this.GetBarcodeText = function() {
		return this.Store +
			'-' + this.EncodeTicketNumber() +
			'.' + this.EncodeMissingGarments()
	}


	this.LoadBarcode = function(barcode) {
		var storeMarker;
		var garmentMarker;
		var missingPieces;

		this.ResetBarcode();

		if(!barcode)
			return false;
		
		storeMarker = barcode.indexOf('-');

		if(storeMarker >= 0)
			this.Store = barcode.substring(0, storeMarker);
		else
			return false;

		garmentMarker = barcode.indexOf('.', storeMarker);

		if(garmentMarker > storeMarker)
			this.TicketNumber = this.ConvFromBase(barcode.substring(storeMarker + 1, garmentMarker), 36);
		else
			return false;

		missingPieces = barcode.substring(garmentMarker + 1);
		


		if(missingPieces != '') {
			missingPieces = this.ConvToBase(this.ConvFromBase(missingPieces, 36), 2);
			for(i = 0; i < missingPieces.length; ++i) {
				if(missingPieces.substr(i, 1) == '1')	{
					this.SetMissingGarment(missingPieces.length - i - 1);
				}
			}
		}

		return true;
	}


	this.ResetMissingGarments = function(i) {
		this.Missing = [];
	}

	this.SetMissingGarment = function(i) {
		this.Missing[i] = true;
	}

	this.IsMissingGarment = function(i) {
		return this.Missing[i];
	}

	this.ConvFromBase = function(str, base) {
		var i, m;
		var result = 0;

		for(i = 0; i < str.length; ++i)
		{
			m = this.Alphabit.indexOf(str.charAt(i).toUpperCase());
			result += Math.pow(base, str.length - i - 1) * m;
		}

		return result;
	}

	this.ConvToBase = function(n, base) {
		var result = '';
		
		if(n == '' || base > this.Alphabit.length)
			return '';

		while(n > 0) {
			result = this.Alphabit.charAt(n % base) + result;
			n = Math.floor(n / base);
		}

		return result;
	}

	this.EncodeTicketNumber = function() {
		return this.ConvToBase(this.TicketNumber, 36);
	}

	this.EncodeMissingGarments = function() {
		var missingDec = 0;

		for (var key in this.Missing) {
			missingDec += Math.pow(2, key);
		}

		return this.ConvToBase(missingDec, 36);
	}
}

