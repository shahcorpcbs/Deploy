<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<!--#include file="../external/include.asp" -->
<%
	include getBarcodeEncoderFilename()
	function getBarcodeEncoderFilename()
		on error resume next
		getBarcodeEncoderFilename = "/include/barcode.asp"
		getBarcodeEncoderFilename = getMSVar("BarcodeEncoderFile")
	end function
%>

<%
	dim invoicenumber
	dim ticketnumber
	dim oldCustomerSeq
	dim hsnumber
	dim isquickinvoice
	
	
	invoicenumber = trim(request.querystring("invoicenumber"))
	ticketnumber = trim(request.querystring("ticketnumber"))
	hsnumber = trim(Request.QueryString("hsnumber"))

	
	if invoicenumber <> "" then
		dim encoder
		set encoder = new BarcodeEncoder
		if encoder.LoadBarcode(invoicenumber) then
			if encoder.TicketNumber <> "" then
				ticketnumber = encoder.TicketNumber
			else
				invoicenumber = encoder.InvoiceNumber
			end if
		end if
	end if

	if ticketnumber = "" then
		if invoicenumber = "" then
			hsnumber = Request.QueryString("hsnumber")
			ticketnumber = hsNumToTicketNum(hsnumber)
		else
			ticketnumber = invoiceNumToTicketNum(invoicenumber)
		end if
	end if
	
	isquickinvoice = isQuickTicket(ticketnumber)

	oldCustomerSeq = Session("customerSequenceNumber")
	Session("customerSequenceNumber") = ticketGetCustomerSeq(ticketnumber)
	

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function
	
	function isRushTicket(ticketnumber)
		dim invoice
		
		if ticketnumber <> "" then
			set invoice = server.createobject("ShahCorpComponents.invoice")
			
			invoice.storeNumber = session("storeid")
		    invoice.initInvoice
	        invoice.DBConnectionString = Session("shahcorpDSN")
	        invoice.getExistingDetails ticketnumber
		
			isRushTicket = invoice.isRush()
		end if
		
		set invoice = nothing
	end function
	
	function invoiceNumToTicketNum(invoicenumber)
		dim query, rs
		
		
		query = "select ticketnumber from ticket where invoicenumber = '" & Replace(invoicenumber, "'", "''") & "'"
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			invoiceNumToTicketNum = rs("ticketnumber")
		end if
		
		set rs = nothing
	end function

	function hsNumToTicketNum(hsnumber)
		dim sqltxt, rs

		sqltxt = "select max(t.ticketnumber) as ticketnumber "
		sqltxt = sqltxt + "from ticket t, ticketlineitemtaggeditem tliti, taggedpiece tp "
		sqltxt = sqltxt + "where t.ticketnumber = tliti.ticketnumber "
		sqltxt = sqltxt + "and tliti.taggeditemid = tp.taggeditemid "
		sqltxt = sqltxt + "and t.ticketstatus = 'AC' "
		sqltxt = sqltxt + "and tp.heatsealid = '" + hsnumber + "'"
   		set rs = getdisconnectedrecordset(sqltxt)

		if rs.recordcount > 0 then
		        hsNumToTicketNum = rs("ticketnumber")
     	end if

     	set rs = nothing
	end function
		
	function ticketGetCustomerSeq(ticketNumber)
		dim query, rs
		
		ticketGetCustomerSeq = 0
		
		if ticketNumber <> "" then
			query = " select customersequencenumber from ticket where ticketnumber = " & ticketNumber
			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				ticketGetCustomerSeq = rs("customersequencenumber")
			end if
			set rs = nothing
		end if
	end function
	
	function isQuickTicket(ticketnumber)
		dim query, rs
		
		if ticketnumber <> "" then
			query = " select ticketnumber from ticket where invoicetype = 'Q' and ticketnumber = " & ticketnumber
			set rs = getdisconnectedrecordset(query)
			isQuickTicket = rs.recordcount > 0
			set rs = nothing
		end if
	
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">


<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<script language="javascript" type="text/javascript">

	function beginPrinting() {
<%		if ticketnumber <> "" then
			select case lcase(request.querystring("useraction"))
			case "printinvoice"
				if isquickinvoice then
%>
		PrintQuickInvoice(<%=ticketnumber%>);
<%
				else
%>
		PrintDetailedInvoice(<%=ticketnumber%>);
<%
				end if
			case "printtags"
%>
		PrintTagsForInvoiceNoPrompt(<%=ticketnumber%>);
<%
			end select
%>
		window.close();
<%
		end if
%>

	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="beginPrinting()" style="background:yellow">
<!-- #include file="../include/localprinter.inc" -->

<BR>
<BR>
<BR>
<BR>
<BR>
<BR>

<% if ticketnumber <> "" then %>
<div style="font-size:20;font-weight:bold;text-align:center">Printing...</div>
<% else %>
<div style="font-size:20;font-weight:bold;text-align:center">Could Not Find Invoice<BR><BR>
<input type="button" value="Close" onclick="window.close()" />
</div>
<% end if %>
</BODY>

</HTML>
<%
	Session("customerSequenceNumber") = oldCustomerSeq
%>
