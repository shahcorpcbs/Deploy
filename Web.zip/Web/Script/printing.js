var CbsForm = {
			Detailed: "detailed",
			Quick: "quick",
			Counter: "counter",
			Edit: "edit",
			Pickup: "pickup",
			Tag: "tag",
			HeatSeal: "heatseal",
			RackSlip: "rackslip",
			BagTag: "bagtag",
			Release: "release",
			CreditCard: "creditcard",
			Pdf: "pdf"};
			
var CbsKey = {
	InvoiceNumber: "invoicenumber",
	TicketNumber: "ticketnumber",
	CustomerSequenceNumber: "customerseq",
	HeatSealNumber: "hsn",
	TransactionID: "transactionid",
	VoidPaymentId: "voidpaymentid"
};


function GetPrinterNames()
{
	if(window.parent) {
		if(window.parent.GetPrinterNames) {
			return window.parent.GetPrinterNames();
		}		
	}
	
	return "";
}

function CbsPrintForm(formType, keyType, key, transParams)
{
	if(window.parent) {
		if(window.parent.PrintForm) {
			window.parent.PrintForm(formType, keyType, key, transParams);
		}		
	}
}

function PrintCreditCardReceipt(transactionId)
{
	CbsPrintForm(CbsForm.CreditCard, CbsKey.TransactionID, transactionId);
	
}

function PrintCreditCardVoidReceipt(voidPaymentId)
{
	CbsPrintForm(CbsForm.CreditCard, CbsKey.VoidPaymentId, voidPaymentId);
}


function PrintPickupInvoiceNoPrompt(ticketNumbers)
{
	CbsPrintForm(CbsForm.Pickup, CbsKey.TicketNumber, ticketNumbers);
}


function PrintPickupInvoice(ticketNumbers)
{
	CbsPrintForm(CbsForm.Pickup, CbsKey.TicketNumber, ticketNumbers);
}


function PrintQuickInvoice(ticketNumbers, alwaysPrint)
{
	CbsPrintForm(CbsForm.Quick, CbsKey.TicketNumber, ticketNumbers, alwaysPrint);
}

function PrintDetailedInvoice(ticketNumbers, alwaysPrint)
{
	CbsPrintForm(CbsForm.Detailed, CbsKey.TicketNumber, ticketNumbers, alwaysPrint);
}

function PrintPDFInvoice(ticketNumbers)
{
	CbsPrintForm(CbsForm.Pdf, CbsKey.TicketNumber, ticketNumbers);
}

function PrintCounterSaleInvoice(ticketNumbers)
{
	CbsPrintForm(CbsForm.Counter, CbsKey.TicketNumber, ticketNumbers);
}

function PrintEditInvoice(ticketNumbers)
{
	CbsPrintForm(CbsForm.Edit, CbsKey.TicketNumber, ticketNumbers);
}

function PrintReleaseForInvoice(ticketNumbers)
{
	CbsPrintForm(CbsForm.Release, CbsKey.TicketNumber, ticketNumbers);
}

function PrintTagsForInvoiceNoPrompt(ticketNumbers)
{
	CbsPrintForm(CbsForm.Tag, CbsKey.TicketNumber, ticketNumbers);
}

function PrintTagsForInvoice(ticketNumbers)
{
	CbsPrintForm(CbsForm.Tag, CbsKey.TicketNumber, ticketNumbers);
}

function PrintHeatSealsForInvoice(ticketNumbers)
{
	CbsPrintForm(CbsForm.HeatSeal, CbsKey.TicketNumber, ticketNumbers);
}

function PrintBagTag(customerSeqNumber)
{
	CbsPrintForm(CbsForm.BagTag, CbsKey.CustomerSequenceNumber, customerSeqNumber);
}

function PrintRackSlip(ticketNumbers)
{
	CbsPrintForm(CbsForm.RackSlip, CbsKey.TicketNumber, ticketNumbers);
}

function PrintCCReceipt(ticketNumbers)
{
	CbsPrintForm(CbsForm.CreditCard, CbsKey.TicketNumber, ticketNumbers);
}