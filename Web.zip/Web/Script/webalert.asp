<%@ Language=VBScript %>

<%
	dim priority
	priority = request.querystring("priority")
%>


<html>
<title>
<%=request.querystring("title")%>
</title>
<head>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">

function handle_onKeyPress() {
	if(window.event.keyCode == 13)
		window.event.keyCode = 0;
}
</script> 

</script>


</head>

<% if priority <= 3 then %>
<body STYLE="margin:0;padding:0" style="background:#eee" onKeyPress="handle_onKeyPress()">
<% else %>
<body STYLE="margin:0;padding:0" style="background:#eee">
<% end if %>

<table style="width:340px" border="0" cellspacing="0" cellpadding="0" style="background:#eee">
	<tr>
		<td align="center" valign="center" style="height:135px;font-size:16">
			<%=replace(request.querystring("txt"), "\n", "<br />")%>
		</td>
	</tr>

	<tr>
		<td align="center" valign="center" >
			<input type="button" id="okBtn" style="width:100px;height:50px" value="Ok" onclick="window.close()" />
		</td>
	</tr>
</table>
</body>

</html>
