
function OpenCashDrawer(ipAddress, printerName)
{
	//Variables are assumed to exist on calling page
	var url = ipAddress + "?printerName=" + encodeURIComponent(printerName);
	//console.log(url);
	try {
		$.ajax({
			type: "POST",
			url: url,
			dataType: "text",
			timeout: "3000",
			success: function(xhr) {
			},
			error: function(xhr, ajaxOptions, thrownError) {
				cbs_alert("Unable to connect to Printer Service to open Cash Drawer. Make sure service is running.");
			}
		});
	} catch (exception) {
		cbs_alert("Unable to send - " + exception.message);
	}
}
