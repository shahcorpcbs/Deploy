<%@ Language=VBScript %>

<%

    dim useReturn
    dim returnInfo
    useReturn = request.querystring("useReturn")
    returnInfo = request.querystring("returnInfo")
%>


<html>
<title>
<%=request.querystring("title")%>
</title>
<head>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">
	window.returnValue = false;
	
	function yes() {
		window.returnValue = true;
		<% if useReturn = 1 then %>
		    //window.opener.handleCBSConfirmReturn(true, '<%= returnInfo %>');
		<% end if %>
		window.close()
	}
	
	function no() {
		window.returnValue = false;
		<% if useReturn = 1 then %>
		    //window.opener.handleCBSConfirmReturn(false, '<%= returnInfo %>');
		<% end if %>
		window.close()
	}
</script>


</head>

<body STYLE="margin:0;padding:0" style="background:#eee">
<table style="width:340px" border="0" cellspacing="0" cellpadding="0" style="background:#eee">
	<tr>
		<td align="center" valign="center" style="height:135px;font-size:16">
			<%=replace(request.querystring("txt"), "\n", "<br />")%>
		</td>
	</tr>
	<tr>
		<td align="center" valign="center" >
			<input type="submit" id="yes" name="yes" style="width:100px;height:50px" value="Yes" onclick="yes()" />
			<input type="button" id="no" name="no" style="width:100px;height:50px" value="No" onclick="no()" />
		</td>
	</tr>
</table>
</body>

</html>
