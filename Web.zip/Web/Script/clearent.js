var version = "CBS_Clearent_1.0"

function performSale(amount, serviceLoc, key, invoiceNum, zip, orderId) {

    var body = {'type': 'SALE', 'amount':amount, "create-token":"true", "software-type" : version, 'order-id': orderId, 'billing': {'zip' : zip.replace(/^\s+|\s+$/g, '')}};
    //var url = baseUrl + "/rest/v2/terminal/transactions/sale";
    var url = getServerAddress() + serviceLoc + "/passThroughPost?path=" + encodeURI("/rest/v2/terminal/transactions/sale") + "&apiKey=" + encodeURI(key);


    $.ajax({
        type: "POST",
        url: url,
        data :JSON.stringify(body),
        dataType: "json",
        contentType: "application/json",
        Accept: "application/json",
        timeout: "120000",
        success: function(xhr) {
            try {
                //console.log(xhr);
                var transaction = xhr.payload.transaction;
                if (transaction["result-code"] === "000") {
                    var token = xhr.payload.tokenResponse;

                    //This function is assumed to exist on calling page
                    clearentCardSuccess(transaction.id, transaction.amount, transaction["card-type"] ? transaction["card-type"] : '',
                        'XXXXXXXXXXXX' + transaction["last-four"], transaction["exp-date"] ? transaction["exp-date"] : '', transaction["authorization-code"],
                        JSON.stringify(transaction), orderId, (token ? token["token-id"] : ''));
                }
                else {
                    if (xhr.payload.error != null) {
                        clearentFailure(JSON.stringify(xhr.payload), false, orderId, amount);
                    }
                    else {
                        clearentFailure(JSON.stringify(transaction), false, orderId, amount);
                    }
                }
            }
            catch (e) {
                //cbs_alert("ERROR " + e.message);
                clearentFailure("Javascript Error " + e.message, false, orderId, amount, true);
            }

        },
        error: function(xhr, ajaxOptions, thrownError) {
            console.log(xhr);
            try {
                if (ajaxOptions === "timeout") {
                    var errMsg = "Did not receive a response in time from Clearent. If card reader returns a success, transaction will be auto-voided";
                    clearentFailure("", true, orderId, amount, false, errMsg);
                } /*else if (xhr.status === 401) {
                    var errMsg = "Transaction not completed!\nUnable to connect to Clearent.";
                    clearentFailure(errMsg, false, orderId, amount, false, errMsg);
                }*/
                else {
                    var jsonResponse = JSON.parse(xhr.responseText);
                    var errMsg = "Transaction not completed!\n" + jsonResponse.payload.error["error-message"]
                    clearentFailure(JSON.stringify(jsonResponse.payload), false, orderId, amount, false, errMsg);
                }
            }
            catch (e) {
                var errMsg = "Error performing transaction -\n" + ajaxOptions + ":" + thrownError;
                clearentFailure(ajaxOptions + ":" + thrownError, false, orderId, amount, false, errMsg);
            }
        }
    });
}

function createOrderId(invoiceNum) {
    var today = new Date();
    var dateTime = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate() + ' ' + today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds() + ":" + today.getMilliseconds();
    return invoiceNum.replace(",", "|") + '_' + dateTime;
}

function chargeOnFileCard(amount, token, expiration, customerId, invoiceNum, serviceLoc, key, zip, orderId) {
    var url = getServerAddress() + serviceLoc + "/passThroughPost?path=" + encodeURI("/rest/v2/transactions/sale") + "&apiKey=" + encodeURI(key);

    var body = {'card' :token, 'customer-id':customerId, 'type': 'SALE', "software-type" : version,
        'amount':amount, 'exp-date': expiration, 'order-id': orderId, 'billing':{'zip' : zip.replace(/^\s+|\s+$/g, '')}};

    //console.log(JSON.stringify(body));

    $.ajax({
        type: "POST",
        url: url,
        data :JSON.stringify(body),
        dataType: "json",
        contentType: "application/json",
        Accept: "application/json",
        success: function(xhr) {
            try {
                //console.log(xhr);
                var transaction = xhr.payload.transaction;
                if (transaction["result-code"] === "000") {

                    //This function is assumed to exist on calling page
                    clearentCardSuccess(transaction.id, transaction.amount, transaction["card-type"] ? transaction["card-type"] : '',
                        transaction.card ? transaction.card : '', transaction["exp-date"] ? transaction["exp-date"] : '', transaction["authorization-code"],
                        JSON.stringify(transaction), orderId)
                }
                else {
                    if (xhr.payload.error != null) {
                        cbs_alert("Transaction not completed -\n" + xhr.payload.error["error-message"]);
                        clearentFailure(JSON.stringify(xhr.payload), false, orderId, amount);
                    }
                    else {
                        cbs_alert("Transaction not approved -\n" + transaction["display-message"]);
                        clearentFailure(JSON.stringify(xhr.payload), false, orderId, amount);
                    }
                }
            }
            catch (e) {
                cbs_alert("ERROR " + e.message);
                clearentFailure("Javascript Error " + e.message, false, orderId, amount, true);
            }

        },
        error: function(xhr, ajaxOptions, thrownError) {
            //console.log(xhr);
            try {
                if (xhr.statusText) {
                    var errMsg = "Transaction failure! Message:" + xhr.statusText;
                    clearentFailure(errMsg, (ajaxOptions === "timeout"), orderId, amount, false, xhr.statusText);
                } else if (xhr.status === 401) {
                    var errMsg = "Transaction not completed!\nUnable to connect to Clearent.";
                    clearentFailure(errMsg, false, orderId, amount, false, errMsg);
                }
                else {
                    var errMsg = "Error performing transaction - " + ajaxOptions + ":" + thrownError;
                    clearentFailure(errMsg, false, orderId, amount, false, errMsg);
                }
            }
            catch (e) {
                var errMsg = "Error performing transaction -\n" + ajaxOptions + ":" + thrownError;
                clearentFailure(ajaxOptions + ":" + thrownError, false, orderId, amount, false, errMsg);
            }
        }
    });
}

function createToken(serviceLoc, key) {
    var body = {'type': 'AUTH', 'amount':'0.00', 'create-token':'true'};
    var url = getServerAddress() + serviceLoc + "/passThroughPost?path=" + encodeURI("/rest/v2/terminal/transactions/token-only") + "&apiKey=" + encodeURI(key);

    $.ajax({
        type: "POST",
        url: url,
        data :JSON.stringify(body),
        dataType: "json",
        contentType: "application/json",
        Accept: "application/json",
        success: function(xhr) {
            try {
                //console.log(xhr);
                var token = xhr.payload.tokenResponse;
                beginUpdateClearentCard(token["token-id"], token["exp-date"] ? token["exp-date"] : "", token["last-four-digits"], token["card-type"]);
            }
            catch (e) {
                clearentTokenFailed("ERROR " + e.message);
            }

        },
        error: function(xhr, ajaxOptions, thrownError) {
            var errMsg;
            try {
                var jsonResponse = JSON.parse(xhr.responseText);
                errMsg = "Transaction not completed - " + jsonResponse.payload.error["error-message"];
            }
            catch(e) {
                errMsg = "Transaction not completed"
            }
            clearentTokenFailed(errMsg);
        }
    });
}

function createTokenWithCardInfo(serviceLoc, key, cardNum, expDate) {
    var body = {'card': cardNum, 'card-type': getCardType(cardNum), 'exp-date':expDate};
    var url = getServerAddress() + serviceLoc + "/passThroughPost?path=" + encodeURI("/rest/v2/tokens") + "&apiKey=" + encodeURI(key);

    $.ajax({
        type: "POST",
        url: url,
        data :JSON.stringify(body),
        dataType: "json",
        contentType: "application/json",
        Accept: "application/json",
        success: function(xhr) {
            try {
                console.log(xhr);
                var token = xhr.payload.tokenResponse;
                console.log(token);
                beginUpdateClearentCard(token["token-id"], token["exp-date"] ? token["exp-date"] : "", token["last-four-digits"], token["card-type"]);
            }
            catch (e) {
                clearentTokenFailed("ERROR " + e.message);
            }

        },
        error: function(xhr, ajaxOptions, thrownError) {
            var errMsg;
            try {
                var jsonResponse = JSON.parse(xhr.responseText);
                errMsg = "Transaction not completed -\n" + jsonResponse.payload.error["error-message"];
            }
            catch(e) {
                errMsg = "Transaction not completed"
            }
            clearentTokenFailed(errMsg);
        }
    });
}

function deleteToken(tokenId, serviceLoc, key) {
    var url = getServerAddress() + serviceLoc + "/deleteToken?tokenId=" + encodeURI(tokenId) + "&apiKey=" + encodeURI(key);

    $.ajax({
        type: "POST",
        url: url,
        dataType: "json",
        contentType: "application/json",
        Accept: "application/json",
        accepts: '',
        success: function(xhr) {
            gotoClearCard()
        },
        error: function(xhr, ajaxOptions, thrownError) {
            cbs_alert("Error: " + xhr.response)
            console.log(xhr);
            handleClearentDeleteFailure();
        }
    });
}


function batchProcessing(batchId, path) {
    showSpinner();
    var url = getServerAddress() + path;

    $.ajax({
        type: "POST",
        url: url + "/batch?batchId=" + batchId,
        async: true,
        dataType: "text",
        success: function(xhr) {
            hideSpinner();
            cbs_alert("Batch has been processed", refreshForm);
        },
        error: function(xhr, ajaxOptions, thrownError) {
            hideSpinner();
            cbs_alert("Unable to process batch, please make sure CBS Service is running")
            //console.log(xhr);
            //alert("Transaction failure! Message:" + xhr.statusText);
        }
    });
}

function addSpaces(num) {
    var result = "";
    for (i = 0; i < num; i++) {
        result += " ";
    }
    return result;
}

function createClearentReceiptData(transactionResult) {
    var text = "Terminal ID" + addSpaces(8) + transactionResult['terminalid'] + "\n";
    if (transactionResult.merchantid)
        text += "MID" + addSpaces(20) + transactionResult.merchantid + "\n";
    text += "Trans ID" + addSpaces(13) + transactionResult.id + "\n";
    text += "Payment Type" + addSpaces(6) + "Credit\n";
    text += "Trans Type" + addSpaces(10) + "Purchase\n";
    text += "Date/Time" + addSpaces(11) + timeNow() + "\n";
    text += "Card Type" + addSpaces(11) + transactionResult['cardtype'] + "\n";
    if (transactionResult.card)
        text += "Card Number" + addSpaces(7) + transactionResult.card +"\n";
    else
        text += "Card Number" + addSpaces(7) + "XXXXXXXXXXXX" + transactionResult.lastfour +"\n";
    if (transactionResult['emventrymethod'])
        text += "Entry Method" + addSpaces(7) + transactionResult['emventrymethod'] + "\n";
    if (transactionResult.cvm)
        text += "CVM" + addSpaces(19) + transactionResult.cvm + "\n";
    text += "Approval Code" + addSpaces(3) + transactionResult['authorizationcode'] + "\n";
    if (transactionResult.emv) {
        text += "AID" + addSpaces(20) + transactionResult.emv['applicationid']+ "\n";
        if (transactionResult.emv['applicationname'] )
            text += "AID NAME" + addSpaces(8) + transactionResult.emv['applicationname'] + "\n";
        text += "AC" + addSpaces(22) + transactionResult.emv['transactioncertificate']+ "\n";
        text += "ATC" + addSpaces(19) + transactionResult.emv['applicationtransactioncounter']+ "\n";
        text += "TVR" + addSpaces(19) + transactionResult.emv['terminalverificationresults']+ "\n";
        text += "IAD" + addSpaces(19) + transactionResult.emv['iad']+ "\n";
        text += "TSI" + addSpaces(19) + transactionResult.emv['transactionstatusinformation']+ "\n";
        if (transactionResult.emv.arc )
            text += "ARC" + addSpaces(19) + transactionResult.emv.arc + "\n";
    }
    text += "\n";
    text += "Total Amount" + addSpaces(8) +"USD$" + transactionResult.amount + "\n";
    text += "\n";
    text += "Description:_____________________________\n";
    text += "\n";
    text += addSpaces(10) + "Approved - Thank You\n";
    text += "\n";
    text += " X____________________________________\n";
    text += addSpaces(11) + "Cardholder Signature\n";
    text += "\n";
    text += "Buy agrees to pay total amount above\n";
    text += "according to cardholder's agreement with\n"
    text += "issuer.\n"

    return text;
}
 
function createClearentVoidReceiptData(transactionResult, amount) {
	//console.log("Creating void receipt");
	//console.log(transactionResult);
    var text = "Terminal ID" + addSpaces(8) + transactionResult['terminal-id'] + "\n";
    if (transactionResult.merchantid)
        text += "MID" + addSpaces(20) + transactionResult['merchant-id'] + "\n";
    text += "Trans ID" + addSpaces(14) + transactionResult.id + "\n";
    text += "Payment Type" + addSpaces(6) + "VOID\n";
    text += "Date/Time" + addSpaces(11) + timeNow() + "\n";
    if (transactionResult.card)
        text += "Card Number" + addSpaces(6) + transactionResult.card +"\n";
    else
        text += "Card Number" + addSpaces(7) + "XXXXXXXXXXXX" + transactionResult.lastfour +"\n";
    text += "Result " + addSpaces(17) + transactionResult['display-message'] + "\n";
    text += "Approval Code" + addSpaces(3) + transactionResult['authorization-code'] + "\n";

    text += "\n";
    text += "Voided Amount" + addSpaces(8) +"USD$" + amount + "\n";


    return text;
}

function timeNow() {
    var d = new Date();

    var year = d.getFullYear().toString();
    var month = (d.getMonth() + 101).toString().substring(1);
    var day = (d.getDate() + 100).toString().substring(1);
    h = (d.getHours()<10?'0':'') + d.getHours();
    m = (d.getMinutes()<10?'0':'') + d.getMinutes();
    ss = (d.getSeconds()<10?'0':'') + d.getSeconds();

    return  month + "/" + day + "/" + year + " " + h +":" + m + ":" + ss;
}

function sendVoidRequest(serviceLoc, key, transactionId) {
    var body = {'type': 'void', 'id':transactionId, "software-type" : version};
    //var url = baseUrl + "/rest/v2/transactions/void";
    var url = getServerAddress() + serviceLoc + "/passThroughPost?path=" + encodeURI("/rest/v2/transactions/void") + "&apiKey=" + encodeURI(key);


    $.ajax({
        type: "POST",
        url: url,
        data :JSON.stringify(body),
        dataType: "json",
        contentType: "application/json",
        Accept: "application/json",
        timeout: "120000",
        success: function(xhr) {
            try {
                //console.log(xhr);
                var transaction = xhr.payload.transaction;
                //This is the 'advice accepted' code that we expect on a void
                if (transaction["result-code"] === "036") {
                    //This function is assumed to exist on calling page
                    voidPaymentSuccess(JSON.stringify(transaction))
                }
                else {
                    cbs_alert("Unable to void transaction - " + transaction["display-message"]);
                    clearentVoidFailed();
                }
            }
            catch (e) {
                cbs_alert("ERROR " + e.message);
                clearentVoidFailed();
            }

        },
        error: function(xhr, ajaxOptions, thrownError) {
            //console.log(xhr);
            clearentVoidFailed();
            var jsonResponse = JSON.parse(xhr.responseText);
            cbs_alert("Unable to void transaction! " + jsonResponse.payload.error["error-message"], "Declined");
        }
    });

}

function checkApiKey(serviceLoc, baseUrl, key) {
    var url = getServerAddress() + serviceLoc + "/checkTerminal?apiKey=" + key + "&address=" + baseUrl;

    $.ajax({
        type: "GET",
        url: url,
        contentType: "text/plain",
        Accept: "*",
        timeout: "120000",
        success: function(xhr) {
            try {
                if (xhr == "0")
                    cbs_alert("Unable to connect to Clearent");
                else
                    cbs_alert("Connected to Clearent and Device Successfully, SN - " + xhr);
            }
            catch (e) {
                cbs_alert("ERROR " + e.message);
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
            //console.log(xhr);
            cbs_alert("Unable to connect to Clearent");
        }
    });
}


function getBackWardLookTime() {
    var d = new Date();
    d.setHours(d.getHours() - 2);

    var year = d.getFullYear().toString().substring(2);
    var month = (d.getMonth() + 101).toString().substring(1);
    var day = (d.getDate() + 100).toString().substring(1);
    h = (d.getUTCHours()<10?'0':'') + d.getUTCHours();
    m = (d.getMinutes()<10?'0':'') + d.getMinutes();

    return month + "-" + day + "-" + year + " " + h + ":" + m + " Z";
}


function checkForMissedApprovals(baseUrl, key) {
    var url = getServerAddress() + baseUrl + "/searchMissingTransactions?apiKey=" + key;
    try {
        $.ajax({
            type: "GET",
            url: url,
            contentType: "application/json",
            Accept: "application/json",
            timeout: "60000",
            success: function(xhr) {
                try {
                    handleClearentSearch(xhr);
                }
                catch (e) {
                    cbs_alert("ERROR " + e.message);
                }

            },
            error: function(xhr, ajaxOptions, thrownError) {
                //console.log(xhr);
                cbs_alert("Unable to connect to Clearent");
            }
        });
    } catch (exception) {
        cbs_alert("Unable to connect to clearent service to attempt")
    }
}

function checkUnfinished(baseUrl, key, orderId) {
    var url = getServerAddress() + baseUrl + "/searchUnfinishedTransactions?orderId=" + encodeURI(orderId) + "&apiKey=" + encodeURI(key);
    try {
        $.ajax({
            type: "GET",
            url: url,
            contentType: "application/json",
            Accept: "application/json",
            timeout: "60000",
            success: function(xhr) {
                try {
                    handleClearentSearch(xhr);
                }
                catch (e) {
                    cbs_alert("ERROR " + e.message);
                    enableScreen();
                }

            },
            error: function(xhr, ajaxOptions, thrownError) {
                //console.log(xhr);
                cbs_alert("Unable to connect to Clearent");
                enableScreen();
            }
        });
    } catch (exception) {
        cbs_alert("Unable to connect to clearent service to attempt")
        enableScreen();
    }
}

function getServerAddress() {
    var loc = window.location.href.toLowerCase();
    var extraCut = 0;
    if (loc.indexOf(":80") != -1)
        extraCut = 5;
    var endStop = loc.indexOf("/mainapp")
    if (endStop == -1)
        endStop = loc.indexOf("/setup")
    endStop = endStop - extraCut;
    return loc.substring(0, endStop);
}

function getCardType(cardNum) {
//Visa, mastercard, american express, discover, diners club, jcb
    if (cardNum.substring(0, 1) == '4')
        return "Visa";
    if (cardNum.substring(0, 2) == '34' || cardNum.substring(0, 2) == '37')
        return "American Express";
    if (cardNum.substring(0, 2) == '36')
        return "Diners Club";
    if (cardNum.substring(0, 2) == '35')
        return "JCB";
    if (cardNum.substring(0, 4) == '6011' || cardNum.substring(0, 2) == '64' || cardNum.substring(0, 2) == '65')
        return "Discover";

    return "MasterCard";
}


function closeMsg(serviceLoc, employeeId, customerId, invoices, terminalId, attemptId) {
    var url = getServerAddress() + serviceLoc + "/closedPage?employeeId=" + employeeId + "&customerId=" + customerId +
        "&invoices=" + encodeURIComponent(invoices) + "&terminalId=" + terminalId + "&attemptId=" + encodeURIComponent(attemptId);

    $.ajax({
        type: "POST",
        url: url,
        contentType: "text/plain",
        Accept: "*",
        timeout: "1200",
        success: function(xhr) {
        },
        error: function(xhr, ajaxOptions, thrownError) {
            console.log("error on close attempt");
            console.log(xhr);
            console.log(thrownError);
        }
    });
}
