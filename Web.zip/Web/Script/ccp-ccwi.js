function CreditCardProcessor() {


	this.Purchase = function(params) {
		var el;
		
		if(params.amount == null ||
			params.clerk == null ||
			params.renderTo == null)
		{
			alert("CreditCardProcessor.Purchase: missing params.");
			return;				
		}
		
		el = document.getElementById(params.renderTo);
		
		if(el) {
			el.innerHTML = '<iframe name="cc_frame" id="cc_frame" style="width:400px; height:300px; border: 1px solid" frameborder="0" scrolling="no" src="http://localhost:8080/purchase.html"></iframe>';

			$("#cc_frame").bind("load", function(event) {
				var cc = this.contentWindow;
				cc.set_amount(params.amount);
				cc.set_clerk(params.clerk);
				cc.on("success", params.success);
				
				cc.on("close", function() {
					$("#cc_frame").hide();
					if(params.close)
						params.close();
				});
				
				cc.begin();
			});
		}
	}
}
