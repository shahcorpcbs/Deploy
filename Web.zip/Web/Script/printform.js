function webuiResult(){
	var input;
}

function pf_printTags(invoiceNumber){
	return window.showModalDialog(
		"/Script/printform.asp?useraction=printtags&invoicenumber=" + encodeURIComponent(invoiceNumber),
		webuiResult,
		"status:no;dialogHeight:245px;dialogWidth:350px;center;edge:Sunken;help:No;resizable: No;scroll:no;");
}

function pf_printInvoice(invoiceNumber){
	return window.showModalDialog(
		"/Script/printform.asp?useraction=printinvoice&invoicenumber=" + encodeURIComponent(invoiceNumber),
		webuiResult,
		"status:no;dialogHeight:245px;dialogWidth:350px;center;edge:Sunken;help:No;resizable: No;scroll:no;");
}


function pf_printTagsTN(ticketNumber){
	return window.showModalDialog(
		"/Script/printform.asp?useraction=printtags&ticketnumber=" + encodeURIComponent(ticketNumber),
		webuiResult,
		"status:no;dialogHeight:245px;dialogWidth:350px;center;edge:Sunken;help:No;resizable: No;scroll:no;");
}

function pf_printInvoiceTN(ticketNumber){
	return window.showModalDialog(
		"/Script/printform.asp?useraction=printinvoice&ticketnumber=" + encodeURIComponent(ticketNumber),
		webuiResult,
		"status:no;dialogHeight:245px;dialogWidth:350px;center;edge:Sunken;help:No;resizable: No;scroll:no;");
}

function pf_printInvoiceHSN(hsNumber){
	return window.showModalDialog(
		"/Script/printform.asp?useraction=printinvoice&hsnumber=" + encodeURIComponent(hsNumber),
		webuiResult,
		"status:no;dialogHeight:245px;dialogWidth:350px;center;edge:Sunken;help:No;resizable: No;scroll:no;");
}

