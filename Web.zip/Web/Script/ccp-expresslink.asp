<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<!--#include file="../include/json.asp"-->

<!--#include file="../include/manifest.asp"-->
<%
	dim query, rs

	'getdisconnectedrecordset lcase(request.querystring("a"))
	
	select case lcase(request.querystring("transaction_type"))
	case "purchase"
		CardPurchase
	case "begin-purchase"
		BeginCardPurchase
	case "add-card"
		AddCard
	case "update-card"
		UpdateCard
	case "delete-card"
		DeleteCard
	end select

	function AddCard()
		dim answer
		answer = request.querystring("answer")
		response.write XMLAnswerToJSON(answer)
	end function
	

	function UpdateCard()
		dim answer
		answer = request.querystring("answer")
		response.write XMLAnswerToJSON(answer)
	end function
	

	function DeleteCard()
		dim answer
		answer = request.querystring("answer")
		response.write XMLAnswerToJSON(answer)
	end function
	
	function BeginCardPurchase()
		dim query, rs
		dim terminalid
		dim clerk
		dim customerseq
		dim transactionid
		dim amount
		
		terminalid = dbcreateqrynumeric(request.querystring("terminalid"))
		clerk = dbcreateqrynumeric(request.querystring("clerk"))
		customerseq = dbcreateqrynumeric(request.querystring("customerseq"))
		transactionid = dbcreateqrynumeric(request.querystring("transaction_id"))
		amount = dbcreateqrynumeric(request.querystring("amount"))

		query = " insert into cardpayment(terminalid, clerk, customersequencenumber, transactionid, amount) "
		query = query & " values ( "
		query = query & terminalid & ", "
		query = query & clerk & ", "
		query = query & customerseq & ", "
		query = query & "'" & dbstr(transactionid) & "', "
		query = query & amount
		query = query & " ) "

		qryexecute query
	end function


	function CardPurchase()
		dim answer
		
		answer = request.querystring("answer")

		response.write XMLAnswerToJSON(answer)
	end function
	
	function XMLAnswerToJSON(xml)
		dim query, rs
		dim transactionid
		dim result
		dim xml_doc
		dim success
		dim result_nodes, node
		
		success = 0
		set xml_doc = server.createobject("MSXML2.DOMDocument")
		
		if not xml_doc.loadXML(xml) then
			result = "{ "
			result = result & """success"": ""0"", "
			result = result & """result"": """ & js_encode("Invalid XML") & """ "
			result = result & "}"
		else
			set result_nodes = xml_doc.selectNodes("//XCEXPRESSLINKRESULT/*")
			
			success = 0
			
			result = "{"
			
			for each node in result_nodes
				result = result & """" & lcase(node.nodeName) & """: """ & js_encode(node.text) & """, "
				if (ucase(node.nodeName) = "APPROVALCODE" and node.text <> "") or (ucase(node.nodeName) = "RESULT" and node.text = "SUCCESS") then
					success = 1
				end if
			next
			
			result = result & """success"": """ & success & """"


			result = result & "}"
		end if

		transactionid = request.querystring("transaction_id")
		
		query = " update cardpayment set "
		query = query & " rawanswer = '" & dbstr(xml) & "',"
		query = query & " success = " & success
		query = query & " where transactionid = '" & dbstr(transactionid) & "'"
		
		getdisconnectedrecordset query

		XMLAnswerToJSON = result
	end function

	

	function js_encode(s)
		on error resume next
		if not isnull(s) then
			js_encode = s
			js_encode = Replace(js_encode, "\", "\\") 
			js_encode = Replace(js_encode, """", "\""")
			js_encode = Replace(js_encode, vbCr, "\r")
			js_encode = Replace(js_encode, vbLf, "\n")
		end if
	end function 



%>