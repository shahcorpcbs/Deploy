<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../external/json.asp" -->
<!--#include file="../external/include.asp" -->
<%
	include getBarcodeEncoderFilename()
	function getBarcodeEncoderFilename()
		on error resume next
		getBarcodeEncoderFilename = "/include/barcode.asp"
		getBarcodeEncoderFilename = getMSVar("BarcodeEncoderFile")
	end function
	
	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function
	
	
	select case lcase(request.querystring("func"))
	case "loadbarcode"
		response.write LoadBarcode()
	end select
	
	
	function LoadBarcode()
		dim barcode
		dim json_encoder
		dim result
		
		set result = Server.CreateObject("scripting.dictionary")
		
		set json_encoder = new JSON
		set barcode = new BarcodeEncoder
		
		
		if barcode.LoadBarcode(request.querystring("barcode")) then
			result.add "Success", "1"
		else
			result.add "Success", "0"
		end if
		
		result.add "InvoiceNumber", barcode.InvoiceNumber
		result.add "TicketNumber",  barcode.TicketNumber
		result.add "Store", barcode.Store

		LoadBarcode = json_encoder.toJSON("LoadBarcode", result, false, null)
	end function
	
	
	
%>


