function webuiResult(){
	var input;
}

function isOtherMsgActive() {
	return document.getElementById('alertBox').style.display === 'block' ||
		document.getElementById('confirmBox').style.display === 'block' ||
		document.getElementById('optionBox').style.display === 'block' ||
		document.getElementById('promptBox').style.display === 'block' ||
		document.getElementById('promptWSelBox').style.display === 'block';
}


async function cbs_alert(txt, finishFunction) {
	while (isOtherMsgActive()) {
		await sleep(500);
	}

	document.getElementById("alertHeader").innerText = txt;
	if (finishFunction)
		document.getElementById("alertBtn").onclick = finishFunction;
	else
		document.getElementById("alertBtn").onclick = clearAlertMsg;
	document.getElementById('alertBox').style.display = 'block';
}

async function cbs_confirm(txt, successFunction, failureFunction, yesText, noText) {
	while (isOtherMsgActive()) {
		await sleep(500);
	}

	document.getElementById("confirmHeader").innerText = txt;
	document.getElementById("confirmBtn1").onclick = successFunction;
	if (failureFunction)
		document.getElementById("confirmBtn2").onclick = failureFunction;
	else
		document.getElementById("confirmBtn2").onclick = clearConfirmMsg;

	if (yesText)
		document.getElementById('confirmBtn1').innerText = yesText;
	if (noText)
		document.getElementById('confirmBtn2').innerText = noText;

	document.getElementById('confirmBox').style.display = 'block';
}

async function cbs_prompt(txt, returnFunction, input, multiline, amountField, declineFunction) {
	while (isOtherMsgActive()) {
		await sleep(500);
	}
	document.getElementById("promptHeader").innerText = txt;

	document.getElementById('inputTxtArea').value = '';
	document.getElementById('inputTxtLine').value = '';
	if (input) {
		if (multiline)
			document.getElementById('inputTxtArea').value = input;
		else
			document.getElementById('inputTxtLine').value = input;
	}

	if (amountField)
		document.getElementById('inputTxtLine').addEventListener("keyup", decimalFormat);

	document.getElementById("promptBtn1").onclick = returnFunction;
	if (declineFunction)
		document.getElementById("promptBtn2").onclick = declineFunction;
	document.getElementById('promptBox').style.display = 'block';

	if (multiline) {
		document.getElementById('inputTxtArea').style.display = 'block';
		document.getElementById('inputTxtLine').style.display = 'none';
		document.getElementById('inputTxtArea').focus();
		document.getElementById('inputTxtArea').select();
	}
	else {
		document.getElementById('inputTxtArea').style.display = 'none';
		document.getElementById('inputTxtLine').style.display = 'block';
		document.getElementById('inputTxtLine').focus();
		document.getElementById('inputTxtLine').select();
	}
}

async function cbs_select(txt, btnPerRow, options, returnFunction) {
	while (isOtherMsgActive()) {
		await sleep(500);
	}
	var optionsSplit;
	var optionsCount;
	if(options) {
		optionsSplit = options.toString().split("|");
		optionsCount = optionsSplit.length;
	}
	else
		optionsCount = 0;

	document.getElementById("optionHeader").innerText = txt;
	var table = document.getElementById("optionTable");
	table.innerHTML = "";
	var rowCnt = 0;
	var cellCnt = 0;
	var row;
	for (var i = 0; i < optionsCount; i++) {
		if (i % btnPerRow === 0) {
			row = table.insertRow(rowCnt);
			rowCnt++;
			cellCnt = 0;
		}
		var cell = row.insertCell(cellCnt++);
		cell.innerHTML = "<BUTTON class=\"overlayBtn\" onclick=\"" + returnFunction + "(" + i + ")\">"
			+ optionsSplit[i] + "</BUTTON>"
	}

	document.getElementById('optionBox').style.display = 'block';
}

async function cbs_promptWSelect(txt, options, input, multiline, returnFunction) {
	while (isOtherMsgActive()) {
		await sleep(500);
	}
	promptWSelChoice = null;
	var optionsSplit;
	var optionsCount;
	if(options) {
		optionsSplit = options.toString().split("|");
		optionsCount = optionsSplit.length;
	}
	else
		optionsCount = 0;

	document.getElementById("promptWSelHeader").innerText = txt;
	var table = document.getElementById("optionTable2");
	table.innerHTML = "";
	var row;
	for (var i = 0; i < optionsCount; i++) {
		row = table.insertRow(i);
		var cell = row.insertCell(0);
		cell.innerHTML = "<BUTTON class=\"overlayBtn\" value=\"" + optionsSplit[i] + "\" onclick=\"setPromptWSelChoice(this)\">"
			+ optionsSplit[i] + "</BUTTON>"
	}

	document.getElementById("promptWSelBtn1").onclick = returnFunction;
	document.getElementById('promptWSelBox').style.display = 'block';

	if (multiline) {
		document.getElementById('inputTxtArea2').style.display = 'block';
		document.getElementById('inputTxtLine2').style.display = 'none';
		if (input)
			document.getElementById('inputTxtArea2').value = input;
		document.getElementById('inputTxtArea2').focus();
	}
	else {
		document.getElementById('inputTxtArea2').style.display = 'none';
		document.getElementById('inputTxtLine2').style.display = 'block';
		if (input)
			document.getElementById('inputTxtLine2').value = input;
		document.getElementById('inputTxtLine2').focus();
	}

}

function show_focus(txt) {
	document.getElementById("smallHeader").innerText = txt;
	document.getElementById('smallBox').style.display = 'block';
}

function promptKeyPress(event) {
	if (event.code === "Enter")
		document.getElementById("promptBtn1").click();

}

function promptWSelKeyPress(event) {
	if (event.code === "Enter")
		document.getElementById("promptWSelBtn1").click();

}

function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}