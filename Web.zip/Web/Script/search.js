function cbs_customer_search(dest) {
	location.href = "/mainapp/customersearch.asp?targetpage=search&dest=" + encodeURIComponent(dest);
}
