<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<!--#include file="../include/json.asp"-->

<!--#include file="../include/manifest.asp"-->
<%
	dim query, rs

	response.write GetCashDrawer(request.querystring("terminalid"))

	
		
	function GetCashDrawer(terminalid)
		dim query, rs
		dim result
		
		query = " select storehardware.cashdrawertype, isnull(printer.printername, '') as printername "
		query = query & " from storehardware "
		query = query & " left outer join printer on storehardware.cashdrawerattachedprinterid = printer.printerid "
		query = query & " where storehardware.hardwaretype = 'CD' "
		query = query & " and storehardware.terminalid = " & terminalid
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			result = "{"
			result = result & "device: """ & js_encode(rs("printername")) & ""","
			
			select case trim(rs("cashdrawertype"))
			case "L"
				result = result & "method: ""printer-port"""
			case "S"
				result = result & "method: ""printer-doc"""
			case "R"
				result = result & "method: ""serial"""
			case "U"
				result = result & "method: ""usb"""
			case else
				result = result & "method: """""
			end select

			result = result & "}"
		end if
		
		GetCashDrawer = result
	end function

	function js_encode(s)
		on error resume next
		if not isnull(s) then
			js_encode = s
			js_encode = Replace(js_encode, "\", "\\") 
			js_encode = Replace(js_encode, """", "\""")
			js_encode = Replace(js_encode, vbCr, "\r")
			js_encode = Replace(js_encode, vbLf, "\n")
		end if
	end function 
%>