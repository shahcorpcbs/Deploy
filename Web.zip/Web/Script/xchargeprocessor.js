XChargeProcessor = function(XCExpressLink) {
	var OnSuccess = null;
	var OnFailure = null;
	var XChargePath = 'C:\\Program Files\\X-Charge\\XCharge.exe';
	
	
	var PurchaseXChargeParams = '/TRANSACTIONTYPE:Purchase /LOCKTRANTYPE /AMOUNT:@@@AMOUNT /TRACK:@@@TRACK /ACCOUNT:@@@ACCOUNT /EXP:@@@EXP /ZIP:@@@ZIP /CV:@@@CV /RECEIPT:@@@RECEIPT /CLERK:@@@CLERK /XMLRESULTFILE /STAYONTOP /AUTOPROCESS /AUTOCLOSE /SMALLWINDOWNOCOLORS /TITLE:CBS /NORESULTDIALOG';
	
	var AddCardPanel = new Ext.FormPanel({
	    labelWidth: 130,
	    frame:true,
	    bodyStyle:'padding:5px',
	    defaults: {width: 150},
	    defaultType: 'textfield',
	    items: [
	    
	    	{
	            fieldLabel: 'Account Number',
	            name: 'account',
	            allowBlank: false,
	            selectOnFocus: true,
	            listeners: {
					'specialkey': function(f,e) {
						if(e.getKey() == 13) {
							var track1, track2;
							var tracks = this.getValue().split('?');
	
							this.setValue('');
							PurchasePanel.getForm().findField('exp').setValue('');
							PurchasePanel.getForm().findField('track2').setValue('');
							
							track1 = (tracks.length > 0 ? tracks[0] + '?' : '');
							track2 = (tracks.length > 1 ? tracks[1] + '?' : '');
							
							if(tracks.length = 2 && track2.length > 16) {
	    						var fl = track2.split('=');
	    						this.setValue(fl[0].substring(1));
	    						PurchasePanel.getForm().findField('exp').setValue(fl[1].substring(0, 4));
								PurchasePanel.getForm().findField('track2').setValue(track2);
							}
							this.focus(true);
						}
					}
				}
	        },{
	            fieldLabel: 'Expiration (YYMM)',
	            name: 'exp'
	        },{
	            fieldLabel: 'Track2',
	            name: 'track2',
	            hidden: true,
	            hideLabel: true,
	            readOnly: true
	        }
	    ]
	});
	
	
	
	var AddCardWindow = new Ext.Window({
	    title       : 'Add Card',
	    layout      : 'fit',
	    width       : 350,
	    height      : 300,
	    closeAction :'hide',
	    plain       : true,
	    items       : PurchasePanel,
	    draggable   : false,
		resizable   : false,
		modal       : true,
	    buttons: [{
	        text     : 'Save',
	        handler  : function() {
		    	fs.getForm().submit({url:'creditCardActions.asp?type=add', waitMsg:'Saving Data...'});
		    	PurchaseWindow.hide();
	        }
	    },{
	        text     : 'Close',
	        handler  : function() {
		        OnFailure({result: 'Window closed'});
	            PurchaseWindow.hide();
	        }
	    }]
	});
	
	
	
	var PurchasePanel = new Ext.FormPanel({
	    labelWidth: 130,
	    frame:true,
	    bodyStyle:'padding:5px',
	    defaults: {width: 150},
	    defaultType: 'textfield',
	    items: [
	    
	    	{
	            fieldLabel: 'Amount',
	            name: 'amount',
	            allowBlank:false,
	            readOnly: true
	        },{
	            fieldLabel: 'Account Number',
	            name: 'account',
	            allowBlank: false,
	            selectOnFocus: true,
	            listeners: {
					'specialkey': function(f,e) {
						if(e.getKey() == 13) {
							var track1, track2;
							var tracks = this.getValue().split('?');
	
							this.setValue('');
							PurchasePanel.getForm().findField('exp').setValue('');
							PurchasePanel.getForm().findField('track2').setValue('');
							
							track1 = (tracks.length > 0 ? tracks[0] + '?' : '');
							track2 = (tracks.length > 1 ? tracks[1] + '?' : '');
							
							if(tracks.length = 2 && track2.length > 16) {
	    						var fl = track2.split('=');
	    						this.setValue(fl[0].substring(1));
	    						PurchasePanel.getForm().findField('exp').setValue(fl[1].substring(0, 4));
								PurchasePanel.getForm().findField('track2').setValue(track2);
							}
							this.focus(true);
						}
					}
				}
	        },{
	            fieldLabel: 'Expiration (YYMM)',
	            name: 'exp'
	        },{
	            fieldLabel: 'Zip Code',
	            name: 'zip'
	        },{
	            fieldLabel: 'CVV2/CVC2',
	            name: 'cv'
	        },{
	            fieldLabel: 'Receipt',
	            name: 'receipt',
	            readOnly: true
	        },{
	            fieldLabel: 'Track2',
	            name: 'track2',
	            hidden: true,
	            hideLabel: true,
	            readOnly: true
	        }
	    ]
	});
	
	var PurchaseWindow = new Ext.Window({
	    title       : 'Credit Card Purchase',
	    layout      : 'fit',
	    width       : 350,
	    height      : 300,
	    closeAction :'hide',
	    plain       : true,
	    items       : PurchasePanel,
	    draggable   : false,
		resizable   : false,
		modal       : true,
	    buttons: [{
	        text     : 'Submit',
	        handler  : function() {
		    	BeginPurchase(PurchasePanel.getForm().getValues(false));
		    	PurchaseWindow.hide();
	        }
	    },{
	        text     : 'Close',
	        handler  : function() {
		        OnFailure({result: 'Window closed'});
	            PurchaseWindow.hide();
	        }
	    }]
	});
	
	
	var BeginPurchase = function(params) {
		try {
			XCExpressLink.XCLinkEXE = XChargePath;
			XCExpressLink.XCLinkParamStr = PurchaseXChargeParams;
			
			XCExpressLink.ClearParams();

			XCExpressLink.AddParam('@@@AMOUNT', params['amount']);
			XCExpressLink.AddParam('@@@TRACK', params['track2']);
			XCExpressLink.AddParam('@@@ACCOUNT', params['account']);
			XCExpressLink.AddParam('@@@EXP', params['exp']);
			XCExpressLink.AddParam('@@@ZIP', params['zip']);
			XCExpressLink.AddParam('@@@RECEIPT', params['receipt']);
			XCExpressLink.AddParam('@@@CV', params['cv']);
			XCExpressLink.AddParam('@@@CLERK', employeeID);
			
			var xcresponse = XCExpressLink.Process();
	
			ProcessResult(xcresponse, 'purchase');
		}
		catch(ex) {
			Ext.MessageBox.alert('Error Processing', ex.description);
		}
	}
	
	var ProcessResult = function(xcresponse, transactiontype) {
			Ext.Ajax.request({
			url: '/mainapp/creditCardActions.asp',
			success: function(result) {
				var resultObj = Ext.util.JSON.decode(result.responseText);
				if(OnSuccess)
					OnSuccess(resultObj);
				if(resultObj.success == 0) {
					Ext.MessageBox.alert('Error Processing', resultObj.result);	
				}
			},
			failure: function(result) {
				if(OnFailure)
					OnFailure({result: 'No answer from processor'});
				Ext.MessageBox.alert('Error Processing', 'Answer could not be retrieved from the processor.');
			},
			params: { xcresponse: xcresponse, transactiontype: transactiontype }
		});
	}

	var ClosePurchaseWindow = function() {
		if(PurchaseWindow.isVisible()) {
	        OnFailure({result: 'Window closed'});
            PurchaseWindow.hide();
		}
	}
	
	
	var ShowPurchaseWindow = function(params) {
		OnSuccess = params.success;
		OnFailure = params.failure;
		
		if(!PurchaseWindow.isVisible()) {
			PurchaseWindow.show();
			var purchaseForm = PurchasePanel.getForm();
			purchaseForm.reset();
			purchaseForm.findField('amount').setValue(params.amount);
			purchaseForm.findField('receipt').setValue(params.receipt);
			purchaseForm.findField('account').focus(true, 500);
			
			setTimeout(ClosePurchaseWindow, 120000);
		}
	}
	
	var TransactionTypes = {
		'purchase' : {description:'Credit Card Purchase', show:ShowPurchaseWindow}
	};
	
	
	this.BeginTransaction = function(typeName, params) {
		var transactionType = TransactionTypes[typeName];
		if(transactionType) {
			transactionType.show(params);
		}
	}

}