<%@ Language=VBScript %>

<%
    dim options
    dim optionsArray
    dim idx
    dim defaultOption
    dim useReturn
    dim returnInfo
    
    options = request.querystring("options")
    defaultOption = request.querystring("defaultOption")
    useReturn = request.querystring("useReturn")
    returnInfo = request.querystring("returnInfo")
    
%>


<html>
<title>
<%=request.querystring("title")%>
</title>
<head>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">
	window.returnValue = null;
	var lastSelection = '<%=defaultOption%>';
	
	
	function vb_replace(src, match, replacement){
		var temp = src;
		
		var i = temp.indexOf(match);

		while(i >= 0) {
		
			temp = temp.replace(match, replacement);
			i = temp.indexOf(match, i + replacement.length + 1);
		}
		
		return temp;
	}
	
	function ok() {
		if(!lastSelection) {
			alert('One option must be selected before continuing');
			return false;
		}
		else {
			returnValue = lastSelection;
		}

		<% if useReturn = 1 then %>
		    window.opener.handleCBSSelectReturn(returnValue, '<%= returnInfo %>');
		    window.opener.focus();
		<% end if %>
		window.close()
	}
	
	function cancel() {
		window.returnValue = null;
		window.close()
	}
	
	function selectOption(o) {
		unselectAll();

		
		o.style.background = 'red';
		
		lastSelection = o.value;

		ok();
	}
	
	function unselectAll() {
		var il = document.getElementsByTagName('input');
		var len = il.length;
		var i, e;

		for (i = 0; i < len; i++) {
		    e = il[i];
		    if (e.name == "selectOption") {
					e.style.background = 'white';	
		    }
		}
	}
	
</script>


</head>

<body STYLE="margin:0;padding:0" onload="" style="background:#eee">
<table style="width:340px" border="0" cellspacing="0" cellpadding="0" style="background:#eee">
	<tr>
		<td style="height:30px" colspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td align="center" valign="center" style="height:55px;font-size:16" colspan="2">
			<%=replace(request.querystring("txt"), "\n", "<br />")%>
		</td>
	</tr>
  <%

    if options <> "" then
      optionsArray = split(options, "|")
  %>
	<tr>
	  <td align="center" valign="center">
	<%
    for idx = lbound(optionsArray) to ubound(optionsArray)
  %>
  		<input
  		name="selectOption"
  		style="width: 200px; height: 40px; <%if optionsArray(idx) = defaultOption then %>background:red<%else%>background:white<%end if%>"
  		type="button" value="<%=optionsArray(idx)%>" onclick="selectOption(this)" /><br>
  	<%
    next
  %>
	  </td>
	</tr>
  <%
    end if
   %>
<!--	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td align="center" valign="center" >
			<input type="submit" style="width:100px;height:50px" value="Ok" onclick="ok()" />
			<input type="button" style="width:100px;height:50px" value="Cancel" onclick="cancel()" />
		</td>
	</tr>

	<table style="width:340px" border="0" cellspacing="0" cellpadding="0" style="background:#eee">
    	<tr>
    		<td align="center" valign="center" style="height:135px;font-size:16">
    			<%=replace(request.querystring("txt"), "\n", "<br />")%>
    		</td>
    	</tr>
    	<tr>
    		<td align="center" valign="center" >
    			<input type="submit" style="width:100px;height:50px" value="Yes" onclick="yes()" />
    			<input type="button" style="width:100px;height:50px" value="No" onclick="no()" />
    		</td>
    	</tr>
    </table>



-->
</table>


</body>

</html>
