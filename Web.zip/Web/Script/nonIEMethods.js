var windowOpen = false;
var innerJob = ""

async function printJobNonIE(job, msg, title) {
	while (windowOpen) {
		await sleep(1500);
	}
	innerJob = job;
	windowOpen = true;
	cbs_confirm(msg, doStart, windowClose);
}

function doStart() {
	windowClose();
	nonIEStartJob(innerJob);
}
function windowClose() {
	clearConfirmMsg();
	windowOpen = false;
}

function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}

var jobRunning = false;
async function nonIEStartJob(job) {
	if(job) {
		var d
		while (jobRunning) {
			await sleep(500);
				if (testing) {
					d = new Date();
					console.log("waiting - " + d.toLocaleTimeString() + "." + d.getMilliseconds());
				}
		}
		try {
			jobRunning = true;
			if(job.url.length > 0) {
				if (testing) {
					console.log("inside nonIE start jobs");
					d = new Date();
					console.log(d.toLocaleTimeString() + "." + d.getMilliseconds());
					console.log(job);
				}
				var random = Math.floor(Math.random() * 10000);
				for(var j = 0; j < job.url.length; j++) {
					var modUrl = job.url[j] + "&UID=" + random;
					if (j == (job.url.length - 1))
						modUrl = modUrl + "&last=1";
					if (testing)
						console.log("Modified url = " + modUrl);
						try {
							jQuery.ajax({
								type: "GET",
								url: modUrl,
								async: false,
								success: function (data) {
									if (modUrl.indexOf("type=pdf") > 0) {
										var link = document.getElementById("downloadLink");
										link.href = "../ReportOutFiles/" + data;
										link.click();
									}

									if (testing) {
										console.log("inside success");
										console.log(data);
										console.log("end");
									}
								},
								error: function (xhr, ajaxOptions, thrownError) {
									cbs_alert("Printing failed")
									console.log(xhr)
									console.log(ajaxOptions)
									console.log(thrownError)
								}
							});
						} catch (exception) {
							cbs_alert("error - " + exception);
							console.log(exception)
						}
				}
			}
			if (testing) {
				d = new Date();
				console.log("before slept - " + d.toLocaleTimeString() + "." + d.getMilliseconds());
			}
			await sleep(500);
			if (testing) {
				d = new Date();
				console.log("slept - " + d.toLocaleTimeString() + "." + d.getMilliseconds());
			}
		} catch (exception) {
			console.log("Error here?");
			console.log(exception);
		}
		jobRunning = false;
	}
}
