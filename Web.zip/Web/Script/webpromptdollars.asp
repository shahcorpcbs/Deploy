<%@ Language=VBScript %>

<%
    dim useReturn
    dim returnInfo
    useReturn = request.querystring("useReturn")
    returnInfo = request.querystring("returnInfo")
%>


<html>
<title>
<%=request.querystring("title")%>
</title>
<head>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript" src="/Script/validation.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<script language="javascript" type="text/javascript">
	window.returnValue = null;
	var lastSelection = null;
	
	
	function vb_replace(src, match, replacement){
		var temp = src;
		
		var i = temp.indexOf(match);

		while(i >= 0) {
		
			temp = temp.replace(match, replacement);
			i = temp.indexOf(match, i + replacement.length + 1);
		}
		
		return temp;
	}
	
	function ok() {
		<% if options <> "" then %>
		if(!lastSelection) {
			alert('One option must be selected before continuing');
			return false;
		}
		<% end if %>

		var returnValue = inputField.value + (lastSelection ? '|' + lastSelection.value : '');
		<% if useReturn = 1 then %>
		    window.opener.handleCBSPromptDollarsReturn(returnValue, '<%= returnInfo %>');  //Must exist on calling page
		    window.opener.focus();
		<% else %>
		    window.returnValue = returnValue;
		<% end if %>
		window.close()
	}
	
	function cancel() {
	
		window.returnValue = null;
		window.close()
	}
	
	function selectOption(o) {
		if(lastSelection) {
			lastSelection.style.background = 'white';	
		}
		
		o.style.background = 'red';
		
		lastSelection = o;
	}
	
	function decimalFormat(obj) {
		var price;
		
		price = obj.value;
		price = trim(price);
		if(price.length > 0) {
			price = cleanNumeric(price);
			if(price == "")	{
				show_focus("Please enter a valid amount.","CBS Error", obj);
				return;
			}
		}
		obj.value = autoFormatCurrency(obj.value);		
	}
	
	
</script>


</head>

<body STYLE="margin:0;padding:0" onload="inputField.select();inputField.focus()" style="background:#eee">
<table style="width:340px" border="0" cellspacing="0" cellpadding="0" style="background:#eee">
	<tr>
		<td align="center" valign="center" style="height:55px;font-size:16">
			<%=replace(request.querystring("txt"), "\n", "<br />")%>
		</td>
	</tr>

	<tr>
		<td align="center" valign="center" style="height:80px" >
			<% if request.querystring("multiline") = 1 then %>
			<textarea id="inputField" style="width:300px" rows="4" style="overflow:auto" ><%=request.querystring("input")%></textarea>
			<% else %>
			<input id="inputField" style="width:300px;font-size:20" value="<%=request.querystring("input")%>" onKeyup="decimalFormat(this);" />
			<% end if %>
		</td>
	</tr>
	<tr>
		<td align="center" valign="center" >
			<input type="submit" style="width:100px;height:50px" value="Ok" onclick="ok()" />
			<input type="button" style="width:100px;height:50px" value="Cancel" onclick="cancel()" />
		</td>
	</tr>
</table>


</body>

</html>
