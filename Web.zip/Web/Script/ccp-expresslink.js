function CreditCardProcessor() {
	
	this.AddCard = function(params) {
		var el;
		var transaction_id;

		if(window.parent) {
			if(window.parent.BeginExpressLinkTransaction) {
				transaction_id = window.parent.BeginExpressLinkTransaction("add-card", params);
			}		
		}
	}
	
	
	this.UpdateCard = function(params) {
		var el;
		var transaction_id;

		if(window.parent) {
			if(window.parent.BeginExpressLinkTransaction) {
				transaction_id = window.parent.BeginExpressLinkTransaction("update-card", params);
			}		
		}
	}
	
	
	this.DeleteCard = function(params) {
		var el;
		var transaction_id;

		if(window.parent) {
			if(window.parent.BeginExpressLinkTransaction) {
				transaction_id = window.parent.BeginExpressLinkTransaction("delete-card", params);
			}		
		}
	}
	
	
	
	
	this.Purchase = function(params) {
		var el;
		var transaction_id;

		
		if(params.amount == null ||
			params.clerk == null)
		{
			alert("CreditCardProcessor.Purchase: missing params.");
			return;				
		}

		if(window.parent) {
			if(window.parent.BeginExpressLinkTransaction) {

				transaction_id = window.parent.BeginExpressLinkTransaction("purchase", params);

				jQuery.getJSON("/script/ccp-expresslink.asp",
					{
						transaction_type: "begin-purchase",
						terminalid: params.terminalid,
						clerk: params.clerk,
						customerseq: params.customerseq,
						transaction_id: params.transaction_id,
						amount: params.amount,
						zip: params.zip,
						receipt: params.receipt
					},
					function(result_obj) {
					}
				);
			}		
		}
	}
	
	
}
