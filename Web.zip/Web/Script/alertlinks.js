// This list may be created by a server logic page PHP/ASP/ASPX/JSP in some backend system.
// There links will be displayed as a dropdown in all link dialogs if the "external_link_list_url"
// option is defined in TinyMCE init.

var tinyMCELinkList = new Array(
	// Name, URL
	["Claims", "/Mainapp/invoiceSearchResults.asp?type=claims"],
	["Quick Invoices", "/Mainapp/invoiceSearchResults.asp?type=quickinvoices"],
	["Price Changes", "/Mainapp/invoiceSearchResults.asp?type=pricechanges"],
	["Invoices Due Today", "/Mainapp/invoiceSearchResults.asp?type=invoicesdue"],
	["Overdue Invoices (7 Days)", "/Mainapp/invoiceSearchResults.asp?type=overdueinvoices&value=30"],
	["Overdue Invoices (30 Days)", "/Mainapp/invoiceSearchResults.asp?type=overdueinvoices&value=30"],
	["Overdue Invoices (60 Days)", "/Mainapp/invoiceSearchResults.asp?type=overdueinvoices&value=30"],
	["Overdue Invoices (90 Days)", "/Mainapp/invoiceSearchResults.asp?type=overdueinvoices&value=30"],
	["Department (Dry Cleaning)", "/Mainapp/invoiceSearchResults.asp?type=department&value='Dry Cleaning'"],
	["Department (Laundry)", "/Mainapp/invoiceSearchResults.asp?type=department&value='Laundry'"],
	["Department (Leathers)", "/Mainapp/invoiceSearchResults.asp?type=department&value='Leathers'"],
	["Department (Alterations)", "/Mainapp/invoiceSearchResults.asp?type=department&value='Alterations'"]
);
