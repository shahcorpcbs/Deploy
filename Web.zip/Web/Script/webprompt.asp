<%@ Language=VBScript %>

<%
    dim options
    dim optionsArray
    dim idx
    dim useReturn
    dim returnInfo
    
    options = request.querystring("options")
    useReturn = request.querystring("useReturn")
    returnInfo = request.querystring("returnInfo")
    
%>


<html>
<title>
<%=request.querystring("title")%>
</title>
<head>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">
	window.returnValue = null;
	var lastSelection = null;
	
	
	function vb_replace(src, match, replacement){
		var temp = src;
		
		var i = temp.indexOf(match);

		while(i >= 0) {
		
			temp = temp.replace(match, replacement);
			i = temp.indexOf(match, i + replacement.length + 1);
		}
		
		return temp;
	}
	
	function ok() {
		<% if options <> "" then %>
		if(!lastSelection) {
			alert('One option must be selected before continuing');
			return false;
		}
		<% end if %>

		var returnValue = inputField.value + (lastSelection ? '|' + lastSelection.value : '');

		<% if useReturn = 1 then %>
		    window.opener.handleCBSPromptReturn(returnValue, '<%= returnInfo %>');  //Must exist on calling page
		    window.opener.focus();
		<% else %>
		    window.returnValue = returnValue;
		<% end if %>
		window.close()
	}
	
	function cancel() {
	
		window.returnValue = null;
		window.close()
	}
	
	function selectOption(o) {
		if(lastSelection) {
			lastSelection.style.background = 'white';	
		}
		
		o.style.background = 'red';
		
		lastSelection = o;
	}

	function checkForEnter() {
	    if(event.keyCode == 13)
		    ok();
	}

	
</script>


</head>

<body STYLE="margin:0;padding:0" onload="inputField.select();inputField.focus()" style="background:#eee">
<table style="width:340px" border="0" cellspacing="0" cellpadding="0" style="background:#eee">
	<tr>
		<td align="center" valign="center" style="height:55px;font-size:16">
			<%=replace(request.querystring("txt"), "\n", "<br />")%>
		</td>
	</tr>
  <%

    if options <> "" then
      optionsArray = split(options, "|")
  %>
	<tr>
	  <td align="center" valign="center">
	<%
    for idx = lbound(optionsArray) to ubound(optionsArray)
  %>
  		<input style="background: white; width: 200px; height: 40px" type="button" value="<%=optionsArray(idx)%>" onclick="selectOption(this)" /><br>
  	<%
    next
  %>
	  </td>
	</tr>
  <%
    end if
   %>
	<tr>
		<td align="center" valign="center" style="height:80px" >
			<% if request.querystring("multiline") = 1 then %>
			<textarea id="inputField" style="width:300px" rows="4" style="overflow:auto" ><%=request.querystring("input")%></textarea>
			<% else %>
			<input id="inputField" style="width:300px;font-size:20" value="<%=request.querystring("input")%>" onkeyup="checkForEnter()" />
			<% end if %>
		</td>
	</tr>
	<tr>
		<td align="center" valign="center" >
			<input type="submit" style="width:100px;height:50px" value="Ok" onclick="ok()" />
			<input type="button" style="width:100px;height:50px" value="Cancel" onclick="cancel()" />
		</td>
	</tr>
</table>


</body>

</html>
