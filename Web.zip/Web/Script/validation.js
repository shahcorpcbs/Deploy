
function isNum1(passedVal, startPos) {
	if (passedVal == "") {
		return true
	}
	moredot = false;
	for (i=startPos; i<passedVal.length ; i++) {
		if(passedVal.charAt(i) == "."){
			if(moredot){
				return false
			}
			//moredot = true
			continue
		}
		if (passedVal.charAt(i) < "0") {
			return false
		}
		if (passedVal.charAt(i) > "9") {
			return false
		}
	}
	return true
}
//********************************************************************************************//

function showFocus(msg,field) {
	alert(msg)
	field.focus()
	field.select()
}

function showFocus1(msg,field) {
	alert(msg)
	field.select()
}
//********************************************************************************************//

function disableRightClick(btnclick) {
	var msg="Right mouse is disabled";
	if (event.button==2)
	{
		alert(msg);
		return false;
	}
}
		
//********************************************************************************************//

function ltrim ( s )
{
	return s.replace( /^\s*/, "" )
}

function rtrim ( s )
{
	return s.replace( /\s*$/, "" );
}

// to trim a string
function trim ( s )
{
	return rtrim(ltrim(s));
}

function parseMoney(n) {
   var s = "" + Math.round(n * 100) / 100
   var i = s.indexOf('.')
   if (i < 0) return s + ".00";
   var t = s.substring(0, i + 1) + s.substring(i + 1, i + 3)
   if (i + 2 == s.length)
   t += "0"
   return t;
}

//Method to format the decimal numbers
function autoFormatCurrency(passedVal) {
	var amount;
	var strLength;
	var substring1, substring2;
	var newStr;
	var amtNumber
	var isNegative;
	
	isNegative = false;
	amount = new String(passedVal);
	amount = amount.replace(".", "");
	amount = amount.replace(".", "");
	if (amount.charAt(0) == "-") {
		isNegative = true;
		amount = amount.replace("-","");
	}else{
		if (amount.charAt(0) == "+") {
			amount = amount.replace("+","");
		}
	}
	strLength = amount.length;
	
	switch(strLength) {
		case 0:
				newStr="";
				break;
		case 1:
			newStr = "0.0" +  amount.valueOf();
			break;
		default:
				substring1 = amount.substring(0, strLength-2);
				amtNumber =  new Number(substring1);
				substring1 = amtNumber.toString();
				substring2 = amount.substring(strLength-2, strLength);
				newStr = substring1 + "." +  substring2;
	}
	if (isNegative) {
		newStr =  "-" + newStr;
	}
	return newStr;
	
}

// keyboard functionality
	function onScreenKeyPress() {
		if(lastFocusControl) {
			if(lastFocusControl.tagName == "INPUT") {
				lastFocusControl.value = lastFocusControl.value + event.srcElement.innerText;
				
			}
			lastFocusControl.focus();
		}
		else {
			//alert("Provide a javascript variable [lastFocusControl] in you page and set it to the INPUT field where you want the input to go");
		}

	}
	function backSpace() {
		if(lastFocusControl) {
			if(lastFocusControl.tagName == "INPUT") {
		//		lastFocusControl.value = lastFocusControl.value + event.srcElement.innerText;
				lastFocusControl.value = lastFocusControl.value.substring(0, lastFocusControl.value.length - 1);
				
			}
			lastFocusControl.select();
		}
	}		

	function numberPoint() {
		if(lastFocusControl) {
			if(lastFocusControl.tagName == "INPUT" && lastFocusControl.value.indexOf(".") < 0 ) {
				lastFocusControl.value = lastFocusControl.value + event.srcElement.innerText;
			}
			lastFocusControl.select();
		}

	}

	function plusMinus() {
		if(lastFocusControl) {
			if(lastFocusControl.tagName == "INPUT") {
			var numValue = trim(lastFocusControl.value);
			  if( numValue != "" && numValue != "." )  {
				lastFocusControl.value = -eval(numValue);
			  }
			}
			lastFocusControl.select();
		}
	}
	
	
//********************************************************************************************//

//numberPad functionality

function onCalcKeyPress() {
		if(lastFocusControl) {
			if(lastFocusControl.tagName == "INPUT") {
				lastFocusControl.value = lastFocusControl.value + event.srcElement.innerText;
				lastFocusControl.value = autoFormatCurrency(lastFocusControl.value);
			}
			lastFocusControl.focus();
		}
		else {
			//alert("Provide a javascript variable [lastFocusControl] in you page and set it to the INPUT field where you want the input to go");
		}

	}
	function onCalcbackSpace() {
		if(lastFocusControl) {
			if(lastFocusControl.tagName == "INPUT") {
		//		lastFocusControl.value = lastFocusControl.value + event.srcElement.innerText;
				lastFocusControl.value = lastFocusControl.value.substring(0, lastFocusControl.value.length - 1);
				lastFocusControl.value = autoFormatCurrency(lastFocusControl.value);
			}
			lastFocusControl.select();
		}
	}		

	function onCalcnumberPoint() {
		if(lastFocusControl) {
			if(lastFocusControl.tagName == "INPUT" && lastFocusControl.value.indexOf(".") < 0 ) {
				lastFocusControl.value = lastFocusControl.value + event.srcElement.innerText;
				lastFocusControl.value = autoFormatCurrency(lastFocusControl.value);
			}
			lastFocusControl.select();
		}

	}
	
	function onCalcplusMinus() {
		var tempVal;
		
		if(lastFocusControl) {
			if(lastFocusControl.tagName == "INPUT") {
			var numValue = trim(lastFocusControl.value);
			  if( numValue != "" && numValue != "." )  {
				//lastFocusControl.value = -eval(numValue);
				tempVal = new String(numValue);
				if (tempVal.charAt(0) == "-") {
					tempVal = tempVal.replace("-", "");
				}else{
					tempVal = "-" + tempVal.valueOf();
				}
				lastFocusControl.value = tempVal;				
				lastFocusControl.value = autoFormatCurrency(lastFocusControl.value);
			  }
			}
			lastFocusControl.select();
		}
	}
		
//********************************************************************************************//

function cleanNumeric(text1){
	text1 =trim(text1);
	var temp = 0
	if( (text1.charAt(0) == "+") || (text1.charAt(0) == "-") ){
		temp = 1
	}

	if(isNum1(text1,temp)){
		return text1;
	}
	else{
		return "";
	}
}

//********************************************************************************************//

// Check whether string s is empty.

function isEmpty(s)
{   return ((s == null) || (s.length == 0))
}

function isDoubleQuote(passedVal) {
	for(i=0; i <passedVal.length; i++)	{
		if(passedVal.charAt(i) == "\"" ) {
			return false
		}
	}
	return true
}

function checkInt(val){
	
	for (i=0; i<val.length ; i++) {
		if (val.charAt(i) < "0") {
			return false
		}
		if (val.charAt(i) > "9") {
			return false
		}
	}
	
	return true;
}

//********************************************************************************************//

// isIntegerInRange (STRING s, INTEGER a, INTEGER b [, BOOLEAN emptyOK])
// 
// isIntegerInRange returns true if string s is an integer 
// within the range of integer arguments a and b, inclusive.
// 
// For explanation of optional argument emptyOK,
// see comments of function isInteger.


function isIntegerInRange (s, a, b)
{   if (isEmpty(s)) 
       if (isIntegerInRange.arguments.length == 1) return defaultEmptyOK;
       else return (isIntegerInRange.arguments[1] == true);

    // Catch non-integer strings to avoid creating a NaN below,
    // which isn't available on JavaScript 1.0 for Windows.
    if (!isInteger(s, false)) return false;

    // Now, explicitly change the type to integer via parseInt
    // so that the comparison code below will work both on 
    // JavaScript 1.2 (which typechecks in equality comparisons)
    // and JavaScript 1.1 and before (which doesn't).
    var num = parseInt (s);
    return ((num >= a) && (num <= b));
}

//********************************************************************************************//
// Function to check if the passed field is missing.

function checkFieldMissing(fld) {
	if (fld == null || fld == "") {
		return false
	}
	return true
}

//********************************************************************************************//

function removeSpaces(fld) {
		var val = ""
		l_length_of_data = fld.length;

		l_ctr=0;

		while(l_ctr != l_length_of_data) {
			if(fld.charAt(l_ctr) == " ") {
				l_ctr++
			}
			else{
				break;
			}
		}
		if(l_ctr > 0){
			for(var i=l_ctr;i < l_length_of_data;i++){
				val = val + fld.charAt(i)
			}
			return val
		}
		else{
			return fld;
		}
}

//********************************************************************************************//
// Function to check for leading spaces.

function isLeadSpaces(passedVal) {
	if(passedVal.charAt(0)==" ") {
		return false
	}
	return true
}

//********************************************************************************************//

// function to check for hours
 
 function checkHours(passedVal) {
	var val ="";
	if (checkInt(passedVal)) {
		val = eval(passedVal);
		if (val > 12){
			return false;
		}
		else {
			return true;
		}
	}
 }


// function to check for minutes
 
 function checkMinutes(passedVal) {
	var val ="";
	if (checkInt(passedVal)) {
		val = eval(passedVal);
		if (val > 59){
			return false;
		}
		else {
			return true;
		}
	}
 }
 
 function checkMonth(passedVal) {
	var val ="";
	if (checkInt(passedVal)) {
		val = eval(passedVal);
		if (val <=0 || val > 12){
			return false;
		}
		else {
			return true;
		}
	}
 }

 function checkYear(passedVal) {
	var val ="";
	if (checkInt(passedVal)) {
		val = eval(passedVal);
		if (passedVal.length != 4){
			return false;
		}
		else {
			return true;
		}
	}
 }
 
function isStrNumeric(v)
{
	for(var idx = 0; idx < v.length; idx++)
	{
		var tc = v.charCodeAt(idx);

		if(!((tc > 47 && tc < 58) || tc == 46))
		{
			return false;
		}
	}
	return true;
}

function isStrInteger(v)
{
	for(var idx = 0; idx < v.length; idx++)
	{
		var tc = v.charCodeAt(idx);

		if(!(tc > 47 && tc < 58))
		{
			return false;
		}
	}
	return true;
}
function isBlank(s)
{
	for (var i = 0; i < s.length; i++) {
		var c = s.charAt(i);
		if ((c != ' ') && (c != '\n') || (c != '')) return false;
	}
	return true;
}

function isStrAlphaNumeric(v)
{
	for(var idx = 0; idx < v.length; idx++)
	{
		var tc = v.charCodeAt(idx);

		if(!((tc > 47 && tc < 58) ||
			(tc > 64 && tc < 91) ||
			(tc > 96 && tc < 123)))
		{
			return false;
		}
	}
	return true;
}


function isStrFriendly(v)
{
	for(var idx = 0; idx < v.length; idx++)
	{
		var tc = v.charCodeAt(idx);

		if(!((tc > 47 && tc < 58) ||
			(tc > 64 && tc < 91) ||
			(tc > 96 && tc < 123) ||
			tc == 32 ||
			tc == 33 || tc == 35 || tc == 36 ||
			tc == 40 || tc == 41 || 
			tc == 45 || tc == 46 ||
			tc == 58 || tc == 59 ||
			tc == 61 || tc == 63 || tc == 64 ||
			tc == 91 || tc == 93 ))
		{
			return false;
		}
	}
	return true;
}
