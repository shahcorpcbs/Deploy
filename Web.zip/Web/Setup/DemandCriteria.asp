<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim priceListId
	dim addOrEditAction
	dim couponId
	dim couponName, discSubType, expDate
	dim minDolar, maxDollar, minPiece, maxPiece
	dim discountP, discountAmt, maxDiscAmt, IsDiscAmt
	dim couponLoc
	dim criteriaName, criteriaValue
	
	priceListId = Request.Form("priceListId")
	addOrEditAction = Request.Form("addOrEdit")
	couponId = Request.Form("discountId")
	collectData
	if addOrEditAction ="edit" then
		criteriaName = Request.Form("criteriaName")
		criteriaValue = Request.Form("criteriaValue")
	else
		criteriaName = "Visit"
		criteriaValue = ""
	end if
	
	sub collectData()
		couponName = Request.Form("couponname")
		discSubType = Request.Form("coupontype")
		expDate = Request.Form("expDate")
		minDolar = Request.Form("minDollar")
		maxDollar = Request.Form("maxDollar")
		minPiece = Request.Form("minPiece")
		maxPiece = Request.Form("maxPiece")
		discountP = Request.Form("discount")
		discountAmt = Request.Form("discount")
		maxDiscAmt = Request.Form("maxdiscount")
		IsDiscAmt = Request.Form("discountamount")
		couponLoc = Request.Form("couponloc")
	end sub
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
		
	function submitForm() {
		var temp;
		var criteria;
		var index;
		var criteriaValue;
		criteriaValue = document.frmcriteria.txtstatus.value;
		if (criteriaValue.length == 0) {
			showFocus("Must enter a criteria.", document.frmcriteria.txtstatus);
			return false;
		}else{
			index = document.frmcriteria.criteria.selectedIndex;
			criteria = document.frmcriteria.criteria(index).value;
			if (criteria == "Visit") {
				if (!checkInt(document.frmcriteria.txtstatus.value)) {
					showFocus("Must enter all numbers.", document.frmcriteria.txtstatus);
					return false;
				}
			}else{
				temp = cleanNumeric(document.frmcriteria.txtstatus.value);
				if(temp == "")	{
					showFocus("Enter valid amount.", document.frmcriteria.txtstatus);
					return false;
				}
			}
		}
		document.frmcriteria.action =  document.frmcriteria.action + "?userAction=criteria"
		document.frmcriteria.submit();
	}
	
	
			
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Coupon Criteria</H1>
<FORM id="frmcriteria" name="frmcriteria" action="onDemandCoupon.asp" Method = "post">
	<INPUT type="hidden" name="priceListId" value="<%= priceListId %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEditAction %>">
	<INPUT type="hidden" name="discountId" value="<%= couponId %>">
	<!-- couypon details-->
	<INPUT type="hidden" name="couponName" value="<%= couponName %>">
	<INPUT type="hidden" name="discSubType" value="<%= discSubType %>">
	<INPUT type="hidden" name="expDate" value="<%= expDate %>">
	<INPUT type="hidden" name="minDollar" value="<%= minDolar %>">
	<INPUT type="hidden" name="maxDollar" value="<%= maxDollar %>">
	<INPUT type="hidden" name="minPiece" value="<%= minPiece %>">
	<INPUT type="hidden" name="maxPiece" value="<%= maxPiece %>">
	<INPUT type="hidden" name="isDiscAmt" value="<%= IsDiscAmt %>">
	<INPUT type="hidden" name="discountAmt" value="<%= discountAmt %>">
	<INPUT type="hidden" name="discountP" value="<%= discountP %>">
	<INPUT type="hidden" name="maxDiscAmt" value="<%= maxDiscAmt %>">
	<INPUT type="hidden" name="couponLoc" value="<%= couponLoc %>">
	
	
<TABLE WIDTH="500px" BORDER=2 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT: 150px"><!-- header row -->
<TBODY>
 <tr>
	<td align=left valign=top>
		<TABLE align=center border="0" cellpadding="10" cellspacing="0" bordercolor=Gray >
		<tr><br>
			<td align=left width=80px>Criteria</td>
			<td align=left>
				<SELECT name=criteria STYLE="FONT-SIZE:16px;Width = 200px ">
					<OPTION VALUE= "Visit" <% if criteriaName = "Visit"  then%> selected <% end if%>>X Visits
					<OPTION VALUE= "DollarsSpent" <% if criteriaName = "DollarsSpent"  then%> selected <% end if%>>X Dollars Spent
				</SELECT>
			</td>
		</tr>
		<tr>
			<td align=left>Value</td>
			<td>
				<INPUT Class = text name=txtstatus Style = "WIDTH: 100px" value=<%= criteriaValue%>> 
			</td>
		</tr>
		<tr height=100px valign=bottom><td colspan=3 align=center>
			<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif);background-position=center"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);background-position=center" onClick="history.back(-1);">
		</td></tr>	
		</TABLE><br><br>
	</TD></TR></TBODY></TABLE></FORM>
</BODY>
</HTML>

