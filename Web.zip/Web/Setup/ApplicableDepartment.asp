<%@ Language=VBScript %>
<% option explicit %>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim storeId
	dim couponId
	dim actionString
	dim priceListId
	dim selDeptId
	dim CouponOrPromotion
	dim loyaltyId
	dim loyaltyName
	couponId = Request.QueryString("couponId")
	priceListId = Request.QueryString("priceListId")
	selDeptId = Request.QueryString("deptId")
	storeId = Session("storeId")
	actionString = Request.QueryString("userAction")
	CouponOrPromotion = Request.QueryString("CouponOrPromotion")
	loyaltyId = Request.QueryString("loyaltyId")
	loyaltyName = Request.QueryString("loyaltyName")
	Select case actionString 
			case "add"
				CouponOrPromotion = Request.Form("CouponOrPromotion")
				addCouponForDepartment
				select case CouponOrPromotion
					Case "Coupon"
						Response.Redirect "AddCoupons.asp?addOrEdit=edit&couponId=" & couponId & "&priceListId=" & priceListId
					Case "Promotion"
						Response.Redirect "Promotion.asp?addOrEdit=edit&couponId=" & couponId & "&priceListId=" & priceListId
					Case "Loyalty Program"
						Response.Redirect "AddLoyalty.asp?addorEdit=edit&couponId=" & couponId & "&priceListId=" & priceListId & "&loyaltyId=" & loyaltyId & "&loyaltyName=" & loyaltyName
				end select
			case "applicableItems"
				CouponOrPromotion = Request.Form("CouponOrPromotion")
				addCouponForDepartment
				Response.Redirect "ApplicableItems.asp?userAction=initialLoad&couponId=" & couponId & "&priceListId=" _
									& priceListId & "&targetPage=ApplicableDepartments&CouponOrPromotion=" _
									& CouponOrPromotion
	end select
	
	function getAllDepartments()
		dim ssql
		dim objResultSet
		
		ssql = "Select departmentID, name from Department where " _
					& " storeId =" & clng(storeId) & " AND disabled=0 " _
					& " And priceListId=" & clng(priceListId) _
					& " And name <> 'SpecialOffers' " _
					& " Order by displaySequence"
		set objResultSet = getDisconnectedRecordset(ssql)
		Set Session("departmentMaster") = objResultSet
		Set getAllDepartments = Session("departmentMaster")
	end function
	
	function getExistingDept()
		dim ssql
		dim objResultSet
		ssql = "Select departmentId from Discountdepartment where " _
				& " discountId=" & clng(couponId)
		set objResultSet = getDisconnectedRecordset(ssql)
		Set Session("existingDepts") = objResultSet
		Set getExistingDept = objResultSet
	end function
	
	function addCouponForDepartment()
		dim intLoop
		dim deptId
		dim ssql
		dim deptInfo
		dim deptArray
		dim deptExists
		dim existingDepts
		dim existingDeptId
		
		DbStartTrans
		if Request.Form("select").Count > 0 then
			for intLoop=1 to Request.Form("select").Count
				deptInfo = Request.Form("select")(intLoop)
				deptArray = Split(deptInfo, "|||")
				deptId = deptArray(0)
				deptExists = deptArray(1)
				if deptExists = "0" then
					ssql = "Insert Into Discountdepartment (discountId, departmentId) " _
						& " Values(" & clng(couponId) & "," & clng(deptId) & ")"
					QryExecuteWithTrans(ssql)
				end if
			next
			set existingDepts = Session("existingDepts")
			if existingDepts.Recordcount > 0 then
				existingDepts.MoveFirst
				while not existingDepts.EOF
					existingDeptId = existingDepts.Fields("departmentId").Value
					deptExists = false
					for intLoop=1 to Request.Form("select").Count
						deptInfo = Request.Form("select")(intLoop)
						deptArray = Split(deptInfo, "|||")
						deptId = deptArray(0)
						if trim(existingDeptId) = trim(deptId) then
							deptExists = true
							exit for
						end if	
					next
					if Not deptExists then
						ssql ="Delete from Discountdepartment where discountId=" & clng(couponId) _
								& " And departmentId=" & existingDeptId
						QryExecuteWithTrans(ssql)
					end if					
					existingDepts.MoveNext
				wend			
			end if
		else
			ssql ="Delete from Discountdepartment where discountId=" & clng(couponId)
			QryExecuteWithTrans(ssql)
		end if 
		DbEndTrans
	end function
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function submitFormAddItem() {
		var selCouponId;
		var priceId;
		var isSelected;
		var loyaltyId;
		var loyaltyName;
		isSelected =false;
		priceId = document.appicabledepartment.priceListId.value;
		selCouponId = document.appicabledepartment.couponId.value;
		loyaltyId = document.appicabledepartment.loyaltyId.value;
		loyaltyName = document.appicabledepartment.loyaltyName.value;
		if(deptTable.rows.length > 0) {
			if(deptTable.rows.length ==1) {
				if(document.appicabledepartment.select.checked) {
					isSelected =true;
				}
			}
			else{
				for (var i = 0; i < document.appicabledepartment.select.length; i++) {
					if(document.appicabledepartment.select[i].checked){
						isSelected =true;
						break;
					}
				}
			}
		}
		if (isSelected) {
			//document.appicabledepartment.action= "ApplicableItems.asp?userAction=initialLoad&couponId=" + selCouponId + "&priceListId=" + priceId + "&targetPage=ApplicableDepartments";
			document.appicabledepartment.action = "?userAction=applicableItems&couponId=" + selCouponId + "&priceListId=" + priceId ;
			document.appicabledepartment.submit();
		}	
	}			
	
	function submitForm() {
		var selCouponId
		var priceId
		var loyaltyId;
		var loyaltyName;
		priceId = document.appicabledepartment.priceListId.value;
		selCouponId = document.appicabledepartment.couponId.value;
		loyaltyId = document.appicabledepartment.loyaltyId.value;
		loyaltyName = document.appicabledepartment.loyaltyName.value;

		document.appicabledepartment.action = "?userAction=add&couponId=" + selCouponId + "&priceListId=" + priceId + "&loyaltyId=" + loyaltyId +"&loyaltyName=" + loyaltyName;
		document.appicabledepartment.submit();
	}		
	
	function cancelForm() {
		var selCouponId
		var priceId
		var couponOrPromo;
		var loyaltyId;
		var loyaltyName;
		priceId = document.appicabledepartment.priceListId.value;
		selCouponId = document.appicabledepartment.couponId.value;
		couponOrPromo = document.appicabledepartment.CouponOrPromotion.value;
		loyaltyId = document.appicabledepartment.loyaltyId.value;
		loyaltyName = document.appicabledepartment.loyaltyName.value;
		if (couponOrPromo == "Coupon"){
			document.appicabledepartment.action = "AddCoupons.asp?addOrEdit=edit&couponId=" + selCouponId + "&priceListId=" + priceId; 
		}else if (couponOrPromo == "Promotion"){
			document.appicabledepartment.action = "Promotion.asp?addOrEdit=edit&couponId=" + selCouponId + "&priceListId=" + priceId;
		}else
			document.appicabledepartment.action = "AddLoyalty.asp?addOrEdit=edit&couponId=" + selCouponId + "&priceListId=" + priceId + "&loyaltyId=" + loyaltyId + "&loyaltyName=" + loyaltyName;
		document.appicabledepartment.submit();
	}
	
	function enableDisableAppItems() {
		var isSelected;
		
		isSelected =false;
		if(deptTable.rows.length > 0) {
			if(deptTable.rows.length ==1) {
				if(document.appicabledepartment.select.checked) {
					isSelected =true;
				}
			}
			else{
				for (var i = 0; i < document.appicabledepartment.select.length; i++) {
					if(document.appicabledepartment.select[i].checked){
						isSelected =true;
						break;
					}
				}
			}
		}
		if (isSelected) {
			document.appicabledepartment.add.disabled =false;
		}else{
			document.appicabledepartment.add.disabled =true;
		}
	}	
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Department List</H1>
<FORM id="appicabledepartment" name="appicabledepartment" action="ApplicableDepartment.asp" Method = "post">
	<INPUT type="hidden" name="couponId" value="<%= couponId %>">
	<INPUT type="hidden" name="priceListId" value="<%= priceListId %>">
	<INPUT type="hidden" name="CouponOrPromotion" value="<%= CouponOrPromotion %>">
	<INPUT type="hidden" name="loyaltyId" value="<%= loyaltyId %>">
	<INPUT type="hidden" name="loyaltyName" value="<%= loyaltyName %>">
	
<TABLE WIDTH="300" BORDER=2 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT:180px"><!-- header row -->
 <tr >
	<td align=left valign=top>
	<TABLE width = 200 border="0" cellpadding="0" cellspacing="0" Style = "MARGIN-LEFT: 8px">
	<tr><td> 
		<DIV STYLE="HEIGHT: 150px; OVERFLOW-X: auto; OVERFLOW-Y: auto; WIDTH: 200px" >
		<TABLE width = 100% style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =1 CELLSPACING=0>
			<tr><td>
			<TABLE name="deptTable" id="deptTable" width = 100% style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =0 CELLSPACING=0>
			<%
				dim rst, rst1
				dim deptValue
				dim found
				dim atLeastOneFound
				set rst = getAllDepartments()
				set rst1 = getExistingDept()
				atLeastOneFound =false
				if rst.Recordcount > 0 then
					rst.moveFirst
				end if
				while not rst.eof 
				deptValue = rst.fields("departmentID")
				found = false
				if rst1.Recordcount > 0 then
					rst1.MoveFirst
					while not found and not rst1.eof
						if rst1.fields("departmentID") = deptValue then
							found =true
							atLeastOneFound =true
						end if
						rst1.MoveNext
					wend
				end if
			%>
				<tr>
					<%
						if found then
					%>
							<td width = 10><input type=checkbox name=select id =select value="<%= rst.fields("departmentID") & "|||1" %>" checked onclick="enableDisableAppItems();"></td>
					<%
						else
					%>
							<td width = 10><input type=checkbox name=select id =select value="<%= rst.fields("departmentID") & "|||0"%>" onclick="enableDisableAppItems();"></td>
					<%
						end if
					%>
						<td width = 100 ><%= rst.fields("name")%></td>
				</tr>
			<%
				rst.MoveNext
				wend
			%>
			</TABLE>
		</td></tr></table>
		</DIV>
	</TD>
	<td align= left vAlign=top>
	<TABLE  border="0" cellpadding="7" cellspacing="0">
	<tr><td align= left vAlign=left> 
		<INPUT class = click name=add type=button value="Applicable Items" onClick="submitFormAddItem()"  style="HEIGHT: 50px; WIDTH: 100px" <% if Not atLeastOneFound then %> disabled <% end if%> ></td></tr>
	<tr><td align= left vAlign=left><br><br><br><br>
		<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif);background-position=center"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp</td><tr>
<br>
	<tr><td align= left vAlign=left>

<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);background-position=center" onClick="cancelForm()">
	</table><br>
	</td><br></tr>
	</TABLE><br>
	</td></tr>
	</TABLE></FORM>
</BODY>
</HTML>
