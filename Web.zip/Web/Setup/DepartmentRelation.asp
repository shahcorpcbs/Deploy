<%@ Language=VBScript %>
<% option explicit %>
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim couponid
	dim pricelistid
	
	couponid = getReqVar("couponid")
	pricelistid = getReqVar("pricelistid")
	
	select case lcase(request.querystring("useraction"))
	case "add"
		addNewRelationship couponid, request.querystring("departmentid"), request.querystring("piececount"), request.querystring("amount")
	case "remove"
		removeRelationship couponid, request.querystring("departmentid")
	end select
	
	function addNewRelationship(couponid, departmentid, piececount, amount)
		dim query, rs
		
		removeRelationship couponid, departmentid
		
		query = " insert into discountdepartmentrule (discountid, departmentid, minpiececount, minqualamount) "
		query = query & " values (" & couponid & ", " & departmentid & ", " & DbCreateQryNumeric(piececount) & ", " & DbCreateQryNumeric(amount) & ")"
		
		qryexecute query
	end function
	
	
	function removeRelationship(couponid, departmentid)
		dim query, rs
		
		query = " delete discountdepartmentrule where discountid = " & couponid
		query = query & " and departmentid = " & departmentid
		
		qryexecute query
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript" src="/Script/validation.js"></script>

<script language="javascript" type="text/javascript">
	var previousElement = null;
	var selectedDepartment = null;
	
	
	
	function exit() {
		document.department.action = "AddCoupons.asp?addOrEdit=edit&priceListId=<%=pricelistid%>&couponId=<%=couponid%>"
		document.department.submit();
	}
	
	
	function removeSelection() {
		if(selectedDepartment != null) {
			document.department.action = "?useraction=remove&departmentid=" + selectedDepartment;
			document.department.submit();
		}
	}
	
	function addNew(departmentid, piececount, amount) {
		document.department.action = "?useraction=add&departmentid=" + departmentid +
                                 "&piececount=" + piececount +
                                 "&amount=" + amount;
		document.department.submit();
	}
	
	
	function selectRow(element) {
		if (previousElement != null){
			previousElement.className="";
		}
		
		selectedDepartment = element.getAttribute("departmentID");
	
		previousElement = element;
		
		element.className = "selected";
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Department Relationship</H1>
<FORM id="department" name="department" action="" Method = "post">
<INPUT type="hidden" name="couponid" value="<%=couponid%>" />
<INPUT type="hidden" name="pricelistid" value="<%=pricelistid%>" />

<TABLE cellspacing="10">
	<TR>
		<TD>
			Department<BR />
			<SELECT name="departmentid" id="departmentid">
			<%
				query = " select department.departmentid, "
				query = query & " department.name as [name] "
				query = query & " from department "
				query = query & " inner join pricelist on department.pricelistid = pricelist.pricelistid "
				query = query & " where department.storeid = " & session("storeid")
				query = query & " and department.pricelistid = " & pricelistid
				query = query & " order by name "
				
				set rs = getdisconnectedrecordset(query)
				
				while not(rs.eof or rs.bof)
			%>
			
				<OPTION value="<%=rs("departmentid")%>"><%=Server.HTMLEncode(rs("name"))%></OPTION>
			<%
					rs.movenext	
				wend
				set rs = nothing
			%>
			</SELECT>
		</TD>
		<TD>
			Piece Count<BR />
			<INPUT name="piececount" id="piececount" style="width:60px" />
		</TD>
		<TD>
			Amount<BR />
			<INPUT name="amount" id="amount" style="width:60px" onkeyup="this.value = autoFormatCurrency(this.value)" />
		</TD>
		<TD>

			<INPUT type="button" style="width:80px;height:40px" value="Add" onclick="addNew(departmentid.value, piececount.value, amount.value)" />
		</TD>
	</TR>
</TABLE>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="removeSelection()">Remove</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" width="100%" cellspacing="0" cellpadding="0">
<TR>
	<TH>Department</TH>
	<TH>Qualifying Piece Count</TH>
	<TH>Qualifying Amount</TH>
</TR>

<%

	query = " select isnull(discountdepartmentrule.minpiececount, 0) as minpiececount, "
	query = query & " isnull(discountdepartmentrule.minqualamount, 0) as minqualamount, "
	query = query & " department.name as 'departmentName', "
	query = query & " department.departmentID "
	query = query & " from discountdepartmentrule "
	query = query & " inner join department on discountdepartmentrule.departmentid = department.departmentid "
	query = query & " where discountdepartmentrule.discountid = " & couponid 
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
%>

<TR onclick="selectRow(this)" departmentID="<%=rs("departmentID")%>">
	<TD><%=Server.HTMLEncode(rs("departmentName"))%></TD>
	<TD><%=Server.HTMLEncode(rs("minpiececount"))%></TD>
	<TD><%=Server.HTMLEncode(FormatCurrency(rs("minqualamount")))%></TD>
</TR>

<%
		rs.movenext
	wend
	set rs = nothing

%>
</TABLE>


</FORM>
</BODY>
</HTML>
