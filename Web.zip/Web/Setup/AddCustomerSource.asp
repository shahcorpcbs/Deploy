<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim isSubmitted 
	dim l_storeid
	dim sqltxt 
	dim BodyCaption
	dim l_sourceid
	dim l_mode
	dim rsSource
	dim rssourcename
	dim l_sourcename
	
	isSubmitted = Request.QueryString("submitted")
	l_storeid = session("StoreID")
	
	if (isSubmitted ) then
		if not isnull(l_storeid) and l_storeid <> "" then
			l_mode = trim(Request.QueryString("mode"))
			'Response.Write l_mode
			if (l_mode= "add") then
				dbstartTrans()
				sqltxt = "insert CustomerSourceDomain (Name,storeid) values (" _
					 & dbcreateqrystring(Request.Form("txtname")) _
					 & "," & l_storeid _
					 & " )"
				'Response.Write sqltxt		 
				QryExecuteWithTrans(sqltxt)
				dbendtrans()
			elseif (l_mode= "edit") then
			
				l_sourceid = Request.Form("SourceID")
				dbstartTrans()
				sqltxt = "update CustomerSourceDomain set " _
					 & "name= " & dbcreateqrystring(Request.Form("txtname")) _
					 & " where CustomerSourceId = " & l_sourceid & " and Storeid = " & l_storeid 
				'Response.write sqltxt	 
				QryexecuteWithTrans(sqltxt)
				dbEndTrans()
			end if
		end if
	end if
	
	dim actionstring
	actionstring= Request.QueryString("userAction")
	if ( not isnull(actionstring) and actionstring <> "") then
		Response.Redirect(actionstring)
	end if
	
	
	l_mode = trim(Request.QueryString("mode"))
	if (l_mode = "add") then
		BodyCaption= "Add Customer Source"
	elseif (l_mode = "edit") then
		BodyCaption= "Edit Customer Source"
		l_sourceid = request.Querystring("SourceID")
		sqltxt = "select * from CustomerSourceDomain where CustomerSourceID = " & l_sourceid
		set rssource = getDisconnectedRecordset(sqltxt)
		if not rssource.Bof and not rssource.EOF then
			l_sourcename = rssource("name")
		end if
	end if
	
	
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
		
	function submitForm() {
		if(trim(document.addcustomersource.txtname.value) =="") {
			alert("Name is a required field");
			document.addcustomersource.txtname.focus();
		}
		else {
		document.addcustomersource.action = "?Submitted=true&mode=" + document.addcustomersource.mode.value + "&useraction=" + "CustomerSource.asp";
		document.addcustomersource.submit();
		}
	}			
	
	
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1><%=BodyCaption%></H1>
<FORM id="addcustomersource" name="addcustomersource" action="" Method = "post">
<input type=hidden name="mode" value ="<%=l_mode%>">
<input type=hidden name="sourceID" value ="<%=l_SourceID%>">
<TABLE WIDTH="320" BORDER=2 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT: 50px"><!-- header row -->
<TBODY>
 <tr>
	<td align=left valign=top>
	<TABLE  border="0" cellpadding="5" cellspacing="0">
	<tr><br>
		<td width =40px >Name&nbsp;<b><font color=red>*</font></td>
		<TD><INPUT Class = text name="txtname" maxlength = 64 value="<%=l_sourcename%>"></TD>
	</tr>
	<TR>
		<td align = left><br></td>
		<td><br>
		<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif);background-position=center"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
		<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);background-position=center" onClick="history.back(-1)">
		</td>
	</tr>
	<table>
	</td></tr>
	</TBODY>
	</TABLE>
	</FORM>
		
</BODY>
</HTML>
