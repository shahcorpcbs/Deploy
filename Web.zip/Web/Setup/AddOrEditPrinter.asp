<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim terminalid
	dim storeid
	dim printerType
	dim U200Type
	dim copies
	dim formName
	dim hardwareID
	dim routeNumber
	dim printerID
	dim promptBeforePrint
	dim promptAfterSms
	dim U200Scroll
	dim isRushPrinter
	dim printGroup
	dim combineInvoices
	dim isDemandPrinter

	dim showU200Type
	dim showCombineSplitDetailed
	dim showRoute
	dim showU200Scroll
	dim showRush
	dim showPrintGroup
	dim showCombine
	dim showDemandPrinter
	dim showMod
	dim setupTermLicense

	query = "select case when OBJECT_ID('printermodifier', 'U') is not null then showPrintModifiers else 0 end result from miscSetup"
	set rs = getdisconnectedrecordset(query)
    showMod = rs("result")

	terminalid = trim(session("setupterminalid"))
	storeid = trim(session("storeid"))
	query = "select licenseType from ClientTerminal where terminalID = " & terminalid
	set rs = getdisconnectedrecordset(query)
    setupTermLicense = cInt(rs("licenseType"))


	printerType = getReqVar("printerType")
	printerID = getReqVar("printerID")
	
	setupDisplaySettings printerID, printerType

	if showU200Type then
		U200Type = getReqVar("U200Type")
	else
		U200Type = -1
	end if
	
	copies = getReqVar("copies")
	formName = getReqVar("formName")
	hardwareID = getReqVar("hardwareID")
	
	printGroup = getReqVar("printGroup")
	
	if showRoute then 
		routeNumber = getReqVar("routeNumber")
	else
		routeNumber = ""
	end if
	
	
	isRushPrinter = getReqVar("isRushPrinter")
	promptBeforePrint = getReqVar("promptBeforePrint")
	isDemandPrinter = getReqVar("isDemandPrinter")
	promptAfterSms = getReqVar("promptAfterSms")
	
	if isDemandPrinter = "" then
		isDemandPrinter = "0"
	end if
	
	combineInvoices = getReqVar("combineInvoices")
	if combineInvoices = "" then combineInvoices = 1
	if showU200Scroll then
		U200Scroll = getReqVar("U200Scroll")
	else
		U200Scroll = "1.3"
	end if

	if U200Scroll = "" then U200Scroll = 1.3
	if isRushPrinter = "" then isRushPrinter = 0
	if copies = "" then copies = 1
	

	
	select case lcase(request.querystring("useraction"))
		case "add_modifier"
			addModifier
		case "remove_modifiers"
			removeModifiers
		case "add_printer"

		case "submit"
			saveForm printerID
			response.redirect "/setup/printers.asp"
		case "delete_printer"
			deletePrinter printerID
			response.redirect "/setup/printers.asp"
		case "select_printer_by_type"
			printerID = selectPrinterByType(getReqVar("printerType"))
	end select
	
	
	
	
	
	getPrinterFromDatabase printerID


	function removeModifiers()
		dim query, rs
		query = " delete printermodifier where printermodifierid in (" & Request.querystring("ids") & ")"
		qryexecute query
	end function

	function addModifier()
		dim query, rs

		query = " insert into printermodifier( "
		query = query & "  [PrinterID] "
		query = query & " ,[TriggerSource] "
		query = query & " ,[TriggerCriteria] "
		query = query & " ,[TriggerValue] "
		query = query & " ,[TargetField] "
		query = query & " ,[TargetValue] "
		query = query & " ) values ( "
		query = query & "'" & dbstr(printerID) & "', "
		query = query & "'" & dbstr(request.form("TriggerSource")) & "', "
		query = query & "'" & dbstr(request.form("TriggerCriteria")) & "', "
		query = query & "'" & dbstr(request.form("TriggerValue")) & "', "
		query = query & "'" & dbstr(request.form("TargetField")) & "', "
		query = query & "'" & dbstr(request.form("TargetValue")) & "'"
		query = query & " ) "

		qryexecute query
	end function

	function setupDisplaySettings(printerID, printerType)
		dim query, rs
		
		showU200Type = false
		showCombineSplitDetailed = false
		showU200Scroll = false
		showRush = false
		showPrintGroup = false
		showCombine = false
		showDemandPrinter = false

		if printerType = "" and printerID <> "" then
			query = " select printerType from printer where printerID = " & printerID
			set rs = getdisconnectedrecordset(query)
	
			if rs.recordcount > 0 then
				printerType = rs("printerType")
			end if
		
		end if

		select case trim(printerType)
			case "Quick Invoice 1"
				showPrintGroup = true
				showDemandPrinter = true
			case "Quick Invoice 2"
				showPrintGroup = true
				showDemandPrinter = true
			case "Detailed Invoice 1"
				showCombineSplitDetailed = true
				showRush = true
				showPrintGroup = true
				showCombine = true
				showDemandPrinter = true
			case "Detailed Invoice 2"
				showCombineSplitDetailed = true
				showRush = true
				showPrintGroup = true
				showCombine = true
				showDemandPrinter = true
			case "Tag Printer 1"
				showU200Type = true
				showU200Scroll = true
				showRush = true
				showPrintGroup = true
			case "Tag Printer 2"
				showU200Type = true
				showU200Scroll = true
				showRush = true
				showPrintGroup = true
			case "Route Printer"
				showRoute = true
				showDemandPrinter = true
			case "Route Tag Printer", "Route Tag Printer 1"
				showRoute = true
				showU200Type = true
				showU200Scroll = true
				showPrintGroup = true
			case "Route Tag Printer 2"	
				showRoute = true
				showU200Type = true
				showU200Scroll = true
				showPrintGroup = true
			case "Edit Invoice"
				showDemandPrinter = true
			case "Pickup Invoice 1", "Pickup Invoice 2"
				showDemandPrinter = true
		end select

	end function
	
	
	function selectPrinterByType(printerType)
		dim query, rs
		
		' need to remove this check later when localprinter can print multiples
		if not (printerType = "Route Printer" or _
				printerType = "Route Tag Printer 1" or printerType = "Route Tag Printer" or _
				printerType = "Route Tag Printer 2") then
			
			query = "select printer.printerid from "
			query = query & " printer inner join storehardware on "
			query = query & " printer.hardwareid = storehardware.hardwareid "
			query = query & " where printerType = '" & printerType & "'"
			query = query & " and storehardware.terminalid = " & terminalid
			
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				selectPrinterByType = rs("printerID")
			end if
			
			set rs = nothing
		
		end if
	end function
	
	function getHardwareName(hardwareID)
		dim query, rs
		
		query = " select * from storehardware where hardwareID = " & hardwareID

		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getHardwareName = Replace(rs("hardwareName"), "'", "''")
		end if
		
		set rs = nothing
	end function
	
	function deletePrinter(printerID)
		dim query, rs
		
		query = "delete from printer where printerid = " & printerID
		
		qryexecute query
	end function
	
	function isUpdateable(printerID)
		dim query, rs
		
		if printerID = "" then
			isUpdateable = false
		else
		
			query = " select printer.* from printer inner join storehardware on "
      query = query & " printer.hardwareid = storehardware.hardwareid "
      query = query & " where printertype in ( "
			query = query & " select printertype from printer where printerid = " & printerid
			query = query & ") and isRushPrinter = " & isRushPrinter
			query = query & " and storehardware.terminalid = " & terminalid

			set rs = getdisconnectedrecordset(query)
			
			isUpdateable = (rs.recordcount > 0)
			
			set rs = nothing
		end if
	end function
	
	function saveForm(printerID)
		dim query
		
		if printerType <> "" then
			if isUpdateable(printerID) then
				query = "update printer set "
				query = query & "printerType = '" & printerType & "'"
				
				if clng(U200Type) < 0 then
					query = query & ", u200 = 0"
					query = query & ", u200Type = 0"
				else
					query = query & ", u200 = 1"
					query = query & ", u200Type = " & U200Type
				end if
				
				query = query & ", numCopies = " & copies
				query = query & ", formName = '" & formName & "'"
				query = query & ", hardwareID = " & hardwareID
				query = query & ", routeNumber = " & DbCreateQryString(routeNumber)  
				query = query & ", printerName = '" & getHardwareName(hardwareID) & "'"
				query = query & ", promptBeforePrint = " & promptBeforePrint
				query = query & ", promptAfterSms = " & promptAfterSms
				query = query & ", U200Scroll = " & U200Scroll
				query = query & ", isRushPrinter = " & isRushPrinter
				query = query & ", printGroup = " & DbCreateQryString(printGroup)
				query = query & ", isDemandPrinter = " & isDemandPrinter  
				query = query & ", combineInvoices = " & combineInvoices
				query = query & " where printerID = " & printerID

			else
				query = " insert into printer (printerType, u200, u200Type, numCopies, formName, hardwareID, "_
				    & "routeNumber, printerName, promptBeforePrint, promptAfterSms, U200Scroll, isRushPrinter, printGroup, combineInvoices, isDemandPrinter) "
				query = query & " values ("
				query = query & "'" & printerType & "'"
				
				if clng(U200Type) < 0 then
					query = query & "," & 0
					query = query & "," & 0
				else
					query = query & "," & 1
					query = query & "," & U200Type
				end if
				
				query = query & "," & copies
				query = query & ",'" & formName & "'"
				query = query & "," & hardwareID
				query = query & "," & DbCreateQryString(routeNumber)
				query = query & ",'" & getHardwareName(hardwareID) & "'"
				query = query & "," & promptBeforePrint
				query = query & "," & promptAfterSms
				query = query & "," & U200Scroll
				query = query & "," & isRushPrinter
				query = query & "," & DbCreateQryString(printGroup)
				query = query & "," & combineInvoices
				query = query & "," & isDemandPrinter
				query = query & ")"
			end if
		end if

		qryexecute query
		
	end function

	function getPrinterFromDatabase(printerID)
		dim query, rs
		
		if printerID <> "" then
			query = "select *, isnull(cast(printGroup as varchar), '') as printGroup from printer where printerID = " & printerID
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				printerType = rs("printerType")
				if rs("u200") then
					U200Type = rs("u200Type")
				else
					U200Type = -1
				end if
				
				copies = rs("numCopies")
				formName = rs("formName")
				routeNumber = rs("routeNumber")
				hardwareID = rs("hardwareID")
				promptBeforePrint = rs("promptBeforePrint")
				promptAfterSms = rs("promptAfterSms")
				U200Scroll = rs("U200Scroll")
				if rs("isRushPrinter") then
					isRushPrinter = 1
				else
					isrushprinter = 0
				end if
				if rs("isDemandPrinter") then
					isDemandPrinter = 1
				else
					isDemandPrinter = 0
				end if
				printGroup = rs("printGroup")
				combineInvoices = rs("combineInvoices")
			end if
		end if
	end function

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	

	function getPrinterTypes()
		dim printerTypes
		set printerTypes = Server.CreateObject("Scripting.Dictionary")
		printerTypes.Add "Pickup Invoice 1", "Pickup Invoice 1"
		printerTypes.Add "Pickup Invoice 2", "Pickup Invoice 2"
		printerTypes.Add "Detailed Invoice 1", "Detailed Invoice 1"
		printerTypes.Add "Detailed Invoice 2", "Detailed Invoice 2"
		if setupTermLicense = 1 then
            printerTypes.Add "Tag Printer 1", "Tag Printer 1"
            printerTypes.Add "Tag Printer 2", "Tag Printer 2"
		end if
		printerTypes.Add "Quick Invoice 1", "Quick Invoice 1"
		printerTypes.Add "Quick Invoice 2", "Quick Invoice 2"
		printerTypes.Add "Counter Sales 1", "Counter Sales 1"
		printerTypes.Add "Counter Sales 2", "Counter Sales 2"
		if setupTermLicense = 1 then
            printerTypes.Add "Route Tag Printer", "Route Tag Printer 1"
            printerTypes.Add "Route Tag Printer 2", "Route Tag Printer 2"
        end if
		printerTypes.Add "Heat Seal", "Heat Seal"
		printerTypes.Add "Edit Invoice", "Edit Invoice"
		printerTypes.Add "Report Printer", "Report Printer"
		printerTypes.Add "Route Printer", "Route Printer"
		printerTypes.Add "CREDIT CARD RECEIPT", "Credit Card Receipt"
		if setupTermLicense = 1 then
            printerTypes.Add "BAG TAG", "Bag Tag"
		end if
		printerTypes.Add "RACK SLIP", "Rack Slip"
		set getPrinterTypes = printerTypes
	end function
	


	function getLongPrinterType(printerType)
		dim printerTypes
		printerType = trim(printerType)
		set printerTypes = getPrinterTypes()
		if printerTypes.Exists(printerType) then
			getLongPrinterType = printerTypes.Item(printerType)
		else
			getLongPrinterType = "[" & printerType & "]"
		end if
	end function
	
	function getU200Types()
		dim U200Types
		set U200Types = Server.CreateObject("Scripting.Dictionary")
		U200Types.Add "-1", "Windows"
		U200Types.Add "0", "U200"
		U200Types.Add "1", "SP500"
		U200Types.Add "2", "U200 Double"
		U200Types.Add "3", "SP500 Double"
		U200Types.Add "4", "Bixolon"
		U200Types.Add "5", "Bixolon Double"
		U200Types.Add "6", "U220"
		U200Types.Add "7", "U220 Double"
		set getU200Types = U200Types
	end function

	function getLongU200Type(U200Type)
		dim U200Types
		U200Type = trim(U200Type)
		set U200Types = getU200Types()
		if U200Types.Exists(U200Type) then
			getLongU200Type = U200Types.Item(U200Type)
		else
			getLongU200Type = "[" & U200Type & "]"
		end if
	end function
%>

<html>
<head>
<title>SetUp</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../External/jquery-3.4.1.js"></script>
</head>
<script language="javascript" type="text/javascript">

function submitForm() {
	document.addoreditprinter.action = "?useraction=submit";
	document.addoreditprinter.submit();
}

function cancelForm() {
	document.addoreditprinter.action = "printers.asp";
	document.addoreditprinter.submit();
}

function deletePrinter() {
    cbs_confirm("Delete printer?", doDelete);
}

function doDelete() {
        clearConfirmMsg();
        document.addoreditprinter.action = "?useraction=delete_printer";
        document.addoreditprinter.submit();
}

function selectPrinterType() {
	document.addoreditprinter.action = "?useraction=select_printer_by_type";
	document.addoreditprinter.submit();
}

function addModifier() {
	document.addoreditprinter.action = "?useraction=add_modifier";
	document.addoreditprinter.submit();
}

function removeModifiers() {
    var checkedVals = $('input[name="printermodifierid"]:checked').map(function() {
        return this.value;
    }).get();
    if (checkedVals.join(",") != "")
        cbs_confirm("Remove selected modifiers?", doRemove);
    else
        cbs_alert("No modifiers selected to remove");
}

function doRemove() {
    clearConfirmMsg();

    var checkedVals = $('input[name="printermodifierid"]:checked').map(function() {
        return this.value;
    }).get();
    if (checkedVals.join(",") != "") {
        document.addoreditprinter.action = "?useraction=remove_modifiers&ids=" + encodeURIComponent(checkedVals.join(","));
        document.addoreditprinter.submit();
    }
}

</SCRIPT>

<style type="text/css">
table.printer-mods {
	margin: 10px;
	border-collapse: collapse;
}

table.printer-mods tr {
	height: 30px;

}
table.printer-mods th {
	background-color: #eee;

}


table.printer-mods td {
	border-bottom: 1px solid #eee;

}

</style>
<body topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->

<form name="addoreditprinter" action="" method="post" style="margin:0px" onsubmit="return false;">

<input type="hidden" name="printerID" value="<%=printerID%>" />



<div name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<span style="float:left">
		<button  onClick="cancelForm()">Cancel</button>
		<button  onClick="deletePrinter()">Delete</button>
	</span>
	<span style="float:right">
		<button  onClick="submitForm()">Ok</button>
	</span>
</div>	
	
<table cellspacing="0" class="itable" style="padding-left:10px">

<tr>
	<th align="left">Attribute</th>
	<th align="left">Value</th>
</tr>
<tr>

<td>Printer Type</td>
<td>
<select name="printerType" onchange="selectPrinterType()">
	<option value=""></option>
<%
	dim printerTypes
	dim printerTypeKeys, printerTypeItems
	dim idx
	
	set printerTypes = getPrinterTypes()

	printerTypeItems = printerTypes.Items
	printerTypeKeys = printerTypes.Keys
	
	for idx = 0 to printerTypes.count - 1
%>
	<option value="<%=printerTypeKeys(idx)%>" <%if printerTypeKeys(idx) = trim(printerType) then%>selected<%end if%>><%=printerTypeItems(idx)%></option>
<%
	next
%>
</select>
</td>
</tr>

<% if showU200Type then %>
<tr>
<td>Driver</td>
<td>
<select name="U200Type">
<%
	dim U200Types
	dim U200TypeKeys, U200TypeItems

	set U200Types = getU200Types()

	U200TypeItems = U200Types.Items
	U200TypeKeys = U200Types.Keys
	
	for idx = 0 to U200Types.count - 1
%>
	<option value="<%=U200TypeKeys(idx)%>" <%if U200TypeKeys(idx) = trim(U200Type) then%>selected<%end if%>><%=U200TypeItems(idx)%></option>
<%
	next
%>
</select>

</td>
</tr>

<% end if %>

<tr>
<td>Printer</td>
<td>
<select name="hardwareID">
<%
	query = "select * from storehardware where hardwaretype = 'PR' and terminalid = " & terminalid & " order by hardwarename "
	set rs = GetDisconnectedRecordset(query)
	
	while not(rs.eof or rs.bof)
%>
	<option value="<%=rs("hardwareID")%>" <%if rs("hardwareID") = hardwareID then%>selected<%end if%>><%=rs("hardwarename")%></option>
<%
		rs.movenext
	wend
	set rs = nothing
%>
</select>
</td>
</tr>
<tr>
<td>Copies</td>
<td>
<select name="copies">
	<option value="0" <%if copies <= 0 then%>selected<%end if%>>0</option>
	<option value="1" <%if copies = 1 then%>selected<%end if%>>1</option>
	<option value="2" <%if copies = 2 then%>selected<%end if%>>2</option>
	<option value="3" <%if copies = 3 then%>selected<%end if%>>3</option>
	<option value="4" <%if copies = 4 then%>selected<%end if%>>4</option>
	<option value="5" <%if copies = 5 then%>selected<%end if%>>5</option>
	<option value="6" <%if copies >= 6 then%>selected<%end if%>>6</option>
</select>
</td>
</tr>
<td>Form</td>
<td>
<select name="formName">
<%
	query = "select * from form where [type] in ('text/rtf', 'text/html') and  storeid = " & storeid
	set rs = GetDisconnectedRecordset(query)
	
	while not(rs.eof or rs.bof)
%>
	<option value="<%=rs("formname")%>" <%if rs("formname") = formName then%>selected<%end if%>><%=rs("formname")%></option>
<%
		rs.movenext
	wend
	set rs = nothing
%>
</select>
</td>
</tr>

<% if showRoute then %>
<tr>
<td>Route</td>
<td>
<select name="routeNumber">
	<option value="">(All)</option>
<%
	query = "select * from route where routenumber > 0 and storeid = " & storeid 
	set rs = GetDisconnectedRecordset(query)
	
	while not(rs.eof or rs.bof)
%>
	<option value="<%=rs("routenumber")%>" <%if rs("routenumber") = routeNumber then%>selected<%end if%>><%=rs("name")%></option>
<%
		rs.movenext
	wend
	set rs = nothing
%>
</select>
</td>
</tr>
<% end if %>


<% if showCombine then %>
<tr>
<td>Combine Invoices</td>
<td>
<select name="combineInvoices">
	<option value="1" <%if combineInvoices = 1 then%>selected<%end if%>>Classic Misc Setup</option>
	<option value="2" <%if combineInvoices = 2 then%>selected<%end if%>>Counter Customers</option>
	<option value="4" <%if combineInvoices = 4 then%>selected<%end if%>>Route Customers</option>
	<option value="6" <%if combineInvoices = 6 then%>selected<%end if%>>All Customers</option>
	<option value="0" <%if combineInvoices = 0 then%>selected<%end if%>>Never</option>
</select>

</td>
</tr>
<% end if %>


<% if showPrintGroup then %>
<tr>
<td>Print Group</td>
<td>
<input name="printGroup" value="<%=printGroup%>" />

</td>
</tr>
<% end if %>



<% if showU200Scroll then %>
<tr>
<td>Scroll</td>
<td>
<select name="U200Scroll">
	<option value="0.9" <%if U200Scroll <= 0.9 then%>selected<%end if%>>0.9</option>
	<option value="1.1" <%if U200Scroll > 0.9 and U200Scroll <= 1.1 then%>selected<%end if%>>1.1</option>
	<option value="1.3" <%if U200Scroll > 1.1 and U200Scroll <= 1.3 then%>selected<%end if%>>1.3</option>
	<option value="1.5" <%if U200Scroll > 1.3 and U200Scroll <= 1.5 then%>selected<%end if%>>1.5</option>
	<option value="1.7." <%if U200Scroll > 1.5 and U200Scroll <= 1.7 then%>selected<%end if%>>1.7</option>
	<option value="1.9" <%if U200Scroll > 1.7 and U200Scroll <= 1.9 then%>selected<%end if%>>1.9</option>
	<option value="2.1" <%if U200Scroll > 1.9 and U200Scroll <= 2.1 then%>selected<%end if%>>2.1</option>
	<option value="2.3" <%if U200Scroll > 2.1 then%>selected<%end if%>>2.3</option>
</select>
</td>
</tr>
<% end if %>

<% if showRush then %>
<tr>
<td>Rush Printer</td>
<td>
<select name="isRushPrinter">
	<option value="0" <%if isRushPrinter = 0 then%>selected<%end if%>>False</option>
	<option value="1" <%if isRushPrinter = 1 then%>selected<%end if%>>True</option>
</select>

</td>
</tr>
<% end if %>

<% if showDemandPrinter then %>
<tr>
<td>On Demand Coupon Printer</td>
<td>
<select name="isDemandPrinter">
	<option value="0" <%if isDemandPrinter = 0 then%>selected<%end if%>>False</option>
	<option value="1" <%if isDemandPrinter = 1 then%>selected<%end if%>>True</option>
</select>

</td>
</tr>
<% end if %>


<tr>
<td>Prompt</td>
<td>
<select name="promptBeforePrint">

	<option value="0" <%if promptBeforePrint  then%>selected<%end if%>>No</option>
	<option value="1" <%if promptBeforePrint  then%>selected<%end if%>>Yes</option>

</select>
</td>
</tr>

<tr>
<td>Prompt after electronic receipt</td>
<td>
<select name="promptAfterSms">

	<option value="0" <%if promptAfterSms  then%>selected<%end if%>>No</option>
	<option value="1" <%if promptAfterSms  then%>selected<%end if%>>Yes</option>

</select>
</td>
</tr>



</table>
<% if showMod = 1 then %>
    <% if printerid <> "" then %>

    <table class="printer-mods">
        <tr>
            <th>Trigger Source</th>
            <th>Trigger Criteria</th>
            <th>Trigger Value</th>
            <th>Target</th>
            <th>Target Value</th>
            <th>Action</th>
        </tr>
    <%
        query = " select * from printermodifier where printerid = '" & dbstr(printerID) & "'"
        set rs = getdisconnectedrecordset(query)

        while not(rs.eof or rs.bof)
    %>

        <tr class="printer-mod">
        <td><%=server.htmlencode(rs("triggersource"))%></td>

        <td><%=server.htmlencode(rs("triggercriteria"))%></td>

        <td><%=server.htmlencode(rs("triggervalue"))%></td>

        <td><%=server.htmlencode(rs("targetfield"))%></td>

        <td><%=server.htmlencode(rs("targetvalue"))%></td>

        <td>
        <input type="checkbox" name="printermodifierid" class="printermodifierid" value="<%=server.htmlencode(rs("printermodifierid"))%>">Remove
        </td>

        </tr>

    <%
            rs.movenext
        wend

        set rs = nothing
    %>

        <tr>
        <td>
        <select name="triggersource">
            <option value="printgroup">Print Group</option>
            <option value="lot">Lot</option>
            <option value="route">Route</option>
        </select>
        </td>

        <td>
        <select name="triggercriteria">
            <option value="ct">contains</option>
            <option value="nct">not contains</option>
        </select>
        </td>

        <td>
        <input  name="triggervalue" value="" />
        </td>

        <td>
        then

        <select name="targetfield">
            <option value="driver">Driver</option>
            <option value="printer">Printer</option>
            <option value="copies">Copies</option>
            <option value="form">Form</option>
        </select>
        </td>

        <td>
        =
        <input  name="targetvalue" value="" />
        </td>

        <td>
        <input value="Add Modifier" type="button" onclick="addModifier()">
        <input value="Remove Modifiers" type="button" onclick="removeModifiers()">
        </td>

        </tr>
    </table>

    <% end if %>
<% end if %>

</form>

</body>
</html>
