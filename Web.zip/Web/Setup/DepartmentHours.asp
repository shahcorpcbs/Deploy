<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim storeID
	dim addOrEdit
	dim storeNumber
	
	storeID = getReqVar("storeID")
	addOrEdit = getReqVar("addOrEdit")
	storeNumber = getReqVar("storeNumber")
	
	
	select case lcase(request.querystring("useraction"))
	case "add"
		addDepartmentDays
	case "remove"
		removeDepartmentDays
	end select
	
	
	function removeDepartmentDays()
		dim departmentDaysID
		dim query
		
		
		departmentDaysID = request.querystring("departmentDaysID")
		
		query = " delete from departmentdays where departmentdaysid = " & departmentDaysID
		

		qryexecute query
		
	
	end function
	
	
	function addDepartmentDays()
		dim departmentid
		dim hours
		dim adddays
		dim query
		
		
		departmentid = request.form("departmentid")
		hours = request.form("hours")
		adddays = request.form("adddays")
		
		query = " insert into departmentdays (departmentid, hour, adddays) "
		query = query & " values ( "
		query = query & departmentid
		query = query & "," & hours
		query = query & "," & adddays
		query = query & ")"
		

		qryexecute query
		
	
	end function
	
	
	
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
%>

<HTML>
<HEAD>
<TITLE>Department Hours</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	var previousElement = null;
	var selectedDepartmentDaysID = null;


	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}
		selectedDepartmentDaysID = element.getAttribute("departmentDaysID");
		previousElement = element;
		element.className = "selected";
	}
	
	function addDepartmentDays() {
		document.DepartmentHours.action = "?useraction=add";
		document.DepartmentHours.submit();
	}
	
	function removeSelected() {
		if(selectedDepartmentDaysID == null) {
			cbs_alert("Make a selection before removing.");
		}
		else {
			document.DepartmentHours.action = "?useraction=remove&departmentdaysid=" + selectedDepartmentDaysID;
			document.DepartmentHours.submit();
		}
	}
	
	function exit() {
		document.DepartmentHours.action = "StoreHours.asp?storeId=<%=storeID%>&addOrEdit=<%=addOrEdit%>&storeNumber=<%=storeNumber%>"
		document.DepartmentHours.submit();
	}

</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Department Hours</H1>
<FORM id="DepartmentHours" name="DepartmentHours" Method="post">
	<INPUT type="hidden" name="storeID" value="<%=storeID%>">
	<INPUT type="hidden" name="addOrEdit" value="<%=addOrEdit%>">
	<INPUT type="hidden" name="storeNumber" value="<%=storeNumber%>">

<table>
<tr>
<td>
Department<br>
<select id="departmentid" name="departmentid">
<%
	query = " select department.departmentid, pricelist.name + ' - ' + department.name as cname "
	query = query & " from pricelist inner join department on pricelist.pricelistid = department.pricelistid "
	query = query & " where pricelist.disable = 0 and department.disabled = 0 "
	
	set rs = getdisconnectedrecordset(query)
	
	while not (rs.eof or rs.bof)
%>
	
	<option value="<%=rs("departmentid")%>" ><%=server.htmlencode(rs("cname"))%></option>
<%
		rs.movenext
	wend
	
	set rs = nothing
%>
</select>


</td><td>
Time<br>
<select id="hours" name="hours">
	<option value="0" >00:00</option>
	<option value="1">01:00</option>
	<option value="2">02:00</option>
	<option value="3">03:00</option>
	<option value="4">04:00</option>
	<option value="5">05:00</option>
	<option value="6">06:00</option>
	<option value="7">07:00</option>
	<option value="8">08:00</option>
	<option value="9">09:00</option>
	<option value="10">10:00</option>
	<option value="11">11:00</option>
	<option value="12">12:00</option>
	<option value="13">13:00</option>
	<option value="14">14:00</option>
	<option value="15">15:00</option>
	<option value="16">16:00</option>
	<option value="17">17:00</option>
	<option value="18">18:00</option>
	<option value="19">19:00</option>
	<option value="20">20:00</option>
	<option value="21">21:00</option>
	<option value="22">22:00</option>
	<option value="23">23:00</option>
</select>
</td><td>
Days<br>
<select id="adddays" name="adddays">
	<option value="-5" >-5</option>
	<option value="-4" >-4</option>
	<option value="-3" >-3</option>
	<option value="-2">-2</option>
	<option value="-1">-1</option>
	<option value="1" selected>+1</option>
	<option value="2">+2</option>
	<option value="3">+3</option>
	<option value="4">+4</option>
	<option value="5">+5</option>
</select>
</td><td>
&nbsp;<br>
<button onclick="addDepartmentDays()">Add</button>
</td>
</tr>
</table>

</FORM>


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="removeSelected()">Remove</BUTTON>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	


<table class="itable" cellspacing="0">
	<tr>
		<th>Department</th>
		<th>Time</th>
		<th>Days</th>
	</tr>
	
<%
	query = " select departmentdays.departmentdaysid, departmentdays.hour, departmentdays.adddays, pricelist.name + ' - ' + department.name as cname "
	query = query & " from departmentdays inner join department on departmentdays.departmentid = department.departmentid "
	query = query & " inner join pricelist on department.pricelistid = pricelist.pricelistid "
	
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
%>
	<tr departmentDaysID="<%=rs("departmentdaysid")%>"  onclick="selectRow(this)">
		<td><%=server.htmlencode(rs("cname"))%></td>
		<td><%=rs("hour")%>:00</td>
		<td><%if rs("adddays") > 0 then%>+<%end if%><%=rs("adddays")%></td>
	</tr>
<%
		rs.movenext
	wend
	set rs = nothing
%>
</table>

</BODY>
</HTML>
