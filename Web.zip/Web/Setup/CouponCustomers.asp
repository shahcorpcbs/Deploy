<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim discountid : discountid = getReqVar("discountid")
	dim refpage : refpage = getReqVar("refpage")

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
%>
<HTML>
<HEAD>
<TITLE>Promotion Customers</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script type="text/javascript" src="../script/date-picker.js"></script>
<script type="text/javascript">

	
	function exit() {
		<% if refpage = "discountlist" then %>
		document.couponCust.action = "/setup/discountlist.asp?discounttype=cu";
		<% else %>
		document.couponCust.action = "/setup/coupon.asp?addoredit=edit&couponid=<%=discountid%>";
		<% end if %>
		document.couponCust.submit();
	}
</script>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Coupon Customers</H1><BR/><BR/>
<FORM name="couponCust" ID="couponCust" METHOD=POST  style="margin:0;padding:0" onsubmit="return false">

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON id="btnRemoveCustomer" onclick="removeCustomer()">Remove</BUTTON>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	
<DIV style="height:670px;overflow:scroll">
<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH>Employee</TH>
		<TH>Customer Name</TH>
		<TH>Invoice Creation Date</TH>
		<TH>Invoice Number</TH>
	</TR>

	<%
		query = " select distinct employee.employeename, Customer.customerName, ticket.createdDate, ticket.invoiceNumber "
		query = query & " from  ticketlineitem "
		query = query & " inner join employee on createdbyemployeeid = employeeid "
		query = query & " inner join Ticket on TicketLineItem.ticketNumber = ticket.ticketNumber "
		query = query & " inner join Customer on ticket.customerSequenceNumber = customer.customerSequenceNumber "
		query = query & " where ticketLineType = 'cu' "
		query = query & " order by 3, 1, 2 "

		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
	%>
	<TR>
		<TD><%=Server.HTMLEncode(rs("employeename"))%></TD>
		<TD><%=Server.HTMLEncode(rs("customerName"))%></TD>
		<TD><%=Server.HTMLEncode(rs("createdDate"))%>&nbsp;</TD>
		<TD><%=Server.HTMLEncode(rs("invoiceNumber"))%>&nbsp;</TD>
	</TR>
	<%
			rs.movenext
		wend
		set rs = nothing
	%>

</TABLE>
</DIV>
</FORM>
</BODY>
</HTML>

