<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
    dim query, rs

    select case lcase(Request.QueryString("useraction"))
    case "add"
        AddQuota
    case "remove"
        RemoveQuota
    end select
    
    sub AddQuota()
        dim query, rs
        dim deptName
        dim pieces
        
        RemoveQuota
        
        deptName = Request.QueryString("deptname")
        pieces = Request.QueryString("pieces")
        
        query = "insert into departmentquota (DepartmentName, PiecesDue) "
        query = query & " values ('" & deptName & "'"
        query = query & ", " & pieces & ")"
        
        qryexecute query
        
    end sub
    
    sub RemoveQuota()
        dim query
        dim deptName

        deptName = Request.QueryString("deptname")

        query = "delete departmentquota where DepartmentName = '" & deptName & "'"

        qryexecute query
    end sub
%>
<HTML>
<HEAD>
<TITLE></TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
    function AddQuota(name, pieces) {
        document.deptquota.action="?useraction=add&deptname=" + name + "&pieces=" + pieces;
        document.deptquota.submit();
    }
    function RemoveQuota(name) {
        document.deptquota.action="?useraction=remove&deptname=" + name;
        document.deptquota.submit();
    }
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Department Quota</H1>
<FORM id="deptquota" name="deptquota" action="" Method = "post">

<table border=1>

<tr>
    <td>
        <select name="addQuotaName">
        <%
            query = "select distinct name from department where storeid = " & session("storeid")    
            set rs = getdisconnectedrecordset(query)
            while not(rs.eof or rs.bof)
        %>
                <option value="<%=rs("name")%>"><%=rs("name")%></option>
        <%
                rs.movenext
            wend
            set rs = nothing
        %>
        <select>
    </td>
    <td><input  name="addQuotaPieces" style="width:50px" ></input></td>
    <td colspan=2><input type="button" value="Add" onclick="AddQuota(addQuotaName.value, addQuotaPieces.value)"></input></td>
</tr>

<%
    query = "select * from departmentquota"
    set rs = getdisconnectedrecordset(query)

    while not(rs.eof or rs.bof)
%>
        <tr>
            <td><%=rs("DepartmentName")%></td>
            <td><%=rs("PiecesDue")%></td>
            <td><input type="button" value="Remove" onclick="RemoveQuota('<%=rs("DepartmentName")%>')"></input></td>
        </tr>
<%
        rs.movenext
    wend
    set rs = nothing
%>
</table>

</FORM>
</BODY>
</HTML>
