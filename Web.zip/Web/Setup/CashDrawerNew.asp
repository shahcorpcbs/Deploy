<%@Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim isSubmitted 
	dim l_storeid 
	dim rstPort
	
	l_storeid  = Session("Storeid")
	l_terminalid =  Session("Setupterminalid")
	isSubmitted = Request.QueryString("submitted")
	
	if isSubmitted then
		updateDatabase()
		Response.Redirect("hardware.asp")
	end if
	
	
	dim l_hardwareid  
	dim l_port  
	dim l_rate 
	dim l_Type  
	dim l_brand 
	dim l_printerid  
	dim l_text 
	dim l_ascii 
	
	Dim rstTerminal
	dim rstCashDrawer
	dim l_terminalId
	
	
	getCashDrawerInfo()
	getPrinters()
	getPorts()		
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" src="../../External/jquery.js"></script>
<script language="javascript" type="text/javascript">
	function getCashDrawer(){
		var i ;
		if (document.cashdrawer.terminalList.selectedIndex >=0 )
		{
			i = document.cashdrawer.terminalList.selectedIndex ;
			document.cashdrawer.action = document.cashdrawer.action + "terminal=" +document.cashdrawer.terminalList(i).value;
			document.cashdrawer.submit();
		}
		else
			return false;
	}
	function validateType(element)
	{
		if ( element != null) {
			if (element.value == "S" || element.value == "L" || element.value == "U"){
				document.getElementById("optPrinter").disabled =false;
				$('input[name=rdserial]').attr("disabled",true);

			}
			else{
				document.getElementById("optPrinter").disabled =true;
				$('input[name=rdserial]').attr("disabled",false);

			}
		}
	}
	
	function submitForm(useraction) {
		if (validateform(useraction)){
			document.cashdrawer.action = "?Submitted=true&useraction="+ useraction;
			document.cashdrawer.submit()
		}
	}	
	
	function cancelForm() {
		document.cashdrawer.action = "Hardware.asp";
		document.cashdrawer.submit()
	}
		
	function validateform(element)	{
	
		if (element != "delete" ){
		    if ($('input[name=rdType]:checked').length == 0) {
				alert("Please select a type of cashdrawer")
				return false;
			}

			if ($('input[name=rdPort]:checked').length == 0) {
				alert("Port is a required field");
				return false;
			}
		}
		return true;
	}		
			
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Cash Drawer</H1>
<FORM id="cashdrawer" name="cashdrawer" action="" Method = "post">
<input type = hidden name = "h_hardwareid" value = "<%=l_hardwareid%>">
<CENTER>
<TABLE WIDTH="500px" BORDER=2 CELLSPACING=0 CELLPADDING=20><!-- header row -->
<TBODY>
 <tr><td width = 100%>
	<TABLE width = 100% border=0 cellpadding="0" cellspacing="0">
	<tr><td>
		<TABLE width = 100% border=0 cellpadding="0" cellspacing="10" >
		<tr><td class = "label" Style="Font-weight=normal" align=right>Type</td>
		<td align = left>

		<Input type=Radio name=rdType value="L" 
			<% if l_type = "L" then %>
				CHECKED 
			<% end if 
			if rstPrinter.recordcount <= 0 then %>
				DISABLED
			<%end if %>
		onclick= "validateType(this)">
		Local
		<Input type=Radio name=rdType value="S" 
			<% if l_type = "S" then %>
				CHECKED 
			<% end if 
			if rstPrinter.recordcount <= 0 then %>
				DISABLED
			<%end if %>
		onclick= "validateType(this)">
		Remote Solenoid
		
		</td>
		<td valign=top>Printer&nbsp;&nbsp;
		<Select id="optPrinter" name=optPrinter STYLE="Height = 24px;FONT-SIZE: 15px ;Width =150px;valign=top"
			<% if l_type <> "S" and l_type <> "L" then %>
				Disabled
			<% end if %>
		>
			<%getPrinters()
				If rstPrinter.recordcount > 0 then
					rstprinter.movefirst
					while not rstPrinter.eof 
			%>
					<option
						<%if l_printerid = trim(rstPrinter("Printerid"))  then %>
							Selected
						<%end if %>  
						value ="<%=rstPrinter("Printerid")%>"><%=rstPrinter("PrinterType")%></option>
					<%
					rstPrinter.movenext
					wend
					rstprinter.close
					set rstPrinter = nothing
				end if
				%>
			</select>
		</td></tr>
		<tr>
		<td></td>
		<td align =left><Input type=radio name=rdType  value = "R" 
							<% if l_type = "R" then %>
									CHECKED 
							<% end if %>
		
						onclick= "validateType(this)"
						>&nbsp;Serial</td>
		<td align= left >
						<Input type=radio name=rdserial  value="epson"
							<% if l_type <> "R" then %>
								Disabled
							<% end if %>
							<% if l_brand = "epson" then %>
									CHECKED 
							<% end if %>
						>&nbsp;Epson&nbsp&nbsp
						<Input type=radio name=rdserial  value="star"
							<% if l_type <> "R" then %>
								Disabled
							<% end if %>
							<% if l_brand = "star" then %>
									CHECKED 
							<% end if %>
			
						>&nbsp;Star
						</td>
		</tr>
		<tr>
		<td></td>
		<td align =left><Input type=radio name=rdType  value = "U" 
							<% if l_type = "U" then %>
									CHECKED 
							<% end if %>
		
						onclick= "validateType(this)"
						>&nbsp;USB</td>
		<td align= left ></td>
		</tr>
		<tr>
		</table>
		<table width = 100% border=0 cellpadding="0" cellspacing="10">
		<tr>
		<td class = "label" Style = "font-weight=normal">Baud Rate&nbsp;&nbsp;
			<SELECT name= optbrate STYLE="Height = 24px;FONT-SIZE: 15px ;Width =90px ">
				<Option 
				<%if l_rate = "1200" then %>
				Selected 
				<%end if%>
				
				Value = 1200>1200</option>
				<Option  <%if l_rate = "1800" then %>
				Selected 
				<%end if%>
				Value = 1800>1800</option>
				<Option  <%if l_rate = "2400" then %>
				Selected 
				<%end if%>
				Value = 2400>2400</option>
				<Option  <%if l_rate = "4800" then %>
				Selected 
				<%end if%>
				Value = 4800>4800</option>
				<Option  <%if l_rate = "7200" then %>
				Selected 
				<%end if%>
				Value = 7200>7200</option>
				<Option  <%if l_rate = "9600" then %>
				Selected 
				<%end if%>
				Value = 9600>9600</option>
				<Option  <%if l_rate = "14400" then %>
				Selected 
				<%end if%>
				Value = 14400>14400</option>
				<Option  <%if l_rate = "19200" then %>
				Selected 
				<%end if%>
				Value = 19200>19200</option>
				<Option  <%if l_rate = "57600" then %>
				Selected 
				<%end if%>
				Value = 38400>38400</option>												
				<Option  <%if l_rate = "57600" then %>
				Selected 
				<%end if%>
				Value = 57600>57600</option>												
				<Option  <%if l_rate = "115200" then %>
				Selected 
				<%end if%>
				Value = 115200>115200</option>																								
				</SELECT> 
		</td>
		</tr>
		</table>
		<table width = 100% border=0 cellpadding="0" cellspacing="10">
		<tr>
			<td align=left class = "label" Style = "font-weight=normal">Text value</td>
			<td ><input class = text maxlength="50" name="txttext" Style = "Width = 120px" value = "<%=l_text%>"></td> 
			<td  align=left class = "label" Style = "font-weight=normal">Ascii value</td>
			<td><input class = text maxlength="64" name="txtascii" Style = "Width = 120px" value="<%=l_ascii%>"></td> 
		</tr>
		</table>
		<table width = 100% border=0 cellpadding="0" cellspacing="10">
		<tr>
		<td class = "label" Style = "font-weight=normal">Port</td>
		<td colspan = "3"><INPUT   name=rdPort type=radio  Value = "LPT1" 
				<% if l_port = "LPT1" then %>
					CHECKED 
				<% end if %>
			<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "LPT1" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 	
			 >&nbsp;LPT 1&nbsp;&nbsp;&nbsp;
			<INPUT   name=rdPort type=radio  Value = "LPT2" 
				<% if l_port = "LPT2" then %>
					CHECKED 
				<% end if %>
				<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "LPT2" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 
			>&nbsp;LPT 2&nbsp;&nbsp;&nbsp;
			<INPUT   name=rdPort type=radio  Value = "LPT3"
				<% if l_port = "LPT3" then %>
					CHECKED 
				<% end if %>	
				<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "LPT3" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 
			>&nbsp;LPT 3&nbsp;&nbsp;&nbsp;
		    <INPUT   name=rdPort type=radio  Value = "USB" 
				<% if l_port = "USB" then %>
					CHECKED 
				<% end if %>
				<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "USB" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 
			>&nbsp;USB&nbsp;&nbsp;&nbsp;
		</tr>
		<tr>
		<td ></td>
		<td  valign=top colspan="3"><INPUT  name=rdPort type=radio  Value = "COM1" 
							<% if l_port = "COM1" then %>
									CHECKED 
							<% end if %>
							<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "COM1" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 
				>&nbsp;COM 1&nbsp;&nbsp;
				<INPUT   name=rdPort type=radio  Value = "COM2" 
							<% if l_port = "COM2" then %>
									CHECKED 
							<% end if %>
						<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "COM2" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 
				>&nbsp;COM 2&nbsp;&nbsp; 
				
		        <INPUT   name=rdPort type=radio  Value = "COM3" 
							<% if l_port = "COM3" then %>
									CHECKED 
							<% end if %>
				<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "COM3" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 
						>&nbsp;COM 3&nbsp;&nbsp; 
						
				<INPUT  name=rdPort type=radio  Value = "COM4" 
							<% if l_port = "COM4" then %>
									CHECKED 
							<% end if %>
							<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "COM4" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if 
				rstPort.close
				set rstPort = nothing
				%> 
				>&nbsp;COM 4<br><br><br></td>
		</tr>
		</table>
	</td>
	</tr>
	</table>
	<table width=100% border=0 >
	<tr>
		<td align=center>
		<INPUT  class = click name="delete" type=button value="Do not use" 
			<%  if len(trim(l_hardwareid)) = 0 then %>
				Disabled
			<%end if %>
			style="HEIGHT: 50; WIDTH: 100" onClick="submitForm('delete')"><br><br>
		</td>	
	</tr>
	<tr >
		<td align=center>
			<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
	</tr>		
	</table>
</td></tr>
</Table>
</CENTER>
</FORM>	
</BODY>
</HTML>


<%
	dim rstPrinter
	
	Function GetPrinters()
	Dim sqltxt
		sqltxt = "Select s.hardwareid, s.hardwarename , p.* from storehardware s , printer p where s.Terminalid = " & l_terminalid & " and s.hardwareid  = p.hardwareid order by p.printerType "
		set rstPrinter = GetDisconnectedRecordset(sqltxt)
	End function
	
	function getCashDrawerInfo()
	dim sqltxt
		sqltxt = "select * from storehardware where hardwaretype = 'CD' and terminalid = " & l_terminalid
		set rstCashDrawer = GetDisconnectedRecordset(sqltxt)
		if rstCashDrawer.recordcount > 0  then
			l_hardwareid = rstCashDrawer("hardwareid")
			l_port  = rstCashDrawer("port")
			l_rate= rstCashDrawer("Baudrate")
			l_Type = rstCashDrawer("CashDrawerType")
			l_brand= rstCashDrawer("brand")
			l_printerid = trim(rstCashDrawer("cashDrawerAttachedPrinterID"))
			l_text= rstCashDrawer("cashDrawerText")
			l_ascii = rstCashDrawer("cashDrawerASCII")
			
		end if
		rstCashDrawer.close
		
		set rstCashDrawer = nothing
		
	end function
	
	function updateDatabase()
	dim hardwareid
	dim sqltxt
	dim l_cashPrinterid
	
	hardwareid= Request.Form("h_hardwareid")
	
	if trim(Request.form("rdType")) = "S" or trim(Request.form("rdType")) = "L" then
			l_cashPrinterid  = Request.form("optPrinter")
	end if
		
	if (Request.QueryString("useraction") = "delete" ) then
	
		sqltxt= "delete storehardware where hardwareid = " & hardwareid
		dbstarttrans()
		QryExecuteWithTrans(sqltxt)
		dbendTrans()
	
	else
	
		 
		if len(trim(hardwareid)) = 0 then
			'insert
			sqltxt = " INSERT INTO  StoreHardware ( terminalID, hardwareName, hardwareType, " _
				  & " cashDrawerType, brand, cashDrawerAttachedPrinterID ,baudRate,  " _
				  & " cashDrawerText,cashDrawerASCII, port) VALUES ( " _
				  &  l_terminalid _
				  & ", " & "'Cash Drawer'" _
				  &  ", " & "'CD'" _
				  & "," & dbcreateqrystring(Request.form("rdType"))_
				  & "," & dbcreateqrystring(Request.form("rdSerial"))_
				  & "," & DbCreateQryNumeric(l_cashPrinterid)_
				  & "," & dbcreateQryString(Request.form("optBrate"))  _
				  & "," & dbcreateqrystring(Request.form("txttext")) _
				  & "," & dbcreateQryString(Request.form("txtascii")) _
				  & "," & dbcreateqrystring(Request.form("rdPort")) _
				  & ")"
				'   Response.Write sqltxt
			dbstarttrans()
			QryExecuteWithTrans(sqltxt)
			DbEndTrans()
					
		else
			'update 
		
		
			sqltxt = " Update StoreHardware set " _
				  & " cashDrawerType= " & dbcreateqrystring(Request.form("rdType"))_
				  & " ,brand =" & dbcreateqrystring(Request.form("rdSerial"))_
				  & ", cashDrawerAttachedPrinterID= " & DbCreateQryNumeric(l_cashPrinterid)_ 
				  & ", baudRate = " & dbcreateQryString(Request.form("optBrate"))  _
				  & ", cashDrawerText= " & dbcreateqrystring(Request.form("txttext")) _
				  & ",cashDrawerASCII=" & dbcreateQryString(Request.form("txtascii")) _
				  & ", port= " & dbcreateqrystring(Request.form("rdPort")) _
				  & " where hardwareid = " & Request.Form("h_hardwareid")  & " and Terminalid = " & l_terminalid
				  ' Response.Write sqltxt
			dbstarttrans()			 
			QryExecuteWithTrans(sqltxt)
			dbendTrans()
			
		end if
	end if
	
	end function
	
	function getPorts()
	dim sqltxt
		sqltxt = "select distinct port from storehardware where port is not null and hardwaretype <> 'CD' and terminalid = " & l_terminalid 
		set rstPort = getdisconnectedrecordset(sqltxt)
		
	end function
%>
