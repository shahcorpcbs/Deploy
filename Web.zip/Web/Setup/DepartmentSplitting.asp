<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim s_query, s_rs

	select case lcase(Request.QueryString("useraction"))
	case "assignsplit"
		query = "update department set splitwithdepartment = " & Request.QueryString("slave") & " where departmentid = " & Request.QueryString("master")
		qryexecute query
	end select
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function splitDepartmentWith(master, slave) {
		document.splitting.action="?useraction=assignsplit&master=" + master + "&slave=" + slave;
		document.splitting.submit();
	}

	function exit() {
		    document.splitting.action = "PricingEditorNew.asp";
		document.splitting.submit();
	}

	
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Department Splitting</H1>
<FORM id="splitting" name="splitting" action="" Method = "post">

<table cellpadding=3  style="margin-left:50px">
	<tr>
		<th>Department</th>
		<th>Splits With</th>
	</tr>
<%

			
	query = "select departmentid, name, splitwithdepartment from department where storeid = " & session("storeid")
	set rs = getdisconnectedrecordset(query)
			
	while not(rs.eof or rs.bof)
%>
	<tr>
		<td><%=rs("name")%></td>
		<td>
			<select id=deptSplittingPair name=deptSplittingPair onchange="splitDepartmentWith(<%=rs("departmentid")%>, this.value)">
			<option value="null">Select Department</option>
<%
		s_query = "select departmentid, name from department where departmentid <> " & rs("departmentid") & " and storeid = " & session("storeid")
		set s_rs = getdisconnectedrecordset(s_query)
				
		while not(s_rs.eof or s_rs.bof)
%>
			<option value="<%=s_rs("departmentid")%>"
			<% if trim(s_rs("departmentid")) = trim(rs("splitwithdepartment")) then %>
			SELECTED
			<% end if %>><%=s_rs("name")%></option>
<%
			s_rs.movenext
		wend
		set s_rs = nothing
%>
			</option>
		</td>
	</tr>
<%
		rs.movenext
	wend
	set rs = nothing
%>

	<tr>
		<td align=center colspan=2>
			<button onclick="exit()" style="width:100px;height:50px" id=button1 name=button1>Ok</button>
		</td>
	</tr>
</table>


	
</BODY>
</HTML>
