<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim priceListId
	dim loyaltyName
	dim loyaltyId
	dim actionString
	dim name
	dim effDate
	dim expDate
	dim validWithOtherOffer
	dim minDolar
	dim maxDollar
	dim minPiece
	dim maxPiece
	dim noOfUses
	dim discSubType
	dim discountP
	dim discountAmt
	dim maxDiscAmt
	dim addOrEditAction
	dim couponId
	dim IsDiscAmt
	name =""
	effDate =Date()
	expDate =""
	validWithOtherOffer=1
	minDolar=""
	maxDollar =""
	minPiece =0
	maxPiece =-1
	noOfUses=0
	discountP =""
	discountAmt =""
	maxDiscAmt =""
	IsDiscAmt = true
	discSubType ="Pieces"
	couponId = Request.QueryString("couponId")
	addOrEditAction = Request.QueryString("addOrEdit")
	actionString = Request.QueryString("userAction")
	priceListId = Request.QueryString("priceListId")
	loyaltyName = Request.QueryString("loyaltyName")
	loyaltyId = Request.QueryString("loyaltyId")
	select case actionString
		case "addloyalty"
				addloyalty()
				Response.Redirect "Loyalty.asp?priceListId=" & priceListId & "&loyaltyName=" & loyaltyName & "&loyaltyid=" & loyaltyId
		case "deptRelation"
				couponId = addloyalty()
				Response.Redirect "DepartmentRelation.asp?couponId=" & couponId	& "&priceListId=" & priceListId & "&CouponOrPromotion=Loyalty Program" & "&loyaltyName=" & loyaltyName & "&loyaltyId=" & loyaltyId
		case "department"
				couponId = addloyalty()
				Response.Redirect "ApplicableDepartment.asp?couponId=" & couponId & "&priceListId=" & priceListId & "&CouponOrPromotion=Loyalty Program" & "&loyaltyName=" & loyaltyName & "&loyaltyId=" & loyaltyId
	end select
	
	function addloyalty()
		dim ssql
		dim rst
		dim discountType
		dim discountId
		collectFormData
		if addOrEditAction ="edit" then	
			discountId = couponId
			ssql ="UPDATE Discount SET discountSubType='" & discSubType & "', discountName='" _
				  & name & "', effectiveDate='" & effDate & "', expiryDate=" & expDate _
				  & ", minPieceCount=" & minPiece & ", maxPieceCount=" & maxPiece _
				  & ", minQualAmount=" & minDolar & ", maxQualAmount=" & maxDollar _
				  & ", discountPercent=" & discountP & ", discountAmount=" & discountAmt _
				  & ", maxDiscountAmount=" & maxDiscAmt & ", validWithOtherOffer=" _
				  &  validWithOtherOffer & ", noOfUses=" & noOfUses & " WHERE discountId=" & clng(couponId)
			QryExecute(ssql)
		else
			ssql ="Select discountType from DiscountTypeDomain where discountTypeName='Loyalty Program'" 
			set rst = getDisconnectedRecordset(ssql)
			if rst.recordcount >0 then
				rst.MoveFirst
				discountType = rst.fields("discountType")
			end if
			ssql="SET NOCOUNT ON;INSERT INTO Discount(priceListId, discountType, " _
				  & " discountSubType, discountName, effectiveDate, expiryDate, " _
				  & " minPieceCount, maxPieceCount, minQualAmount, maxQualAmount, " _
				  & " discountPercent, discountAmount, maxDiscountAmount, " _
				  & " validWithOtherOffer, noOfUses) VALUES(" & clng(priceListId) _
				  & ",'" & discountType & "','" & discSubType & "','" & name & "','" _
				  & effDate & "'," & expDate & "," & minPiece & "," & maxPiece & "," _
				  & minDolar & "," & maxDollar & "," & discountP & "," & discountAmt _
				  & "," & maxDiscAmt & "," & validWithOtherOffer & "," & noOfUses & ");" _
				  & "SELECT SCOPE_IDENTITY(); SET NOCOUNT OFF;"
			DbStartTrans
			discountId = QryExecuteWithTransAndSelect(ssql)
			DbEndTrans
			'inserted this to save the loyaltyid/discountid correlation - mwiemann 7/20/2003
			ssql="select count(*) as cnt from LoyaltyDiscount where discountId = "& discountID &" and loyaltyId = " & loyaltyid & ";"
			set rst = getDisconnectedRecordset(ssql)
			if rst.Fields("cnt").Value = 0 then
				ssql="insert into LoyaltyDiscount(loyaltyId,discountId) VALUES (" & clng(loyaltyId) _
				& "," & clng(discountId) & ");"
			end if	
			QryExecute(ssql)
		end if
		addloyalty = discountId
	end function
	
	function collectFormData()
		name = Request.Form("couponname")
		discSubType = Request.Form("coupontype")
		effDate=Request.Form("effectdate")
		expDate = Request.Form("expDate")
		noOfUses = clng(Request.Form("noOfUses"))
		if len(trim(expDate)) =0 then
			expDate ="NULL"
		else
			expDate ="'" & expDate & "'"
		end if
		if IsEmpty(Request.Form("isvalidwith")) then
			validWithOtherOffer =0
		else
			validWithOtherOffer =1
		end if
		select case Request.Form("discountamount")
			case "1"
				discountAmt = CDbl(Request.Form("discount"))
				discountP ="NULL"
				maxDiscAmt ="NULL"
			case "2"
				discountP = CDbl(Request.Form("discount"))
				discountAmt ="NULL"
				if len(trim(Request.Form("maxdiscount"))) > 0 then
					maxDiscAmt = CDbl(Request.Form("maxdiscount"))
				else
					maxDiscAmt = "NULL"
				end if
		end select
		select case discSubType
			case "Pieces"
					minPiece = clng(Request.Form("minPiece"))
					maxPiece = clng(Request.Form("maxPiece"))
					if maxPiece = -1 then
						maxPiece = "NULL"	
					end if
					minDolar ="NULL"
					maxDollar ="NULL"
			case "Amount"
					minDolar = CDbl(Request.Form("minDollar"))
					maxDollar = CDbl(Request.Form("maxDollar"))
					minPiece ="NULL"
					maxPiece ="NULL"
		end select
	end function
	
	function getCouponDetails()
		dim ssql
		dim objResultSet
		ssql = "Select discountId, discountName, effectiveDate, expiryDate, " _
				& " discountsubType, isnull(minPieceCount,0) as minPieceCount, " _
				& " maxPieceCount, isnull(minQualAmount, 0) as minQualAmount, " _
				& " isnull(maxQualAmount,0) as maxQualAmount, discountPercent, " _
				& "  discountAmount, isnull(maxDiscountAmount,0) as maxDiscountAmount, " _
				& " validWithOtherOffer, noOfUses from Discount where discountId=" & couponId
		set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.recordcount >0 then
			name =objResultSet.Fields("discountName")
			effDate = FormatDateTime(objResultSet.Fields("effectiveDate"), vbShortDate)
			noOfUses=objResultSet.Fields("noOfUses")
			if not isnull(objResultSet.fields("expiryDate")) then
				expDate = FormatDateTime(objResultSet.fields("expiryDate"), vbShortDate)
			end if
			discSubType = trim(objResultSet.Fields("discountsubType"))
			if discSubType ="Pieces" then
				minPiece = objResultSet.fields("minPieceCount")
				if IsNull(objResultSet.fields("maxPieceCount")) then
					maxPiece = -1
				else
					maxPiece = objResultSet.fields("maxPieceCount")
				end if
			else
				minDolar = objResultSet.fields("minQualAmount")
				maxDollar = objResultSet.fields("maxQualAmount")
			end if
			if not IsNull(objResultSet.fields("discountPercent")) then
				discountP = objResultSet.fields("discountPercent")
				maxDiscAmt = objResultSet.fields("maxDiscountAmount")
				IsDiscAmt =false
			else
				discountAmt = objResultSet.fields("discountAmount")
				IsDiscAmt =true
			end if
			if objResultSet.fields("validWithOtherOffer") then
				validWithOtherOffer = 1
			else
				validWithOtherOffer =0
			end if
		end if
	end function
		
	function checkNullField(val)
		if IsNull(val) then
			checkNullField =""
		else
			checkNullField =val
		end if
	end function
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker.js"></script>
<script language="javascript" type="text/javascript">

	function submitFormDepartment() {
		var priceId;
		var addEdit;
		var couponId;
		var loyName;
		var loyId;
		addEdit =document.addloyalty.addOrEdit.value;
		priceId = document.addloyalty.priceListId.value;
		couponId = document.addloyalty.discountId.value;
		loyName = document.addloyalty.loyaltyName.value;
		loyId = document.addloyalty.loyaltyId.value;
		if(validateForm()){
			document.addloyalty.action=document.addloyalty.action + "?userAction=department&priceListId=" + priceId +"&addOrEdit=" + addEdit + "&couponId=" + couponId + "&loyaltyName=" + loyName + "&loyaltyId=" + loyId;
			document.addloyalty.submit();
		}
	}
	function submitFormRelationship() {
		var priceId;
		var addEdit;
		var couponId;
		var loyName;
		var loyId;
		addEdit =document.addloyalty.addOrEdit.value;
		priceId = document.addloyalty.priceListId.value;
		couponId = document.addloyalty.discountId.value;
		loyName = document.addloyalty.loyaltyName.value;
		loyId = document.addloyalty.loyaltyId.value;
		if(validateForm()){
			document.addloyalty.action=document.addloyalty.action + "?userAction=deptRelation&priceListId=" + priceId +"&addOrEdit=" + addEdit + "&couponId=" + couponId + "&loyaltyName=" + loyName + "&loyaltyId=" + loyId;
			document.addloyalty.submit();
		}
	}
		
	function submitForm() {
		var priceList
		var discountId
		var addEdit
		var loyName
		var loyId
		priceList = document.addloyalty.priceListId.value;
		discountId = document.addloyalty.discountId.value;
		addEdit = document.addloyalty.addOrEdit.value;
		loyName = document.addloyalty.loyaltyName.value;
		loyId = document.addloyalty.loyaltyId.value;
		if (validateForm()){
			document.addloyalty.action = "?userAction=addloyalty&priceListId=" + priceList +"&addOrEdit=" + addEdit + "&couponId=" + discountId + "&loyaltyName=" + loyName + "&loyaltyId=" + loyId;
			document.addloyalty.submit();
		}
	}
	
	function validateForm() {
		var temp;
		var index;
		var ctype;
		temp = document.addloyalty.couponname.value;
		if (temp.length==0){
			showFocus("Offer name cannot be blank", document.addloyalty.couponname);
			return false;
		}
		temp = document.addloyalty.expDate.value;
		//if(temp.length>0 && 
		
		temp = document.addloyalty.noOfUses.value;

		temp = document.addloyalty.discount.value;
		if(temp.length==0){
			showFocus("Discount is invalid", document.addloyalty.discount);
			return false;
		}else{
			temp = cleanNumeric(temp);
			if (temp == "") {
				showFocus("Discount is invalid", document.addloyalty.discount);
				return false;
			} //eval(temp)<=eval(0)
		}
		if(document.addloyalty.discountamount[1].checked){
			temp = document.addloyalty.maxdiscount.value;
			temp = cleanNumeric(temp);
			if (!isNum1(temp,0)) {
					showFocus("Invalid Max Discount", document.addloyalty.maxdiscount);
					return false;
			} //eval(temp)<=eval(0)
			
		}
		index = document.addloyalty.coupontype.selectedIndex;
		ctype = document.addloyalty.coupontype(index).value;
		if(ctype=="Amount"){
			temp = document.addloyalty.minDollar.value;
			if(temp.length==0 || !isNum1(temp,0)){
				showFocus("Invalid Min Dollar Amount", document.addloyalty.minDollar);
				return false;
			}
			temp = document.addloyalty.maxDollar.value;
			if(temp.length==0 || !isNum1(temp,0)){
				showFocus("Invalid Max Dollar Amount", document.addloyalty.maxDollar);
				return false;
			}
		}
		return true;
	}
	function enableDisableMaxDisc(){
		if (document.addloyalty.discountamount[0].checked) {
			document.addloyalty.maxdiscount.value="";
			document.addloyalty.maxdiscount.disabled=true;
		}
		else {
			document.addloyalty.maxdiscount.disabled =false;
		}
	}
	function adjustDiscSubType(){
		var index;
		index = document.addloyalty.coupontype.selectedIndex;
		if (document.addloyalty.coupontype(index).value == "Pieces"){
			document.addloyalty.minpiece.disabled=false;
			document.addloyalty.maxpiece.disabled=false;
			document.addloyalty.minDollar.value="";
			document.addloyalty.maxDollar.value="";
			document.addloyalty.minDollar.disabled=true;
			document.addloyalty.maxDollar.disabled=true;
		}else{
			document.addloyalty.minpiece.disabled=true;
			document.addloyalty.maxpiece.disabled=true;
			document.addloyalty.minDollar.disabled=false;
			document.addloyalty.maxDollar.disabled=false;
		}
	}
	
	function cancelForm() {
		var loyaltyId
		var pricelistId
		var loyaltyName
		loyaltyId = document.addloyalty.loyaltyId.value
		pricelistId = document.addloyalty.priceListId.value
		loyaltyName = document.addloyalty.loyaltyName.value
		document.addloyalty.action="Loyalty.asp?loyaltyId=" + loyaltyId + "&pricelistid=" + pricelistId + "&loyaltyName=" + loyaltyName;
		document.addloyalty.submit();
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Add Loyalty Offer</H1>
<CENTER>
<FORM id="addloyalty" name="addloyalty" action="addloyalty.asp" Method = "post">
	<input type="hidden" name="Horde" value="03f8cf1caacb2781342becfcfc94af95" />
	<INPUT type="hidden" name="priceListId" value="<%= priceListId %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEditAction %>">
	<INPUT type="hidden" name="discountId" value="<%= couponId %>">
	<INPUT type="hidden" name="loyaltyName" value="<%= loyaltyName %>">
	<INPUT type="hidden" name="loyaltyId" value="<%= loyaltyId %>">
<TABLE WIDTH="550" BORDER=2 CELLSPACING=0 CELLPADDING=10 Style = ><!-- header row -->
<TBODY>
	<%
		if addOrEditAction ="edit" then
			getCouponDetails
		end if
	%>
	
 <tr>
	<td align=left valign=top>
	<TABLE width = 100% border="0" cellpadding="5" cellspacing="0" Style = "MARGIN-LEFT: 8px">
	<tr valign=bottom>
		<td height=30px colspan=4 class=label>Loyalty Offer</td>
	</tr>
	<tr>
		<td align=right>Offer Name</td>
		<td colspan=3>
			<INPUT Class = text name=couponname Style = "WIDTH:250px" value="<%= name%>">
		</TD>
	</tr>
	<tr>
		<td align=right>Offer Type</td>
		<td colspan=3>
			<SELECT name= coupontype STYLE="FONT-SIZE:14px;WIDTH:150px" onChange="adjustDiscSubType();">
				<%
					if discSubType ="Pieces" then
				%>
					<OPTION  Selected  Value = "Pieces">Pieces</OPTION>
					<OPTION  Value = "Amount">Amount</OPTION>
				<%
					else
				%>
					<OPTION  Value = "Pieces">Pieces</OPTION>
					<OPTION  Selected Value = "Amount">Amount</OPTION>
				<%
					end if
				%>
			</SELECT> 
		</td>
	</tr>
	<tr>
		<td align=right>Number of uses</td>
		<td>
			<input CLASS=text name=noOfUses style="width=50px" value="<%= noOfUses%>">
		</td>
	</tr>	
	<tr>
		<td align=right>Effective Date</td>
		<td colspan=5>
			<INPUT Class = text name=effectdate Style = "WIDTH: 70px;vertical-align:middle;" value="<%= effDate%>" readonly>
			<INPUT class=click id=BttnEffDate name=BttnEffDate type=button value="..." style="width:25px;height:25px;vertical-align:top;" onClick="javascript:show_calendar('addloyalty.effectdate');">
		&nbsp&nbsp&nbsp
		Expiration Date&nbsp
			<INPUT Class = text name=expDate Style = "WIDTH: 70px;vertical-align:middle;" value="<%= expDate %>" readonly>
			<INPUT class=click id=BttnexpDate name=BttnexpDate type=button value="..." style="width:25px;height:25px;vertical-align:top;" onClick="javascript:show_calendar('addloyalty.expDate');">
		</TD>
	</tr>
	<!--
	<tr>
		<td>Due Date</td>
		<td>
			<INPUT Class = text name=txtDueDate Style = "WIDTH: 70px;vertical-align:middle;" value="<%= expDate %>" readonly>
			<INPUT class=click id=BttnexpDate name=BttnexpDate type=button value="..." style="width:25px;height:25px;vertical-align:middle;" onClick="javascript:show_calendar('addloyalty.expDate');">
		</td>
	</tr>
	-->
	<tr valign=bottom>
		<td height=30px colspan=4 class=label>Discount Amount</td>
	</tr>
	<tr>
		<%
			if IsDiscAmt then
		%>
			<td align=right>Discount</td>
			<td>
				<INPUT Class = text name=discount Style = "WIDTH: 80px" value="<%= discountAmt%>">
			&nbsp&nbsp&nbsp
				<Input type= radio name=discountamount value="1" Checked onClick="enableDisableMaxDisc()">&nbsp;&nbsp;Dollars ($)&nbsp&nbsp
				<Input type= radio name=discountamount value="2" onClick="enableDisableMaxDisc()">&nbsp;&nbsp;Percent (%)
			</td>
		<%
			else
		%>
			<td align=right>Discount</td>
			<td>
				<INPUT Class = text name=discount Style = "WIDTH: 80px" value="<%= discountP%>">
			&nbsp&nbsp&nbsp
				<Input type= radio name=discountamount value="1" onClick="enableDisableMaxDisc()">&nbsp;&nbsp;Dollars ($)&nbsp&nbsp
				<Input type= radio name=discountamount value="2" checked onClick="enableDisableMaxDisc()">&nbsp;&nbsp;Percent(%)
			</td>
		<%
			end if
		%>
	</tr>
	<tr>
		<td align=right>Max Discount ($)</td>
		<td>
			<INPUT Class = text name=maxdiscount Style = "WIDTH: 80px" value="<%= maxDiscAmt%>" <% if IsDiscAmt then %> disabled <% end if%>>
		</TD>
	</tr>
	<tr valign=bottom>
		<td height=30px colspan=4 class=label>Invoice Limits</td>
	</tr>
	<tr valign=middle>
		<td align=right>Min/Max Pieces</td>
		<td colspan=5>
			<SELECT name= minpiece STYLE="FONT-SIZE:  15px; HEIGHT: 24px;  WIDTH: 60px" <% if discSubType="Amount" then %> disabled <% end if%>>
				<%
					dim i
					for i=0 to 50
					if discSubType ="Pieces" and clng(minPiece)=i then
						
				%>
						<OPTION  Value ="<%= i%>" selected><%= i%></OPTION>
				<%
					else
				%>
						<OPTION  Value ="<%= i%>"><%= i%></OPTION>
				<%
					end if
					next
				%>
			</SELECT>
			&nbsp;To&nbsp&nbsp
			<SELECT name= maxpiece STYLE="FONT-SIZE:  15px; HEIGHT: 24px;  WIDTH: 100px" <% if discSubType="Amount" then %> disabled <% end if%>>
				<%
					for i=0 to 50
					if discSubType ="Pieces" and clng(maxPiece)=i then
						
				%>
						<OPTION  Value ="<%= i%>" selected><%= i%></OPTION>
				<%
					else
				%>
						<OPTION  Value ="<%= i%>"><%= i%></OPTION>
				<%
					end if
					next
				%>
					<OPTION  Value ="-1" <% if clng(maxPiece) = -1 then%> selected <%end if%>>Unlimited</OPTION>
			</SELECT>  
		</td>
	</tr>
	<tr valign=middle>
		<td align=right>Min/Max Dollar</td>
		<td align=left colspan=5>
			<INPUT Class = text name=minDollar Style = "WIDTH: 80px" value="<%= minDolar%>" <% if discSubType="Pieces" then %> disabled <% end if%>>
			&nbsp;To&nbsp;&nbsp
			<INPUT Class = text name=maxDollar Style = "WIDTH: 80px" value="<%= maxDollar%>" <% if discSubType="Pieces" then %> disabled <% end if%>>  
		</td>
	</tr>
	<tr><td height=20px></td></tr>
	<tr>
		<%
			if validWithOtherOffer = 1 then
		%>
				<td colspan=4>
					<input type=checkbox name="isvalidwith" style =margin-left=20px value="1" checked>&nbsp;&nbsp;Valid With Other Offers</td>
				</td>
		<%
			else
		%>
			<td colspan=4>
				<input type=checkbox name="isvalidwith" style =margin-left=20px value="1">&nbsp;&nbsp;Valid With Other Offers</td>
			</td>
		<%
			end if
		%>
	</tr>
	<tr>
		<td colspan=6 align=center>
			<INPUT class = click name="appdepartment" type=button value="Applicable Department" style="HEIGHT: 75px; WIDTH: 150px" onClick="submitFormDepartment()">&nbsp&nbsp&nbsp&nbsp&nbsp
			<INPUT class = click name="relationship" type=button value="Department Relationship" style="HEIGHT: 75px; WIDTH: 150px" onClick="submitFormRelationship()">
		</td>
	</tr>
	<tr height=100px>
		<td colspan=6 align=center>
			<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
		</td></tr>
	</table>
	</td></tr>
</TABLE>
</FORM>
</CENTER>		
</BODY>
</HTML>

