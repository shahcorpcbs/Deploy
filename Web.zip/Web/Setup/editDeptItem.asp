<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
    dim plId, deptId, itemId
    dim d_name, oldName, d_displaySequence, d_useGlobalTax, d_useGlobalDays, d_discountable, d_vipDiscountable, d_vipQualified
    dim d_saleOnly, d_couponable, d_splitInvoice, d_qtyInInventory, d_itemCost, d_prePayPercent, d_notes, d_printNotes
    dim d_userCounter, d_priceLater, d_prompt, d_options, d_prepayDiscount, d_price, d_finishTime, d_outsideService, d_shortcut
    dim d_taxId, d_surchargeId, d_daysToProcess, d_formName, d_useGlobalDescr, d_taxNames, d_useGlobalSur, deptDaysToProc

    plId = trim(getReqVar("plID"))
    deptId = trim(getReqVar("deptID"))
    itemId = trim(getReqVar("itemId"))


    dim storeId, query2, rs2, cnt
    storeId = Session("storeID")
    query = "select daysToProcess from Department where departmentId = " & deptId
    set rs = getdisconnectedrecordset(query)
    deptDaysToProc = rs("daysToProcess")

	if trim(Request.QueryString("useraction")) = "submit" then
	    oldName = Request.Form("oldName")

        dim u_name, u_displaySequence, u_useGlobalDays, u_discountable, u_vipDiscountable, u_vipQualified
        dim u_saleOnly, u_couponable, u_splitTicket, u_outsideService, u_printNotes, u_notes, u_useGlobalTax
        dim u_daysToProcess, u_prePayPercent, u_prepayDiscount, u_taxId, u_surchargeId, u_priceLater, u_shortcut
        dim u_price, u_quantity, u_finishTime, u_prompt, u_options, u_formName, u_useGlobalDescr, u_useGlobalSur
        dim taxes, curTax, surcharges, curSur, index, saveMode
		SaveFormData()
	end if

    if itemId <> "" then
        query = "select * from PriceListitem where priceListItemid = " & itemId
        set rs = getdisconnectedrecordset(query)
        d_name = rs("itemName")
        oldName = d_name
        d_displaySequence = rs("displaySequence")
        d_useGlobalTax = rs("useGlobalTax")
        d_useGlobalDays = rs("useGlobalDays")
        d_splitInvoice = rs("splitInvoice")
        d_discountable = rs("discountable")
        d_vipDiscountable = rs("vipDiscountable")
        d_vipQualified = rs("vipQualified")
        d_saleOnly = rs("saleOnly")
        d_couponable = rs("couponable")
        d_outsideService = rs("outsideService")
        d_printNotes = rs("printNotes")
        d_priceLater = rs("pricelater")
        d_useGlobalSur = rs("useGlobalSurcharge")

        d_price = rs("price")
        d_daysToProcess = rs("daysToProcess")
        d_prePayPercent = rs("prePayPercent")
        d_finishTime = rs("finishTime")
        d_notes = rs("notes")
        d_prepayDiscount = rs("prepayDiscount")
        d_prompt = rs("prompt")
        d_options = rs("options")
        d_qtyInInventory = rs("qtyInInventory")
        d_formName = rs("itemReleaseInvoiceFormName")
        d_useGlobalDescr = rs("useGlobalDescr")
        d_shortcut = rs("itemShortcut")

        query = "select a.taxCode, b.description from ItemTax a, Tax b where a.taxCode = b.taxCode and priceListItemId = " & itemId
        set rs = getdisconnectedrecordset(query)
        while not(rs.eof or rs.bof)
            d_taxId = d_taxId & rs("taxCode") & ","
            d_taxNames = d_taxNames & rs("description") & ","
        rs.movenext
        wend

        query = "select surchargeCode from ItemSurcharge where priceListItemId = " & itemId
        set rs = getdisconnectedrecordset(query)
        while not(rs.eof or rs.bof)
            d_surchargeId = d_surchargeId & rs("surchargeCode") & ","
        rs.movenext
        wend

    end if


    function SaveFormData()
		u_name = trim(Request.QueryString("name"))
		u_useGlobalTax = trim(Request.QueryString("globTax"))
		u_useGlobalSur = trim(Request.QueryString("globSur"))
		u_useGlobalDays = trim(Request.QueryString("globDays"))
		u_splitTicket = trim(Request.QueryString("spTic"))
		u_discountable = trim(Request.QueryString("disc"))
		u_vipDiscountable = trim(Request.QueryString("vipDisc"))
		u_vipQualified = trim(Request.QueryString("vipQual"))
		u_saleOnly = trim(Request.QueryString("saleOnly"))
		u_couponable = trim(Request.QueryString("coupon"))
		u_outsideService = trim(Request.QueryString("outServ"))
		u_printNotes = trim(Request.QueryString("printNotes"))
		u_priceLater = trim(Request.QueryString("priceLater"))
		u_taxId = trim(Request.QueryString("taxCode"))
		u_surchargeId = trim(Request.QueryString("surCode"))
		u_price = trim(Request.QueryString("price"))
		u_prePayPercent = trim(Request.QueryString("prepayPer"))
		u_quantity = trim(Request.QueryString("quantity"))
		u_daysToProcess = trim(Request.QueryString("daysProc"))
		u_displaySequence = trim(Request.QueryString("dispSeq"))
		u_finishTime = trim(Request.QueryString("finishTime"))
		u_prompt = trim(Request.QueryString("prompt"))
		u_options = trim(Request.QueryString("options"))
		u_prepayDiscount = trim(Request.QueryString("prepayDiscount"))
		u_notes = trim(Request.QueryString("notes"))
		u_formName =  trim(Request.QueryString("formName"))
		u_useGlobalDescr = trim(Request.QueryString("useGlobalDescr"))
		u_shortcut = trim(Request.QueryString("shortcut"))
		saveMode = trim(Request.QueryString("saveMode"))

        if itemId = "" then

            query = "SET NOCOUNT ON; Insert into PriceListItem(DepartmentId, PriceListId, ItemName, price, useGlobalTax, useGlobalSurcharge, " _
                & "useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, outsideService, saleOnly, splitInvoice, " _
                & "qtyInInventory, prepayPercent, displaySequence, daysToProcess, notes, printNotes, priceLater, " _
                & "prompt, options, finishTime, prepayDiscount, useGlobalDescr, itemShortcut, itemReleaseInvoiceFormName) " _
                & "values (" & deptId & ", " & plId & ", '" & DBStr(u_name) & "', '" & u_price & "', " & u_useGlobalTax _
                & ", " & u_useGlobalSur & ", " & u_useGlobalDays & ", " & u_discountable & ", " & u_vipDiscountable & ", " & u_vipQualified _
                & ", " & u_couponable & ", " & u_outsideService & ", " & u_saleOnly & ", " & u_splitTicket & ", '" _
                & u_quantity & "', '" & u_prePayPercent & "', '" & u_displaySequence & "', '" & u_daysToProcess & "', '" _
                & DBStr(u_notes) & "', " & u_printNotes & ", " & u_priceLater & ", '" & DBStr(u_prompt) & "', '" _
                & DBStr(u_options) & "', '" & u_finishTime & "', '" & u_prepayDiscount & "', " & u_useGlobalDescr  _
                & ", '" & DBStr(u_shortcut) & "', "
                if u_formName = "" then
                    query = query & "null "
                else
                    query = query & "'" & DBStr(u_formName)  & "'"
                end if
                query = query & "); " & "SELECT SCOPE_IDENTITY(); SET NOCOUNT OFF;"

		    DbStartTrans()
                itemId = QryExecuteWithTransAndSelect(query)
            DbEndTrans

            if u_taxId <> "" then
                taxes = Split(u_taxId,",")
                for index = 0 to UBound(taxes)
                    curTax = trim(taxes(index))
                    query = "insert into ItemTax (PricelistItemId, taxCode, storeId) values (" _
                        & itemId & ", " & curTax & ", " & storeId & ")"
                    qryexecute query
                next
            end if

            if u_surchargeId <> "" then
                surcharges = Split(u_surchargeId,",")
                for index = 0 to UBound(surcharges)
                    curSur = trim(surcharges(index))
                    query = "insert into ItemSurcharge (PricelistItemId, surchargeCode, priceListId) values (" _
                        & itemId & ", " & curSur & ", " & plId & ")"
                    qryexecute query
                next
            end if

           if u_useGlobalDescr = 1 then
                addGlobalDesc itemId
           end if
        else
            if saveMode = 0 then
                updateIndividualItem(itemId)
            elseif saveMode = 1 then
                query = "select priceListItemId itemId from PriceListItem where priceListId = " & plId _
                    & " and itemName = '" & DBStr(oldName) & "'"
                set rs = getdisconnectedrecordset(query)
                while not(rs.eof or rs.bof)
                    updateIndividualItem(rs("itemId"))
                rs.movenext
                wend
            elseif saveMode = 2 then
                query = "select priceListItemId itemId from PriceListItem where itemName = '" & DBStr(oldName) & "'"
                set rs = getdisconnectedrecordset(query)
                while not(rs.eof or rs.bof)
                    updateIndividualItem(rs("itemId"))
                rs.movenext
                wend
            end if

        end if

        response.redirect "priceListDeptsList.asp?plId=" & plId & "&expandedDept=" & deptId
    end function


    function updateIndividualItem(currItemId)
            query = "Update PriceListItem set itemName = '" & DBStr(u_name) _
                &  "', displaySequence = " & DBStr(u_displaySequence) _
                &  ", useGlobalTax = " & DBStr(u_useGlobalTax) _
                &  ", useGlobalSurcharge = " & DBStr(u_useGlobalSur) _
                &  ", useGlobalDays = " & DBStr(u_useGlobalDays) _
                &  ", splitInvoice = " & DBStr(u_splitTicket) _
                &  ", discountable = " & DBStr(u_discountable) _
                &  ", VIPDiscountable = " & DBStr(u_vipDiscountable) _
                &  ", VIPQualified = " & DBStr(u_vipQualified) _
                &  ", saleOnly = " & DBStr(u_saleOnly) _
                &  ", couponable = " & DBStr(u_couponable) _
                &  ", outsideService = " & DBStr(u_outsideService) _
                &  ", printNotes = " & DBStr(u_printNotes) _
                &  ", priceLater = " & DBStr(u_priceLater) _
                &  ", price = " & DBStr(u_price) _
                &  ", prePayPercent = " & DBStr(u_prePayPercent) _
                &  ", qtyInInventory = '" & DBStr(u_quantity) _
                &  "', daysToProcess = '" & DBStr(u_daysToProcess) _
                &  "', finishTime = '" & DBStr(u_finishTime) _
                &  "', prompt = '" & DBStr(u_prompt) _
                &  "', options = '" & DBStr(u_options) _
                &  "', prepayDiscount = '" & DBStr(u_prepayDiscount) _
                &  "', notes = '" & DBStr(u_notes) _
                &  "', itemShortcut = '" & DBStr(u_shortcut) _
                &  "', useGlobalDescr = " & u_useGlobalDescr
                if u_formName = "" then
                    query = query & ", itemReleaseInvoiceFormName = null "
                else
                    query = query & ", itemReleaseInvoiceFormName = '" & DBStr(u_formName)  & "'"
                end if
                query = query & " where PriceListItemId = " & currItemId
            qryexecute query


            query = "delete ItemTax where priceListItemId = " & currItemId
            qryexecute query

            if u_taxId <> "" then
                taxes = Split(u_taxId,",")
                for index = 0 to UBound(taxes)
                    curTax = trim(taxes(index))
                    query = "insert into ItemTax (PricelistItemId, taxCode, storeId) values (" _
                        & currItemId & ", " & curTax & ", " & storeId & ")"
                    qryexecute query
                next
            end if

            query = "delete ItemSurcharge where priceListItemId = " & currItemId
            qryexecute query

            if u_surchargeId <> "" then
                surcharges = Split(u_surchargeId,",")
                for index = 0 to UBound(surcharges)
                    curSur = trim(surcharges(index))
                    query = "insert into ItemSurcharge (PricelistItemId, surchargeCode, priceListId) values (" _
                        & currItemId & ", " & curSur & ", " & plId & ")"
                    qryexecute query
                next
            end if

           clearGlobalDesc currItemId
           if u_useGlobalDescr = 1 then
                addGlobalDesc currItemId
           end if

    end function

    function clearGlobalDesc(currItemId)
        query = "delete ItemDescriptorPrice where priceListItemId = " & currItemId & "  and IsGlobal = 1"
        qryexecute query
    end function

    function addGlobalDesc(currItemId)
        query = "insert into ItemDescriptorPrice (priceListItemId, descriptorName, descriptorType, price, " _
            & "disabled, useGlobalTax, useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, " _
            & "outsideService, prepaypercent, displaySequence, daysToProcess, imageFileName, notes, printNotes, " _
            & "useCounter, prepayDiscount, isGlobal) " _
            & "(select " & currItemId & ", descriptorName, descriptorType, price, disabled, useGlobalTax, " _
            & "useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, outsideService, prepaypercent, " _
            & "displaySequence, daysToProcess, imageFileName, notes, printNotes, useCounter, prepayDiscount, 1 " _
            & "from ItemDescriptorPrice a where priceListItemId = 0 and descriptorName not in " _
            & "(select descriptorName from ItemDescriptorPrice c where c.priceListItemId = " & currItemId _
            & "and a.descriptorType = c.descriptorType))"

        qryexecute query

    end function

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
%>

<html>
<head>
<title>Edit Department Item</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
<link href="../style/overlay.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="/External/jquery-3.4.1.js"></script>
<script language="javascript" type="text/javascript">

    function save() {
        var name = $.trim(document.getElementById('txt_name').value);
        if (name === "") {
            cbs_alert("Cannot set a blank name");
            return;
        }

        var price = encodeURIComponent(document.getElementById('txt_price').value);
        if (price == "") {
            cbs_alert("Cannot set a blank price");
            return;
        }

       submitForm();
    }

function submitForm() {
    var name = $.trim(document.getElementById('txt_name').value);
    var price = encodeURIComponent(document.getElementById('txt_price').value);
    var prePayPercent = encodeURIComponent(document.getElementById('txt_pp').value);
    if (prePayPercent == "")
        prePayPercent = "0"

    var surcharges = "";
    $('[id^=chkSur_]').each(function() {
        if (this.checked) {
            var number = this.id.split('_').pop();
            surcharges = surcharges + number + ",";
        }
    });

    if (printOptions[printOptions.length - 1] == "|")
        printOptions = printOptions.substring(0, printOptions.length - 1);

    <% if itemId <> "" then %>
        saveMode = document.getElementById('saveOptionSel').value;
    <% else %>
        var saveMode = 0;
    <% end if %>

	document.editDeptItemForm.action = "?useraction=submit" +
	    "&plId=<%=plId%>" +
	    "&deptId=<%=deptId%>" +
	    "&itemId=<%=itemId%>" +
	    "&saveMode=" + saveMode +
	    "&name=" + encodeURIComponent(name) +
	    "&globTax=" + (document.getElementById('chk_globalTax').checked ? "1" : "0") +
	    "&globSur=" + (document.getElementById('chk_globalSur').checked ? "1" : "0") +
	    "&globDays=" + (document.getElementById('chk_globalDays').checked ? "1" : "0") +
	    "&spTic=" + (document.getElementById('chk_splitTicket').checked ? "1" : "0") +
	    "&disc=" + (document.getElementById('chk_discountable').checked ? "1" : "0") +
	    "&vipDisc=" + (document.getElementById('chk_vipdiscountable').checked ? "1" : "0") +
	    "&vipQual=" + (document.getElementById('chk_vipQualified').checked ? "1" : "0") +
	    "&saleOnly=" + (document.getElementById('chk_saleOnly').checked ? "1" : "0") +
	    "&coupon=" + (document.getElementById('chk_couponable').checked ? "1" : "0") +
	    "&outServ=" + (document.getElementById('chk_outsideService').checked ? "1" : "0") +
	    "&printNotes=" + (document.getElementById('chk_printNotes').checked ? "1" : "0") +
	    "&priceLater=" + (document.getElementById('chk_priceLater').checked ? "1" : "0") +
	    "&useGlobalDescr=" + (document.getElementById('chk_useGlobalDescr').checked ? "1" : "0") +
	    "&taxCode=" + encodeURIComponent(taxCodes) +
	    "&surCode=" + encodeURIComponent(surcharges) +
	    "&price=" + encodeURIComponent(price) +
	    "&prepayPer=" + encodeURIComponent(prePayPercent) +
	    "&quantity=" + encodeURIComponent(document.getElementById('txt_quantity').value) +
	    "&shortCut=" + encodeURIComponent(document.getElementById('txt_shortCut').value) +
	    "&daysProc=" + encodeURIComponent(document.getElementById('txt_daysToProcess').value) +
	    "&dispSeq=" + encodeURIComponent(document.getElementById('txt_displaySeq').value) +
	    "&finishTime=" + encodeURIComponent(document.getElementById('txt_finishTime').value) +
	    "&prompt=" + encodeURIComponent(document.getElementById('txt_prompt').value) +
	    "&options=" + encodeURIComponent(printOptions) +
	    "&prepayDiscount=" + encodeURIComponent(document.getElementById('txt_pd').value) +
	    "&formName=" + encodeURIComponent(document.getElementById('sel_formName').value) +
	    "&notes=" + encodeURIComponent(document.getElementById('txt_notes').value);
    document.editDeptItemForm.submit();
}

function cancelForm() {
    document.editDeptItemForm.action = "priceListDeptsList.asp?plId=<%=plId%>&expandedDept=<%=deptId%>";
	document.editDeptItemForm.submit();
}

function toggleGlobal() {
    if (document.getElementById('chk_useGlobalDescr').checked)
        document.getElementById('globalDescrTable').style.visibility="visible";
    else
        document.getElementById('globalDescrTable').style.visibility="hidden";
}

function toggleDays() {
    if (document.getElementById('chk_globalDays').checked) {
        document.getElementById('txt_daysToProcess').disabled = true;
        document.getElementById('txt_daysToProcess').value = "<%= deptDaysToProc %>";
    }
    else
        document.getElementById('txt_daysToProcess').disabled = false;
}

function toggleTaxes() {
    if (document.getElementById('chk_globalTax').checked) {
        document.getElementById('sel_taxCode').disabled = true;
        useDeptTaxList();
        $('[id^=img_tax]').each(function() {
            this.style.visibility = 'hidden';
        });
    }
    else {
        document.getElementById('sel_taxCode').disabled = false;
        var i = 0;
        $('[id^=img_tax]').each(function() {
            this.style.visibility = 'visible';
        });
    }
}

function toggleSurcharges() {
    if (document.getElementById('chk_globalSur').checked) {
        useDeptSurList();
        $('[id^=chkSur_]').each(function() {
            this.disabled = true;
        });
    }
    else {
        $('[id^=chkSur_]').each(function() {
            this.disabled = false;
        });
    }
}

	function formatAmount(element)
	{
		var temp = cleanNumeric(element.value)
		element.value = autoFormatCurrency(temp)
	}

	var taxNames;
	var taxCodes;
	var printOptions;

	function init() {
	    taxNames = '<%= d_taxNames %>'.trim();
	    taxCodes = '<%= d_taxId %>'.trim();
	    printOptions = '<%= d_options %>'.trim();
        updateTaxList();
	    updateOptions();
	    toggleTaxes();
	    toggleSurcharges();
	    toggleDays();

	    <% if itemId = "" then %>
            document.getElementById('chk_vipdiscountable').checked = true;
            document.getElementById('chk_discountable').checked = true;
            document.getElementById('chk_vipQualified').checked = true;
            document.getElementById('chk_couponable').checked = true;
            useDeptTaxList();
            useDeptSurList();
        <% end if %>

        showEdit();
	}

	function updateOptions() {
	    var result = "";
	    var printArray = printOptions.split("|");
	    for (i = 0; i < printArray.length; i++) {
	        if (printArray[i] != '')
	            result += " " + printArray[i] + " <img src='../images/Cancel-2.gif' id='img_opt_" + i + "' style='width:15px;height:15px;' onClick='removeOpt(" + i + ")' />";
        }

	    document.getElementById('printOptList').innerHTML  = result;
	}

	function addOption() {
	    var optToAdd = document.getElementById('txt_option').value
	    if (printOptions.length > 0)
	        printOptions += "|"
	    printOptions += optToAdd;
        updateOptions();
	    document.getElementById('txt_option').value = "";
	}

	function removeOpt(index) {
	    var optToRemove = printOptions.split("|")[index];
	    if (printOptions.includes("|" + optToRemove))
            printOptions = printOptions.replace("|" + optToRemove, "");
	    else
            printOptions = printOptions.replace(optToRemove, "");
        updateOptions();
	}

	function updateTaxes() {
	    var value = document.getElementById('sel_taxCode').value
	    var name = $("#sel_taxCode option:selected" ).text().trim();
	    if (taxCodes.indexOf(value) == -1) {
	        taxCodes += value + ",";
	        taxNames += name + ",";
	        updateTaxList();
	    }
	}

	function removeTax(index) {
	    var nameToRemove = taxNames.split(",")[index];
	    var codeToRemove = taxCodes.split(",")[index];
        taxNames = taxNames.replace(nameToRemove + ",", "");
        taxCodes = taxCodes.replace(codeToRemove + ",", "");
	    updateTaxList();
	}

	function updateTaxList() {
	    var result = "";
	    var namesArray = taxNames.split(",");
	    var codeArray = taxCodes.split(",");
	    for (i = 0; i < namesArray.length; i++) {
	        if (namesArray[i] != '')
	            result += " " + namesArray[i] + " <img src='../images/Cancel-2.gif' id='img_tax_" + i + "' style='width:15px;height:15px;' onClick='removeTax(" + i + ")' />";
        }

	    document.getElementById('taxList').innerHTML  = result;
	}

	function useDeptTaxList() {
	    taxNames = "";
	    taxCodes = "";
	    <%
	        dim deptTaxQuery, dtResult
	        deptTaxQuery = "select a.description, a.taxCode from Tax a, DepartmentTax b where a.taxCode = b.taxCode and b.departmentId = " & deptId
	        set dtResult = getdisconnectedrecordset(deptTaxQuery)
	        while not(dtResult.eof or dtResult.bof)
	    %>
            taxNames += "<%= dtResult("description") %>,";
            taxCodes += "<%= dtResult("taxCode") %>,";
        <%
		    dtResult.movenext
			wend
        %>
        updateTaxList();
	}

	function useDeptSurList() {
	    var surcharges = "";
	    <%
	        dim deptSurQuery, dsResult
	        deptSurQuery = "select surchargeCode from DepartmentSurcharge where departmentId = " & deptId _
	            & " and priceListId = " + plID
	        set dsResult = getdisconnectedrecordset(deptSurQuery)
	        while not(dsResult.eof or dsResult.bof)
	    %>
            surcharges += "<%= dsResult("surchargeCode") %>,";
        <%
		    dsResult.movenext
			wend
        %>
        if (document.getElementById("chkSur_1")) {
            if (surcharges.indexOf("1,") == -1)
                document.getElementById("chkSur_1").checked = false;
            else
                document.getElementById("chkSur_1").checked = true;
        }

        if (document.getElementById("chkSur_2")) {
            if (surcharges.indexOf("2,") == -1)
                document.getElementById("chkSur_2").checked = false;
            else
                document.getElementById("chkSur_2").checked = true;
        }
	}

	function updateDescr(descrName, descrType) {
		document.editDeptItemForm.action = "editItemDescr.asp?plId=<%=plId%>&deptId=<%=deptId%>&itemID=<%=itemId%>&descrName="
            + descrName + "&descrType=" + descrType + "&fromSrc=editItem";
    	document.editDeptItemForm.submit();
	}

	function showEdit() {
		document.getElementById('editItemTable').style.display = 'block';
		document.getElementById('descTable').style.display = 'none';
	}

	function showDesc() {
		document.getElementById('descTable').style.display = 'block';
		document.getElementById('editItemTable').style.display = 'none';
	}

</SCRIPT>
</head>
<body topmargin=0 leftmargin=0 onload="init(); "><!-- #include file="../include/banner.inc" -->
<H1>Edit Item <%=oldName %></H1><BR/>
<form name="editDeptItemForm" action="" method="post" style="margin:0px" onSubmit="return false">
<INPUT type="hidden" name="oldName" value="<%=oldName%>">

<% if itemId <> "" then %>
	<SPAN style="float:left; padding-left:20px">
		<BUTTON class="rounded" onclick="showEdit()">Edit Item</BUTTON>
		<BUTTON class="rounded" onclick="showDesc()">Show Descriptors</BUTTON>
	</SPAN>
<% end if %>

	<TABLE id="editItemTable" name="editItemTable" ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=1 CELLPADDING=5 style="white-space: nowrap" >
		<tr height=20px></tr>
        <tr>
            <td>Name</td>
            <td><input type="text" id="txt_name" value='<%=d_name%>' maxlength="64"></td>
            <td>Price</td>
            <td><input type="number" step="0.01" id="txt_price" name="txt_price" value='<%=formatnumber(d_price, 2, , , false)%>' min="0" max="1000" onKeyUp="formatAmount(this)" ></td>
         </tr>
        <tr>
            <td>Use Global Days</td>
            <td><INPUT type="checkbox" id="chk_globalDays" name="chk_globalDays" onClick="toggleDays()" <%if d_useGlobalDays then %>checked<% end if %> /></td>
            <td>Days To Process</td>
            <td><input type="number" id="txt_daysToProcess" value='<%= d_daysToProcess%>' min="0" max="100"></td>
         </tr>
        <tr>
            <td>Quantity</td>
            <td><input type="number" id="txt_quantity" value='<%= d_qtyInInventory%>' min="0" max="1000"></td>
            <td>Price Later</td>
            <td><INPUT type="checkbox" id="chk_priceLater" name="chk_priceLater" <%if d_priceLater then %>checked<% end if %> /></td>
         </tr>
        <tr>
            <td>Sales Only</td>
            <td><INPUT type="checkbox" id="chk_saleOnly" name="chk_saleOnly" <%if d_saleOnly then %>checked<% end if %> /></td>
            <td>Outside Service</td>
            <td><INPUT type="checkbox" id="chk_outsideService" name="chk_outsideService" <%if d_outsideService then %>checked<% end if %> /></td>
        </tr>
        <tr>
            <td>Display Sequence</td>
            <td><input type="number" id="txt_displaySeq" value='<%= d_displaySequence%>' min="0" ></td>
            <td>Finish Time</td>
            <td><input type="number" id="txt_finishTime" value='<%= d_finishTime%>' min="0" ></td>
        </tr>
        <tr>
            <td>Split Ticket</td>
            <td><INPUT type="checkbox" id="chk_splitTicket" name="chk_splitTicket" <%if d_splitInvoice then %>checked<% end if %> /></td>
            <td>Use Global Descriptors</td>
            <td><INPUT type="checkbox" id="chk_useGlobalDescr" name="chk_useGlobalDescr" onClick="toggleGlobal()" <%if d_useGlobalDescr then %>checked<% end if %> /></td>
       </tr>
        <tr>
            <td>Discountable</td>
            <td><INPUT type="checkbox" id="chk_discountable" name="chk_discountable" <%if d_discountable then %>checked<% end if %> /></td>
            <td>Coupon</td>
            <td><INPUT type="checkbox" id="chk_couponable" name="chk_couponable" <%if d_couponable then %>checked<% end if %> /></td>
        </tr>
        <tr>
            <td>VIP Discountable</td>
            <td><INPUT type="checkbox" id="chk_vipdiscountable" name="chk_vipdiscountable" <%if d_vipDiscountable then %>checked<% end if %> /></td>
            <td>VIP Qualified</td>
            <td><INPUT type="checkbox" id="chk_vipQualified" name="chk_vipQualified" <%if d_vipQualified then %>checked<% end if %> /></td>
        </tr>
        <tr>
            <td>Prepay Percent</td>
            <td><input type="number" id="txt_pp" value='<%= d_prePayPercent%>' min="0" max="99.99" ></td>
            <td>Prepay Discount</td>
            <td><input type="number" id="txt_pd" step="0.0001" value='<%= d_prePayDiscount%>' min="0" max="99.99" ></td>
        </tr>
        <tr>
            <td>Item Shortcut</td>
            <td><input type="text" id="txt_shortCut" value='<%=d_shortcut%>' maxlength="64"></td>
        </tr>
        <tr>
            <td>Use Global Taxes</td>
            <td><INPUT type="checkbox" id="chk_globalTax" name="chk_globalTax" onClick="toggleTaxes()" <%if d_useGlobalTax then %>checked<% end if %> />
        		<SELECT name="sel_taxCode" id="sel_taxCode" onChange="updateTaxes(this)">
        		    <option value=""></option>
        			<%
                        query2 = "select taxCode, description from Tax "
                        set rs2 = getdisconnectedrecordset(query2)
        				while not(rs2.eof or rs2.bof)
        			%>
        				<OPTION value="<%=rs2("taxCode")%>">
        				<%=Server.HTMLEncode(rs2("description"))%></OPTION>
        			<%
        				rs2.movenext
        				wend
        				set rs2 = nothing
        			%>
        		</SELECT>
            </td>
		    <td colspan=2>Taxes:
		    <div id="taxList"></div>
		    </td>
        </tr>
		<tr>
            <td>Use Global Surcharges</td>
            <td><INPUT type="checkbox" id="chk_globalSur" name="chk_globalSur" onClick="toggleSurcharges()" <%if d_useGlobalSur then %>checked<% end if %> /></td>
            <td colspan="2">Surcharges:<br />

		<%
            query2 = "select name, surchargeCode from Surcharge where priceListid = " & plId
            set rs2 = getdisconnectedrecordset(query2)
			while not(rs2.eof or rs2.bof)
		%>
		    <%=rs2("name")%>
            <INPUT type="checkbox" id="chkSur_<%=rs2("surchargeCode")%>" <% if instr(d_surchargeId, rs2("surchargeCode") & ",") > 0 then %> checked <%end if %>  />
			<%
				rs2.movenext
				wend
				set rs2 = nothing
			%>
			</td>
        </tr>
        <tr>
            <td>Print Notes</td>
            <td><INPUT type="checkbox" id="chk_printNotes" name="chk_printNotes" <%if d_printNotes then %>checked<% end if %> /></td>
            <td>Item Release Form</td>
            <td>
                <SELECT name="sel_formName" id="sel_formName">
                    <option value="">None</option>
                    <%
                        query2 = "select formName from Form "
                        set rs2 = getdisconnectedrecordset(query2)
                        while not(rs2.eof or rs2.bof)
                    %>
                        <OPTION value="<%=rs2("formName")%>"
                        <% if Not IsNull(d_formName) then
                            if cstr(rs2("formName")) = cstr(d_formName) then %>
                                selected
                        <%
                            end if
                         end if
                         %>
                        >
                        <%=Server.HTMLEncode(rs2("formName"))%></OPTION>
                    <%
                        rs2.movenext
                        wend
                        set rs2 = nothing
                    %>
                </SELECT>
            </td>
        </tr>
        <tr>
            <td colspan="1">Options for Item Note</td>
            <td colspan="1">
                <input type="text" id="txt_option" size="20" maxlength="20">
                <INPUT type="button" value="Add" onclick="addOption()" />
           </td>
            <td colspan="1">Prompt for Item Note</td>
            <td colspan="1"><input type="text" id="txt_prompt" value='<%= d_prompt%>' size="20" maxlength="120" ></td>
        </tr>
        <tr>
		    <td colspan=4>
		    <div id="printOptList"></div>
		    </td>
        </tr>
        <tr>
            <td style="vertical-align: top">Item Notes</td>
            <td colspan="3"> <textarea rows=5 cols="50" maxlength="1024" id="txt_notes"><%=d_notes%></textarea></td>
        </tr>
		<tr height=10px><td></td></tr>

        <% if itemId <> "" then %>
		<tr><td></td>
			<TD colspan="3">Save
                <SELECT name="saveOptionSel" id="saveOptionSel">
                <option value="0">This Item (<%=d_name%>)</option>
                <option value="1">All (<%=d_name%>)'s in this pricelist</option>
                <option value="2">All (<%=d_name%>)'s in all pricelists</option>
			</td>
		</tr>
		<% end if %>
		<tr>
			<TD colspan="3">
				<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick= "save()">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton style="background-image:url(../images/Cancel.gif)" type=button value="" onClick="cancelForm()">
						</TD>
					</tr>
				</table>
			</TD>
		</tr>
    </table>


    <div id="descTable" style="display:none">
    <br /><br /><br />
    <TABLE ALIGN=center WIDTH="750px" BORDER=0 CELLSPACING=1 CELLPADDING=5  style="border: 1px solid black;">
        <tr>
            <td><h3>Unique</h3></td>
            <td style="text-align: right" colspan="4"><h4>Upcharges, Colors, & Patterns</h4></td>
        </tr>
        <tr height=50px></tr>
        <tr>
                <%
                    if itemId <> "" then
                        query2 = "select priceListItemId Id, descriptorName name, descriptorType type " _
                            & "from ItemDescriptorPrice where priceListItemId = " & itemId & " and disabled = 0 " _
                            & "order by descriptorType, displaySequence"
                        set rs2 = getdisconnectedrecordset(query2)
                        cnt = 0
                        while not(rs2.eof or rs2.bof)
                        cnt = cnt + 1
                %>
                    <td><a href="#" onclick="updateDescr('<%= rs2("name") %>', '<%= rs2("type") %>'); return false;"><%= rs2("name") %></a>
                    <%if rs2("type") = "CO" then %>
                    (Color)
                    <%elseif rs2("type") = "PA" then %>
                    (Pattern)
                    <%elseif rs2("type") = "UP" then %>
                    (Upcharge)
                    <%elseif rs2("type") = "BR" then %>
                    (Brand)
                    <% end if %>
                    </td>
                <% if cnt mod 3 = 0 then %>
                </tr><tr>
                <% end if %>
                <%
                        rs2.movenext
                        wend
                        set rs2 = nothing
                    end if
                %>
		<tr height=30px></tr>
    </table>

    <br /><br /><br />
    <TABLE ALIGN=center WIDTH="750px" BORDER=0 CELLSPACING=1 CELLPADDING=5 id="globalDescrTable"
        style="border: 1px solid black;<% if not d_useGlobalDescr then %> visibility: hidden <% end if %>">
    		<tr>
    		    <td><h3>Inherited from Global</h3></td>
    		    <td style="text-align: right" colspan="4"><h4>Upcharges, Colors, & Patterns</h4></td>
    		</tr>
    		<tr>
                <%
                    query2 = "select priceListItemId Id, descriptorName name, descriptorType type " _
                        & "from ItemDescriptorPrice where priceListItemId = 0 and disabled = 0 " _
                        & "order by descriptorType, displaySequence"
                    set rs2 = getdisconnectedrecordset(query2)
                    cnt = 0
                    while not(rs2.eof or rs2.bof)
                        cnt = cnt + 1
                %>
                    <td><%= rs2("name") %>
                    <%if rs2("type") = "CO" then %>
                    (Color)
                    <%elseif rs2("type") = "PA" then %>
                    (Pattern)
                    <%elseif rs2("type") = "UP" then %>
                    (Upcharge)
                    <%elseif rs2("type") = "BR" then %>
                    (Brand)
                    <% end if %>
                    </td>
                <% if cnt mod 3 = 0 then %>
                </tr><tr>
                <% end if %>
                <%
                    rs2.movenext
                    wend
                    set rs2 = nothing
                %>
		<tr height=30px></tr>
    </table>
    <br /></br /><br /><br />
</div>
</form>

</body>
</html>
