<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim query, rs
	dim discountID
	
	
	discountID = Request.QueryString("discountID")
	if discountID = "" then
		discountID = Request.Form("discountID")
	end if
	
	
	select case lcase(Request.QueryString("userAction"))
		case "addrange"
			query = "insert into DiscountValidRange (DiscountID, BeginRange, EndRange, ValidSun, ValidMon, ValidTue, ValidWed, ValidThu, ValidFri, ValidSat) "
			query = query & " values( "
			query = query & discountID
			query = query & ", " & Request.QueryString("rangeBegin")
			query = query & ", " & Request.QueryString("rangeEnd")
			query = query & ", " & TF210(Request.QueryString("sun"))
			query = query & ", " & TF210(Request.QueryString("mon"))
			query = query & ", " & TF210(Request.QueryString("tue"))
			query = query & ", " & TF210(Request.QueryString("wed"))
			query = query & ", " & TF210(Request.QueryString("thu"))
			query = query & ", " & TF210(Request.QueryString("fri"))
			query = query & ", " & TF210(Request.QueryString("sat"))
			query = query & ")"
			qryexecute query
			
		case "removerange"
			query = "delete DiscountValidRange where id = " & Request.QueryString("id")
			qryexecute query
	end select


	function TF210(value)
		if lcase(value) = "true" then
			TF210 = 1
		else
			TF210 = 0
		end if
	end function
	
	function timeForHour(hour24)
		dim ampm
		dim hour
		
		if hour24 >= 12 then
			hour = hour24 - 12
			ampm = "PM"
		else
			hour = hour24
			ampm = "AM"
		end if
		if hour = 0 then
			hour = 12
		end if
		
		timeForHour = hour & ":00 " & ampm
	end function
	
	function d_timeRange(start, selected)
		dim index
		dim isselected

		for index = start to 23
			
			if index = selected then
				isselected = "SELECTED "
			else
				isselected = ""
			end if
			
			Response.Write "<OPTION " & isselected & "VALUE=" & index & ">" & timeForHour(index) & "</OPTION>"
		next
	end function
%>

<HTML>
<HEAD>
<TITLE>Gift Card Program</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

<style type="text/css">

table.rtable  {
	padding:5px;
	background:white;
	width:500px;
	border:2px solid #CCC;
	border-bottom:10px solid #CCC;
}

table.rtable td {
	border-bottom:2px solid #CCC;
}

</style>

</HEAD>
<script language="javascript" type="text/javascript">
	function addNewRange(range_begin, range_end, day_sun, day_mon, day_tue, day_wed, day_thu, day_fri, day_sat) {
		document.discountTime.action =
		"?userAction=addRange" +
		"&rangeBegin=" + range_begin +
		"&rangeEnd=" + range_end +
		"&sun=" + day_sun +
		"&mon=" + day_mon +
		"&tue=" + day_tue +
		"&wed=" + day_wed +
		"&thu=" + day_thu +
		"&fri=" + day_fri +
		"&sat=" + day_sat;
		
		
		document.discountTime.submit();
	}
	
	function removeRange(id) {
		document.discountTime.action =
		"?userAction=removeRange" +
		"&id=" + id
		document.discountTime.submit();
	
	}
	
	function done() {
<%
	query = "select * from discount where discountid = " & discountID
	set rs = getdisconnectedrecordset(query)
	
	if rs.recordcount > 0 then
	
		select case lcase(rs("discounttype"))
			case "cu"
%>
		document.discountTime.action = "AddCoupons.asp?addOrEdit=edit&priceListId=<%=rs("pricelistid")%>&couponId=<%=rs("discountid")%>"
<%
			case "pr"
%>
		document.discountTime.action = "Promotion.asp?addOrEdit=edit&priceListId=<%=rs("pricelistid")%>&couponId=<%=rs("discountid")%>"
<%
		end select
		set rs = nothing
	end if
%>
		document.discountTime.submit();
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Discount Time</H1>
<FORM id="discountTime" name="discountTime" action="start2.asp" method="Post">
<INPUT id="discountID" name="discountID" TYPE=hidden VALUE="<%=discountID%>">
<CENTER>

	<TABLE class=rtable cellspacing=0 cellpadding=0 border=0>
	
	    <TR>
	       <TD colspan=3>Select</TD>
	    </TR>
		<TR><TD>

		<SELECT NAME='RANGE_BEGIN'>
		<%d_timeRange 0, 0%>
		</SELECT>
		TO
		<SELECT NAME='RANGE_END'>
		<%d_timeRange 0, 0%>
		</SELECT>
				
		</TD><TD>

		S<INPUT NAME='DAY_SUN' TYPE=checkbox checked></INPUT>
		M<INPUT NAME='DAY_MON' TYPE=checkbox checked></INPUT>
		T<INPUT NAME='DAY_TUE' TYPE=checkbox checked></INPUT>
		W<INPUT NAME='DAY_WED' TYPE=checkbox checked></INPUT>
		T<INPUT NAME='DAY_THU' TYPE=checkbox checked></INPUT>
		F<INPUT NAME='DAY_FRI' TYPE=checkbox checked></INPUT>
		S<INPUT NAME='DAY_SAT' TYPE=checkbox checked></INPUT>
		
		</TD><TD>

		<INPUT TYPE=button VALUE='Add'
		 ONCLICK='addNewRange(
		RANGE_BEGIN.value,
		RANGE_END.value,
		DAY_SUN.checked,
		DAY_MON.checked,
		DAY_TUE.checked,
		DAY_WED.checked,
		DAY_THU.checked,
		DAY_FRI.checked,
		DAY_SAT.checked
		);'></INPUT>
				
		</TD></TR>
	</TABLE>

<TABLE class=rtable cellspacing=0 cellpadding=0 border=0>
<%

	if discountID <> "" then
	
	query = "select * from DiscountValidRange where discountID = " & discountID
	set rs = getdisconnectedrecordset(query)

	
	while not (rs.eof or rs.bof)


%>


		<TR><TD style="font-size:15">


		<%=timeForHour(rs("BeginRange"))%> To <%=timeForHour(rs("EndRange"))%>
				
		</TD><TD valign=center>

		<span style="text-align:center;width:20px;height:20px;background:<%if rs("ValidSun") then%>#2F2<%else%>#F22<%end if%>">S</span>
		<span style="text-align:center;width:20px;height:20px;background:<%if rs("ValidMon") then%>#2F2<%else%>#F22<%end if%>">M</span>
		<span style="text-align:center;width:20px;height:20px;background:<%if rs("ValidTue") then%>#2F2<%else%>#F22<%end if%>">T</span>
		<span style="text-align:center;width:20px;height:20px;background:<%if rs("ValidWed") then%>#2F2<%else%>#F22<%end if%>">W</span>
		<span style="text-align:center;width:20px;height:20px;background:<%if rs("ValidThu") then%>#2F2<%else%>#F22<%end if%>">T</span>
		<span style="text-align:center;width:20px;height:20px;background:<%if rs("ValidFri") then%>#2F2<%else%>#F22<%end if%>">F</span>
		<span style="text-align:center;width:20px;height:20px;background:<%if rs("ValidSat") then%>#2F2<%else%>#F22<%end if%>">S</span>


		</TD><TD>
			<INPUT TYPE=button VALUE='Remove'
			 ONCLICK='removeRange(<%=rs("ID")%>);'></INPUT>
		</TD></TR>
<%

		rs.movenext
	wend
	
	set rs = nothing
	
	end if
%>
</TABLE>

	<INPUT TYPE=button VALUE='Done' style="width:80px;height:50px;margin-top:30px" ONCLICK='done();'></INPUT>
			 
</CENTER>
</FORM>   
</BODY>
</HTML>
