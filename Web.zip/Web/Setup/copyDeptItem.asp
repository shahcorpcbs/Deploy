<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs, query2, rs2, query3, rs3
    dim plId, deptId, copyPlId, copyDeptId, copyItemId

    plId = trim(getReqVar("plID"))
    deptId = trim(getReqVar("deptId"))
    copyPlId = trim(getReqVar("copyPlId"))
    copyDeptId = trim(getReqVar("copyDeptId"))

    if copyPlId = "" then
        copyPLId = plId
        copyDeptId = deptId
    end if


	if trim(Request.QueryString("useraction")) = "submit" then
		SaveFormData()
	end if

    query = "select name, priceListid from priceList"
    set rs = getdisconnectedrecordset(query)

    if copyPlId <> "" then
        query2 = "select name, departmentId from department where priceListId = " & copyPlId
        set rs2 = getdisconnectedrecordset(query2)
    end if

    if copyDeptId <> "" then
        query3 = "select itemName, priceListItemId, price from PriceListItem where priceListId = " & copyPlId & " and departmentId = " & copyDeptId
        set rs3 = getdisconnectedrecordset(query3)
    end if


    function SaveFormData()

        dim name, copyItemId, newItemId, newPrice
		name = trim(Request.QueryString("name"))
		newPrice = trim(Request.QueryString("newPrice"))
		copyItemId = trim(Request.QueryString("copyItemId"))

            query = "SET NOCOUNT ON; Insert into PriceListItem(departmentId, priceListId, itemName, commonItem, price, " _
                & "disabled, useGlobalTax, useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, " _
                & "outsideService, saleOnly, splitInvoice, qtyInInventory, itemCost, prePayPercent, displaySequence, " _
                & "daysToProcess, imageFileName, itemReleaseInvoiceFormName, notes, printNotes, useCounter, itemShortcut, "_
                & "priceLater, InventoryQuantity, prompt, options, finishTime, prepayDiscount, useGlobalDescr) "_
                & "(select " & deptId & ", " & plId & ", '" & DBStr(name) & "', commonItem, '" & newPrice & "', disabled, "_
                & "useGlobalTax, useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, "_
                & "outsideService, saleOnly, splitInvoice, qtyInInventory, itemCost, prePayPercent, displaySequence, " _
                & "daysToProcess, imageFileName, itemReleaseInvoiceFormName, notes, printNotes, useCounter, itemShortcut, " _
                & "priceLater, InventoryQuantity, prompt, options, finishTime, prepayDiscount, useGlobalDescr from PriceListItem " _
                & "where priceListItemId = " & copyItemId & "); SELECT SCOPE_IDENTITY(); SET NOCOUNT OFF;"
		    DbStartTrans()
                newItemId = QryExecuteWithTransAndSelect(query)
            DbEndTrans

                 query = "Insert into ItemDescriptorPrice(priceListItemId, descriptorName, descriptorType, price, " _
                    & "disabled, useGlobalTax, useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, " _
                    & "outsideService, prePayPercent, displaySequence, daysToProcess, imageFileName, notes, " _
                    & "printNotes, UseCounter, prepayDiscount) " _
                    & "(select " & newItemId & ", c.descriptorName, c.descriptorType, c.price,  "_
                    & "c.disabled, c.useGlobalTax, c.useGlobalDays, c.discountable, c.VIPDiscountable, c.VIPQualified, c.couponable, " _
                    & "c.outsideService, c.prePayPercent, c.displaySequence, c.daysToProcess, c.imageFileName, c.notes, " _
                    & "c.printNotes, c.UseCounter, c.prepayDiscount " _
                    & "from ItemDescriptorPrice c where c.priceListItemId = " & copyItemId & " )"
                 qryexecute query


                 query = "Insert into ItemDescriptorTax(priceListItemId, descriptorName, descriptorType, taxCode, storeId) " _
                     & "(select " & newItemId & ", c.descriptorName, c.descriptorType, c.taxCode, c.storeId from "_
                     & " ItemDescriptorTax c where c.priceListItemId = " & copyItemId & " )"
                 qryexecute query


                 query = "Insert into itemDescriptorSurcharge(priceListItemId, descriptorName, descriptorType, surchargeCode, priceListId) " _
                     & "(select " & newItemId & ", c.descriptorName, c.descriptorType, c.surchargeCode, " & plId & " from "_
                     & "itemDescriptorSurcharge c where c.priceListItemId = " & copyItemId & " )"
                 qryexecute query


                 query = "Insert into itemTax(priceListItemId, taxCode, storeId) " _
                     & "(select " & newItemId & ", c.taxCode, c.storeId from "_
                     & "itemTax c where c.priceListItemId = " & copyItemId & " )"
                 qryexecute query


                 query = "Insert into itemSurcharge(priceListItemId, surchargeCode, priceListId) " _
                     & "(select " & newItemId & ", c.surchargeCode, " & plId & " from "_
                     & "itemSurcharge c where c.priceListItemId = " & copyItemId & " )"
                 qryexecute query


        response.redirect "priceListDeptsList.asp?plId=" & plId & "&expandedDept=" & deptId
    end function

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
%>

<html>
<head>
<title>Copy Department Item</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</head>
<script language="javascript" type="text/javascript">

    function submitForm() {
        if (document.getElementById('copyPlId').value == -1) {
            cbs_alert("Select a Price List");
            return;
        }
        if (document.getElementById('copyDeptId').value == -1) {
            cbs_alert("Select a Department");
            return;
        }
        var name = $.trim(document.getElementById('nameText').value);
        if (name === "") {
            cbs_alert("Cannot set a blank item name");
            return;
        }
        var newPrice = $.trim(document.getElementById('newPrice').value);
        if (newPrice === "") {
            cbs_alert("Cannot set a blank price");
            return;
        }

        document.copyItemDeptForm.action = "?useraction=submit" +
            "&plId=<%=plId%>&deptId=<%=deptId%>" +
	        "&name=" + encodeURIComponent(name) +
	        "&newPrice=" + encodeURIComponent(newPrice) +
            "&copyPlId=<%=copyPLId%>" +
            "&copyDeptId=<%=copyDeptId%>" +
            "&copyItemId=" + encodeURIComponent(document.getElementById('copyItemId').value);
        document.copyItemDeptForm.submit();
    }

    function changePriceList() {
        if (document.getElementById('copyPlId').value == -1)
            return;

        document.copyItemDeptForm.action = "?useraction=update" +
            "&plId=<%=plId%>&deptId=<%=deptId%>" +
            "&copyPlId=" + encodeURIComponent(document.getElementById('copyPlId').value);
        document.copyItemDeptForm.submit();
    }

    function changeDept() {
        if (document.getElementById('copyPlId').value == -1)
            return;
        if (document.getElementById('copyDeptId').value == -1)
            return;

        document.copyItemDeptForm.action = "?useraction=update" +
            "&plId=<%=plId%>&deptId=<%=deptId%>" +
            "&copyPlId=" + encodeURIComponent(document.getElementById('copyPlId').value) +
            "&copyDeptId=" + encodeURIComponent(document.getElementById('copyDeptId').value);
        document.copyItemDeptForm.submit();
    }

	function formatAsMoney(mnt)
	{
		mnt -= 0;
		mnt = (Math.round(mnt*100))/100;
		return (mnt == Math.floor(mnt)) ? mnt + '.00' : ( (mnt*10 == Math.floor(mnt*10)) ? mnt + '0' : mnt);
	}

    function changeName() {
        var selectBox = document.getElementById("copyItemId");
        var element = selectBox.options[selectBox.selectedIndex];
        if (element) {
            document.getElementById('nameText').value = element.text;
            document.getElementById('newPrice').value = formatAsMoney(element.getAttribute("price"));
        }

    }

    function cancelForm() {
        document.copyItemDeptForm.action = "priceListDeptsList.asp?plID=<%=plID%>&expandedDept=<%=deptId%>";
        document.copyItemDeptForm.submit();
    }

</SCRIPT>
<body topmargin=0 leftmargin=0 onLoad="changeName()" ><!-- #include file="../include/banner.inc" -->
<H1>Copy Item</H1><BR/><BR/>
<form name="copyItemDeptForm" action="" method="post" style="margin:0px" >
	<TABLE ALIGN=center WIDTH="500px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px></tr>
        <tr style="text-align: left">
            <th>Price List</th>
            <th>Department</th>
            <th>Item</th>
        </tr>
    <td>
		<SELECT name="copyPlId" id="copyPlId" onChange="changePriceList()">
		    <option value="-1">Select</option>
			<%
				while not(rs.eof or rs.bof)
			%>
				<OPTION value="<%=rs("priceListId")%>"
				<% if cstr(rs("priceListId")) = cstr(copyPLId) then %>
				    selected
				<% end if %>
				>
				<%=Server.HTMLEncode(rs("name"))%></OPTION>
			<%
					rs.movenext
				wend
				set rs = nothing
			%>
		</SELECT>
    </td>
    <td>
		<SELECT name="copyDeptId" id="copyDeptId" onChange="changeDept()">
		    <option value="-1">Select</option>
			<%
			    if query2 <> "" then
				    while not(rs2.eof or rs2.bof)
			%>
				<OPTION value="<%=rs2("departmentId")%>"
				<% if cstr(rs2("departmentId")) = cstr(copyDeptId) then %>
				    selected
				<% end if %>
				>
				<%=Server.HTMLEncode(rs2("name"))%></OPTION>
			<%
                    rs2.movenext
                    wend
                    set rs2 = nothing
				end if
			%>
		</SELECT>
    </td>
    <td>
		<SELECT name="copyItemId" id="copyItemId" onChange="changeName()">
			<%
			    if query3 <> "" then
				    while not(rs3.eof or rs3.bof)
			%>
				<OPTION value="<%=rs3("priceListItemId")%>" price="<%=rs3("price")%>">
				<%=Server.HTMLEncode(rs3("itemName"))%></OPTION>
			<%
                    rs3.movenext
                    wend
                    set rs3 = nothing
				end if
			%>
		</SELECT>
    </td>
    </tr>
		<tr  <% if query3 = "" then %> style="visibility:hidden;" <% end if %>>
		    <td>New Item Name</td>
            <td><input type="text" id="nameText" ></td>
        </td></tr>
		<tr  <% if query3 = "" then %> style="visibility:hidden;" <% end if %>>
		    <td>New Item Price</td>
            <td><input type="number" id="newPrice" ></td>
        </td></tr>
        <tr height=50px></tr>
		<tr>
			<TD>
				<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick= "submitForm()">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton style="background-image:url(../images/Cancel.gif)" type=button value="" onClick="cancelForm()">
						</TD>
					</tr>
				</table>
			</TD>
		</tr>
</table>


</form>

</body>
</html>
