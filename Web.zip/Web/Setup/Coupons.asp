<%@ Language=VBScript %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitFormCouponSetup() {
		document.coupons.action = "discountlist.asp?discounttype=cu";
		document.coupons.submit();
	}
	function submitFormPromotionSetup() {
		document.coupons.action = "discountlist.asp?discounttype=pr";
		document.coupons.submit();
	}
	function submitFormLoyaltyGift() {
		document.coupons.action = "LoyaltyGift.asp";
		document.coupons.submit();
	}
	function submitFormVIPDiscountSetup() {
		document.coupons.action = "VIpDiscount.asp";
		document.coupons.submit();
	}
	function submitFormReferalSetup() {
		document.coupons.action = "Referal.asp";
		document.coupons.submit();
	}
	function submitFormDemandCouponSetup() {
		document.coupons.action = "OnDemandCoupon.asp";
		document.coupons.submit();
	}
	function cancelForm() {
		document.coupons.action = "MainSetUp.asp";
		document.coupons.submit();
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Coupons and Promotions</H1>
<FORM id="coupons" action = "MainSetUp.asp" name="coupons" method ="POST">
<CENTER>
<TABLE WIDTH = "400px" BORDER=0 CELLSPACING=0 CELLPADDING=10>
	<tr>
	<td align=center valign=top>
	<TABLE WIDTH="100%" BORDER= 0 CELLSPACING=0 CELLPADDING=0>
	<TBODY>
	<tr colspan= "2">
		<td align=left >
        <BUTTON class=std style="width:200px;height:100px;font-size:12px"  name=coupon1 onClick="submitFormCouponSetup()">Coupon</button></td>
		<td align=left >
		<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=promotion1 onClick="submitFormPromotionSetup()" >Promotion</button>
		</td>
		<td align=left >
		<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=ondemand onClick="submitFormDemandCouponSetup()">Demand Coupon</button>
		</td></tr>

	<tr colspan= "2">
		<td align=left >
		<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=vip onClick="submitFormVIPDiscountSetup()">VIP</button>
		</td>
		<td align=left >
		<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=referal onclick="submitFormReferalSetup()">Referral</button>
		</td>
		<td align=left >
		<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=loyalty onClick="submitFormLoyaltyGift()" >Loyalty / Gift Card</button>
		</td>
	</tr>	
	
	</TBODY></TABLE>
	
	<BR><BR>
		<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
	</td></tr>
	</td></tr>
	</CENTER>
	</TABLE>
</FORM>
</BODY>
</HTML>
