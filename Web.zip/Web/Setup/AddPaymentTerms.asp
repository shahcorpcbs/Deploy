<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim isSubmitted 
	dim l_storeid
	dim sqltxt 
	dim actionstring	
	dim l_discountdays
	dim l_discountpercent
	dim l_daysPastDue
	
	
	dim termName
	dim termTerms
	dim termRate
	dim termDays
	dim termCharges
	
	isSubmitted = Request.QueryString("submitted")
	l_storeid = session("StoreID")
	l_storeid = 1
	
	
	select case lcase(Request.QueryString("mode"))
	case "edit"
		loadTermsFromID Request.QueryString("termsid")
	case "add"
		loadTermsDefault
	end select
	
	if (isSubmitted ) then
		if not isnull(l_storeid) and l_storeid <> "" then
			
			select case lcase(Request.QueryString("mode"))
			case "edit"
				dbstartTrans()
				sqltxt = "update PaymentTermsDomain set " _
						 & "paymentname=" & dbcreateqrystring(Request.Form("txtname")) _
						 & ",discountdays=" & dbcreateqryNumeric(Request.Form("txtdays")) _
						 & ",discountpercent=" & dbcreateqryNumeric(Request.Form("txtrate")) _
						 & ",dayspastdueforfc=" & dbcreateqryNumeric(Request.Form("txtdayspastdue")) _
						 & ",terms=" & dbcreateqrystring(Request.Form("txtterm")) _
						 & " where paymentTermsID = " & Request.QueryString("termsid")
						' Response.Write sqltxt
				QryExecuteWithTrans(sqltxt)
				DbEndTrans()
			case "add"
				dbstartTrans()
				sqltxt = "insert PaymentTermsDomain (storeid,paymentname,discountdays,discountpercent,dayspastdueforfc,terms) values (" _
						 &		l_storeid _
						 & "," & dbcreateqrystring(Request.Form("txtname")) _
						 & "," & dbcreateqryNumeric(Request.Form("txtdays")) _
						 & "," & dbcreateqryNumeric(Request.Form("txtrate")) _
						 & "," & dbcreateqryNumeric(Request.Form("txtdayspastdue")) _
						 & "," & dbcreateqrystring(Request.Form("txtterm")) _
						 & " )"
						' Response.Write sqltxt
				QryExecuteWithTrans(sqltxt)
				DbEndTrans()
			end select
	

			
			
			
		end if
	end if
	

	actionstring= Request.QueryString("userAction")
	if ( not isnull(actionstring) and actionstring <> "") then
		Response.Redirect(actionstring)
	end if

	sub loadTermsDefault()
	
	end sub
	
	
	sub loadTermsFromID(id)
		dim query, rs
		query = "select * from paymenttermsdomain where paymentTermsID = " & id
		set rs = getdisconnectedrecordset(query)
		
		termName = rs("paymentName")
		termTerms = rs("terms")
		termRate = rs("discountPercent")
		termDays = rs("discountDays")
		termCharges = rs("daysPastDueForFC")
	end sub
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
		
	function submitForm() {
		if (trim(document.addpaymentterm.txtname.value) =="") {
			alert("Name is a required field");
			document.addpaymentterm.txtname.focus();
		}
		else{
		document.addpaymentterm.action =document.addpaymentterm.action + "?Submitted=true&mode=<%=Request.Querystring("mode")%>&termsid=<%=Request.QueryString("termsid")%>&userAction=" + "PaymentTerms.asp";
		document.addpaymentterm.submit();

	}
	}
	
	function validateDiscount(element){
		if ( ! isNum1(element.value, 0)){
			alert("Please enter a decimal value ");
			element.focus();
		}
	}				
	
	
	function validateTerm(element){
		if ( !checkInt(element.value)){
			alert("Please enter a Numeric value ");
			element.focus();
		}
	}		
	
	function cancelForm(){
		document.addpaymentterm.action = "CustomerSetup.asp";
		document.addpaymentterm.submit();
		
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Add Payment Terms</H1>
<FORM id="addpaymentterm" name="addpaymentterm" action="" Method = "post">

<TABLE WIDTH="350" BORDER=2 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT: 50px"><!-- header row -->
<TBODY>
 <tr>
	<td align=left valign=top>
	<TABLE border="0" cellpadding="0" cellspacing="0" Style = "MARGIN-LEFT: 8px">
	<tr><td> <br>
	<TABLE border="0" cellpadding="5" cellspacing="0">
	<tr>
		<td width = 100px><B><b><font color=red>Name</font></td>
		<TD><INPUT Class = text name="txtname" maxlength = 64 value="<%=termName%>"></TD>
	</tr>
	<tr>
		<td colspan=2><B><font color=red>Terms<font color=black></b>&nbsp;&nbsp;Enter 1 (1 month), 30 (30 days)</font></td>
	<tr>
		<td></tr><TD><INPUT Class = text name="txtterm" onblur = validateTerm(this) value="<%=termTerms%>"></TD>
	</tr></tr>
	<tr>
		<td><b>Discount Rate</td>
		<TD><INPUT Class = text name="txtrate" onblur = validateDiscount(this) value="<%=termRate%>"></TD>
	</tr>
	<tr>
		<td width = 120px ><b>Discount Days</td>
		<TD><INPUT Class = text name="txtdays" onblur = validateTerm(this) value="<%=termDays%>"></TD>
	</tr>
	<tr>
		<td><font Color=red>* Required Fields
	</tr>
	</table>
	</td>
	</TR>
	<tR><td align = center><br>
		<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif);background-position=center"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
		<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);background-position=center" onClick="history.back(-1)">
	 </td></tr>
	 </table><br>
	 </td></tr>
	 </TBODY>
	</TABLE>
	</FORM>
		
</BODY>
</HTML>
