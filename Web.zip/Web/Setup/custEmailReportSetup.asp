<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/ValidateFunction.asp"-->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	if trim(Request.QueryString("userAction")) = "del" then
	    query = "Update EmailCustomerSchedule set Active = 0, Deleted = 1 where Id = " & Request.QueryString("schId")
	    qryexecute query
	end if

%>

<HTML>
<HEAD>
<TITLE>Customer Email Setup</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script type="text/javascript">
	var previousElement = null;
	var selectedId = null;


	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}
		selectedId = element.getAttribute("schId");

		previousElement = element;

		element.className = "selected";
	}

	function exit() {
        document.custEmailSch.action = "/MainApp/marketingMenu.asp";
        document.custEmailSch.submit();
	}

	function addMessage() {
        document.custEmailSch.action = "/setup/editCustReportSch.asp?addoredit=add";
        document.custEmailSch.submit();
	}

	function editMessage() {
		if(selectedId != null) {
            document.custEmailSch.action = "/setup/editCustReportSch.asp?addoredit=edit&schId="  + selectedId;
            document.custEmailSch.submit();
		}
		else
		    cbs_alert("Select a report to edit");
	}

	function deleteMessage() {
		if(selectedId != null) {
		    cbs_confirm("Are you sure you want to delete this schedule?", realDelete)
		}
		else
		    cbs_alert("Select a report to delete");
	}

	function realDelete() {
        document.custEmailSch.action = "?userAction=del&schId=" + selectedId;
        document.custEmailSch.submit();
	}

	function runMessage() {
		if(selectedId != null) {
            document.custEmailSch.action = "/mainapp/runCustEmailReport.asp?from=schedule&schId=" + selectedId;
            document.custEmailSch.submit();
        }
		else
		    cbs_alert("Select a report to run");
	}

</script>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Customer Email From Query Setup</H1><BR/><BR/>

<FORM name="custEmailSch" ID="custEmailSch" METHOD=POST  style="margin:0;padding:0" onsubmit="return false">

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="addMessage()">Add</BUTTON>
		<BUTTON onclick="editMessage()">Edit</BUTTON>
		<BUTTON onclick="deleteMessage()">Delete</BUTTON>
		<BUTTON onclick="runMessage()">Run Now</BUTTON>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>

<DIV style="overflow:scroll; height: 590px">
<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH>Job Name</TH>
		<TH>Report Name</TH>
		<TH>Subject</TH>
		<TH>Active</TH>
		<TH>Frequency</TH>
		<TH>Report Format</TH>
		<TH>Form Name</TH>
	</TR>
	<%
        query = "select e.Id, e.reportId, e.userQueryId, e.subject, e.active, e.Frequency, e.sendAsAttachment, e.name,  " _
            & "e.formatType, hf.name formName from EmailCustomerSchedule e left join HtmlForm hf on e.formId = hf.formId " _
            & " where e.Deleted = 0"
        set rs = getdisconnectedrecordset(query)
		while not(rs.eof or rs.bof)
	%>
	<TR onclick="selectRow(this)" schId="<%=rs("id")%>" >
	    <td><%=rs("name")%></td>
	    <td>
            <% if rs("userQueryId") <> "" then
                dim query2, rs2
                query2 = "select name from UserQuery where userQueryId = " & rs("userQueryId")
                set rs2 = getdisconnectedrecordset(query2)%>
                <%= rs2("name") %>

            <% else
                    if rs("reportId") = "25" then %>
                    AR Statement
                    <% else %>
                    AR Multi-Pickup Statement
                    <% end if
            end if %>
	    </td>
	    <td><%=rs("subject")%></td>
        <td>
            <% if rs("active") then %>
                Active
            <% else %>
                Inactive
            <% end if %>
        </td>
        <td>
            <% if rs("frequency") = 0 then %>
                Manual Only
            <% Elseif rs("frequency") = 1 then %>
                Once
            <% ElseIf rs("frequency") = 4 Then %>
                Hourly
            <% ElseIf rs("frequency") = 2 Then %>
                Daily
            <% ElseIf rs("frequency") = 5 Then %>
                Weekly
            <% else %>
                Monthly
            <% end if %>
        </td>
        <td>
            <% if rs("formatType") = 1 then %>
                HTML
            <% Elseif rs("formatType") = 2 then %>
                CSV
            <% ElseIf rs("formatType") = 3 Then %>
                PDF
            <% end if %>
        </td>
        <td>
            <%= rs("formName") %>
        </td>

	</TR>
	<%
		rs.movenext
		wend
		set rs = nothing
	%>
</TABLE>
</DIV>
</FORM>
</BODY>
</HTML>

