<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim device
	dim wwwTools, regTools
	dim ssql
	dim cameraList
	dim cameraName, cameraURL, cameraDefault
	dim userAction
	dim associatedTerminalID
	
	device = Trim(Request.QueryString("device"))
	userAction = Trim(Request.QueryString("action"))

	associatedTerminalID = Trim(Request.QueryString("terminalID"))
	if associatedTerminalID = "" then
		associatedTerminalID = Trim(Request.Form("terminalID"))
		
		if associatedTerminalID = "" then
			associatedTerminalID = Session("terminalID")
		end if
	end if
	
	cameraName = ""
	cameraURL = ""
	cameraDefault = false


	select case userAction
		case "submit"
			submitCameraToDatabase
		case "remove"
			removeCameraFromDatabase
	end select
	
	sub submitCameraToDatabase()
		dim defString
		dim nCameraName
		dim nCameraURL
		dim nCameraDefault
		
		nCameraName = Request.Form("txCameraName")
		nCameraURL = Request.Form("txCameraURL")
		nCameraDefault = ""

		if Request.Form("ckCameraDefault") = "on" then
			nCameraDefault = "default"
		end if


		if device = "new" then
			ssql = "INSERT INTO StoreHardware (terminalID, hardwareName, hardwareType, brand, model) VALUES ('" & associatedTerminalID & "', '" & nCameraName & "', 'IC',  '" & nCameraURL & "', '" & nCameraDefault & "')"
		else
			if device <> "" then
				ssql = "UPDATE StoreHardware SET terminalID='" & associatedTerminalID & "', hardwareName='" & nCameraName & "', brand ='" & nCameraURL & "', model='" & nCameraDefault & "' WHERE hardwareID='" & device & "'"
			else
				ssql = ""
			end if
		end if

		QryExecute(ssql)
		
		Response.Redirect "/setup/Hardware.asp"
	end sub
	
	sub removeCameraFromDatabase()
		if device <> "" and device <> "new" then
			ssql = "DELETE FROM StoreHardware WHERE hardwareType='IC' AND hardwareID='" & device & "'"
			device = ""
			QryExecute(ssql)
		end if
	end sub
	
	
	if device <> "" and device <> "new" then
		ssql = "SELECT terminalID, hardwareName, brand, model from StoreHardware where hardwareType = 'IC' and hardwareID = '" & device & "'"
		set cameraList = getDisconnectedRecordset(ssql)		

		if not cameraList.EOF then
			cameraName = cameraList("hardwareName")
			cameraURL = cameraList("brand")
			cameraDefault = Trim(cameraList("model")) = "default"
			associatedTerminalID = cameraList("terminalID")
		end if
		
		cameraList.Close
		set cameraList = nothing
	end if
%>

<HTML>
<HEAD>
<TITLE>Image Capture Setup</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<SCRIPT LANGUAGE="javascript" >

	function selectCamera(){
		document.cameraSetup.action= "?device=" + cameraSetup.cameralist.options[cameraSetup.cameralist.selectedIndex].value;
		document.cameraSetup.submit();
	}
	
	function refreshImage(){
		document.cameraSetup.submit();
	}
	
	function submitSettings(){
		document.cameraSetup.action= "?action=submit&device=" + cameraSetup.cameralist.options[cameraSetup.cameralist.selectedIndex].value + "&terminalID=" + cameraSetup.terminallist.options[cameraSetup.terminallist.selectedIndex].value;
		document.cameraSetup.submit();
	}
	
	function removeCamera(){
		document.cameraSetup.action= "?action=remove&device=" + cameraSetup.cameralist.options[cameraSetup.cameralist.selectedIndex].value;
		document.cameraSetup.submit();
	}
	
	function goBack(){
		document.cameraSetup.action= "/setup/Hardware.asp"
		document.cameraSetup.submit();
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Image Capture Setup</H1>
<FORM id="cameraSetup" action = "" name="cameraSetup" method ="POST">

		<font face="Verdana, Helvetica" size=2 color="#000000">
		
		<TABLE width = 90% border="0" cellpadding="10" cellspacing="0" Style = "MARGIN-LEFT: 10px">
		
		<tr>
		<td>
		Select Camera:
		</td><td width="100%">
		<SELECT name=cameralist  onchange ="selectCamera()">
			<option <%if device = "new" then%>selected<%end if%> value="new">New Camera</option>
		<%
			ssql = "SELECT hardwareID, hardwareName from StoreHardware where hardwareType = 'IC'"
			set cameraList = getDisconnectedRecordset(ssql)
			
			while not cameraList.EOF
		%>
			<option <%if trim(device) = trim(cameraList("hardwareID")) then%>selected<%end if%> value=<%=cameraList("hardwareID")%>><%=cameraList("hardwareName")%></option>
		<%
			cameraList.MoveNext
			wend
			
			cameraList.Close
			set cameraList = nothing
		%>	
		</SELECT>
		
		

		<%if device <> "new" and device <> "" then%>
		&nbsp&nbsp&nbsp&nbsp&nbsp<INPUT name="btRemoveCamera" type=button  value="Remove" onClick="removeCamera()"/>
		<%end if%>
		
		</td>
		
		</tr><tr>
		<td>
		Camera Name:
		</td><td>
		<INPUT name="txCameraName" maxLength=50 size=80  value="<%=cameraName%>">
		</td>	
		</tr><tr>
				<td>
		Camera URL:
				</td><td>
		<INPUT name="txCameraURL" maxLength=256 size=80  value="<%=cameraURL%>">
		</td>	
		</tr>
		
		<td>
		Associated Terminal:
		</td><td>
		<SELECT name=terminallist>
		<%
			dim terminalList
			ssql = "SELECT terminalID, name from Terminal where storeID = '" & Session("Storeid") & "'"
			set terminalList = getDisconnectedRecordset(ssql)
			
			while not terminalList.EOF
		%>
			<option <%if trim(associatedTerminalID) = trim(terminalList("terminalID")) then%>selected<%end if%> value=<%=terminalList("terminalID")%>><%=terminalList("name")%></option>
		<%
			terminalList.MoveNext
			wend
			
			terminalList.Close
			set terminalList = nothing
		%>	
		</SELECT>
	
		&nbsp&nbsp&nbsp&nbsp&nbsp
		Default:

			<INPUT type=checkbox name=ckCameraDefault Style = "height=28px;WIDTH:28px" <% if cameraDefault then %>CHECKED<%End if  %>>

		</td>	
		</tr>
		
		
		
		
		
		
		
		<%if cameraURL <> "" then%>
		<tr >
		<td colspan = "2" align=center>
		<IMG src=<%=cameraURL%>>
		<BR>
		<INPUT name="btRefreshImage" type=button style="Height:50px" value="Capture Image" onClick="refreshImage()"/>
		</td>
		</tr>
		
		<%end if%>
		
		
		
		


		<tr >
		<td colspan = "2"  align=center>
	<INPUT class=touchnoBorder type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitSettings()"  id=button1 name=button1>&nbsp&nbsp&nbsp&nbsp&nbsp
	<INPUT class=touchnoBorder type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="goBack();" id=button2 name=button2>
		</td>
		</tr>
		</table>
		</font>
		
		
		<INPUT type="hidden" name="txDevice" class=text value="<%=device%>">
		<INPUT type="hidden" name="txTerminalID" class=text value="<%=associatedTerminalID%>">
		
</FORM>
</BODY>
</HTML>

