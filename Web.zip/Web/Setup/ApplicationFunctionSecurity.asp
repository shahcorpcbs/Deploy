<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim l_storeid
	dim isSubmitted 
	
	l_storeid = Session("storeid")
	isSubmitted = Request.QueryString("submitted")
	
	if isSubmitted then
		UpdateDatabase()
		Response.Redirect ("mainsetup.asp")
	end if
	
	getFunctionList()
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function setsecuritylevel(element){
	var x, i
		if ( document.applicationsecurity.chkFunctionId.length > 0) 
		{	i = 0;
			while (i < document.applicationsecurity.chkFunctionId.length){
				if (document.applicationsecurity.chkFunctionId(i).checked){
					document.applicationsecurity.h_securitylevel(i).value = element.value;
			//		alert(document.applicationsecurity.chkFunctionId(i).value)
			//		alert(document.applicationsecurity.h_securitylevel(i).value)
					document.all("appFunction").rows(i +1).cells(2).innerText = element.value;
					
					//alert(document.all("appFunction").rows(i +1).cells(3).innerText)
    
				}
			i++;
			}
		
		}
	
	
	}
	function submitForm() {
	var x, i;
		if ( document.applicationsecurity.chkFunctionId.length > 0) {
			i = 0;
			while (i < document.applicationsecurity.chkFunctionId.length){
				document.applicationsecurity.chkFunctionId(i).checked = true;
				i++;
			}
				document.applicationsecurity.action = "?Submitted=true";
				document.applicationsecurity.submit();
		}
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Application Security</H1>
<FORM id="applicationsecurity" name="applicationsecurity" action="MainSetup.asp" Method = "post">

<TABLE WIDTH= 650  BORDER=2 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT: 50px"><!-- header row -->
 <tr >
	<td align=left valign=top>
	<TABLE width = 100% border="0" cellpadding="7" cellspacing="0" Style = "MARGIN-LEFT: 5px">
	<tr><td width = 70% align=left valign=top> <br>
		<DIV STYLE="HEIGHT: 380px; OVERFLOW-X: auto; OVERFLOW-Y: auto; WIDTH: 450px" >
			<TABLE id = "appFunction" name = "appFunction" width = 100% style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =2 CELLSPACING=0>
			<tr><td width = 5></td>
				<td width = 330><B>Application Function Name</td>
				<td width = 80 align = middle><B>Security Level</td>
			</tr>
			<% if rstlist.recordcount > 0 then
				while not rstlist.eof %>
				<tr><td >
					<INPUT type = checkbox name=chkFunctionId value= "<%=rstlist("Functionid")%>"><INPUT type = hidden name=h_securitylevel value= "<%=rstlist("securitylevel")%>"> 
				</td>
				<td  ><%=rstlist("Name")%></td>
				<td align = middle>
					<%=rstlist("securitylevel")%></td>
				</tr>
			<% 
				rstlist.movenext
				wend
				rstlist.close
				set rstlist = nothing	
				end if %>
			</table>
		</DIV>
	</TD>
	<td align= left vAlign=top width = 20%> 
	<TABLE  border="0" cellpadding="7" cellspacing="0">
	<tr><td ><BR><BR>
		<INPUT class = click name=level type=button value="0" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 5px">
		<INPUT class = click name=level type=button value="1" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 20px">
	</td></tr>
	<tr><td> <BR><BR>
		<INPUT class = click name=level type=button value="2" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 5px">
		<INPUT class = click name=level type=button value="3" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 20px">
	</td></tr>
	<tr><td><BR><BR> 
		<INPUT class = click name=level type=button value="4" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 5px">
		<INPUT class = click name=level type=button value="5" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 20px">
	</td></tr>
	<tr><td  > <BR><BR>
		<INPUT class = click name=level type=button value="6" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 5px">
		<INPUT class = click name=level type=button value="7" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 20px">
	</td></tr>
	<tr><td  ><BR><BR> 
		<INPUT class = click name=level type=button value="8" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 5px">
		<INPUT class = click name=level type=button value="9" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 20px">
	</td></tr>
	</table> 
	</td></tr>
	</TABLE>
		<INPUT class = click name=OK type=button value="OK" onClick="submitForm()"  style="HEIGHT: 24px; WIDTH: 62px;Margin-left= 450px">
		<INPUT class = click name=Cancel type=button value="Cancel" onClick="history.back(-1)"  style="HEIGHT: 24px; WIDTH: 62px;Margin-left= 10px">
		<br><BR>
	</td></tr>
	</TABLE></FORM>
</BODY>
</HTML>
<%
	dim rstList
	Function getFunctionlist()
	dim sqltxt
		sqltxt = "select functionid, name,securitylevel = isnull(securitylevel, 0) from applicationfunctiondomain " 'order by name "
		set rstList = getdisconnectedrecordset(sqltxt)
	end function
	
	Function UpdateDatabase()
	dim sqltxt
	dim totalcount
	dim i 
	totalcount = 0
	totalcount = Request.Form("chkFunctionid").count
	dbstartTrans()
	for i = 1 to totalcount 
		 sqltxt = "update applicationfunctiondomain set securitylevel = " & Request.Form("h_securitylevel")(i) _
					& " where functionid = " & Request.Form("chkfunctionid")(i)
		qryexecutewithtrans(sqltxt)
	next 
	 dbendtrans()
	end function
	


%>

