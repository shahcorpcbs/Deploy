<%@Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim isSubmitted 
	dim l_terminalid
	dim l_storeid 
	dim rstPort
	
	l_storeid  = Session("Storeid")
	l_terminalid = Session("Setupterminalid")
	isSubmitted = Request.QueryString("submitted")
	if isSubmitted then
		updateDatabase()
		Response.Redirect("hardware.asp")
	end if
	
	

	dim rstScanner
	dim l_hardwareid
	dim l_port 
	dim l_rate
	dim l_text
	
	
	getBarcodeInfo()
	getPorts()
%>	
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
		
	function submitForm(useraction) {
		if (validateform(useraction)){
			document.frmScanner.action ="?Submitted=true&useraction=" + useraction;
			document.frmScanner.submit();
		}
	}	
	
	function validateform(element)	{
	i = 0
	found = false;
	retval = false;
		if (element != "delete" ){
		var radios = document.getElementsByName('rdPort');
			while (i < radios.length){
				if ( radios[i].checked){
					found = true;
					retval=true;
					break;
				}
				i++;
			}
		if (found == false)
			alert("Port is a required field");
			
		}
		else
			retval= true;
		return retval;
	}		
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Barcode Scanner</H1>
<FORM id="frmScanner" name="frmScanner" action = "" Method = "post">

<input type = hidden name = "h_hardwareid" value = "<%=l_hardwareid %>">

<TABLE WIDTH="550px" BORDER=2 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT: 50px"><!-- header row -->

<TBODY>
 <tr>
	<td align=left valign=top>
	<TABLE width =550px border="0" cellpadding="10" cellspacing="0" Style="MARGIN-LEFT: 10px">
		<tr><br>
		<td width= 60 class = "label" Style="Font-weight=normal">Type</td>
		<td width = 400px  align = left>
		<input class = text maxlength="255" name="txtBrand" Style = "Width= 200px" value = "<%=l_text%>">&nbsp;&nbsp;(For Information purpose only)
		</td>
		</tr>
		<tr>
			<td width= 60 class = "label"  Style="Font-weight=normal">Port</td>
		 	<td width = 350px  align = left>
		 	<INPUT  name="rdPort" id="rdPort" type=radio  Value = "COM1"
		 		<% if l_port = "COM1" then %>
					CHECKED 
				<% end if %>
	
				<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "COM1" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 
			>&nbsp;&nbsp;COM 1
			<INPUT   name="rdPort" id="rdPort" type=radio  Value = "COM2"
				<% if l_port = "COM2" then %>
					CHECKED 
				<% end if %>
				
				<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "COM2" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 
			style="margin-left=20px">&nbsp;&nbsp;COM 2
			
			<INPUT  name="rdPort" id="rdPort" type=radio  Value = "COM3"
				<% if l_port = "COM3" then %>
					CHECKED 
				<% end if %>
			
				<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "COM3" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 
			style="margin-left=20px" >&nbsp;&nbsp;COM 3
			
			<INPUT   name="rdPort" id="rdPort" type=radio  Value = "COM4"
				<% if l_port = "COM4" then %>
					CHECKED 
				<% end if %>
				
				<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "COM4" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if 
				rstPort.close
				set rstPort = nothing
				%> 
			style="margin-left=20px" >&nbsp;&nbsp;COM 4
			</td> 
		</tr>
		<tr>
		<td width= 60 class = "label" STYLE= "Font-weight=normal" >Baud Rate</td>
		<td width = 300px >
			<SELECT name= optbrate STYLE="Height = 24px;FONT-SIZE: 15px ;Width = 120px ">
				<Option 
				<%if l_rate = "1200" then %>
				Selected 
				<%end if%>
				
				Value = 1200>1200</option>
				<Option  <%if l_rate = "1800" then %>
				Selected 
				<%end if%>
				Value = 1800>1800</option>
				<Option  <%if l_rate = "2400" then %>
				Selected 
				<%end if%>
				Value = 2400>2400</option>
				<Option  <%if l_rate = "4800" then %>
				Selected 
				<%end if%>
				Value = 4800>4800</option>
				<Option  <%if l_rate = "7200" then %>
				Selected 
				<%end if%>
				Value = 7200>7200</option>
				<Option  <%if l_rate = "9600" then %>
				Selected 
				<%end if%>
				Value = 9600>9600</option>
				<Option  <%if l_rate = "14400" then %>
				Selected 
				<%end if%>
				Value = 14400>14400</option>
				<Option  <%if l_rate = "19200" then %>
				Selected 
				<%end if%>
				Value = 19200>19200</option>
				<Option  <%if l_rate = "57600" then %>
				Selected 
				<%end if%>
				Value = 38400>38400</option>												
				<Option  <%if l_rate = "57600" then %>
				Selected 
				<%end if%>
				Value = 57600>57600</option>												
				<Option  <%if l_rate = "115200" then %>
				Selected 
				<%end if%>
				Value = 115200>115200</option>																								
				</SELECT> 
			</td>
		</tr>
		<br><br>
		<tr><td align=center colspan=4>
			<INPUT  class = click name="delete" type=button style="width:100;height=50" value="Do not use" 
			<%  if len(trim(l_hardwareid)) = 0 then %>
				Disabled
			<%end if %>
			onClick="submitForm('delete')"></td></tr>
		<tr><td align=center colspan=4>	
		<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif);background-position=center" onClick="submitForm('add')">&nbsp&nbsp&nbsp&nbsp&nbsp
		<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);background-position=center" onClick="history.back(-1)">
			
		<!--<INPUT class = click name=OK type=button value="OK" style="HEIGHT: 24px; MARGIN-left= 20px; WIDTH: 62px" onClick="submitForm('add')">
		<INPUT class = click name=cancel type=button value="Cancel" style="HEIGHT: 24px; MARGIN-left= 20px; WIDTH: 62px" onClick="history.back(-1)"><br><br>-->
		</td></tr>
		</table>
	
	</td></tr>
	</Table></FORM>
		
</BODY>
</HTML>

<%
	function getBarcodeinfo()
	dim sqltxt
		
		sqltxt = "select * from storehardware where hardwaretype = 'BS' and terminalid = " & l_terminalid
		set rstScanner = GetDisconnectedRecordset(sqltxt)
		if rstScanner.recordcount > 0  then
			l_hardwareid = rstScanner("hardwareid")
			l_port  = rstScanner("port")
			l_rate= rstScanner("Baudrate")
			l_text= rstScanner("Brand")
		end if
		rstScanner.close
		set rstScanner = nothing
		
	end function
	
	function updateDatabase()
	dim hardwareid
	dim sqltxt
	hardwareid = Request.Form("h_hardwareid")
	
	if (Request.QueryString("useraction") = "delete" ) then
	
		sqltxt= "delete storehardware where hardwareid = " & hardwareid
		dbstarttrans()
		QryExecuteWithTrans(sqltxt)
		dbendTrans()
	
	else
		if len(trim(hardwareid)) = 0 then
			'insert
			sqltxt = "insert Storehardware (terminalid,hardwarename,hardwaretype, port, baudRate, " _
				 & " Brand ) values (" _
				  & l_terminalid _
				  & ", " & "'Barcode Scanner'" _
				  &  ", " & "'BS'" _
				  & "," & dbcreateqrystring(Request.form("rdPort")) _
				  & "," & dbcreateQryString(Request.form("optBrate"))  _
				  & "," & dbcreateQryString(Request.form("txtBrand")) _
				  & ")"
				  ' Response.Write sqltxt
				   dbstarttrans()
				   QryExecuteWithTrans(sqltxt)
				   dbendTrans()
	
		else
			'update 
		
			sqltxt = "update Storehardware set  " _
				  & "port=" & dbcreateqrystring(Request.form("rdPort")) _
				  & ", baudRate=" & dbcreateQryString(Request.form("optBrate"))  _
				  & ", Brand=" & dbcreateQryString(Request.form("txtBrand")) _
				  & " where hardwareid = " & hardwareid
				   'Response.Write sqltxt
				   dbstarttrans()
				   QryExecuteWithTrans(sqltxt)
				   dbendTrans()
		end if
	end if
	end function
	
	
	function getPorts()
	dim sqltxt
		sqltxt = "select distinct port from storehardware where port is not null and hardwaretype <> 'BS' and terminalid = " & l_terminalid 
		set rstPort = getdisconnectedrecordset(sqltxt)
		
	end function
%>
