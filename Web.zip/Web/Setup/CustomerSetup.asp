<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim isSubmitted 
	dim l_storeid
	dim sqltxt 
	dim l_address
	dim l_route
	dim l_payment
	dim l_prefer
	dim l_notes
	dim l_autocustid
	dim l_editcustid
	dim l_defsearch
	dim a_defsearch
	dim l_Zip
	
	dim sDbaction
	
	isSubmitted = Request.QueryString("submitted")
	l_storeid = session("StoreID")

	if (isSubmitted ) then
	
		dim x
		
		x=Request.Form("defdsearch")
		
		if (x = "name") then
				l_defsearch= 1
		else
				l_defsearch= 0
		end if
			
		if  Request.Form("qryAction") = "1"  then 'update  data
					
			dbstartTrans()
			
			if (l_defsearch = 1) then
				a_defsearch = "CUSTOMERNAME"
			else	
				a_defsearch = "CUSTOMERID"
			end if	
			
			sqltxt	 = "Update customersetupoptions set " _
							& "allowentrycustaddr =" &  evalRequestValue(request.form("chkaddress")) _
							& " , allowentrycustrouteinfo =" &  evalRequestValue(request.form("chkrouteinfo")) _
							& " , allowentrycustPayPromo =" &  evalRequestValue(request.form("chkpayment")) _
							& " , allowentrycustPref =" &  evalRequestValue(request.form("chkprefer")) _
							& " , allowentrycustNotes =" &  evalRequestValue(request.form("chknotes")) _
							& " , autoCustomerId =" &  evalRequestValue(request.form("chkautoCustId")) _
							& " , allowEditCustomerId =" &  evalRequestValue(request.form("chkeditCustId")) _
							& " , DefaultSearchMethod=" & "'" & a_defsearch & "'" _
							& " , autoZipToCity =" &  evalRequestValue(request.form("chkZip")) _
							& " where Storeid = " & l_storeid
							
			QryExecutewithtrans(sqltxt)
			
			if request.form("pricetable")<> "" then
			
				sqltxt = "Update pricelist set defaultind= 0" _
								& "where storeid = " & l_storeid
								
				QryExecutewithtrans(sqltxt)
						
				Sqltxt = "Update pricelist set defaultind= 1" _
								& "where Pricelistid = " & request.form("pricetable") & " and storeid = " & l_storeid
								
				QryExecutewithtrans(sqltxt)
				
			end if
			
			dbEndTrans()
		
		else 'insert data 
			
				dbstartTrans()	
				
				if (l_defsearch = 1) then
					a_defsearch = "CUSTOMERNAME"
				else	
					a_defsearch = "CUSTOMERID"
				end if
				
				sqltxt = 	"Insert customersetupoptions (storeid, allowentrycustaddr, allowentrycustRouteinfo, allowentryCustpayPromo, allowentryCustpref, " _
								& " allowentryCustNotes, autocustomerid, allowEditCustomerid, defaultSearchMethod, autoZipToCity) values (" _
							& l_storeid _
							& "," & evalRequestValue(request.form("chkaddress")) _
							& "," & evalRequestValue(request.form("chkrouteinfo")) _
							& "," & evalRequestValue(request.form("chkpayment")) _
							& "," & evalRequestValue(request.form("chkprefer")) _
							& "," & evalRequestValue(request.form("chknotes")) _
							& "," & evalRequestValue(request.form("chkautoCustId")) _
							& "," & evalRequestValue(request.form("chkeditustId")) _
							& "," &   "'" & a_defsearch & "'" _
							& "," & evalRequestValue(request.form("chkZip")) _
							& ")"
							
				QryExecutewithtrans(sqltxt)
							
				if request.form("pricetable")<> "" then
				
						sqltxt = "Update pricelist set defaultind= 0" _
								& "where storeid = " & l_storeid
								
							QryExecuteWithTrans(sqltxt)
						
						Sqltxt = "Update pricelist set defaultind= 1" _
								& "where Pricelistid = " & request.form("pricetable") & " and storeid = " & l_storeid
								
								QryExecuteWithTrans(sqltxt)
				end if
				
				dbEndTrans()
				
			end if
	
	end if
	
	dim actionstring
	actionstring= Request.QueryString("userAction")
	if ( not isnull(actionstring) and actionstring<>"") then
		Response.Redirect(actionstring)
	end if
	
	
	
	if (not isnull(l_storeid) and not l_storeid = "" ) then
	
		dim rsCustomeroption
		
		sqltxt = "select *  from customersetupoptions where storeid =" & l_storeid
		
		set rsCustomeroption= getDisconnectedRecordset(sqltxt)
		
		sDbaction = 2 'Insert
		
'		l_defsearch= 0
		
		if not rsCustomeroption.BOf and not rsCustomeroption.Eof then
		
			sDbaction = 1 'update
			
			dim i
			
			'response.write "geek"
			l_address = 0
			l_address = checkfornull(rsCustomeroption("allowentrycustaddr"))
			'Response.Write l_address
			l_route = checkfornull(rsCustomeroption("allowentrycustRouteInfo"))
			l_payment = checkfornull(rsCustomeroption("allowentrycustpayPromo"))
			l_prefer = checkfornull(rsCustomeroption("allowentrycustPref"))
			l_notes = checkfornull(rsCustomeroption("allowentrycustNotes"))
			l_autocustid = checkfornull(rsCustomeroption("autoCustomerID"))
			l_Editcustid = checkfornull(rsCustomeroption("alloweditCustomerId"))
			i= checkfornull(rsCustomeroption("defaultSearchMethod"))
			
			l_Zip = checkfornull(rsCustomeroption("autoZipTOCity"))
			
			if (ucase(i) = "CUSTOMERNAME") then
				l_defsearch= "1"
			else
				l_defsearch= "0"
			end if
			'Response.Write  (l_defsearch)
			rsCustomeroption.Close()
			set rsCustomeroption= nothing
		end if
		
	end if
	
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm() {
		document.customersetup.submit();
	}
	function submitFormCustomerRequiredDetails() {
		document.customersetup.action = "?submitted=true" + "&userAction=" +
		 "CustomerRequiredField.asp"
		document.customersetup.submit();
	}
	function submitFormCustomerSource() {
		document.customersetup.action = "?submitted=true" + "&userAction=CustomerSource.asp"
		document.customersetup.submit();
	}
	function submitFormPreferences() {
		document.customersetup.action = "?submitted=true" + "&userAction=CustomerPreferences.asp"
		document.customersetup.submit();
	}
	
	function submitForm() {
		document.customersetup.action = "?submitted=true" + "&userAction=MainSetUp.asp"
		document.customersetup.submit();
	}						
	function setSearchId(){
		var i;
		var j;
		if  (document.customersetup.defdsearch[0].checked )
			document.customersetup.searchvalue.value = "0" ;
		else
			document.customersetup.searchvalue.value = "1" ;
	}
	function cancelForm(){
		document.customersetup.action = "mainsetup.asp"
		document.customersetup.submit();
	}					
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Customer Setup</H1>
<FORM id="customersetup" name="customersetup" action="" Method = "post">
<input type=hidden name="qryAction" value="<%=sdbaction%>">
<input type=hidden name="searchvalue" >
<TABLE align = center WIDTH="500" BORDER=0 CELLSPACING=1 CELLPADDING=0 ><!-- header row -->
<TBODY>
 <tr>
	<td align=center valign=top>
	<TABLE width = 500px  cellpadding="8" cellspacing="0" Style = "MARGIN-LEFT: 8px" class="itable">
		<tr> 
			<TH width = 200px  class="label">Display Details Of:</TH>
			<TH class="label">Default Search Method:</TH>
			
		</tr>
		<tr >
			<TD ><INPUT type=checkbox name="chkaddress" <%if (l_address ) then %> checked <%end if %>>&nbsp;&nbsp;Address</TD>
			<TD><INPUT type=radio name="defdsearch" value="id" <%if ( l_defsearch = "0") then %> checked <%end if %>   onclick="setSearchId()">&nbsp;&nbsp;Customer ID</TD>
			<!--<TD>Required Customer Detail&nbsp;&nbsp;<Select  id=select1 name=select1></select></TD>-->
			
		</tr>
		<tr>
			<TD><INPUT type=checkbox name="chkrouteinfo" <%if (l_route ) then %> checked <%end if %>>&nbsp;&nbsp;Route Information</TD>
			<TD><INPUT type=radio name="defdsearch" value="name" <%if ( l_defsearch ="1" ) then %> checked <%end if %> onclick="setSearchId()">&nbsp;&nbsp;Customer Name/Phone Number</TD>
			
			
		</tr>
		<tr >
			<TD><INPUT type=checkbox name="chkpayment" <%if (l_payment ) then %> checked <%end if %>>&nbsp;&nbsp;Payment/Promotions</TD>
			<TD><INPUT type=checkbox name="chkautoCustId" <%if (l_autocustid ) then %> checked <%end if %>>&nbsp;&nbsp;Auto Number Customer ID</TD>
			
		</tr>
		<tr >
			<TD><INPUT type=checkbox name="chkprefer" <%if (l_prefer ) then %> checked <%end if %>>&nbsp;&nbsp;Preferences</TD>
			
			<TD><INPUT type=checkbox name="chkEditCustId" <%if (l_EditCustid ) then %> checked <%end if %>>&nbsp;&nbsp;Edit Customer ID&nbsp;&nbsp;</TD>
		</tr>
		<tr>
			<TD><INPUT type=checkbox name="chknotes" <%if (l_notes ) then %> checked <%end if %>>&nbsp;&nbsp;Notes</TD>
			
				<TD align = center class="label">Required Details:</TD>
		</tr>
		
		<tr>
			<TD><INPUT type=checkbox name="chkZip" <%if (l_Zip ) then %> checked <%end if %>>&nbsp;&nbsp;Auto Zipcode to City</TD>
			<td align= center >
				<!--<INPUT class = click name=RequiredInfo type=button value="Add other Required Details" style="HEIGHT: 24px; WIDTH: 160px;" onclick="submitFormCustomerRequiredDetails()">-->
				<BUTTON class=std name=RequiredInfo onclick="submitFormCustomerRequiredDetails()" style="width:200px;height:75px">Add other Required Details</button>
			</td>	
		</tr>
		
		
		</Table>
		<TABLE width = 500px border="0" cellpadding="5" cellspacing="0" Style = "MARGIN-LEFT: 8px">
		<tr height=5px><td></td></tr>
		
		<tr >
			<TD width = 100px class="label">Other Defaults</TD>
			<TD colspan= 2 align= right>Price Table&nbsp;&nbsp;&nbsp;&nbsp;
			<Select id=pricetable name=pricetable>
			<%
				dim rspricelist
				sqltxt = "Select pl.defaultind, pl.PriceListId, (pl.name + ' at ' + s.name) as name from Pricelist pl, store s where (pl.storeid = " & l_storeid & " or pl.pricelistid in (select pricelistid from storealtpricelist where storeid = " & l_storeid & "))"
				sqltxt = sqltxt & " and s.storeid = pl.storeid"

				set rspricelist = getdisconnectedrecordset(sqltxt)
				if rspricelist.recordcount > 0 then
					while not rspricelist.EOF
			%> 	
				<OPTION 
					<% if rspricelist("defaultind") then	%>
						selected
					<%	end if	%>
					VALUE= "<%=rspricelist("PriceListId") %>"><%= rspricelist("Name") %>
				</option>
					<%
					rspricelist.MoveNext
					wend
					rspricelist.close
					set rspricelist = nothing
				end if
				%>
			</select></TD>
		</tr>
		<tr height = 10px><td></td></tr>
		<tr>
			<td align = center colspan="3">
				<BUTTON class=std name=custsource onclick="submitFormCustomerSource()">Customer Source</button>
				<BUTTON class=std name=preferences onclick="submitFormPreferences()">Preferences</button>
			</td>	
		</tr>	
	</table><br><br><br>
	<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
	<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">

	 </td></tr>
	 <tr height = 10 ><td></td></tr>
	</TBODY>
	</TABLE>
	</FORM>
		
</BODY>
</HTML>

