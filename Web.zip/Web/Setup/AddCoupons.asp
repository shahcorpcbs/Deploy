<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/ValidateFunction.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim priceListId
	dim actionString
	dim name
	dim effDate
	dim expDate
	dim validWithOtherOffer
	dim minDolar
	dim maxDollar
	dim minPiece
	dim maxPiece
	dim discSubType
	dim discountP
	dim discountAmt
	dim maxDiscAmt
	dim addOrEditAction
	dim couponId
	dim IsDiscAmt
	dim appliesPerUnit
	dim noofuses
	dim shortcut
	dim userMessage
	dim itemAboveZero

	userMessage = ""
	shortcut = ""
	noofuses = ""
	name =""
	effDate =Date()
	expDate =""
	validWithOtherOffer=1
	minDolar=""
	maxDollar =""
	minPiece =0
	maxPiece =-1
	itemAboveZero = 0
	discountP =""
	discountAmt =""
	maxDiscAmt =""
	IsDiscAmt = true
	discSubType ="Pieces"
	couponId = Request.QueryString("couponId")
	addOrEditAction = Request.QueryString("addOrEdit")
	actionString = Request.QueryString("userAction")
	priceListId = Request.QueryString("priceListId")
	
	select case actionString
		case "addCoupon"
				if addCoupon() then
					Response.Redirect "discountlist.asp?discounttype=cu&priceListId=" & priceListId
				end if
		case "deptRelation"
				couponId = addCoupon()
				if couponId then
					Response.Redirect "DepartmentRelation.asp?couponId=" & couponId	& "&priceListId=" & priceListId & "&CouponOrPromotion=Coupon"
				end if
		case "department"
				couponId = addCoupon()
				if couponId then
					Response.Redirect "ApplicableDepartment.asp?couponId=" & couponId & "&priceListId=" & priceListId & "&CouponOrPromotion=Coupon"	
				end if
		case "discountTime"
				couponId = addCoupon()
				if couponId then
					Response.Redirect "discountTime.asp?discountId=" & couponId	
				end if
	end select
	
	function verifyDiscountShortcut(priceListID, discountID, shortcut, discountName)
		dim query, rs
		
		verifyDiscountShortcut = true
		
		if discountID <> "" then
			query = " select discountID, discountName from discount where discountID <> " & discountID
			query = query & " and priceListID = " & priceListID
			query = query & " and not(shortcut is null) "
			query = query & " and shortcut = '" & shortcut & "'"
			query = query & " and active = 1 "
			
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				discountName = rs("discountName")
				verifyDiscountShortcut = false
			end if

			set rs = nothing

		end if
	end function
	
	function addCoupon()
		dim ssql
		dim rst
		dim discountType
		dim discountId
		dim discountName
		
		if not verifyDiscountShortcut(priceListID, couponId, Request.Form("shortcut"), discountName) then
			addCoupon = 0
			userMessage = "Shortcut '" & Request.Form("shortcut") & "' already used by:"
			userMessage = userMessage & "<br />" & discountName
			exit function
		end if
		
		collectFormData
		
		if addOrEditAction ="edit" then	
			discountId = couponId
			ssql ="UPDATE Discount SET discountSubType='" & discSubType & "', discountName='" _
				  & DBStr(name) & "', effectiveDate='" & effDate & "', expiryDate=" & expDate _
				  & ", minPieceCount=" & minPiece & ", maxPieceCount=" & maxPiece _
				  & ", minQualAmount=" & minDolar & ", maxQualAmount=" & maxDollar _
				  & ", discountPercent=" & discountP & ", discountAmount=" & discountAmt _
				  & ", maxDiscountAmount=" & maxDiscAmt & ", validWithOtherOffer=" _
				  &  validWithOtherOffer _
				  & ", appliesPerUnit = " & appliesPerUnit _
				  & ", noofuses = " & noofuses _
				  & ", shortcut = " & shortcut _
				  & ", itemAboveZero = " & itemAboveZero _
				  & " WHERE discountId=" & clng(couponId)
			QryExecute(ssql)
		else
			ssql ="Select discountType from DiscountTypeDomain where discountTypeName='Coupon'" 
			set rst = getDisconnectedRecordset(ssql)
			if rst.recordcount >0 then
				rst.MoveFirst
				discountType = rst.fields("discountType")
			end if
			ssql="SET NOCOUNT ON;INSERT INTO Discount(priceListId, discountType, " _
				  & " discountSubType, discountName, effectiveDate, expiryDate, " _
				  & " minPieceCount, maxPieceCount, minQualAmount, maxQualAmount, " _
				  & " discountPercent, discountAmount, maxDiscountAmount, " _
				  & " validWithOtherOffer, appliesPerUnit, noofuses, shortcut, itemAboveZero) VALUES(" & clng(priceListId) _
				  & ",'" & discountType & "','" & discSubType & "','" & DBStr(name) & "','" _
				  & effDate & "'," & expDate & "," & minPiece & "," & maxPiece & "," _
				  & minDolar & "," & maxDollar & "," & discountP & "," & discountAmt _
				  & "," & maxDiscAmt & "," & validWithOtherOffer & "," & appliesPerUnit & "," & noofuses & ", " _
				  & shortcut & ", " & itemAboveZero & ");" _
				  & "SELECT SCOPE_IDENTITY(); SET NOCOUNT OFF;"
			DbStartTrans
			discountId = QryExecuteWithTransAndSelect(ssql)
			DbEndTrans
		end if
		addCoupon = discountId
	end function
	
	function collectFormData()
		name = Request.Form("couponname")
		discSubType = Request.Form("coupontype")
		effDate=Request.Form("effectdate")
		expDate = Request.Form("expDate")
		noofuses = Request.Form("noofuses")
		
		shortcut = Request.Form("shortcut")
		
		if len(trim(shortcut)) = 0 then
			shortcut = "NULL"
		else
			shortcut = "'" & shortcut & "'"
		end if
		
		if len(trim(expDate)) =0 then
			expDate ="NULL"
		else
			expDate ="'" & expDate & "'"
		end if
		if len(trim(noofuses)) =0 then
			noofuses = "NULL"
		else
			noofuses = noofuses
		end if
		if IsEmpty(Request.Form("isvalidwith")) then
			validWithOtherOffer =0
		else
			validWithOtherOffer =1
		end if
		if isempty(Request.Form("appliesPerUnit")) then
			appliesPerUnit = 0
		else
			appliesPerUnit = 1
		end if
		select case Request.Form("discountamount")
			case "1"
				discountAmt = CDbl(Request.Form("discount"))
				discountP ="NULL"
			case "2"
				discountP = CDbl(Request.Form("discount"))
				discountAmt ="NULL"
		end select
		if len(trim(Request.Form("maxdiscount"))) > 0 then
			maxDiscAmt = CDbl(Request.Form("maxdiscount"))
		else
			maxDiscAmt = "NULL"
		end if
		select case discSubType
			case "Pieces"
					minPiece = clng(Request.Form("minPiece"))
					maxPiece = clng(Request.Form("maxPiece"))
					if maxPiece = -1 then
						maxPiece = "NULL"	
					end if
					minDolar ="NULL"
					maxDollar ="NULL"
                if isempty(Request.Form("pieceMinAmt")) then
                    itemAboveZero = 0
                else
                    itemAboveZero = 1
                end if
			case "Amount"
					minDolar = CDbl(Request.Form("minDollar"))
					maxDollar = CDbl(Request.Form("maxDollar"))
					minPiece ="NULL"
					maxPiece ="NULL"
					itemAboveZero = 0
		end select
		
	end function
	
	function getCouponDetails()
		dim ssql
		dim objResultSet
		ssql = "Select discountId, discountName, effectiveDate, expiryDate, itemAboveZero, " _
				& " discountsubType, isnull(minPieceCount,0) as minPieceCount, " _
				& " maxPieceCount, isnull(minQualAmount, 0) as minQualAmount, " _
				& " isnull(maxQualAmount,0) as maxQualAmount, discountPercent, " _
				& "  discountAmount, isnull(cast(maxDiscountAmount as varchar), '') as maxDiscountAmount, " _
				& " validWithOtherOffer, appliesPerUnit, noofuses, isnull(shortcut, '') as shortcut from Discount where discountId=" & couponId
		set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.recordcount >0 then
			name = objResultSet.Fields("discountName")
			shortcut = objResultSet.Fields("shortcut")
			effDate = FormatDateTime(objResultSet.Fields("effectiveDate"), vbShortDate)
			if not isnull(objResultSet.fields("expiryDate")) then
				expDate = FormatDateTime(objResultSet.fields("expiryDate"), vbShortDate)
			end if
			discSubType = trim(objResultSet.Fields("discountsubType"))
			if discSubType ="Pieces" then
				minPiece = objResultSet.fields("minPieceCount")
				if IsNull(objResultSet.fields("maxPieceCount")) then
					maxPiece = -1
				else
					maxPiece = objResultSet.fields("maxPieceCount")
				end if
			else
				minDolar = objResultSet.fields("minQualAmount")
				maxDollar = objResultSet.fields("maxQualAmount")
			end if
			if not IsNull(objResultSet.fields("discountPercent")) then
				discountP = objResultSet.fields("discountPercent")
				maxDiscAmt = objResultSet.fields("maxDiscountAmount")
				IsDiscAmt =false
			else
				maxDiscAmt = objResultSet.fields("maxDiscountAmount")
				discountAmt = objResultSet.fields("discountAmount")
				IsDiscAmt =true
			end if
			if objResultSet.fields("validWithOtherOffer") then
				validWithOtherOffer = 1
			else
				validWithOtherOffer =0
			end if
			if objResultSet.fields("appliesPerUnit") then
				appliesPerUnit = 1
			else
				appliesPerUnit = 0
			end if
			noofuses = objResultSet.fields("noofuses")
			itemAboveZero = objResultSet.fields("itemAboveZero")
		end if
	end function
		
	function checkNullField(val)
		if IsNull(val) then
			checkNullField =""
		else
			checkNullField =val
		end if
	end function
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker.js"></script>
<script language="javascript" type="text/javascript">

	function submitFormDepartment() {
		var priceId;
		var addEdit;
		var couponId
		addEdit =document.addcoupon.addOrEdit.value;
		priceId = document.addcoupon.priceListId.value;
		couponId = document.addcoupon.discountId.value;
		if(validateForm()){
			document.addcoupon.action=document.addcoupon.action + "?userAction=department&priceListId=" + priceId +"&addOrEdit=" + addEdit + "&couponId=" + couponId;
			document.addcoupon.submit();
		}
	}
	function submitFormRelationship() {
		var priceId;
		var addEdit;
		var couponId
		addEdit =document.addcoupon.addOrEdit.value;
		priceId = document.addcoupon.priceListId.value;
		couponId = document.addcoupon.discountId.value;
		if(validateForm()){
			document.addcoupon.action=document.addcoupon.action + "?userAction=deptRelation&priceListId=" + priceId +"&addOrEdit=" + addEdit + "&couponId=" + couponId;
			document.addcoupon.submit();
		}
	}
		
	function submitForm() {
		var priceList
		var discountId
		var addEdit
		priceList = document.addcoupon.priceListId.value;
		discountId = document.addcoupon.discountId.value;
		addEdit = document.addcoupon.addOrEdit.value;
		if (validateForm()){
			document.addcoupon.action = "?userAction=addCoupon&priceListId=" + priceList +"&addOrEdit=" + addEdit + "&couponId=" + discountId;
			document.addcoupon.submit();
		}
	}
	
	function validateForm() {
		var temp;
		var ctype;
		temp = document.addcoupon.couponname.value;
		if (temp.length==0){
			showFocus("Coupon name can not be blank", document.addcoupon.couponname);
			return false;
		}
		temp = document.addcoupon.expDate.value;
		//if(temp.length>0 && 
		temp = document.addcoupon.discount.value;
		if(temp.length==0){
			showFocus("Discount is invalid", document.addcoupon.discount);
			return false;
		}else{
			temp = cleanNumeric(temp);
			if (temp == "") {
				showFocus("Discount is invalid", document.addcoupon.discount);
				return false;
			} //eval(temp)<=eval(0)
		}
		if(document.addcoupon.discountamount[1].checked){
			temp = document.addcoupon.maxdiscount.value;
			temp = cleanNumeric(temp);
			if (!isNum1(temp,0)) {
					showFocus("Invalid Max Discount", document.addcoupon.maxdiscount);
					return false;
			} //eval(temp)<=eval(0)
			
		}
		ctype = $("#coupontype").val()
		if(ctype=="Amount"){
			temp = document.addcoupon.minDollar.value;
			if(temp.length==0 || !isNum1(temp,0)){
				showFocus("Invalid Min Dollar Amount", document.addcoupon.minDollar);
				return false;
			}
			temp = document.addcoupon.maxDollar.value;
			if(temp.length==0 || !isNum1(temp,0)){
				showFocus("Invalid Max Dollar Amount", document.addcoupon.maxDollar);
				return false;
			}
		}
		return true;
	}
	function enableDisableMaxDisc(){
		/*if (document.addcoupon.discountamount[0].checked) {
			document.addcoupon.maxdiscount.value="";
			document.addcoupon.maxdiscount.disabled=true;
		}
		else {
			document.addcoupon.maxdiscount.disabled =false;
		}*/
	}
	function adjustDiscSubType(){
		var couponType = $("#coupontype").val()
		if (couponType === "Pieces"){
			document.addcoupon.minpiece.disabled=false;
			document.addcoupon.maxpiece.disabled=false;
			document.addcoupon.minDollar.value="";
			document.addcoupon.maxDollar.value="";
			document.addcoupon.minDollar.disabled=true;
			document.addcoupon.maxDollar.disabled=true;
			document.getElementById('pieceMinAmt').style.visibility = '';
			document.getElementById('pieceMinAmtLbl').style.visibility = '';
		}else{
			document.addcoupon.minpiece.disabled=true;
			document.addcoupon.maxpiece.disabled=true;
			document.addcoupon.minDollar.disabled=false;
			document.addcoupon.maxDollar.disabled=false;
			document.getElementById('pieceMinAmt').style.visibility = 'hidden';
			document.getElementById('pieceMinAmtLbl').style.visibility = 'hidden';
		}
	}
	function cancelForm(){
		var priceList
		priceList = document.addcoupon.priceListId.value;
		document.addcoupon.action="discountlist.asp?discounttype=cu&priceListId=" + priceList;
		document.addcoupon.submit();
	}
	
	function addTimeRange() {
		var priceId;
		var addEdit;
		var couponId
		addEdit =document.addcoupon.addOrEdit.value;
		priceId = document.addcoupon.priceListId.value;
		couponId = document.addcoupon.discountId.value;
		
		if (validateForm()){
		
			document.addcoupon.action=document.addcoupon.action + "?userAction=discountTime&priceListId=" + priceId +"&addOrEdit=" + addEdit + "&couponId=" + couponId;
			document.addcoupon.submit();

		}
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Add Coupon</H1>
<CENTER>
<FORM id="addcoupon" name="addcoupon" action="AddCoupons.asp" Method = "post">
	<input type="hidden" name="Horde" value="03f8cf1caacb2781342becfcfc94af95" />
	<INPUT type="hidden" name="priceListId" value="<%= priceListId %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEditAction %>">
	<INPUT type="hidden" name="discountId" value="<%= couponId %>">
<TABLE WIDTH="550" BORDER=2 CELLSPACING=0 CELLPADDING=10><!-- header row -->



<TBODY>
	<%
		if addOrEditAction ="edit" then
			getCouponDetails
		end if
	%>
	<%
		if userMessage <> "" then
	%>
	<tr>
		<td colspan=4 style="background:yellow">
			<%=userMessage%>
		</TD>
	</tr>
	<%
		end if
	%>
	
 <tr>
	<td align=left valign=top>
	<TABLE width = 100% border="0" cellpadding="5" cellspacing="0" Style = "MARGIN-LEFT: 8px">
	<tr valign=bottom>
		<td height=30px colspan=4 class=label>Coupon Offer</td>
	</tr>
	<tr>	
		<td align=right>Coupon Name</td>
		<td colspan=3>
			<INPUT Class = text name=couponname Style = "WIDTH:250px" value="<%= name%>">
		</TD>
	</tr>
	<tr>	
		<td align=right>Shortcut</td>
		<td colspan=3>
			<INPUT Class = text name=shortcut Style = "WIDTH:250px" value="<%= shortcut%>">
		</TD>
	</tr>
	<tr>
		<td align=right>Coupon Type</td>
		<td colspan=3 style="white-space: nowrap">
			<SELECT name="coupontype" id="coupontype" STYLE="FONT-SIZE:14px;WIDTH:150px" onChange="adjustDiscSubType();">
				<%
					if discSubType ="Pieces" then
				%>
					<OPTION  Selected  Value = "Pieces">Pieces</OPTION>
					<OPTION  Value = "Amount">Amount</OPTION>
				<%
					else
				%>
					<OPTION  Value = "Pieces">Pieces</OPTION>
					<OPTION  Selected Value = "Amount">Amount</OPTION>
				<%
					end if
				%>
			</SELECT>
                <label for="pieceMinAmt" id="pieceMinAmtLbl">Only Include Items with Cost</label>
                <input type=checkbox id="pieceMinAmt" name="pieceMinAmt" style =margin-left=20px" <% if itemAboveZero then %> checked <% end if %>>
            </td>
		</td>
	</tr>
	<tr>
		<td align=right>Effective Date</td>
		<td colspan=5>
			<INPUT Class = text name=effectdate Style = "WIDTH: 70px;vertical-align:middle;" value="<%= effDate%>" readonly>
			<INPUT class=click id=BttnEffDate name=BttnEffDate type=button value="..." style="width:25px;height:25px;vertical-align:middle;" onClick="javascript:show_calendar('addcoupon.effectdate');">
		&nbsp&nbsp&nbsp
		Expiration Date&nbsp
			<INPUT Class = text name=expDate Style = "WIDTH: 70px;vertical-align:middle;" value="<%= expDate %>" readonly>
			<INPUT class=click id=BttnexpDate name=BttnexpDate type=button value="..." style="width:25px;height:25px;vertical-align:middle;" onClick="javascript:show_calendar('addcoupon.expDate');">
		</TD>
	</tr>
	<tr>
		<td align=right>Max Uses</td>
		<td colspan=5>
			<INPUT Class = text name=noofuses Style = "WIDTH: 70px;vertical-align:middle;" value="<%= noofuses%>" >
			(Leave blank for unlimited)

		</TD>
	</tr>
	
	<!--
	<tr>
		<td>Due Date</td>
		<td>
			<INPUT Class = text name=txtDueDate Style = "WIDTH: 70px;vertical-align:middle;" value="<%= expDate %>" readonly>
			<INPUT class=click id=BttnexpDate name=BttnexpDate type=button value="..." style="width:25px;height:25px;vertical-align:middle;" onClick="javascript:show_calendar('addcoupon.expDate');">
		</td>
	</tr>
	-->
	<tr valign=bottom>
		<td height=30px  colspan=4 class=label>Discount Amount</td>
	</tr>
	<tr>
		<%
			if IsDiscAmt then
		%>
			<td align=right>Discount</td>
			<td>
				<INPUT Class = text name=discount Style = "WIDTH: 80px" value="<%= discountAmt%>">
			&nbsp&nbsp&nbsp
				<Input type= radio name=discountamount value="1" Checked onClick="enableDisableMaxDisc()">&nbsp;&nbsp;Dollars ($)&nbsp&nbsp
				<Input type= radio name=discountamount value="2" onClick="enableDisableMaxDisc()">&nbsp;&nbsp;Percent (%)
			</td>
		<%
			else
		%>
			<td align=right>Discount</td>
			<td>
				<INPUT Class = text name=discount Style = "WIDTH: 80px" value="<%= discountP%>">
			&nbsp&nbsp&nbsp
				<Input type= radio name=discountamount value="1" onClick="enableDisableMaxDisc()">&nbsp;&nbsp;Dollars ($)&nbsp&nbsp
				<Input type= radio name=discountamount value="2" checked onClick="enableDisableMaxDisc()">&nbsp;&nbsp;Percent(%)
			</td>
		<%
			end if
		%>
	</tr>
	<tr>
		<td align=right>Max Discount ($)</td>
		<td>
			<INPUT Class = text name=maxdiscount Style = "WIDTH: 80px" value="<%= maxDiscAmt%>">
		</TD>
	</tr>
	<tr valign=bottom>
		<td height=30px colspan=4 class=label>Invoice Limits</td>
	</tr>
	<tr valign=middle>
		<td align=right>Min/Max Pieces</td>
		<td colspan=5>
			<SELECT name= minpiece STYLE="FONT-SIZE:  15px; HEIGHT: 24px;  WIDTH: 60px" <% if discSubType="Amount" then %> disabled <% end if%>>
				<%
					dim i
					for i=0 to 50
					if discSubType ="Pieces" and (minPiece)=i then
						
				%>
						<OPTION  Value ="<%= i%>" selected><%= i%></OPTION>
				<%
					else
				%>
						<OPTION  Value ="<%= i%>"><%= i%></OPTION>
				<%
					end if
					next
				%>
			</SELECT>
			&nbsp;To&nbsp&nbsp
			<SELECT name= maxpiece STYLE="FONT-SIZE:  15px; HEIGHT: 24px;  WIDTH: 80px" <% if discSubType="Amount" then %> disabled <% end if%>>
				<%
					for i=0 to 50
					if discSubType ="Pieces" and (maxPiece)=i then
						
				%>
						<OPTION  Value ="<%= i%>" selected><%= i%></OPTION>
				<%
					else
				%>
						<OPTION  Value ="<%= i%>"><%= i%></OPTION>
				<%
					end if
					next
				%>
					<OPTION  Value ="-1" <% if (maxPiece) = -1 then%> selected <%end if%>>Unlimited</OPTION>
			</SELECT>  
		</td>
	</tr>
	<tr valign=middle>
		<td align=right>Min/Max Dollar</td>
		<td align=left colspan=5>
			<INPUT Class = text name=minDollar Style = "WIDTH: 80px" value="<%= minDolar%>" <% if discSubType="Pieces" then %> disabled <% end if%>>
			&nbsp;To&nbsp;&nbsp
			<INPUT Class = text name=maxDollar Style = "WIDTH: 80px" value="<%= maxDollar%>" <% if discSubType="Pieces" then %> disabled <% end if%>>  
		</td>		
	</tr>
	<tr><td height=20px></td></tr>
	<tr>
		<%
			if validWithOtherOffer = 1 then
		%>
			<td colspan=4>
					<input type=checkbox name="isvalidwith" style =margin-left=20px value="1" checked>&nbsp;&nbsp;Valid With Other Offers</td>
			</td>
		<%
			else
		%>
			<td colspan=4>
				<input type=checkbox name="isvalidwith" style =margin-left=20px value="1">&nbsp;&nbsp;Valid With Other Offers</td>
			</td>
		<%
			end if
		%>
		

	</tr>
	<tr>
		<td colspan="4">
			<input type=checkbox name="appliesperunit" style="margin-left:20px" value="1"
			<% if appliesPerUnit then %> checked <% end if %>
			>&nbsp;&nbsp;Multiply Discount by Piece Count</input>
		</td>
	</tr>
	<tr>
		<td colspan=6 align=center>
			<INPUT class = click name="appdepartment" type=button value="Applicable Department" style="HEIGHT: 75px; WIDTH: 150px" onClick="submitFormDepartment()">
			<INPUT class = click name="relationship" type=button value="Department Relationship" style="HEIGHT: 75px; WIDTH: 150px" onClick="submitFormRelationship()">
			<INPUT class = click name="addtimerange" type=button value="Applicable Days" style="HEIGHT: 75px; WIDTH: 150px" onClick="addTimeRange()">
		</td>
	</tr>
	<tr height=100px>
		<td colspan=6 align=center>
			<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
		</td></tr>
	</table>
	</td></tr>
</TABLE>
</FORM>
</CENTER>			
</BODY>
</HTML>

