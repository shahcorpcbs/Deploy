<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs, plId, deptId, itemId, descrName, descrType
    plId = trim(getReqVar("plID"))
    deptId = trim(getReqVar("deptId"))
    itemId = trim(getReqVar("itemId"))
    descrName = trim(getReqVar("descrName"))
    descrType = trim(getReqVar("descrType"))
    
    
    dim includeType
    if descrType = "CO" then
        includeType = 1
    elseif descrType = "PA" then
        includeType = 2
    else
        includeType = 3
    end if    
    
    
	if trim(Request.QueryString("useraction")) = "submit" then
		SaveFormData()
	end if



    function SaveFormData()
        dim selectedIds, idArray, currId, xCount
        selectedIds = trim(getReqVar("selectedIds"))

        idArray =  Split(selectedIds, ",")
        For xCount = LBound(idArray) To UBound(idArray)
            currId = idArray(xCount)
            addIndiv(currId)
        Next

        response.redirect "ItemDescrList.asp?plId=" & plId & "&deptId=" & deptId & "&itemId=" & itemId & "&includeType=" & includeType

    end function


    function addIndiv(currItemId)
        query = "Insert into ItemDescriptorPrice(priceListItemId, descriptorName, descriptorType, price, useGlobalTax, " _
            & "useGlobalSurcharge, useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, outsideService, " _
            & "printNotes, prepayPercent, daysToProcess, displaySequence, notes, prepayDiscount, isGlobal) (select " _
            & currItemId & ", descriptorName, descriptorType, price, useGlobalTax, useGlobalSurcharge, useGlobalDays, " _
            & "discountable, VIPDiscountable, VIPQualified, couponable, outsideService, printNotes, prepayPercent, " _
            & "daysToProcess, displaySequence, notes, prepayDiscount, isGlobal from ItemDescriptorPrice " _
            & "where priceListItemId = " & itemId & " and descriptorName = '" & descrName & "' and descriptorType = '" _
            & descrType & "')"
        qryexecute query


        query = "insert into ItemDescriptorTax (PricelistItemId, descriptorName, descriptorType, taxCode, storeId) (select " _
            & currItemId & ", descriptorName, descriptorType, taxCode, storeId from ItemDescriptorTax where priceListItemId = " _
            & itemId & " and descriptorName = '" & descrName & "' and descriptorType = '" & descrType & "')"
        qryexecute query

        query = "insert into ItemDescriptorSurcharge (PricelistItemId, descriptorName, descriptorType, surchargeCode, priceListId) (select " _
            & currItemId & ", descriptorName, descriptorType, surchargeCode, priceListId from ItemDescriptorSurcharge where priceListItemId = " _
            & itemId & " and descriptorName = '" & descrName & "' and descriptorType = '" & descrType & "')"
        qryexecute query

    end function


	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
%>

<html>
<head>
<title>Choose Items for Descriptor <%=descrName%></title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</head>
<SCRIPT type="text/javascript" >

	function selChange(option) {
        var checkboxes = $(this).closest('form').find(':checkbox');
        $('input[type=checkbox]').each(function () {
            this.checked = (option == 1);
        });
	}



function submitForm() {
    var selIds = ""

        var checkboxes = $(this).closest('form').find(':checkbox');
        $('input[type=checkbox]').each(function () {
            if (this.checked)  {
                selIds = selIds + this.id + ",";
            }
        });

    if (selIds.length = 0)
        cancelForm();
    else {
        selIds = selIds.substring(0, selIds.length - 1);
        document.getElementById('selectedIds').value = selIds
        document.chooseDescItemsForm.action = "?useraction=submit";
        document.chooseDescItemsForm.submit();
	}
}

function cancelForm() {
	document.chooseDescItemsForm.action = "/Setup/ItemDescrList.asp?plId=<%=plId%>&deptId=<%=deptId%>&itemId=<%=itemId%>&includeType=<%=includeType%>";
	document.chooseDescItemsForm.submit();
}

</SCRIPT>
<body topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->

<form name="chooseDescItemsForm" action="" method="post" style="margin:0px">
<INPUT type="hidden" name="plId" id="plId" value="<%=plId%>" />
<INPUT type="hidden" name="deptId" id="deptId" value="<%=deptId%>" />
<INPUT type="hidden" name="itemId" id="itemId" value="<%=itemId%>" />
<INPUT type="hidden" name="descrName" id="descrName" value="<%=descrName%>" />
<INPUT type="hidden" name="descrType" id="descrType" value="<%=descrType%>" />
<INPUT type="hidden" name="selectedIds" id="selectedIds" value="" />
<H1>Choose Descriptor Items</H1>

	<TABLE  ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=30px></tr>
		<tr style="text-align: left">
		    <td colspan="2" style="white-space: nowrap;"><input type="radio" name="sel_choice" id="sel_all" value="0" onClick="selChange(1)"><label for="sel_all"><b>Select All</b></label></td>
		    <td colspan="2" style="white-space: nowrap;"><input type="radio" name="sel_choice" id="sel_none" value="1" onClick="selChange(0)"><label for="sel_none"><b>Select None</b></label></td>
        </tr>
        <%
            dim newRow
            newRow = true
            query = "select itemName, priceListItemId from PriceListItem where departmentId = " & deptId _
                & " and priceListId = " & plId & " and priceListItemID not in (select priceListItemID from "_
                & " ItemDescriptorPrice where descriptorName = '" & descrName & "' and descriptorType = '" & descrType & "')"
            set rs = getdisconnectedrecordset(query)
            while not(rs.eof or rs.bof)
        %>
        <% if newRow then %>
        <tr>
        <% end if %>
        <td>
            <%= rs("itemName")%>
        <td>
            <INPUT type=checkbox id="<%=rs("priceListItemId")%>">
        </td>
        <% if not newRow then %>
        </tr>
        <% end if %>
        <%
            newRow = not newRow
            rs.movenext
            wend
            set rs = nothing
        %>



		<tr height=30px></tr>
		<tr>
			<TD colspan="6">
				<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick="submitForm()">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton style="background-image:url(../images/Cancel.gif)" type=button value="" onClick="cancelForm()">
						</TD>
					</tr>
				</table>
			</TD>
		</tr>
		<tr height=100px><td></td></tr>
</table>

</form>

</body>
</html>
