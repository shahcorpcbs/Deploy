<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim actionString
	dim storeId
	dim priceListId
	dim selCouponId
	storeId = Session("storeId")
	priceListId =Request.QueryString("priceListId")
	actionString = Request.QueryString("userAction")
	select case actionString
		case "getCoupons"
					priceListId = Request.QueryString("priceListId")
		case "delete"
					selCouponId = Request.QueryString("couponId")
					deleteCoupon()
	end select
	function getAllPriceTables()
		dim ssql
		dim objResultSet
		ssql ="Select priceListID, name from PriceList where storeId=" & clng(storeId) _
			  & " AND disable=0"
		set objResultSet = getDisconnectedRecordset(ssql)
		if priceListId = "" then
			if objResultSet.RecordCount > 0 then
				objResultSet.moveFirst
				priceListId = objResultSet.Fields("priceListID")
			else
				priceListId = 0
			end if
		end if
		set getAllPriceTables = objResultSet
		
	end function
	
	function getAllCouponsForPriceList()
		dim ssql
		if not IsEmpty(priceListId) then
			ssql ="Select discountId, discountName From discount, discounttypeDomain " _
					& " Where priceListId=" & clng(priceListId) _
					& " AND Discount.discountType = DiscountTypeDomain.discountType " _
					& " AND discountTypeName='Coupon'" _
					& " AND active = 1 "
					
			set getAllCouponsForPriceList = getDisconnectedRecordset(ssql)
		end if
	end function
	
	function deleteCoupon()
		dim ssql
		ssql = "UPDATE Discount SET active = 0 WHERE discountId=" & clng(selCouponId)
		QryExecute(ssql)
	end function
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function submitFormAddItem() {
		var priceListId
		if (document.couponsetup.priceTable.length > 0){
			priceListId =  document.couponsetup.priceTable(document.couponsetup.priceTable.selectedIndex).value
			document.couponsetup.action="AddCoupons.asp?addOrEdit=add&priceListId=" + priceListId;
			document.couponsetup.submit();
		}
	}			
	
	function editCoupon() {
		var priceListId
		var couponId
		if (couponTable.rows.length > 0) {
			if(couponTable.rows.length ==1) 
			{
				if(document.couponsetup.select.checked) {
					couponId = document.couponsetup.select.value;
				}
			}
			else{
				for (var i = 0; i < document.couponsetup.select.length; i++) {
					if(document.couponsetup.select[i].checked){
						couponId = document.couponsetup.select[i].value;
						break;
					}
				}
			}
			priceListId =  document.couponsetup.priceTable(document.couponsetup.priceTable.selectedIndex).value
			document.couponsetup.action="AddCoupons.asp?addOrEdit=edit&priceListId=" + priceListId + "&couponId=" + couponId; 
			document.couponsetup.submit();
		}
	}	
	
	function submitForm() {
		document.couponsetup.action="Coupons.asp"
		document.couponsetup.submit();
	}	
	
	function getCoupons() {
		var priceListId
		priceListId =  document.couponsetup.priceTable(document.couponsetup.priceTable.selectedIndex).value
		document.couponsetup.action = "?userAction=getCoupons&priceListId=" + priceListId;
		document.couponsetup.submit();
	}
	
	function deleteCoupon(){
		var couponId
		if (couponTable.rows.length > 0) {
			if(couponTable.rows.length ==1) 
			{
				if(document.couponsetup.select.checked) {
					couponId = document.couponsetup.select.value;
				}
			}
			else{
				for (var i = 0; i < document.couponsetup.select.length; i++) {
					if(document.couponsetup.select[i].checked){
						couponId = document.couponsetup.select[i].value;
						break;
					}
				}
			}
			document.couponsetup.action = "?userAction=delete&couponId=" + couponId;
			document.couponsetup.submit();
		}
	}
			
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Available Coupons</H1>
<FORM id="couponsetup" name="couponsetup" action="CouponSetup.asp" Method = "post"><input type="hidden" name="Horde" value="03f8cf1caacb2781342becfcfc94af95" />

<TABLE WIDTH="400" BORDER=2 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT:80px"><!-- header row -->
 <tr >
	<td align=left valign=top><br>
	<TABLE width = 300 border="0" cellpadding="0" cellspacing="0" Style = "MARGIN-LEFT: 25px;MARGIN-RIGHT: 25px">
	<tr><td height=40px width=120px align=right>Price Table&nbsp</td>
		<td>
			<SELECT name=priceTable STYLE="FONT-SIZE: 14px;Width =220px;" onChange="getCoupons()">
			<%
				dim rst
				set rst = getAllPriceTables
				
				while not rst.EOF
					
					if clng(priceListId) = rst.Fields("priceListID") then
			%>
				<OPTION value="<%= rst.Fields("priceListID")%>" selected><%= rst.Fields("name")%></option>
			<%
					else
			%>
				<OPTION value="<%= rst.Fields("priceListID")%>"><%= rst.Fields("name")%></option>
			<%
					end if
				rst.MoveNext
				wend
			%>
		</SELECT>
	</td></tr>
	<tr><td  align= left vAlign=top colspan=2> <br><br>
		<DIV STYLE="HEIGHT: 220px; OVERFLOW-X: auto; OVERFLOW-Y: auto; WIDTH: 300px" >
		<TABLE width = 100% style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =1 CELLSPACING=0>
			<tr><td>
			<TABLE name="couponTable" id="couponTable" width = 100% style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =0 CELLSPACING=0>
			<%
				dim iCounter
				set rst = getAllCouponsForPriceList()
				iCounter =1
				while not rst.EOF
					
			%>
				<tr >
					<%
					if iCounter = 1 then
					%> 
						<td width = 10>
							<input type=radio name=select id=select checked value="<%= rst.Fields("DiscountID")%>">
						</td>
					<%
					else
					%>
						<td width = 10>
							<input type=radio name=select id=select value="<%= rst.Fields("DiscountID")%>">
						</td>
					<%
					end if
					%>
					<td><%= rst.Fields("discountName")%></td>
				</tr>
			<%
				rst.MoveNext
				iCounter = iCounter +1
				wend
			%>
			</TABLE>
		</td></tr></table>
		</DIV><br><br>
	</TD>
	<td align= left vAlign=top>
	<TABLE  border="0" cellpadding="5" cellspacing="0">
	<tr><td align= left vAlign=left> <br>
		<INPUT class = click name=add type=button value="Add" onClick="submitFormAddItem()"  style="Height:50;width=100"><br>
		<INPUT class = click name=edit type=button value="Edit" onClick="editCoupon()"  style="Height:50;width=100"><br>
		<INPUT class = click name=delete type=button value="Delete" style="Height:50;width=100" onClick="deleteCoupon();"><br>
	</td></tr>
	</table>
		<tr height=70px valign=top><td align= center width=100% colspan=3> 
		<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" onClick="submitForm()"  style="background-image:url(../images/Cancel.gif)"></td></tr>
		<br><br>
	</td></tr>
	</TABLE>
	</td></tr>
	</TABLE></FORM>
</BODY>
</HTML>

