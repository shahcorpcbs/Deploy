<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<!--#include file="../include/queryParamFunctions.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%

	dim query, rs
    dim addoredit, custSchId, useraction, userQueryId, reportId, params
    dim l_queryName, l_query, l_frequency, l_active, l_hour, l_dayOfWeek, l_day, l_sendAtt, l_message, l_jobName
    dim l_formatType, l_subject, l_formId, l_reportId, l_sendGrid

	addoredit = trim(Request.QueryString("addoredit"))
    custSchId = trim(Request.QueryString("schId"))
    userQueryId = trim(Request.QueryString("userQueryId"))
    reportId = trim(Request.QueryString("reportId"))
    l_sendGrid = getMSVar("useSendGrid")


	if trim(Request.QueryString("useraction")) = "submit" then
	    if userQueryId <> "" then
            queryTemplate = getUserQuery(userQueryId)
            set params = getQueryParams(queryTemplate)
            SaveFormData()
       else
            SaveReportData()
       end if
	end if

    if addoredit = "edit" then
            query = "select ecs.id, ecs.userQueryId, ecs.subject, ecs.reportId, name, ecs.frequency, ecs.active, ecs.hour, "_
                & "ecs.dayOfWeek, ecs.day, ecs.sendAsAttachment, ecs.query, ecs.formatType, ecs.message, ecs.formId " _
                & "from EmailCustomerSchedule ecs "  _
                & " where ecs.id = " & custSchId
        set rs = getdisconnectedrecordset(query)

       userQueryId = rs("userQueryId")
       reportId = rs("reportId")
       l_jobName = rs("name")
       l_frequency = rs("frequency")
       l_active = rs("active")
       l_hour = rs("hour")
       l_dayOfWeek = rs("dayOfWeek")
       l_day = rs("day")
       l_sendAtt = rs("sendAsAttachment")
       l_query = rs("query")
       l_subject = rs("subject")
       l_message = rs("message")
       l_formId = rs("formId")
       l_formatType = rs("formatType")

       if userQueryId <> "" then
            query = "select name from userQuery where userQueryId = " & userQueryId
            set rs = getdisconnectedrecordset(query)
            l_queryName = rs("name")
            set params = getQueryParams(l_query)
            reportId = ""
       else
            if reportId = 25 then
                l_queryname = "AR Statement"
            else
                l_queryname = "AR Multi-Pickup Statement"
            end if

            createReportParams(reportId)

       end if
    else
        l_active = true
        l_frequency = 0
        if userQueryId <> "" then
            query = "select name from userQuery where userQueryId = " & userQueryId
            set rs = getdisconnectedrecordset(query)
            l_jobName = rs("name")
            dim queryTemplate
            queryTemplate = getUserQuery(userQueryId)
            set params = getQueryParams(queryTemplate)
        end if

        if reportId <> "" then
            if reportId = 25 then
                l_jobName = "AR Statement"
            else
                l_jobName = "AR Multi-Pickup Statement"
            end if
            createReportParams(reportId)
        end if

    end if

    function SaveReportData()
        dim reportId, frequencyType, active, hour, dayofWeek, day, sendAtt, queryTransformed, dateString, message, subject, formatType, jobName
        dim newId

		reportId = trim(Request.QueryString("reportId"))
		frequencyType = trim(Request.QueryString("frequency"))
		active = trim(Request.QueryString("active"))
		hour = trim(Request.QueryString("hourOfDay"))
		dayofWeek = trim(Request.QueryString("dayofWeek"))
		day = trim(Request.QueryString("dayOfMonth"))
		sendAtt = trim(Request.QueryString("sendAtt"))
		dateString = trim(Request.QueryString("dateString"))
		jobName = trim(Request.QueryString("jobName"))
		subject = trim(Request.QueryString("subject"))
		message = trim(Request.QueryString("message"))
		formatType = trim(Request.QueryString("formatType"))

        if addoredit = "edit" then
            query = "Update EmailCustomerSchedule set Frequency = " & frequencyType
            query = query &  ", Active = " & active
            query = query &  ", hour = " & hour
            query = query &  ", dayOfWeek = " & dayOfWeek
            query = query &  ", day = " & day
            query = query &  ", SendAsAttachment = " & sendAtt
            query = query &  ", FormatType = " & formatType
            query = query &  ", Query = '" & DBStr(queryTransformed)
            query = query &  "', Subject = '" & DBStr(subject)
            query = query &  "', Name = '" & DBStr(jobName)
            query = query &  "', Message = '" & DBStr(message)
            query = query & "' where id = " & custSchId
            qryexecute query

            query = "delete EmailReportVariable where CustEmailSchId = " & custSchId
            qryexecute query
        else
            query = "Insert into EmailCustomerSchedule(Name, ReportId, Active, Frequency, Hour, DayOfWeek, Day, " _
                & "SendAsAttachment, Query, Subject, Message, FormatType) values ('"
            query = query & DBStr(jobName) & "', "
            query = query & DBStr(reportId) & ", "
            query = query & DBStr(active) & ", "
            query = query & DBStr(frequencyType) & ", "
            query = query & DBStr(hour) & ", "
            query = query & DBStr(dayofWeek) & ", "
            query = query & DBStr(day) & ", "
            query = query & DBStr(sendAtt) & ", '"
            query = query & DBStr(queryTransformed) & "', '"
            query = query & DBStr(subject) & "', '"
            query = query & DBStr(message) & "', "
            query = query & DBStr(formatType) & ")"

			openConnection
			dbInsert query
			set rs = dbselect("select @@IDENTITY as rowid")
			custSchId = rs("rowid")
			set rs = nothing
			closeconnection
        end if

        dim queryStart
        queryStart = "Insert into EmailReportVariable(CustEmailSchId, VariableName, VariableValue) values (" & custSchId & ", '"


        query = queryStart & "StartDate', '" & DBStr(trim(Request.QueryString("dateString"))) & "')"
        qryexecute query

        query = queryStart & "statementDate', '" & DBStr(trim(Request.QueryString("stmtString"))) & "')"
        qryexecute query

        query = queryStart & "statementDueDate', '" & DBStr(trim(Request.QueryString("dueString"))) & "')"
        qryexecute query

        query = queryStart & "PriceListId', '" & DBStr(trim(Request.QueryString("plId"))) & "')"
        qryexecute query

        query = queryStart & "RouteId', '" & DBStr(trim(Request.QueryString("routeId"))) & "')"
        qryexecute query

        query = queryStart & "ShowDetail', '" & DBStr(trim(Request.QueryString("showDetail"))) & "')"
        qryexecute query

        query = queryStart & "IncludeActive', '" & DBStr(trim(Request.QueryString("incAct"))) & "')"
        qryexecute query

        query = queryStart & "ShowZeroBal', '" & DBStr(trim(Request.QueryString("showZero"))) & "')"
        qryexecute query

        query = queryStart & "ExcludeNegativeBalances', '" & DBStr(trim(Request.QueryString("excNeg"))) & "')"
        qryexecute query

        response.redirect "custEmailReportSetup.asp"
    end function

    function SaveFormData()
        dim reportId, frequencyType, active, hour, dayofWeek, day, sendAtt, queryTransformed, dateString, emailField
        dim message, formId, subject, formatType, jobName

        jobName = trim(Request.QueryString("jobName"))
		reportId = trim(Request.QueryString("userQueryId"))
		frequencyType = trim(Request.QueryString("frequency"))
		active = trim(Request.QueryString("active"))
		hour = trim(Request.QueryString("hourOfDay"))
		dayofWeek = trim(Request.QueryString("dayofWeek"))
		day = trim(Request.QueryString("dayOfMonth"))
		sendAtt = trim(Request.QueryString("sendAtt"))
		dateString = trim(Request.QueryString("dateString"))
		emailField = "email"
		subject = trim(Request.QueryString("subject"))
		message = trim(Request.QueryString("message"))
		formId = trim(Request.QueryString("formId"))
		formatType = trim(Request.QueryString("formatType"))

	    queryTransformed = transformQuery(queryTemplate, params, request.form, dateString)

        if addoredit = "edit" then
            query = "Update EmailCustomerSchedule set Frequency = " & frequencyType
            query = query &  ", Active = " & active
            query = query &  ", hour = " & hour
            query = query &  ", dayOfWeek = " & dayOfWeek
            query = query &  ", day = " & day
            query = query &  ", SendAsAttachment = " & sendAtt
            query = query &  ", FormatType = " & formatType
            query = query &  ", Query = '" & DBStr(queryTransformed)
            query = query &  "', EmailField = '" & DBStr(emailField)
            query = query &  "', Name = '" & DBStr(jobName)
            query = query &  "', Subject = '" & DBStr(subject)
            query = query &  "', Message = '" & DBStr(message)
            query = query &  "', FormId = '" & DBStr(formId)
            query = query & "' where id = " & custSchId
        else
            query = "Insert into EmailCustomerSchedule(Name, userQueryId, Active, Frequency, Hour, DayOfWeek, Day, " _
                & "SendAsAttachment, Query, EmailField, Subject, Message, FormatType, FormId) values ('"
            query = query & DBStr(jobName) & "', "
            query = query & DBStr(reportId) & ", "
            query = query & DBStr(active) & ", "
            query = query & DBStr(frequencyType) & ", "
            query = query & DBStr(hour) & ", "
            query = query & DBStr(dayofWeek) & ", "
            query = query & DBStr(day) & ", "
            query = query & DBStr(sendAtt) & ", '"
            query = query & DBStr(queryTransformed) & "', '"
            query = query & DBStr(emailField) & "', '"
            query = query & DBStr(subject) & "', '"
            query = query & DBStr(message) & "', "
            query = query & DBStr(formatType) & ", '"
            query = query & DBStr(formId) & "')"
        end if
        qryexecute query

        response.redirect "custEmailReportSetup.asp"
    end function

    function createReportParams(reportId)
        dim result, query, rs, queryStart, defPl, defRId, defStartD, defSD, defDD, defSID, defIAI, defSZB, defENB
        if custSchId <> "" then
            queryStart = "select VariableValue vv from EmailReportVariable where CustEmailSchId = " & custSchId & " and VariableName = '"
            query = queryStart & "PriceListId'"
            set rs = getdisconnectedrecordset(query)
            defPl = rs("vv")

            query = queryStart & "RouteId'"
            set rs = getdisconnectedrecordset(query)
            defRId = rs("vv")

            query = queryStart & "StartDate'"
            set rs = getdisconnectedrecordset(query)
            defStartD = rs("vv")

            query = queryStart & "statementDate'"
            set rs = getdisconnectedrecordset(query)
            defSD = rs("vv")

            query = queryStart & "statementDueDate'"
            set rs = getdisconnectedrecordset(query)
            defDD = rs("vv")

            query = queryStart & "ShowDetail'"
            set rs = getdisconnectedrecordset(query)
            defSID = rs("vv")

            query = queryStart & "IncludeActive'"
            set rs = getdisconnectedrecordset(query)
            defIAI = rs("vv")

            query = queryStart & "ShowZeroBal'"
            set rs = getdisconnectedrecordset(query)
            defSZB = rs("vv")

            query = queryStart & "ExcludeNegativeBalances'"
            set rs = getdisconnectedrecordset(query)
            defENB = rs("vv")
        else
            defPl = -1
            defRId = -1
            defStartD = 7
            defSD = ""
            defDD = ""
            defSID = 0
            defIAI = 0
            defSZB = 0
            defENB = 0
        end if

        set result = CreateObject("Scripting.Dictionary")
        addParam result, "Price_List", "pricelist", defPl, 0, 0
        addParam result, "Route", "route", defRId, 0, 0
        addParam result, "Start_Date", "date", defStartD, 0, 0
        addParam result, "Statement_Date", "date", defSD, 0, 0
        addParam result, "Due_Date", "date", defDD, 0, 0
        addParam result, "Show_Invoice_Details", "bit", defSID, 0, 0
        addParam result, "Include_Active_Invoices", "bit", defIAI, 0, 0
        addParam result, "Show_Zero_Balance_Statements", "bit", defSZB, 0, 0
        addParam result, "Exclude_Negative_Balance_Statements", "bit", defENB, 0, 0
        set params = result
    end function


	function getUserQuery(userQueryId)
		dim query, rs

		query = " select query from userQuery where userQueryId = " & userQueryId
		set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
			getUserQuery = rs("query")
		end if
	end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

%>

<html>
<head>
<title>Edit Customer Email Schedule</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</head>
<script language="javascript" src="../external/jquery.js"></script>
<script language="javascript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">

function submitForm() {
    <% if addoredit = "add" then %>
    var reportId = $.trim(document.getElementById('reportId').value);
    if (reportId === "") {
        cbs_alert("Need to select a report");
        return;
    }
    <% end if %>


    var jobName = $.trim(document.getElementById('jobName').value);
     if (jobName === "") {
         cbs_alert("Need to set a Job Name");
         return;
     }

    var subject = $.trim(document.getElementById('subject').value);
     if (subject === "") {
         cbs_alert("Need to set a subject");
         return;
     }

    var myRadio = $("input[name=frequency]");
    var checkedValue = myRadio.filter(":checked").val();
    if (checkedValue == "") {
        cbs_alert("Need to select a frequency");
        return;
    }

    var isActive = document.getElementById('active').checked ? "1" : "0";
    <% if l_sendGrid then %>
    var sendAtt = document.getElementById('sendAtt').checked ? "1" : "0";
    <% else %>
    var sendAtt = "0";
    <% end if %>

    var dateString = ""
    if (document.getElementById('dateField') != null) {
        dateString = document.getElementById('dateField').value;
        if (dateString == 5) {
            var start = document.getElementById('start_Date').value;
            var end = document.getElementById('end_Date').value;
            if (start == "") {
                cbs_alert("If using custom date, then start date must be entered")
                return;
            }
            else if (end == "") {
                cbs_alert("If using custom date, then end date must be entered")
                return;
            }
            dateString = dateString + "_" + start + "_" + end;
        }
    }
    <% if reportId <> "" then %>
        var stmtDateString = document.getElementById('Statement_Date_sel').value;
        if (stmtDateString == 5) {
            var start = document.getElementById('Statement_Date_custDate').value;
            if (start == "") {
                cbs_alert("If using custom date, then statement date must be entered")
                return;
            }
            stmtDateString = stmtDateString + "_" + start;
        }
        var dueDateString = document.getElementById('Due_Date_sel').value;
        if (dueDateString == 5) {
            var start = document.getElementById('Due_Date_custDate').value;
            if (start == "") {
                cbs_alert("If using custom date, then due date must be entered")
                return;
            }
            dueDateString = dueDateString + "_" + start;
        }

        document.editCustReportForm.action = "?useraction=submit" +
    	    "&addoredit=<%=addoredit%>" +
    	    "&schId=<%=custSchId%>" +
    	    "&reportId=<%=reportId%>" +
    	    "&hourOfDay=" + $("#hourOfDay").val() +
    	    "&dayOfWeek=" + $("#dayOfWeek").val() +
    	    "&dayOfMonth=" + $("#dayOfMonth").val() +
            "&frequency=" + checkedValue +
            "&active=" + isActive +
            "&sendAtt=" + sendAtt +
    	    "&dateString=" + encodeURIComponent(dateString) +
    	    "&stmtString=" + encodeURIComponent(stmtDateString) +
    	    "&dueString=" + encodeURIComponent(dueDateString) +
    	    "&plId=" + encodeURIComponent($("#Price_List").val()) +
    	    "&routeId=" + encodeURIComponent($("#Route").val()) +
    	    "&showDetail=" + encodeURIComponent($("#Show_Invoice_Details").val()) +
    	    "&incAct=" + encodeURIComponent($("#Include_Active_Invoices").val()) +
    	    "&showZero=" + encodeURIComponent($("#Show_Zero_Balance_Statements").val()) +
    	    "&excNeg=" + encodeURIComponent($("#Exclude_Negative_Balance_Statements").val()) +
    	    "&jobName=" + encodeURIComponent(jobName) +
    	    "&subject=" + encodeURIComponent(subject) +
    	    "&message=" + encodeURIComponent($("#newMessage").val()) +
    	    <% if l_sendGrid then %>
    	    "&formatType=" + encodeURIComponent($("#formatType").val());
    	    <% else %>
    	    "&formatType=1"
    	    <% end if %>
    <% else %>
        document.editCustReportForm.action = "?useraction=submit" +
            "&addoredit=<%=addoredit%>" +
            "&schId=<%=custSchId%>" +
            "&userQueryId=<%=userQueryId%>" +
            "&hourOfDay=" + $("#hourOfDay").val() +
            "&dayOfWeek=" + $("#dayOfWeek").val() +
            "&dayOfMonth=" + $("#dayOfMonth").val() +
            "&frequency=" + checkedValue +
            "&active=" + isActive +
            "&sendAtt=" + sendAtt +
            "&dateString=" + encodeURIComponent(dateString) +
    	    "&jobName=" + encodeURIComponent(jobName) +
            "&subject=" + encodeURIComponent(subject) +
            "&message=" + encodeURIComponent($("#newMessage").val()) +
    	    "&formId=" + encodeURIComponent($("#formId").val()) +
    	    <% if l_sendGrid then %>
    	    "&formatType=" + encodeURIComponent($("#formatType").val());
    	    <% else %>
    	    "&formatType=1"
    	    <% end if %>
	<% end if %>
	document.editCustReportForm.submit();
}

function updateDateFields() {
    var myRadio = $("input[name=frequency]");
    var checkedValue = parseInt(myRadio.filter(":checked").val());


    if (checkedValue === 0 || checkedValue === 1 || checkedValue === 4) {   //Once, manual or hourly
        $("#hourRow").css("display", "none");
        $("#dayOfWeekRow").css("display", "none");
        $("#dayOfMonthRow").css("display", "none");
    }
    else if (checkedValue === 2) {  //Daily
        $("#hourRow").css("display", "");
        $("#dayOfWeekRow").css("display", "none");
        $("#dayOfMonthRow").css("display", "none");
    }
    else if (checkedValue === 3) {  //Monthly
        $("#hourRow").css("display", "");
        $("#dayOfWeekRow").css("display", "none");
        $("#dayOfMonthRow").css("display", "");
    }
    else if (checkedValue === 5) {  //Weekly
        $("#hourRow").css("display", "");
        $("#dayOfWeekRow").css("display", "");
        $("#dayOfMonthRow").css("display", "none");
    }

    $("#hourOfDay").val(<%=l_hour%>)
    $("#dayOfWeek").val(<%=l_dayOfWeek%>)
    $("#dayOfMonth").val(<%=l_day%>)

}

function getRptParams() {
    var reportId = $.trim(document.getElementById('reportId').value);
	var action = "?useraction=reload" +
	    "&addoredit=<%=addoredit%>" +
	    "&schId=<%=custSchId%>";
	if (reportId == "-1")
	    action = action + "&reportId=25";
	else if (reportId == "-2")
	    action = action + "&reportId=27";
	else
	    action = action + "&userQueryId=" + encodeURIComponent(reportId);

	document.editCustReportForm.action = action;
	document.editCustReportForm.submit();
}

function showHideDates() {
    var dateSel = document.getElementById('dateField').value;
    if (dateSel == 5) {
        document.getElementById('start_Date').style.visibility = "visible";
        document.getElementById('end_Date').style.visibility = "visible";
    }
    else {
        document.getElementById('start_Date').style.visibility = "hidden";
        document.getElementById('end_Date').style.visibility = "hidden";
    }
}

function showHideOtherDates(dateField) {
    var dateSel = document.getElementById(dateField + "_sel").value;
    if (dateSel == 5) {
        document.getElementById(dateField + '_custDate').style.visibility = "visible";
        document.getElementById(dateField + '_custDate').style.margin = "10px";
    }
    else {
        document.getElementById(dateField + '_custDate').style.visibility = "hidden";
    }
}

function cancelForm() {
	document.editCustReportForm.action = "custEmailReportSetup.asp";
	document.editCustReportForm.submit();
}

</SCRIPT>
<body topmargin=0 leftmargin=0 onload="updateDateFields()"><!-- #include file="../include/banner.inc" -->

<form name="editCustReportForm" action="" method="post" style="margin:0px">

<BR>


	<TABLE ALIGN=center WIDTH="600px" style="white-space: nowrap" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px></tr>
		<th>Schedule Email to Customers</th>
<tr>
    <tr>
        <td>Job Name</td>
        <td>
            <INPUT TYPE="text" id="jobName" value="<%=l_jobName%>"></input>
        </td>
    </tr>
    <td>Customer to Email</td>
    <td>
        <% if addoredit = "edit" then %>
            <%= l_queryName %>
        <% else %>
			<SELECT id="reportId" onchange="getRptParams()">
                <option value="">Select Query</option>
                <option value="-1" <% if reportId = "25" then%> selected <%end if %>>AR Statement</option>
                <option value="-2" <% if reportId = "27" then%> selected <%end if %>>AR Multi-Pickup Statement</option>
                <% dim query3, rs3

                    query3 = "select userQueryId, name from userQuery where query like '%email%' and name not like '%Missing Email%' order by name"
                    set rs3 = getdisconnectedrecordset(query3)
                     while not(rs3.eof or rs3.bof) %>
                     <option value="<%=rs3("userQueryId")%>"
                            <% if userQueryId = cstr(rs3("userQueryId")) then %>
                            selected
                            <% end if %>
                     ><%=rs3("name")%></option>
                        <% rs3.movenext
                    wend %>
			</SELECT>
		<% end if %>
    </td>
</tr>
<tr>
    <td>Active</td>
    <td>
        <% if l_active then %>
            <input type="checkbox" id="active" checked>
        <% else %>
            <input type="checkbox" id="active">
        <% end if %>
    </td>
</tr>
<tr>
    <td>Frequency</td>
    <td colspan="3">
        <label for="manual">
        <Input type=Radio name=frequency value="0" onclick="updateDateFields()" id="manual"
        	<% if l_frequency = "0" then %>
        		CHECKED
        	<% end if %>
        	>Manual Only</label>
        <label for="daily">
        <Input type=Radio name=frequency value="2" onclick="updateDateFields()" id="daily"
        	<% if l_frequency = "2" then %>
        		CHECKED
        	<% end if %>
        	>Daily</label>
        <label for="weekly">
        <Input type=Radio name=frequency value="5" onclick="updateDateFields()" id="weekly"
        	<% if l_frequency = "5" then %>
        		CHECKED
        	<% end if %>
        	>Weekly</label>
        <label for="monthly">
        <Input type=Radio name=frequency value="3" onclick="updateDateFields()" id="monthly"
        	<% if l_frequency = "3" then %>
        		CHECKED
        	<% end if %>
        	>Monthly</label>
    </td>
</tr>
<tr id="hourRow" style="display: none">
    <td>Hour of Day</td>
    <td>
        <SELECT id=hourOfDay STYLE="font-size:16px;">
            <option value="0">12 AM</option>
            <option value="1">1 AM</option>
            <option value="2">2 AM</option>
            <option value="3">3 AM</option>
            <option value="4">4 AM</option>
            <option value="5">5 AM</option>
            <option value="6">6 AM</option>
            <option value="7">7 AM</option>
            <option value="8">8 AM</option>
            <option value="9">9 AM</option>
            <option value="10">10 AM</option>
            <option value="11">11 AM</option>
            <option value="12">12 PM</option>
            <option value="13">1 PM</option>
            <option value="14">2 PM</option>
            <option value="15">3 PM</option>
            <option value="16">4 PM</option>
            <option value="17">5 PM</option>
            <option value="18">6 PM</option>
            <option value="19">7 PM</option>
            <option value="20">8 PM</option>
            <option value="21">9 PM</option>
            <option value="22">10 PM</option>
            <option value="23">11 PM</option>
        </SELECT>
    </td>
</tr>
<tr id="dayOfWeekRow" style="display: none">
    <td>Day of Week</td>
    <td>
        <SELECT id=dayOfWeek STYLE="font-size:16px;">
            <option value="1">Sunday</option>
            <option value="2">Monday</option>
            <option value="3">Tuesday</option>
            <option value="4">Wednesday</option>
            <option value="5">Thursday</option>
            <option value="6">Friday</option>
            <option value="7">Saturday</option>
        </SELECT>
    </td>
</tr>
<tr id="dayOfMonthRow" style="display: none">
    <td>Day of Month</td>
    <td>
        <SELECT id=dayOfMonth STYLE="font-size:16px;">
            <option value="1">1st</option>
            <option value="2">2nd</option>
            <option value="3">3rd</option>
            <option value="4">4th</option>
            <option value="5">5th</option>
            <option value="6">6th</option>
            <option value="7">7th</option>
            <option value="8">8th</option>
            <option value="9">9th</option>
            <option value="10">10th</option>
            <option value="11">11th</option>
            <option value="12">12th</option>
            <option value="13">13th</option>
            <option value="14">14th</option>
            <option value="15">15th</option>
            <option value="16">16th</option>
            <option value="17">17th</option>
            <option value="18">18th</option>
            <option value="19">19th</option>
            <option value="20">20th</option>
            <option value="21">21st</option>
            <option value="22">22nd</option>
            <option value="23">23rd</option>
            <option value="24">24th</option>
            <option value="25">25th</option>
            <option value="26">26th</option>
            <option value="27">27th</option>
            <option value="28">28th</option>
            <option value="0">Last Day</option>
        </SELECT>
    </td>
</tr>
<tr>
    <td>Subject</td>
    <td>
        <INPUT TYPE="text" id="subject" value="<%=l_subject%>"></input>
    </td>
</tr>
<tr>
    <td>Message</td>
    <td>
        <textarea id="newMessage" cols="50" rows="10" ><%=l_message%></textarea>
    </td>
</tr>
<% if reportId = "" then %>
<tr>
    <td>Form</td>
    <td>
        <select id="formId">
            <option value="0">none</option>
			<%
				query = " select formid, name from htmlform "
				set rs = getdisconnectedrecordset(query)

				while not(rs.eof or rs.bof)
			%>
			<OPTION value="<%=rs("formid")%>" <% if rs("formId") = l_formId then%>selected<% end if %>><%=server.htmlencode(rs("name"))%></OPTION>
			<%
				rs.movenext
				wend
				set rs = nothing
			%>
        </select>
    </td>
</tr>
<% end if %>
<% if l_sendGrid then %>
<tr>
    <td>Send As Attachment</td>
    <td>
        <% if l_sendAtt then %>
            <input type="checkbox" id="sendAtt" checked>
        <% else %>
            <input type="checkbox" id="sendAtt">
        <% end if %>
    </td>
</tr>
<tr>
    <td>Format Type</td>
    <td>
        <SELECT id=formatType STYLE="font-size:16px;">
            <option value="1" <% if l_formatType = 1 then %> selected <% end if %>>HTML</option>
            <option value="2" <% if l_formatType = 2 then %> selected <% end if %>>CSV</option>
            <option value="3" <% if l_formatType = 3 then %> selected <% end if %>>PDF</option>
        </SELECT>
    </td>
</tr>
<% end if %>


<% if userQueryId <> "" or reportId <> "" then %>

    <tr height="50px"><td></td></tr>
    <tr><td colspan=2><b>Variables:</b></td></tr>
<%
	dim item
	dim listedParameters

	set listedParameters = Server.CreateObject("Scripting.Dictionary")

	if ubound(params.items) >= 0 then
	for each item in params.items
		if not listedParameters.exists(replace(item.paramName, "@", "")) then
			listedParameters.add item.paramName, ""
%>
    <% if item.paramName <> "End_Date" then %>
        <TR>
            <TD>
                 <% if item.paramName = "Start_Date" then %>
                    Date Range
                 <% else %>
                    <%=Server.HTMLEncode(Replace(item.paramName, "_", " ") )%>
                 <% end if %>
            </TD>
            <TD>
                <% if reportId <> "" then %>
                    <%= getParamField(item, request.form(item.paramName), 1)%>
                <% else %>
                    <%= getParamField(item, request.form(item.paramName), 0)%>
                <% end if %>
            </TD>
        </TR>
    <% end if %>
<%
		end if
	next
	else
%>
	<TR>
		<TD colspan="2">This query does not have any parameters.</TD>
	</TR>
<%
	end if
%>
<%
	end if
%>
</TABLE>


<TABLE ALIGN=center WIDTH="500px" BORDER=0 CELLSPACING=1 CELLPADDING=5>
		<tr height=30px></tr>
		<tr>
			<td></td>
			<TD>
				<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick="submitForm()">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton style="background-image:url(../images/Cancel.gif)" type=button value="" onClick="cancelForm()">
						</TD>
					</tr>
				</table>
			</TD>
		</tr>
</TABLE>

</form>

</body>
</html>
