<!--#INCLUDE FILE="../include/loader.asp"-->
<!-- #INCLUDE FILE="../include/AdoConstants.inc" -->
<!-- #INCLUDE FILE="../include/ValidateFunction.asp" -->

<%

ON Error resume next
   dim errNumber 
   errNumber = 0
   dim errMessage
   errMessage = "no error"
   dim localDict 
   Set localDict = Server.CreateObject("Scripting.Dictionary")
 	

   Response.Buffer = True
  sub TrapError(errNum,errMsg)
       errNumber = errNum
      errMessage = errMsg
 end sub 
	Dim load
		Set load = new Loader
		load.initialize
		Err.Clear

	'systwm data 
	Dim countElements
		countElements = load.Count
	Dim topKey
	    topKey = load.getValue("topKey")		
	Dim editLevel
	    editLevel = load.getValue("editLevel")		    
	Dim stID
	    stID = load.getValue("storeid")
    Dim ids
		ids = load.getValue("ids")
    Dim imgfile
		imgfile = load.getValue("imageFileName")
    Dim emailForm
		emailForm = load.getValue("emailFormName")
	Dim emailText
		emailText = load.getValue("emailText")		
    Dim releaseForm
		releaseForm = load.getValue("itemReleaseInvoiceForm")		
	Dim action
		action = load.getValue("action")		
  'application data ' text fields
	Dim nameInput 
		nameInput = load.getValue("name")
	Dim price
		price = load.getValue("price")
	Dim taxString
		taxString = load.getValue("tax")		
	Dim quantity
		quantity = load.getValue("qtyInInventory")	
	Dim days
		days = load.getValue("days")		
	Dim surchargeString
		surchargeString = load.getValue("surcharge")		
	Dim prepay
		prepay = load.getValue("prepayPercent")		
	Dim maxItem
		maxItem = load.getValue("maxItemInReceipt")	
	Dim notes
		notes = load.getValue("itemnotes")	
'application data ' check boxes
	Dim disable
		disable = load.getValue("disabled")	
	Dim UGTax
		UGTax = load.getValue("useGlobalTax")			
	Dim UGDays
		UGDays = load.getValue("useGlobalDays")							
	Dim splitInvoice
		splitInvoice = load.getValue("splitInvoice")	
	Dim discountable
		discountable = load.getValue("discountable")	
	Dim VIPDiscountable
		VIPDiscountable = load.getValue("VIPDiscountable")							
	Dim VIPQualified
		VIPQualified = load.getValue("VIPQualified")		
	Dim saleOnly
		saleOnly = load.getValue("saleOnly")						
	Dim couponable
		couponable = load.getValue("couponable")
	Dim outsideService
		outsideService = load.getValue("outsideService")
	Dim printNotes
		printNotes = load.getValue("printNotes")
    Dim desType
		desType = load.getValue("desType")	
	Dim displaySequence
		displaySequence = load.getValue("displaySequence")
	Dim prepayDiscount
		prepayDiscount = load.getValue("prepayDiscount")
		
					
	Dim splits
	
		splits=Split(ids,"~$~")

	Dim id
	Dim newID 'used in insert option
	Dim priceListId


	Dim surchargeCodes
	  surchargeCodes = Split(surchargeString,",")
 Response.Write "inside for"
	dim idkey
	dim desName

	dim desId
	dim splitKey
	dim sequence
	dim pkType
	 dim cmd
    dim icounter
 ON Error resume next
Set oConn = Server.CreateObject("ADODB.Connection")
      dim ors 							     
Set ors = Server.CreateObject("ADODB.Recordset")
dim dsnString

 
dsnString = Session("shahcorpDSN")
'oConn.Open "DSN=shahcorp;uid=shahcorp;pwd=shahcorp"
oConn.Open dsnString

oConn.CursorLocation = adUseClient
if Err.number <> 0 then 
 	 TrapError Err.number,Err.Description 
end if	

      if InStr(topKey, "TABLE") <> 0 then
	    splitKey =  split(topKey,"TABLE")
	    topKey = splitKey(1)
	    ' adding dummy keys to work with tables
	    splits=Split("TABLE0","$")
      end if
	  if InStr(topKey, "DEPT") <> 0 then
	    splitKey =  split(topKey,"DEPT")
	    topKey = splitKey(1)
	  end if
	  if InStr(topKey, "ITEM") <> 0 then
	    splitKey =  split(topKey,"ITEM")
	    topKey = splitKey(1)
	  end if
	  ' else edit level is in sub items topkey not required
call update
  
sub update()
	  Response.Write """" & "start" & """"
 	  'oConn.BeginTrans 

	  
 For iCounter = LBound(splits) To UBound(splits)
	 Set cmd = Server.CreateObject("ADODB.Command")
	 Set cmd.ActiveConnection = oConn
	  if editLevel = "ITEM" then
	      cmd.CommandText = "dbo.copyItems"
	  elseif editLevel = "DEPT" then
	  	  cmd.CommandText = "dbo.copyDepartments"
	  elseif editLevel = "TABLE" then
	  	  cmd.CommandText = "dbo.copyTables"
	  elseif editLevel = "CO" or editLevel = "PA" or editLevel = "UP" then
	   Response.Write "for subitems"
	   	  cmd.CommandText = "dbo.UpdateSubItems"
	   	  action = "INSERT"
	  end if
	  cmd.CommandType = adCmdStoredProc
	  idkey = splits(icounter)
	  if InStr(idkey, "|") <> 0 then
	    splitKey =  split(idkey,"|")
	    desId = splitKey(2)
	    desName = splitKey(1)
	    desType = splitKey(0)
	    idkey = desId
	    pkType = "SUBITEM"
	    Response.write " pkType :" & pkType
	  end if
	  if InStr(idkey, "TABLE") <> 0 then
	    splitKey =  split(idkey,"TABLE")
	    desId = splitKey(1)
	    pkType = "TABLE"
	    idkey = desId
	    desName = nameInput
	  end if
	  if InStr(idkey, "DEPT") <> 0 then
	   splitKey =  split(idkey,"DEPT")
	    desId = splitKey(1)
	    pkType = "DEPT"
	    idkey = desId
	    desName = nameInput
	  end if
	  if InStr(idkey, "ITEM") <> 0 then
	    splitKey =  split(idkey,"ITEM")
	    desId = splitKey(1)
	    pkType = "ITEM"
	    idkey = desId
	    desName = nameInput
	  end if
 


	  Response.Write idkey
	 ' ON Error resume next
	    Dim objParam 
       With cmd
  
         Set objParam = .CreateParameter("RetVal", adInteger, adParamReturnValue)
         .Parameters.Append objParam
 			Response.Write " z1"        
         if editLevel = "CO" or editLevel = "PA" or editLevel = "UP" then
         else
           Response.Write " z2"
            Set objParam = .CreateParameter("topKey", adInteger, adParamInput, , topKey)
      		.Parameters.Append objParam 
	     end if
			Response.Write " z3"	     
         if editlevel = "TABLE" then
          Set objParam = .CreateParameter("primaryKey", adInteger, adParamInput, , NULL)
         else	          
          Set objParam = .CreateParameter("primaryKey", adInteger, adParamInput, , idkey)
         end if
       '  cmd("primaryKey") = 1
			.Parameters.Append objParam
			Response.Write " z4"
		 Set objParam = .CreateParameter("pkType", adVarChar, adParamInput, 10, pkType)
         	.Parameters.Append objParam
		 Set objParam = .CreateParameter("action", adVarChar, adParamInput, 10, action)
        	.Parameters.Append objParam
				Response.Write " z2"		
         Set objParam = .CreateParameter("editLevel", adVarChar, adParamInput, 10, editLevel)
          .Parameters.Append objParam
			
         Set objParam = .CreateParameter("storeid", adInteger, adParamInput,, stID)
         			.Parameters.Append objParam
			
         Set objParam = .CreateParameter("disableItem", adInteger, adParamInput, , disable)
         			.Parameters.Append objParam
	Response.Write " a"		
         Set objParam = .CreateParameter("useGT", adInteger, adParamInput, , UGTax)
         			.Parameters.Append objParam
			
         Set objParam = .CreateParameter("useGD", adInteger, adParamInput, , UGDays)
        			.Parameters.Append objParam
         Set objParam = .CreateParameter("splitTicket", adInteger, adParamInput, , splitInvoice)
        			.Parameters.Append objParam		
        Set objParam = .CreateParameter("discountable", adInteger, adParamInput, , discountable )
        			.Parameters.Append objParam	
        Set objParam = .CreateParameter("VIPDiscountable", adInteger, adParamInput, , VIPDiscountable )
        			.Parameters.Append objParam	 
        Set objParam = .CreateParameter("VIPQualified ", adInteger, adParamInput, , VIPQualified  )
        			.Parameters.Append objParam	     
        Set objParam = .CreateParameter("salesOnly ", adInteger, adParamInput, , saleOnly  )
        			.Parameters.Append objParam
        Set objParam = .CreateParameter("coupon", adInteger, adParamInput, , couponable  )
        			.Parameters.Append objParam	           				        			   			       				
        Set objParam = .CreateParameter("outsideService", adInteger, adParamInput, , outsideService  )
        			.Parameters.Append objParam	  
        Set objParam = .CreateParameter("printItemNotes", adInteger, adParamInput, , printNotes   )
        			.Parameters.Append objParam	     
    Response.Write " b"		    			
        		  Response.Write " check valye :" & (nameInput)   			
        		  
    Set objParam = .CreateParameter("ItemName", adVarChar, adParamInput, 30, (nameInput)  )
         		.Parameters.Append objParam
         		
	if not isnull(price) and len(trim(price))<> 0 then
         Set objParam = .CreateParameter("price", adDecimal, adParamInput, , price)
	else
	     Set objParam = .CreateParameter("price", adDecimal, adParamInput, , NULL)
	end if          
         	objParam.Precision = 38
		    objParam.NumericScale = 2
		   .Parameters.Append objParam
		   
   Set objParam = .CreateParameter("tax", adVarChar, adParamInput, 30, (taxString) )
  		.Parameters.Append objParam		
  		
        		Response.Write " b1"		   
		        Response.Write " d1"
		        
   if not isnull(quantity) and len(trim(quantity))<> 0 then
         Set objParam = .CreateParameter("qty", adDecimal, adParamInput, , quantity)
   else
	     Set objParam = .CreateParameter("qty", adDecimal, adParamInput, , NULL)
   end if                
		   objParam.Precision = 38
           objParam.NumericScale = 2
           .Parameters.Append objParam
                 Response.Write " d2"
                 
    if not isnull(days) and len(trim(days))<> 0 then
         Set objParam = .CreateParameter("days", adDecimal, adParamInput, , days)
   else
	     Set objParam = .CreateParameter("days", adDecimal, adParamInput, , NULL)
   end if                
            objParam.Precision = 38
            objParam.NumericScale = 2
           .Parameters.Append objParam
                  Response.Write " d3"	                		        		
                  
  Set objParam = .CreateParameter("surcharg", adVarChar, adParamInput, 30,surchargeString )
     		.Parameters.Append objParam
  	

   if not isnull(prepay) and len(trim(prepay))<> 0 then
         Set objParam = .CreateParameter("prepay", adDecimal, adParamInput, ,prepay)
   else
	     Set objParam = .CreateParameter("prepay", adDecimal, adParamInput, , NULL)
   end if  			 
      	 objParam.Precision = 38
		 objParam.NumericScale = 2
		 .Parameters.Append objParam
				Response.Write " d4"  
				
    if not isnull(maxItem) and len(trim(maxItem))<> 0 then
         Set objParam = .CreateParameter("maxItem", adDecimal, adParamInput, , maxItem)
    else
	     Set objParam = .CreateParameter("maxItem", adDecimal, adParamInput, , NULL)
    end if  			 
             objParam.Precision = 38
		     objParam.NumericScale = 2
			.Parameters.Append objParam
							     			
	 Set objParam = .CreateParameter("itemNotes", adVarChar, adParamInput,500, (notes) )
        .Parameters.Append objParam 
        		    Response.Write " b2"

           		    	 
	 Set objParam = .CreateParameter("graphIcon", adVarChar, adParamInput, 100, (imgfile) )
        	.Parameters.Append objParam
        	
    if not isnull(releaseForm) and len(trim(releaseForm))<> 0 then     		
		 Set objParam = .CreateParameter("ItemRelease", adVarChar, adParamInput,100, (releaseForm) )
    else
	 Set objParam = .CreateParameter("ItemRelease", adVarChar, adParamInput,100, NULL )    		 
    end if     		
		  .Parameters.Append objParam
		          		
    if not isnull(emailForm) and len(trim(emailForm))<> 0 then     		
		 Set objParam = .CreateParameter("emailText", adVarChar, adParamInput,100, (emailForm) )
    else
	 Set objParam = .CreateParameter("emailText", adVarChar, adParamInput,100, NULL )    		 
    end if
        	.Parameters.Append objParam
        		

if editLevel = "CO" or editLevel = "PA" or editLevel = "UP" then		  
   Response.Write "SUB ITEM LEVEL"
    if not isnull(desType) and len(trim(desType))<> 0 then          		
       Set objParam = .CreateParameter("subItemType", adVarChar, adParamInput,10, desType )
    else
      Set objParam = .CreateParameter("subItemType", adVarChar, adParamInput,10, desType )    		         		       		         		
    end  if
        	.Parameters.Append objParam
        		 
    if not isnull(desName) and len(trim(desName))<> 0 then          		
       Set objParam = .CreateParameter("subItemName", adVarChar, adParamInput,100, desName )
    else
      Set objParam = .CreateParameter("subItemName", adVarChar, adParamInput,100, desName )    		         		       		         		
    end if   
            .Parameters.Append objParam   	
            
			
		if not isnull(displaySequence) and len(trim(displaySequence))<> 0 then
			Set objParam = .CreateParameter("displaySequence", adInteger, adParamInput, , displaySequence)
		else
			Set objParam = .CreateParameter("displaySequence", adInteger, adParamInput, , NULL)
		end if  			 

		.Parameters.Append objParam

		if not isnull(prepayDiscount) and len(trim(prepayDiscount))<> 0 then
			Set objParam = .CreateParameter("prepayDiscount", adDecimal, adParamInput, , prepayDiscount)
		else
			Set objParam = .CreateParameter("prepayDiscount", adDecimal, adParamInput, , 0)
		end if          
		objParam.Precision = 38
		objParam.NumericScale = 2
		.Parameters.Append objParam
            
            
 end if           	 
     Response.Write " c "	   		        		        		
     Response.Write " d "	
     ON Error resume next	
          dim resultValue  	    							     
              .Execute
  set objErr = Server.CreateObject ("ADODB.Error")
    For Each objErr in oConn.Errors 
        if objErr.NativeError  = 50000 then
   		  	 errNumber = objErr.number
 		  	 errMessage = Replace(objErr.Description ,"[Microsoft][ODBC SQL Server Driver][SQL Server]","")
 		  	 exit sub
 		 end if
 	next	  	 
               
 
      	if Err.number <> 0 then 
       	   'Response.Write Err.Description
 		  	 errNumber = Err.number
 		  	 errMessage = Err.Description 
 		   	 oConn.RollbackTrans 
	         exit sub
		 end if	
       
      End With	      
		  

next
 'oConn.CommitTrans 
 Response.Write "after comminting0"
end sub
'ors.Close
oConn.Close
 Response.Write "after comminting1"

set ors=nothing
set oConn=nothing
 Response.Write "after comminting2"

'error display code	

%>
<html>		
<body id=<%=errNumber%>>
  <%=errNumber%><%=errMessage%>
 <form name="resultForm">
 <!-- <input type="text" name="sql" size="40" value=<%=sSQL%>  >
  <input type="text" name="objname" size="40" value=<%=nameInput%>  >
  <input type="text" name="editlevel" size="40" value=<%=action%>  >
  <input type="text" name="ids" size="40" value=<%=ids%>  >
  <input type="text" name="disabled1" size="40" value=<%=disable%>  >-->
  <INPUT TYPE="text" name="error"   value="<%=errNumber%>">
  <INPUT TYPE="text" name="message"  value="<%=errMessage%>">  
  <INPUT TYPE="hidden" name="error"   value="<%=errNumber%>">
  <INPUT TYPE="hidden" name="message"  value="<%=errMessage%>">
 </form>
</body>
</html>
		
	




