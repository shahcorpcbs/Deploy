<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<!--#include file="../include/queryParamFunctions.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%

	dim query, rs
    dim addoredit, emailSchId, useraction, userQueryId, params, l_sendGrid
    dim l_queryName, l_query, l_frequency, l_active, l_hour, l_dayOfWeek, l_day, l_sendAtt, l_formatType

	addoredit = trim(Request.QueryString("addoredit"))
    emailSchId = trim(Request.QueryString("schId"))
    userQueryId = trim(Request.QueryString("userQueryId"))
    l_sendGrid = getMSVar("useSendGrid")

    dim query2, rs2

	if trim(Request.QueryString("useraction")) = "submit" then
        queryTemplate = getUserQuery(userQueryID)
        set params = getQueryParams(queryTemplate)
		SaveFormData()
	end if

    if addoredit = "edit" then
        query = "select erq.id, erq.userQueryId, uq.Name queryName, erq.frequency, erq.active, erq.hour, erq.dayOfWeek, erq.day, "_
            & "erq.sendAsAttachment, erq.query, erq.formatType from EmailReportSchedule erq, UserQuery uq where erq.id = "  _
            & emailSchId & " and erq.userQueryId = uq.userQueryId"
        set rs = getdisconnectedrecordset(query)

       userQueryID = rs("userQueryId")
       l_queryName = rs("queryName")
       l_frequency = rs("frequency")
       l_active = rs("active")
       l_hour = rs("hour")
       l_dayOfWeek = rs("dayOfWeek")
       l_day = rs("day")
       l_sendAtt = rs("sendAsAttachment")
       l_query = rs("query")
       l_formatType = rs("formatType")

        set params = getQueryParams(l_query)
    else
        l_active = true
        l_frequency = 0
        if userQueryId <> "" then
            dim queryTemplate
            queryTemplate = getUserQuery(userQueryID)
            set params = getQueryParams(queryTemplate)
        end if
    end if

    function SaveFormData()
        dim reportId, frequencyType, active, hour, dayofWeek, day, sendAtt, queryTransformed, dateString, newId, formatType

		reportId = trim(Request.QueryString("userQueryId"))
		frequencyType = trim(Request.QueryString("frequency"))
		active = trim(Request.QueryString("active"))
		hour = trim(Request.QueryString("hourOfDay"))
		dayofWeek = trim(Request.QueryString("dayofWeek"))
		day = trim(Request.QueryString("dayOfMonth"))
		sendAtt = trim(Request.QueryString("sendAtt"))
		dateString = trim(Request.QueryString("dateString"))
		formatType = trim(Request.QueryString("formatType"))

	    queryTransformed = transformQuery(queryTemplate, params, request.form, dateString)

        if addoredit = "edit" then
            query = "Update EmailReportSchedule set Frequency = " & frequencyType
            query = query &  ", Active = " & active
            query = query &  ", hour = " & hour
            query = query &  ", dayOfWeek = " & dayOfWeek
            query = query &  ", day = " & day
            query = query &  ", formatType = " & formatType
            query = query &  ", Query = '" & DBStr(queryTransformed)
            query = query & "' where id = " & emailSchId
            qryexecute query
        else
            query = "Insert into EmailReportSchedule(UserQueryId, Active, Frequency, Hour, DayOfWeek, Day, FormatType, SendAsAttachment, Query) values ("
            query = query & DBStr(reportId) & ", "
            query = query & DBStr(active) & ", "
            query = query & DBStr(frequencyType) & ", "
            query = query & DBStr(hour) & ", "
            query = query & DBStr(dayofWeek) & ", "
            query = query & DBStr(day) & ", "
            query = query & DBStr(formatType) & ", "
            query = query & DBStr(sendAtt) & ", '"
            query = query & DBStr(queryTransformed) & "')"

			openConnection
			dbInsert query
			set rs = dbselect("select @@IDENTITY as rowid")
			newId = rs("rowid")
			set rs = nothing
			closeconnection
        end if

        if addoredit = "add" and newId <> "" then
            response.redirect "editEmployeeEmailReports.asp?schId=" & newId
        else
            response.redirect "empEmailReportSetup.asp"
        end if
    end function


	function getUserQuery(userqueryid)
		dim query, rs

		query = " select query from userquery where userqueryid = " & userqueryid
		set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
			getUserQuery = rs("query")
		end if
	end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

%>

<html>
<head>
<title>Edit Email Schedule</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</head>
<script language="javascript" src="../external/jquery.js"></script>
<script language="javascript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">

function submitForm() {
    <% if addoredit = "add" then %>
    var reportId = $.trim(document.getElementById('reportId').value);
    if (reportId === "") {
        cbs_alert("Need to select a report");
        return;
    }
    <% end if %>

    var myRadio = $("input[name=frequency]");
    var checkedValue = myRadio.filter(":checked").val();
    if (checkedValue == "") {
        cbs_alert("Need to select a frequency");
        return;
    }

    var isActive = document.getElementById('active').checked ? "1" : "0";
    <% if l_sendGrid then %>
    var sendAtt = document.getElementById('sendAtt').checked ? "1" : "0";
    <% else %>
    var sendAtt = "0";
    <% end if %>


    var dateString = ""
    if (document.getElementById('dateField') != null) {
        dateString = document.getElementById('dateField').value;
        if (dateString == 5) {
            var start = document.getElementById('start_Date').value;
            var end = document.getElementById('end_Date').value;
            if (start == "") {
                cbs_alert("If using custom date, then start date must be entered")
                return;
            }
            else if (end == "") {
                cbs_alert("If using custom date, then end date must be entered")
                return;
            }
            dateString = dateString + "_" + start + "_" + end;
        }
    }

	document.editEmpReportForm.action = "?useraction=submit" +
	    "&addoredit=<%=addoredit%>" +
	    "&schId=<%=emailSchId%>" +
        <% if addoredit = "add" then %>
	    "&userQueryId=" + encodeURIComponent(reportId) +
	    <% else %>
	    "&userQueryId=<%=userQueryId%>" +
	    <% end if %>
	    "&hourOfDay=" + $("#hourOfDay").val() +
	    "&dayOfWeek=" + $("#dayOfWeek").val() +
	    "&dayOfMonth=" + $("#dayOfMonth").val() +
        "&frequency=" + checkedValue +
        "&active=" + isActive +
        "&sendAtt=" + sendAtt +
    	<% if l_sendGrid then %>
    	"&formatType=" + encodeURIComponent($("#formatType").val()) +
    	<% else %>
    	"&formatType=1" +
    	<% end if %>
	    "&dateString=" + encodeURIComponent(dateString);
	document.editEmpReportForm.submit();
}

function updateDateFields() {
    var myRadio = $("input[name=frequency]");
    var checkedValue = parseInt(myRadio.filter(":checked").val());


    if (checkedValue === 0 || checkedValue === 1 || checkedValue === 4) {   //Once, manual or hourly
        $("#hourRow").css("display", "none");
        $("#dayOfWeekRow").css("display", "none");
        $("#dayOfMonthRow").css("display", "none");
    }
    else if (checkedValue === 2) {  //Daily
        $("#hourRow").css("display", "");
        $("#dayOfWeekRow").css("display", "none");
        $("#dayOfMonthRow").css("display", "none");
    }
    else if (checkedValue === 3) {  //Monthly
        $("#hourRow").css("display", "");
        $("#dayOfWeekRow").css("display", "none");
        $("#dayOfMonthRow").css("display", "");
    }
    else if (checkedValue === 5) {  //Weekly
        $("#hourRow").css("display", "");
        $("#dayOfWeekRow").css("display", "");
        $("#dayOfMonthRow").css("display", "none");
    }

    $("#hourOfDay").val(<%=l_hour%>)
    $("#dayOfWeek").val(<%=l_dayOfWeek%>)
    $("#dayOfMonth").val(<%=l_day%>)

}

function getRptParams() {
    var reportId = $.trim(document.getElementById('reportId').value);
	document.editEmpReportForm.action = "?useraction=reload" +
	    "&addoredit=<%=addoredit%>" +
	    "&schId=<%=emailSchId%>" +
	    "&userQueryId=" + encodeURIComponent(reportId);
	document.editEmpReportForm.submit();
}

function showHideDates() {
    var dateSel = document.getElementById('dateField').value;
    if (dateSel == 5) {
        document.getElementById('start_Date').style.visibility = "visible";
        document.getElementById('end_Date').style.visibility = "visible";
    }
    else {
        document.getElementById('start_Date').style.visibility = "hidden";
        document.getElementById('end_Date').style.visibility = "hidden";
    }
}

function cancelForm() {
	document.editEmpReportForm.action = "empEmailReportSetup.asp";
	document.editEmpReportForm.submit();
}

</SCRIPT>
<body topmargin=0 leftmargin=0 onload="updateDateFields()"><!-- #include file="../include/banner.inc" -->

<form name="editEmpReportForm" action="" method="post" style="margin:0px">

<BR>


	<TABLE ALIGN=center WIDTH="600px" style="white-space: nowrap" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px></tr>
<tr>
    <td>Report</td>
    <td>
        <% if addoredit = "edit" then %>
            <%= l_queryName %>
        <% else %>
			<SELECT id="reportId" onchange="getRptParams()">
			<option value="">Select Report</option>
			<% dim query3, rs3

			    query3 = "select userQueryId, name from userQuery order by name"
                set rs3 = getdisconnectedrecordset(query3)
                 while not(rs3.eof or rs3.bof) %>
                 <option value="<%=rs3("userQueryId")%>"
                        <% if userQueryId = cstr(rs3("userQueryId")) then %>
                        selected
                        <% end if %>
                 ><%=rs3("name")%></option>
                    <% rs3.movenext
                wend %>
			</SELECT>
		<% end if %>
    </td>
</tr>
<tr>
    <td>Active</td>
    <td>
        <% if l_active then %>
            <input type="checkbox" id="active" checked>
        <% else %>
            <input type="checkbox" id="active">
        <% end if %>
    </td>
</tr>
<tr>
    <td>Frequency</td>
    <td colspan="3">
        <label for="manual">
        <Input type=Radio name=frequency value="0" onclick="updateDateFields()" id="daily"
        	<% if l_frequency = "0" then %>
        		CHECKED
        	<% end if %>
        	>Manual Only</label>
        <label for="daily">
        <Input type=Radio name=frequency value="2" onclick="updateDateFields()" id="daily"
        	<% if l_frequency = "2" then %>
        		CHECKED
        	<% end if %>
        	>Daily</label>
        <label for="weekly">
        <Input type=Radio name=frequency value="5" onclick="updateDateFields()" id="weekly"
        	<% if l_frequency = "5" then %>
        		CHECKED
        	<% end if %>
        	>Weekly</label>
        <label for="monthly">
        <Input type=Radio name=frequency value="3" onclick="updateDateFields()" id="monthly"
        	<% if l_frequency = "3" then %>
        		CHECKED
        	<% end if %>
        	>Monthly</label>
    </td>
</tr>
<tr id="hourRow" style="display: none">
    <td>Hour of Day</td>
    <td>
        <SELECT id=hourOfDay STYLE="font-size:16px;">
            <option value="0">12 AM</option>
            <option value="1">1 AM</option>
            <option value="2">2 AM</option>
            <option value="3">3 AM</option>
            <option value="4">4 AM</option>
            <option value="5">5 AM</option>
            <option value="6">6 AM</option>
            <option value="7">7 AM</option>
            <option value="8">8 AM</option>
            <option value="9">9 AM</option>
            <option value="10">10 AM</option>
            <option value="11">11 AM</option>
            <option value="12">12 PM</option>
            <option value="13">1 PM</option>
            <option value="14">2 PM</option>
            <option value="15">3 PM</option>
            <option value="16">4 PM</option>
            <option value="17">5 PM</option>
            <option value="18">6 PM</option>
            <option value="19">7 PM</option>
            <option value="20">8 PM</option>
            <option value="21">9 PM</option>
            <option value="22">10 PM</option>
            <option value="23">11 PM</option>
        </SELECT>
    </td>
</tr>
<tr id="dayOfWeekRow" style="display: none">
    <td>Day of Week</td>
    <td>
        <SELECT id=dayOfWeek STYLE="font-size:16px;">
            <option value="1">Sunday</option>
            <option value="2">Monday</option>
            <option value="3">Tuesday</option>
            <option value="4">Wednesday</option>
            <option value="5">Thursday</option>
            <option value="6">Friday</option>
            <option value="7">Saturday</option>
        </SELECT>
    </td>
</tr>
<tr id="dayOfMonthRow" style="display: none">
    <td>Day of Month</td>
    <td>
        <SELECT id=dayOfMonth STYLE="font-size:16px;">
            <option value="1">1st</option>
            <option value="2">2nd</option>
            <option value="3">3rd</option>
            <option value="4">4th</option>
            <option value="5">5th</option>
            <option value="6">6th</option>
            <option value="7">7th</option>
            <option value="8">8th</option>
            <option value="9">9th</option>
            <option value="10">10th</option>
            <option value="11">11th</option>
            <option value="12">12th</option>
            <option value="13">13th</option>
            <option value="14">14th</option>
            <option value="15">15th</option>
            <option value="16">16th</option>
            <option value="17">17th</option>
            <option value="18">18th</option>
            <option value="19">19th</option>
            <option value="20">20th</option>
            <option value="21">21st</option>
            <option value="22">22nd</option>
            <option value="23">23rd</option>
            <option value="24">24th</option>
            <option value="25">25th</option>
            <option value="26">26th</option>
            <option value="27">27th</option>
            <option value="28">28th</option>
            <option value="0">Last Day</option>
        </SELECT>
    </td>
</tr>

<% if l_sendGrid then %>
<tr>
    <td>Send Report As Attachment</td>
    <td>
        <% if l_sendAtt then %>
            <input type="checkbox" id="sendAtt" checked>
        <% else %>
            <input type="checkbox" id="sendAtt">
        <% end if %>
    </td>
</tr>

<tr>
    <td>Format Type</td>
    <td>
        <SELECT id=formatType STYLE="font-size:16px;">
            <option value="1" <% if l_formatType = 1 then %> selected <% end if %>>HTML</option>
            <option value="2" <% if l_formatType = 2 then %> selected <% end if %>>CSV</option>
            <option value="3" <% if l_formatType = 3 then %> selected <% end if %>>PDF</option>
        </SELECT>
    </td>
</tr>
<% end if %>


<% if userQueryId <> "" then %>

    <tr height="50px"><td></td></tr>
    <tr><td colspan=2><b>Variables:</b></td></tr>
<%
	dim item
	dim listedParameters

	set listedParameters = Server.CreateObject("Scripting.Dictionary")

	if ubound(params.items) >= 0 then
	for each item in params.items
		if not listedParameters.exists(replace(item.paramName, "@", "")) then
			listedParameters.add item.paramName, ""
%>
    <% if item.paramName <> "End_Date" then %>
        <TR>
            <TD>
                 <% if item.paramName = "Start_Date" then %>
                    Date Range
                 <% else %>
                    <%=Server.HTMLEncode(Replace(item.paramName, "_", " ") )%>
                 <% end if %>
            </TD>
            <TD>
                <%=getParamField(item, request.form(item.paramName), 0)%>

            </TD>
        </TR>
    <% end if %>
<%
		end if
	next
	else
%>
	<TR>
		<TD colspan="2">This query does not have any parameters.</TD>
	</TR>
<%
	end if
%>
<%
	end if
%>
</TABLE>


<TABLE ALIGN=center WIDTH="500px" BORDER=0 CELLSPACING=1 CELLPADDING=5>
		<tr height=30px></tr>
		<tr>
			<td></td>
			<TD>
				<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick="submitForm()">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton style="background-image:url(../images/Cancel.gif)" type=button value="" onClick="cancelForm()">
						</TD>
					</tr>
				</table>
			</TD>
		</tr>
</TABLE>

</form>

</body>
</html>
