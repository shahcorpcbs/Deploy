<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/processor.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
    dim employeeId, addoredit
    dim useraction
    dim canSms, canEmail, use_clearent

    employeeId = trim(Request.QueryString("employeeId"))
	addoredit = trim(Request.QueryString("addoredit"))

    canSms = getMSVar("useTwilio")
    canEmail = getMSVar("useEmail")
    determineIfClearent


	if trim(Request.QueryString("useraction")) = "submit" then
		SaveFormData()
	end if

    if addoredit = "edit" then
		query = "select e.employeeId, e.employeeName, e.email, e.phone, "_
		    & " a.sms voidSms, a.email voidEmail, "_
		    & " b.sms arrSms, b.email arrEmail, "_
		    & " c.sms unhSms, c.email unhEmail, "_
		    & " d.sms handSms, d.email handEmail, "_
		    & " f.sms voidIncSms, f.email voidIncEmail, "_
		    & " g.sms credAddSms, g.email credAddEmail, "_
		    & " h.sms cdoSms, h.email cdoEmail "_
		    & " from employee e, EmployeeMessageSetup a, EmployeeMessageSetup b, EmployeeMessageSetup c, EmployeeMessageSetup d, "_
		    & " EmployeeMessageSetup f, EmployeeMessageSetup g, EmployeeMessageSetup h "_
		    & " where e.employeeId = " & employeeId & " and a.employeeId = e.employeeId and a.messageId = 1 and "_
		    & " b.employeeId = e.employeeId and b.messageId = 2 and "_
		    & " c.employeeId = e.employeeId and c.messageId = 3 and "_
		    & " d.employeeId = e.employeeId and d.messageId = 4 and "_
		    & " f.employeeId = e.employeeId and f.messageId = 5 and "_
		    & " g.employeeId = e.employeeId and g.messageId = 6 and "_
		    & " h.employeeId = e.employeeId and h.messageId = 7 "_
		    & " order by employeeName"

		set rs = getdisconnectedrecordset(query)
    end if

    function SaveFormData()
        dim queryPrefix
        dim voidSms, voidEmail, arrSms, arrEmail, unhSms, unhEmail, handSms, handEmail
        dim voidIncSms, voidIncEmail, credAddSms, credAddEmail, cdoSms, cdoEmail

        if canSms then
            voidSms = Request.QueryString("voidSmsSel")
            arrSms = Request.QueryString("arrSmsSel")
            unhSms = Request.QueryString("unhSmsSel")
            handSms = Request.QueryString("handSmsSel")
            voidIncSms = Request.QueryString("voidIncSmsSel")
            credAddSms = Request.QueryString("credAddSmsSel")
            cdoSms = Request.QueryString("cdoSmsSel")
        else
            voidSms = 0
            arrSms = 0
            unhSms = 0
            handSms = 0
            voidIncSms = 0
            credAddSms = 0
            cdoSms = 0
        end if

        if canEmail then
            voidEmail = Request.QueryString("voidEmailSel")
            arrEmail = Request.QueryString("arrEmailSel")
            unhEmail = Request.QueryString("unhEmailSel")
            handEmail = Request.QueryString("handEmailSel")
            voidIncEmail = Request.QueryString("voidIncEmailSel")
            credAddEmail = Request.QueryString("credAddEmailSel")
            cdoEmail = Request.QueryString("cdoEmailSel")
        else
            voidEmail = 0
            arrEmail = 0
            unhEmail = 0
            handEmail = 0
            voidIncEmail = 0
            credAddEmail = 0
            cdoEmail = 0
        end if


        if addoredit = "edit" then
            query = "delete EmployeeMessageSetup where messageId is not null and employeeId = " & employeeId
            qryexecute query

        end if
        
        if voidSms <> 0 or arrSms <> 0 or unhSms <> 0 or handSms <> 0 or voidEmail <> 0 or arrEmail <> 0 or _
            unhEmail <> 0 or handEmail <> 0 or voidIncSms <> 0 or voidIncEmail <> 0 or credAddSms <> 0 or _
            credAddEmail <> 0  or cdoSms <> 0 or cdoEmail  then

            queryPrefix = "Insert into EmployeeMessageSetup(EmployeeId, MessageId, Sms, Email) values (" & employeeId & ", "
            query = queryPrefix + "1, " & voidSms & ", " & voidEmail & ")"
            qryexecute query

            query = queryPrefix + "2, " & arrSms & ", " & arrEmail & ")"
            qryexecute query

            query = queryPrefix + "3, " & unhSms & ", " & unhEmail & ")"
            qryexecute query

            query = queryPrefix + "4, " & handSms & ", " & handEmail & ")"
            qryexecute query

            query = queryPrefix + "5, " & voidIncSms & ", " & voidIncEmail & ")"
            qryexecute query

            query = queryPrefix + "6, " & credAddSms & ", " & credAddEmail & ")"
            qryexecute query

            query = queryPrefix + "7, " & cdoSms & ", " & cdoEmail & ")"
            qryexecute query
        
        end if

        response.redirect "employeeAlerts.asp"
    end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function
%>

<html>
<head>
<title>Employee Alerts SetUp</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
<SCRIPT type="text/javascript" >

function init() {
    <% if addoredit = "edit" then %>
        <% if canSms then %>
            <% if use_clearent = 1 then %>
                document.getElementById("voidSmsSel").value = <%= rs("voidSms") %>;
            <% end if %>
            document.getElementById("arrSmsSel").value = <%= rs("arrSms") %>;
            document.getElementById("unhSmsSel").value = <%= rs("unhSms") %>;
            document.getElementById("handSmsSel").value = <%= rs("handSms") %>;
            document.getElementById("voidIncSmsSel").value = <%= rs("voidIncSms") %>;
            document.getElementById("credAddSmsSel").value = <%= rs("credAddSms") %>;
            document.getElementById("cdoSmsSel").value = <%= rs("cdoSms") %>;
        <% end if %>

        <% if canEmail then %>
            <% if use_clearent = 1 then %>
                document.getElementById("voidEmailSel").value = <%= rs("voidEmail") %>;
            <% end if %>
            document.getElementById("arrEmailSel").value = <%= rs("arrEmail") %>;
            document.getElementById("unhEmailSel").value = <%= rs("unhEmail") %>;
            document.getElementById("handEmailSel").value = <%= rs("handEmail") %>;
            document.getElementById("voidIncEmailSel").value = <%= rs("voidIncEmail") %>;
            document.getElementById("credAddEmailSel").value = <%= rs("credAddEmail") %>;
            document.getElementById("cdoEmailSel").value = <%= rs("cdoEmail") %>;
        <% end if %>
    <% end if %>
}


function submitForm() {
    <% if addoredit = "add" then %>
        if (document.getElementById("employee").value === "") {
            cbs_alert("Employee must be selected");
            return;
        }
    <% end if %>

	document.editEmployeeAlertForm.action = "?useraction=submit" +
	    "&addoredit=<%=addoredit%>" +
	    <% if addoredit = "edit" then %>
	        "&employeeId=<%=employeeId%>" +
	    <% else %>
	        "&employeeId=" + document.getElementById("employee").value +
	    <% end if %>

	    <% if canSms then %>
	        <% if use_clearent = 1 then %>
                "&voidSMSSel=" + document.getElementById("voidSmsSel").value +
            <% else %>
                "&voidSMSSel=" + "0" +
	        <% end if %>
            "&arrSmsSel=" + document.getElementById("arrSmsSel").value +
            "&unhSmsSel=" + document.getElementById("unhSmsSel").value +
            "&handSmsSel=" + document.getElementById("handSmsSel").value +
            "&voidIncSmsSel=" + document.getElementById("voidIncSmsSel").value +
            "&credAddSmsSel=" + document.getElementById("credAddSmsSel").value +
            "&cdoSmsSel=" + document.getElementById("cdoSmsSel").value +
        <% end if %>


	    <% if canEmail then %>
	        <% if use_clearent = 1 then %>
                "&voidEmailSel=" + document.getElementById("voidEmailSel").value +
            <% else %>
                "&voidEmailSel=" + "0" +
            <% end if %>
            "&arrEmailSel=" + document.getElementById("arrEmailSel").value +
            "&unhEmailSel=" + document.getElementById("unhEmailSel").value +
            "&handEmailSel=" + document.getElementById("handEmailSel").value +
            "&voidIncEmailSel=" + document.getElementById("voidIncEmailSel").value +
            "&credAddEmailSel=" + document.getElementById("credAddEmailSel").value +
            "&cdoEmailSel=" + document.getElementById("cdoEmailSel").value +
        <% end if %>
        "";

    //alert(document.editEmployeeAlertForm.action);
	document.editEmployeeAlertForm.submit();
}

function cancelForm() {
	document.editEmployeeAlertForm.action = "employeeAlerts.asp";
	document.editEmployeeAlertForm.submit();
}

</SCRIPT>
</head>
<body topmargin=0 leftmargin=0 onload="init()"><!-- #include file="../include/banner.inc" -->

<form name="editEmployeeAlertForm" action="" method="post" style="margin:0px">

	<TABLE ALIGN=center WIDTH="500px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px></tr>
<tr>
    <td>Employee Name</td>
    <td>
        <% if addoredit = "add" then %>
            <select id="employee" required>
                <option value=""></option>
            <%
                query = "select employee.employeeId, employee.employeeName from employee where employeeId not in "
                query = query & " (select employeeId from EmployeeMessageSetup where messageId is not null) and employeestatus = 'A' "
                query = query & " and (employee.email is not null or phone is not null) order by lastname "
                set rs = getdisconnectedrecordset(query)

                while not(rs.eof or rs.bof)
            %>
                <option value="<%=rs("employeeId")%>" ><%=rs("employeeName")%></option>
            <%
			    rs.movenext
                wend
            %>
            </select>
        <% else %>
            <%=rs("employeeName") %>
        <% end if %>
    </td>
</tr>
<% if addoredit = "edit" then %>
    <tr>
        <td>Employee Phone</td>
        <td><%=rs("phone") %></td>
    </tr>
    <tr>
        <td>Employee Email</td>
        <td><%=rs("email") %></td>
        </tr>
    <tr>

<% end if %>
</tr>
</TABLE>
<br /><br /><br />
    <table ALIGN=center WIDTH="500px" BORDER=0 CELLSPACING=1 CELLPADDING=5>
        <tr style="text-align: left">
            <th>Message Type</th>
            <% if canSms then %>
                <th>SMS Notification</th>
            <% end if %>
            <% if canEmail then %>
                <th>Email Notification</th>
            <% end if %>
        </tr>
        <% if use_clearent = 1 then %>
            <tr>
                <td>Payment Voids</td>
                       <% if canSms then %>
                            <td>
                                <select id="voidSmsSel" name="voidSmsSel" required>
                                    <option value="0">Never</option>
                                    <option value="1">When Clocked In</option>
                                    <option value="2">Always</option>
                                </select>
                            </td>
                        <%end if %>
                       <% if canEmail then %>
                            <td>
                                <select id="voidEmailSel" name="voidEmailSel" required>
                                    <option value="0">Never</option>
                                    <option value="1">When Clocked In</option>
                                    <option value="2">Always</option>
                                </select>
                           </td>
                       <% end if %>
                </tr>
            <% end if %>
            <tr>
                <td>Arrived</td>
                   <% if canSms then %>
                    <td>
                        <select id="arrSmsSel" required>
                            <option value="0">Never</option>
                            <option value="1">When Clocked In</option>
                            <option value="2">Always</option>
                        </select>
                   </td>
                    <%end if %>
                   <% if canEmail then %>
                        <td>
                            <select id="arrEmailSel" required>
                                <option value="0">Never</option>
                                <option value="1">When Clocked In</option>
                                <option value="2">Always</option>
                            </select>
                       </td>
                   <% end if %>
            </tr>
            <tr>
                <td>Charge/Credit Added</td>
                   <% if canSms then %>
                    <td>
                        <select id="credAddSmsSel" required>
                            <option value="0">Never</option>
                            <option value="1">When Clocked In</option>
                            <option value="2">Always</option>
                        </select>
                   </td>
                    <%end if %>
                   <% if canEmail then %>
                        <td>
                            <select id="credAddEmailSel" required>
                                <option value="0">Never</option>
                                <option value="1">When Clocked In</option>
                                <option value="2">Always</option>
                            </select>
                       </td>
                   <% end if %>
            </tr>
            <tr>
                <td>Void Invoice</td>
                   <% if canSms then %>
                    <td>
                        <select id="voidIncSmsSel" required>
                            <option value="0">Never</option>
                            <option value="1">When Clocked In</option>
                            <option value="2">Always</option>
                        </select>
                   </td>
                    <%end if %>
                   <% if canEmail then %>
                        <td>
                            <select id="voidIncEmailSel" required>
                                <option value="0">Never</option>
                                <option value="1">When Clocked In</option>
                                <option value="2">Always</option>
                            </select>
                       </td>
                   <% end if %>
            </tr>
            <tr>
                <td>Cash Drawer Opened</td>
                   <% if canSms then %>
                    <td>
                        <select id="cdoSmsSel" required>
                            <option value="0">Never</option>
                            <option value="1">When Clocked In</option>
                            <option value="2">Always</option>
                        </select>
                   </td>
                    <%end if %>
                   <% if canEmail then %>
                        <td>
                            <select id="cdoEmailSel" required>
                                <option value="0">Never</option>
                                <option value="1">When Clocked In</option>
                                <option value="2">Always</option>
                            </select>
                       </td>
                   <% end if %>
            </tr>
            <tr>
                <td>Unhandled</td>
                   <% if canSms then %>
                    <td>
                        <select id="unhSmsSel" required>
                            <option value="0">Never</option>
                            <option value="1">When Clocked In</option>
                            <option value="2">Always</option>
                        </select>
                   </td>
                    <%end if  %>
                   <% if canEmail then %>
                        <td>
                            <select id="unhEmailSel" required>
                                <option value="0">Never</option>
                                <option value="1">When Clocked In</option>
                                <option value="2">Always</option>
                            </select>
                       </td>
                   <% end if %>
                </tr>
            </tr>
            <tr>
                <td>Handled</td>
                   <% if canSms then %>
                    <td>
                        <select id="handSmsSel" required>
                            <option value="0">Never</option>
                            <option value="1">When Clocked In</option>
                            <option value="2">Always</option>
                        </select>
                   </td>
                    <%end if  %>
                   <% if canEmail then %>
                        <td>
                            <select id="handEmailSel" required>
                                <option value="0">Never</option>
                                <option value="1">When Clocked In</option>
                                <option value="2">Always</option>
                            </select>
                       </td>
                   <% end if %>
                </tr>
            </tr>
		<tr height=30px></tr>
		<tr>
			<td></td>
			<TD>
				<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick= "submitForm('add')">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton style="background-image:url(../images/Cancel.gif)" type=button value="" onClick="cancelForm()">
						</TD>
					</tr>
				</table>
			</TD>
		</tr>
</table>

</form>

</body>
</html>
