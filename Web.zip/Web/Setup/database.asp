<%@ Language=VBScript %>

<!-- #INCLUDE FILE="../include/loader.asp"-->
<!-- #INCLUDE FILE="../include/AdoConstants.inc" -->

<%
	Dim load
	Dim fileData
	Dim fileName
	Dim storeid

	Set load = new Loader
	load.initialize
	fileData = load.getFileData("file")
	fileName = load.getFileName("file")
	storeid = load.getValue("storeid")


	select case ucase(Request.QueryString("mode"))
	case "I"
		insertIntoDatabase
	case "U"
		UpdateDatabase
	end select
	
	function insertIntoDatabase()
		dim oConn
		dim oRs
		dim dsnString
		dim sSQL
		dim oCmd
	
		if storeid = "" or fileName = "" then exit function
	
		Set oConn = Server.CreateObject("ADODB.Connection")
		Set oRs = Server.CreateObject("ADODB.Recordset")
		dsnString  = Session("shahcorpDSN")
		Set oCmd = Server.CreateObject("ADODB.Command")
	
		oConn.Open dsnString

		sSQL = "SELECT * FROM Form WHERE formName = '" & fileName & "' AND storeID = " & storeid

		oRs.Open sSQL, oConn, 3, 3
		
		if oRs.RecordCount = 0 then
			oRs.AddNew
			oRs.Fields("formName") = fileName
			oRs.Fields("storeID") = storeid
			oRs.Fields("formLayout").AppendChunk = fileData & ChrB(0)
	        oRs.Update

		end if
	end function
	
	function updateDatabase()
		dim oConn
		dim oRs
		dim dsnString
		dim sSQL
		dim oCmd

		if storeid = "" or fileName = "" then exit function
	
		Set oConn = Server.CreateObject("ADODB.Connection")
		Set oRs = Server.CreateObject("ADODB.Recordset")
		dsnString  = Session("shahcorpDSN")
	
		Set oCmd = Server.CreateObject("ADODB.Command")

		oConn.Open dsnString

		sSQL = "SELECT * FROM Form WHERE formName = '" & fileName & "' AND storeID = " & storeid

		oRs.Open sSQL, oConn, 3, 3
	
		if oRs.recordCount > 0 then
		
			oRs.Fields("formLayout").AppendChunk = fileData & ChrB(0)
			
		    oRs.Update
	    end if
	end function


%>


