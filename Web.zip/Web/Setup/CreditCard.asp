<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim isSubmitted 
	dim l_storeid
	dim sqltxt 
	dim BodyCaption
	dim l_creditid
	dim l_mode
	dim rsCredit
	dim actionstring
	dim totalcount
	
	isSubmitted = Request.QueryString("submitted")
	l_storeid = session("StoreID")
	actionstring = Request.QueryString("userAction")
	if (isSubmitted ) then
		if not isnull(l_storeid) and l_storeid <> "" then
			l_mode = Request.QueryString("mode")	
			if (l_mode= "delete") then
				l_creditid = Request.Form("Creditid")
				DbSTartTrans()
				sqltxt = "delete from creditCardtypedomain  where creditcardTypeid =" & l_Creditid
				QryExecuteWithTrans(sqltxt)
				DbEndTrans()
			elseif (l_mode= "add") then
				actionstring = actionstring & "?mode=" & l_mode 
				Response.Redirect(actionstring)	
			elseif (l_mode= "edit") then
				actionstring = actionstring & "?mode=" & l_mode & "&creditid=" & Request.Form("creditid")
				Response.Redirect(actionstring)	
			else 
				Response.Redirect(actionstring)	
			end if
		end if
	end if
	
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">


	function submitForm(element) {
		var x;
			
		if (element=="delete1"){
			x ="CreditCard.asp";
			document.creditcard.mode.value="delete";
			document.creditcard.action="?Submitted=true&userAction=" + x  + "&mode=" + document.creditcard.mode.value + "&Creditid=" + document.creditcard.creditid.value;
			}
		else if (element=="add"){
				x = "AddCreditCard.asp";
				document.creditcard.mode.value="add";
				document.creditcard.action="?Submitted=true&userAction=" + x  + "&mode=" + document.creditcard.mode.value;
			}
		else if	(element=="edit"){
				x = "AddCreditCard.asp";
				document.creditcard.mode.value="edit";
				document.creditcard.action="?Submitted=true&userAction=" + x  + "&mode=" + document.creditcard.mode.value + "&Creditid=" + document.creditcard.creditid.value;
			}
		document.creditcard.submit();
	}			
	function setCreditId(element){
		document.creditcard.creditid.value = element.value;
		document.creditcard.edit.disabled = false;
		document.creditcard.delete1.disabled = false;
	}
	function cancelForm(){
		document.creditcard.action = "CustomerSetup.asp";
		document.creditcard.submit();
		
	}	
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Credit Card</B>
<center>
<FORM id="creditcard" name="creditcard" action="customersetup.asp" Method = "post">
<input type=hidden name="mode">
<input type=hidden name="creditid" >

<TABLE WIDTH="500" BORDER=2 CELLSPACING=0 CELLPADDING=5 ><!-- header row -->
 <tr >
	<td align=left valign=top>
	<TABLE BORDER=0 width = 500 CELLSPACING=0 CELLPADDING=0 >
	<tr><td><br>
		<DIV STYLE="HEIGHT: 250px; OVERFLOW-X: auto; OVERFLOW-Y: auto; WIDTH: 350px" >
		<TABLE width = 100% style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =1 CELLSPACING=0>
			<tr><td>
			<TABLE width = 100% style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =0 CELLSPACING=0>
			<%
				l_storeid = 1
				dim rscreditcards
				totalcount = 0
				sqltxt = "select *  from creditCardTypeDomain where storeid =" & l_storeid
				'set rscreditcards = Server.CreateObject("ADODB.Recordset")
				set rscreditcards= getdisconnectedRecordset(sqltxt)
				totalcount = rscreditcards.RecordCount
				
				while not rscreditcards.BOF and not rscreditcards.EOF 
			%>
				<tr height =30>	
				<td width = 10><Input type=radio name=rdname value="<%=rscreditcards("CreditCardTypeID")%>" onclick = "setCreditId(this)"></td>
				<td width = 1000 ><%=rscreditcards("Name")%></td></tr>	
			<%	rscreditcards.movenext	
				wend		
			%>
				<tr height= 30><td width = 10></td><td width = 1000 ></td></tr>
				<tr height= 30></tr>
				<tr height= 30></tr>
				<tr height= 30></tr>
				<tr height= 30></tr>
				<tr height= 30></tr>
				<tr height= 30></tr>
		</TABLE>
		</td></tr></table>
		</DIV>
	</TD>
	<td align= left vAlign=top><br>
	<TABLE border="0" cellpadding=" " cellspacing="0" style= "MARGIN-LEFT=50px">
	<tr><td align=left vAlign=left>
		<!--<INPUT class = click name=add type=button value="Add" onClick="submitForm(this.name)"  style="HEIGHT: 24px; WIDTH: 62px;">-->
		<BUTTON class=std name=add onClick="submitForm(this.name)" style="font-size:12px">Add</button>
	</td>
	</tr>
	<tr><td align= left vAlign=left><br><br> 
		<!--<INPUT class = click name=delete1 type=button value="Delete" Disabled onClick="submitForm(this.name)"  style="HEIGHT: 24px; WIDTH: 62px">-->
		<BUTTON class=std name=delete1 Disabled onClick="submitForm(this.name)" style="font-size:12px">Delete</button>
	</td>
	</tr>
	<tr><td align=left vAlign=left> <br><br>
		<!--<INPUT class = click name=edit type=button value="Edit"  disabled onClick="submitForm(this.name)"  style="HEIGHT: 24px; WIDTH: 62px;">-->
		<BUTTON class=std name=edit disabled onClick="submitForm(this.name)" style="font-size:12px">Edit</button>
	</td>
	</tr>
	</table>
	<tr height=100px><td align= center colspan=2>
		<INPUT class = touchnoborder name=OK type=button value="" onClick="cancelForm()"  value="" style="background-image:url(../images/Ok.gif);background-position=center">&nbsp&nbsp&nbsp&nbsp&nbsp
		<INPUT class = touchnoborder name=cancel type=button value="" onClick="cancelForm()"  style="background-image:url(../images/Cancel.gif);background-position=center">
		</td>
	</tr>
	</table>
	<td></tr>
	</table><br>
	</td><tr></TABLE></FORM>
</center>
</BODY>
</HTML>
