<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
 	dim selectedCustomerPreferenceTypeID
 	
 	selectedCustomerPreferenceTypeID = getReqVar("CustomerPreferenceTypeID")

	select case lcase(request.querystring("useraction"))
	case "add"
		selectedCustomerPreferenceTypeID = addCustomerPreference(request.querystring("name"))
	case "remove"
		removeCustomerPreference request.querystring("id")
	case "update"
		updateCustomerPreference
	end select
	
	function updateCustomerPreference()
		dim query, rs
		
		if selectedCustomerPreferenceTypeID <> "" then
			query = " update customerpreferencetype set "
			query = query & "  [name] = '" & request.form("name") & "'"
			query = query & ", [options] = '" & request.form("options") & "'"
			query = query & ", [default] = '" & request.form("default") & "'"
			query = query & ", [formlabel] = '" & request.form("formlabel") & "'"
			query = query & " where customerPreferenceTypeID = " & selectedCustomerPreferenceTypeID

			qryexecute query
			
			
		end if
	
	end function
	
	function addCustomerPreference(name)
		dim query, rs
		dim result
		
		query = " insert into customerpreferencetype (name) values ('" & name & "')"

		openConnection
		dbInsert query
		set rs = dbselect("select @@IDENTITY as rowid")
		result = rs("rowid")
		set rs = nothing
		closeconnection
	
		addCustomerPreference = result
	end function
	

  
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function removeCustomerPreference(id)
		dim query, rs
		
		
		query = " delete customerpreference where customerpreferencetypeid = " & id
		qryexecute query
		
		query = " delete customerpreferencetype where customerpreferencetypeid = " & id
		qryexecute query
	end function
	
%>
<HTML>
<HEAD>
<TITLE>Customer Preferences Setup</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript">
	
	function addCustomerPreference() {
		cbs_prompt("Preference name:", handleAddPrefName);
	}

	function handleAddPrefName() {
        clearPromptMsg();
	    var name = document.getElementById('inputTxtLine').value;
		if(name) {
			document.CustomerPreference.action = "?useraction=add&name=" + name;
			document.CustomerPreference.submit();
		}
	}
	
	function removeCustomerPreference(id) {
	    cbs_confirm("Remove preference?", doRemovePref)
	}

	function doRemovePref() {
        clearConfirmMsg();
        document.CustomerPreference.action = "?useraction=remove&id=" + id;
        document.CustomerPreference.submit();
	}
	
	function updateForm() {
			document.CustomerPreference.action = "?useraction=update";
			document.CustomerPreference.submit();
	}
	
	function selectCustomerPreference(id) {
			document.CustomerPreference.action = "?useraction=select&CustomerPreferenceTypeID=" + id;
			document.CustomerPreference.submit();
	}
	
	function exitForm() {
		document.CustomerPreference.action = '/setup/CustomerSetup.asp';
		document.CustomerPreference.submit();
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Customer Preferences Setup</H1>
<FORM id="CustomerPreference" name="CustomerPreference" action="Lots.asp" Method = "post">

Add customer preference<br>
<select style="width:250px;font-size:24px" name="CustomerPreferenceTypeID" onchange="selectCustomerPreference(this.value)">
<option value="">Select Preference</option>
<%
query = " select name, CustomerPreferenceTypeID from CustomerPreferenceType  "

set rs = getdisconnectedrecordset(query)

while not(rs.eof or rs.bof)
%>
	<option value="<%=rs("CustomerPreferenceTypeID")%>" <%if trim(selectedCustomerPreferenceTypeID) = trim(rs("CustomerPreferenceTypeID")) then%>selected<%end if%>><%=server.htmlencode(rs("name"))%></option>

<%
	rs.movenext
wend

set rs = nothing
%>
</select>

<input type="button" style="height:40px; width: 80px" onclick="removeCustomerPreference(CustomerPreferenceTypeID.value)" value="Remove" />
<input type="button" style="height:40px; width: 80px" onclick="addCustomerPreference()" value="Add" />



<div name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<span style="float:left">
		<button name="update" onClick="updateForm()">Update</button>
	</span>
	<span style="float:right">
      <button name="exit" onClick="exitForm()">Exit</button>
	</span>
</div>	
<%
	dim name
	dim options
	dim default
	dim formLabel
	
	if selectedCustomerPreferenceTypeID <> "" then
		query = " select * from customerPreferenceType where customerPreferenceTypeID = " & selectedCustomerPreferenceTypeID
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			name = rs("name")
			options = rs("options")
			default = rs("default")
			formLabel = rs("formlabel")
		end if
	
		set rs = nothing
	
	end if
	


%>
<TABLE class="itable" cellspacing="0">
	<TR>
		<TH>Option</TH>
		<TH>Value</TH>
	</TR>

	<TR>
		<TD>Name</TD>
		<TD><INPUT name="name" value="<%=name%>" /></TD>
	</TR>
	<TR>
		<TD>Options</TD>
		<TD><INPUT name="options" value="<%=options%>" /></TD>
	</TR>
	
	<TR>
		<TD>Default</TD>
		<TD><INPUT name="default" value="<%=default%>" /></TD>
	</TR>
	
	<TR>
		<TD>Form Label</TD>
		<TD><INPUT name="formLabel" value="<%=formLabel%>" /></TD>
	</TR>

<TABLE>

</FORM>
</BODY>
</HTML>