<%@ Language=VBScript %>
<%option explicit%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim message
	dim formid
	dim formstring
	
	formid = getReqVar("formid")
	


	select case Request.QueryString("useraction")
		case "saveform"
			formid = saveForm(formid)
		case "open"
			formid = Request.QueryString("formid")
		case "new"
			formid = ""
		case "delete"
			deleteForm Request.Form("formid")
			formid = ""
	end select
	
	formstring = readForm(formid)
	
	function deleteForm(formid)
		dim query, rs
		
		query = " delete startpageform where formid = " & formid

		qryexecute query
	end function
	
	function readForm(formid)
		dim query, rs
		
		if formid <> "" then
			query = "select isnull(html, '') as html from startpageform where formid = " & formid

			set rs = getdisconnectedrecordset(query)
			
			ReadForm = rs("html")
	
			set rs = nothing
		end if
	end function
	
	function formExists(formid)
		dim query, rs
		
		if formid <> "" then
			query = "select count(*) as cnt from startpageform where formid = " & formid
			set rs = getdisconnectedrecordset(query)
			
			formExists = rs("cnt") > 0
			
			set rs = nothing
		else
			formExists = false
		end if
	end function
	
	function saveForm(formid)
		dim query, rs
		dim result
		
		if formExists(formid) then
			query = "update startpageform set "
			query = query & "StoreID = " & session("storeid") & ","
			query = query & "Name = '" & DBStr(Request.Form("formname")) & "',"
			query = query & "HTML = '" & DBStr(Request.Form("htmldata")) & "' "
			query = query & "where formid = " & formid
			
			qryexecute query
			result = formid
			
			message = "Form Updated"
		else
			query = "insert into startpageform (StoreID, Name, HTML) values "
			query = query & "(" & session("storeid") & ","
			query = query & "'" & DBStr(Request.Form("formname")) & "',"
			query = query & "'" & DBStr(Request.Form("htmldata")) & "')"

			openConnection
			dbInsert query
			set rs = dbselect("select @@IDENTITY as rowid")
			result = rs("rowid")
			set rs = nothing
			closeconnection
		
			message = "Form Saved"
		end if

		saveForm = result
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function


	function getFormName(formid)
		dim query, rs
		
		if formid <> "" then
			query = "select isnull(name, '') as name from startpageform where formid = " & formid
			set rs = getdisconnectedrecordset(query)
			
			getFormName = rs("name")
		
			set rs = nothing
		else
			getFormName = "New Alert"
		end if
	end function	
%>

<HTML>
<HEAD>
<TITLE>HTML Form</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">



<link rel="stylesheet" type="text/css" href="/external/ext/resources/css/ext-all.css" />

<script type="text/javascript" src="/external/ext/adapter/ext/ext-base.js"></script>
<script type="text/javascript" src="/external/ext/ext-all.js"></script>



<script language="javascript" type="text/javascript">
	var htmlEditor;


	Ext.onReady(function(){

		Ext.QuickTips.init();
		
		htmlEditor = new Ext.form.HtmlEditor({
			width: 600,
			height: 500
		});
		htmlEditor.setValue(Ext.get('formcontents').dom.innerHTML);
		htmlEditor.render('editor');
	});

	function exit() {
		document.formeditor.action = "mainsetup.asp";
		document.formeditor.submit();
	}
	
	function saveForm() {
		document.formeditor.htmldata.value = htmlEditor.getValue();

		document.formeditor.action = "?useraction=saveform";
		document.formeditor.submit();
	}

	function finishForm() {
		opener.window.location.reload();
		window.close();
	}

	function openForm(formID) {
		document.formeditor.action = "?useraction=open&formID=" + formID;
		document.formeditor.submit();
	}
	
	function newForm() {
		document.formeditor.action = "?useraction=new";
		document.formeditor.submit();
	}
	function deleteForm() {
	    cbs_confirm("Delete alert?", doDelete);
	}

	function doDelete() {
        clearConfirmMsg();
        document.formeditor.action = "?useraction=delete";
        document.formeditor.submit();
	}
</script>

</HEAD>
<BODY topmargin=0 leftmargin=0 onload="">
<!-- #include file="../include/banner.inc" -->

<FORM id="formeditor" name="formeditor" method="post" onsubmit="return false">

<INPUT type="hidden" name="formid" value="<%=formid%>">
<INPUT type="hidden" name="htmldata">

<TABLE>
	<TR>
		<TD>
			Existing Forms:<BR />
			<SELECT name="selectedFormID" onchange="openForm(selectedFormID.value);">
				<OPTION value=""></OPTION>
			<%
				query = "select formid, name from startpageform"
				set rs = getdisconnectedrecordset(query)
				
				while not(rs.eof or rs.bof)
			%>
				<OPTION value="<%=rs("formid")%>" <%if trim(formid) = trim(rs("formid")) then%>selected<%end if%>><%=Server.HTMLEncode(rs("name"))%></OPTION>
			
			<%
					rs.movenext
				wend
				set rs = nothing
			%>
			</SELECT>

		</TD>
	</TR>
</TABLE>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="newForm()">New</BUTTON>
		<BUTTON onclick="saveForm()">Save</BUTTON>
		<BUTTON onclick="deleteForm()">Delete</BUTTON>
	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	


<table cellpadding="2" style="width=100%; background:lightgrey;" style="width:100%">
	<tr><td style="font-size:12">
		Form Name:<input name="formname" style="width:300px" value="<%=getFormName(formid)%>">
	</td></tr>
</table>


<div id="editor" name="editor" style="width:100%;height:500px"></div>
<div id="formcontents" name="formcontents" style="display:none"><%=formstring%></div>


</FORM>

</BODY>
</HTML>

