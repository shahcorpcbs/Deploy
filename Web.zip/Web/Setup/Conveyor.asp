<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim BaudRate
	dim ComPort
	dim query, rs
	
	BaudRate = trim(Request.QueryString("baudrate"))
	ComPort = trim(Request.QueryString("port"))
	
	query = "select port, baudrate from storehardware where hardwaretype = 'CF' and terminalid = " & Session("terminalid")
	set rs = getdisconnectedrecordset(query)
	
	if not (rs.eof or rs.bof) then
		if ComPort <> "" and BaudRate <> "" then
			set rs = nothing
			query = "update storehardware set port = '" & ComPort & "', baudRate = '" & BaudRate & "' where hardwaretype = 'CF' and terminalid = " & Session("terminalid")
			qryexecute query
		elseif Request.QueryString("submitted") = "true" then
			query = "delete storehardware where hardwaretype = 'CF' and terminalid = " & Session("terminalid")
			qryexecute query
		else
			BaudRate = rs("baudRate")
			ComPort = rs("port")
			set rs = nothing
		end if	
	else
		if ComPort <> "" and BaudRate <> "" then
			set rs = nothing
			query = "insert into Storehardware (terminalid,hardwarename,hardwaretype, port, baudRate, " _
				 & " defaultCustomerDisplayText, scrollIfCapable, displayCustomerName, " _
				 & "displayItemPrice, displayItem, showUpcharges, showUpchargePrice ) values (" _
				  & Session("terminalid") _
				  & ", 'Automatic Conveyor Finder', 'CF'" _
				  & ",'" & ComPort & "'," & BaudRate & ",'',0,0,0,0,0,0)"
				qryexecute query
		end if
	end if
	
	if Request.QueryString("submitted") = "true" then
		Response.Redirect("hardware.asp")
	end if
	
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Conveyor Setup</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>
<script language="javascript" type="text/javascript">
	function selectPort(value) {
		cs.opBaudRate.disabled = (value == "");
	}
	
	function submitForm() {
		document.cs.action = "?submitted=true" +
						"&port=" + cs.opPort.value +
						"&baudrate=" + cs.opBaudRate.value;
						
		document.cs.submit();
	}
	
	function cancelForm() {
		document.cs.action = "Hardware.asp"
		document.cs.submit();
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Conveyor Setup</B>
<FORM id="cs" name="cs" action="" Method = "post">
	<div style="color:black;border:1px ridge grey;width:500px;padding:30px;margin:50px;">
	<div style="margin:10px">
		<span style="width:50%;text-align:right;">Port:</span>
		<SELECT name= opPort STYLE="Height = 24px;FONT-SIZE: 15px ;Width = 160px " onchange="selectPort(value)">
			<Option <%if ComPort = "Not Installed" then %>
			Selected 
			<%end if%>
			Value = "">Not Installed</option>
			
			<Option <%if ComPort = "COM1" then %>
			Selected 
			<%end if%>
			Value = COM1>COM1</option>
			<Option  <%if ComPort = "COM2" then %>
			Selected 
			<%end if%>
			Value = COM2>COM2</option>
			<Option  <%if ComPort = "COM3" then %>
			Selected 
			<%end if%>
			Value = COM3>COM3</option>
			<Option  <%if ComPort = "COM4" then %>
			Selected 
			<%end if%>
			Value = COM4>COM4</option>												
		</SELECT> 	
		
	</div>
	<div style="margin:10px">
		<span style="width:50%;text-align:right;">Baud Rate:</span>
		<SELECT <%if ComPort = "" then%>disabled<%end if%> name= opBaudRate STYLE="Height = 24px;FONT-SIZE: 15px ;Width = 160px ">
			<Option <%if BaudRate = "1200" then %>
			Selected 
			<%end if%>
			Value = 1200>1200</option>
			<Option  <%if BaudRate = "1800" then %>
			Selected 
			<%end if%>
			Value = 1800>1800</option>
			<Option  <%if BaudRate = "2400" then %>
			Selected 
			<%end if%>
			Value = 2400>2400</option>
			<Option  <%if BaudRate = "4800" then %>
			Selected 
			<%end if%>
			Value = 4800>4800</option>
			<Option  <%if BaudRate = "7200" then %>
			Selected 
			<%end if%>
			Value = 7200>7200</option>
			<Option  <%if BaudRate = "9600" then %>
			Selected 
			<%end if%>
			Value = 9600>9600</option>
			<Option  <%if BaudRate = "14400" then %>
			Selected 
			<%end if%>
			Value = 14400>14400</option>
			<Option  <%if BaudRate = "19200" then %>
			Selected 
			<%end if%>
			Value = 19200>19200</option>
			<Option  <%if BaudRate = "57600" then %>
			Selected 
			<%end if%>
			Value = 38400>38400</option>												
			<Option  <%if BaudRate = "57600" then %>
			Selected 
			<%end if%>
			Value = 57600>57600</option>												
			<Option  <%if BaudRate = "115200" then %>
			Selected 
			<%end if%>
			Value = 115200>115200</option>																								
		</SELECT> 
	</div>
	<div style="text-align:center;margin-top:40px">
		<INPUT class=touchnoBorder type=button style="background-image:url(../images/Ok.gif)"onClick="submitForm()">
		<INPUT class=touchnoBorder type=button style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
	</div>
	</div>
</FORM>
</BODY>
</HTML>
