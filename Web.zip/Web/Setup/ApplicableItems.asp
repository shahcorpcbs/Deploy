<%@ Language=VBScript %>
<% option explicit %>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	'selDeptId = Request.QueryString("deptId")
	dim storeId
	dim couponId
	dim actionString
	dim selDeptId
	dim priceListId
	dim targetPage
	dim minPCount
	dim minAmt
	dim CouponOrPromotion
	storeId = Session("storeId")	
	couponId = Request.QueryString("couponId")
	priceListId = Request.QueryString("priceListId")
	targetPage = Request.QueryString("targetPage")
	actionString = Request.QueryString("userAction")
	CouponOrPromotion = Request.Form("CouponOrPromotion")
	select case actionString
		case "add"
			select case targetPage
				case "ApplicableDepartments"
						addItemsForAppDepts
						select case CouponOrPromotion
							case "Coupon"
								Response.Redirect "CouponSetup.asp?priceListId=" & priceListId
							case "Promotion"
								Response.Redirect "PromotionsList.asp?priceListId=" & priceListId
						end select
				case "DepartmentRel"
						addItemsForDeptRelation
						Response.Redirect "DepartmentRelation.asp?couponId=" & couponId	_
											& "&priceListId=" & priceListId & "&CouponOrPromotion=" &CouponOrPromotion
			end select
		case "initialLoad"
				CouponOrPromotion = Request.QueryString("CouponOrPromotion")
				if targetPage ="DepartmentRel" then
					selDeptId = Request.QueryString("deptId")
					minPCount = Request.QueryString("minPCount")
					minAmt = Request.QueryString("minAmt")
				end if
	end select
	
	sub addItemsForDeptRelation()
		dim intLoop
		dim ssql
		dim itemId
		dim deptId
		
		deptId = Request.Form("deptId")
		minPCount = Request.Form("minPCount")
		minAmt = Request.Form("minAmt")
		DbStartTrans
		ssql = "Delete From DiscountDepartment Where DiscountId=" & clng(couponId) _
				& " And DepartmentId=" & deptId
		QryExecuteWithTrans(ssql)
		if Request.Form("select").Count > 0 then
			for intLoop=1 to Request.Form("select").Count
				itemId = Request.Form("select")(intLoop)
				ssql = "Insert Into Discountdepartment (discountId, departmentId, priceListItemId, " _
						& " minPieceCount, minQualAmount) " _
						& " Values(" & clng(couponId) & "," & clng(deptId) & "," _
						& clng(itemId) & "," & minPCount & "," & minAmt & ")"
				QryExecuteWithTrans(ssql)
			Next
		else
			ssql = "Insert Into Discountdepartment (discountId, departmentId, minPieceCount, " _
				& "minQualAmount) Values(" & clng(couponId) & "," & clng(deptId) _
				& "," & minPCount & "," & minAmt & ")"
			QryExecuteWithTrans(ssql)
		end if
		DbEndTrans
	end sub
	
		
	function getExistingItemsForDept(deptId)
		dim ssql
		
		ssql = "Select priceListItemId from DiscountDepartment where " _
				& " discountId=" & clng(couponId) & " And departmentId=" & deptId
		set getExistingItemsForDept = getDisconnectedRecordset(ssql)
	end function
	
	function getAllItemsForDept(deptId)
		dim  ssql
		ssql = "Select priceListItemId, itemName from PriceListItem Where " _
				& " departmentId=" & clng(deptId) & " And priceListId=" & clng(priceListId) _
				& " And disabled=0"
		set getAllItemsForDept = getDisconnectedRecordset(ssql)
	end function
	
	function getAllSelectedDepts()
		dim  ssql
		dim objResultSet
		
		ssql = "Select Distinct departmentId from Discountdepartment where " _
				& " discountId=" & clng(couponId)
		set objResultSet = getDisconnectedRecordset(ssql)
		Set Session("existingDepts") = objResultSet
		set getAllSelectedDepts = objResultSet
	end function
	
	sub addItemsForAppDepts()
		dim intLoop
		dim deptItemInfo
		dim deptItemArray
		dim deptId
		dim itemId
		dim ssql
		
		DbStartTrans
		ssql = "Delete From DiscountDepartment Where DiscountId=" & clng(couponId)
		QryExecuteWithTrans(ssql)
		if Request.Form("select").Count > 0 then
			for intLoop=1 to Request.Form("select").Count
				deptItemInfo = Request.Form("select")(intLoop)
				deptItemArray = Split(deptItemInfo, "|||")
				deptId = deptItemArray(0)
				itemId = deptItemArray(1)
				ssql = "Insert Into Discountdepartment (discountId, departmentId, priceListItemId) " _
						& " Values(" & clng(couponId) & "," & clng(deptId) & "," & clng(itemId) & ")"
				QryExecuteWithTrans(ssql)
			next
		else
			insertDeptWithNoItems
		end if
		DbEndTrans
	end sub
	
	sub insertDeptWithNoItems()
		dim ssql
		dim existingDepts
		dim deptId
		
		set existingDepts = Session("existingDepts")
		if existingDepts.Recordcount > 0 then
			existingDepts.MoveFirst
			while not existingDepts.EOF
				deptId = existingDepts.Fields("departmentId").Value
				ssql = "Insert Into Discountdepartment (discountId, departmentId) " _
						& " Values(" & clng(couponId) & "," & clng(deptId) & ")"
				QryExecuteWithTrans(ssql)
				existingDepts.MoveNext
			wend
		end if
	end sub
	
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function submitForm() {
		var discountId
		var targetPg
		var priceId
		var selDeptId
		discountId = document.appicableitem.couponId.value;
		targetPg = document.appicableitem.targetPage.value;
		priceId = document.appicableitem.priceListId.value;
		selDeptId = document.appicableitem.deptId.value;
		document.appicableitem.action = "?userAction=add&couponId=" + discountId + "&targetPage=" + targetPg + "&priceListId=" + priceId + "&deptId=" + selDeptId;
		document.appicableitem.submit();
	}
	
	function selectAllRows() {
		for (i = 0; i < document.appicableitem.select.length; i++) {
			document.appicableitem.select[i].checked = true;
		}

	}
	function deSelectAllRows() {
		for (i = 0; i < document.appicableitem.select.length; i++) {
			document.appicableitem.select[i].checked = false;
		}

	}
				
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Applicable Items</H1>
<FORM id="appicableitem" name="appicableitem" action="ApplicableItems.asp" Method = "post">
	<INPUT type="hidden" name="couponId" value="<%= couponId %>">
	<INPUT type="hidden" name="deptId" value="<%= selDeptId %>">
	<INPUT type="hidden" name="targetPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="priceListId" value="<%= priceListId %>">
	<INPUT type="hidden" name="minPCount" value="<%= minPCount %>">
	<INPUT type="hidden" name="minAmt" value="<%= minAmt %>">
	<INPUT type="hidden" name="CouponOrPromotion" value="<%= CouponOrPromotion %>">
	
<TABLE WIDTH="300" BORDER=2 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT:180px"><!-- header row -->
 <tr >
	<td align=center valign=top>
	<TABLE width = 350 border="0" cellpadding="0" cellspacing="0" Style = "MARGIN-LEFT: 8px">
	<tr><td> 
		<DIV STYLE="HEIGHT: 250px; OVERFLOW-X: auto; OVERFLOW-Y: auto; WIDTH: 250px" >
		<TABLE width = 100% style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =1 CELLSPACING=0>
			<tr><td>
			<TABLE width = 100% style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =0 CELLSPACING=0>
			<%
				dim deptId
				dim allItems
				dim existingItems
				dim found
				dim itemValue
				dim deptMaster
				dim deptName
				dim selectedDepts
				if actionString ="initialLoad" then
					select case targetPage
						case "ApplicableDepartments"
								set selectedDepts = getAllSelectedDepts()
								if selectedDepts.RecordCount > 0 then
									selectedDepts.MoveFirst
									while not selectedDepts.EOF
									deptId = selectedDepts.Fields("departmentId").Value
									set allItems = getAllItemsForDept(deptId)
									set existingItems = getExistingItemsForDept(deptId)
									while not allItems.EOF
										itemValue = allItems.Fields("priceListItemId").Value
										found =false
										if existingItems.Recordcount > 0 then
											existingItems.MoveFirst
											if existingItems.Fields("priceListItemId").Value = 0 then
												found =true
											else
												while not found and not existingItems.eof
													if existingItems.fields("priceListItemId") = itemValue then
														found =true
													end if
													existingItems.MoveNext
												wend
											end if
										end if
			%>
									<tr>
									<%
										if found then
									%>
										<td><input type=checkbox name=select id =select value="<%= deptId & "|||" & itemValue%>" checked></td>
									<%
										else
									%>
										<td><input type=checkbox name=select id =select value="<%= deptId & "|||" & itemValue%>"></td>
									<%
										end if
									%>
										<td>
											<%
												deptName = ""
												set deptMaster = Session("departmentMaster")
												if deptMaster.RecordCount > 0 then
													deptMaster.Filter = "departmentId=" & deptId
													if deptMaster.RecordCount > 0 then
														deptName = deptMaster.Fields("name").Value
													end if
													deptMaster.Filter = adFilterNone
												end if
												Response.Write allItems.Fields("itemName").Value & " (" & deptName & ")"
											%>
										</td>
									</tr>	
			<%
										allItems.MoveNext
									wend
									selectedDepts.MoveNext
								wend
							end if
						case "DepartmentRel"
								deptId = Request.QueryString("deptId")
								deptName = Request.QueryString("deptName")
								set allItems = getAllItemsForDept(deptId)
								set existingItems = getExistingItemsForDept(deptId)
								while not allItems.EOF
									itemValue = allItems.Fields("priceListItemId").Value
									found =false
									if existingItems.Recordcount > 0 then
										existingItems.MoveFirst
										if existingItems.Fields("priceListItemId").Value = 0 then
											found =true
										else
											while not found and not existingItems.eof
												if existingItems.fields("priceListItemId") = itemValue then
													found =true
												end if
												existingItems.MoveNext
											wend
										end if
									end if
			%>
									<tr>
									<%
										if found then
									%>
										<td><input type=checkbox name=select id =select value="<%= itemValue%>" checked></td>
									<%
										else
									%>
										<td><input type=checkbox name=select id =select value="<%= itemValue%>"></td>
									<%
										end if
									%>
									<td><%= allItems.Fields("itemName").Value & " (" & deptName & ")"%></td>
									</tr>
			<%	
								allItems.MoveNext
							wend
					end select
				end if
			%>
			
			</TABLE>
		</td></tr></table>
		</DIV>
	</TD>
	</tr>
	<tr>
	<td align= left vAlign=top>
		<TABLE width=100% border="0" cellpadding="7" cellspacing="0">
			<tr>
				<td colspan=2 align= center>
					<INPUT class = click name=bttnSelectAll type=button value="Select All" style="HEIGHT: 50px; WIDTH: 100px;" onClick="selectAllRows();">
					<INPUT class = click name=bttnSelectNone type=button value="Select None" style="HEIGHT: 50px; WIDTH: 100px;" onclick="deSelectAllRows();">
				</td>
			</tr>
			<tr height=100>
				<td  colspan=2 align= center>
					<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif);background-position=center"onClick="submitForm()">
					&nbsp&nbsp&nbsp&nbsp&nbsp
					<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);background-position=center" onClick="history.back(-1);">
				</td>
			</tr>
		</table>
	</td><br></tr>
	</TABLE><br>
	</td></tr>
	</TABLE></FORM>
</BODY>
</HTML>
