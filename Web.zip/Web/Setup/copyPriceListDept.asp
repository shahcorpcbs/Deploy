<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs, query2, rs2
    dim plId, copyPlId, copyDeptId, startDept
    dim name,  emailText, sourceId, dynMult, dynRO

    plId = trim(getReqVar("plID"))
    copyPlId = trim(getReqVar("copyPlId"))
	copyDeptId = trim(Request.QueryString("copyDeptId"))

    if copyPlId = "" then
        copyPLId = plId
        startDept = trim(getReqVar("deptId"))
        copyDeptId = startDept
    end if

	if trim(Request.QueryString("useraction")) = "submit" then
		SaveFormData()
	end if

    query = "select name, priceListid from priceList"
    set rs = getdisconnectedrecordset(query)

    if copyPlId <> "" then
        query2 = "select name, departmentId from department where priceListId = " & copyPlId
        set rs2 = getdisconnectedrecordset(query2)
    end if


    function SaveFormData()

        dim name, newDeptId, copyTo, copyToItems
		name = trim(Request.QueryString("name"))
		copyDeptId = trim(Request.QueryString("copyDeptId"))
		copyTo = trim(Request.QueryString("copyToId"))




            query = "SET NOCOUNT ON; Insert into Department(PriceListId, StoreId, disabled, name, description, commonItem, " _
                & "displaySequence, useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, "_
                & "outsideService, saleOnly, splitInvoice, prePayPercent, daysToProcess, imageFileName, "_
                & "itemReleaseInvoiceForm, notes, printNotes, maxItemsInReceipt, printerId, SplitWithDepartment, " _
                & "lotGroup, useHeatSeals, splitGroup, printGroup, userMaxItem)  "_
                & "(select " & plId & ", storeId, disabled, '" & DBStr(name) & "', description, commonItem, "_
                & "displaySequence, useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, "_
                & "outsideService, saleOnly, splitInvoice, prePayPercent, daysToProcess, imageFileName, "_
                & "itemReleaseInvoiceForm, notes, printNotes, maxItemsInReceipt, printerId, SplitWithDepartment, " _
                & "lotGroup, useHeatSeals, splitGroup, printGroup, userMaxItem from Department where departmentId = " _
                & copyDeptId & "); SELECT SCOPE_IDENTITY(); SET NOCOUNT OFF;"
		    DbStartTrans()
                newDeptId = QryExecuteWithTransAndSelect(query)
            DbEndTrans

                query = "insert into departmentTax (DepartmentId, taxCode, storeId) " _
                    & " (select " & newDeptId & ", taxCode, storeId from departmentTax where departmentId = " & copyDeptId & ")"
                qryexecute query

                query = "insert into departmentSurcharge (DepartmentId, surchargeCode, PriceListId) " _
                    & " (select " & newDeptId & ", surchargeCode, " & plId & " from departmentSurcharge where departmentId = " & copyDeptId & ")"
                qryexecute query

                if  copyTo <> 2 then
                    copyToItems = trim(Request.QueryString("copyToItems"))

                    query = "Insert into PriceListItem(DepartmentId, PriceListId, disabled, itemName, commonItem, " _
                        & "price, useGlobalTax, useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, "_
                        & "outsideService, saleOnly, splitInvoice, qtyInInventory, itemCost, prePayPercent, displaySequence, "_
                        & "daysToProcess, imageFileName, itemReleaseInvoiceFormName, notes, printNotes, useCounter, " _
                        & "itemShortcut, priceLater, InventoryQuantity, prompt, options, finishTime, prepayDiscount, useGlobalDescr)  "_
                        & "(select " & newDeptId & ", " & plId & ", disabled, itemName, commonItem, " _
                        & "price, useGlobalTax, useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, "_
                        & "outsideService, saleOnly, splitInvoice, qtyInInventory, itemCost, prePayPercent, displaySequence, "_
                        & "daysToProcess, imageFileName, itemReleaseInvoiceFormName, notes, printNotes, useCounter, " _
                        & "itemShortcut, priceLater, InventoryQuantity, prompt, options, finishTime, prepayDiscount, useGlobalDescr " _
                        & "from PriceListItem where departmentId = " & copyDeptId

                    if copyTo = 3 then
                        query = query & " and priceListItemId in (" & copyToItems & ")"
                    end if
                    query = query & ")"
                    qryexecute query


                     query = "Insert into ItemDescriptorPrice(priceListItemId, descriptorName, descriptorType, price, " _
                        & "disabled, useGlobalTax, useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, " _
                        & "outsideService, prePayPercent, displaySequence, daysToProcess, imageFileName, notes, " _
                        & "printNotes, UseCounter, prepayDiscount) " _
                        & "(select a.priceListItemId, c.descriptorName, c.descriptorType, c.price,  "_
                        & "c.disabled, c.useGlobalTax, c.useGlobalDays, c.discountable, c.VIPDiscountable, c.VIPQualified, c.couponable, " _
                        & "c.outsideService, c.prePayPercent, c.displaySequence, c.daysToProcess, c.imageFileName, c.notes, " _
                        & "c.printNotes, c.UseCounter, c.prepayDiscount " _
                        & "from PriceListItem a, PriceListItem b, ItemDescriptorPrice c where c.priceListItemId = b.priceListItemId " _
                        & "and a.priceListItemId in (select priceListItemId from PriceListItem where DepartmentId = " & newDeptId _
                        & ") and b.departmentId = " & copyDeptId & " and b.itemName = a.itemName)"
                    qryexecute query


                     query = "Insert into ItemDescriptorTax(priceListItemId, descriptorName, descriptorType, taxCode, storeId) " _
                         & "(select a.priceListItemId, c.descriptorName, c.descriptorType, c.taxCode, c.storeId from "_
                         & "PriceListItem a, PriceListItem b, ItemDescriptorTax c where c.priceListItemId = b.priceListItemId " _
                         & "and a.priceListItemId in (select priceListItemId from PriceListItem where DepartmentId = " & newDeptId _
                         & ") and b.departmentId = " & copyDeptId & " and b.itemName = a.itemName)"
                    qryexecute query


                     query = "Insert into itemDescriptorSurcharge(priceListItemId, descriptorName, descriptorType, surchargeCode, priceListId) " _
                         & "(select a.priceListItemId, c.descriptorName, c.descriptorType, c.surchargeCode, " & plId & " from "_
                         & "PriceListItem a, PriceListItem b, itemDescriptorSurcharge c where c.priceListItemId = b.priceListItemId " _
                         & "and a.priceListItemId in (select priceListItemId from PriceListItem where DepartmentId = " & newDeptId _
                         & ") and b.departmentId = " & copyDeptId & " and b.itemName = a.itemName)"
                    qryexecute query


                     query = "Insert into itemTax(priceListItemId, taxCode, storeId) " _
                         & "(select a.priceListItemId, c.taxCode, c.storeId from "_
                         & "PriceListItem a, PriceListItem b, itemTax c where c.priceListItemId = b.priceListItemId " _
                         & "and a.priceListItemId in (select priceListItemId from PriceListItem where DepartmentId = " & newDeptId _
                         & ") and b.departmentId = " & copyDeptId & " and b.itemName = a.itemName)"
                    qryexecute query


                     query = "Insert into itemSurcharge(priceListItemId, surchargeCode, priceListId) " _
                         & "(select a.priceListItemId, c.surchargeCode, " & plId & " from "_
                         & "PriceListItem a, PriceListItem b, itemSurcharge c where c.priceListItemId = b.priceListItemId " _
                         & "and a.priceListItemId in (select priceListItemId from PriceListItem where DepartmentId = " & newDeptId _
                         & ") and b.departmentId = " & copyDeptId & " and b.itemName = a.itemName)"
                    qryexecute query

                end if

        response.redirect "priceListDeptsList.asp?plId=" & plId
    end function

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
%>

<html>
<head>
<title>Copy Department</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</head>
<script language="javascript" type="text/javascript">

    function submitForm() {
        if (document.getElementById('copyPlId').value == -1) {
            cbs_alert("Select a Price List");
            return;
        }
        var name = $.trim(document.getElementById('nameText').value);
        if (name === "") {
            cbs_alert("Cannot set a blank department name");
            return;
        }

        var copyTo = document.getElementById('copyItemsSel').value;
        var copyItems = ""
        if (copyTo == 3) {
            $(':checkbox').each(function() {
                if(this.checked) {
                    copyItems += this.getAttribute("itemId") + ",";
                }
            });
            if (copyItems == "") {
                cbs_alert("If selecting individual items, must select at least one");
                return;
            }
            copyItems = copyItems.slice(0, -1);
        }


        document.copyPLDeptForm.action = "?useraction=submit" +
            "&plId=<%=plId%>" +
	        "&copyToId=" + encodeURIComponent(copyTo) +
	        "&copyToItems=" + encodeURIComponent(copyItems) +
	        "&name=" + encodeURIComponent(name) +
            "&copyPlId=<%=copyPLId%>" +
            "&copyDeptId=" + encodeURIComponent(document.getElementById('copyDeptId').value);
        document.copyPLDeptForm.submit();
    }

    function changePriceList() {
        if (document.getElementById('copyPlId').value == -1)
            return;

        document.copyPLDeptForm.action = "?useraction=update" +
            "&plId=<%=plId%>" +
            "&copyPlId=" + encodeURIComponent(document.getElementById('copyPlId').value);
        document.copyPLDeptForm.submit();
    }

    function changeDept() {
        if (document.getElementById('copyPlId').value == -1)
            return;
        if (document.getElementById('copyDeptId').value == -1)
            return;

        document.copyPLDeptForm.action = "?useraction=update" +
            "&plId=<%=plId%>" +
            "&copyPlId=" + encodeURIComponent(document.getElementById('copyPlId').value) +
            "&copyDeptId=" + encodeURIComponent(document.getElementById('copyDeptId').value);
        document.copyPLDeptForm.submit();
    }

    function changeItemsSelTo() {
        if (document.getElementById('copyItemsSel').value == 3)
            document.getElementById('copySelItems').style = "visibility:visible";
       else
           document.getElementById('copySelItems').style = "visibility:collapse";
    }

    function init() {
        var selectBox = document.getElementById("copyDeptId");
        var element = selectBox.options[selectBox.selectedIndex];
        if (element && element.value != -1)
            document.getElementById('nameText').value = element.text;
    }

    function cancelForm() {
		document.copyPLDeptForm.action = "priceListDeptsList.asp?plID=<%=plID%>";
        document.copyPLDeptForm.submit();
    }

</SCRIPT>
<body topmargin=0 leftmargin=0 onLoad="init()"><!-- #include file="../include/banner.inc" -->
<H1>Copy Price List Dept</H1><BR/><BR/>
<form name="copyPLDeptForm" action="" method="post" style="margin:0px">
	<TABLE ALIGN=center WIDTH="500px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px></tr>
        <tr style="text-align: left">
            <th>Price List</th>
            <th>Department</th>
        </tr>
    <td>
		<SELECT name="copyPlId" id="copyPlId" onChange="changePriceList()">
			<%
				while not(rs.eof or rs.bof)
			%>
				<OPTION value="<%=rs("priceListId")%>"
				<% if cstr(rs("priceListId")) = cstr(copyPLId) then %>
				    selected
				<% end if %>
				>
				<%=Server.HTMLEncode(rs("name"))%></OPTION>
			<%
					rs.movenext
				wend
				set rs = nothing
			%>
		</SELECT>
    </td>
    <td>
		<SELECT name="copyDeptId" id="copyDeptId" onChange="changeDept()">
		    <option value="-1">Select</option>
			<%
			    if query2 <> "" then
				    while not(rs2.eof or rs2.bof)
			%>
				<OPTION value="<%=rs2("departmentId")%>"
				<% if cstr(rs2("departmentId")) = cstr(copyDeptId) then %>
				    selected
				<% end if %>
				>
				<%=Server.HTMLEncode(rs2("name"))%></OPTION>
			<%
                    rs2.movenext
                    wend
                    set rs2 = nothing
				end if
			%>
		</SELECT>
    </td>
    </tr>
	<tr  <% if query2 = "" then %> style="visibility:hidden;" <% end if %>>
		    <td>New Dept Name</td>
            <td><input type="text" id="nameText" ></td>
        </td></tr>

    <% if copyDeptId <> "" then %>
        <tr height=50px></tr>
        <tr style="vertical-align:top">
            <td>Copy</td>
            <td>
                <SELECT name="copyItemsSel" id="copyItemsSel" onChange="changeItemsSelTo()">
                    <option value="1">All Items</option>
                    <option value="2">No Items</option>
                    <option value="3">Selected Items</option>
                </select>
            </td>
            </tr>
            <tr height=50px></tr>
            <tr>
            <td colspan="4" id="copySelItems" style="visibility:collapse;">
                <table>
                    <% dim query5, rs5, cnt
                        cnt = 0
                        query5 = "select itemName, priceListItemId from PriceListItem where departmentId = " & copyDeptId
                        set rs5 = getdisconnectedrecordset(query5)
                        while not(rs5.eof or rs5.bof) %>
                   <% if cnt mod 4 = 0 then %>
                   </tr><tr>
                   <% end if %>
                        <td><label for="chkCopyItem_<%=rs5("priceListItemId")%>"><%= rs5("itemName")%></label></td>
                        <td style="padding-right: 50px">
                            <Input type=checkbox id="chkCopyItem_<%=rs5("priceListItemId")%>" itemId="<%=rs5("priceListItemId")%>">
                        </td>
                    <% cnt = cnt + 1
                       rs5.movenext
                       wend %>
                </table>

            </td>
        </tr>
    <% end if %>

    <tr height=50px></tr>
		<tr>
			<TD>
				<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick= "submitForm()">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton style="background-image:url(../images/Cancel.gif)" type=button value="" onClick="cancelForm()">
						</TD>
					</tr>
				</table>
			</TD>
		</tr>
</table>


</form>

</body>
</html>
