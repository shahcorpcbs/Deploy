<!DOCTYPE html>
<%@ Language=VBScript %>
<!-- #include file="../include/upload.asp"-->
<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
    dim query, rs
    dim includeDisabled, plID, deptId, toggleId, itemId, userAction
    plId = trim(Request.QueryString("plID"))
    deptId = trim(Request.QueryString("deptId"))
    itemId = trim(Request.QueryString("itemId"))
    includeDisabled = Request.QueryString("includeDisabled")
    if includeDisabled = "" then includeDisabled = 0
    userAction = Request.QueryString("userAction")
    toggleId = Request.QueryString("toggleId")

    if toggleId <> "" then
       query = "update PriceListItem set disabled = ~disabled where priceListItemId = " & toggleId
       qryexecute query
    end if

    if userAction = "imageChange" then
        updateXWeb
    end if

    query = "select priceListItemId Id, itemName name, disabled, price, daysToProcess, qtyInInventory, imageFileName " _
        & "from PriceListItem where departmentId = " & deptId
    if includeDisabled = 0 then
        query = query & " and disabled = 0 "
    end if
    query = query & "order by displaySequence"
    set rs = getdisconnectedrecordset(query)

	sub updateXWeb()
		dim i, uploader, file, fileName

		fileName = Request.QueryString("fileName")
		Set uploader = new FileUploader
		uploader.Upload()

		if uploader.files.count > 0 then
            dim fs,tfile, pathToFile
            pathToFile = Server.mapPath("../uploadedImages/") & "/"

            set fs=Server.CreateObject("Scripting.FileSystemObject")
            set tfile=fs.CreateTextFile(pathToFile & fileName, True)

			for each file in uploader.Files.Items
				For i = 1 to LenB(file.FileData)
				    tfile.Write(Chr(AscB(MidB(file.FileData, i, 1))))
				Next
			next

			query = "update PriceListItem set imageFileName = '" & fileName & "' where priceListItemId = " & itemId
            qryexecute query

            tfile.close
            set tfile=nothing
            set fs=nothing
		end if
	end sub


%>

<HTML>
<HEAD>
<TITLE>Department Items</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
<script>
	var previousElement = null;
	var selectedId = null;

	function editDeptItem(itemId) {
		document.deptItemTable.action = "editPriceListItems.asp?plId=<%=plId%>&deptID=<%=deptId%>&itemId=" + itemId
		document.deptItemTable.submit();
	}

	function selectRow(element) {
		var childEl;
		if (previousElement != null){
			previousElement.className="";
		}
		element.className = "selected";
		previousElement = element;
		selectedId = element.getAttribute("itemId");

		var selectedStatus = element.getAttribute("disabledItem");
		if (selectedStatus == 1)
            document.querySelector('#btnDisable').innerHTML = 'Enable';
        else
            document.querySelector('#btnDisable').innerHTML = 'Disable';
    }

	function update() {
		document.deptItemTable.action = "?useraction=update&plId=<%=plId%>&deptId=<%=deptId%>&includeDisabled=" + ($("#chkDisabled").is(":checked") ? "1" : "0");
		document.deptItemTable.submit();
	}

    function toggleEnabled() {
        if (selectedId == null) {
            cbs_alert("Please Select Department");
            return;
        }
		document.deptItemTable.action = "?useraction=update&plId=<%=plId%>&deptId=<%=deptId%>&toggleId=" + selectedId + "&includeDisabled=" + ($("#chkDisabled").is(":checked") ? "1" : "0");
		document.deptItemTable.submit();
    }

    function edit() {
        if (selectedId == null) {
            cbs_alert("Please Select Item");
            return;
        }
		document.deptItemTable.action = "editDeptItem.asp?plId=<%=plId%>&deptId=<%=deptId%>&itemID=" + selectedId
		document.deptItemTable.submit();
    }

    function createNew() {
        cbs_select('Create Item', 2, "Copy Existing|Create New", "handleCreateChoice");
    }

    function handleCreateChoice(newOption) {
        if (newOption == 1)
            document.deptItemTable.action = "editDeptItem.asp?plId=<%=plId%>&deptId=<%=deptId%>"
        else
		    document.deptItemTable.action = "copyDeptItem.asp?plId=<%=plId%>&deptId=<%=deptId%>"
		document.deptItemTable.submit();
    }

	function editItemDesc(itemId) {
		document.deptItemTable.action = "ItemDescrList.asp?plId=<%=plId%>&deptID=<%=deptId%>&itemId=" + itemId
		document.deptItemTable.submit();
	}

    function changeImage(input) {
        var reader;

        if (input.files && input.files[0]) {
            reader = new FileReader();
            fileName = input.files[0].name;
            reader.onload = imageIsLoaded;
            reader.readAsDataURL(input.files[0]);
        }
    }

    function imageIsLoaded(e) {
		document.deptItemTable.action = "?useraction=imageChange&plId=<%=plId%>&deptId=<%=deptId%>&itemId="
		    + selectedId + "&includeDisabled=" + ($("#chkDisabled").is(":checked") ? "1" : "0") + "&fileName="
		    + encodeURIComponent(fileName);
		document.deptItemTable.submit();
    }


	function exit() {
		    document.deptItemTable.action = "priceListDeptsList.asp?plID=<%=plID%>";
        document.deptItemTable.submit();
	}

</script>

</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<INPUT type="hidden" name="plID" value="<%=plID%>" />
<H1>Price List Department Items</H1>
<br>
<br>
<FORM name="deptItemTable" ID="deptItemTable" METHOD=POST enctype="multipart/form-data" style="margin:0;padding:0" onsubmit="return false;">
    <table>
        <tr>
            <td>Include Disabled</td>
            <td><Input type=checkbox name=chkDisabled id="chkDisabled" onclick="update();"
            <% if includeDisabled = 1 then %>
                checked
            <% end if %>
            ></td>
        </tr>
    </table>
    <div name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
        <SPAN style="float:left">
            <BUTTON id="btnNew" onclick="createNew()">Create New</BUTTON>
        </SPAN>
        <SPAN style="float:left">
            <BUTTON id="btnEdit" onclick="edit()">Edit</BUTTON>
        </SPAN>
        <SPAN style="float:left">
            <BUTTON id="btnDisable" onclick="toggleEnabled()">Disable</BUTTON>
        </SPAN>
        <SPAN style="float:right">
            <BUTTON onclick="exit()">Exit</BUTTON>
        </SPAN>
    </div>


    <TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
        <TR style="background:#CCC;text-align:left" >
            <TH>Item Name</TH>
            <TH>Image</TH>
            <TH>Price</TH>
            <TH>Days To Process</TH>
            <TH>Quantity</TH>
            <TH>Edit Descriptors</TH>
        </TR>

    <% while not(rs.eof or rs.bof) %>
        <tr onClick="selectRow(this)" itemId="<%=rs("id")%>" <% if rs("disabled") then %> disabledItem="1" <% else %> disabledItem="0" <% end if %>>
            <td><%=rs("name")%></td>
            <td style="white-space: nowrap">
                <% if IsNull(rs("imageFileName")) or rs("imageFileName") = "" then %>
                    <i style="vertical-align: -webkit-baseline-middle">None</i>
                <% else %>
                    <img style="max-height: 20px; vertical-align: -webkit-baseline-middle" src="../uploadedImages/<%= rs.Fields("imageFileName")%>">
                <% end if %>
                &nbsp;<input type="file" style="display: none" name="filetag_<%=rs("id")%>" id="filetag_<%=rs("id")%>" onchange="changeImage(this)"/>
                <BUTTON style="width: 60px; height: 42px"><label for="filetag_<%=rs("id")%>">Update<br />Image</label></BUTTON>
            </td>
            <td><%=rs("price")%></td>
            <td><%=rs("daysToProcess")%></td>
            <td><%=rs("qtyInInventory")%></td>
            <td><BUTTON style="width: 45px; height: 30px" onclick="editItemDesc('<%=rs("Id")%>')">Edit</BUTTON></td>
        </tr>

        <%
            rs.movenext
            wend
            set rs = nothing
        %>
    </table>
</form>
</BODY>
</HTML>

