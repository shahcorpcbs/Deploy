<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim pricelistid : pricelistid = getReqVar("pricelistid")
	dim discounttype : discounttype = ucase(getReqVar("discounttype"))

	if pricelistid = "" then pricelistid = getDefaultPriceListID(session("storeid"))
	if discounttype = "" then discounttype = "CU"
	
	select case lcase(request.querystring("useraction"))
	case "remove"
		removeDiscount request.querystring("discountid")
	end select

	
	function removeDiscount(discountID)
		dim query, rs
		
		query = " delete from discount where discountid = " & discountid
		qryexecute query
	end function
	
	function getDefaultPriceListID(storeid)
		dim query, rs
		query = " select min(pricelistid) from pricelist "
		query = query & " where storeid = " & storeid
		
		set rs = getdisconnectedrecordset(query)
		
		getDefaultPriceListID = 0
		
		if rs.recordcount > 0 then
			getDefaultPriceListID = rs(0)
		end if
		
		set rs = nothing
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getDiscountTypeName(discountType)
		select case discountType
		case "CU"
			getDiscountTypeName = "Coupon"
		case "PR"
			getDiscountTypeName = "Promotion"
		end select
	end function
%>
<HTML>
<HEAD>
<TITLE>Discounts</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script type="text/javascript" src="../script/date-picker.js"></script>
<script type="text/javascript">
	var previousElement = null;
	var selectedDiscountID = null;
	var selectedDiscountType = null;
	
	function removeDiscount() {
		if(selectedDiscountID != null)
		    cbs_confirm("Delete selected discount?", doDelDisc);
	}

	function doDelDisc() {
        clearConfirmMsg();
	    document.discountlist.action = "/setup/discountlist.asp?useraction=remove&discountid=" + selectedDiscountID;
        document.discountlist.submit();
	}
	
	function editDiscount() {
		if(selectedDiscountID != null) {
			if(selectedDiscountType == "PR") {
				document.discountlist.action = "/setup/promotion.asp?addoredit=edit&couponid=" + selectedDiscountID + "&pricelistid=<%=pricelistid%>";
			}
			else {
				document.discountlist.action = "/setup/addcoupons.asp?addoredit=edit&couponid=" + selectedDiscountID + "&pricelistid=<%=pricelistid%>";
			}
			document.discountlist.submit();
		}
	}

	
	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}
		selectedDiscountID = element.getAttribute("discountID");
		selectedDiscountType = element.getAttribute("discountType");
		
		previousElement = element;
		
		element.className = "selected";
	}
	
	function exit() {
		document.discountlist.action = "/setup/coupons.asp";
		document.discountlist.submit();
	}
	
	function selectDiscountType(discountType) {
		document.discountlist.action = "/setup/discountlist.asp?discounttype=" + discountType;
		document.discountlist.submit();
	}
	
	function selectPriceListID(priceListID) {
		document.discountlist.action = "/setup/discountlist.asp?pricelistid=" + priceListID;
		document.discountlist.submit();
	}

	function addDiscount() {
		var selectedDiscountType;
		var selectedPriceList;
		selectedPriceList = $("#pricelistid").val();
		selectedDiscountType = $("#discounttype").val();
		
		if(selectedDiscountType == "PR") {
			document.discountlist.action = "/setup/promotion.asp?addoredit=add&priceListID=" + selectedPriceList;
		}
		else {
			document.discountlist.action = "/setup/addcoupons.asp?addoredit=add&priceListID=" + selectedPriceList;
		}
		document.discountlist.submit();
	}
	
	function viewPromotionCustomers() {
		if(selectedDiscountID != null) {
			document.discountlist.action = "/setup/promotioncustomers.asp?refpage=discountlist&discountid=" + selectedDiscountID;
			document.discountlist.submit();
		}
	}
	function viewCouponCustomers() {
		if(selectedDiscountID != null) {
			document.discountlist.action = "/setup/couponcustomers.asp?refpage=discountlist&discountid=" + selectedDiscountID;
			document.discountlist.submit();
		}
	}
	
	
</script>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Discounts</H1><BR/><BR/>

<FORM name="discountlist" ID="discountlist" METHOD=POST  style="margin:0;padding:0"> 

<TABLE cellpadding="10">

<TR>
<TD>
Discount Type<BR />
<SELECT onchange="selectDiscountType(this.value)" name="discounttype" id="discounttype">
<OPTION value="CU" <%if "CU" = discounttype then%>selected<%end if%>>Coupon</OPTION>
<OPTION value="PR" <%if "PR" = discounttype then%>selected<%end if%>>Promotion</OPTION>
</SELECT>
</TD>
<TD>
Price List<BR />
<SELECT onchange="selectPriceListID(this.value)" name="pricelistid" id="pricelistid">

<%
	query = " select pricelistid, name from pricelist where disable = 0 "
	query = query & " order by name "
	
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
%>
<OPTION value="<%=rs("pricelistid")%>" <%if trim(rs("pricelistid")) = trim(pricelistid) then%>selected<%end if%>><%=Server.HTMLEncode(rs("name"))%></OPTION>
<%
		rs.movenext
	wend
	set rs = nothing
%>
	
</SELECT>
</TD>
</TR>
</TABLE>

</FORM>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON style="vertical-align: top" onclick="addDiscount()">Add<BR /><%=getDiscountTypeName(discounttype)%></BUTTON>
		<BUTTON onclick="editDiscount()">Edit</BUTTON>
		<BUTTON onclick="removeDiscount()">Remove</BUTTON>
		<% if discounttype = "PR" then %>
		<BUTTON onclick="viewPromotionCustomers()">Customers</BUTTON>
		<% elseif discounttype = "CU" then %>
		<BUTTON onclick="viewCouponCustomers()">Customers</BUTTON>
		<% end if %>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<DIV style="overflow:scroll; height: 590px">
<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH>Price List</TH>
		<TH>Discount Type</TH>
		<TH>Discount Name</TH>
		<TH>Description</TH>
	</TR>
	<%
		query = " select pricelist.name as pricelistname, discount.discountid, discount.discounttype, discount.discountname, discount.discountpercent, discount.discountamount "
		query = query & " from discount "
		query = query & " inner join pricelist on discount.pricelistid = pricelist.pricelistid "
		query = query & " where discount.pricelistid = " & pricelistid
		query = query & " and discount.discounttype = '" & discounttype & "'"
		query = query & " and discount.discountid > 0 "
		query = query & " order by pricelist.name, discount.discounttype, discount.discountname"
		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
	%>
	<TR onclick="selectRow(this)" discountID="<%=rs("discountid")%>" discountType="<%=rs("discounttype")%>">
		<TD><%=Server.HTMLEncode(rs("pricelistname"))%></TD>
		<TD><%=Server.HTMLEncode(getDiscountTypeName(rs("discounttype")))%></TD>
		<TD><%=Server.HTMLEncode(rs("discountname"))%></TD>
		<TD>
		<%
			if not isnull(rs("discountpercent")) then
				response.write rs("discountpercent") & "% Off"
			elseif not isnull(rs("discountamount")) then
				response.write formatcurrency(rs("discountamount")) & " Off"
			end if
		
		%>
		</TD>
	</TR>
	<%
			rs.movenext
		wend
		set rs = nothing
	%>
</TABLE>
</DIV>

</BODY>
</HTML>

