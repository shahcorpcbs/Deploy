<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/security.asp" -->

<!--#include file="../include/notification.asp" -->
<!--#include file="../include/messages.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/invoiceOverlay.asp" -->
<%
	dim sec_A, useAdv, editAllQ, brandRsp, useOverlay, defaultTxtInput
	dim distinctUpcharges, upChargeValue, origTotal, ppPopup, forceHSBeforeDetail, currHS, usedHSList, hasHSItems
	dim hasSubscription


	defaultTxtInput = getMSVar("defaultTextField")
	forceHSBeforeDetail = getMSVar("forceDetailHeatSeal")
	currHS = Request.Form("currHS")
	if forceHSBeforeDetail then
	    usedHSList = Request.Form("usedHSList")
	end if
	if currHS = "" then
	    currHS = Request.Form("itemHeatSeal")
	end if
	if Request.Form("hasHSItems") = "" then
	    hasHSItems = 0
	else
	    hasHSItems = Request.Form("hasHSItems")
    end if

	useAdv = getMSVar("useAdvDetailScreen")
	if useAdv then
	    useOverlay = true
	else
	    useOverlay = getMSVar("useOverlayDesc")
	end if
	editAllQ = getMSVar("updateAllQuickItems")
	ppPopup = getMSVar("prepayPopupOnDetailPage")
	sec_GetDayAfter

	function sec_GetDayAfter()
		dim query, rs
		dim ticketNumber
		dim invoiceObj

		sec_A = ""

		ticketNumber = trim(Request.QueryString("ticketNumber"))

		if ticketNumber = "" then
			if isobject(session("invoice")) then
				if not(session("invoice") is nothing) then
					set invoiceObj = session("invoice")
					ticketNumber =  trim(invoiceObj.ticketNo)
				end if
			end if
		end if

		if ticketNumber <> "" then
			if ticketNumber > 0 then

				query = "select datediff(hour, isnull(createddate, getdate()), getdate()) as dd from ticket where ticketnumber = " & ticketNumber
				set rs = getdisconnectedrecordset(query)

				if rs("dd") > 24 then
					sec_A = "(da)"
				end if

				set rs = nothing

				query = "select count(*) as cnt from rackassignment where ticketnumber = " & ticketNumber
				set rs = getdisconnectedrecordset(query)

				if rs("cnt") > 0 then
					sec_A = "(ra)"
				end if

				set rs = nothing

				query = "select invoicetotal, (invoicetotal - amountpaid) as amountdue from ticket where ticketnumber = " & ticketnumber
				set rs = getdisconnectedrecordset(query)

                origTotal = rs("invoicetotal")
				if rs("amountdue") = 0.00 then
					sec_A = "(pd)"
				end if

				set rs = nothing
			end if
		end if
	end function

%>

<%sec_RequestAccess sec_A & Request.QueryString("userAction")%>
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	'****************************************
	'Name   :Detailed Invoice
    'Author : Poonam Gupta
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 26-Jun-2002    Poonam			Reformatted the negative amounts,
	'								Displayed Gross Total for line items
	'								Changed the redirection logic when: Always redirect to customer functions page
	' 19-Sept-2002	Poonam			print heat seal numbers
	' 20-Sept-2002	Poonam			Item Count validation for heat seal & clear invoice
	' 20-Sept-2002	Poonam			heat Seal validation when prepay clicked
	'*****************************************************************

	const maxSubItemCount = 7
	const maxCouponsCount =12
	const maxDeptCount =4
	dim invoice
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim custSeqNumber, custPriceList, custPhone, customerName
	dim actionString
	dim selectedDept
	dim storeId
	dim addOrEdit
	dim isDueDateSet
	dim f_upcharges, f_colors, f_pattern, f_brand, f_heatseal, forceNext
	dim upchargeSet, colorSet, patternSet, brandSet
	dim curr_LineNo
	dim ObjMiscSetUp
	dim ticketNumber
	dim alertMessage
	dim selItemId
	dim selUpchargeValue, selPatternValue, selColorValue, selBrandValue
	dim multiplePickup
	dim originatingPage
	dim deptIds()
	dim sInvoicenumber
	dim maxItemCountPerDept
	dim isMaxItemExceedPerDept
	dim maxItemDeptName
	dim loyaltyCard
	dim loyaltyEnabled
	dim prPurchaseLoy
	dim prLoyOffers
	dim numLoyOffers
	dim prInvoice
	dim prVisits
	dim custVisits
	dim CorL
	dim hasNotes
	dim userHasSelected
	dim createdDate
	dim quickItemsCount
	dim datasource
	dim objWord
	dim txtAmountEntered
	dim priceTableMultiplier
	dim priceTableSourceID
	dim priceTableRoundOff
	dim hsPieceCnt
	dim hsItemName
	dim hsItemID
	dim needHS, deptNeedHS
	dim hsCount
	dim wshell
	dim fname
	dim lastItemQuantity
	dim enableRedoMode
	dim alternativeRedo
	dim sqltxt, rst
	dim errMsg, hasErrorMsg, hasInfoMsg
	dim maxItemsCount, colCount, rowCount
    dim screenWidth, screenHeight

    screenWidth = Request.Form("screenWidth")
    if screenWidth = "" then
        screenWidth = Request.QueryString("screenWidth")
        if screenWidth = "" then
            screenWidth = Session("screenWidth")
            screenHeight = Session("screenHeight")
        else
            screenHeight = Request.QueryString("screenHeight")
        end if
    else
        screenHeight = Request.Form("screenHeight")
    end if

    session("screenWidth") = screenWidth
    session("screenHeight") = screenHeight




    if useOverlay then
        colCount = 4
        if screenWidth <> "" and int(screenWidth) >= 1200 then
            colCount = 4 + int((int(screenWidth) - 1050) /150)
            if colCount > 8 then
                colCount = 8
            end if
        end if
        rowCount = 7
        if screenHeight <> "" and int(screenHeight) >= 900 then
            rowCount = 7 + int((int(screenHeight) - 750) /150)
        end if
    else
        colCount = 5
        rowCount = 6
    end if
    maxItemsCount = colCount * rowCount - 1


	lastItemQuantity = 1

	if Request.QueryString("userAction") = "edit" then
		set session("invoice") = nothing
	end if

	sInvoicenumber = session("invoicelist")

	alertMessage =""
	initializeMiscSetUp
	set ObjMiscSetUp = Session("miscSetUp")
	if ObjMiscSetUp.Count > 0 then
		f_upcharges =ObjMiscSetUp.Item("forceUpcharges")
		f_colors =ObjMiscSetUp.Item("forceColors")
		f_pattern =ObjMiscSetUp.Item("forcePatterns")
		if useAdv then
		    f_brand =ObjMiscSetUp.Item("forceBrands")
		else
		    f_brand = 0
		end if
		f_heatseal=ObjMiscSetUp.Item("useHeatSeal")
	else
		f_upcharges =0
		f_colors =0
		f_pattern =0
		f_brand =0
		f_heatseal = 0
	end if

	forceNext = 0
	if f_upcharges or f_colors or f_brand or f_pattern then
	    forceNext = Request.QueryString("forceNext")
	end if

	alternativeRedo = getMSVar("alternativeRedo")

	ticketNumber = Request.QueryString("ticketNumber")
	custSeqNumber = getCustomerSeqFromTicket(ticketNumber)

	storeId = Session("storeId")
	customerName = session("customername")
	custPhone =session("customerphone")
	custPriceList = Session("priceList")
	actionString = Request.QueryString("userAction")
	setStartIndexForPaging
	selectedDept = Request.Form("selectedDept")
	curr_LineNo = Request.Form("lineNumber")
	addOrEdit = Request.Form("addOrEdit")
	upchargeSet = Request.Form("upchargeSet")
	colorSet = Request.Form("colorSet")
	patternSet = Request.Form("patternSet")
	brandSet = Request.Form("brandSet")
	isDueDateSet = Request.Form("isDueDateSet")
	if custSeqNumber = "" then custSeqNumber = Request.Form("custSeqNumber")
	if custSeqNumber = "" then custSeqNumber = session("customersequencenumber")
	selItemId = Request.Form("selItemId")
	selUpchargeValue = Request.Form("selUpcharge")
	selColorValue = Request.Form("selColor")
	selPatternValue = Request.Form("selPattern")
	selBrandValue = Request.Form("selBrand")
	originatingPage = Request.Form("originPage")
	userHasSelected = Request.Form("userHasSelected")
	if userHasSelected = "" then
		userHasSelected = false
	end if


    hasSubscription = getCustSubscription
	needHS = Request.Form("needHS")
	deptNeedHS = false
	if (selectedDept = "" and needHS = "") then
		needHS = "True"
	elseif (selectedDept <> "" and selectedDept <> "-1") then
		sqltxt = "select useheatseals from department where departmentid = " & selectedDept
		set rst = getDisconnectedRecordSet(sqltxt)
		if rst.RecordCount > 0 then
		    deptNeedHS = rst("useHeatSeals")
			if needHS = "" then
			needHS = rst("useHeatSeals")
        else
				needHS = rst("useHeatSeals") OR needHS
			end if
		end if
	else
		needHS = "True"
	end if
	hsCount = Request.Form("hsCount")
	if hsCount = "" then
		hsCount = 0
	end if
	createdDate = Request.Form("createdDate")
	enableRedoMode = Request.Form("enableRedoMode")
	if enableRedoMode = "" then enableRedoMode = 0

	custPriceList = getCustomerDefaultPriceListID(custSeqNumber)
	priceTableMultiplier = getPriceTableMultiplier(custPriceList)
	priceTableSourceID = getPriceTableSourceID(custPriceList)
	priceTableRoundOff = getPriceTableRoundOff(custPriceList)

	setDeptDueDates

	Select case actionString
			case "toggleRedoMode"
						if enableRedoMode = 0 then
							enableRedoMode = 1
						else
							enableRedoMode = 0
						end if
			case "fromMultiplePickup"
						fromMultiplePickup
			case "create"
						session("Invoicelist") =""
						sInvoicenumber = session("invoicelist")
						multiplePickup = Request.QueryString("multiplePickup")
						if multiplePickup ="1" then
							Response.Redirect "multiplePickup.asp?addOrEdit=add"
						end if
						addOrEdit ="add"
						set invoice = Server.CreateObject("ShahCorpComponents.invoice")
						invoice.DBConnectionString = Session("shahcorpDSN")
						set Session("invoice") = invoice
						invoice.terminalid = Session("TerminalID")
						invoice.storeNumber = Session("StoreID")
						invoice.createdByEmployeeId = Session("EmployeeID")
						invoice.LoadDefaults
						invoice.isAdd = true
						invoice.amountPaid = 0
						initialize
						invoice.custSeqNumber = custSeqNumber
						invoice.starchPref = Session("starchPref")
						invoice.finishPref = Session("finishPref")
						invoice.multiPickUpCustName	= ""
						invoice.multiPickUpLoc = ""
						createdDate = Now()
						invoice.createdDate = createdDate
						invoice.loadCustomerPreferences custSeqNumber, ""

			case "addshortcutitem"
						addShortcutItem

			case "addHeatSealItem"
						setInvoiceDueDate
						addHeatSealItem
						hscount = invoice.countHeatSeals()
						if hsPieceCnt > 1 then
							Response.Redirect "additionalHeatSeal.asp?pieceCount=" & hsPieceCnt & "&itemName=" & hsItemName & "&itemID=" & hsItemID _
											& "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
											& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
											& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
											& "&addOrEdit=" & addOrEdit & "&deptIndex=" & deptStartIndex _
											& "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
											& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue _
											& "&selBrand=" & selBrandValue
						end if

			case "getItemDetails"
						userHasSelected = true
						upchargeSet = "False"
						colorSet = "False"
						patternSet = "False"
						brandSet = "False"
						setInvoiceDueDate
						selItemID = Request.QueryString("itemId")
						getItemDetails Request.QueryString("itemId"), Request.QueryString("quantity"), Request.QueryString("promptResponse")
						lastItemQuantity = Request.QueryString("quantity")
						enableRedoMode = 0
			case "changeQuantity"
						'if addOrEdit = "edit" then
						'	checkMaxItemsPerDept
						'end if

						'if not (isMaxItemExceedPerDept) then
							setInvoiceDueDate
							changeQuantity
						'end if
			case "deleteItem"
						setInvoiceDueDate
						deleteItem
						selUpchargeValue = ""
						selPatternValue = ""
					    selBrandValue = ""
						selColorValue =""
						selItemId = -1
			case "clearInvoice"
					setInvoiceDueDate
					set invoice = Session("invoice")
					invoice.clearInvoice
					if addOrEdit = "edit" then
						invoice.isAdd = false
					end if
					selUpchargeValue = ""
					selPatternValue = ""
					selBrandValue = ""
					selColorValue =""

			case "overridePrice"
					setInvoiceDueDate
					overrideLinePrice
			case "addCharge"
					setInvoiceDueDate
					addCharge
			case "getCommonItems"
					setInvoiceDueDate
					set invoice = Session("invoice")
					getCommonItems
			case "addUpcharge"
					lastItemQuantity = Request.Form("lastItemQuantity")
					setInvoiceDueDate
					addUpCharge
			case "addColor"
					lastItemQuantity = Request.Form("lastItemQuantity")
					setInvoiceDueDate
					addColor
			case "addPattern"
					lastItemQuantity = Request.Form("lastItemQuantity")
					setInvoiceDueDate
					addPattern
			case "addBrand"
					lastItemQuantity = Request.Form("lastItemQuantity")
					setInvoiceDueDate
					addBrand
			case "changeDept"
					setInvoiceDueDate
					set invoice = Session("invoice")
					selectedDept = Request.Form("selectedDept")
					getItemsForDept
			case "getCoupons"
					setInvoiceDueDate
					if getCoupons() then
						gotoCoupons
					end if

			case "getLoyalty"
					setInvoiceDueDate
					getLoyalty
			case "addCoupon"
					' from coupons page
					addCoupon
			case "nextPage"
					lastItemQuantity = Request.Form("lastItemQuantity")
					txtAmountEntered = request.form("txtAmountEntered")
					set invoice = Session("invoice")
			case "prePay"
				setInvoiceOnDelivery request.querystring("invoiceOnDelivery")
				setInvoiceDueDate
				checkForRushUpcharge
				prePayInvoice
			case "done"
				onDone
			case "newInvoiceNo"
					saveInvoiceWithInvNo
			case "nosplit"
					saveInvoiceWithNoSplit
			case "split"
					saveInvoiceWithSplitAndInvNo
			case "hold"
					holdInvoice
			case "edit"
				session("Invoicelist")= ""
				originatingPage = Request.QueryString("originPage")
				multiplePickup = Request.QueryString("multiplePickup")
				if multiplePickup ="True" then
					Response.Redirect "multiplePickup.asp?ticketNumber=" & ticketNumber & "&addOrEdit=edit&originPage=" & originatingPage
				end if
				addOrEdit ="edit"
				set invoice = Server.CreateObject("ShahCorpComponents.invoice")
				invoice.DBConnectionString = Session("shahcorpDSN")
				set Session("invoice") = invoice
				invoice.storeNumber = Session("StoreID")
				invoice.LoadDefaults
				invoice.getExistingDetails ticketNumber
				if err.number <> 0 then
					set errorList =  Server.CreateObject("Scripting.Dictionary")
					errorList.Add err.number,err.description & " Edit Invoice"
					set session("errorList") = errorList
					Response.redirect("../include/error.asp")
				end if

				custSeqNumber = invoice.custSeqNumber
				session("Invoicelist") = invoice.invoiceno
				sInvoicenumber = session("Invoicelist")
				Session("customersequencenumber") = custSeqNumber
				createdDate = invoice.createdDate
				initialize
				selectedDept = invoice.getFirstDeptId()
				getItemsForDept
			case "changeStarchPref"
					changePref("starch")
			case "changeFinishPref"
					changePref("finish")
			case "changePreference"
				changePreference request.querystring("preferenceTypeID"), request.querystring("value"), request.querystring("save")
			case "returnFromNotes"
					attachNotes
			' added by
			case "returnFromCapture"
					attachCaptureNotes
			case "cancel"
					session("invoicelist") = ""
					select case addOrEdit
						case "add"
								Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
						case "edit"
								select case originatingPage
									case "customerfunctions"
											Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
									case "invoicesearch"
											Response.Redirect "invoiceSearch.asp"
									case "quickinvtool"
											Response.Redirect "quickInvoices.asp"
									case "garmentsearch"
											Response.Redirect "garmentsearchresults.asp"
									case else
											Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
								end select
					end select
			case "fromPickup"
					fromPickup

			case "fromTagAllocation"
					addOrEdit = Request.QueryString("addOrEdit")
					originatingPage = Request.QueryString("originPage")
					set invoice = Session("invoice")
					checkForTagsAfterAllocation request.querystring("button") = "ok"
			case "fromOnDemandCoupons"
				fromOnDemandCoupons
			case "getSubItems"
				userHasSelected = true
				getSubItems
			case "fromAddlHeatSeal"
				fromAddlHeatSeal
			case "fromHeatSeal"
					fromHeatSeal
					onDone
			case "fromValHeatSeal"
					fromHeatSeal
					checkForOnDemandCoupon
			case "fromCustomerNotes"
					initializeformHiddenValues
			case "setDeptDueDate"
					setDeptDueDate
			case "setAllDeptDueDate"
					setAllDeptDueDate
			case "createBrand"
			    createBrand
	end select
	setInvoiceDueDate


	if createdDate = "" then
		set invoice = session("invoice")
		createdDate = invoice.createdDate
	end if

	set invoice = Session("invoice")
	quickItemsCount = invoice.liColTotal("quantity", "itemType = 'DE'")

	' functions start here

	sub onDone()
		setInvoiceOnDelivery request.querystring("invoiceOnDelivery")
		setInvoiceDueDate
		checkForRushUpcharge
		checkForOnDemandCoupon ' commented after adding heat seal
	end sub

	sub checkForRushUpcharge()
		dim groupSimilarItems
		dim invoice

		set invoice = Session("invoice")

		if ObjMiscSetUp.Count > 0 then
			groupSimilarItems = ObjMiscSetUp.Item("groupSimilarItems")
		else
			groupSimilarItems = true
		end if

        invoice.applyRushUpcharge(groupSimilarItems)

	end sub

	function getCustSubscription
	    dim query, rs, subId
	    subId = ""
	    query = "select subId from SubXCust where enabled = 1 and custSeqNum = " & custSeqNumber
        set rs = getdisconnectedrecordset(query)
        if rs.recordcount > 0 then
            subId = rs("subId")
            errMsg = "<BR><B>Customer has a subscription, prices will be updated at save</B>"
            hasInfoMsg = true
        end if
        getCustSubscription = subId
	end function

	function setSubscriptionPrice(invoiceNos)
        Dim httpRequest, postResponse

        on error resume next
        Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
        httpRequest.Open "POST", getAddressPath("main") & getCommonShortPath() & "/setSubPrice?custSeqNum=" & custSeqNumber & "&ticketNums=" & invoiceNos, False
        httpRequest.SetRequestHeader "Content-Type", "text/plain"
        httpRequest.Send
        postResponse = httpRequest.ResponseText
	end function


	function changePreference(preferenceTypeID, value, save)
		dim query

		set invoice = Session("invoice")
		invoice.setCustomerPreference preferenceTypeID, value

		if save then
			query = " delete customerpreference  "
			query = query & " where ticketnumber is null "
			query = query & " and customerpreferencetypeid = " & preferenceTypeID
			query = query & " and customersequencenumber = " & custSeqNumber

			qryexecute query

			query = " insert into customerpreference (value, ticketnumber, customerpreferencetypeid, customersequencenumber) "
			query = query & " values ('" & DBStr(value) & "'"
			query = query & ", null "
			query = query & ", " & preferenceTypeID
			query = query & ", " & custSeqNumber
			query = query & ")"


			qryexecute query


		end if
	end function


	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

	function setInvoiceOnDelivery(v)
		dim invoice
		set invoice = Session("invoice")

		invoice.invoiceOnDelivery = ("1" = v)
	end function

	sub addShortcutItem()
		dim itemid
		dim invoice

		itemid = convertShortcutToItem(Request.QueryString("shortcut"))

		if itemid <> "" then
			userHasSelected = false
			upchargeSet = "False"
			colorSet = "False"
			patternSet = "False"
			setInvoiceDueDate
			selItemID = itemid
			getItemDetails itemid, 1, ""
		end if


		itemid = convertShortcutToDiscount(Request.QueryString("shortcut"))

		if itemid <> "" then
			if getCoupons() then
				set invoice = Session("invoice")
				invoice.getQualifyingCoupons
				invoice.addCoupon itemid
			end if
		end if
	end sub

	function checkForActiveTicket(hsnumber)
		dim query1
		dim rs1
		dim retVal
		retVal = true
		hasErrorMsg = false

		query1 = "select count(*) as cnt from ticket t, ticketlineitemtaggeditem tli, taggedpiece tp where t.ticketnumber = "
		query1 = query1 & " tli.ticketnumber and tli.taggeditemid = tp.taggeditemid and t.ticketstatus = 'AC' and tp.heatsealid = '" & hsnumber & "'"
		set rs1 = getDisconnectedRecordset(query1)
		if cint(rs1("cnt").value) > 0 then
			retVal = false
            errMsg = "<BR><B>Heat seal number " & hsnumber & " is on an active invoice.  It cannot be added to this invoice.</B>"
            hasErrorMsg = true
		end if
		set rs1 = nothing

		checkForActiveTicket = retVal
	end function

	function checkForAlreadyEntered(hsnumber)
		dim retVal
		retVal = true
		hasErrorMsg = false

		if not invoice.verifyHeatSeal(hsnumber) then
			retVal = false
            errMsg = "<BR><B>Heat seal number " & hsnumber & " is already on this invoice.</B>"
            hasErrorMsg = true
		end if

		checkForAlreadyEntered = retVal
	end function

	function checkHSCustomer(hsnumber)
		dim retVal, qry1, rs1
		retVal = true
		hasErrorMsg = false

		qry1 = "select top 1 customersequencenumber as cs from ticket t, ticketlineitemtaggeditem tli, taggedpiece tp where t.ticketnumber = "
		qry1 = qry1 & " tli.ticketnumber and tli.taggeditemid = tp.taggeditemid and t.ticketstatus = 'FI' and tp.heatsealid = '" & hsnumber & "' order by t.ticketnumber desc"
		set rs1 = getDisconnectedRecordset(qry1)
		if rs1.recordcount = 1 then
			if clng(rs1("cs")) <> clng(custSeqNumber) then
				retVal = false
				errMsg = "<BR><B>Heat seal number " & hsnumber & " does not belong to this customer.  It cannot be added to this invoice.</B>"
				hasErrorMsg = true
			end if
		end if

		checkHSCustomer = retVal

	end function

	sub addHeatSealItem()
		dim hsnumber, taggedItemID, query, rs, notOnActiveTicket, notOnThisTicket, correctCustomer
		'Retrieve pricelistitemid from taggedItem using heatseal number
		hsnumber = Request.QueryString("heatSeal")
		'Check to see if item is already on another active invoice
		notOnThisTicket = checkForAlreadyEntered(hsnumber)
		notOnActiveTicket = checkForActiveTicket(hsnumber)
		correctCustomer =  checkHSCustomer(hsnumber)
		if notOnActiveTicket and notOnThisTicket and correctCustomer then
			hsItemID = convertHeatSealToItem(hsnumber)

			if hsItemID <> "" then
				userHasSelected = false
				upchargeSet = "False"
				colorSet = "False"
				patternSet = "False"
				setInvoiceDueDate
				selItemID = hsItemID
				getItemDetails hsItemID, 1, ""

		           'Retrieve itemname, quantity from pricelistitem using pricelistitemid
		           query = "select * from pricelistitem where pricelistitemid =" & hsItemID
		           set rs = getDisconnectedRecordset(query)

		           if rs.recordcount > 0 then
		                 hsItemName = rs("itemname")
		                 hsPieceCnt = rs("qtyInInventory")
		           end if
		           set rs = nothing

				invoice.addHeatSealInfoForItem curr_LineNo, hsnumber, hsItemName, hsItemID
				hscount = invoice.countHeatSeals()
				hasHSItems = 1

				'Check for item descriptors and add them if necessary
				taggedItemID = convertHeatSealToTaggedItem(hsnumber)
				query = "select * from taggeditemdescriptor where taggeditemid =" & taggedItemID
				set rs = getDisconnectedRecordset(query)

				if rs.recordcount > 0 then
			        while not(rs.eof or rs.bof)
						select case rs("DescriptorType")
							case "PA"
								invoice.addPattern curr_LineNo, rs("DescriptorName"), 1, false
								patternSet  = invoice.isPatternSetForItem(curr_LineNo)
							case "UP"
								invoice.addUpcharge curr_LineNo, rs("DescriptorName"), 1, false
								upchargeSet = invoice.isUpchargeSetForItem(curr_LineNo)
							case "CO"
								invoice.addColor curr_LineNo, rs("DescriptorName"), 1, false
								colorSet = invoice.isColorSetForItem(curr_LineNo)
						end select
						rs.movenext
					wend
					set rs = nothing
				end if
			else
                if forceHSBeforeDetail then
                    currHS = hsnumber
                    errMsg = "<BR><B>New heat seal number " & hsnumber & ", please detail item for heatseal</B>"
                    hasInfoMsg = true
                end if
			end if
		else
		    currHS = ""
		end if
	end sub


	function convertShortcutToItem(shortcut)
		dim query, rs

		convertShortcutToItem = ""

		query = "select pricelistitemid from pricelistitem where itemshortcut = '" & DBStr(shortcut) & "'"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			convertShortcutToItem = rs("pricelistitemid")
		end if

		set rs = nothing
	end function

	function convertShortcutToDiscount(shortcut)
		dim query, rs

		convertShortcutToDiscount = ""

		query = "select discountid from discount where shortcut = '" & DBStr(shortcut) & "'"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			convertShortcutToDiscount = rs("discountid")
		end if

		set rs = nothing
	end function

	function convertHeatSealToItem(heatseal)
		dim query, rs

		convertHeatSealToItem = ""

		query = "select pricelistitemid from taggedItem where taggedItemID = (select distinct taggedItemID from taggedPiece where heatSealID = '" & DBStr(heatseal) & "')"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			convertHeatSealToItem = rs("pricelistitemid")
		end if

		set rs = nothing
	end function

	function convertHeatSealToTaggedItem(heatseal)
		dim query, rs

		convertHeatSealToTaggedItem = ""

		query = "select distinct taggedItemID from taggedPiece where heatSealID = '" & DBStr(heatseal) & "'"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			convertHeatSealToTaggedItem = rs("taggedItemID")
		end if

		set rs = nothing
	end function

	sub setDeptDueDates()
		dim cntDeptsOnInvoice
		dim i
		dim dueDate
		dim deptName


		if isobject(Session("invoice")) then
		    if not (Session("invoice") is nothing) then
			    set invoice = Session("invoice")

			    cntDeptsOnInvoice = Request.Form("deptOnInvoice").count

			    for i = 1 to cntDeptsOnInvoice
			    	deptName = Request.Form("deptOnInvoice")(i)
			    	dueDate = trim(Request.Form("deptDueDate" & replace(deptName, " ", "")))

			    	if dueDate <> "" then
			    	   invoice.setDeptDueDate deptName, dueDate
			    	end if
			    next

'				invoice.adjustDueDatesForRoute custSeqNumber
'			    invoice.adjustDueDatesForWorkload
			end if
		end if
	end sub

	function ExtractDate(d)
		ExtractDate = Datepart("m", d) & "/" & Datepart("d", d) & "/" & Datepart("yyyy", d)
	end function

	sub setDeptDueDate
		set invoice = Session("invoice")
		invoice.setDeptDueDate Request.QueryString("department"), Request.QueryString("date")
	end sub

	sub setAllDeptDueDate
		set invoice = Session("invoice")
		invoice.setAllDepartmentDueDates Request.QueryString("date")
	end sub


	sub selectNextItem()
		dim lineItems
		set invoice = Session("invoice")
		set lineItems = invoice.lineItems

		lineItems.Filter = "itemType = 'IT' AND lineNumber > " & curr_LineNo
		lineItems.Sort = "lineNumber"

		if not (lineItems.EOF or lineItems.BOF) then
			curr_LineNo = lineItems("lineNumber")
			selUpchargeValue = ""
			selPatternValue = ""
			selBrandValue = ""
			selColorValue =""
		end if

		lineItems.Filter = adFilterNone
	end sub

	sub fromHeatSeal()
		dim itemsHeatSealInfo

		set invoice = Session("invoice")
		initializeformHiddenValues
		hsCount = invoice.countHeatSeals()
		upchargeSet = Request.QueryString("upSet")
		colorSet = Request.QueryString("cSet")
		patternSet = Request.QueryString("pSet")
	end sub

	sub fromAddlHeatSeal()
		initializeformHiddenValues
		upchargeSet = Request.QueryString("upSet")
		colorSet = Request.QueryString("cSet")
		patternSet = Request.QueryString("pSet")
	end sub

	sub initializeformHiddenValues()
		set invoice = Session("invoice")
		curr_LineNo = Request.QueryString("lineNo")
		selectedDept = Request.QueryString("dept")
		if not IsEmpty(Request.QueryString("itIndex")) then
			itemsStartIndex = clng(Request.QueryString("itIndex"))
		else
			itemsStartIndex =0
		end if
		if not IsEmpty(Request.QueryString("upIndex")) then
			upChargeStartIndex = clng(Request.QueryString("upIndex"))
		else
			upChargeStartIndex =0
		end if
		if not IsEmpty(Request.QueryString("cIndex")) then
			colorsStartIndex = clng(Request.QueryString("cIndex"))
		else
			colorsStartIndex =0
		end if
		if not IsEmpty(Request.QueryString("pIndex")) then
			patternStartIndex = clng(Request.QueryString("pIndex"))
		else
			patternStartIndex =0
		end if
		addOrEdit = Request.QueryString("addOrEdit")
		if not IsEmpty(Request.QueryString("deptIndex")) then
			deptStartIndex = clng(Request.QueryString("deptIndex"))
		else
			deptStartIndex =0
		end if
		if not IsEmpty(Request.QueryString("needHS")) then
			needHS = Request.QueryString("needHS")
		else
			needHS = "True"
		end if
		selItemId = Request.QueryString("selItemId")
		selUpchargeValue = Request.QueryString("selUp")
		selPatternValue = Request.QueryString("selPattern")
		selBrandValue = Request.QueryString("selBrand")
		selColorValue = Request.QueryString("selColor")
		originatingPage = Request.QueryString("originPage")
	end sub


	sub getSubItems()
		dim lineNo
		set invoice = Session("invoice")
		lineNo = Request.QueryString("lineNo")
		curr_LineNo = lineNo
		selItemId = invoice.getItemIdForLineNo(lineNo)
		getDistinctUpcharges selItemId
		getDistinctColors selItemId
		getDistinctPatterns selItemId
		selUpchargeValue = ""
		selPatternValue = ""
		selBrandValue = ""
		selColorValue =""
		lastItemQuantity = invoice.getLineQuantity(lineNo)

		if f_upcharges or f_colors or f_pattern or f_brand then
			colorSet = invoice.isColorSetForItem(lineNo)
			patternSet = invoice.isPatternSetForItem(lineNo)
			upchargeSet = invoice.isUpchargeSetForItem(lineNo)
			f_brand = isBrandSetForItem(lineNo)
		end if
	end sub

	sub fromOnDemandCoupons()
		dim submit

		set invoice = Session("invoice")
		submit = Request.QueryString("submit")
		if submit = "yes" then
			invoice.applyOnDemandCoupons =true
		else
			invoice.applyOnDemandCoupons = false
		end if
		invoiceDone
		checkForSplit
	end sub


	function countUserDefinedTags(ticketNumber)
		dim query, rs

		countUserDefinedTags = 0

		if ticketNumber <> "" then
			query = " select tagNumber from tickettag where tagNumberType = 'T' and ticketNumber = " & ticketNumber
			set rs = getdisconnectedrecordset(query)

			countUserDefinedTags = rs.recordcount

			set rs = nothing
		end if

	end function


	sub checkForTags()
		dim tagsSameAsInvNos
		dim promptForTagsAfterDetail
		dim enableLotTags
		dim promptForTagsType

		if ObjMiscSetUp.Count > 0 then
			tagsSameAsInvNos = ObjMiscSetUp.Item("sameTagInvNumber")
			promptForTagsAfterDetail = ObjMiscSetUp.Item("promptForTagsAfterDetail")
			enableLotTags = ObjMiscSetUp.Item("enableLotTags")
			promptForTagsType = ObjMiscSetUp.Item("promptForTagsType")
		else
			tagsSameAsInvNos = true
			promptForTagsAfterDetail = true
			promptForTagsType = 0
		end if

		if promptForTagsAfterDetail and promptForTagsType = 0 then
			Response.Redirect "addTagNumber.asp?addOrEdit=" & addOrEdit & "&originPage=" & request.querystring("useraction")
		else
			saveInvoiceToDatabase tagsSameAsInvNos
		end if
	end sub

	sub checkForTagsAfterAllocation(generateTags)
		dim tagsSameAsInvNos


		if ObjMiscSetUp.Count > 0 then
			tagsSameAsInvNos = ObjMiscSetUp.Item("sameTagInvNumber")
		else
			tagsSameAsInvNos = true
		end if

		saveInvoiceToDatabase tagsSameAsInvNos And generateTags
	end sub


	function getExistingTagCount(ticketNumber)
		dim query, rs

		query = "SELECT count(*) as cnt FROM TicketTag WHERE ticketNumber = " & ticketNumber
		set rs = getdisconnectedrecordset(query)

		getExistingTagCount = rs("cnt")
		set rs = nothing
	end function


	function deleteExistingTags(ticketNumber)
		dim query, rs

		if ticketNumber <> "" then
			query = "DELETE TicketTag WHERE ticketNumber = " & ticketNumber
			qryexecute query
		end if
	end function

	sub saveInvoiceToDatabase(generateTags)
		dim empId
		dim terminalId
		dim empName
		dim storeName
		dim invNumber
		dim notifyPickup
		dim ssql
		dim objResultSet
		dim pickUp
		dim printTagsForHeatSeals
		dim hsNosForPrinting
		dim transactionchangedue
		dim isrush
		dim promptForTags
		dim doTagGeneration
		dim ticketnumber
		dim invoiceRedirect
		dim enableLotTags
		dim promptForTagsType
		dim pickupObj

		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")

		isrush = invoice.isRush()

		invoice.saveInvoice addOrEdit, empId, terminalId, 0, empName, storeName, true

		if trim(request.querystring("useraction")) = "fromPickup" or trim(request.querystring("originPage")) = "fromPickup" then
			set pickupObj = session("pickupObj")
			pickupObj.applyPayments empId, terminalId, "'" & invoice.getTicketNosForPrinting() & "'" , -1
			transactionchangedue = pickupObj.getChangeDue()
		end if


		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice saveInvoice"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if

		if ObjMiscSetUp.Count > 0 then
			printTagsForHeatSeals = ObjMiscSetUp.Item("printTagsForHeatSealItems")
			promptForTags = ObjMiscSetUp.Item("promptForTagsAfterDetail")
			enableLotTags = ObjMiscSetUp.Item("enableLotTags")
			promptForTagsType = ObjMiscSetUp.Item("promptForTagsType")
		else
			printTagsForHeatSeals = false
			promptForTags = false
			enableLotTags = false
			promptForTagsType = 0
		end if

		if generateTags then
			if promptForTags then
		  		if invoice.ticketTags is nothing then
	  				doTagGeneration = getExistingTagCount(invoice.ticketNo) <= 0
	  			else
	  				doTagGeneration = invoice.ticketTags.Count <= 0
	  			end if
			else
				deleteExistingTags invoice.ticketNo
				doTagGeneration = true
			end if

			if doTagGeneration then
				invoice.insertTagsForTicket printTagsForHeatSeals
			end if
  		end if

		invNumber = invoice.getTicketNosForPrinting()
		pickUp ="0"
		notifyPickup = ObjMiscSetUp.Item("notifyPickup")




		recordDetailedNote(invoice.getInvoiceNos())

		if notifyPickup then
			ssql = "Select distinct Ticket.ticketNumber From Ticket, RackAssignment Where customersequencenumber=" & custSeqNumber _
					& " AND ticketStatus='AC' AND invoiceType='D' AND onHold=0 AND Ticket.ticketNumber = rackAssignment.ticketNumber"
			set objResultSet = getDisconnectedRecordset(ssql)

			if objResultSet.Recordcount > 0 then
				pickUp = "1"
			end if
		end if

		hsNosForPrinting = invoice.heatSealNumbersForPrinting


		if addOrEdit = "add" then
			dim i
			dim ticket_numbers

			ticket_numbers = split(invNumber, ",")

			for i = lbound(ticket_numbers) to ubound(ticket_numbers)
				CBS_TriggerNotification "NDROPOFF", empId, custSeqNumber, ticket_numbers(i)

				if ObjMiscSetUp.Item("useHeatSeal") then
					if ObjMiscSetup.Item("conveyorType") = "MP" then
						ssql = "exec sendtoconveyor " & ticket_numbers(i)
						QryExecute ssql
					elseif ObjMiscSetup.Item("conveyorType") = "IT" then
						ssql = "exec sendtoitacs " & ticket_numbers(i)
						QryExecute ssql
					elseif ObjMiscSetup.Item("conveyorType") = "WH" then
						if addOrEdit = "add" then
							ssql = "exec sendtowhiteconveyor 'TICKET_CREATE'," & ticket_numbers(i)
							QryExecute ssql
							ssql = "exec sendtowhiteadc 'TICKET_CREATE'," & ticket_numbers(i)
							QryExecute ssql
						elseif addOrEdit = "edit" then
							ssql = "exec sendtowhiteconveyor 'TICKET_MODIFY'," & ticket_numbers(i)
							QryExecute ssql
							ssql = "exec sendtowhiteadc 'TICKET_MODIFY'," & ticket_numbers(i)
							QryExecute ssql
						end if
					end if
				end if

			next
		elseif addOrEdit = "edit" then

			if ObjMiscSetUp.Item("useHeatSeal") then
				if ObjMiscSetup.Item("conveyorType") = "MP" then
					ssql = "exec sendtoconveyor " & invNumber
					QryExecute ssql
				elseif ObjMiscSetup.Item("conveyorType") = "IT" then
					ssql = "exec sendtoitacs " & invNumber
					QryExecute ssql
				elseif ObjMiscSetup.Item("conveyorType") = "WH" then
					if addOrEdit = "add" then
						ssql = "exec sendtowhiteconveyor 'TICKET_CREATE'," & invNumber
						QryExecute ssql
						ssql = "exec sendtowhiteadc 'TICKET_CREATE'," & invNumber
						QryExecute ssql
					elseif addOrEdit = "edit" then
						ssql = "exec sendtowhiteconveyor 'TICKET_MODIFY'," & invNumber
						QryExecute ssql
						ssql = "exec sendtowhiteadc 'TICKET_MODIFY'," & invNumber
						QryExecute ssql
					end if
				end if
			end if

			if not invoice.isQuickInvoice() and  origTotal <> "" and origTotal <> 0 and origTotal <> invoice.getInvoiceAmountToPay then
                session("amountChanged") = 1
                session("newAmount") = invoice.getInvoiceAmountToPay
			end if
		end if

        if hasSubscription <> "" then
            setSubscriptionPrice invNumber
        end if


		invoiceRedirect = "customerfunctions.asp?userAction=print&addOrEdit=" _
							& addOrEdit & "&ticketNumber=" & invNumber _
							& "&invoiceType=D&customerseq=" & custSeqNumber _
							& "&pickUp=" & pickUp & "&heatSeals=" & hsNosForPrinting _
							& "&totalchangedue=" & transactionchangedue _
							& "&isrush=" & isrush

		if 	Request.QueryString("prepay") = "1" then
            prePayInvoice
		elseif promptForTags and promptForTagsType = 1 then
			session("s_errMessage") = ""
			Session("invoiceRedirect") = invoiceRedirect

			Response.Redirect "assignTicketsToLots.asp?ticketNumbers=" & invNumber & "&employeeid=" & Session("employeeID")
		else
			Response.Redirect invoiceRedirect
		end if
	end sub


	sub fromMultiplePickup()
		dim starchPref
		dim finishPref
		dim multiLocation
		dim multiName
		dim submitAction
		addOrEdit = Request.Form("addOrEdit")
		set invoice = Server.CreateObject("ShahCorpComponents.invoice")
		invoice.DBConnectionString = Session("shahcorpDSN")
		set Session("invoice") = invoice
		session("invoicelist") = invoice.invoiceno
		sinvoicenumber = session("invoicelist")
		select case addOrEdit
			case "add"
				invoice.isAdd = true
				invoice.amountPaid = 0
				initialize
				invoice.custSeqNumber = custSeqNumber
				submitAction = Request.QueryString("submit")
				select case submitAction
					case "ok"
							multiLocation = Request.Form("txtLocation")
							multiName = Request.Form("txtName")
							finishPref = Request.QueryString("finishPref")
							starchPref = Request.QueryString("starchPref")
					case "cancel"
							multiLocation = ""
							multiName = ""
							finishPref = Session("finishPref")
							starchPref  = Session("starchPref")

				end select
			case "edit"
				ticketNumber = Request.Form("ticketNumber")
				invoice.getExistingDetails ticketNumber
				if err.number <> 0 then
					set errorList =  Server.CreateObject("Scripting.Dictionary")
					errorList.Add err.number,err.description & " Edit Invoice"
					set session("errorList") = errorList
					Response.redirect("../include/error.asp")
				end if
				custSeqNumber = invoice.custSeqNumber
				Session("customersequencenumber") = custSeqNumber
				session("invoicelist") = invoice.invoiceno
				sinvoicenumber = session("invoicelist")
				initialize
				submitAction = Request.QueryString("submit")
				multiLocation = Request.Form("txtLocation")
				multiName = Request.Form("txtName")
				finishPref = Request.QueryString("finishPref")
				starchPref = Request.QueryString("starchPref")
		end select
		invoice.loadCustomerPreferences custSeqNumber, ""
		invoice.setCustomerPreferenceByName "starch", starchPref
		invoice.setCustomerPreferenceByName "finish", finishPref
		invoice.starchPref = starchPref
		invoice.finishPref = finishPref
		invoice.multiPickUpLoc = multiLocation
		invoice.multiPickUpCustName = multiName
	end sub

	sub fromPickup()
		dim submit
		dim pickupObj
		dim applyPrepayDiscount
		dim prepayDiscount
		dim signatureId

		set invoice = Session("invoice")
		submit = Request.QueryString("submit")
		applyPrepayDiscount = 1
		signatureId = Request.Form("PickupSignatureId")
		if signatureId = "" then
			signatureId = -1
		end if

		if trim(request.querystring("useraction")) = "fromPickup" and trim(request.querystring("submit")) <> "cancel" then
			set pickupObj = session("pickupObj")

			If cdbl(pickupObj.getAmountPaid()) >= 0.01 Then
				invoice.applyPrepay True
				invoiceDone
			End If
		End If


		if submit = "done" then
			set pickupObj = Session("pickupObj")
			invoice.signatureId = signatureId
			if applyPrepayDiscount = "1" then
				prepayDiscount = ObjMiscSetUp.Item("prepayDiscountPercent")
			end if

			if invoice.isSplitInvoice() then
				invoice.splitInvoice addOrEdit
				saveInvoiceWithSplit
			else
				checkForAutoInvNumbers
			end if
		elseif submit = "paylater" and sec_IsAllowed("paylater") then
			if invoice.splitTheInvoice then
				saveInvoiceWithSplit
			else
				checkForAutoInvNumbers
			end if
		else
			cancelDoneOperation
		end if
	end sub

	sub cancelDoneOperation()
		invoice.cancelDoneOperation
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice cancelDoneOperation"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub saveInvoiceWithSplitAndInvNo()
		set invoice = Session("invoice")
		invoice.splitInvoice addOrEdit
		checkForPrepay
	end sub

	sub setInvoiceDueDate ()
		dim resetDueDate
		dim dueDate

		resetDueDate = request.form("resetDueDate")
		set invoice = Session("invoice")

		if resetDueDate <> "" or isDueDateSet ="1" then
			if resetDueDate <> "" then
				dueDate = Date()
				invoice.setAllDepartmentDueDates dueDate
			else
				dueDate = Request.Form("txtDueDate")
				invoice.setInvoiceDueDate dueDate
			end if



			if err.number <> 0 then
				set errorList =  Server.CreateObject("Scripting.Dictionary")
				errorList.Add err.number,err.description & "-Function= Detailed Invoice setInvoiceDueDate"
				set session("errorList") = errorList
				Response.redirect("../include/error.asp")
			end if
			isDueDateSet ="0"

		end if

	end sub

	'added by
	sub attachCaptureNotes()
		dim imgID
		dim imgURL
		dim selLineNo
		dim oldNotes
		dim ssql
		dim imageList
		dim imgFileName
		dim comments

		set invoice = Session("invoice")


		selLineNo = Request.Form("selLineNo")
		imgID = Trim(Request.Form("imgID"))

		oldNotes = invoice.getItemNotes(selLineNo)


		ssql = "SELECT ImageFile, Comments from CapturedImages WHERE ID='" & imgID & "'"
		set imageList = getDisconnectedRecordset(ssql)

		if not imageList.EOF then
			imgFileName =  "/ImageCapture/" &  Trim(imageList("ImageFile"))
		else
			imgFileName = "../images/copy.gif"
		end if

		comments = Trim(imageList("Comments"))

		imageList.Close
		set imageList = nothing

		imgURL = oldNotes & "<a onClick=""viewImage(" & imgID & ");""><img border=""0"" src=""" & imgFileName & """ width=""20"" height=""20""></a>&nbsp" & comments

		invoice.attachNotes selLineNo, imgURL

		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice attachCaptureNotes"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub


	sub attachNotes()
		dim selLineNo
		dim itemNotes
		selLineNo = Request.Form("selLineNo")
		itemNotes = Request.Form("itemNotes")
		set invoice = Session("invoice")
		invoice.attachNotes selLineNo, itemNotes
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice attachNotes"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub changePref(prefType)
		dim pref
		dim changeStatus
		dim ssql

		set invoice = Session("invoice")
		pref = Request.QueryString("pref")
		changeStatus = Request.QueryString("changeStatus")
		select case prefType
			case "starch"
					invoice.starchPref = pref
					Session("starchPref") = pref
					if changeStatus = "yes" then
						ssql = "Update Customer Set starchPreferenceName ='" & pref & "' Where customerSequenceNumber=" &  custSeqNumber
						QryExecute ssql
					end if
			case "finish"
					invoice.finishPref = pref
					Session("finishPref") = pref
					if changeStatus = "yes" then
						ssql = "Update Customer Set finishPreferenceName ='" & pref & "' Where customerSequenceNumber=" &  custSeqNumber
						QryExecute ssql
					end if
		end select

	end sub

	sub initialize()
		curr_LineNo = ""
		upchargeSet = "False"
		colorSet = "False"
		patternSet = "False"
		brandSet = "False"
		isDueDateSet =0
		selectedDept =-1
		selItemId =-1
		selUpchargeValue = ""
		selPatternValue = ""
		selBrandValue = ""
		selColorValue =""
		getCustomerDetails
		invoice.priceListId = custPriceList
		invoice.setStoreDays storeId
		getCommonItems
		getAllDepartments
		getAllStarchPref
		getAllFinishPref
		getCustLoyalty
	end sub

	function getPriceTableMultiplier(priceListID)
		dim query, rs

		getPriceTableMultiplier = 1.0

		if priceListID <> "" then
			query = "select dynamicMultiplier from pricelist where pricelistid = " & priceListID
			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				getPriceTableMultiplier = rs("dynamicMultiplier")
			end if

			set rs = nothing
		end if
	end function

	function getPriceTableRoundOff(priceListID)
		dim query, rs

		getPriceTableRoundOff = 0.01

		if priceListID <> "" then
			query = "select dynamicRoundOff from pricelist where pricelistid = " & priceListID
			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				getPriceTableRoundOff = rs("dynamicRoundOff")
			end if

			set rs = nothing
		end if
	end function

	function getPriceTableSourceID(priceListID)
		dim query, rs

		getPriceTableSourceID = -1

		if priceListID <> "" then
			query = "select dynamicSourceID from pricelist where pricelistid = " & priceListID
			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				getPriceTableSourceID = rs("dynamicSourceID")
			end if

			set rs = nothing
		end if
	end function



	sub saveInvoiceWithSplit()
		dim autoInvNos

		if ObjMiscSetUp.Count > 0 then
			autoInvNos = ObjMiscSetUp.Item("useAutomaticInvoiceNumbers")
		else
			autoInvNos = false
		end if
		set invoice = Session("invoice")
		if autoInvNos then
			saveInvoice true
		else
			Response.Redirect "multipleInvoiceNos.asp?targetPage=detail&addOrEdit=" & addOrEdit _
									& "&onHold=0&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
									& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
									& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
									& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
									& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue _
									& "&selBrand=" & selBrandValue & "&originPage=" & originatingPage
		end if
	end sub

	sub holdInvoice()
		dim autoInvNos
		dim empId
		dim terminalId
		dim empName
		dim storename

		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")
		if ObjMiscSetUp.Count > 0 then
			autoInvNos = ObjMiscSetUp.Item("useAutomaticInvoiceNumbers")
		else
			autoInvNos = false
		end if
		set invoice = Session("invoice")

		select case addOrEdit
			case "add"
				if autoInvNos then
					invoice.invoiceNo =""
					invoice.saveInvoice addOrEdit, empId, terminalId, 1, empName, storeName, true
					if err.number <> 0 then
						set errorList =  Server.CreateObject("Scripting.Dictionary")
						errorList.Add err.number,err.description & "-Function= Detailed Invoice holdInvoice-saveInvoice"
						set session("errorList") = errorList
						Response.redirect("../include/error.asp")
					end if
					Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
				else
					Response.Redirect "newInvoiceNumber.asp?addOrEdit=" & addOrEdit _
										& "&onHold=1&targetPage=detail" _
										& "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
										& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
										& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
										& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
										& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue _
										& "&selBrand=" & selBrandValue
				end if
			case "edit"
				invoice.saveInvoice addOrEdit, empId, terminalId, 1, empName, storeName, true
				if err.number <> 0 then
					set errorList =  Server.CreateObject("Scripting.Dictionary")
					errorList.Add err.number,err.description & "-Function= Detailed Invoice holdInvoice-saveInvoice"
					set session("errorList") = errorList
					Response.redirect("../include/error.asp")
				end if
				Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
		end select
	end sub

	sub saveInvoiceWithNoSplit()
		' when the user selects no split in split prompt & auto invoice no. is set to true
		set invoice = Session("invoice")
		invoice.splitTheInvoice = false
		if addOrEdit = "add" then
			invoice.invoiceNo =""
		end if
		checkForPrepay
		'saveInvoice false
	end sub

	sub saveInvoiceWithInvNo()
		dim Inv_submit
		dim invoiceNumber
		dim inv_onHold
		dim empId
		dim terminalId
		dim empName
		dim storeName

		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")
		set invoice = Session("invoice")
		Inv_submit = Request.QueryString("submit")
		curr_LineNo = Request.QueryString("lineNo")
		selectedDept = Request.QueryString("dept")
		if not IsEmpty(Request.QueryString("itIndex")) then
			itemsStartIndex = clng(Request.QueryString("itIndex"))
		else
			itemsStartIndex =0
		end if
		if not IsEmpty(Request.QueryString("upIndex")) then
			upChargeStartIndex = clng(Request.QueryString("upIndex"))
		else
			upChargeStartIndex =0
		end if
		if not IsEmpty(Request.QueryString("cIndex")) then
			colorsStartIndex = clng(Request.QueryString("cIndex"))
		else
			colorsStartIndex =0
		end if
		if not IsEmpty(Request.QueryString("pIndex")) then
			patternStartIndex = clng(Request.QueryString("pIndex"))
		else
			patternStartIndex =0
		end if
		'dueDateSet = Request.QueryString("isDueDateSet")
		addOrEdit = Request.QueryString("addOrEdit")
		if not IsEmpty(Request.QueryString("deptIndex")) then
			deptStartIndex = clng(Request.QueryString("deptIndex"))
		else
			deptStartIndex =0
		end if
		selItemId = Request.QueryString("selItemId")
		selUpchargeValue = Request.QueryString("selUp")
		selPatternValue = Request.QueryString("selPattern")
		selBrandValue = Request.QueryString("selBrand")
		selColorValue = Request.QueryString("selColor")
		originatingPage = Request.QueryString("originPage")
		inv_onHold = Request.QueryString("onHold")
		if Inv_submit = "ok" then
			invoiceNumber = Request.QueryString("invNo")
			invoice.invoiceNo =invoiceNumber
			if inv_onHold = 1 then
				invoice.saveInvoice addOrEdit, empId, terminalId, 1, empName, storeName, true
				if err.number <> 0 then
					set errorList =  Server.CreateObject("Scripting.Dictionary")
					errorList.Add err.number,err.description & "-Function= Detailed Invoice saveInvoiceWithInvNo-saveInvoice"
					set session("errorList") = errorList
					Response.redirect("../include/error.asp")
				end if
				Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
			else
				saveInvoice false
			end if
		else
			if inv_onHold = "0" then
				cancelDoneOperation
			end if
		end if
	end sub

	sub checkForOnDemandCoupon()
        'Does anything in this function matter other than calling the next steps? Feels like this was an old way of
        'doing ondemand before it was done on payment page and it just never got deleted.
		dim applyOnDemandCoupons
		dim promptForOnDemand

		set invoice = Session("invoice")

		if applyOnDemandCoupons then
			if ObjMiscSetUp.Count > 0 then
				promptForOnDemand = ObjMiscSetUp.Item("promptForOnDemandCoupons")
			else
				promptForOnDemand = false
			end if
			if promptForOnDemand then
				Response.Redirect "promptForOnDemandCoupons.asp?addOrEdit=" & addOrEdit _
								& "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
								& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
								& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
								& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
								& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue  & "&selBrand=" & selBrandValue
			else
				invoiceDone
				checkForSplit
			end if
		else
			invoiceDone
			checkForSplit
		end if
	end sub

	sub invoiceDone()
		dim tagsSameAsInvNo
		dim oneDiscount
		dim taxCodes

		set invoice = Session("invoice")


		if ObjMiscSetUp.Count > 0 then
			tagsSameAsInvNo = ObjMiscSetUp.Item("sameTagInvNumber")
			oneDiscount = ObjMiscSetUp.Item("oneDiscountPerInvoice")
		else
			tagsSameAsInvNo =true
			oneDiscount = false
		end if

		invoice.tagsSameAsInvNos = tagsSameAsInvNo

		if not IsObject(Session("taxCodes")) then
			getTaxCodes
		end if


		set taxCodes = Session("taxCodes")
		invoice.addOrEdit = addOrEdit
		invoice.invoiceDone oneDiscount, taxCodes

		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice -invoiceDone:invoiceDone"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub checkForSplit()

		dim splitPrompt
		dim splitInvoice

		if ObjMiscSetUp.Count > 0 then
			splitPrompt = ObjMiscSetUp.Item("promptBefoerInvSpli")
		else
			splitPrompt =false
		end if

		splitInvoice = invoice.isSplitInvoice()

		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice invoiceDone-isSplitInvoice"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if

		if splitInvoice =true then
			if splitPrompt = true then
				Response.Redirect "promptToSplit.asp?targetPage=detail&addOrEdit=" & addOrEdit _
								& "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
								& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
								& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
								& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
								& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue _
								& "&selBrand=" & selBrandValue & "&originPage=" & originatingPage
			else
				invoice.splitInvoice addOrEdit
				'saveInvoiceWithSplit
			end if
		end if
		''''by rahul
		'submit = "cancel"
		'call frompickup
		'''end rahul
		checkForPrepay
	end sub

	sub checkForPrepay()
		dim prePayAmt
		dim fullPrepay
		dim splitTheInvoice

		dim pickupAction
		pickupAction = Request.QueryString("submit")

		if ObjMiscSetUp.Count > 0 then
			fullPrepay = ObjMiscSetUp.Item("prepayInvoice")
		else
			fullPrepay =false
		end if

		prePayAmt = 0

		if (prePayAmt <= 0 OR pickupAction = "OnAccount" or addOrEdit = "edit") then
			splitTheInvoice = invoice.splitTheInvoice
			if splitTheInvoice then
				saveInvoiceWithSplit
			else
				checkForAutoInvNumbers
			end if
		else

			gotoPickUpScreen prePayAmt
		end if

	end sub

	sub checkForAutoInvNumbers()
		' when no need to split invoice
		dim autoInvNos

		if ObjMiscSetUp.Count > 0 then
			autoInvNos = ObjMiscSetUp.Item("useAutomaticInvoiceNumbers")
		else
			autoInvNos = false
		end if

		if autoInvNos = true then
			if addOrEdit ="add" then
				invoice.invoiceNo =""
			end if

			saveInvoice false
		else

			select case addOrEdit
				case "add"

					Response.Redirect "newInvoiceNumber.asp?addOrEdit=" & addOrEdit _
									& "&onHold=0&targetPage=detail" _
									& "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
									& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
									& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
									& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
									& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue _
									& "&selBrand=" & selBrandValue
				case "edit"
					saveInvoice false
			end select

		end if
	end sub

	sub saveInvoice(updateMainInvNo)
		dim invoicesDictionary
		dim invoicesArray
		dim counter
		dim aInvoice
		dim splitTheInvoice

		splitTheInvoice = invoice.splitTheInvoice
		if splitTheInvoice then
			set invoicesDictionary = invoice.invoicesDictionary
			if addOrEdit = "add" and updateMainInvNo then
				invoice.invoiceNo = ""
			end if

			invoicesArray = invoicesDictionary.Items
			for counter=0 to invoicesDictionary.Count-1
				set aInvoice = invoicesArray(counter)
				aInvoice.invoiceNo =""
			next

		end if

		checkForTags

	end sub

	sub getTaxCodes()
		dim objResultSet
		dim ssql

		ssql = "Select taxCode, description, taxPercent FROM Tax Where storeID=" & clng(storeId)
		set objResultSet = getDisconnectedRecordset(ssql)
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice getTaxCodes"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		set Session("taxCodes") = objResultSet
	end sub

	sub gotoPickUpScreen(amountDue)
		dim pickupObj
		dim prepayAmt


		set pickupObj = Server.CreateObject("ShahCorpComponents.pickup")

		pickupObj.DBConnectionString = Session("shahcorpDSN")
		pickupObj.storeId = storeId
		pickupObj.initStorePaymentTypeInfo()
		pickupObj.userAction = "prepay"
		pickupObj.addOrEdit = addOrEdit
		pickupObj.custSeqNumber = custSeqNumber
		pickupObj.storeId = storeId
		'prepayAmt = invoice.getPrePayAmount()
		prepayAmt = amountDue

		pickupObj.addInvoiceObjToPickup invoice
		set Session("pickupObj") = pickupObj
		Response.Redirect "pickup.asp?targetPage=detail&userAction=prepay&addOrEdit=" & addOrEdit _
							& "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
							& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
							& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
							& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
							& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue & "&selBrand=" & selBrandValue _
							& "&originPage=" & originatingPage & "&prepayAmt=" & prepayAmt
	end sub

	sub prePayInvoice()
		set invoice = Session("invoice")
		gotoPickUpScreen invoice.invoiceTotal
	end sub

	sub deleteItem()
		dim selLineNo

		selLineNo = Request.QueryString("itemId")
		set invoice = Session("invoice")
		invoice.deleteItem selLineNo
		invoice.deleteHeatSeal selLineNo
		query = "delete Employeetip where TicketNumber = '" & invoice.ticketNo & "' and LineItemNumber = " & selLineNo
		qryexecute query
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice deleteItem"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub addCharge()
		dim chgDesc
		dim amount
		dim taxCode
		dim countAs

		chgDesc = Request.Form("txtchargedesc")
		amount = Request.Form("txtcharge")
		taxCode = Request.Form("taxrates")
		countAs = Request.Form("countas")
		set invoice = Session("invoice")
		invoice.addChargeLineNew storeid, custPriceList, amount, chgDesc, countAs, selectedDept, 1
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice addCharge"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if

	end sub

	sub overrideLinePrice()
		dim selLine
		dim newPrice

		selLine = Request.Form("itemIdToChange")
		newPrice = Request.Form("txtPrice")
		set invoice = Session("invoice")
		invoice.overRidePrice newPrice, selLine

		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice overrideLinePrice"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub changeQuantity()
		dim quantity
		dim selLineNo

		selLineNo = Request.QueryString("itemId")
		quantity = Request.QueryString("quantity")
		set invoice = Session("invoice")
		invoice.changeQuantity quantity, selLineNo

		upchargeSet = invoice.isUpchargeSetForItem(selLineNo)
		colorSet = invoice.isColorSetForItem(selLineNo)
		patternSet = invoice.isPatternSetForItem(selLineNo)
		brandSet = isBrandSetForItem(selLineNo)

		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice changeQuantity"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub addCoupon()
		dim couponId
		dim couponOrLoyalty

		couponId = Request.QueryString("couponId")
		couponOrLoyalty = Request.QueryString("CorL")
		set invoice = Session("invoice")
		if couponOrLoyalty = "C" then
			invoice.addCoupon couponId
		else
			invoice.addLoyalty couponId
		end if
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice addCoupon"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub getLoyalty()
		dim tempVal
		dim offers
		dim oneDiscount
		dim upSet
		dim cSet
		dim patSet
		dim couponRst
		dim allowCoupons

		oneDiscount = false
		allowCoupons = false
		Set Session("displayCoupons")= nothing
		set invoice = Session("invoice")
		if ObjMiscSetUp.Count > 0 then
			allowCoupons = ObjMiscSetUp.Item("allowDropoffCoupons")
			oneDiscount = ObjMiscSetUp.Item("oneDiscountPerInvoice")
		end if
		tempVal =true

		if not allowCoupons then
			alertMessage = "Loyalty discounts are not allowed at drop off"
			exit sub
		end if
		if oneDiscount then
			if invoice.vipQualified then
				tempVal =false
				alertMessage = "Cannot add loyalty discounts as the customer is VIP qualified & only one discount is allowed."
			else
				tempVal  = invoice.isFirstCoupon()
				if err.number <> 0 then
					set errorList =  Server.CreateObject("Scripting.Dictionary")
					errorList.Add err.number,err.description & "-Function= Detailed Invoice getLoyalty-isFirstCoupon"
					set session("errorList") = errorList
					Response.redirect("../include/error.asp")
				end if
				if not tempVal then
					alertMessage = "There exists one discount and only one discount is allowed"
				end if
			end if
		else
			if invoice.vipQualified then
				tempVal = invoice.isVipValidWithOtherOffer()
				if err.number <> 0 then
					set errorList =  Server.CreateObject("Scripting.Dictionary")
					errorList.Add err.number,err.description & "-Function= Detailed Invoice getLoyalty-isVipValidWithOtherOffer"
					set session("errorList") = errorList
					Response.redirect("../include/error.asp")
				end if
				if Not tempVal then
					alertMessage = "Customer is VIP qualified and VIP is not valid with other offers."
				end if
			end if
			if tempVal then
				if Not invoice.isFirstCoupon then
					tempVal = invoice.validateCouponAdd()
					if err.number <> 0 then
						set errorList =  Server.CreateObject("Scripting.Dictionary")
						errorList.Add err.number,err.description & "-Function= Detailed Invoice getLoyalty-validateCouponAdd"
						set session("errorList") = errorList
						Response.redirect("../include/error.asp")
					end if
					if not tempVal then
						alertMessage = "There exists one discount on the invoice which is not valid with other offer"
					end if
				end if
			end if
		end if
		if tempVal then
			invoice.getQualifyingLoyalty
			if err.number <> 0 then
				set errorList =  Server.CreateObject("Scripting.Dictionary")
				errorList.Add err.number,err.description & "-Function= Detailed Invoice getLoyalty-getQualifyingCoupons"
				set session("errorList") = errorList
				Response.redirect("../include/error.asp")
			end if
			Set couponRst = invoice.getDisplayCouponRst()
			if err.number <> 0 then
				set errorList =  Server.CreateObject("Scripting.Dictionary")
				errorList.Add err.number,err.description & "-Function= Detailed Invoice getLoyalty-getDisplayCouponRst"
				set session("errorList") = errorList
				Response.redirect("../include/error.asp")
			end if
			if couponRst.RecordCount > 0 then
				couponRst.PageSize =maxCouponsCount
				Set Session("displayCoupons")= couponRst
				Response.Redirect "allCoupons.asp?targetPage=detail&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
								& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
								& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
								& "&addOrEdit=" & addOrEdit & "&deptIndex=" & deptStartIndex _
								& "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
								& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue & "&selBrand=" & selBrandValue _
								& "&originPage=" & originatingPage	& "&CorL=" & "L"
			else
				alertMessage = "No Qualifying Discounts to add."
			end if
		end if
	end sub


	function getCoupons()
		dim tempVal
		dim coupons
		dim oneDiscount
		dim upSet
		dim cSet
		dim patSet
		dim couponRst
		dim allowCoupons

		oneDiscount = false
		allowCoupons = false
		Set Session("displayCoupons") = nothing
		set invoice = Session("invoice")

		if ObjMiscSetUp.Count > 0 then
			allowCoupons = ObjMiscSetUp.Item("allowDropoffCoupons")
			oneDiscount = ObjMiscSetUp.Item("oneDiscountPerInvoice")
		end if
		tempVal =true

		getCoupons = false

		if not allowCoupons then
			alertMessage = "Coupons are not allowed at drop off"
			exit function
		end if
		if oneDiscount then
			if invoice.vipQualified then
				tempVal =false
				alertMessage = "Can not add coupons as the customer is vip qualified & only one discount is allowed."
			else
				tempVal  = invoice.isFirstCoupon()
				if not tempVal then
					alertMessage = "There exists one coupon and only one discount is allowed"
				end if
			end if
		else
			if invoice.vipQualified then
				tempVal = invoice.isVipValidWithOtherOffer()
				if Not tempVal then
					alertMessage = "Customer is vip qualified and vip is not valid with other offers."
				end if
			end if
			if tempVal then
				if Not invoice.isFirstCoupon then
					tempVal = invoice.validateCouponAdd()
					if not tempVal then
						alertMessage = "There exists one coupon on the invoice which is not valid with other offer"
					end if
				end if
			end if
		end if
		if tempVal then
			invoice.getQualifyingCoupons
			Set couponRst = invoice.getDisplayCouponRst()
			if couponRst.RecordCount > 0 then
				getCoupons = true
			else
				alertMessage = "No Qualifying Coupons to add."
			end if
		end if
	end function

	sub gotoCoupons()
		dim invoice
		dim couponRst

		set invoice = Session("invoice")
		invoice.getQualifyingCoupons
		Set couponRst = invoice.getDisplayCouponRst()
		couponRst.PageSize =maxCouponsCount
		Set Session("displayCoupons")= couponRst
		Response.Redirect "allCoupons.asp?targetPage=detail&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
						& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
						& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
						& "&addOrEdit=" & addOrEdit & "&deptIndex=" & deptStartIndex _
						& "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
						& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue & "&selBrand=" & selBrandValue _
						& "&originPage=" & originatingPage	& "&CorL=" & "C" & "&itemCntWCost=" & getItemWCostCount
	end sub

    function getItemWCostCount
        dim cnt, lineItems
        cnt = 0
        set lineItems = invoice.lineItems
	    If lineItems.RecordCount > 0 Then
	        lineItems.MoveFirst
	        While Not lineItems.EOF

	            if lineItems("lineItemTotal") > 0 and lineItems("itemType") = "IT" then
	                cnt = cnt + lineItems("quantity")
                end if
	            lineItems.MoveNext
	        Wend
	    End If

        getItemWCostCount = cnt
    end function

	function getDescriptorQuantity(quantity, lastItemQuantity)
		dim autoQuantityOnDescriptors

		if ObjMiscSetUp.Count > 0 then
			autoQuantityOnDescriptors = ObjMiscSetUp.Item("autoQuantityOnDescriptors")
		else
			autoQuantityOnDescriptors = false
		end if

		getDescriptorQuantity = quantity

		if autoQuantityOnDescriptors and quantity = "" and lastItemQuantity <> "" then
			getDescriptorQuantity = lastItemQuantity
		end if

	end function

	sub addUpCharge()
		dim quantity
		dim groupSimilarItems


		set invoice = Session("invoice")

		if not userHasSelected and invoice.isUpchargeSetForItem(curr_LineNo) then
			if not ((f_colors and Session("totalColorscount") <> 0 and not invoice.isColorSetForItem(curr_LineNo)) or _
				 (f_pattern and Session("totalPatternscount") <> 0 and not invoice.isPatternSetForItem(curr_LineNo))) then
				selectNextItem
			end if
		end if

		selUpchargeValue = Request.QueryString("upchargeid")
		quantity = getDescriptorQuantity(Request.QueryString("quantity"), lastItemQuantity)
		if ObjMiscSetUp.Count > 0 then
			groupSimilarItems = ObjMiscSetUp.Item("groupSimilarItems")
		else
			groupSimilarItems = true
		end if


		invoice.addUpcharge curr_LineNo, selUpchargeValue, quantity, groupSimilarItems, priceTableMultiplier, priceTableRoundOff


		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice addUpCharge"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if

		upchargeSet = invoice.isUpchargeSetForItem(curr_LineNo)

		set Session("invoice") = invoice
	end sub

	sub addColor()
		dim quantity
		dim groupSimilarItems

		set invoice = Session("invoice")

		if not userHasSelected and invoice.isColorSetForItem(curr_LineNo) then
			if not ((f_upcharges and Session("totalUpchargescount") <> 0 and not invoice.isUpchargeSetForItem(curr_LineNo)) or _
				(f_pattern and Session("totalPatternscount") <> 0 and not invoice.isPatternSetForItem(curr_LineNo))) then
				selectNextItem
			end if
		end if

		selColorValue= Request.QueryString("colorid")
		quantity = getDescriptorQuantity(Request.QueryString("quantity"), lastItemQuantity)
		if ObjMiscSetUp.Count > 0 then
			groupSimilarItems = ObjMiscSetUp.Item("groupSimilarItems")
		else
			groupSimilarItems = true
		end if

        if useAdv then
            if quantity = "" then
                quantity = 1
            end if
            if lastItemQuantity = "" then
                lastItemQuantity = 1
            end if
            'For some reason the add descriptor method multiples the input quantity by the number of items. Maybe
            'used to be for the old advanced screen and that was the only way to set all the items to have the same descriptor
            'but we no longer want that so we divide it here because I don't want to mess in the dll
            quantity = quantity / lastItemQuantity
            invoice.addDescriptor curr_LineNo, selColorValue, "CO", quantity
        else
		    invoice.addColor curr_LineNo, selColorValue, quantity, groupSimilarItems, priceTableMultiplier, priceTableRoundOff
		end if

		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice addColor"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if

		colorSet = invoice.isColorSetForItem(curr_LineNo)
	end sub

	sub addPattern()
		dim quantity
		dim groupSimilarItems

		set invoice = Session("invoice")

		if not userHasSelected and invoice.isPatternSetForItem(curr_LineNo) then
			if not ((f_colors and Session("totalColorscount") <> 0 and not invoice.isColorSetForItem(curr_LineNo)) or _
				(f_upcharges and Session("totalUpchargescount") <> 0 and not invoice.isUpchargeSetForItem(curr_LineNo))) then
				selectNextItem
			end if
		end if

		selPatternValue= Request.QueryString("patternid")
		quantity = getDescriptorQuantity(Request.QueryString("quantity"), lastItemQuantity)

		if ObjMiscSetUp.Count > 0 then
			groupSimilarItems = ObjMiscSetUp.Item("groupSimilarItems")
		else
			groupSimilarItems = true
		end if

        if useAdv then
            if quantity = "" then
                quantity = 1
            end if
            if lastItemQuantity = "" then
                lastItemQuantity = 1
            end if
            quantity = quantity / lastItemQuantity  'See note for color here
            invoice.addDescriptor curr_LineNo, selPatternValue, "PA", quantity
        else
		    invoice.addPattern curr_LineNo, selPatternValue, quantity, groupSimilarItems, priceTableMultiplier, priceTableRoundOff
        end if

		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice addPattern"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if

		patternSet  = invoice.isPatternSetForItem(curr_LineNo)
	end sub

	sub addBrand()
		dim quantity

		set invoice = Session("invoice")

		selBrandValue= Request.QueryString("brandid")
		quantity = getDescriptorQuantity(Request.QueryString("quantity"), lastItemQuantity)
        if quantity = "" then
            quantity = 1
        end if
        if lastItemQuantity = "" then
            lastItemQuantity = 1
        end if
        quantity = quantity / lastItemQuantity 'See note for color here

        invoice.addDescriptor curr_LineNo, selBrandValue, "BR", quantity
        brandSet  = isBrandSetForItem(curr_LineNo)

		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice addBrand"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	function isBrandSetForItem(lineNum)
        Dim itemCnt, brCnt
        itemCnt = invoice.liColTotal("quantity", "lineNumber=" & lineNum & " AND itemtype='Item'")
        brCnt = invoice.liColTotal("quantity", "parentLineNumber=" & lineNum & " AND itemtype='Brand'")
        isBrandSetForItem = brCnt >= itemCnt
	end function

	sub checkMaxItemsPerDept()
		dim selItemId
		dim selItemQty
		dim selItemDeptId
		dim selItemPkgQty
		dim chkMaxItem
		dim currentQty
		dim departmentMasterRst

		isMaxItemExceedPerDept = false

		selItemId = Request.QueryString("itemId")
		if isnull(Request.QueryString("quantity")) or Request.QueryString("quantity") = "" then
			selItemQty = 1
		else
			selItemQty = clng(Request.QueryString("quantity"))
		end if

		if actionString = "getItemDetails" then
			selItemDeptId = clng(Request.QueryString("itemDeptId"))
			if IsNull(Request.QueryString("pkgQty")) or Request.QueryString("pkgQty") = "" then
				selItemPkgQty = 1
			else
				selItemPkgQty = clng(Request.QueryString("pkgQty"))
			end if
		else
			selItemDeptId = 0
			selItemPkgQty = 1
		end if

		set invoice = Session("invoice")

		chkMaxItem = invoice.checkAllowableItemCountPerDept(selItemId, selItemQty, selItemPkgQty, selItemDeptId, actionString)
		if err.number <> 0 then
			Response.write err.Description & ": Error in checkAllowableItemCountPerDept"
			Response.End
		end if
		currentQty = chkMaxItem(1)
		selItemDeptId = chkMaxItem(2)

		'maxItemCountPerDept = 32200
		set departmentMasterRst = Session("departmentMaster")
		departmentMasterRst.Filter = "departmentID=" & selItemDeptId
		If departmentMasterRst.RecordCount > 0 Then
		    maxItemCountPerDept = departmentMasterRst.Fields("maxItemsInReceipt").value
		    maxItemDeptName = departmentMasterRst.Fields("name").value
		    If IsNull(maxItemCountPerDept) Then
		        maxItemCountPerDept = 32200
		    Else
		        maxItemCountPerDept = clng(maxItemCountPerDept)
		    End If
		End If

		departmentMasterRst.Filter = adFilterNone
		departmentMasterRst.MoveFirst

		If clng(currentQty) > clng(maxItemCountPerDept) Then
		    isMaxItemExceedPerDept = True
		End If
	end sub


	sub getItemDetails(selitemid, quantity, promptResponse)
		dim groupSimilarItems
		dim adjustDueDateForRoute

		if quantity = "" then
			quantity = 1
		end if
		if ObjMiscSetUp.Count > 0 then
			if ObjMiscSetup.Item("ForceOneItemLine") then
				groupSimilarItems = "-1"
				adjustDueDateForRoute = false
			else
				groupSimilarItems = ObjMiscSetup.Item("groupSimilarItems")
				adjustDueDateForRoute = ObjMiscSetup.Item("adjustDueDateForRoute")
			end if
		else
			groupSimilarItems = true
		end if
		set invoice = Session("invoice")

		if enableRedoMode then
			curr_LineNo = invoice.addItem (selItemId, groupSimilarItems, quantity, 0, 1)
			invoice.setLineToRedo curr_LineNo
		else
			curr_LineNo = invoice.addItem (selItemId, groupSimilarItems, quantity, priceTableMultiplier, priceTableRoundOff)
		end if

		if promptResponse <> "" then
				dim responseParts

				responseParts = split(promptResponse, "|")

    		invoice.attachNotes curr_LineNo, responseParts(0)

    		if ubound(responseParts) > lbound(responseParts) then
    			invoice.attachPromptReponse curr_LineNo, responseParts(1)
    		end if
    	end if

		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice getItemDetails"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if

		selUpchargeValue = ""
		selPatternValue = ""
		selBrandValue = ""
		selColorValue =""

		invoice.adjustDueDatesForWorkload
		if adjustDueDateForRoute then
			invoice.adjustDueDatesForRoute custSeqNumber
		end if

        if selectedDept <> "" and selectedDept <> "-1" then
            sqltxt = "select useheatseals from department where departmentid = " & selectedDept
            set rst = getDisconnectedRecordSet(sqltxt)
            if rst("useheatseals") then
                hasHSItems = 1
            end if
		end if


		if forceHSBeforeDetail and currHS <> "" then
            invoice.addHeatSealInfoForItem2 curr_LineNo, currHS
            usedHSList = usedHSList & "|" & currHS
            currHS = ""

		end if

	end sub

	sub setStartIndexForPaging()
		upChargeStartIndex = Request.Form("upChargePageCount")
		patternStartIndex = Request.Form("patternPageCount")
		colorsStartIndex = Request.Form("colorsPageCount")
		itemsStartIndex = Request.Form("ItemPageCount")
		deptStartIndex = Request.Form("DeptPageCount")
		if(IsEmpty(upChargeStartIndex)) OR upChargeStartIndex ="0"  OR upChargeStartIndex ="" then
			upChargeStartIndex=1
		else
			upChargeStartIndex=Int(upChargeStartIndex)

		end if
		if(IsEmpty(patternStartIndex)) Or patternStartIndex="0"  OR patternStartIndex ="" then
			patternStartIndex=1
		else
			patternStartIndex=Int(patternStartIndex)
		end if
		if(IsEmpty(colorsStartIndex)) Or colorsStartIndex="0"  OR colorsStartIndex ="" then
			colorsStartIndex=1
		else
			colorsStartIndex=Int(colorsStartIndex)
		end if
		if(IsEmpty(itemsStartIndex)) Or itemsStartIndex="0"  OR itemsStartIndex ="" then
			itemsStartIndex=1
		else
			itemsStartIndex=Int(itemsStartIndex)
		end if
		if(IsEmpty(deptStartIndex)) Or deptStartIndex="0"  OR deptStartIndex ="" then
			deptStartIndex=1
		else
			deptStartIndex=Int(deptStartIndex)
		end if
	end sub

	sub getCustLoyalty()
		dim ssql
		dim rst
		ssql = "select * from loyaltyCustomer where customerSequenceNumber =" & Clng(custSeqNumber)
		set rst = getDisconnectedRecordset(ssql)
		if rst.Recordcount> 0 then
			loyaltyCard = rst.fields("loyaltyCardId")
			loyaltyEnabled = rst.fields("enabled")
		end if
		ssql = "select * from loyalty"
		set rst = getDisconnectedRecordset(ssql)
		if rst.Recordcount>0 then
			prPurchaseLoy = rst.fields("promptPurchase")
			prInvoice = rst.fields("promptAtInvoice")
			prVisits = rst.fields("Visits")
			prLoyOffers = rst.fields("promptIfOffers")
		end if
		ssql = "select sum(noOfuses) as noofuses from loyaltycustomeroffers where customersequencenumber =" & Clng(custSeqNumber)
		set rst = getDisconnectedRecordset(ssql)
		numLoyOffers = rst.fields("noofuses")

		ssql = "select * from customer where customersequencenumber = " & clng(custSeqNumber)
		set rst = getDisconnectedRecordset(ssql)
		custVisits = rst.fields("visitCount")

	end sub

	function amountCustomerSpent(customerSeq, days)
		dim query, rs
		dim result

		query = "select sum(invoiceTotal) as total from Ticket where ticketStatus='FI' " _
		& " and customerSequenceNumber = " & customerSeq _
		& " and datediff(mm, createdDate, getdate()) < " & days

		set rs = getdisconnectedrecordset(query)


		result = 0

		if rs.recordcount > 0 then
			result = rs("total")
		end if

		set rs = nothing

		amountCustomerSpent = result


	end function

	function isCustomerVIPQualified(customerSeq)
		dim query, rs
		dim moneySpent
		dim moneyRequired


		query = "select isnull(VIPValidNbrOfMonths, 30) as VIPValidNbrOfMonths, isnull(VIPMinQualAmount, 10000) as VIPMinQualAmount from PriceList where priceListID = " & custPriceList
		set rs = getdisconnectedrecordset(query)

		moneySpent = 0
		moneyRequired = 0

		if rs.recordcount > 0 then
			moneySpent = amountCustomerSpent(customerSeq, rs("VIPValidNbrOfMonths"))
			moneyRequired = rs("VIPMinQualAmount")
		end if

		set rs = nothing

		isCustomerVIPQualified = (moneySpent > moneyRequired)
	end function


	function getCustomerDefaultPriceListID(customerseq)
		dim query, rs

		query = " select defaultPriceListId from customer where customersequencenumber = " & customerseq
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getCustomerDefaultPriceListID = rs("defaultPriceListId")
		end if

		set rs = nothing
	end function

	function isPromptToDeliverEnabled(customersequencenumber)
		dim query, rs

		isPromptToDeliverEnabled = false

		if ObjMiscSetup.Item("promptToDeliver") then
			query = " select routenumber from customer where routenumber = 0 and customersequencenumber = " & customersequencenumber
			set rs = getdisconnectedrecordset(query)
			if rs.recordcount > 0 then
				isPromptToDeliverEnabled = true
			end if
			set rs = nothing
		end if

	end function

	function getCustomerSeqFromTicket(ticketNumber)
		dim query, rs
		if ticketNumber <> "" then
			query = " select customersequencenumber from ticket where ticketnumber = " & ticketNumber
			set rs = getdisconnectedrecordset(query)
			if rs.recordcount > 0 then
				getCustomerSeqFromTicket = rs("customersequencenumber")
			end if
		end if
	end function

	sub getCustomerDetails()
		dim ssql
		dim objResultSet
		dim areaCode
		dim vipQualified

		ssql = "Select IsNull(starchPreferenceName, '') as starchPreferenceName, IsNull(finishPreferenceName, '') as finishPreferenceName, defaultPriceListId, " _
				& " IsNull(firstName, '') as firstName, IsNull(middleInitial,'') as middleInitial, " _
				& " IsNull(lastName, '') as lastName, Isnull(mainAreaCode, '') as mainAreaCode, " _
				& " isnull(mainPhone, '') as mainPhone, vipExpiryDate, vipQualAmount, " _
				& " isnull(vipEligible, 0) as vipEligible, isnull(vipQualified, 0) as vipQualified, referralQualified, isNull(routeNumber,-1) as routeNumber, dbo.getCustomerVisits(customer.customersequencenumber, null, null) as visitCount, " _
				& " IsNull(screenNotes,'') as screenNotes, taxExempt, surchargeExempt from customer where customerSequenceNumber=" _
				& Clng(custSeqNumber)
		Set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Recordcount > 0 then
			objResultSet.MoveFirst
			customerName  = Trim(objResultSet.fields("firstName") &  " "  & objResultSet.fields("middleInitial") & " " & objResultSet.fields("lastName"))
			session("customername") = customerName
			areaCode = objResultSet.fields("mainAreaCode")
			custPhone = objResultSet.fields("mainPhone")
			if len(Trim(custPhone)) > 0 then
				if len(Trim(areaCode)) > 0 then
					custPhone = areaCode & "-"  & Mid(custPhone,1,3) & "-" & Mid(custPhone,4,len(custPhone))
				end if
			end if
			session("customerphone") = custPhone
			if isnull(objResultSet.fields("defaultPriceListId").Value) then
				Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
			end if
			custPriceList = objResultSet.fields("defaultPriceListId").Value
			Session("priceList") = custPriceList
			Session("starchPref") = objResultSet.fields("starchPreferenceName").Value
			Session("finishPref") = objResultSet.fields("finishPreferenceName").Value
			Session("ScreenNotes") = objResultSet.fields("screenNotes").Value

			invoice.custVisitCount = objResultSet.Fields("visitCount").Value
			invoice.excludeTaxes = objResultSet.Fields("taxExempt").Value
			invoice.excludeSurcharges = objResultSet.Fields("surchargeExempt").Value

			vipQualified = objResultSet.Fields("vipEligible").Value and isCustomerVIPQualified(custSeqNumber)

			if vipQualified then
				'invoice.vipQualAmount = objResultSet.Fields("vipQualAmount").Value
				invoice.vipQualified = true
				if not isnull(objResultSet.Fields("vipExpiryDate").Value) then
					invoice.vipExpiryDate = objResultSet.Fields("vipExpiryDate").Value
				else
					invoice.vipExpiryDate = Date()
				end if
			else
				invoice.vipQualified = false
			end if



			invoice.referralQualified = true

			if addoredit = "add" or invoice.isQuickInvoice() then
				invoice.routeNumber = objResultSet.Fields("routeNumber").Value
			end if
		end if

	end sub

	'MWiemann 01 DEC 03 -- procedure to determine if customer has notes saved for them
	sub doesCustHaveNotes()
		dim ssql
		dim notesRst
		dim screen, invoice
		hasNotes = 0
		ssql = "select screennotes, invoicenotes FROM customer " _
			   & "WHERE customersequencenumber = " & custSeqNumber
		set notesRst = getDisconnectedRecordset(ssql)
		screen = notesRst.fields("screennotes").value
		invoice = notesRst.fields("invoicenotes").value
		if len(screen) > 0 or len(invoice) > 0 then
			hasNotes = 1
		end if

	end sub

	function CreateSortOrder()
		dim sortMethod

		sortMethod = 0

		if ObjMiscSetUp.Count > 0 then
			sortMethod = ObjMiscSetUp.Item("ItemSortMethod")
		end if

		if sortMethod = 0 then
			CreateSortOrder = " ORDER BY displaySequence"
		else
			CreateSortOrder = " ORDER BY useCounter DESC"
		end if
	end function

	sub getItemsForDept()
		dim ssql
		dim itemsRst

		ssql = "select priceListItemID, departmentID, itemName, price, imageFileName, qtyInInventory, isnull(options, '') as options, isnull(prompt, '') as prompt " _
				& " FROM PriceListItem where departmentID=" & clng(selectedDept) _
				& " AND priceListID in (" & clng(custPriceList) & ", " & priceTableSourceID & ")" _
				& " AND disabled=0 "

		ssql = ssql & CreateSortOrder()

		set itemsRst = getDisconnectedRecordset(ssql)
		if itemsRst.Recordcount > 0 then
			itemsRst.PageSize = maxItemsCount
		end if
		Set Session("ItemsToBeShown")= itemsRst
		selItemId =-1
		selUpchargeValue =""
		selColorValue = ""
		selPatternValue =""
		selBrandValue =""
	end sub

	sub getCommonItems()
		dim commResultSet
		dim ssql

		'Modified by vivek on 18 Feb 2003 to fix the Issue 298
		'Where Condition PLI.PriceListID = Pl.PriceListID included in the following query to prevent the Cartesian Product
		'This query was returning duplicate records.
		ssql ="SELECT PLI.priceListItemID, PLI.departmentID, PLI.itemName, PLI.price, PLI.imageFileName, PLI.qtyInInventory, isnull(options, '') as options, isnull(prompt, '') as prompt " _
			  & " FROM PriceListItem PLI, PriceList PL WHERE PLI.PriceListID = Pl.PriceListID " _
			  & " AND commonItem=1 AND disabled =0  AND PL.storeId = " & clng(storeId)

		if priceTableSourceID > 0 then
			ssql = ssql & " AND PL.priceListID = " & priceTableSourceID
		else
			ssql = ssql & " AND PL.priceListID = " & custPriceList
		end if

		ssql = ssql & CreateSortOrder()

		set commResultSet = getDisconnectedRecordset(ssql)
		if commResultSet.Recordcount > 0 then
			commResultSet.PageSize = maxItemsCount
		end if
		Set Session("ItemsToBeShown")= commResultSet
	End sub



	sub getAllDepartments()
		dim ssql
		dim objResultSet

		ssql = " Select departmentID, name, splitInvoice, imageFileName, maxItemsInReceipt from Department where "
		ssql = ssql & " storeId =" & clng(storeId) & " and name != 'Subscription' AND disabled=0 "

		if priceTableSourceID > 0 then
			ssql = ssql & " AND priceListID = " & priceTableSourceID
		else
			ssql = ssql & " AND priceListID = " & custPriceList
		end if

		ssql = ssql & " And name <> 'SpecialOffers' "
		ssql = ssql & " Order by priceListID, displaySequence "

		Set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.RecordCount > 0 then
			objResultSet.PageSize = maxDeptCount
		end if
		set Session("departmentMaster") = objResultSet
	end sub

	sub getAllStarchPref()
		dim ssql
		dim objResultSet
		ssql ="SELECT starchPreferenceName, imageFileName FROM StoreStarchPreference where storeid=" & clng(storeId) _
					& " AND enabled=1 Order by displaySequence"
		Set objResultSet = getDisconnectedRecordset(ssql)
		set Session("starchPrefMaster") = objResultSet
	end sub

	sub getAllFinishPref()
		dim ssql
		dim objResultSet

		ssql ="SELECT finishPreferenceName, imageFileName FROM StoreFinishPreference where storeid=" & clng(storeId) _
				& " AND enabled=1 Order by displaySequence"
		Set objResultSet = getDisconnectedRecordset(ssql)
		set Session("finishPrefMaster") = objResultSet
	end sub

	function getDistinctUpcharges(selItemId)
        dim ssql, upChargeRst

        ssql ="Select descriptorName, price, imageFileName, displaySequence From itemDescriptorPrice where descriptorType='UP' " _
				& " AND priceListItemId =" & clng(selItemId) _
				& " AND disabled=0"

		ssql = ssql & CreateSortOrder()
		set upChargeRst = getDisconnectedRecordset(ssql)
		Session("totalUpchargescount") = upChargeRst.recordcount
        upChargeRst.PageSize = maxSubItemCount
		set getDistinctUpcharges = upChargeRst
		if not useOverlay then
		    Set Session("upcharges")= upChargeRst
	    end if
    End function

	function getDistinctColors(selItemId)
        dim ssql, colorsRst

        if useAdv then
            ssql = " select descriptor.name descriptorName, price, icon imageFileName, descriptor.displayOrder displaySequence " _
                & " from descriptor " _
                & " inner join descriptorgroup on descriptor.descriptorgroupid = descriptorgroup.descriptorgroupid " _
                & " where descriptorgroup.type = 'CO'"

            if ObjMiscSetUp.Count > 0 then
                ssql = ssql & " order by descriptor.displayOrder, descriptorName"
            else
                ssql = ssql & " order by UsageCounter"
            end if
        else
            ssql ="Select descriptorName, imageFileName, displaySequence From itemDescriptorPrice where descriptorType='CO' " _
                    & " AND priceListItemId =" & clng(selItemId) _
                    & " AND disabled=0"
            ssql = ssql & CreateSortOrder()
		end if
		set colorsRst = getDisconnectedRecordset(ssql)
		Session("totalColorscount") = colorsRst.recordcount
		colorsRst.PageSize = maxSubItemCount
		set getDistinctColors = colorsRst
		if not useOverlay then
		    Set Session("colors")= colorsRst
	    end if
	End function

	function getDistinctPatterns(selItemId)
		dim ssql, patternRst
        if useAdv then
            ssql = " select descriptor.name descriptorName, price, icon imageFileName, descriptor.displayOrder displaySequence " _
                & " from descriptor " _
                & " inner join descriptorgroup on descriptor.descriptorgroupid = descriptorgroup.descriptorgroupid " _
                & " where descriptorgroup.type = 'PA'"

            if ObjMiscSetUp.Count > 0 then
                ssql = ssql & " order by descriptor.displayOrder, descriptorName"
            else
                ssql = ssql & " order by UsageCounter"
            end if
        else
            ssql ="Select descriptorName, imageFileName, displaySequence From itemDescriptorPrice where descriptorType='PA' " _
                    & " AND priceListItemId =" & clng(selItemId) _
                    & " AND disabled=0"
            ssql = ssql & CreateSortOrder()
		end if
		set patternRst = getDisconnectedRecordset(ssql)
        Session("totalPatternscount") = patternRst.recordCount
        patternRst.PageSize = maxSubItemCount
		set getDistinctPatterns = patternRst
		if not useOverlay then
		    Set Session("patterns")= patternRst
	    end if
	End function

	sub getDistinctBrands(selItemId, filterValue)
		dim ssql, patternRst

            ssql = " select top 50 descriptor.name descriptorName, price, icon imageFileName, descriptor.displayOrder displaySequence " _
                & " from descriptor " _
                & " inner join descriptorgroup on descriptor.descriptorgroupid = descriptorgroup.descriptorgroupid " _
                & " where descriptorgroup.type = 'BR'"
            if filterValue <> "" then
                ssql = ssql & " and descriptor.name like '%" & filterValue & "%' "
            end if
            if ObjMiscSetUp.Count > 0 then
                ssql = ssql & " order by descriptor.displayOrder, descriptorName"
            else
                ssql = ssql & " order by UsageCounter"
            end if

		set brandRsp = getDisconnectedRecordset(ssql)
        brandRsp.PageSize = maxSubItemCount
        Session("totalBrandscount") = brandRsp.recordCount

	End sub

	function createBrand()
		dim query, rs, brandName

		brandName = Request.QueryString("filterValue")

		query = " select descriptor.descriptorid, descriptor.descriptorgroupid "
		query = query & " from descriptor "
		query = query & " inner join descriptorgroup on descriptor.descriptorgroupid = descriptorgroup.descriptorgroupid "
		query = query & " where descriptorgroup.type = 'BR' "
		query = query & " and descriptor.name = '" & dbstr(brandName) & "'"

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount = 0 then
			query = " insert into descriptor (descriptorgroupid, name, displayOrder) "
			query = query & " select descriptorgroup.descriptorgroupid, '" & dbstr(brandName) & "', 1"
			query = query & " from descriptorgroup "
			query = query & " where descriptorgroup.type = 'BR' "
			qryexecute query
		end if

		set rs = nothing
	end function


  function checkIfDeptExists(deptId)
	dim retVal
	dim counter
	dim maxCount

	retVal = false
	maxCount = ubound(deptIds)
	if ubound(deptIds) > 0 then
		for counter =1 to maxCount
			'Response.Write "deptId =" & deptIds(counter)
			if deptId = deptIds(counter) then
				retVal = true
				exit for
			end if
		next
	end if
	checkIfDeptExists = retVal
  end function


	function debugLineItems(lines)
	    Dim liClone
	    Dim invoicesArray
	    Dim counter
	    Dim aInvoice

	    Set liClone = lines.Clone

	    liClone.filter = adFilterNone

	    If liClone.RecordCount > 0 Then
	        liClone.MoveFirst
	        While Not liClone.EOF
	            response.write liClone("deptid") & "--" & liClone("dueDate") & "--" & liClone("redo") & liClone("linenumber") & "--" & liClone("originallinenumber") & "--" & liClone("lineItemTotal") & ":" & liClone("taxableAmt") & "--" & liClone("deptname") & "--" & liClone("quantity") & "--" & liClone("itemname") & "--" & liClone("daysToProcess") & "--" & liClone("dueDate") & "<br>"
	            liClone.MoveNext
	        Wend
	    End If

	    response.write liClone.RecordCount & " Line Items" & "<br>"

	end function


	function getDeptDueDate(lines, deptID)
		dim linesClone
		dim max
		dim datedue

		set linesClone = lines.clone()

		max = "1/1/1980"

		linesClone.filter = "deptID=" & deptID

		if linesClone.recordcount > 0 then
			linesClone.movefirst
			while not (linesClone.eof or linesClone.bof)
				datedue = linesClone("duedate")

				if datediff("d", max, datedue) > 0 then
					max = datedue
				end if
				linesClone.moveNext
			wend
		end if
		set linesClone = nothing

		datedue = max

        dim weekdayDone, query, rs
        query = "select dayOfWeek from Department where departmentId = " & deptID
        set rs = getdisconnectedrecordset(query)
        weekdayDone = rs("dayOfWeek")
        if weekdayDone <> 0 then
            while Weekday(datedue) <> weekdayDone
                datedue = DateAdd("d", 1, datedue)
            wend
        end if


		getDeptDueDate = datepart("m", datedue) & "/" & datepart("d", datedue) & "/" & datepart("yyyy", datedue)
	end function

	function GenerateDayNotes()
	    dim query, rs
        dim colorRamp
        dim colorIdx
		dim idx
		dim cday, m, d, y

        colorRamp = Array("33FFFF", "66FFFF", "99FFFF", "CCFFFF", "FFFFCC", "FFFF99", "FFCC66", "FF9933", "FF6600", "FF3300", "FF0000")

        query = "select distinct datepart(m, ds.date) as month, datepart(d, ds.date) as day, datepart(yyyy, ds.date) as year, cast(((ds.PiecesDue * 100) / dq.PiecesDue) as varchar)  as filled, ds.DepartmentName "
        query = query & " from dailystatistics ds, DepartmentQuota dq where "
        query = query & " datediff(m, dateadd(m, datediff(m, 0, getdate()), 0), ds.date) < 2 "
        query = query & " and ds.departmentName = dq.departmentName "
        query = query & " and dq.PiecesDue is not null "

        set rs = getdisconnectedrecordset(query)

        while not(rs.eof or rs.bof)
            colorIdx = rs("filled") / 10
            if colorIdx > 10 then
                colorIdx = 10
            end if
            Response.write "AddDayNote(" & rs("month") & "," & rs("day") & "," & rs("year") & ",'" & rs("DepartmentName") & "','" & rs("filled") & "% Filled');"
            Response.write "AddDayStyle(" & rs("month") & "," & rs("day") & "," & rs("year") & ",'" & rs("DepartmentName") & "','background:#" & colorRamp(colorIdx) & "');"
            rs.movenext
        wend

        set rs = nothing

	end function

	sub recordDetailedNote(invoicenumber)
		dim query


		query = "insert into customernote (customersequencenumber, storeguid, source, note)"
		query = query & " select " & Session("customersequencenumber")
		query = query & ", store.guid"
		query = query & ", '" & session("employeename") & "'"

		if addOrEdit = "add" then
			query = query & ", 'Created invoice " & invoicenumber & "'"
		else
			query = query & ", 'Edited invoice " & invoicenumber & "'"
		end if
		query = query & " from store where storeid = " & session("storeid")

		qryexecute query
	end sub

	function getSelectedItemName()
	    if cint(selItemId) <> -1 then
	        dim query, rs
	        query = "select itemName from PriceListItem where priceListItemId = " &  selItemId
            set rs = getdisconnectedrecordset(query)
            getSelectedItemName = replace(rs("itemName"), "'", "&#39;")
	    else
	        getSelectedItemName = ""
	    end if
	end function


%>
<HTML>
<HEAD>
<TITLE>Detailed Invoice</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
	var lastFocusControl;
function txtAmountEntered_onblur() {
	lastFocusControl = event.srcElement;
}

//-->
</SCRIPT>
</HEAD>
<script language="JavaScript" src="../script/validation.js"></script>
<script language="JavaScript" src="../script/date-picker.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" src="../External/jquery-1.6.4.js"></script>
<script language="javascript" type="text/javascript">
	var previousElement=null;
	var alertMessage = null;


	function validateDepartmentMaxPieces() {
		var returnValue;

		returnValue = true;
		$('.departmentMaxPieces').each( function(i) {
			var pieces;
			var maxPieces;

			pieces = parseInt(this.getAttribute('pieces'));
			maxPieces = parseInt(this.getAttribute('maxPieces'));

            if(pieces > maxPieces) {
                cbs_alert('Department \'' + this.getAttribute('deptName') + '\' has more then its maximum ' + maxPieces + ' pieces.  ' +
                                        'Please remove ' + (pieces - maxPieces) + ' pieces from this department before continuing.');
                returnValue = false;
            }
		});
		return returnValue;
	}


	function submitForm() {
		var forceValues;
		var invoiceOnDelivery;
		var minimumPrepayAmount;

		if(!validateDepartmentMaxPieces())
		    return false;


		minimumPrepayAmount = document.detailedInvoice.minimumPrepayAmount.value;
		forceValues = validateForceSubItems();

		if(!forceValues)
			return false;

		if(minimumPrepayAmount > 0) {
			return prePayInvoice();
		}

		<% if isPromptToDeliverEnabled(custSeqNumber) then %>
            cbs_confirm("Would the customer like this invoice delivered?", forceValYes, forceValNo);
        <% else %>
            handleForceValues(0);
		<% end if %>
	}

	function forceValYes() {
        clearConfirmMsg();
        handleForceValues(1);
	}

	function forceValNo() {
        clearConfirmMsg();
        handleForceValues(0);
	}

    var globInvoiceOnDelivery
	function handleForceValues(invoiceOnDelivery) {
		var needHeatSeal = document.detailedInvoice.needHS.value;
		var useHeatSeal = document.detailedInvoice.useHS.value;
		var heatSealCount = document.detailedInvoice.hsCount.value;
		var itemCount = document.detailedInvoice.txtTotal.value;
		var quickItemsCount = document.detailedInvoice.quickItemsCount.value;
		globInvoiceOnDelivery = invoiceOnDelivery;

				if (itemCount > 0) {
					if ("<%=hasHSItems%>" == 1 && (useHeatSeal == "True") && (needHeatSeal == "True")) {
						showHeatSeal();
					}
					else {
	                    <% if ppPopup = "True" and addOrEdit = "add" then %>
					        cbs_confirm("Do you want to prepay this invoice?", doneYes, doneNo);
					    <% else %>
	                        document.detailedInvoice.done.disabled = true;
						    doDone(false);
						<% end if %>
					}
				}
				else {
					cbs_alert("Must have at least a servicable item on the invoice.");
				}
	}

	function doneYes() {
        clearConfirmMsg();
        doDone(true);
	}

	function doneNo() {
        clearConfirmMsg();
        doDone(false);
	}

    function doDone(sendToPrepay) {
	    if (sendToPrepay)
		    document.detailedInvoice.action= "detailedInvoice.asp?userAction=prePay&prepay=1&invoiceOnDelivery=" + globInvoiceOnDelivery;
		else
		    document.detailedInvoice.action= "detailedInvoice.asp?userAction=done&invoiceOnDelivery=" + globInvoiceOnDelivery;
		document.detailedInvoice.submit();
    }

	function redirectFocus() {
        var el = document.getElementById("detailedInvoice");
        var eventName = "keypress";

        if (document.getElementById('descBox').style.display == 'none') {
            <% if defaultTxtInput = 1 then %>
                el = document.getElementById("itemSearch");
            <% else %>
                el = document.getElementById("itemShortcut");
            <% end if %>
            if (el != null) {
                setTimeout(function() { el.focus(); }, 500);
            }
        }
        <% if useOverlay then %>
        if (document.getElementById('descBox').style.display == 'block')
            setInterval(updateOverLay, 100);
        <% end if %>

    }


	function prePayInvoice() {
		var forceValues;
		var invoiceOnDelivery;

		forceValues = validateForceSubItems();
		if (forceValues == true)
		{
			<% if isPromptToDeliverEnabled(custSeqNumber) then %>
                cbs_confirm("Would the customer like this invoice delivered?", finishPrepayYes, finishPrepayNo);
            <% else %>
                finishPrepayInvoice(0);
			<% end if %>
		}
	}

	function finishPrepayYes() {
        clearConfirmMsg();
	    finishPrepayInvoice(1);
	}
	function finishPrepayNo() {
        clearConfirmMsg();
	    finishPrepayInvoice(0);
	}


	function finishPrepayInvoice(invoiceOnDelivery) {
		var itemCount = document.detailedInvoice.txtTotal.value;
		var useHeatSeal = document.detailedInvoice.useHS.value;
		var needHeatSeal = document.detailedInvoice.needHS.value;
			if (itemCount > 0)
			{
				if ((useHeatSeal == "True") && (needHeatSeal == "True")) {
						showHeatSeal();
				}
				else {
                    document.detailedInvoice.action= "detailedInvoice.asp?userAction=prePay&invoiceOnDelivery=" + invoiceOnDelivery;
                    document.detailedInvoice.submit();
				}
			}
			else
			{
				cbs_alert("Must have at least a servicable item on the invoice.")
			}
	}

	function setFocus() {
	    document.getElementById("screenWidth").value = screen.width;
	    document.getElementById("screenHeight").value = screen.height;

		if (document.detailedInvoice.itemHeatSeal)
			document.detailedInvoice.itemHeatSeal.focus()
		<% if useOverlay then %>
            <% if Request.QueryString("doAnotherDesc") = 1 then %>
                    <% if Request.QueryString("useraction") = "addUpcharge" then %>
                        popDesc('UP', true, '<%= getSelectedItemName %>');
                    <% elseif Request.QueryString("useraction") = "addColor" then %>
                        popDesc('CO', true, '<%= getSelectedItemName %>');
                    <% elseif Request.QueryString("useraction") = "addPattern" then %>
                        popDesc('PA', true, '<%= getSelectedItemName %>');
                    <% elseif Request.QueryString("useraction") = "addBrand" then %>
                        popDesc('BR', true, '<%= getSelectedItemName %>');
                    <% end if %>
            <% elseif Request.QueryString("useraction") = "getItemDetails" then %>
                    <% if f_upcharges then %>
                        popDesc('UP', true, '<%= getSelectedItemName %>');
                    <% elseif f_colors then %>
                        popDesc('CO', true, '<%= getSelectedItemName %>');
                    <% elseif f_pattern then %>
                        popDesc('PA', true, '<%= getSelectedItemName %>');
                    <% elseif f_brand then %>
                        popDesc('BR', true, '<%= getSelectedItemName %>');
                    <% else %>
                        closeDesc();
                    <% end if %>
            <% elseif forceNext and (Request.QueryString("useraction") = "addUpcharge" or Request.QueryString("useraction") = "addColor" _
                or Request.QueryString("useraction") = "addPattern" or Request.QueryString("useraction") = "addBrand") then %>
                    <% if Request.QueryString("useraction") = "addUpcharge" then %>
                        goToNextForced("UP");
                    <% elseif Request.QueryString("useraction") = "addColor" then %>
                        goToNextForced("CO");
                    <% elseif Request.QueryString("useraction") = "addPattern" then %>
                        goToNextForced("PA");
                    <% elseif Request.QueryString("useraction") = "addBrand" then %>
                        goToNextForced("BR");
                    <% end if %>
            <% elseif Request.QueryString("useraction") = "filterBrand" or Request.QueryString("useraction") = "createBrand" then
                if f_brand and forceNext then %>
                    popDesc("BR", true, '<%= getSelectedItemName %>')
                <% else %>
                    popDesc("BR", false, '<%= getSelectedItemName %>')
                <% end if %>
                document.getElementById("filterTxt").value = '<%= Request.QueryString("filterValue")%>';
                document.getElementById("filterTxt").focus();
            <% end if %>
        <% end if %>
	}

	function viewImage(imgID){
		window.showModelessDialog('cameraViewer.asp?imgID=' + imgID + '',window,'help:no;status:no;scroll:no;dialogWidth:326px;dialogHeight:320px');
	}

	function showAddCharge() {
		var forceValues;
		var itemCount;
		var currLineNumber;
		var selDeptId;

		currLineNumber = document.detailedInvoice.lineNumber.value;
		itemCount = document.detailedInvoice.txtTotal.value;
		if (currLineNumber == ""){
			forceValues = true;
		}
		else {
			forceValues =validateForceSubItems();
		}
		if (forceValues == true){
			if (itemCount == 0){
				selDeptId = document.detailedInvoice.selectedDept.value;
				if (selDeptId == -1) {
					cbs_alert("Must select a department before adding charge");
					return false;
				}
			}
			document.detailedInvoice.action="addCharge.asp?targetPage=detail";
			document.detailedInvoice.submit();
		}
	}

	function showAllCoupons() {
		var forceValues;
		forceValues = validateForceSubItems();
		if (forceValues == true) {
			document.detailedInvoice.action=document.detailedInvoice.action + "?userAction=getCoupons";
			document.detailedInvoice.submit();
		}
	}

	function showAllLoyalty() {
		var forceValues;
		forceValues = validateForceSubItems();
		if (forceValues == true) {
			document.detailedInvoice.action=document.detailedInvoice.action + "?userAction=getLoyalty";
			document.detailedInvoice.submit();
		}
	}

	function selectRow(element) {
		var childEl;
		var lineNo;
		var currentLineNo;
		var submit;
		if (previousElement == null){
			deselectSelectedRow();
		} else{
			previousElement.style.background="white";
		}
		if (element.getAttribute("name") == "main"){
			childEl = element.children[0];
		}
		else {
			childEl = element.children[1];
		}
		var rowChildNodes = childEl.children
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if(childEl.tagName == "INPUT") {
				childEl.checked=true;
				break;
			}
		}
		previousElement =element;
		//element.style.background="#DBF2F4";
		element.style.background="#C2DACD";

		lineNo = 1;


		if (element.title == "IT" || element.title == "DE" || element.title == "SI") {
			document.detailedInvoice.upChargePageCount.value = eval(0);
			document.detailedInvoice.colorsPageCount.value = eval(0);
			document.detailedInvoice.PatternPageCount.value = eval(0);

			if(childEl.tagName == "INPUT"){
				if (invoiceTable.rows.length > 0) {
					for (var i = 0; i < document.detailedInvoice.select.length; i++) {
						if(document.detailedInvoice.select[i].checked){
							lineNo = document.detailedInvoice.select[i].value;
							break;
						}
					}
				}
				currentLineNo = document.detailedInvoice.lineNumber.value;
				if (currentLineNo == ""){
					submit = true;
				}
				else {
						submit =validateForceSubItems();
				}
				document.detailedInvoice.action ="?userAction=getSubItems&lineNo=" + lineNo;
				document.detailedInvoice.submit();
			}
		}
	}

	function deselectSelectedRow() {
		var currLineNo;
		var i
		currLineNo = document.detailedInvoice.lineNumber.value;
		if (currLineNo.length > 0) {
			for(var i=0; i<invoiceTable.rows.length; i++){
				invoiceTable.rows[i].style.background =	"white";
			}
		}
	}

    var itemDetailsEl;
    var savedElements;
    var savedElement;
	function getItemDetails(element) {
		var itemId
		var currentLineNo
		var itemName
		var price
		var quantity = document.detailedInvoice.txtAmountEntered.value;
		var deptId
		var pkgQty
        var itemNote;

		if (!checkInt(quantity)) {
			show_focus("Must enter all numbers.");
			return false;
		}

        <% if f_heatseal and deptNeedHS and forceHSBeforeDetail and currHS = "" then %>
            if (document.detailedInvoice.itemHeatSeal.value == "") {
                cbs_alert("Need to enter a heat seal before detailing the item");
                return false;
            }

            if ("<%=usedHSList%>".indexOf("|" + document.detailedInvoice.itemHeatSeal.value) !== -1) {
                cbs_alert("Heat Seal " + document.detailedInvoice.itemHeatSeal.value + " already used on this invoice");
                return false;
            }
        <% end if %>

        savedElement = element;
		itemDetailsEl = element
		currentLineNo = document.detailedInvoice.lineNumber.value;
		document.detailedInvoice.upChargePageCount.value = eval(0);
		document.detailedInvoice.colorsPageCount.value = eval(0);
		document.detailedInvoice.PatternPageCount.value = eval(0);
		itemId = element.id;
		itemName = element.name;
		price = element.title;
		deptId = element.getAttribute('deptId');
		pkgQty = element.getAttribute('pkgQty');

		if (currentLineNo != "") {
		    if (!validateForceSubItems())
		        return false;
		}

		<% if enableRedoMode then %>
             if(element.getAttribute('clickPrompt') != "") {
                savedElements = quantity + "|" +itemName + "|" +price + "|" +itemId + "|" +deptId + "|" +pkgQty;
                 cbs_promptWSelect(element.getAttribute('clickPrompt'), element.getAttribute('clickOptions'), "", true, handleOptionsReturn);
                 return false;
             }
		<% end if %>
        document.getElementById('inputTxtLine').value = '';
        finishGetItemDetails();
	}

	function finishGetItemDetails(itemNote) {
	    var itemNote = document.getElementById('inputTxtLine').value
		var quantity = document.detailedInvoice.txtAmountEntered.value;
		var	itemId = itemDetailsEl.id;
    	var	itemName = itemDetailsEl.name;
    	var	price = itemDetailsEl.title;
    	var	deptId = itemDetailsEl.getAttribute('deptId');
    	var	pkgQty = itemDetailsEl.getAttribute('pkgQty');
		document.detailedInvoice.action = "?userAction=getItemDetails&itemId=" + itemId + "&quantity=" + quantity + "&itemDeptId=" + deptId + "&pkgQty=" + pkgQty + "&promptResponse=" + encodeURIComponent(itemNote ? itemNote : "");
		document.detailedInvoice.submit();
	}


	function handleOptionsReturn(returnVal) {
        clearPromptWSelMsg();
        var variables = savedElements.split("|")
	    var note = document.getElementById('inputTxtArea2').value + "|" + (promptWSelChoice ? promptWSelChoice.value : "");
        handleItemPrompt(variables[0], variables[1], variables[2], variables[3], variables[4], variables[5], note);
	}

	function handleItemPrompt(quantity, itemName, price, itemId, deptId, pkgQty, itemNote) {
		document.detailedInvoice.action ="?userAction=getItemDetails&itemId=" + itemId + "&quantity=" + quantity + "&itemDeptId=" + deptId + "&pkgQty=" + pkgQty + "&promptResponse=" + encodeURIComponent(itemNote ? itemNote : "");
		document.detailedInvoice.submit();
	}


	function validateForceSubItems(){
		var retVal;
		var tempVal;
		var selItemId
		selItemId = eval(document.detailedInvoice.selItemId.value)

		retVal = true;
		if (selItemId == -1){
			return retVal;
		}

		if(document.detailedInvoice.forceUpcharges.value == "True" && document.detailedInvoice.upchargeSet.value == "False" && document.detailedInvoice.totalUpchargescount.value  != "0") {
			cbs_alert("Upcharge not selected.");
			retVal = false;
		}
		if (retVal) {
			if(document.detailedInvoice.forceColors.value == "True" && document.detailedInvoice.colorSet.value == "False" && document.detailedInvoice.totalColorscount.value  != "0" ) {
				cbs_alert("Color not selected.");
				retVal = false;
			}

		}
		if (retVal) {
			if(document.detailedInvoice.forcePatterns.value == "True" && document.detailedInvoice.patternSet.value == "False" && document.detailedInvoice.totalPatternscount.value  != "0") {
				cbs_alert("Pattern not selected.");
				retVal = false;
			}
		}
		if (retVal) {
			if(document.detailedInvoice.forceBrands.value == "True" && document.detailedInvoice.brandSet.value == "False" && document.detailedInvoice.totalBrandscount.value  != "0") {
				cbs_alert("Brand not selected.");
				retVal = false;
			}
		}
		return retVal;
	}

	function nextUpChargePage() {
		document.detailedInvoice.upChargePageCount.value = eval(eval(document.detailedInvoice.upChargePageCount.value) + eval(1));
		document.detailedInvoice.action ="?userAction=nextPage";
		document.detailedInvoice.submit();
	}

	function nextColorPage() {
		document.detailedInvoice.colorsPageCount.value = eval(eval(document.detailedInvoice.colorsPageCount.value) + eval(1));
		document.detailedInvoice.action ="?userAction=nextPage";
		document.detailedInvoice.submit();
	}

	function nextPatternsPage() {
		document.detailedInvoice.PatternPageCount.value = eval(eval(document.detailedInvoice.PatternPageCount.value) + eval(1));
		document.detailedInvoice.action ="?userAction=nextPage";
		document.detailedInvoice.submit();
	}

	function nextItemsPage() {
		document.detailedInvoice.ItemPageCount.value = eval(eval(document.detailedInvoice.ItemPageCount.value) + eval(1));
		<% if ObjMiscSetUp.Item("useHeatSeal") then %>
		document.detailedInvoice.action ="?userAction=nextPage";
		<% else %>
		document.detailedInvoice.action ="?userAction=nextPage&itemFilter=" + document.getElementById("itemSearch").value;
		<% end if %>
		document.detailedInvoice.submit();
	}

	function nextDeptPage() {
		document.detailedInvoice.DeptPageCount.value = eval(eval(document.detailedInvoice.DeptPageCount.value) + eval(1));
		document.detailedInvoice.action ="?userAction=nextPage";
		document.detailedInvoice.submit();
	}

	function setSelectedUpCharge(element) {
		var selectedUpCharge = element.name;
		var price = element.title;
		var quantity = document.detailedInvoice.txtAmountEntered.value;
		var doAnother = document.getElementById('doAnotherDesc').checked;

		document.detailedInvoice.action ="?userAction=addUpcharge&upchargeid=" + escape(selectedUpCharge) + "&quantity=" +
		    quantity + "&forceNext=" + (isForced ? "1" : "0") + "&doAnotherDesc=" + (doAnother ? "1" : "0");
		document.detailedInvoice.submit();
	}

	function setSelectedColor(element) {
		var selectedColor = element.name;
		var quantity = document.detailedInvoice.txtAmountEntered.value;
		var doAnother = document.getElementById('doAnotherDesc').checked;
		document.detailedInvoice.action ="?userAction=addColor&colorid=" + escape(selectedColor) + "&quantity=" +
            quantity + "&forceNext=" + (isForced ? "1" : "0") + "&doAnotherDesc=" + (doAnother ? "1" : "0");
		document.detailedInvoice.submit();

	}

	function setSelectedPattern(element) {
		var selectedPattern = element.name;
		var quantity = document.detailedInvoice.txtAmountEntered.value;
		var doAnother = document.getElementById('doAnotherDesc').checked;
		document.detailedInvoice.action ="?userAction=addPattern&patternid=" + escape(selectedPattern) + "&quantity=" +
            quantity + "&forceNext=" + (isForced ? "1" : "0") + "&doAnotherDesc=" + (doAnother ? "1" : "0");
		document.detailedInvoice.submit();

	}

	function setSelectedBrand(element) {
		var selectedPattern = element.name;
		var quantity = document.detailedInvoice.txtAmountEntered.value;
		var doAnother = document.getElementById('doAnotherDesc').checked;
		document.detailedInvoice.action ="?userAction=addBrand&brandid=" + escape(selectedPattern) + "&quantity=" +
            quantity + "&forceNext=" + (isForced ? "1" : "0") + "&doAnotherDesc=" + (doAnother ? "1" : "0");
		document.detailedInvoice.submit();
	}

	function updateOverLay() {
        if (document.getElementById('descBox').style.display == 'block' && document.activeElement.id != "qtnTxt")
            document.getElementById('qtnTxt').value = document.detailedInvoice.txtAmountEntered.value;
	}

	function changeQuantity(){
		var quantity = document.detailedInvoice.txtAmountEntered.value;
		var selItemID = null;

		if(quantity == "")
			return false;
		else if(quantity < 0)
		{
			cbs_alert("Quantity must be greater then zero.");
			return false;
		}


		if (invoiceTable.rows.length > 0) {
			for (var i = 0; i < document.detailedInvoice.select.length; i++) {
				if(document.detailedInvoice.select[i].checked){
					selItemID = document.detailedInvoice.select[i].value;
					break;
				}
			}
			if(selItemID != null) {
				if (!checkInt(quantity)) {
					show_focus("Must enter all numbers.");
					return false;
				}else{
					document.detailedInvoice.action ="?userAction=changeQuantity&itemId=" + selItemID + "&quantity=" + quantity;
					document.detailedInvoice.submit();
				}
			}
		}
	}

	function getSelectedItemID(selItemId){
		var str1
		var s_index
		s_index = selItemId.indexOf("#");
		if(s_index ==-1) {
			str1=selItemId;
		}else{
			str1 = selItemId.substring(s_index+1, selItemId.length);
		}
		return (str1);
	}

	function deleteItems() {
		var selItemID = null;

		if (invoiceTable.rows.length > 0) {
			for (var i = 0; i < document.detailedInvoice.select.length; i++) {
				if(document.detailedInvoice.select[i].checked){
					selItemID = document.detailedInvoice.select[i].value;
					break;
				}
			}
			if(selItemID != null) {
				document.detailedInvoice.action ="?userAction=deleteItem&itemId=" + selItemID;
				document.detailedInvoice.submit();
			}
		}
	}

	function clearInvoice()	{
		var itemCount;
		itemCount = document.detailedInvoice.txtTotal.value;
		if (itemCount > 0) {
			document.detailedInvoice.action ="?userAction=clearInvoice";
			document.detailedInvoice.submit();
		}
	}

	function populateCommonItems(){
		var submit;
		var currentLineNo;
		currentLineNo = document.detailedInvoice.lineNumber.value;
		if (currentLineNo == ""){
			submit = true;
		}
		else {
			submit =validateForceSubItems();
		}
		if (submit == true) {
			document.detailedInvoice.ItemPageCount.value = eval(0);
			document.detailedInvoice.selectedDept.value =-1;
			document.detailedInvoice.lineNumber.value ="";
			document.detailedInvoice.action ="?userAction=getCommonItems";
			document.detailedInvoice.submit();

		}

	}

	function adjustPrice(selItemID) {
		document.detailedInvoice.action = "overRidePrice.asp?targetPage=detail&selectedItemId=" + selItemID;
		document.detailedInvoice.submit();
	}

	function showOverRidePrice() {
		var selItemID = null;


		if (invoiceTable.rows.length > 0) {
			for (var i = 0; i < document.detailedInvoice.select.length; i++) {
				if(document.detailedInvoice.select[i].checked){
					selItemID = document.detailedInvoice.select[i].value;
					break;
				}
			}
			if(selItemID != null) {
				document.detailedInvoice.action = "overRidePrice.asp?targetPage=detail&selectedItemId=" + selItemID;
				document.detailedInvoice.submit();
			}
		}
	}

	function setSelectedDept(d_element) {
		var submit;
		var currentLineNo;
		currentLineNo = document.detailedInvoice.lineNumber.value;
		if (currentLineNo == ""){
			submit = true;
		}
		else {
			submit =validateForceSubItems();
		}
		if (submit == true) {
			document.detailedInvoice.ItemPageCount.value = eval(0);
			document.detailedInvoice.lineNumber.value =""
			document.detailedInvoice.selectedDept.value = d_element.id;
			document.detailedInvoice.action ="?userAction=changeDept";
			document.detailedInvoice.submit();
		}
	}

	function setDueDate() {
		var dueDateSet;

		document.detailedInvoice.isDueDateSet.value ="1";
		show_calendar("detailedInvoice.txtDueDate");
	}

	function changeStarchPref() {
		document.detailedInvoice.action = "starchPreferences.asp?targetPage=detail";
		document.detailedInvoice.submit();
	}

	function changeFinishPref() {
		document.detailedInvoice.action = "finishPreferences.asp?targetPage=detail";
		document.detailedInvoice.submit();
	}

	function hideScrollBars(){
		document.body.style.overflow='hidden';
	}

	function checkForAlertMessages() {
		hideScrollBars();
		<%
			if Len(alertMessage) > 0 then
			Response.Write "alertMessage='"
			Response.Write alertMessage
			Response.Write "'"
			end if
		%>
		if (alertMessage != null){
			cbs_alert (alertMessage);
		}
		lastFocusControl = eval(document.detailedInvoice.txtAmountEntered);
	}

	function showItemNotes() {
		var lineNumber;
		lineNumber = 1;
		if (invoiceTable.rows.length > 0) {
			if(invoiceTable.rows.length ==2)
			{
				if(document.detailedInvoice.select.checked) {
					lineNumber = document.detailedInvoice.select.value;
				}
			}
			else{
				for (var i = 0; i < document.detailedInvoice.select.length; i++) {
					if(document.detailedInvoice.select[i].checked){
						lineNumber = document.detailedInvoice.select[i].value;
						break;
					}
				}
			}
			if(lineNumber!= null){
				document.detailedInvoice.action = "ItemNotes.asp?lineNumber=" + lineNumber + "&targetPage=detail";
				document.detailedInvoice.submit();
			}

		}
	}

	function holdTicket() {
		var itemCount;
		itemCount = document.detailedInvoice.txtTotal.value;
		if (itemCount > 0) {
			document.detailedInvoice.action ="?userAction=hold";
			document.detailedInvoice.submit();
		}else{
			cbs_alert("Must have at least a servicable item on the invoice.")
		}
	}

	function cancelForm() {
		document.detailedInvoice.action =document.detailedInvoice.action + "?userAction=cancel";
		document.detailedInvoice.submit();
	}

	function previousDeptPage() {
		document.detailedInvoice.DeptPageCount.value = eval(1);
		document.detailedInvoice.action ="?userAction=nextPage";
		document.detailedInvoice.submit();
	}

	function prevPatternsPage() {
		document.detailedInvoice.PatternPageCount.value = eval(1);
		document.detailedInvoice.action ="?userAction=nextPage";
		document.detailedInvoice.submit();
	}

	function prevUpChargePage() {
		document.detailedInvoice.upChargePageCount.value = eval(1);
		document.detailedInvoice.action ="?userAction=nextPage";
		document.detailedInvoice.submit();
	}

	function prevColorPage() {
		document.detailedInvoice.colorsPageCount.value = eval(1);
		document.detailedInvoice.action ="?userAction=nextPage";
		document.detailedInvoice.submit();
	}

	function prevItemsPage() {
		document.detailedInvoice.ItemPageCount.value = eval(1);
// Uncomment the following line and comment previous line if 'Previous' button should take to Previous page
		//document.detailedInvoice.ItemPageCount.value = eval(document.detailedInvoice.ItemPageCount.value) - 1;
		<% if ObjMiscSetUp.Item("useHeatSeal") then %>
		document.detailedInvoice.action ="?userAction=nextPage";
		<% else %>
		document.detailedInvoice.action ="?userAction=nextPage&itemFilter=" + document.getElementById("itemSearch").value;
		<% end if %>
		document.detailedInvoice.submit();
	}

	function showCustomerNotes() {
		document.detailedInvoice.action = "customerNotes.asp?targetPage=detail";
		document.detailedInvoice.submit();
	}
	function captureImage(){

		var lineNumber;
		lineNumber = 1;
		if (invoiceTable.rows.length > 0) {
			if(invoiceTable.rows.length ==2)
			{
				if(document.detailedInvoice.select.checked) {
					lineNumber = document.detailedInvoice.select.value;
				}
			}
			else{
				for (var i = 0; i < document.detailedInvoice.select.length; i++) {
					if(document.detailedInvoice.select[i].checked){
						lineNumber = document.detailedInvoice.select[i].value;
						break;
					}
				}
			}
			if(lineNumber!= null){
				document.detailedInvoice.action = "cameraCapture.asp?lineNumber=" + lineNumber + "&action=capture&targetPage=detail"
				document.detailedInvoice.submit();

			}
		}
	}

	function showHeatSeal() {
		var submit;
		var currentLineNo;
		var itemCount;
		itemCount = document.detailedInvoice.txtTotal.value;
		if (itemCount > 0) {
			currentLineNo = document.detailedInvoice.lineNumber.value;
			if (currentLineNo == ""){
				submit = true;
			}
			else {
				submit =validateForceSubItems();
			}
			if (submit == true) {
				document.detailedInvoice.action = "heatSeal.asp"
				document.detailedInvoice.submit();
			}
		}
	}

	function promptForLoyalty() {
		var offers
		var purchase
		var visits
		var numOffers
		var invoice
		var loyEnabled
		var cVisits
		var retValue

		purchase = document.detailedInvoice.promptPurchase.value;
		visits = document.detailedInvoice.visits.value;
		invoice = document.detailedInvoice.promptInvoice.value;
		cVisits = document.detailedInvoice.custVisits.value;

		if (loyEnabled == null) {
			if (purchase == 1) {
				if (invoice == 1) {
					if (visits == cVisits) {
                        cbs_confirm("Would you like to purchase the loyalty program?", gotoPurcLoy, finishLoyaltyHandling);
                        return;
					}
				}
			}
		}
		finishLoyaltyHandling();
	}

	function gotoPurcLoy() {
        clearConfirmMsg();
		document.detailedInvoice.action = "/purchaseLoyalty.asp";
        document.detailedInvoice.submit();
	}

	function finishLoyaltyHandling() {
        clearConfirmMsg();
	    var offers = document.detailedInvoice.promptLoyOffers.value;
		var numOffers = document.detailedInvoice.numLoyOffers.value;
		var loyEnabled = document.detailedInvoice.loyaltyEnabled.value;
		if (loyEnabled) {
			if (offers == 1) {
				if (numOffers > 0) {
					cbs_alert("You have loyalty offers that can be used");
				}
			}
		}
	}

	function selectDeptDueDate(element, deptName) {
	    SetCurrentGroup(deptName);
		show_calendar("detailedInvoice." + element.name);
	}

	function changeAllDeptDueDates() {
		if(document.detailedInvoice.invoiceDueDate.value != "" )
		{
			document.detailedInvoice.action = "?userAction=setAllDeptDueDate" +
			    "&date=" + document.detailedInvoice.invoiceDueDate.value;
			document.detailedInvoice.submit();
		}
	}

	function changeDeptDueDate(dept, date) {
		document.detailedInvoice.action = "?userAction=setDeptDueDate" +
										"&department=" + dept +
										"&date=" + date.value;
		document.detailedInvoice.submit();
	}

	function fillCalenderNotes() {
    <% GenerateDayNotes() %>
	}

	function addShortcutItem(shortcut) {
		document.detailedInvoice.action = "?userAction=addshortcutitem&shortcut=" + shortcut;
		document.detailedInvoice.submit();
	}

	function addHeatSealItem(heatseal) {
		document.detailedInvoice.action = "?userAction=addHeatSealItem&heatseal=" + heatseal;
		document.detailedInvoice.submit();
	}

	function captureKeyup(element){
		var useHS = document.detailedInvoice.useHS.value;

		if (event.keyCode == 13){
			if (useHS == "True") {
				addHeatSealItem(element.value);
			}
			else {
				addShortcutItem(element.value);
			}
		}
	}

	var savPrefTypeId
	var savOptionSelected
	var savOptions;
	function changePreference(preferenceTypeID, preferenceName, options, defaultOption) {
	    savPrefTypeId = preferenceTypeID;
	    savOptions = options;
		cbs_select('Select ' + preferenceName + ' Preference', 1, options, "handlePrefReturn");
	}

    function handlePrefReturn(returnVal) {
        clearOptionMsg();
        savOptionSelected = savOptions.split("|")[returnVal]
        cbs_confirm("Save customer preference?", savePrefTrue, savePrefFalse);
   }

	function savePrefTrue() {
	    doSavePref(true);
	}
	function savePrefFalse() {
	    doSavePref(false);
	}

	function doSavePref(savePreference) {
        clearConfirmMsg();
        document.detailedInvoice.action = "?userAction=changePreference" +
            "&preferenceTypeID=" + savPrefTypeId +
            "&value=" + savOptionSelected +
            "&save=" + savePreference;
        document.detailedInvoice.submit();
	}

	function toggleRedoMode() {
		document.detailedInvoice.action = "?userAction=toggleRedoMode";
		document.detailedInvoice.submit();
	}

	function showDesc(descType) {
	    <% if selItemId <> "-1" then %>
	    popDesc(descType, false, '<%= getSelectedItemName %>');
	    <% else %>
	    cbs_alert("An item must be selected to add a descriptor");
	    <% end if %>
	}



	function goToNextForced(lastDesc) {
    	if (lastDesc == "UP") {
    	    <% if f_colors then %>
                popDesc('CO', true, '<%= getSelectedItemName %>');
            <% elseif f_pattern then %>
                popDesc('PA', true, '<%= getSelectedItemName %>');
            <% elseif f_brand then %>
                popDesc('BR', true, '<%= getSelectedItemName %>');
            <% else %>
                closeDesc();
            <% end if %>
        }
    	else if (lastDesc == "CO") {
            <% if f_pattern then %>
                popDesc('PA', true, '<%= getSelectedItemName %>');
            <% elseif f_brand then %>
                popDesc('BR', true, '<%= getSelectedItemName %>');
            <% else %>
                closeDesc();
            <% end if %>
        }
    	else if (lastDesc == "PA") {
            <% if f_brand then %>
                popDesc('BR', true, '<%= getSelectedItemName %>');
            <% else %>
                closeDesc();
            <% end if %>
        }
    	else if (lastDesc == "BR")
            closeDesc();
	}

	function createDescBtn(type, descName, price, isSel, imageFileName, trimName) {
        var newBtn = "<BUTTON type=\"button\" class=\"small\" id=\"" + descName + "\" name=\"" + descName + "\" title=\"" +
            price + "\" style=\"overflow: hidden; width:110px;height:70px;"
        if (isSel)
            newBtn += "border:2px inset #CCCCCC;"

        if (type === "UP") {
            newBtn += "background: #FFFFFF ";
            if (imageFileName)
                newBtn += "url(../uploadedImages/" + imageFileName + ") ";
            newBtn += "no-repeat top;\" onClick=\"setSelectedUpCharge(this);\">";
        }
        else if (type === "CO")
            newBtn += "background:" + descName + ";\" onClick=\"setSelectedColor(this)\">";
        else if (type === "PA") {
            newBtn += "background: #FFFFFF ";
            if (imageFileName)
                newBtn += "url(../uploadedImages/" + imageFileName + ") ";
            newBtn += " no-repeat top;\" onClick=\"setSelectedPattern(this);\">";
        }
        else if (type === "BR")
            newBtn += "background:" + descName + ";\" onClick=\"setSelectedBrand(this)\">";
        newBtn += "<span class=\"detBtnTxt\" style=\"font-size: 13px; font-weight:bold\">" + trimName + "</span></button>"
	    return newBtn;
	}

    function displayUpcharge(filterValue) {
    	var table = document.getElementById("descTable");
        var rowCnt = 0;
        var cellCnt = 0;
        var btnPerRow = 6;
        if (screen.width <= 1100)
            btnPerRow = 5;

        var row;
        var i = 0;
        var cnt = 0;
 	    <%  if selItemId <> "-1" then
 			Set distinctUpcharges = getDistinctUpcharges(selItemId)
 			if distinctUpcharges.Recordcount > 0 then
                while Not (distinctUpcharges.Eof)
                    upChargeValue = distinctUpcharges.Fields("descriptorName")
                %>
                    if (cnt < btnPerRow * 6) {
                        if (filterValue == null || filterValue == "" || '<%= replace(upChargeValue, "'", "")%>'.toLowerCase().includes(filterValue.toLowerCase())) {
                            if (i % btnPerRow === 0) {
                                    row = table.insertRow(rowCnt);
                                    rowCnt++;
                                    cellCnt = 0;
                            }
                            var cell = row.insertCell(cellCnt++);
                            var isSel = false;
                            <% if selupChargeValue = upChargeValue then %>
                                isSel = true;
                            <% end if %>
                            cell.innerHTML = createDescBtn('UP', '<%= replace(upChargeValue, "'", "")%>', '<%= distinctUpcharges.Fields("price")%>',
                                isSel, '<%= distinctUpcharges.Fields("imageFileName")%>', '<%= WordTrim(replace(upChargeValue, "'", ""), 15)%>');
                            i++;
                            cnt++
                        }
                    }
                <%
                 distinctUpcharges.MoveNext
                 wend
            end if
            end if
           %>
    }

    function displayColors(filterValue) {
    	var table = document.getElementById("descTable");
        var rowCnt = 0;
        var cellCnt = 0;
        var btnPerRow = 6;
        if (screen.width <= 1100)
            btnPerRow = 5;
        var row;
        var i = 0;
        var cnt = 0;
 	    <%  if selItemId <> "-1" then
 			Set distinctUpcharges = getDistinctColors(selItemId)
 			if distinctUpcharges.Recordcount > 0 then
                while Not (distinctUpcharges.Eof)
                    upChargeValue = distinctUpcharges.Fields("descriptorName")
                %>
                    if (cnt < btnPerRow * 6) {
                        if (filterValue == null || filterValue == "" || '<%= replace(upChargeValue, "'", "") %>'.toLowerCase().includes(filterValue.toLowerCase())) {
                            if (i % btnPerRow === 0) {
                                    row = table.insertRow(rowCnt);
                                    rowCnt++;
                                    cellCnt = 0;
                            }
                            var cell = row.insertCell(cellCnt++);
                            var isSel = false;
                            <% if selColorValue = upChargeValue then %>
                                isSel = true;
                            <% end if %>
                            cell.innerHTML = createDescBtn('CO', '<%= replace(upChargeValue, "'", "")%>', '',
                                isSel, '<%= replace(upChargeValue, "'", "")%>', '<%= WordTrim(replace(upChargeValue, "'", ""), 15)%>');
                            i++;
                            cnt++;
                        }
                    }
                <%
                 distinctUpcharges.MoveNext
                 wend
            end if
            end if
           %>
    }

    function displayPatterns(filterValue) {
    	var table = document.getElementById("descTable");
        var rowCnt = 0;
        var cellCnt = 0;
        var btnPerRow = 6;
        if (screen.width <= 1100)
            btnPerRow = 5;
        var row;
        var i = 0;
        var cnt = 0;
 	    <%  if selItemId <> "-1" then
 			Set distinctUpcharges = getDistinctPatterns(selItemId)
 			if distinctUpcharges.Recordcount > 0 then
                while Not (distinctUpcharges.Eof)
                    upChargeValue = distinctUpcharges.Fields("descriptorName")
                %>
                    if (cnt < btnPerRow * 6) {
                        if (filterValue == null || filterValue == "" || '<%= replace(upChargeValue, "'", "") %>'.toLowerCase().includes(filterValue.toLowerCase())) {
                            if (i % btnPerRow === 0) {
                                    row = table.insertRow(rowCnt);
                                    rowCnt++;
                                    cellCnt = 0;
                            }
                            var cell = row.insertCell(cellCnt++);
                            var isSel = false;
                            <% if selColorValue = upChargeValue then %>
                                isSel = true;
                            <% end if %>
                            cell.innerHTML = createDescBtn('PA', '<%= replace(upChargeValue, "'", "")%>', '',
                                isSel, '<%= replace(upChargeValue, "'", "")%>', '<%= WordTrim(replace(upChargeValue, "'", ""), 15)%>');
                            i++;
                            cnt++;
                        }
                    }
                <%
                 distinctUpcharges.MoveNext
                 wend
            end if
        end if
        %>
    }



    function displayItems(filterValue) {
    	var table = document.getElementById("itemsTable");
    	table.removeChild(table.getElementsByTagName("tbody")[0]);
        var rowCnt = 0;
        var cellCnt = 0;
        var row;
        var cell;
        row = table.insertRow(rowCnt);
        rowCnt++;
		<%
            dim commonItemsCount, iStartIndex
            dim colsCounter
            dim commItems
            Set commItems = Session("ItemsToBeShown")
            if commItems.RecordCount > 0 then
                iStartIndex = itemsStartIndex
                commonItemsCount = commItems.PageCount
                commItems.AbsolutePage = iStartIndex
                while Not (commItems.Eof )
                if commItems.Fields("itemName") <> "Tip" then
	    %>
	        if (rowCnt < <%=rowCount%> || (rowCnt == <%=rowCount%> && cellCnt + 1 < <%=colCount%> )) {
                if (cellCnt >= <%=colCount%> ) {
                    row = table.insertRow(rowCnt);
                    rowCnt++;
                    cellCnt = 0;
                }
                if (filterValue == null || filterValue == "" || "<%= replace(commItems.Fields("itemName"), """", "")%>".toLowerCase().includes(filterValue.toLowerCase())) {
                    cell = row.insertCell(cellCnt++);
                    cell.innerHTML = "<BUTTON type=\"button\" class=\"<% if useOverlay then %>diItemBig<% else %>diItemSmall<%end if%>\" id=\"<%= commItems.Fields("priceListItemId")%>\"" +
                            "name=\"<%= replace(commItems.Fields("itemName"), """", "&quot;")%>\" title=\"<%= commItems.Fields("price")%>\"" +
                            "deptId=\"<%= commItems.Fields("departmentID")%>\" pkgQty=\"<%= commItems.Fields("qtyInInventory")%>\"" +
                            "style=\"max-width: 200px; " +
                        <% if trim(selItemId) = trim(commItems.Fields("priceListItemId").Value)  then %>
                            "border:2px inset #CCCCCC; " +
                        <% end if %>
                        "background: #FFFFFF " +
                        <%if commItems.Fields("imageFileName") <> "" then%>
                            "url(../uploadedImages/<%=commItems.Fields("imageFileName")%>) " +
                        <% end if %>
                        "no-repeat top; " +
                        <% if useOverlay then %>
                            "background-size: 50px; " +
                        <% else %>
                            "background-size: contain; " +
                        <% end if %>
                        "clickPrompt=\"<%=commItems.Fields("prompt")%>\" clickOptions=\"<%=commItems.Fields("options")%>\" onClick=\"getItemDetails(this)\">" +
                        "<span class=\"detBtnTxt\" style=\"margin-top: 43px; overflow:hidden\"><%= WordTrim(replace(commItems.Fields("itemName"), """", "&quot;"), 14)%></span></button>"
                }
            }
        <%    end if
		 commItems.MoveNext
		wend %>
		<% if iStartIndex < commonItemsCount then %>
            if (rowCnt == <%=rowCount%> && cellCnt + 1 == <%=colCount%>) {
            cell = row.insertCell(cellCnt++);
            cell.innerHTML = "<BUTTON type=\"button\" class=small id=moreItems name=moreItems style=" +
            <% if useOverlay then %>
                "width:80px;height:65px; background:#dcdcdc; margin-top:7px" +
            <% else %>
                "width:65px;height:50px" +
            <% end if %>
            "\" onClick=\"nextItemsPage();\" ><img src=\"/static/icons/24x24/next.png\"><br>More</button>"
            }
		<%
			else
				if iStartIndex > 1 And iStartIndex >= commonItemsCount then %>
                    if (cellCnt >= <%=colCount%> ) {
                        row = table.insertRow(rowCnt);
                        rowCnt++;
                        cellCnt = 0;
                    }
                    cell = row.insertCell(cellCnt++);
                    cell.innerHTML = "<BUTTON type=\"button\" class=small id=prevItems name=prevItems style=" +
                    <% if useOverlay then %>
                        "width:80px;height:65px; background:#dcdcdc; margin-top:7px" +
                    <% else %>
                        "width:65px;height:50px" +
                   <% end if %>
                    "\" onClick=\"prevItemsPage();\" ><img src=\"/static/icons/24x24/previous.png\"><br>Previous</Button>"
		        <% end if %>
			<% end if %>
       <% end if %>
    }

    function createBrand() {
        var brandName = document.getElementById("filterTxt").value;
        if (brandName != "") {
            document.detailedInvoice.action = "?userAction=createBrand&selItem=<%=selItemId%>&filterValue=" +
                encodeURIComponent(brandName) + "&forceNext=" + (isForced ? "1" : "0");
        	document.detailedInvoice.submit();
        }
    }

    function init() {
        checkForAlertMessages();
        fillCalenderNotes();
        setFocus();
        if ("<%=Request.QueryString("itemFilter")%>" != "") {
            document.getElementById("itemSearch").value = "<%=Request.QueryString("itemFilter")%>";
        }

        displayItems('<%=Request.QueryString("itemFilter")%>')
        if (isIpadOS()) {   //iPads can't go full screen, so we shrink the size of the items list so the btn on bottom show up
            var divElm = document.getElementById("invList");
            var origHeight = divElm.style.height;
            var origHeight = origHeight.replace("px", "");
            var subFulHeight = origHeight * .72;
            divElm.style.height = subFulHeight.toString() + "px";
        }
        redirectFocus();
    }

    function isIpadOS() {
      return navigator.maxTouchPoints &&
        navigator.maxTouchPoints > 2 &&
        /MacIntel/.test(navigator.platform);
    }


    async function  confirmDateChange() {
    <%if not invoice.isInvoiceEmpty() then %>
        var oldDate = document.getElementById("invoiceDueDate").value;
        show_calendar('detailedInvoice.invoiceDueDate');

        var newDate = document.getElementById("invoiceDueDate").value;
        var pickerDiv = document.getElementById(datePickerDivID);
        while (newDate == oldDate) {
            await wait();
            newDate = document.getElementById("invoiceDueDate").value;
        }
        changeAllDeptDueDates();
        <% end if %>
    }


    const wait = () =>
       new Promise(resolve =>
          setTimeout(() => resolve(true), 300)
       );



    function displayBrands(filterValue, reload) {
        if (filterValue && reload) {
            document.detailedInvoice.action = "?userAction=filterBrand&selItem=<%=selItemId%>&filterValue=" +
                encodeURIComponent(filterValue) + "&forceNext=" + (isForced ? "1" : "0");
        	document.detailedInvoice.submit();
        	return;
        }

    	var table = document.getElementById("descTable");
        var rowCnt = 0;
        var cellCnt = 0;
        var btnPerRow = 6;
        if (screen.width <= 1100)
            btnPerRow = 5;
        var row;
        var i = 0;
 	    <%  if selItemId <> "-1" and useAdv then
 	        dim cnt
 	        cnt = 0
 	        getDistinctBrands selItemId, Request.QueryString("filterValue")
 			if brandRsp.Recordcount > 0 then
                while Not (brandRsp.Eof or cnt >= 36)
                    upChargeValue = brandRsp.Fields("descriptorName")
                %>
                    if (<%=cnt%> < btnPerRow * 6) {
                            if (i % btnPerRow === 0) {
                                    row = table.insertRow(rowCnt);
                                    rowCnt++;
                                    cellCnt = 0;
                            }
                            var cell = row.insertCell(cellCnt++);
                            var isSel = false;
                            <% if selColorValue = upChargeValue then %>
                                isSel = true;
                            <% end if %>
                            cell.innerHTML = createDescBtn('BR', '<%= replace(upChargeValue, "'", "")%>', '',
                                isSel,  '<%= replace(upChargeValue, "'", "")%>', '<%= replace(WordTrim(upChargeValue, 15), "'", "")%>');
                            i++;
                        }
                <%
                 cnt = cnt + 1
                 brandRsp.MoveNext
                 wend
            end if
        end if
        %>
    }



</SCRIPT>


<BODY topmargin=0 leftmargin=0 onLoad="init()" >

<!-- #include file="../include/banner.inc" -->
<FORM id="detailedInvoice" name="detailedInvoice" action="detailedInvoice.asp" method="post" style="margin:0;padding:0" onsubmit="return false">
<div>Detailed Invoice <%=sInvoiceNumber%></div>


	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 style="border-top:2px ridge gray;border-bottom:2px ridge gray"  style="background:#FFF" >

		<input type="hidden" name="Horde" value="ab0903842b449d92d9b1a109f6656666" />
		<input type="hidden" name="Horde" value="be1dba8a9aae1ade8cfde782ce21e53a" />
			<INPUT type="hidden" name="custSeqNumber" value="<%= custSeqNumber %>">
			<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
			<INPUT type="hidden" name="targetPage" value="<%= actionString %>">
			<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
			<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
			<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
			<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
			<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
			<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
			<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
			<INPUT type="hidden" name="forceUpcharges" value="<%= f_upcharges %>">
			<INPUT type="hidden" name="forceColors" value="<%= f_colors %>">
			<INPUT type="hidden" name="forcePatterns" value="<%= f_pattern %>">
			<INPUT type="hidden" name="forceBrands" value="<%= f_brand %>">
			<INPUT type="hidden" name="upchargeSet" value="<%= upchargeSet %>">
			<INPUT type="hidden" name="colorSet" value="<%= colorSet %>">
			<INPUT type="hidden" name="patternSet" value="<%= patternSet %>">
			<INPUT type="hidden" name="brandSet" value="<%= brandSet %>">
			<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
			<INPUT type="hidden" name="isDueDateSet" value="<%= isDueDateSet%>">
			<input type="hidden" name="functionID" id="functionID" value="">
			<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
			<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
			<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
			<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
			<input type="hidden" name="selBrand" id="selBrand" value="<%= selBrandValue%>">
			<input type="hidden" name="totalUpchargescount" id="totalUpchargescount" value="<%= Session("totalUpchargescount")%>">
			<input type="hidden" name="totalPatternscount" id="totalPatternscount" value="<%= Session("totalPatternscount")%>">
			<input type="hidden" name="totalColorscount" id="totalColorscount" value="<%= Session("totalColorscount")%>">
			<input type="hidden" name="totalBrandscount" id="totalBrandscount" value="<%= Session("totalBrandscount")%>">
			<input type="hidden" name="frmuserAction" id="frmuserAction" value="<%=actionstring%>">
			<input type="hidden" name="loyaltyCard" id="loyaltyCard" value="<%=loyaltyCard%>">
			<input type="hidden" name="loyaltyEnabled" id="loyaltyEnabled" value="<%=loyaltyEnabled%>">
			<input type="hidden" name="promptPurchase" id="promptPurchase" value="<%=prPurchaseLoy%>">
			<input type="hidden" name="promptInvoice" id="promptInvoice" value="<%=prInvoice%>">
			<input type="hidden" name="promptLoyOffers" id="promptLoyOffers" value="<%=prLoyOffers%>">
			<input type="hidden" name="visits" id="visits" value="<%=prVisits%>">
			<input type="hidden" name="numLoyOffers" id="numLoyOffers" value="<%=numLoyOffers%>">
			<input type="hidden" name="custVisits" id="custVisits" value="<%=custVisits%>">
			<input type="hidden" name="userHasSelected" id="userHasSelected" value="<%=userHasSelected%>">
			<input type="hidden" name="createdDate" id="createdDate" value="<%=createdDate%>">
			<input type="hidden" name="quickItemsCount" id="quickItemsCount" value="<%=quickItemsCount%>">
			<input type="hidden" name="useHS" id="useHS" value="<%=ObjMiscSetUp.Item("useHeatSeal")%>">
			<input type="hidden" name="needHS" id="needHS" value="<%=needHS%>">
			<input type="hidden" name="currHS" id="currHS" value="<%=currHS%>">
			<input type="hidden" name="usedHSList" id="usedHSList" value="<%=usedHSList%>">
			<input type="hidden" name="hasHSItems" id="hasHSItems" value="<%=hasHSItems%>">
			<input type="hidden" name="hsCount" id="hsCount" value="<%=hsCount%>">
			<input type="hidden" name="lastItemQuantity" id="lastItemQuantity" value="<%=lastItemQuantity%>">
			<input type="hidden" name="enableRedoMode" id="enableRedoMode" value="<%=enableRedoMode%>">
			<INPUT type="hidden" name="minimumPrepayAmount" value="<%=invoice.getMinimumPrepay()%>">
            <input type="hidden" name="screenWidth" id="screenWidth">
            <input type="hidden" name="screenHeight" id="screenHeight">
		<tr>
				<td valign=top style="border-right:2px ridge gray">
					<TABLE ALIGN=center WIDTH="100%" BORDER=0  CELLPADDING=0 CELLSPACING=0>
						<tr>
							<td style="background-color:#6698FF;">
								<%
									dim deptRst
									dim lStart, noOfElements
									set deptRst =  Session("departmentMaster")
									if deptRst.RecordCount > 0 then
										lStart =deptStartIndex
										noOfElements = deptRst.PageCount
										deptRst.AbsolutePage = lStart
										'While Not (deptRst.Eof Or deptRst.AbsolutePage <> lStart )

								%>

								<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=2 CELLPADDING=0 style="background-color:#6698FF;font-size:10px;">
									<tr align=center>
										<td valign=top>
											<BUTTON type="button" class=small id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" style="width: 80px;
											<%
													if trim(selectedDept) = trim(deptRst.Fields("departmentID")) then %>
													border:2px inset #CCCCCC;
												<% if enableRedoMode then %>
														background: darkgray;
												<% else %>
													background: white;
												<%
													end if
													end if
											%>
											" onClick="setSelectedDept(this)"><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>

										</td>
										<%
											deptRst.MoveNext
											if Not deptRst.eof then
										%>
											<td valign=top>
											<BUTTON type="button" class=small id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" style="width: 80px;
											<%
													if trim(selectedDept) = trim(deptRst.Fields("departmentID")) then %>
													border:2px inset #CCCCCC;
												<% if enableRedoMode then %>
														background: darkgray;
												<% else %>
													background: white;
												<%
													end if
													end if
											%>
											" onClick="setSelectedDept(this)"><%if deptRst.Fields("imageFileName") <> "" then%><img src="../uploadedImages/<%= deptRst.Fields("imageFileName")%>"><br><%end if%><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>
											</td>
										<%
											deptRst.MoveNext
											end if
											if lStart < noOfElements then
										%>
												<td valign=top>
													<BUTTON type="button" class=small style="width: 80px" id=otherDept name=otherDept onClick="nextDeptPage();"><img src="/static/icons/24x24/next.png"><br>Other Dept</button>
												</td>
										<%
											else
												if lStart > 1 And lStart >= noOfElements then
										%>
												<td valign=top>
													<BUTTON type="button" class=small style="width: 80px" id=previous name=previous onClick="previousDeptPage();"><img src="/static/icons/24x24/previous.png"><br>Previous</button>
												</td>
										<%
												end if
											end if
										%>
									</tr>
									<tr align=center>
										<%
											if Not deptRst.eof then
										%>
											<td valign=top>
												<BUTTON type="button" class=small id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" onClick="setSelectedDept(this)" style="width: 80px;
												<%
													if trim(selectedDept) = trim(deptRst.Fields("departmentID")) then %>
													border:2px inset #CCCCCC;
												<% if enableRedoMode then %>
														background: darkgray;
												<% else %>
													background: white;
												<%
													end if
													end if
												%>"><%if deptRst.Fields("imageFileName") <> "" then%><img src="../uploadedImages/<%= deptRst.Fields("imageFileName")%>"><br><%end if%><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>
											</td>
										<%
											deptRst.MoveNext
											else
										%>
											<td>&nbsp</td>
										<%
											end if
											if Not deptRst.eof then
										%>
											<td valign=top>
												<BUTTON type="button" class=small id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" onClick="setSelectedDept(this)" style="width: 80px;
												<%
													if trim(selectedDept) = trim(deptRst.Fields("departmentID")) then %>
													border:2px inset #CCCCCC;
												<% if enableRedoMode then %>
														background: darkgray;
												<% else %>
													background: white;
												<%
													end if
													end if
												%>"><%if deptRst.Fields("imageFileName") <> "" then%><img src="../uploadedImages/<%= deptRst.Fields("imageFileName")%>"><br><%end if%><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>
											</td>
										<% else %>
										<td>&nbsp</td>
										<% end if%>

											<td valign=top>
											<% if alternativeRedo = 1 then %>
												<BUTTON type="button" class=small onClick="toggleRedoMode()" style="width: 80px;
												<%
													if enableRedoMode then
												%>
													border:2px inset #CCCCCC; background: darkgray;
												<%
													end if
												%>">Redo</button>
											<% elseif addOrEdit = "add" then %>
												<BUTTON type="button" class=small id=bttnCommonItems name=bttnCommonItems onClick="populateCommonItems()" style="width: 80px;
												<%
													if clng(selectedDept) = -1 then
												%>
													border:2px inset #CCCCCC;
												<%
													end if
												%>">Common<br>Items</button>
											<% else %>
												&nbsp
											<% end if %>
											</td>

									</tr>

								</table>
								<% end if%>
							</td>
							<td style="border-left:2px ridge gray;" valign=center>
								<TABLE ALIGN=center BORDER=0 CELLPADDING=2 CELLSPACING=0 style="font-size:10px;" >
								    <% dim useBigBtn
								    loyaltyEnabled = false
								    if useOverlay then
                                        useBigBtn = screenWidth >= 1500
                                        if ((not isNull(loyaltyCard)) and (loyaltyEnabled)) then
                                            useBigBtn = screenWidth >= 1600
                                        end if
                                    else
                                        useBigBtn = false
                                    end if
								    %>
									<tr>
										<td <% if not useBigBtn then %>width=20%<% end if %> align=center>
											<BUTTON type="button" class=<% if useBigBtn then %>diOtherBig<% else %>diOtherSmall<% end if %> name=overridePrice onClick="showOverRidePrice()"><img src="/static/icons/24x24/edit.png"><br>Override Price</button>
										</td>
										<td <% if not useBigBtn then %>width=20%<% end if %> align=center>
											<BUTTON type="button" class=<% if useBigBtn then %>diOtherBig<% else %>diOtherSmall<% end if %> name=addCharge onClick="showAddCharge()"><img src="/static/icons/24x24/add.png"><br>Add Charge</button>
										</td>
										<td <% if not useBigBtn then %>width=20%<% end if %> align=center>
											<BUTTON type="button" class=<% if useBigBtn then %>diOtherBig<% else %>diOtherSmall<% end if %> name=bttnholdTicket onClick="holdTicket()"><img src="/static/icons/24x24/pause.png"><br>Hold</button>
										</td>
										<td <% if not useBigBtn then %>width=20%<% end if %> align=center>
											<BUTTON type="button" class=<% if useBigBtn then %>diOtherBig<% else %>diOtherSmall<% end if %> name=coupons onClick="showAllCoupons()"><img src="/static/icons/24x24/discount.png"><br>Add Coupon</button>
										</td>
										<td <% if not useBigBtn then %>width=20%<% end if %> align=center>
										<%	if ((not isNull(loyaltyCard)) and (loyaltyEnabled)) then %>
												<BUTTON type="button" class=<% if useBigBtn then %>diOtherBig<% else %>diOtherSmall<% end if %> name=loyalty onClick="showAllLoyalty();">
												<img src="../images/Loyalty.gif"><br>Loyalty</BUTTON>
										<% end if %>
										</td>
									<% if not useBigBtn then %>
									</tr>
									<tr>
									<% end if %>
										<td align=center>
											<BUTTON type="button" class=<% if useBigBtn then %>diOtherBig<% else %>diOtherSmall<% end if %> name=heatseal value="Heat Seal" onClick="showHeatSeal()"><img src="/static/icons/24x24/heatseal.png"><br>Heat Seal</button>
										</td>
										<td align=center>
											<BUTTON type="button" class=<% if useBigBtn then %>diOtherBig<% else %>diOtherSmall<% end if %> name=deleteItem onClick="deleteItems()"><img src="/static/icons/24x24/remove.png"><br>Delete Item</button>
										</td>
										<td align=center>
											<BUTTON type="button" class=<% if useBigBtn then %>diOtherBig<% else %>diOtherSmall<% end if %> name=bttnClearInvoice onClick="clearInvoice()"><img src="/static/icons/24x24/clear.png"><br>Clear</button>
										</td>
										<td align=center>
											<BUTTON type="button" class=<% if useBigBtn then %>diOtherBig<% else %>diOtherSmall<% end if %> name=Notes onClick="showItemNotes()"><img src="/static/icons/24x24/note.png"><br>Item Notes</button>
										</td>

										<%
											dim cameraList
											dim cameraCount
											dim ssql

											ssql = "SELECT * from StoreHardware where hardwareType = 'IC'"
											set cameraList = getDisconnectedRecordset(ssql)

											cameraCount = cameraList.RecordCount

											cameraList.Close
											set cameraList = nothing

											if cameraCount > 0 then
										%>
										<td align=center>
											<BUTTON type="button" class=<% if useBigBtn then %>diOtherBig<% else %>diOtherSmall<% end if %> id=imgCap name=imgCap onClick="captureImage();"><img src="../images/find.gif"><br>Image</button>
										</td>
										<%
											end if
										%>

									</tr>
								</table>
							</td>
						</tr>
						<tr style="height:400px" >
							<td  style="border-top:2px ridge gray">
								<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=1 >
									<TR valign=center>
										<TD align=center valign=center>
											<INPUT id=txtAmountEntered name=txtAmountEntered class=text maxlength="5" style="WIDTH: 140px;vertical-align:middle;" value="<%=txtAmountEntered%>" >
										</TD>

										<TD>
											<BUTTON type="button" style="width:60px;height:30px;" name=quantity id=quantity onClick="changeQuantity()">Qty</button>
										</TD>
									</TR>

									<tr height=10px><td></td></tr>
									<TR>
										<TD colspan=2 style="vertical-align:middle;text-align:center;height:100px">
											<!-- #include file="../include/integerPad.inc" -->
										</TD>
									</TR>
								</table>
							</td>
							<td  style="border-top:2px ridge gray;border-left:2px ridge gray;" <% if useOverlay then %> rowspan="2" <% end if %> valign=top >
								<% if ObjMiscSetUp.Item("useHeatSeal") then %>
								    <B>HeatSeal: </B><INPUT style="width:380px" name="itemHeatSeal" onkeyup="captureKeyup(this);"
								    <% if forceHSBeforeDetail and currHS <> "" then %>
								        value="<%=currHS%>"
								    <% else %>
								        value="<%=Server.HTMLEncode(request.querystring("itemheatseal"))%>"
								    <% end if %>
								    >
								    <% if hasInfoMsg then %>
                                        <span style="color:green;font-size:smaller"><%=errMsg%></span>
								    <% else %>
                                        <span style="color:red;font-size:smaller"><%=errMsg%></span>
                                    <% end if %>
								<% else %>
								    <div style="border-bottom: 1px solid">
								    <input id="itemSearch" onkeyup="displayItems(this.value);" placeholder="Search" style="border: solid thin; width: 150px; background:white;" value="<%=Server.HTMLEncode(request.querystring("itemFilter"))%>" />
								    <input id="itemShortcut" onkeyup="captureKeyup(this);" placeholder="Shortcut" style="margin-left: 20px; border: solid thin; width: 150px; background:white;" value="<%=Server.HTMLEncode(request.querystring("itemshortcut"))%>" />
                                    </div>
								    <% if hasInfoMsg then %>
                                        <span style="color:green;font-size:smaller"><%=errMsg%></span>
								    <% else %>
                                        <span style="color:red;font-size:smaller"><%=errMsg%></span>
                                    <% end if %>
								<% end if %>
								<TABLE id="itemsTable" name="itemsTable" <% if useOverlay then %>style="width:-webkit-fill-available" <% else %> width=450 <%end if%> BORDER=0 CELLSPACING=1 CELLPADDING=1 >
									<tbody <% if useOverlay then %> style="width:-webkit-fill-available" <% end if %> />
								</table>
							</td>
						</tr>
						<% if useOverlay then
						    dim descHeight
						    descHeight = 180
						    if screenHeight <> "" then
                                descHeight = 180 + ((cint(screenHeight) - 768) / 1.6)
                            end if
						 %>
						<tr  style="height:<%= descHeight%>px">
							<td style="background:#FFF" style="border-top:2px ridge gray">
								<TABLE  style="background:#FFF" align="Center" BORDER=0 CELLSPACING=1 CELLPADDING=1>
                                        <tr height=50>
						                <td>
									    <div style="text-align:center" style="width:260px">
                                            <button type="button" style="margin:2px; width:80px;height:55px;vertical-align: top; overflow: hidden" onclick="showDesc('UP')"> Upcharges</button>
                                            <button type="button" style="margin:2px; width:80px;height:55px;vertical-align: top; overflow: hidden" onclick="showDesc('CO')">Colors</button>
                                       </td>
                                       </tr>
                                        <tr height=50>
						                <td>
									    <div style="text-align:center" style="width:260px">
                                            <button type="button" style="margin:2px; width:80px;height:55px;vertical-align: top; overflow: hidden" onclick="showDesc('PA')">Patterns</button>
                                            <% if useAdv then %>
                                            <button type="button" style="margin:2px; width:80px;height:55px;vertical-align: top; overflow: hidden" onclick="showDesc('BR')">Brands</button>
                                            <% end if %>
                                       </td>
                                       </tr>
						<% else %>
						<tr  style="height:180px">
							    <td style="background:#FFF" style="border-top:2px ridge gray" colspan=2>
								<TABLE  style="background:#FFF" width=415 BORDER=0 CELLSPACING=1 CELLPADDING=1>
									    <tr height=50>
										<td style="width:70px" >Upcharges</td>
										<%
											 if curr_LineNo <> "" then
												Set distinctUpcharges = Session("upcharges")
												if distinctUpcharges.Recordcount > 0 then
													lStart = upChargeStartIndex
													noOfElements = distinctUpcharges.PageCount
													distinctUpcharges.AbsolutePage = lStart
													while Not (distinctUpcharges.Eof Or distinctUpcharges.AbsolutePage <> lStart )
														upChargeValue = distinctUpcharges.Fields("descriptorName")
											%>
													<td align="center" style="width:45px">
														<BUTTON type="button" class=small id="<%= upChargeValue%>" name="<%= upChargeValue%>" title="<%= distinctUpcharges.Fields("price")%>" style="overflow: hidden;
														<%
															if selUpchargeValue = upChargeValue then
														%>
															border:2px inset #CCCCCC;
														<%
															end if
														%>
														background: #FFFFFF url(../uploadedImages/<%= distinctUpcharges.Fields("imageFileName")%>) no-repeat top;
														" onClick="setSelectedUpCharge(this);"><span class="detBtnTxt"><%= WordTrim(upChargeValue, 15)%></span></button>
													</td>
											<%
														distinctUpcharges.MoveNext
														wend
													if lStart < noOfElements then
												%>
													<td  style="width:45px" align="center">
														<BUTTON type="button" class=small id=moreUpCharge name=moreUpCharge onClick="nextUpChargePage();" style="background:#dcdcdc"><img src="/static/icons/24x24/next.png"><br>More</button>
													</td>
											<%
													else
														if lStart > 1 And lStart >= noOfElements then

											%>
														<td  style="width:45px" align="center">
															<BUTTON type="button" class=small id=prevUpCharge name=prevUpCharge onClick="prevUpChargePage();" style="background:#dcdcdc"><img src="/static/icons/24x24/previous.png"><br>Previous</BUTTON>
														</td>
											<%
														end if
													end if
												end if
											end if
										%>
											<td>&nbsp;</td>
									</tr>
									<tr height=50>
										<td style="width:70px" >Colors</td>
										<%
											dim distinctColors, colorValue
											if curr_LineNo <> "" then
												Set distinctColors = Session("colors")
												if distinctColors.Recordcount > 0 then
													lStart = colorsStartIndex
													noOfElements = distinctColors.PageCount
													distinctColors.AbsolutePage = lStart
													while Not (distinctColors.Eof Or distinctColors.AbsolutePage <> lStart )
														colorValue = distinctColors.Fields("descriptorName")
												%>
														<td height=45px style="width:45px"  align="center">
															<BUTTON type="button" class=small id="<%= colorValue%>" name="<%= colorValue%>" style="overflow: hidden;
															<%
																if selColorValue = colorValue then
															%>
																border:2px inset #CCCCCC;
															<%
																end if
															%>
															background:<%= Replace(colorValue," ", "")%>;
															" onClick="setSelectedColor(this);"><span class="detBtnTxt"><%= WordTrim(colorValue,15)%><span></button>
														</td>
												<%
														distinctColors.MoveNext
													wend
													if lStart < noOfElements then
												%>
													<td style="width:45px" align="center">
														<BUTTON type="button" type="button" class=small id=moreColors name=moreColors onClick="nextColorPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/next.png"><br>More</button>
													</td>
											<%
													else
														if lStart > 1 And lStart >= noOfElements then

											%>
															<td  style="width:45px" align="center">
																<BUTTON type="button" class=small id=prevColors name=prevColors onClick="prevColorPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/previous.png"><br>Previous</button>
															</td>
											<%
														end if
													end if
												end if
											end if
										%>
										<td>&nbsp;</td>
									</tr>
									<tr height=50>
										<td style="width:70px" >Patterns</td>
										<%
											dim distinctPatterns
											dim patternValue
											if curr_LineNo <> "" then
												Set distinctPatterns = Session("patterns")
												if distinctPatterns.Recordcount > 0 then
													lStart = patternStartIndex
													noOfElements = distinctPatterns.PageCount
													distinctPatterns.AbsolutePage = lStart
													while Not (distinctPatterns.Eof Or distinctPatterns.AbsolutePage <> lStart )
														patternValue = distinctPatterns.Fields("descriptorName")
												%>
														<td height=45px style="width:45px" align="center">
															<BUTTON type="button" class=small id="<%= patternValue%>" name="<%= patternValue%>" style="overflow: hidden;
															<%
																if selPatternValue = patternValue then
															%>
																border:2px inset #CCCCCC;
															<%
																end if
															%>
															background: #FFFFFF url(../uploadedImages/<%= distinctPatterns.Fields("imageFileName")%>);
															" onClick="setSelectedPattern(this);"><span class="detBtnTxt"><%= WordTrim(patternValue,15)%></span></button>
														</td>
												<%
														distinctPatterns.MoveNext
													wend
													if lStart < noOfElements then
												%>
													<td  style="width:45px" align="center">
														<BUTTON type="button" class=small id=morePatterns name=morePatterns onClick="nextPatternsPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/next.png"><br>More</button>
													</td>
											<%
													else
														if lStart > 1 And lStart >= noOfElements then
											%>
														<td style="width:45px" align="center">
															<BUTTON type="button" class=small id=prevPatterns name=prevPatterns onClick="prevPatternsPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/previous.png"><br>Previous</button>
														</td>
											<%
														end if
													end if
												end if
											end if
										%>
										<td>&nbsp;</td>
									</tr>
									<% end if %>
								</table>
							</td>
						</tr>
					</table>
				</td>
				<td valign="top">
					<TABLE WIDTH="280px" BORDER=0 CELLSPACING=3 CELLPADDING=0 style="background:#FFF">
						<tr >
							<td >
								<TABLE WIDTH="280px" BORDER=0 CELLSPACING=0 CELLPADDING=0 style="background:#FFF">
									<tr>
										<td width=35px rowspan=2 style="border-left:1px solid black;border-top:1px solid black;border-bottom:1px solid black;">
											<%
												doesCustHaveNotes
												if hasNotes = 1 then
											%>
											<BUTTON type="button" class=small id=customerNotes name=customerNotes style="background-color:coral" onClick="showCustomerNotes();"><img src="/static/icons/24x24/note.png"><br>Customer Notes</button>
											<%
												else
											%>
											<BUTTON type="button" class=small id=customerNotes name=customerNotes style="width:90px" onClick="showCustomerNotes();"><img src="/static/icons/24x24/note.png"><br>Customer Notes</button>
											<%
												end if
											%>

										</td>
										<%
											if invoice.multiPickUpCustName = "" then
										%>
										<td class="label" align=center style="border-top:1px solid black; border-right:1px solid black;height:20px;"><%= Server.HTMLEncode(customerName)%>&nbsp;</td>
									</tr>
									<tr>
										<td class="label" align=center style="border-right:1px solid black;border-bottom:1px solid black;height:20px;"><%= custPhone%>&nbsp;</td>
										<%
											else
										%>
										<td class="label" align=center style="border-top:1px solid black; border-right:1px solid black;height:20px;"><%= invoice.multiPickUpCustName%>&nbsp;</td>
									</tr>
									<tr>
										<td class="label" align=center style="border-right:1px solid black;border-bottom:1px solid black;height:20px;"><%= invoice.multiPickUpLoc%>&nbsp;</td>
										<%
											end if
										%>
									</tr>

								</table>
							</td>
						</tr>
<%

				dim customerPreference
				dim customerPreferences
				dim customerPreferencesRS
				dim query

				set customerPreferences = invoice.preferences

				query = " select * from customerpreferencetype order by displayorder "
        set customerPreferencesRS = getdisconnectedrecordset(query)

        dim itemViewHeight
        ' for a 768 screen, mine is 1080
        itemViewHeight = 470
        if useOverlay then
            if screenHeight <> "" then
                itemViewHeight = 470 + ((cint(screenHeight) - 768) / 1.6)
            end if
        end if
        if customerPreferencesRS.recordcount > 0 then
        	itemViewHeight = itemViewHeight - round(customerPreferencesRS.recordcount / 3 + 0.5) * 37
        end if

%>
						<tr >
							<td valign="top">

								<DIV id="invList" STYLE="overflow-y:auto;height:<%=itemViewHeight%>px; overflow-x:auto; width:280px;background:white;border:1px solid gray">
									<TABLE WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=0>
										<tr rowspan =5>
											<td>
												<TABLE name="invoiceTable" id ="invoiceTable" WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=2>
												<input type="hidden" name="select" id="select" value="">
																<%
														dim displayRst
														dim displayAsEntered
														dim cloneRst
														dim checkItem
														dim varBookMark
														dim currDeptId
														dim displayDeptName, deptName
														dim deptDueDate
														dim redoItem

														Redim deptIds(0)
														invoiceDone
														set displayRst = invoice.lineItems
														if displayRst.RecordCount > 0 then
															set cloneRst = displayRst.Clone
															if ObjMiscSetUp.Count > 0 then
																displayAsEntered = ObjMiscSetUp.Item("displayItemsAsEntered")
															else
																displayAsEntered =true
															end if
															if Not displayAsEntered then
																displayRst.Sort = "itemType, lineNumber DESC"
															else
																displayRst.Sort = "itemType"
															end if
															displayRst.MoveFirst
															displayRst.Filter = "itemType='DE'"


															%>

															<%
															while not displayRst.eof
																checkItem = false
																if displayRst.Fields("quantity") > 0  then
																	if IsNumeric(curr_LineNo) then
																		if clng(curr_LineNo) =  displayRst.Fields("lineNumber").Value then
																			checkItem = true
																		end if
																	end if
														%>
															<tr name="main" title="DE" onClick="selectRow(this);" <% if checkItem then%>style="background-color:#C2DACD;" <%end if %>>
																<td colspan=2 valign=top><input type="radio" name="select" id="select" value="<%= displayRst.Fields("lineNumber")%>" <% if checkItem then%> checked <%end if %>></td>
																<td class="label" width="15px" align=right valign=top><%= displayRst.Fields("quantity")%></td>
																<td class="label" valign=top><%=Server.HTMLEncode(displayRst.Fields("itemName"))%></td>
																<td class="label" width="50px" align=right valign=top><%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2)%></td>
															</tr>
																<%
																	'Response.Write displayRst.Fields("itemName")
																	if not IsNull(displayRst.Fields("notes")) then
																%>
															<tr>
																<td colspan=2 valign=top></td>
																<td class="label" width="15px" align=right valign=top></td>
																<td class="label" valign=top>
																<span style="color:#009b01"><%= displayRst.Fields("notes") %></span>
																</td>
																<td class="label" width="50px" align=right valign=top></td>
															</tr>
																<%
																	end if
																%>
														<%	end if
														%>
													<%
																displayRst.MoveNext
															wend
															displayRst.Filter = adFilterNone
														%>

														<% if (isMaxItemExceedPerDept) then %>
															<tr> <td colspan=3 class="label" width="50px" align=right valign=top style="color:RED" >
															Maximum Count of <%= maxItemCountPerDept %> for "<%= maxItemDeptName %>" exceeded </td> </tr>
														<% end if%>

														<%
															displayRst.MoveFirst
															while not displayRst.eof
																if not isNull(displayRst.Fields("deptId").Value) then
																	currDeptId = displayRst.Fields("deptId").Value

																	if not checkIfDeptExists(currDeptId) then
																		dim isManualMaxPiecesEnabled
																		dim departmentPieceCount
																		dim departmentMaxPieces

																		isManualMaxPiecesEnabled = invoice.isManualMaxPiecesEnabled(currDeptId)
																		departmentPieceCount = invoice.getDepartmentPieceCount(currDeptId)
																		departmentMaxPieces = invoice.getDepartmentMaxPieces(currDeptId)

																		displayDeptName = false
																		Redim Preserve deptIds(UBound(deptIds)+1)
																		deptIds(UBound(deptIds)) = currDeptId

																		varBookMark = displayRst.Bookmark
																		displayRst.Filter = "deptId=" & currDeptId
																		deptName = displayRst.Fields("deptName").Value

														%>
														<%
																		while not displayRst.eof

																		checkItem = false
																		redoItem = false
																		select case displayRst.Fields("itemType")
																				case "IT"

														%>
																					<%
																						if  Not displayDeptName then
																							deptDueDate = getDeptDueDate(displayRst, displayRst.Fields("deptID").Value)
																					%>
																							<tr name="dept" style="color:#B22222;">
																								<td colspan=5 class="label" style="background:#EEE;">
																									<% if isManualMaxPiecesEnabled then %>
																									<span class="departmentMaxPieces"
																										pieces="<%=departmentPieceCount%>"
																										maxPieces="<%=departmentMaxPieces%>"
																										deptName="<%=deptName%>"
																										style="float:left;width:70px;padding:4px;">
																											<%=departmentPieceCount%>/<%=departmentMaxPieces%>
																									</span>
																									<% end if %>
																									<span style="float:left;"><input style="background:#EEE" name="deptOnInvoice" value="<%= deptName%>" readonly></span>
																									<span style="float:right">
																									<input name="deptDueDate<%= replace(deptName, " ", "")%>"  onclick="selectDeptDueDate(this, '<%=deptName%>');" style="width:80px;text-align:center" value="<%= deptDueDate%>">
																									</span>
																								</td>
																							</tr>
																					<%
																							displayDeptName = true
																						end if

																						if IsNumeric(curr_LineNo) then
																							if clng(curr_LineNo) =  displayRst.Fields("lineNumber").Value then
																								checkItem = true
																							end if
																						end if

																						redoItem = displayRst.Fields("redo")
																					%>
																					<tr name="main" title="IT" onClick="selectRow(this);" style="<% if redoItem then %>color: gray; <% end if %> <% if checkItem then%>background-color:#C2DACD; <%end if %>">
																						<td  valign="center" colspan=2 valign=top><input type="radio" name="select" id="select" value="<%=displayRst.Fields("lineNumber")%>"
																							<% if checkItem then%> checked <%end if %>
																						></td>
																						<td  valign="center" class="label" width="15px" align=right valign=top><%= displayRst.Fields("quantity")%></td>
																						<td  valign="center" class="label" valign=top >
																							<% if checkItem then %><a name="itemAnchor" <% if redoItem then %>style="color: gray"<% end if %>><% end if %>
																							<%=Server.HTMLEncode(displayRst.Fields("itemName"))%>
																							<% if displayRst.Fields("priceLater") then %> <span style="background:red;color:white">&nbsp;(Needs Pricing)&nbsp;</span><% end if %>
																							<% if checkItem then %></a><% end if %>
																						</td>
																						<td  valign="center" class="label" width="100px" align=right valign=top><%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
																					</tr>

																						<%

																							'Response.Write  displayRst.Fields("itemName")
																							if not isNull(displayRst.Fields("promptResponse")) or not isNull(displayRst.Fields("notes")) or not isNull(displayRst.Fields("peNotes")) then

																						%>

																					<tr>
																						<td colspan=2 valign=top></td>
																						<td class="label" width="15px" align=right valign=top></td>
																						<td class="label" valign=top>
																						<%
																							if not isNull(displayRst.Fields("notes")) then
																						%>
																						<div style="color:#009b01"><%= displayRst.Fields("notes") %></div>
																						<%
																							end if
																						%>

																						<%
																							if not isNull(displayRst.Fields("peNotes")) then
																						%>

																							<div style="color:#4381Ef"><%= displayRst.Fields("peNotes") %></div>
																						<%
																							end if
																						%>

																						<%
																							if not isNull(displayRst.Fields("promptResponse")) then
																						%>
																							<div style="color:#ff0000"><%= displayRst.Fields("promptResponse") %></div>
																						<%
																							end if
																						%>
																						</td>
																						<td class="label" width="50px" align=right valign=top></td>
																					</tr>

																						<%
																							end if
																						%>
																<%
																				cloneRst.Filter ="parentLineNumber=" & displayRst.Fields("lineNumber")
																					if cloneRst.Recordcount > 0 then
																						cloneRst.MoveFirst
																						while not cloneRst.Eof

																						  checkItem = false
  																						if IsNumeric(curr_LineNo) then
  																							if clng(curr_LineNo) =  cloneRst.Fields("lineNumber") then
  																								checkItem = true
  																							end if
  																						end if
																%>
																						<tr name="sub" title="SI" onClick="selectRow(this);" style="<% if redoItem then %>color: gray;"<% end if %> <% if checkItem then%>background-color:#C2DACD; <%end if %>">
																							<td width=10px></td>
																							<td valign=top><input type="radio" name="select" id="select" value="<%= cloneRst.Fields("lineNumber")%>" <% if checkItem then%> checked <%end if %>></td>
																							<td class="label" width="15px" align=right valign=top><%= cloneRst.Fields("quantity")%></td>
																							<td class="label" valign=top><%=Server.HTMLEncode(cloneRst.Fields("itemName"))%></td>
																							<td class="label" width="100px" align=right valign=top><%= FormatCurrency(cloneRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
																						</tr>
																								<%
																									'Response.Write cloneRst.Fields("itemName")
																									if not isNull(cloneRst.Fields("notes")) then
																								%>
																						<tr>
																							<td colspan=2 valign=top></td>
																							<td class="label" width="15px" align=right valign=top></td>
																							<td class="label" valign=top>
																							<span style="color:#009b01"><%= cloneRst.Fields("notes") %></span>
																								<%
																									'end if
																									if not isNull(cloneRst.Fields("peNotes")) then
																								%>
																									<br><span style="color:#4381Ef"><%= cloneRst.Fields("peNotes") %></span>
																								<%
																									end if
																								%>
																							</td>
																						<td class="label" width="100px" align=right valign=top></td>
																						</tr>
																								<%
																									end if
																								%>
																<%
																							cloneRst.MoveNext
																						wend
																				end if
																				cloneRst.Filter = adFilterNone
																		case "CU"
																					if  Not displayDeptName then
																%>
																				<tr name="dept" style="color:#B22222;">
																					<td colspan=5 class="label" style="background:#EEE;">
																						<% if isManualMaxPiecesEnabled then %>
																						<span class="departmentMaxPieces"
																							pieces="<%=departmentPieceCount%>"
																							maxPieces="<%=departmentMaxPieces%>"
																							deptName="<%=deptName%>"
																							style="float:left;width:70px;padding:4px">
																								<%=departmentPieceCount%>/<%=departmentMaxPieces%>
																						</span>
																						<% end if %>
																						<span style="float:left;"><input style="background:#EEE" name="deptOnInvoice" value="<%= deptName%>" readonly></span>
																						<span style="float:right">
																						<input name="deptDueDate<%= replace(deptName, " ", "")%>"  onclick="selectDeptDueDate(this, '<%=deptName%>');" style="width:80px;text-align:center" value="<%= deptDueDate%>">
																						</span>
																					</td>
																				</tr>
																<%
																						displayDeptName = true
																					end if
																%>
																				<tr name="main" onClick="selectRow(this);" style="color:#996633;">
																					<td colspan=2 valign=top><input type="radio" name="select" id="select" value="<%= displayRst.Fields("lineNumber")%>"></td>
																					<td class="label" width="15px" align=right valign=top><%= displayRst.Fields("quantity")%></td>
																					<td class="label" valign=top>
																						<%=Server.HTMLEncode(displayRst.Fields("itemName"))%>
																					</td>
																					<td class="label" width="100px" align=right valign=top><%= FormatCurrency(-displayRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
																				</tr>




													<%
																		case "AC"
																				if  Not displayDeptName then
													%>
																				<tr name="dept" style="color:#B22222;">
																					<td colspan=5 class="label" style="background:#EEE;">
																						<% if isManualMaxPiecesEnabled then %>
																						<span class="departmentMaxPieces"
																							pieces="<%=departmentPieceCount%>"
																							maxPieces="<%=departmentMaxPieces%>"
																							deptName="<%=deptName%>"
																							style="float:left;width:70px;padding:4px">
																								<%=departmentPieceCount%>/<%=departmentMaxPieces%>
																						</span>
																						<% end if %>
																						<span style="float:left;"><input style="background:#EEE" name="deptOnInvoice" value="<%= deptName%>" readonly></span>
																						<span style="float:right">
																						<input name="deptDueDate<%= replace(deptName, " ", "")%>"  onclick="selectDeptDueDate(this, '<%=deptName%>');" style="width:80px;text-align:center" value="<%= deptDueDate%>">
																						</span>
																					</td>
																				</tr>
													<%
																					displayDeptName = true
																				end if
													%>
																				<tr name="main" onClick="selectRow(this);" style="color:#FF4500;">
																					<td colspan=2 valign=top><input type="radio" name="select" id="select" value="<%= displayRst.Fields("lineNumber")%>"></td>
																					<td class="label" width="15px" align=right valign=top><%= displayRst.Fields("quantity")%></td>
																					<td class="label" valign=top><%=Server.HTMLEncode(displayRst.Fields("itemName"))%></td>
																					<td class="label" width="100px" align=right valign=top><%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
																				</tr>

																						<%
																							'Response.Write  displayRst.Fields("itemName")
																							if not isNull(displayRst.Fields("notes")) then
																						%>
																				<tr>
																					<td></td>
																					<td></td>
																					<td><span style="color:#009b01"><%= displayRst.Fields("notes") %></span></td>
																					<td></td>
																				</tr>
																						<%
																							end if
																						%>

																<%
																		case "PR"
																					if  Not displayDeptName then
																%>
																				<tr name="dept" style="color:#B22222;">
																					<td colspan=5 class="label" style="background:#EEE;">
																						<% if isManualMaxPiecesEnabled then %>
																						<span class="departmentMaxPieces"
																							pieces="<%=departmentPieceCount%>"
																							maxPieces="<%=departmentMaxPieces%>"
																							deptName="<%=deptName%>"
																							style="float:left;width:70px;padding:4px">
																								<%=departmentPieceCount%>/<%=departmentMaxPieces%>
																						</span>
																						<% end if %>
																						<span style="float:left;"><input style="background:#EEE" name="deptOnInvoice" value="<%= deptName%>" readonly></span>
																						<span style="float:right">
																						<input name="deptDueDate<%= replace(deptName, " ", "")%>"  onclick="selectDeptDueDate(this, '<%=deptName%>');" style="width:80px;text-align:center" value="<%= deptDueDate%>">
																						</span>
																					</td>
																				</tr>
																<%
																						displayDeptName = true
																					end if
																%>
																				<tr name="main" style="color:#996633;">
																					<td colspan=2 valign=top></td>
																					<td class="label" width="15px" align=right valign=top></td>
																					<td class="label" valign=top>
																						<%=Server.HTMLEncode(displayRst.Fields("itemName"))%>
																					</td>
																					<td class="label" width="100px" align=right valign=top ><%= FormatCurrency(-displayRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
																				</tr>

																<%
																		case "TA"
																					if  Not displayDeptName then
																%>
																				<tr name="dept" style="color:#B22222;">
																					<td colspan=5 class="label" style="background:#EEE;">
																						<% if isManualMaxPiecesEnabled then %>
																						<span class="departmentMaxPieces"
																							pieces="<%=departmentPieceCount%>"
																							maxPieces="<%=departmentMaxPieces%>"
																							deptName="<%=deptName%>"
																							style="float:left;width:70px;padding:4px">
																								<%=departmentPieceCount%>/<%=departmentMaxPieces%>
																						</span>
																						<% end if %>
																						<span style="float:left;"><input style="background:#EEE" name="deptOnInvoice" value="<%= deptName%>" readonly></span>
																						<span style="float:right">
																						<input name="deptDueDate<%= replace(deptName, " ", "")%>"  onclick="selectDeptDueDate(this, '<%=deptName%>');" style="width:80px;text-align:center" value="<%= deptDueDate%>">
																						</span>
																					</td>
																				</tr>
																<%
																						displayDeptName = true
																					end if
																%>
																				<tr name="main" style="color:#996633;">
																					<td colspan=2 valign=top></td>
																					<td class="label" width="15px" align=right valign=top></td>
																					<td class="label" valign=top>
																						<%=Server.HTMLEncode(displayRst.Fields("itemName"))%>
																					</td>
																					<td class="label" width="100px" align=right valign=top><%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
																				</tr>
																<%
																		case "SU"
																					if  Not displayDeptName then
																%>
																				<tr name="dept" style="color:#B22222;">
																					<td colspan=5 class="label" style="background:#EEE;">
																						<% if isManualMaxPiecesEnabled then %>
																						<span class="departmentMaxPieces"
																							pieces="<%=departmentPieceCount%>"
																							maxPieces="<%=departmentMaxPieces%>"
																							deptName="<%=deptName%>"
																							style="float:left;width:70px;padding:4px">
																								<%=departmentPieceCount%>/<%=departmentMaxPieces%>
																						</span>
																						<% end if %>
																						<span style="float:left;"><input style="background:#EEE" name="deptOnInvoice" value="<%= deptName%>" readonly></span>
																						<span style="float:right">
																						<input name="deptDueDate<%= replace(deptName, " ", "")%>"  onclick="selectDeptDueDate(this, '<%=deptName%>');" style="width:80px;text-align:center" value="<%= deptDueDate%>">
																						</span>
																					</td>
																				</tr>
																<%
																						displayDeptName = true
																					end if
																%>
																				<tr name="main" style="color:#996633;">
																					<td colspan=2 valign=top></td>
																					<td class="label" width="15px" align=right valign=top></td>
																					<td class="label" valign=top>
																						<%=Server.HTMLEncode(displayRst.Fields("itemName"))%>
																					</td>
																					<td class="label" width="100px" align=right valign=top><%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
																				</tr>
																<%
																		case "VI"
																					if  Not displayDeptName then
																%>
																				<tr name="dept" style="color:#B22222;">
																					<td colspan=5 class="label" style="background:#EEE;">
																						<% if isManualMaxPiecesEnabled then %>
																						<span class="departmentMaxPieces"
																							pieces="<%=departmentPieceCount%>"
																							maxPieces="<%=departmentMaxPieces%>"
																							deptName="<%=deptName%>"
																							style="float:left;width:70px;padding:4px">
																								<%=departmentPieceCount%>/<%=departmentMaxPieces%>
																						</span>
																						<% end if %>
																						<span style="float:left;"><input style="background:#EEE" name="deptOnInvoice" value="<%= deptName%>" readonly></span>
																						<span style="float:right">
																						<input name="deptDueDate<%= replace(deptName, " ", "")%>"  onclick="selectDeptDueDate(this, '<%=deptName%>');" style="width:80px;text-align:center" value="<%= deptDueDate%>">
																						</span>
																					</td>
																				</tr>
																<%
																						displayDeptName = true
																					end if
																%>
																				<tr name="main" style="color:#996633;">
																					<td colspan=2 valign=top></td>
																					<td class="label" width="15px" align=right valign=top></td>
																					<td class="label" valign=top>
																						<%=Server.HTMLEncode(displayRst.Fields("itemName"))%>
																					</td>
																					<td class="label" width="100px" align=right valign=top><%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
																				</tr>
												<%
																	end select
																	displayRst.MoveNext
																wend
																displayRst.Filter = ""
																displayRst.Bookmark = varBookMark
															end if
														end if
														displayRst.MoveNext
													wend
												displayRst.MoveFirst
												displayRst.Filter = "deptId=Null"
												while not displayRst.eof
										%>
													<tr name="main" onClick="selectRow(this);" style="color:#996633;">
														<td colspan=2 valign=top><input type="radio" name="select" id="select" value="<%= displayRst.Fields("lineNumber")%>"></td>
														<td class="label" width="15px" align=right valign=top><%= displayRst.Fields("quantity")%></td>
														<td class="label" valign=top><%= displayRst.Fields("itemName") %></td>
														<td class="label" width="50px" align=right valign=top><%= FormatCurrency(-displayRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
													</tr>

										<%
													displayRst.MoveNext
												wend
												displayRst.Filter = ""
											end if
										%>
												</table>
											</td>
										</tr>
									</table>
								</div>
							</td>
						</tr>
						<tr >
							<td>
								<TABLE WIDTH="280px" BORDER=0 CELLSPACING=0 CELLPADDING=2 style="background:#FFF" >
									<tr>
										<td align=left class="label" width=100px>Due Date</td>
										<td align=right>
                                            <INPUT id=invoiceDueDate name=invoiceDueDate class=text style="WIDTH: 100px;height:22px;text-align:right;" value="<%if not invoice.isInvoiceEmpty() then response.write invoice.getDeptDueDate("")%>" onclick="confirmDateChange()" readonly>
										</td>
									</tr>
									<tr>
										<td align=left class="label" width=100px>Total Price</td>
										<td align=right>
											<INPUT id=txtTotalPrice name=txtTotalPrice class=text style="WIDTH: 100px;height:22px;text-align:right;" value="<%= FormatCurrency(invoice.getInvoiceAmountToPay(),2, -1, 0) %>" readonly>
										</td>
									</tr>
									<tr>
										<td align=left class="label" width=100px>Total Pieces</td>
										<td align=right>
											<INPUT id=txtTotal name=txtTotal class=text style="WIDTH: 100px;height:22px;text-align:right;" value="<%= invoice.getTotalItemCount() %>" readonly>
										</td>
									</tr>
									<tr>
									<td align="center" colspan=2>
									<div style="text-align:center" style="width:260px">
<%


        while not (customerPreferencesRS.eof or customerPreferencesRS.bof)
        	if customerPreferences.exists(clng(customerPreferencesRS("customerPreferenceTypeID"))) then
        		response.write "<button type=""button"" style=""margin:2px;width:80px;height:55px;vertical-align: top; overflow: hidden"" onclick=""changePreference(" & clng(customerPreferencesRS("customerPreferenceTypeID")) & ", '" & customerPreferencesRS("name") & "', '" & customerPreferencesRS("options") & "', '" & customerPreferences(clng(customerPreferencesRS("customerPreferenceTypeID"))) & "');"">"
        		response.write customerPreferencesRS("name") & "<br/>" & customerPreferences(clng(customerPreferencesRS("customerPreferenceTypeID")))
        		response.write "</button>"
        	end if

        	customerPreferencesRS.movenext
        wend

%>
									</div>
									</td>
									</tr>
									<tr>
										<td colspan=2>
											<TABLE WIDTH="280px" BORDER=0 CELLSPACING=1 CELLPADDING=0 >
												<tr>
													<td align=center>
														<INPUT class=touchNoBorder id=done name=done type=button value="" style="background-image:url(../images/ok.gif);" onClick="submitForm();">
													</td>
													<td align=center>
														<INPUT class=touchNoBorder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm();">
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
	</TABLE>
</FORM>
</BODY>
</HTML>