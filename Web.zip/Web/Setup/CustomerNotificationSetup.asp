<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
    dim overwrite
    dim query2, rs2, sms, email
    overwrite = trim(request.form("overwrite"))

	if trim(Request.QueryString("useraction")) = "submit" then
		SaveFormData()
	end if

    function SaveFormData()
        dim query2, currId

        query = "select id from QueryAlert where messageTypeId in (2, 3)"
        set rs = getdisconnectedrecordset(query)

         while not(rs.eof or rs.bof)
            currId = rs("id")

            sms = trim(Request.QueryString("chkSmsReport" & currId))
            email = trim(Request.QueryString("chkEmailReport" & currId))

            dim query3, exists
            query3 = "select * from CustomerMessageSetup where customerId = 0 and QueryId = " & currId
            set rs2 = getdisconnectedrecordset(query3)
            if rs2.recordcount > 0 then
                exists = 1
            else
                exists = 0
            end if


            if overwrite = 0 then
                if exists = 1 then
                    query2 = "Update CustomerMessageSetup set Sms = " & sms & ", email = " & email _
                        & " where customerId = 0 and QueryId = " & currId
                else
                    query2 = "insert into CustomerMessageSetup (CustomerId, QueryId, Sms, Email) values " _
                        & "(0, " & currId & ", " & sms & ", " & email & ")"
                end if
                qryexecute query2

            elseif overwrite = 1 then
                query2 = "delete CustomerMessageSetup where customerId != 0"
                qryexecute query2

                if exists = 1 then
                    query2 = "Update CustomerMessageSetup set Sms = " & sms & ", email = " & email _
                        & " where QueryId = " & currId
                else
                    query2 = "insert into CustomerMessageSetup (CustomerId, QueryId, Sms, Email) values " _
                        & "(0, " & currId & ", " & sms & ", " & email & ")"
                end if
                qryexecute query2

            elseif overwrite = 2 then
                query2 = "update CustomerMessageSetup set Sms = " & sms & " where queryId = " & currId
                qryexecute query2

            elseif overwrite = 3 then
                query2 = "update CustomerMessageSetup set Email = " & email & " where queryId = " & currId
                qryexecute query2
            end if
         rs.movenext
         wend

		Response.redirect("SMSMenu.asp")
    end function
%>

<html>
<head>
<title>Customer Notification Set Up</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</head>
<SCRIPT type="text/javascript" >


function save() {
    var msg;
    var option = document.getElementById("overwrite").value;

    if (option == 1)
        msg = "This will overwrite all manually set all customers to use the default options, are you sure you want to continue";
    else if (option == 2)
        msg = "This will overwrite all manually set customers' sms message options to use these options, are you sure you want to continue?";
    else if (option == 3)
        msg = "This will overwrite all manually set customers' email message options to use these options, are you sure you want to continue?";
    else
        msg = "This will update all existing customers who have not have manually set message choices, are you sure you want to continue?";

    cbs_confirm(msg, submitForm);
}


function submitForm() {
    var reports = '';
    <%
        query = "select id from QueryAlert where messageTypeId in (2, 3)"
        set rs = getdisconnectedrecordset(query)
        while not(rs.eof or rs.bof)
    %>
        reports = reports + "&chkSmsReport<%=rs("id")%>=" + ($("#chkSmsReport<%=rs("id")%>").is(":checked") ? "1" : "0") +
                "&chkEmailReport<%=rs("id")%>=" + ($("#chkEmailReport<%=rs("id")%>").is(":checked") ? "1" : "0");
    <%
        rs.movenext
        wend
    %>

	document.customerNotificationForm.action = "?useraction=submit" + reports;
	document.customerNotificationForm.submit();
}

function cancelForm() {
		document.customerNotificationForm.action = "\smsMenu.asp";
		document.customerNotificationForm.submit();
}

	function selChange(option) {
	    $("#sourceM").attr('checked', true);
        var checkboxes = $(this).closest('form').find(':checkbox');
        $('input[type=checkbox]').each(function () {
            if (this.id != 'chkSmsReport-10') {
                if (option == 2) {
                    if (this.id.indexOf("chkSms") != -1)
                        this.checked = true;
                }
                else if (option == 3) {
                    if (this.id.indexOf("chkEmail") != -1)
                        this.checked = true;
                }
                else
                    this.checked = (option == 1);
                this.disabled = false;
            }
        });
	}

</SCRIPT>
<body topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->

<form name="customerNotificationForm" action="" method="post" style="margin:0px">
	<TABLE ALIGN=center WIDTH="500px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px></tr>
		<tr><td colspan="3" style="text-align: center">
				<select style="margin:13px" name="overwrite" id="overwrite">
        			<option value="0">Save as Default</option>
        			<option value="1">Overwrite for All Customers</option>
        			<option value="2">Overwrite SMS for All</option>
        			<option value="3">Overwrite Email for All</option>
        		</select>
        </td></tr>
		<tr style="text-align: left">
		    <td style="white-space: nowrap;"><input type="radio" name="sel_choice" id="sel_all" value="0" onClick="selChange(1)"><label for="sel_all">Select All</label></td>
		    <td style="white-space: nowrap;"><input type="radio" name="sel_choice" id="sel_allSMS" value="0" onClick="selChange(2)"><label for="sel_allSMS">Select All SMS</label></td>
		    <td style="white-space: nowrap;"><input type="radio" name="sel_choice" id="sel_allEmail" value="0" onClick="selChange(3)"><label for="sel_allEmail">Select All Email</label></td>
		    <td style="white-space: nowrap;"><input type="radio" name="sel_choice" id="sel_none" value="1" onClick="selChange(0)"><label for="sel_none">Select None</label></td>
        </tr>
        <tr style="text-align: left">
            <th></th>
            <th>Message Type</th>
            <th>SMS Notification</th>
            <th>Email Notification</th>
        </tr>

        <tr><td style="white-space: nowrap; font-weight: bold">Transactions:</td></tr>
        <%
            query = "select id, name, triggerType from QueryAlert where messageTypeId in (2, 3) and groupType = 1 order by id desc"
            set rs = getdisconnectedrecordset(query)

            while not(rs.eof or rs.bof)
        %>
            <tr <% if rs("triggerType") = 0 then %>style="display: none" <% end if %>><td></td>
                <%
                    sms = 0
                    email = 0
                        query2 = "select sms, email from CustomerMessageSetup where queryId = " & rs("id") & " and customerId = 0"
                        set rs2 = getdisconnectedrecordset(query2)
                        if rs2.recordCount > 0 then
                            sms = rs2("sms")
                            email = rs2("email")
                        end if
                     %>
                <td  style="white-space: nowrap;"><%= rs("name") %></td>
                <% if rs("id") = "-10" then %>
                        <td><INPUT type=checkbox id="chkSmsReport<%=rs("id")%>" checked disabled> </TD>
                        <td> </TD>
                <% else %>
                    <td><INPUT type=checkbox id="chkSmsReport<%=rs("id")%>" <%if sms then %> checked <%end if %>> </TD>
                    <td> <INPUT type=checkbox id="chkEmailReport<%=rs("id")%>" <%if email then %> checked <%end if %>> </TD>
                <% end if %>
            </tr>
        <%
            rs.movenext
            wend
            set rs = nothing
        %>

        <tr><td style="white-space: nowrap; font-weight: bold; padding-top: 60px">Customer Service:</td></tr>
        <%
            query = "select id, name, triggerType from QueryAlert where messageTypeId in (2, 3) and groupType = 2 order by id desc"
            set rs = getdisconnectedrecordset(query)

            while not(rs.eof or rs.bof)
        %>
            <tr <% if rs("triggerType") = 0 then %>style="display: none" <% end if %>><td></td>
                <%
                    sms = 0
                    email = 0
                        query2 = "select sms, email from CustomerMessageSetup where queryId = " & rs("id") & " and customerId = 0"
                        set rs2 = getdisconnectedrecordset(query2)
                        if rs2.recordCount > 0 then
                            sms = rs2("sms")
                            email = rs2("email")
                        end if
                     %>
                <td  style="white-space: nowrap;"><%= rs("name") %></td>
                <td><INPUT type=checkbox id="chkSmsReport<%=rs("id")%>" <%if sms then %> checked <%end if %>> </TD>
                <td> <INPUT type=checkbox id="chkEmailReport<%=rs("id")%>" <%if email then %> checked <%end if %>> </TD>
            </tr>
        <%
            rs.movenext
            wend
            set rs = nothing
        %>

        <tr><td style="white-space: nowrap; font-weight: bold; padding-top: 60px">Delivery:</td></tr>
        <%
            query = "select id, name, triggerType from QueryAlert where messageTypeId in (2, 3) and groupType = 3 order by id desc"
            set rs = getdisconnectedrecordset(query)

            while not(rs.eof or rs.bof)
        %>
            <tr <% if rs("triggerType") = 0 then %>style="display: none" <% end if %>><td></td>
                <%
                    sms = 0
                    email = 0
                        query2 = "select sms, email from CustomerMessageSetup where queryId = " & rs("id") & " and customerId = 0"
                        set rs2 = getdisconnectedrecordset(query2)
                        if rs2.recordCount > 0 then
                            sms = rs2("sms")
                            email = rs2("email")
                        end if
                     %>
                <td  style="white-space: nowrap;"><%= rs("name") %></td>
                <td><INPUT type=checkbox id="chkSmsReport<%=rs("id")%>" <%if sms then %> checked <%end if %>> </TD>
                <td> <INPUT type=checkbox id="chkEmailReport<%=rs("id")%>" <%if email then %> checked <%end if %>> </TD>
            </tr>
        <%
            rs.movenext
            wend
            set rs = nothing
        %>

		<tr height=30px></tr>
		<tr>
			<td></td><td></td>
			<TD>
				<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick= "save()">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton style="background-image:url(../images/Cancel.gif)" type=button value="" onClick="cancelForm()">
						</TD>
					</tr>
				</table>
			</TD>
		</tr>
		<tr height=100px><td></td></tr>
</table>

</form>

</body>
</html>
