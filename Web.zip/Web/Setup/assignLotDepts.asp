<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs, lotID, lotName
	dim isSubmitted, msg
	dim target
	dim ticketNumber
	lotID = Request.QueryString("lotid")
	lotName = Request.QueryString("lotName")
	isSubmitted = Request.QueryString("Submitted")
	target = getReqVar("target")
	ticketNumber = getReqVar("ticketNumber")
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	if isSubmitted then
		updateDatabase(lotID)
		Response.Redirect("lots.asp?lotID=" & lotID)
	else

	end if

	function d_lots(selected, deptid)
		dim query, rs
		query = "select * from lot where id =" & lotID
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			while not(rs.eof or rs.bof)
				if rs("id") = selected then
				Response.Write "<INPUT TYPE=CHECKBOX style=width:25px;height:25px CHECKED name=box" & deptid & "></INPUT>"
				else
				Response.Write "<INPUT TYPE=CHECKBOX style=width:25px;height:25px name=box" & deptid & "></INPUT>"
				end if
				rs.movenext
			wend
			set rs = nothing

		end if
	end function

	function updateDatabase(lotID)
		dim query, rs
		query = "delete from lotDepartment where lotid = " & lotID
		QryExecute(query)

		query = "select * from department"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			while not(rs.eof or rs.bof)
				if evalRequestValue(Request.form("box" & rs("departmentid"))) = 1 then
					query = "insert into lotDepartment values( " & lotID & "," & rs("departmentid") & ")"
					QryExecute(query)
				end if
				rs.movenext
			wend
			set rs = nothing
		end if
	end function


%>
<HTML>
<HEAD>
<TITLE>Assign Departments to Lot</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">


	function cancelForm() {
		document.assignDepts.action =  "lots.asp?lotID=<%=lotID%>"; 
		document.assignDepts.submit();
	}

	function executeForm(id) {
		document.assignDepts.action =  "?Submitted=true" +
										"&lotID=" + id;
		document.assignDepts.submit();
	}



</SCRIPT>
<BODY topmargin=0 leftmargin=0 ><!-- #include file="../include/banner.inc" -->
<FORM id="assignDepts" name="assignDepts" action="assignLotDepts.asp" Method = "post">
<input type="hidden" name="target" value="<%=target%>" />
<input type="hidden" name="ticketNumber" value="<%=ticketNumber%>" />
<center>
<div style="background:lightblue;color:black;height:20;font-size:14">
	<b>Assign Departments to Lot - <%=lotName%></b>
</div>
<table border=1 cellspacing=0>

	<tr align=center style="background:CCFFCC;height:80px">


</table>

<div style="width:100%;margin-bottom:20px">
<%
	dim query_department
	dim rs_department


	query = "select * from pricelist where disable = 0 and storeid = " & session("storeid")
	set rs = getdisconnectedrecordset(query)

	while not (rs.eof or rs.bof)
%>
	<table border=1 style="float:center;">
		<tr>
			<th>
				<%=rs("name")%>
			</th>
		</tr>

<%
		query_department = "select d.*, ld.lotid as lot from department d LEFT OUTER JOIN lotdepartment ld ON d.departmentid = ld.deptid "
		query_department = query_department & "where d.disabled = 0 and d.pricelistid = " & rs("pricelistid")
		query_department = query_department & " and ld.lotid = " & lotid
		query_department = query_department & " and d.departmentid not in (select deptid from lotdefaultdepartment)"
		set rs_department = getdisconnectedrecordset(query_department)

		while not (rs_department.eof or rs_department.eof)
%>
		<tr>
			<td style="font-size:18">
				<%d_lots rs_department("lot"), rs_department("departmentid")%><%=rs_department("name")%>
			</td>
		</tr>
<%
			rs_department.movenext
		wend
		set rs_department = nothing
%>
	</table>
<%
		rs.movenext
	wend
	set rs = nothing
%>

</div>

<br><br>
<INPUT class=touchnoBorder id=cancelButton name=okButton type=button value="" style="background-image:url(../images/ok.gif)" onClick="executeForm(<%=lotid%>)">
<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
</center>

</FORM>
</BODY>
</HTML>