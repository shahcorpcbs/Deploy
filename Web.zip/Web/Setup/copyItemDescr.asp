<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs, query2, rs2, query3, rs3, query4, rs4
    dim plId, deptId, itemId, copyPlId, copyDeptId, copyItemId, descrType
    dim plName, deptName, itemName

    plId = trim(getReqVar("plID"))
    deptId = trim(getReqVar("deptId"))
    itemId = trim(getReqVar("itemID"))
    copyPlId = trim(getReqVar("copyPlId"))
    copyDeptId = trim(getReqVar("copyDeptId"))
    copyItemId = trim(getReqVar("copyItemId"))
    descrType = trim(getReqVar("descrType"))

    if copyPlId = "" then
        copyPLId = plId
        copyDeptId = deptId
        copyItemId = itemId
    end if


	if trim(Request.QueryString("useraction")) = "submit" then
		handleSave()
	end if

    query = "select name from PriceList where priceListId = " & plId
    set rs = getdisconnectedrecordset(query)
    plName = rs("name")

    query = "select name from Department where departmentId = " & deptId
    set rs = getdisconnectedrecordset(query)
    deptName = rs("name")

    query = "select itemName from PriceListItem where priceListItemId = " & itemId
    set rs = getdisconnectedrecordset(query)
    itemName = rs("itemName")

    query = "select name, priceListid from priceList"
    set rs = getdisconnectedrecordset(query)

    if copyPlId <> "" then
        query2 = "select name, departmentId from department where priceListId = " & copyPlId
        set rs2 = getdisconnectedrecordset(query2)
    end if

    if copyDeptId <> "" then
        query3 = "select itemName, priceListItemId from PriceListItem where priceListId = " & copyPlId & " and departmentId = " & copyDeptId
        set rs3 = getdisconnectedrecordset(query3)
    end if

    if copyItemId <> "" then
        query4 = "select descriptorName, price from ItemDescriptorPrice where priceListItemId = " & copyItemId _
            & " and descriptorType = '" & descrType & "' and disabled = 0"
        set rs4 = getdisconnectedrecordset(query4)
    end if

    function handleSave()
        dim copyType, deptsToCopyTo, query, rs

        copyType = getReqVar("copyToId")


        'Could create more efficient queries for each possibility rather than looping through create queries for each item
        'but then if any changes needed, would have to make them several times over. If page is slow, maybe reconsider
        if copyType = 1 then
            SaveFormData(itemId)
        elseif copyType = 2 then
            query3 = "select priceListItemId from PriceListItem where priceListId = " & plId & " and departmentId = " & deptId
            set rs3 = getdisconnectedrecordset(query3)
            while not(rs3.eof or rs3.bof)
                SaveFormData(rs3("priceListItemId"))
            rs3.movenext
            wend
        elseif copyType = 3 then
            query2 = "select departmentId from department where priceListId = " & plId
            set rs2 = getdisconnectedrecordset(query2)
            while not(rs2.eof or rs2.bof)
                query3 = "select priceListItemId from PriceListItem where priceListId = " & plId & " and departmentId = " & rs2("departmentId")
                set rs3 = getdisconnectedrecordset(query3)
                while not(rs3.eof or rs3.bof)
                    SaveFormData(rs3("priceListItemId"))
                rs3.movenext
                wend
            rs2.movenext
            wend
        elseif copyType = 4 then
            deptsToCopyTo = getReqVar("copyToDepts")
			dim deptIds, i
            deptIds = split(deptsToCopyTo, ",")
			for i = lbound(deptIds) to ubound(deptIds)
			    if deptIds(i) <> "" then
                    query3 = "select priceListItemId from PriceListItem where priceListId = " & plId & " and departmentId = " & deptIds(i)
                    set rs3 = getdisconnectedrecordset(query3)
                    while not(rs3.eof or rs3.bof)
                        SaveFormData(rs3("priceListItemId"))
                    rs3.movenext
                    wend
                end if
			next
        end if

        dim includeType
        if descrType = "CO" then
            includeType = 1
        elseif descrType = "PA" then
            includeType = 2
        else
            includeType = 3
        end if
        response.redirect "ItemDescrList.asp?plId=" & plId & "&deptId=" & deptId & "&itemId=" & itemId & "&includeType=" & includeType
    end function


    function SaveFormData(copyToItemId)
        on error resume next

        dim name, copyItemId, newItemId, newPrice, copyDescName
		name = trim(Request.QueryString("name"))
		newPrice = trim(Request.QueryString("newPrice"))
		copyItemId = trim(Request.QueryString("copyItemId"))
		copyDescName = trim(Request.QueryString("copyDescName"))


		query = "Insert into ItemDescriptorPrice(priceListItemId, descriptorName, descriptorType, price, " _
		   & "disabled, useGlobalTax, useGlobalDays, discountable, VIPDiscountable, VIPQualified, couponable, " _
		   & "outsideService, prePayPercent, displaySequence, daysToProcess, imageFileName, notes, " _
		   & "printNotes, UseCounter, prepayDiscount) " _
		   & "(select " & copyToItemId & ", '" & DBStr(name) & "', '" & descrType & "', '" & newPrice & "', " _
		   & "c.disabled, c.useGlobalTax, c.useGlobalDays, c.discountable, c.VIPDiscountable, c.VIPQualified, " _
		   & "c.couponable, c.outsideService, c.prePayPercent, c.displaySequence, c.daysToProcess, " _
		   & "c.imageFileName, c.notes, c.printNotes, c.UseCounter, c.prepayDiscount " _
		   & "from ItemDescriptorPrice c where c.priceListItemId = " & copyItemId & " and DescriptorName = '" _
		   & copyDescName & "' and descriptortype = '" & descrType & "')"
		qryexecute query


		query = "Insert into ItemDescriptorTax(priceListItemId, descriptorName, descriptorType, taxCode, storeId) " _
		    & "(select " & copyToItemId & ", '" & DBStr(name) & "', '" & descrType & "', c.taxCode, c.storeId from "_
		    & " ItemDescriptorTax c where c.priceListItemId = " & copyItemId & " and DescriptorName = '" _
		    & copyDescName & "' and descriptortype = '" & descrType & "')"
		qryexecute query


		query = "Insert into itemDescriptorSurcharge(priceListItemId, descriptorName, descriptorType, surchargeCode, priceListId) " _
		    & "(select " & copyToItemId & ", '" & DBStr(name) & "', '" & descrType & "', c.surchargeCode, " & plId _
		    & " from itemDescriptorSurcharge c where c.priceListItemId = " & copyItemId & " and DescriptorName = '" _
		    & copyDescName & "' and descriptortype = '" & descrType & "')"
		qryexecute query
    end function

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
%>

<html>
<head>
<title>Copy Department Item</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</head>
<script language="javascript" type="text/javascript">

    function submitForm() {
        if (document.getElementById('copyPlId').value == -1) {
            cbs_alert("Select a Price List");
            return;
        }
        if (document.getElementById('copyDeptId').value == -1) {
            cbs_alert("Select a Department");
            return;
        }
        if (document.getElementById('selCopyItemId').value == -1) {
            cbs_alert("Select an Item");
            return;
        }
        var name = $.trim(document.getElementById('nameText').value);
        if (name === "") {
            cbs_alert("Cannot set a blank item name");
            return;
        }
        var newPrice = $.trim(document.getElementById('newPrice').value);
        if (newPrice === "") {
            cbs_alert("Cannot set a blank price");
            return;
        }

        var copyTo = document.getElementById('copyTo').value;
        var copyDepts = ""
        if (copyTo == 4) {
            $(':checkbox').each(function() {
                if(this.checked) {
                    copyDepts += this.getAttribute("deptId") + ",";
                }
            });
            if (copyDepts == "") {
                cbs_alert("If selecting individual departments, must select at least one");
                return;
            }
        }

        document.copyItemDescrForm.action = "?useraction=submit" +
            "&plId=<%=plId%>&deptId=<%=deptId%>" +
	        "&name=" + encodeURIComponent(name) +
	        "&newPrice=" + encodeURIComponent(newPrice) +
	        "&copyToId=" + encodeURIComponent(copyTo) +
	        "&copyToDepts=" + encodeURIComponent(copyDepts) +
            "&copyPlId=<%=copyPLId%>" +
            "&copyDeptId=<%=copyDeptId%>" +
            "&copyItemId=" + encodeURIComponent(document.getElementById('selCopyItemId').value) +
            "&copyDescName=" + encodeURIComponent(document.getElementById('copyDescId').value);
        document.copyItemDescrForm.submit();
    }

    function changePriceList() {
        if (document.getElementById('copyPlId').value == -1)
            return;

        document.copyItemDescrForm.action = "?useraction=update" +
            "&plId=<%=plId%>&deptId=<%=deptId%>" +
            "&copyPlId=" + encodeURIComponent(document.getElementById('copyPlId').value);
        document.copyItemDescrForm.submit();
    }

    function changeDept() {
        if (document.getElementById('copyPlId').value == -1)
            return;
        if (document.getElementById('copyDeptId').value == -1)
            return;

        document.copyItemDescrForm.action = "?useraction=update" +
            "&plId=<%=plId%>&deptId=<%=deptId%>&copyItemId=" +
            "&copyPlId=" + encodeURIComponent(document.getElementById('copyPlId').value);
            "&copyDeptId=" + encodeURIComponent(document.getElementById('copyDeptId').value);

        document.copyItemDescrForm.submit();
    }

    function changeItem() {
        if (document.getElementById('copyPlId').value == -1)
            return;
        if (document.getElementById('copyDeptId').value == -1)
            return;
        if (document.getElementById('selCopyItemId').value == -1)
            return;

        document.copyItemDescrForm.action = "?useraction=update" +
            "&plId=<%=plId%>&deptId=<%=deptId%>" +
            "&copyPlId=" + encodeURIComponent(document.getElementById('copyPlId').value) +
            "&copyDeptId=" + encodeURIComponent(document.getElementById('copyDeptId').value) +
            "&copyItemId=" + encodeURIComponent(document.getElementById('selCopyItemId').value)
        document.copyItemDescrForm.submit();
    }

	function formatAsMoney(mnt)
	{
		mnt -= 0;
		mnt = (Math.round(mnt*100))/100;
		return (mnt == Math.floor(mnt)) ? mnt + '.00' : ( (mnt*10 == Math.floor(mnt*10)) ? mnt + '0' : mnt);
	}

    function changeName() {
        var selectBox = document.getElementById("copyDescId");
        var element = selectBox.options[selectBox.selectedIndex];
        if (element) {
            document.getElementById('nameText').value = element.text;
            document.getElementById('newPrice').value = formatAsMoney(element.getAttribute("price"));
        }
    }

    function changeCopyTo() {
        if (document.getElementById('copyTo').value == 4)
            document.getElementById('copySelDepts').style = "visibility:visible";
        else
            document.getElementById('copySelDepts').style = "visibility:collapse";
    }

    function cancelForm() {
        var includeType = "";
        if ('<%= descrType %>' == "CO")
            includeType = 1;
        else if ('<%= descrType %>' == "PA")
            includeType = 2;
        else if ('<%= descrType %>' == "UP")
            includeType = 3;
        document.copyItemDescrForm.action = "itemDescrList.asp?plId=<%=plId%>&deptId=<%=deptId%>&itemId=<%=itemId%>&includeType=" + includeType;
	    document.copyItemDescrForm.submit();
    }

</SCRIPT>
<body topmargin=0 leftmargin=0 onLoad="changeName()" ><!-- #include file="../include/banner.inc" -->
<H1>Copy Descriptor</H1><BR/><BR/>
<form name="copyItemDescrForm" action="" method="post" style="margin:0px" >
	<INPUT type="hidden" name="plId" value="<%= plId%>">
	<INPUT type="hidden" name="deptId" value="<%= deptId%>">
	<INPUT type="hidden" name="itemId" value="<%= itemId%>">
	<INPUT type="hidden" name="descrType" value="<%= descrType%>">

	<TABLE ALIGN=center WIDTH="500px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px></tr>
        <tr style="text-align: left">
            <th>Price List</th>
            <th>Department</th>
            <th>Item</th>
            <th>Descriptor</th>
        </tr>
    <td>
		<SELECT name="copyPlId" id="copyPlId" onChange="changePriceList()">
		    <option value="-1">Select</option>
			<%
				while not(rs.eof or rs.bof)
			%>
				<OPTION value="<%=rs("priceListId")%>"
				<% if cstr(rs("priceListId")) = cstr(copyPLId) then %>
				    selected
				<% end if %>
				>
				<%=Server.HTMLEncode(rs("name"))%></OPTION>
			<%
					rs.movenext
				wend
				set rs = nothing
			%>
		</SELECT>
    </td>
    <td>
		<SELECT name="copyDeptId" id="copyDeptId" onChange="changeDept()">
		    <option value="-1">Select</option>
			<%
			    if query2 <> "" then
				    while not(rs2.eof or rs2.bof)
			%>
				<OPTION value="<%=rs2("departmentId")%>"
				<% if cstr(rs2("departmentId")) = cstr(copyDeptId) then %>
				    selected
				<% end if %>
				>
				<%=Server.HTMLEncode(rs2("name"))%></OPTION>
			<%
                    rs2.movenext
                    wend
                    set rs2 = nothing
				end if
			%>
		</SELECT>
    </td>
    <td>
		<SELECT name="selCopyItemId" id="selCopyItemId" onChange="changeItem()">
		    <option value="-1">Select</option>
			<%
			    if query3 <> "" then
				    while not(rs3.eof or rs3.bof)
			%>
				<OPTION value="<%=rs3("priceListItemId")%>"
				<% if cstr(rs3("priceListItemId")) = cstr(copyItemId) then %>
				    selected
				<% end if %>>
				<%=Server.HTMLEncode(rs3("itemName"))%></OPTION>
			<%
                    rs3.movenext
                    wend
                    set rs3 = nothing
				end if
			%>
		</SELECT>
    </td>
    <td>
		<SELECT name="copyDescId" id="copyDescId" onChange="changeName()">
			<%
			    if query4 <> "" then
				    while not(rs4.eof or rs4.bof)
			%>
				<OPTION value="<%=rs4("descriptorName")%>" price="<%=rs4("price")%>">
				<%=Server.HTMLEncode(rs4("descriptorName"))%></OPTION>
			<%
                    rs4.movenext
                    wend
                    set rs4 = nothing
				end if
			%>
		</SELECT>
    </td>
    </tr>
		<tr  <% if query4 = "" then %> style="visibility:hidden;" <% end if %>>
		    <td>New Descriptor Name</td>
            <td><input type="text" id="nameText" ></td>
        </td></tr>
		<tr  <% if query4 = "" then %> style="visibility:hidden;" <% end if %>>
		    <td>New Descriptor Price</td>
            <td><input type="number" id="newPrice" ></td>
        </td></tr>
        <% if query4 <> "" then %>
        <tr height=50px></tr>
        <tr style="vertical-align:top">
            <td>Copy Descriptor to:</td>
            <td>
                <SELECT name="copyTo" id="copyTo" onChange="changeCopyTo()">
                    <option value="1">Single Item (<%= itemName %>)</option>
                    <option value="2">All Items in Dept (<%=deptName %>)</option>
                    <option value="3">All Items in All Depts for PriceList (<%=plName %>)</option>
                    <option value="4">All Items in Selected Depts</option>
                </select>
            </td>
            </tr>
            <tr height=50px></tr>
            <tr>
            <td colspan="4" id="copySelDepts" style="visibility:collapse;">
                <table>
                    <% dim query5, rs5, cnt
                        cnt = 0
                        query5 = "select departmentId, name from Department where disabled = 0 and priceListId = " & plId
                        set rs5 = getdisconnectedrecordset(query5)
                        while not(rs5.eof or rs5.bof) %>
                   <% if cnt mod 4 = 0 then %>
                   </tr><tr>
                   <% end if %>
                        <td><label for="chkCopyDep_<%=rs5("departmentId")%>"><%= rs5("name")%></label></td>
                        <td style="padding-right: 50px">
                            <Input type=checkbox id="chkCopyDep_<%=rs5("departmentId")%>" deptId="<%=rs5("departmentId")%>">
                        </td>
                    <% cnt = cnt + 1
                       rs5.movenext
                       wend %>
                </table>

            </td>
        </tr>
        <% end if %>
        <tr height=50px></tr>
		<tr>
			<TD>
				<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick= "submitForm()">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton style="background-image:url(../images/Cancel.gif)" type=button value="" onClick="cancelForm()">
						</TD>
					</tr>
				</table>
			</TD>
		</tr>
</table>


</form>

</body>
</html>
