<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<!--#include file="../include/services.asp" -->
<%
	dim isSubmitted 
	dim l_storeid
	dim l_terminalid, printerIP

	Dim userIPAddress
    userIPAddress = getLocalPrinterAddress(session("terminalid"))
	
	
	isSubmitted = Request.QueryString("submitted")
	
	l_storeid = session("StoreID")
	l_terminalid = session("Setupterminalid")

	dim query, rs
    printerIP = getPrinterShortPath()


	
	if (isSubmitted ) then
		if Request.QueryString("useraction")= "add" then
			AddPrinters()
		elseif Request.QueryString("useraction")= "delete" then
			DeletePrinters()
		end if
	end if


	    Dim data, httpRequest, postResponse
        on error resume next
	    Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
        httpRequest.Open "GET", "http://" & userIPAddress & printerIP & "/listPrinters", False
		httpRequest.send
        postResponse = Replace(httpRequest.ResponseText, "'", "\'")

	getTerminalPrinters()
	
%>

<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript" src="/script/printing.js"></script>
<script type="text/javascript" src="/external/jquery-3.4.1.js"></script>
<SCRIPT type="text/javascript">

	function getPrinterNames() {
		var printerArr;
		var i;
		var opt;
		var list = document.AddPrinterForm.selectMachine;
		
		printerArr = '<%= postResponse%>'.split(",");
		
		for(i = 0; i < printerArr.length; i++) {
			opt = new Option();
			opt.text = printerArr[i];
			opt.value = printerArr[i];
	
			list.options[list.options.length] = opt;
		}

	}

	function submitForm(element) {
		if (element == "add" ) {
            if (document.getElementById("selectMachine").value != null && document.getElementById("selectMachine").value != "") {
                document.AddPrinterForm.action = "?submitted=true&useraction=add";
                document.AddPrinterForm.submit();
            }
		}
		else if (element == "delete" ){
		    if (document.getElementById("selectTerminal").value != null && document.getElementById("selectTerminal").value != "") {
			    document.AddPrinterForm.action = "?submitted=true&useraction=delete";
				document.AddPrinterForm.submit();
			}
		}
		
	}	//end of function		
	
	
	function cancelForm(){
		document.AddPrinterForm.action = "Printers.asp";
		document.AddPrinterForm.submit();
		
	}		
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="getPrinterNames()">
<!-- #include file="../include/banner.inc" -->
<H1>Add Printers</H1>
<FORM id="AddPrinterForm" name="AddPrinterForm" action="customersetup.asp" Method = "post">
<center>
<TABLE WIDTH="550" BORDER=0 CELLSPACING=0 CELLPADDING=10><!-- header row -->

 <tr >
	<td align=left valign=top>
		<TABLE border="0" width = 40% cellpadding="0" cellspacing="0" >
			<tr>
			<td>
			Windows Printers<br />
			<SELECT multiple id=selectMachine name=selectMachine size = 10 STYLE="FONT-SIZE:16px; width:300px; height:auto" >
			</SELECT>
			</td>
			</tr>
		</table>
	</TD>
	
	<td align= left vAlign=top>
		<table>
		<tr>
			<td align= left valign=left><br><br>
			<INPUT class =click name="add" id="add" type=button value="Add>>" onClick="submitForm('add')"  style="HEIGHT: 50px; WIDTH: 100px;">
			</td>
		</tr>
		<tr>
			<td align= left valign=left><br><br>
			<INPUT class = click name="delete" id="delete" type=button value="<<Delete" onClick="submitForm('delete')"  style="HEIGHT: 50px; WIDTH: 100px;">
			</td>
		</tr>
		</Table>
	</td>
	
	<td>
		<TABLE border="0" width = 40% cellpadding="0" cellspacing="0">
			<tr><td>
			Printers Available in CBS<br />
			<SELECT multiple id=selectTerminal name=selectTerminal size = 10 STYLE="FONT-SIZE: 16px; width:300px; height:auto" >
			<%
					if rstTerminalPrinters.Recordcount > 0 then
						while not rstTerminalPrinters.eof
				%>	
				<OPTION VALUE= "<%=trim(rstTerminalPrinters("hardwareid"))%>"><%=trim(rstTerminalPrinters("hardwarename")) %> </option>
				<%
					rstTerminalPrinters.movenext
					wend
						rstTerminalPrinters.close
						set rstTerminalPrinters = nothing
					end if 
				
				%>
			</SELECT>
			</td>
			</tr>
		</table>
	</td>
	</tr>
	</TABLE>
	<table WIDTH="550" border=0>
	<tr height=100 valign=middle>
		<td align= center>
			<INPUT class = touchnoborder name=cancel type=button value="" onClick="cancelForm()"  style="background-image:url(../images/ok.gif);">&nbsp&nbsp&nbsp
			<INPUT class = touchnoborder name=OK type=button value="" onClick="cancelForm()"   style="background-image:url(../images/Cancel.gif);">
		</td>
	</tr>
	</table>
	</FORM>
</center>	
</BODY>
</HTML>
<%
	dim rstTerminalprinters
	
	function getTerminalPrinters()
	dim sqltxt
	
	sqltxt = "Select Hardwarename, hardwareid from storehardware where hardwareType= 'PR' "_
				&  " and terminalid = " & l_terminalid
				
	set rstTerminalPrinters = getDisconnectedrecordset(sqltxt)
	
	
	end function
	
	function DeletePrinters()
	dim sqltxt
		dim counter 
		dim sName
		DbStartTrans()		 
		for counter = 1 to Request.Form("selectTerminal").count
				sName = trim(Request.Form("selectTerminal").Item(counter))
				sqltxt = "Delete printer where hardwareid = " & sName _
							& " ; Delete storehardware where hardwareid = " & sName	
					
						 
			'Response.Write sqltxt
			QryExecuteWithTrans(sqltxt)
			next 
		DbEndTrans()
	
	
	end Function
	
	
	function AddPrinters()
		dim sqltxt
		dim counter 
		dim sName
		DbStartTrans()		 
		for counter = 1 to Request.Form("selectMachine").count
				sName = trim(Request.Form("selectMachine").Item(counter))
				sqltxt = " INSERT INTO  StoreHardware ( terminalID, hardwareName, hardwareType )" _
							& " VALUES ( " _
							&  l_terminalid _
							& ", " & DbCreateQryString(sName)_
							&  ", " & "'PR'" & ")"	
						 
			'Response.Write sqltxt
			QryExecuteWithTrans(sqltxt)
			next 
		DbEndTrans()
		
	 end function
	
%>
	



