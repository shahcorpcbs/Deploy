<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim isSubmitted 
	dim l_storeid
	dim sqltxt 
	dim l_sourceid
	dim l_mode
	Dim actionstring
	
	isSubmitted = Request.QueryString("submitted")
	l_storeid = session("StoreID")
	actionstring = Request.QueryString("userAction")
	
	if (isSubmitted ) then
		if not isnull(l_storeid) and l_storeid <> "" then
			l_mode = Request.QueryString("mode")	
			if (l_mode= "delete") then
				l_sourceid = Request.Form("sourceid")
				sqltxt = "delete from CustomerSourceDomain where CustomerSourceID =" & l_sourceid
				QryExecute(sqltxt)
			elseif (l_mode= "add") then
				actionstring = actionstring & "?mode=" & l_mode 
				Response.Redirect(actionstring)	
			elseif (l_mode= "edit") then
				actionstring = actionstring & "?mode=" & l_mode & "&sourceid=" & Request.Form("sourceid")
				Response.Redirect(actionstring)	
			elseif (l_mode= "toggleactive") then
				toggleSourceActive Request.Form("sourceid")
			else 
				Response.Redirect(actionstring)	
			end if
		end if
	end if
	
	function toggleSourceActive(sourceid)
		dim query, rs
		
		query = " update customersourcedomain set active = (case active when 0 then 1 else 0 end) "
		query = query & " where customersourceid = " & sourceid

		qryexecute query
	
	end function
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<STYLE type="text/css">
.inactive {
	background: #eee;
	padding: 2px;
	border: 1px solid #ccc;
	font-size: 12px;
}

</STYLE>

</HEAD>
<script language="javascript" type="text/javascript">

	function submitForm(element) {
		var x;
		var i;	
		if (element=="delete"){
			x ="CustomerSource.asp";
			document.customersource.mode.value="delete";
			document.customersource.action="?Submitted=true&userAction=" + x  + "&mode=" + document.customersource.mode.value + "&sourceid=" + document.customersource.sourceid.value;
			}
		else if (element=="add"){
				x = "AddCustomerSource.asp";
				document.customersource.mode.value="add";
				document.customersource.action="?Submitted=true&userAction=" + x  + "&mode=" + document.customersource.mode.value;
			}
		else if	(element=="edit"){
				x = "AddCustomerSource.asp";
				document.customersource.mode.value="edit";
				document.customersource.action="?Submitted=true&userAction=" + x  + "&mode=" + document.customersource.mode.value + "&sourceid=" + document.customersource.sourceid.value;
			}
		else if (element == "toggleactive") {
			x ="CustomerSource.asp";
			document.customersource.mode.value="toggleactive";
			document.customersource.action="?Submitted=true&userAction=" + x  + "&mode=" + document.customersource.mode.value + "&sourceid=" + document.customersource.sourceid.value;
		}
		document.customersource.submit();
	}			
	function setSourceId(element){
		document.customersource.sourceid.value = element.value;
		document.customersource.edit.disabled = false;
		document.customersource.toggleactive.disabled = false;
	}
	
	function cancelForm(){
		document.customersource.action = "CustomerSetup.asp";
		document.customersource.submit();
		
	}		
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Customer Source</H1>
<center>
<FORM id="customersource" name="customersource" action="customersetup.asp" Method = "post">
<input type=hidden name="mode">
<input type=hidden name="sourceid" >


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON name="add" onClick="submitForm(this.name)" style="font-size:12px">Add</button>
		<BUTTON name=delete onClick="submitForm(this.name)"<% if (totalcount= 0 ) then %> Disabled<%end if%> style="font-size:12px">Delete</button>
		<BUTTON name=edit  onClick="submitForm(this.name)"  Disabled style="font-size:12px">Edit</button>
		<BUTTON name=toggleactive  onClick="submitForm(this.name)"  Disabled style="font-size:12px; vertical-align:top">Toggle<br>Active</button>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON name=OK onClick="cancelForm()" >Exit</BUTTON>
	</SPAN>
</DIV>	

			<TABLE CLASS="itable" BORDER =0 CELLSPACING=0>
			<tr>
				<th width="40px">&nbsp;</th>
				<th>Name</th>
				<th>Status</th>
				<th>Customers</th>
				<th>Last Addition</th>
				<th>Total Sales</th>
			</tr>
			<%
				l_storeid = 1
				dim rssource
				dim totalcount
				totalcount = 0

				sqltxt = "SELECT CustomerSourceDomain.customerSourceID, CustomerSourceDomain.Active, CustomerSourceDomain.name, COUNT(Customer.customerSequenceNumber) AS customercount, ISNULL(SUM(Customer.totalSales), 0) AS totalsales,  "
				sqltxt = sqltxt & "isnull(convert(varchar, MAX(Customer.createdDate), 101), 'None') AS lastcreatedate "
				sqltxt = sqltxt & "FROM CustomerSourceDomain LEFT OUTER JOIN "
				sqltxt = sqltxt & "Customer ON CustomerSourceDomain.customerSourceID = Customer.customerSourceID "
				sqltxt = sqltxt & "WHERE (CustomerSourceDomain.storeID = 1) "
				sqltxt = sqltxt & "GROUP BY CustomerSourceDomain.customerSourceID, CustomerSourceDomain.name, CustomerSourceDomain.Active "
				
				set rssource= getdisconnectedrecordset(sqltxt)
				totalcount = rssource.RecordCount
				while not rssource.BOF and not rssource.EOF 
			%>
				<tr height =30>	
					<td width = 40px align="center"><Input type=radio name=rdname value="<%=rssource("CustomerSourceId")%>" onclick="setSourceId(this)" ></td>
					<td><%=rssource("Name")%></td>
					<td>
					<% if not rssource("Active") then%><span class="inactive">INACTIVE</span>
					<% else %>&nbsp;
					<% end if %>
					</td>
					<td align="center"><%=rssource("customercount")%></td>
					<td align="center"><%=rssource("lastcreatedate")%></td>
					<td align="right"><%=formatcurrency(rssource("totalsales"))%></td>
				</tr>	
			<%	rssource.movenext	
				wend		
			%>

			</TABLE>

</FORM>
</center>
</BODY>
</HTML>


