<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim isSubmitted 
	dim l_storeid
	dim sqltxt 
	dim BodyCaption
	dim l_creditid
	dim l_creditType
	dim l_creditname
	dim l_mode
	dim rsCredit
	
	isSubmitted = Request.QueryString("submitted")
	l_storeid = session("StoreID")
		
	if (isSubmitted ) then
		if not isnull(l_storeid) and l_storeid <> "" then
			l_mode = Request.QueryString("mode")	
			if (l_mode= "add") then
				dbstartTrans()
				sqltxt = "insert CreditcardTypeDomain (name,cardType,Storeid) Values (" _
					& dbcreateqrystring(Request.Form("txtname")) _
					& "," & dbcreateqrystring(Request.Form("credittype")) _
					 & "," & l_storeid _
					 & " )"
			'Response.Write sqltxt		 
				QryexecuteWithTrans(sqltxt)
				dbendTrans()
			elseif (l_mode= "edit") then
				l_creditid = Request.Form("creditid")
				dbstartTrans()
				sqltxt = "update CreditcardTypeDomain set " _
					 & "name= " & dbcreateqrystring(Request.Form("txtname")) _
					 & ", Cardtype=" & dbcreateqrystring(Request.Form("credittype"))_
					 & " where CreditCardTypeID = " & l_creditid & "and Storeid = " & l_storeid 
						 
				Qryexecutewithtrans(sqltxt)
				dbendtrans()
			end if
		end if
	end if
	
	dim actionstring
	actionstring= Request.QueryString("userAction")
	'Response.Write actionstring
	if ( not isnull(actionstring) and actionstring <> "") then
		Response.Redirect(actionstring)
	end if
	
	
	l_mode = Request.QueryString("mode")
	
	if (l_mode = "add") then
		BodyCaption= "Add Credit Card"
	elseif (l_mode = "edit") then
		BodyCaption= "Edit Credit Card"
		l_creditid = request.Querystring("Creditid")
		sqltxt = "select * from CreditcardTypedomain where CreditcardTypeid = " & l_creditid
		set rscredit = getDisconnectedRecordset(sqltxt)
		if not rsCredit.bof and not rsCredit.EOF then
		l_creditname = rscredit("name")
		l_credittype = rscredit("cardtype")
		end if
	end if
	
	
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	
	function setCreditType(){
		var i 
		i = document.addcreditcard.optcreditype.selectedIndex
		document.addcreditcard.credittype.value = document.addcreditcard.optcreditype[i].value;
	}
			
	function submitForm() {
		if(trim(document.addcreditcard.txtname.value) =="") {
			alert("Name is a required field");
			document.addcreditcard.txtname.focus();
		}
		else {
			setCreditType()
			document.addcreditcard.action = "?Submitted=true&mode=" + document.addcreditcard.mode.value + "&useraction=" + "Creditcard.asp";
			document.addcreditcard.submit();
		}
	}			
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<B class="pageHeading"><%=BodyCaption%></B>
<FORM id="addcreditcard" name="addcreditcard" action="" Method = "post">
<input type=hidden name="mode" value ="<%=l_mode%>">
<input type=hidden name="creditid" value ="<%=l_creditid%>">
<input type=hidden name="credittype" >
<TABLE WIDTH="200" BORDER=2 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT: 50px"><!-- header row -->
<tr><td align=left valign=top>
	<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT: 8px">
	<tr><td>
	<TABLE width = 200px border="0" cellpadding="7" cellspacing="0">
	<tr>
		<td width = 150px >Card Name&nbsp;<b><font color=red>*</font></td>
		<TD>
        <SELECT name="txtname" style="width:185px">
            <OPTION <%if l_creditname = "Visa" then%>selected<%end if%> value="Visa">Visa</OPTION>
            <OPTION <%if l_creditname = "MasterCard" then%>selected<%end if%>  value="MasterCard">MasterCard</OPTION>
            <OPTION <%if l_creditname = "Discover" then%>selected<%end if%>  value="Discover">Discover</OPTION>
            <OPTION <%if l_creditname = "Diners Club" then%>selected<%end if%>  value="Diners Club">Diners Club</OPTION>
            <OPTION <%if l_creditname = "American Express" then%>selected<%end if%>  value="American Express">American Express</OPTION>
            <OPTION <%if l_creditname = "JCB" then%>selected<%end if%>  value="JCB">JCB</OPTION>
            <OPTION <%if l_creditname = "Carte Blanche" then%>selected<%end if%>  value="Carte Blanche">Carte Blanche</OPTION>
            <OPTION <%if l_creditname = "Australian BankCard" then%>selected<%end if%>  value="Australian BankCard">Australian BankCard</OPTION>
        </SELECT>

        
        </TD>
	</tr>
	<tr>
		<td width = 150px >Type</td>
		<TD><Select name="optcreditype" style= "width = 185px">
			<option Value="credit" selected >Credit</option>
			<option Value="debit" >Debit</option>
		</SELECT></TD>
	</tr>
	</table>
	</td></TR>
	<tR><td align = left><br>
	<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif);background-position=center"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
	<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);background-position=center" onClick="history.back(-1)">
		 </td></tr>
	</TABLE><br>
<td></tr></table>
</FORM>
		
</BODY>
</HTML>
