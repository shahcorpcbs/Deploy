<%@Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim isSubmitted 
	dim l_terminalid
	dim l_storeid 
	dim rstPort
	
	l_storeid  = Session("Storeid")
	l_terminalid = Session("Setupterminalid")
	isSubmitted = Request.QueryString("submitted")
	if (isSubmitted) then
		updateDatabase()
		Response.Redirect("hardware.asp")
	end  if
	
	dim rstDisplay
	dim l_hardwareid
	dim l_port 
	dim l_rate
	dim l_text
	dim l_scroll
	dim l_name
	dim l_price
	dim l_item
	dim l_upcharge
	dim l_upchargePrice
	
	getCustomerDisplayInfo()
	getPorts()
	
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	
	function submitForm(useraction) {
		if (validateform(useraction)) {
			document.customerdisplay.action = "?Submitted=true&useraction="+ useraction
			document.customerdisplay.submit();
		}
	}	
	
	function cancelForm() {
		document.customerdisplay.action = "Hardware.asp"
		document.customerdisplay.submit();
	}		
	
	function validateform(element)	{
	i = 0
	found = false;
	retval = false;
		if (element != "delete" ){
			while (i < document.customerdisplay.rdPort.length){
				if ( document.customerdisplay.rdPort(i).checked){
					found = true;
					retval=true;
					break;
				}
				i++;
			}
		if (found == false)
			alert("Port is a required field");
			
		}
		else
			retval= true;
		return retval;
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0 bgColor=6jh67>
<!-- #include file="../include/banner.inc" -->
<H1>Customer Display</H1>
<FORM id="customerdisplay" name="customerdisplay" action="" Method = "post">
<input type = hidden name = "h_hardwareid" value = "<%=l_hardwareid %>">
<CENTER>
<TABLE WIDTH=600px BORDER=2 CELLSPACING=0 CELLPADDING=0 ><!-- header row -->
<TBODY>
 <tr>
	<td align=left valign=top>
	<TABLE width = 100% border="0" cellpadding="10" cellspacing="0" Style = "MARGIN-LEFT: 10px">
	<tr><td><br>
		<TABLE width = 100% border="0" cellpadding="10" cellspacing="0">
		<tr>
			<td  valign=top width = 90 class = "label" Style="FONT-Weight=normal;" >Port:<br><br></td>
			<td valign=top align= left>
				<INPUT id=portno name=rdPort type=radio  Value = "COM1" 
				<% if l_port = "COM1" then %>
					CHECKED 
				<% end if %> 
				<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "COM1" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 
				>
				COM1
				&nbsp;&nbsp
				
				<INPUT id=portno name=rdPort type=radio  Value = "COM2" 
				<% if l_port = "COM2" then %>
				CHECKED 
				<% end if %>
				<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "COM2" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 
				>COM 2
				&nbsp;&nbsp
				
				<INPUT id=portno name=rdPort type=radio  Value = "COM3" 
				<% if l_port = "COM3" then %>
				CHECKED 
				<% end if %>
				<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "COM3" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if %> 
				>COM 3
				&nbsp;&nbsp
				
				<INPUT id=portno name=rdPort type=radio  Value = "COM4"
				<% if l_port = "COM4" then %>
				CHECKED 
				<% end if %>
				<% if rstPort.recordcount > 0  then 
						rstPort.Movefirst
						Do while not rstPort.eof%>
						<%if ucase(rstport("port")) = "COM4" then %>
							Disabled
						<%
						exit do
						end if %>		
				<%		rstPort.movenext
						loop
					
				%>
					
				<% end if  
				rstPort.close
				set rstPort = nothing
				%>
				>COM 4</td>
		</tr>
		<tr>
			<td valign=top width = 90 class = "label" Style="FONT-Weight=normal;">Baud Rate<br><br></td>
			<td valign=top >
			<SELECT name= optBrate STYLE="Height = 24px;FONT-SIZE: 15px ;Width = 160px ">
				<Option 
				<%if l_rate = "1200" then %>
				Selected 
				<%end if%>
				
				Value = 1200>1200</option>
				<Option  <%if l_rate = "1800" then %>
				Selected 
				<%end if%>
				Value = 1800>1800</option>
				<Option  <%if l_rate = "2400" then %>
				Selected 
				<%end if%>
				Value = 2400>2400</option>
				<Option  <%if l_rate = "4800" then %>
				Selected 
				<%end if%>
				Value = 4800>4800</option>
				<Option  <%if l_rate = "7200" then %>
				Selected 
				<%end if%>
				Value = 7200>7200</option>
				<Option  <%if l_rate = "9600" then %>
				Selected 
				<%end if%>
				Value = 9600>9600</option>
				<Option  <%if l_rate = "14400" then %>
				Selected 
				<%end if%>
				Value = 14400>14400</option>
				<Option  <%if l_rate = "19200" then %>
				Selected 
				<%end if%>
				Value = 19200>19200</option>
				<Option  <%if l_rate = "57600" then %>
				Selected 
				<%end if%>
				Value = 38400>38400</option>												
				<Option  <%if l_rate = "57600" then %>
				Selected 
				<%end if%>
				Value = 57600>57600</option>												
				<Option  <%if l_rate = "115200" then %>
				Selected 
				<%end if%>
				Value = 115200>115200</option>																								
				</SELECT> 
			</td>
		</tr>
		<tr>
			<td width =80 class = "label" Style="FONT-Weight=normal;">Display Text</td>
			<td >
			<input class = text maxlength="64" name="txtdisplayText" Style = "Width = 200px" value = "<%=l_text %>">
			&nbsp;&nbsp
			<input type=checkbox name=chkScroll 
			<% if l_scroll  then %>
				CHECKED 
			<% end if %>
			>Scroll if Capable</td>
		</tr>
		</table>
		<TABLE width = 100% border="0" cellpadding="10" cellspacing="0">
		<tr>
			<td align=left valign=top class = "label" Style="FONT-Weight=normal;" >Display</td>
		</tr>
		<tr>
			<td align=left valign=top><INPUT name=chkDisplayName type=checkbox 
			<% if l_name   then %>
				CHECKED 
			<% end if %>>&nbsp;&nbsp;Customer Name</td>
			<td align=left valign=top><INPUT name=chkDisplayPrice type=checkbox
			 <% if l_price  then %>
				CHECKED 
			<% end if %>>&nbsp;&nbsp;Incoming Item Pricing</td>
		</tr>
		<tr>
			<td align=left valign=top ><INPUT  name=chkDisplayItems type=checkbox 
			<% if l_item  then %>
				CHECKED 
			<% end if %> >&nbsp;&nbsp;Display Incoming Items</td>
			<td align=left valign=top ><INPUT name =chkShowUpcharges type=checkbox 
			<% if l_upcharge  then %>
				CHECKED 
			<% end if %> >&nbsp;&nbsp;Show Upcharges</td>
			<td align=left valign=top ><INPUT name=chkShowPricing type=checkbox  
			<% if l_upchargePrice  then %>
				CHECKED 
			<% end if %>	
			>&nbsp;&nbsp;Upcharging Pricing</td>
		</tr>
		<table align=center>
			<td  align=center colspan="2">
			<br><br>
			<INPUT class = click name="delete" type=button value="Do not use"
			<%  if len(trim(l_hardwareid)) = 0 then %>
				Disabled
			<%end if %>
			style="HEIGHT: 50px;width:100" onClick="submitForm('delete')">&nbsp<br><br>
			<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitForm()">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
			</td>
			
		</table>
	</table>
	</td></tr>
</Table></FORM>
</CENTER>
</BODY>
</HTML>

<%
	function getCustomerDisplayInfo()
	dim sqltxt
		
		sqltxt = "select * from storehardware where hardwaretype = 'DP' and terminalid = " & l_terminalid
		'Response.Write sqltxt
		set rstDisplay = GetDisconnectedRecordset(sqltxt)
		
		if rstdisplay.recordcount > 0  then
			l_hardwareid = rstDisplay("hardwareid")
			l_port  = rstDisplay("port")
			l_rate= rstDisplay("Baudrate")
			l_text= rstDisplay("defaultCustomerDisplayText")
			l_scroll= rstDisplay("scrollIfCapable")
			l_name= rstDisplay("displayCustomerName")
			l_price= rstDisplay("displayItemPrice")
			l_item= rstDisplay("displayItem")
			l_upcharge= rstDisplay("displayItem")
			l_upchargePrice= rstDisplay("showUpchargePrice")
		end if
		
		rstDisplay.close
		set rstDisplay = nothing
		
	end function
	
	function updateDatabase()
	dim hardwareid
	dim sqltxt
	hardwareid = Request.Form("h_hardwareid")
	if (Request.QueryString("useraction") = "delete" ) then
		sqltxt= "delete storehardware where hardwareid = " & hardwareid
		dbstarttrans()
		QryExecuteWithTrans(sqltxt)
		dbendTrans()
	
	else
	
		if len(trim(hardwareid)) = 0 then
		'insert
			sqltxt = "insert Storehardware (terminalid,hardwarename,hardwaretype, port, baudRate, " _
				 & " defaultCustomerDisplayText, scrollIfCapable, displayCustomerName, " _
				 & "displayItemPrice, displayItem, showUpcharges, showUpchargePrice ) values (" _
				  & l_terminalid _
				  & ", " & "'Customer Display Pole'" _
				  &  ", " & "'DP'" _
				  & "," & dbcreateqrystring(Request.form("rdPort")) _
				  & "," & dbcreateQryString(Request.form("optBrate"))  _
				   & "," & dbcreateQryString(Request.form("txtdisplayText")) _
				   & "," & evalRequestValue(Request.form("chkScroll")) _
				   & "," & evalRequestValue(Request.form("chkDisplayName")) _
				   & "," & evalRequestValue(Request.form("chkDisplayPrice")) _
				   & "," & evalRequestValue(Request.form("chkDisplayItems")) _
				   & "," & evalRequestValue(Request.form("chkShowUpcharges")) _
				   & "," & evalRequestValue(Request.form("chkShowPricing")) _
				   & ")"
				  ' Response.Write sqltxt
				   dbstarttrans()
				   QryExecuteWithTrans(sqltxt)
				   dbendTrans()
	
		else
		'update 
		
			sqltxt = "update Storehardware set  " _
				  & "port=" & dbcreateqrystring(Request.form("rdPort")) _
				  & ", baudRate=" & dbcreateQryString(Request.form("optBrate"))  _
				  & ", defaultCustomerDisplayText=" & dbcreateQryString(Request.form("txtdisplayText")) _
				  & ",  scrollIfCapable=" & evalRequestValue(Request.form("chkScroll")) _
				  & ", displayCustomerName=" & evalRequestValue(Request.form("chkDisplayName")) _
				  & ", displayItemPrice=" & evalRequestValue(Request.form("chkDisplayPrice")) _
				  & ", displayItem=" & evalRequestValue(Request.form("chkDisplayItems")) _
				  & ", showUpcharges=" & evalRequestValue(Request.form("chkShowUpcharges")) _
				  & ", showUpchargePrice=" & evalRequestValue(Request.form("chkShowPricing")) _
				  & " where hardwareid = " & hardwareid
				   'Response.Write sqltxt
				   dbstarttrans()
				   QryExecuteWithTrans(sqltxt)
				   dbendTrans()
		end if
	end if
	
	end function
	
	function getPorts()
	dim sqltxt
		sqltxt = "select distinct port from storehardware where port is not null and hardwaretype <> 'DP' and terminalid = " & l_terminalid 
		set rstPort = getdisconnectedrecordset(sqltxt)
		
	end function
	
%>
