<%@ Language=VBScript %>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
		
	function submitForm() {
		document.addholiday.submit();
	}
			
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Add Holidays</H1>
<FORM id="addholiday" name="addholiday" action="store.asp" Method = "post">

<TABLE WIDTH="280" BORDER=2 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT: 50px"><!-- header row -->
<TBODY>
 <tr>
	<td align=left valign=top>
		<TABLE border="0" cellpadding="0" cellspacing="0" bordercolor=Gray Style = "MARGIN-LEFT: 8px">
		<tr><td> 
			<!-- #include file="script/calendar.asp" -->
			
		 </td></tr>
		 
		<tr Style = "MARGIN-LEFT: 8px"><td class= label Style = "FONT-WEIGHT: normal">&nbsp;&nbsp;Duration Of Holiday
		<SELECT name=noofdays STYLE="FONT-SIZE: 15px ;Width = 100px ">
			<%
			for i = 1 to 31
			%>	
			<OPTION VALUE= "<%= i %>"> <%= i %>
			<%
			next
			%>
					
		</SELECT></td>
		</tr>
		<tr><td align= left vAlign=center><br>
		<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif);background-position=center"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
		</TABLE><br>
	</TD></TR></TBODY></TABLE></FORM>
</BODY>
</HTML>
