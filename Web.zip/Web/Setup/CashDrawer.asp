<%@ Language=VBScript %>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="link/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
		
	function submitForm() {
		document.cashdrawer.submit();
	}			
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Cash Drawer</H1>
<FORM id="cashdrawer" name="cashdrawer" action="Hardware.asp" Method = "post">
<CENTER>
<TABLE WIDTH="380" BORDER=2 CELLSPACING=0 CELLPADDING=0 ><!-- header row -->
<TBODY>
 <tr>
	<td align=left valign=top>
	<TABLE border="0" cellpadding="0" cellspacing="0">
	<tr><td> 
		<TABLE width = 390px border="0" cellpadding="3" cellspacing="0" Style = "MARGIN-LEFT: 5px">
		<tr height = 40 ><td></td><td class = "label" Style="WIDTH=90">Cash Drawer 1<br></td></tr>
		<tr>
		<td><Input type=checkbox name=solenoid1 Checked>Solenoid</td>
		<td><Input type=checkbox name=serial1 Checked>Serial</td>
		<td align= right  ><Input type=radio name=type1 value="epson">Epson</td>
		<td align=left ><Input type=radio name=type1 value="star">Star</td>
		</tr>
		<tr>
		<td class = "label" Style = "font-weight=normal">Baud Rate</td>
		<td >
			<SELECT name= brate1 STYLE="Height = 24px;FONT-SIZE: 15px ;Width =60px ">
				<Option  Selected  Value = 1200>1200</option>
				<Option  Value = 1800>1800</option>
				<Option  Value = 2400>2400</option>
				<Option  Value = 4800>4800</option>
				<Option  Value = 7200>7200</option>
				<Option  Value = 9600>9600</option>
				<Option  Value = 14400>14400</option>
				<Option  Value = 19200>19200</option>
				<Option  Value = 38400>38400</option>												
				<Option  Value = 57600>57600</option>												
				<Option  Value = 115200>115200</option>																								
				</SELECT> 
		</td>
		<td align = right class = "label" Style = "font-weight=normal">Text</td>
		<td ><input class = text maxlength="2" name="txttext1" Style = "Width = 80px" ></td> 
		</tr>
		</tr>
			<td valign = bottom class = "label" Style = "font-weight=normal">Port</td>
			<td></td>
			<td align = right class = "label" Style = "font-weight=normal">Ascii</td>
			<td><input class = text maxlength="2" name="asciitext1" Style = "Width = 80px" ></td> 
		</tr>
		<tr height=10px>
		<td ><INPUT id=portno1 name=portno1 type=radio  Value = "1" CHECKED >LPT 1
		<INPUT id=portno1 name=portno1 type=radio  Value = "2" >LPT 2
		<INPUT id=portno1 name=portno1 type=radio  Value = "3" >LPT 3
		<INPUT id=portno1 name=portno1 type=radio  Value = "4" >USB
		</td>
		</tr>
		<tr height=10px>
		<td> <INPUT id=portno1 name=portno1 type=radio  Value = "1" >COM 1
		<INPUT id=portno1 name=portno1 type=radio  Value = "2" >COM 2 
		<INPUT id=portno1 name=portno1 type=radio  Value = "3" >COM 3
		<INPUT id=portno1 name=portno1 type=radio  Value = "3" >COM 4
		</td>
		</tr>
		<tr height = 40><td></td><td class = "label">Cash Drawer 2<br></td></tr>
		<tr>
		<td><Input type=checkbox name=solenoid2 Checked>Solenoid</td>
		<td><Input type=checkbox name=serial2 Checked>Serial</td>
		<td><Input type=radio name=type2 value="epson">Epson</td>
		<td><Input type=radio name=type2 value="star">Star</td>
		</tr>
		<tr>
		<td  class = "label" Style = "font-weight=normal" >Baud Rate</td>
		<td >
			<SELECT name= brate2 STYLE="Height = 24px;FONT-SIZE: 15px ;Width = 60px ">
				<Option  Selected  Value = 1200>1200</option>
				<Option  Value = 1800>1800</option>
				<Option  Value = 2400>2400</option>
				<Option  Value = 4800>4800</option>
				<Option  Value = 7200>7200</option>
				<Option  Value = 9600>9600</option>
				<Option  Value = 14400>14400</option>
				<Option  Value = 19200>19200</option>
				<Option  Value = 38400>38400</option>												
				<Option  Value = 57600>57600</option>												
				<Option  Value = 115200>115200</option>																								
				</SELECT> 
		</td>
		<td align = right class = "label" Style = "font-weight=normal">Text</td>
		<td ><input class = text maxlength="2" name="txttext2" Style = "Width = 80px" ></td> 
		</tr>
		<tr>
			<td valign = bottom class = "label" Style = "font-weight=normal">Port</td>
			<td></td>
			<td align = right class = "label" Style = "font-weight=normal">Ascii</td>
			<td><input class = text maxlength="2" name="asciitext2" Style = "Width = 80px" ></td> 
		</tr>
		<tr>
		<td  ><INPUT id=portno2 name=portno2 type=radio  Value = "1" CHECKED>LPT 1</td>
		<td  ><INPUT id=portno2 name=portno2 type=radio  Value = "2" >LPT 2</td> 
		<td  ><INPUT id=portno2 name=portno2 type=radio  Value = "3" >LPT 3</td>
		<td  ><INPUT id=portno2 name=portno2 type=radio  Value = "4" >USB</td>
		</tr>
		<tr>
		<td valign=top><INPUT id=portno2 name=portno2 type=radio  Value = "1"  >COM 1</td>
		<td valign=top><INPUT id=portno2 name=portno2 type=radio  Value = "2" >COM 2</td> 
		<td valign=top><INPUT id=portno2 name=portno2 type=radio  Value = "3">COM 3</td>
		<td valign=top><INPUT id=portno2 name=portno2 type=radio  Value = "3" >COM 4</td>
		</tr>
	</table><br>
	<INPUT class = click name=OK type=button value="OK" style="HEIGHT: 24px; MARGIN-left= 310px; WIDTH: 62px" onClick="submitForm()">
	<br></td></tr></table>
	</td><tr></Table>
</CENTER>	
</FORM>	
</BODY>
</HTML>

