<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	
	dim descriptor
	dim order: order = 1
	
	for each descriptor in request.form("descriptor")
		dim name
		dim color
		dim icon
		dim del
		dim groupid
		dim preview
		dim quantity

		name = request.form("desc_name_" & descriptor)
		color = request.form("desc_color_" & descriptor)
		icon = request.form("desc_icon_" & descriptor)
		del = request.form("desc_delete_" & descriptor)
		preview = request.form("desc_preview_" & descriptor)
		quantity = request.form("desc_quantity_" & descriptor)
		groupid = request.form("group_id")
		
		if preview <> "" then
			preview = 1
		else
			preview = 0
		end if
		
		if left(descriptor, 3) = "new" then

			query = " insert into descriptor (descriptorgroupid, name, color, icon, displayorder, preview, maxquantity) "
			query = query & " values (" & dbstr(groupid) & ", '" & dbstr(name) & "', '" & dbstr(color) & "', '" & dbstr(icon) & "', " & dbstr(order) & ", " & dbstr(preview) & ", " & dbstr(quantity) & ")"

		elseif del <> "" then
			query = "delete from descriptor where descriptorid = " & descriptor
		else
		
			query = "update descriptor set name = '" & dbstr(name) & "',"
			query = query & " color = '" & dbstr(color) & "',"
			query = query & " icon = '" & dbstr(icon) & "',"
			query = query & " displayorder = '" & dbstr(order) & "',"
			query = query & " preview = " & dbstr(preview) & ","
			query = query & " maxquantity = " & dbstr(quantity)
			
			query = query & " where descriptorid = " & descriptor
		end if

		qryexecute query
		order = order + 1
	next
%>


<HTML>
<HEAD>
<script type="text/javascript" src="/external/jquery-1.6.4.js"></script>
<script type="text/javascript" src="/external/jquery.tmpl.js"></script>
<!-- #include virtual="/include/ui.inc" -->




<TITLE></TITLE>


<SCRIPT type="text/javascript">
	var counter = 1;
	
	$(function() {
		
		$("#desc_tmpl").template("desc");
		
		$("#descriptor_list").sortable({
			placeholder: "ui-state-highlight"
		});
		
		$("#sortable").disableSelection();
		
		$("#group_id").bind("change", function() {
			loadDescriptorGroup($("#group_id").val());
		});
		
		$("#save").bind("click", function() {
			$("#descriptors").submit();
		});
		
		$("#add").bind("click", function() {
			$.tmpl("desc", {id: "new" + counter++, name: "", color: "ffffff", quantity: 1}).appendTo("#descriptor_list");
		});

		
		$("#import_text").bind("click", function() {
			
			var text = $("#import_text_area").val();
			var p = text.split("\n");
			for(i in p) {
				
				$.tmpl("desc", {id: "new" + counter++, name: p[i], color: "ffffff", quantity: 1}).appendTo("#descriptor_list");
			}
			
		});
	});

	function loadDescriptorGroup(id) {
		$.getJSON("/json/invoicing.asp",
		{group: "descriptor", id: id},
		function(data) {
			$("#descriptor_list").empty();
			$.tmpl("desc", data.items).appendTo("#descriptor_list");
		});
	}

	
</SCRIPT>

<SCRIPT id="desc_tmpl" type="text/x-jquery-tmpl">
	<li>
	<div class="desc">
	
		<input type="hidden" name="descriptor" value="${id}" />
		
		<label for="desc_name">Name</label>
		<input id="desc_name" name="desc_name_${id}" value="${name}" />
		
		<label for="desc_color">Color</label>
		<input id="desc_color" name="desc_color_${id}" class="color" value="${color}" />
		
		<label for="desc_icon">Icon</label>
		<input id="desc_icon" name="desc_icon_${id}" value="${icon}" />

		<label for="desc_preview">Preview</label>
		<input type="checkbox" id="desc_preview" name="desc_preview_${id}" value="1" {{if preview}}checked{{/if}} />

		<label for="desc_quantity">Quantity</label>
		<input id="desc_quantity" name="desc_quantity_${id}" value="${quantity}" />

		<label for="desc_delete">Delete</label>
		<input type="checkbox" id="desc_delete" name="desc_delete_${id}" value="1" />

	</div>
	</li>
</SCRIPT>

<STYLE type="text/css">

#descriptor_list {
	padding:0; 
	margin:0;
	
}

#descriptor_list li {
	list-style-type: none;
	
}

</STYLE>

</HEAD>

<BODY topmargin=0 leftmargin=0>

<H1>Descriptors</H1>

<form name="descriptors" id="descriptors" action="descriptors.asp?useraction=save" method="post">


<select id="group_id" name="group_id">
	<option value=""></option>
<%
	query = " select descriptorgroupid, name from descriptorgroup "
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
%>

	<option value="<%=rs("descriptorgroupid")%>"><%=server.htmlencode(rs("name"))%></option>

<%
		rs.movenext
	wend
	
	set rs = nothing
%>

</select>

<button id="add">add</button>
<button id="save">save</button>

<textarea id="import_text_area"></textarea>
<button id="import_text">import</button>



<ul id="descriptor_list"></ul>

</form>

</BODY>
</HTML>
