<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
    dim query, rs

	if trim(Request.QueryString("useraction")) = "save" then
	    query = "update SMSAutoHandle set handle = " & Request.QueryString("opt1") & " where id = 1"
	    qryexecute query

	    query = "update SMSAutoHandle set handle = " & Request.QueryString("opt2") & " where id = 2"
	    qryexecute query

	    query = "update SMSAutoHandle set handle = " & Request.QueryString("opt3") & " where id = 3"
	    qryexecute query

	    query = "update SMSAutoHandle set handle = " & Request.QueryString("opt4") & " where id = 4"
	    qryexecute query

	    query = "update SMSAutoHandle set handle = " & Request.QueryString("opt5") & " where id = 5"
	    qryexecute query

	    query = "update SMSAutoHandle set handle = " & Request.QueryString("opt6") & " where id = 6"
	    qryexecute query
	end if
%>

<HTML>
<HEAD>
<TITLE>Message Forwarding Setup</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
<link href="../style/overlay.css" rel="stylesheet" type="text/css">
</HEAD>
<script type="text/javascript">

	function exit() {
		document.smsAutoHandledList.action = "/setup/smsMenu.asp";
		document.smsAutoHandledList.submit();
	}

	function save() {
        var action = "?useraction=save&opt1=" + $("#handlingChk_1").val() +
            "&opt2=" + $("#handlingChk_2").val() +
            "&opt3=" + $("#handlingChk_3").val() +
            "&opt4=" + $("#handlingChk_4").val() +
            "&opt5=" + $("#handlingChk_5").val() +
            "&opt6=" + $("#handlingChk_6").val();
        document.smsAutoHandledList.action = action;
        document.smsAutoHandledList.submit();
	}


</script>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>SMS Auto-Handled Messages</H1>
<BR/><BR/>

<FORM name="smsAutoHandledList" ID="smsAutoHandledList" METHOD=POST  style="margin:0;padding:0" onsubmit="return false;">

<DIV style="overflow:scroll; height: 590px">
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="save()">Save</BUTTON>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>
<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="5" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH>Word(s)</TH>
		<TH>Matching*</TH>
		<TH>Handling</TH>
	</TR>
	<%
        query = "select id, handle from SMSAutoHandle order by id"
        set rs = getdisconnectedrecordset(query)

		while not(rs.eof or rs.bof)
	%>
	<TR >
	    <td>
	        <% if rs("id") = 1 then %>
            Join<br /><div style="font-size: 12px"><i>Customer option 'Opt in to Marketing Texts' is enabled.</i></div>
        </td>
	    <td>
	        Contains
            <% elseif rs("id") = 2 then %>
            Start<br /><div style="font-size: 12px"><i>Customer is removed from list of customers not to send any text messages to.</i></div>
        </td>
	    <td>
	        Equals
            <% elseif rs("id") = 3 then %>
            Quit, Stop, Stopall, Unsubscribe, Cancel, End<br /><div style="font-size: 12px"><i>Customer is added to list of customers not to send any messages to. Cannot be ignored.</i></div>
        </td>
	    <td>
	        Equals
            <% elseif rs("id") = 4 then %>
            Pick up, Pick-up<br /><div style="font-size: 12px"><i>Customer is added as a stop on next route they are on.</i></div>
        </td>
	    <td>
	        Contains
            <% elseif rs("id") = 5 then %>
            Arrived<br /><div style="font-size: 12px"><i>SMS notification is sent to employees set up to receive arrived notifications.<br />Is always treated as unread so any employee working will see it in CBS.</i></div>
        </td>
	    <td>
	        Contains
            <% elseif rs("id") = 6 then %>
            Skip<br /><div style="font-size: 12px"><i>Customer is removed from next manifest for their route.</i></div>
        </td>
	    <td>
	        Contains
	    <% end if %>
	    </td>
        <td>
            <select id="handlingChk_<%= rs("id")%>" required>
                <% if rs("id") <> 5 then %>
                <option value="1" <% if rs("handle") = 1 then %>selected<% end if%>>Auto Handled</option>
                <% end if %>
                <option value="2" <% if rs("handle") = 2 then %>selected<% end if%>>Auto Handled But Unread</option>
                <% if rs("id") <> 3 then %>
                <option value="3" <% if rs("handle") = 3 then %>selected<% end if%>>Not Auto Handled</option>
                <% end if %>
            </select>
        		<!--Input type=Radio name=handlingChk_<%= rs("id")%> value="1" id="hca_<%= rs("id")%>"
        		    <% if rs("id") = 5 then %>
        		    style="visibility:hidden"
        		    <% end if %>
        			<% if rs("handle") = 1 then %>
        				CHECKED
        			<% end if %>>
        			<label for="hca_<%= rs("id")%>"
                        <% if rs("id") = 5 then %>
                        style="visibility:hidden"
                        <% end if %>>Auto Handled</label>
        		<Input type=Radio name=handlingChk_<%= rs("id")%> value="2" id="hcau_<%= rs("id")%>"
        			<% if rs("handle") = 2 then %>
        				CHECKED
        			<% end if %>>
        			<label for="hcau_<%= rs("id")%>">Auto Handled But Unread</label>
        	    <% if rs("id") <> 3 then %>
        		<Input type=Radio name=handlingChk_<%= rs("id")%> value="3" id="hcna_<%= rs("id")%>"
        			<% if rs("handle") = 3 then %>
        				CHECKED
        			<% end if %>>
        			<label for="hcna_<%= rs("id")%>">Not Auto Handled</label>
        		<% end if %>
        		-->
        </td>
	</TR>
	<%
		rs.movenext
		wend
		set rs = nothing
	%>
</TABLE>

<br />
* All matching ignores case.
</DIV>
</FORM>
</BODY>
</HTML>

