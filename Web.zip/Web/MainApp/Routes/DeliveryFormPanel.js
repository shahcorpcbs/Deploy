
DeliveryFormPanel = function(config) {
	Ext.apply(this, config)
	
	
    this.formReader = new Ext.data.JsonReader(
			{
	            root: 'rows',
	            totalProperty: 'recordcount',
	            id: 'id'
	        },
	        ['id', 'customersequencenumber',  'deliveryaddress', 'deliveryphone', 'deliverynotes',
			'delivermon', 'delivertue', 'deliverwed', 'deliverthu', 'deliverfri', 'deliversat', 'deliversun']
        );
		
    DeliveryFormPanel.superclass.constructor.call(this, {

        url:'actions.asp?a=saveDelivery',
        reader : this.formReader,
		border: false,
		frame: true,
		bodyStyle:'padding:5px 5px 0',
		labelAlign: 'top',
        buttons: [
		{
            text: 'Remove',
			handler: function(){alert('Not implemented.');}
        },
		{
            text: 'Save',
			handler: this.saveDeliveryForm,
			scope: this
        }
		],
        items: [
		{
			xtype:'hidden',
            name: 'id'
        },
		{
			xtype:'hidden',
            name: 'customersequencenumber'
        },
		new CBS.fields.Customer({
			fieldLabel: 'Customer',
			anchor:'80%'  
		}),

		{
            xtype: 'textarea',
            fieldLabel: 'Address',
            name: 'deliveryaddress',
            height:65,
			width: 300
        },
		{
            xtype: 'textfield',
            fieldLabel: 'Phone',
            name: 'deliveryphone'
        },
		{
			xtype: 'tabpanel',
			plain:true,
			activeTab: 0,
			anchor:'80%',
			border: true,
			defaults:{autoHeight:true, bodyStyle:'padding:5px'},
			items: [
			{
				title: 'Notes',
				layout: 'form',
				items: {
					xtype:'htmleditor',
					id:'note',
					name: 'deliverynotes',
					hideLabel: true
				}
			},
			{
					title: 'Delivery Days',
					layout: 'form',
					items: [
	                    new Ext.form.ComboBox({
	                        fieldLabel: 'Sunday',
	                        hiddenName:'deliversun',
							store: deliveryOptionsStore,
	                        valueField:'value',
	                        displayField:'label',
	                        mode: 'local',
	                        triggerAction: 'all',
							editable: false
	                    }),
	                    new Ext.form.ComboBox({
	                        fieldLabel: 'Monday',
	                        hiddenName:'delivermon',
							store: deliveryOptionsStore,
	                        valueField:'value',
	                        displayField:'label',
	                        mode: 'local',
	                        triggerAction: 'all',
							editable: false
	                    }),
	                    new Ext.form.ComboBox({
	                        fieldLabel: 'Tuesday',
	                        hiddenName:'delivertue',
							store: deliveryOptionsStore,
	                        valueField:'value',
	                        displayField:'label',
	                        mode: 'local',
	                        triggerAction: 'all',
							editable: false
	                    }),
	                    new Ext.form.ComboBox({
	                        fieldLabel: 'Wednesday',
	                        hiddenName:'deliverwed',
							store: deliveryOptionsStore,
	                        valueField:'value',
	                        displayField:'label',
	                        mode: 'local',
	                        triggerAction: 'all',
							editable: false
	                    }),
	                    new Ext.form.ComboBox({
	                        fieldLabel: 'Thursday',
	                        hiddenName:'deliverthu',
							store: deliveryOptionsStore,
	                        valueField:'value',
	                        displayField:'label',
	                        mode: 'local',
	                        triggerAction: 'all',
							editable: false
	                    }),
	                    new Ext.form.ComboBox({
	                        fieldLabel: 'Friday',
	                        hiddenName:'deliverfri',
							store: deliveryOptionsStore,
	                        valueField:'value',
	                        displayField:'label',
	                        mode: 'local',
	                        triggerAction: 'all',
							editable: false
	                    }),
	                    new Ext.form.ComboBox({
	                        fieldLabel: 'Saturday',
	                        hiddenName:'deliversat',
							store: deliveryOptionsStore,
	                        valueField:'value',
	                        displayField:'label',
	                        mode: 'local',
	                        triggerAction: 'all',
							editable: false
	                    })
					]
				}
				]
			}
		]
    });
}

Ext.extend(DeliveryFormPanel, Ext.FormPanel, {
    loadDeliveryForm : function(deliveryID) {
        this.load({url:'actions.asp?a=getDelivery&id=' + deliveryID, waitMsg:'Loading'});
    },
	saveDeliveryForm : function() {
		var form = this.getForm();

		if(form.isValid()) {
			form.submit({
				scope: this,
				waitMsg: 'Saving',
				//params: {'deliveryID' : this.deliveryID},
				failure: function(frm, act) {
					Ext.MessageBox.alert('Saving', 'Error saving form.');
				},
				success: function(frm, act) {
					if(act.result.success != 0)
						this.destroy();
					else
						Ext.MessageBox.alert('Saving', act.result.answer)
				}
			});
		}
		else
			Ext.MessageBox.alert('Saving', 'Form not complete.')
	},
	closeDeliveryForm : function() {
		this.destroy();
	}
	
	
});