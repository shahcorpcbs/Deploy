<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Routes</title>
	
	<link rel="stylesheet" type="text/css" href="../../external/ext/resources/css/ext-all.css" />
	
	<script type="text/javascript" src="/external/ext/adapter/ext/ext-base.js"></script>
	
	<script type="text/javascript" src="/external/ext/ext-all-debug.js"></script>
	
	<script type="text/javascript" src="../CBS/CustomerField.js"></script>
	
	<script type="text/javascript" src="DeliveryFormPanel.js"></script>
	<script type="text/javascript" src="routes.js"></script>
	
	<link rel="stylesheet" type="text/css" href="../CBS/CustomerField.css" />
</head>
<body>

<div id="header"></div>

</body>
</html>
