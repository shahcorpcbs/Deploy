
Ext.onReady(function(){

    Ext.QuickTips.init();

	var treeLoader = new Ext.tree.TreeLoader({
            dataUrl:'actions.asp?a=getRouteNode'
        });

	
    var tree = new Ext.tree.TreePanel({
		region:'west',
        autoScroll:true,
        animate:true,
        enableDD:true,
        containerScroll: true, 
        loader: treeLoader,
		width: 350,
		split: true,
        tbar: [{
            text: 'New Route',
			handler: function(){alert('Not implemented.');}
        }]
    });

    var root = new Ext.tree.AsyncTreeNode({
        text: 'Routes',
        draggable:false,
        id:'R'
    });

	tree.on('nodedragover', function(obj) {
		return obj.data.node.attributes.cls != 'route' && obj.target.attributes.cls == 'delivery';
	});

	
	var deliveryOptions = [
        ['0', '--'],
        ['1', 'Drop Off'],
        ['2', 'Pick Up'],
        ['3', 'Always Stop']
	]
	
    deliveryOptionsStore = new Ext.data.SimpleStore({
        fields: ['value', 'label'],
        data : deliveryOptions
    })
	
    

    var form = new DeliveryFormPanel();
	
	
	
	
	
	
	
	tree.on('click', function(node, e) {
		form.loadDeliveryForm(node.attributes.id);
	});
	
	
	
	
    tree.setRootNode(root);
	root.expand();
	
	
    var viewport = new Ext.Viewport({
        layout:'border',
		items: [tree, { region:'center', items: form }]
    });


});

