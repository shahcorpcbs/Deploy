<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../../include/QueryDatabase.asp"-->
<!--#include file="../../include/json.asp"-->

<%
	dim query, rs
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if
	
	select case request.querystring("a")
	case "getRouteNode"
		response.write getRouteNode(request.form("node"))
	case "getDelivery"
		response.write getDelivery(request.querystring("id"))
	end select
	
	
	function getDelivery(id)
		dim query, rs
		
		query = " select * from customerdelivery where id = " & right(id, len(id) - 1)
		
		set rs = getdisconnectedrecordset(query)
		
		getDelivery = rsToJSON(rs, limit, start)
		
		set rs = nothing
	end function
	
	function getRouteNode(node)
		if len(node) <= 1 then
			query = " select 'R' + cast(routeNumber as varchar) as [id], name as [text], 'route' as [cls] from route "
			query = query & " where routenumber > 0 "
		elseif left(node, 1) = "R" then
			query = " select 'D' + cast(customerdelivery.id as varchar) as [id], customer.customername as [text], 'delivery' as [cls], 'true' as [leaf] "
			query = query & " from customerdelivery inner join customer on customerdelivery.customersequencenumber = customer.customersequencenumber "
			query = query & " where customerdelivery.routeid = " & right(node, len(node) - 1)
		elseif left(node, 1) = "D" then
			query = " select 'D' + cast(customerdelivery.id as varchar) as [id], customer.customername as [text], 'delivery' as [cls] "
			query = query & " from customerdelivery inner join customer on customerdelivery.customersequencenumber = customer.customersequencenumber "
			query = query & " where customerdelivery.parentdeliveryid = " & right(node, len(node) - 1)
		end if
		
		set rs = getdisconnectedrecordset(query)

		getRouteNode = rsToJSONArray(rs)
	
		set rs = nothing
	
	end function
%>