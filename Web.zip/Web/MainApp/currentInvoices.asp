<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!-- #include file="../include/EmployeeSecurity.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	'******************************************************************************
	'Name   : CurrentInvoices.asp
    '==============================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------------
    ' 09-Sep-2003	 Johnston		Increased font size in select table
    '******************************************************************************


	dim actionString
	dim l_invoicenumber
	dim l_customerseq
	dim l_multiplePickup
	dim l_target
	dim l_sortorder
	
	actionString = Request.QueryString("userAction")
	l_target = Request.QueryString("targetpage")	
	
	l_invoicenumber = Request.QueryString("Invoicenumber")
	
	'response.write l_invoicenumber
	
	if (Request.QueryString("searchtype")="customer" ) then
	
		l_customerseq = session("customersequencenumber")
	else
		l_customerseq= ""
	end if
	
	dim l_ticketstatus
		
	if trim(actionstring) = "Current" then
		l_ticketstatus = "'AC'"
		l_sortorder = ""
	else
		l_ticketstatus = "'FI','VO'"
		l_sortorder = " desc"
	end if
	
	l_multiplePickup = 0
	
	getInvoiceList()
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Current Invoices</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	var previousElement=null;
	var l_ticketnumber = null;
	var l_multiplePickup = 0;
	
	function trackInvoice() {
		document.currentInvoices.action = "garmentTrack.asp?Ticketnumber=" + l_ticketnumber;
		document.currentInvoices.submit();
	}
	
	function viewInvoice() {
		var tPage;
		if(document.currentInvoices.originalPage.value=="Current"){
			tPage = document.currentInvoices.targetPage.value;
			if (tPage == "invoicesearch.asp") {
				document.currentInvoices.action = "Detailedinvoice.asp?userAction=edit&Ticketnumber=" +  l_ticketnumber + "&multiplePickup=" + l_multiplePickup + "&originPage=invoicesearch";				
			}else{
				document.currentInvoices.action = "Detailedinvoice.asp?userAction=edit&Ticketnumber=" +  l_ticketnumber + "&multiplePickup=" + l_multiplePickup + "&originPage=customerfunctions";
			}	
		}else{
		
			document.currentInvoices.action = "finishedInvoices.asp?userAction=edit&Ticketnumber=" +  l_ticketnumber;
		}
		document.currentInvoices.submit();
	}
	
	function selectRow(element) {
		var childEl;
		var tempvalue;
		if (previousElement !=null){
			previousElement.style.background="white";
		}
		childEl = element.children[0];
		var rowChildNodes = childEl.children
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if(childEl.tagName == "INPUT") {
				childEl.checked=true;
				tempvalue = childEl.value;
				l_ticketnumber = tempvalue.substring(0, tempvalue.indexOf(";"));
				l_multiplePickup = tempvalue.substring(tempvalue.indexOf(";")+ 1);
				document.currentInvoices.trackDetail.disabled = false
				document.currentInvoices.view.disabled  = false
				break;
			}
		}
		previousElement =element;
		element.style.background="#DBF2F4";
		 
	}
		
	function cancelForm() {
		document.currentInvoices.action = document.currentInvoices.targetPage.value;
		document.currentInvoices.submit();
	}
	function captureKeyUpEvent(element){
		
	  	if (event.keyCode == 13){
	  		event.returnValue = true;	
			viewInvoice();
		}
	}
						
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<%
	dim formTitle
	if actionString="Current" then
		formTitle ="Current Invoices"
	else
		formTitle ="Finished Invoices"	
	end if	
%>
<B class="pageHeading"><%= formTitle %></B>
<FORM id="currentInvoices" name="currentInvoices" action="" method="post">
	<INPUT type="hidden" name="originalPage" value="<%= actionString %>">
	<INPUT type="hidden" name="targetPage" value="<%=l_target %>">
	
<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=0>
	<!-- header row -->
	<tr>
		
		<td align="center">
			<%if rstInvoice.recordcount <= 0 then   %>
				<Font color= red><B>
				<%Response.write "No Matching Records found" %>
				</B><Font>
				<% End If %>
				
			<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5>
				<!-- heading -->
				<tr>
					<th width=30px></th>
					<th width =90px align=left class="label">Invoice Number</th>
					<th width =90px align=left class="label">Customer Name</th>
					<th width =90px align=left class="label">Date In</th>
					<th width =90px align=left class="label">Amount</th>
					<th width =190px align=left class="label">Department</th>
					<th width =90px align=left class="label">Rack Number</th>
					<th width =90px align=left class="label">Last Scan</th>
					<th width =210px align=left class="label">Date/Time</th>
					<th width=16px></th>
				</tr>
			</table>
		</td>
	</tr>
	<!-- list -->
	<tr>
		<td align="center">
		
			<DIV STYLE="overflow-y:auto;height:500px; overflow-x:auto; width=100%">
					<TABLE WIDTH="100%" style="border-color:#2F4F4F;border-style:solid;background-color:white;" BORDER=1 CELLSPACING=0 onKeyPress="captureKeyUpEvent(this)">
						<tr rowspan =5>
							<td>
								
								<TABLE WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=3>
								<!-- to be removed while coding -->	
									<%if rstInvoice.recordcount > 0 then 
										if rstInvoice("multiplepickup") = true then
											l_multiplePickup = 1
										else
											l_multiplePickup = 0
										end if
										
										while not rstInvoice.eof 
									%>	
										
										<!-- Following lines modified by J.Johnston, 9Sep03-->
										<!-- Original font size was 12px-->
										<tr onClick="selectRow(this)">
										<td width=25px><input type="radio" name="select" id="select" style="height=28;Width=28px;" value ="<%=rstInvoice("Ticketnumber") & ";" & l_multiplePickup%>"></td>
										<td width = 80px  STYLE="FONT-SIZE: 18px;"><%=rstInvoice("invoicenumber") %></td>
										<%if rstInvoice("ticket_multipickup") = true then%>
											<td width = 100px  STYLE="FONT-SIZE: 18px;"><%=rstInvoice("multiPickupCustomerName")%>&nbsp<%=rstInvoice("multiPickupLocation") %></td>
										<%else%>
											<td width = 100px  STYLE="FONT-SIZE: 18px;"><%=rstInvoice("Customername") %></td>
										<%end if%>										
										<td width = 70px  STYLE="FONT-SIZE: 18px;"><%=rstInvoice("datein") %></td>
										<td width = 80px  STYLE="FONT-SIZE: 18px;">
										<% if not isnull(rstInvoice("nettotal")) then%>
											<%=formatcurrency(rstInvoice("nettotal"), 2)%>
										<%	End if
										%>
										 </td>
										<td width = 190px  STYLE="FONT-SIZE: 18px;"><%=trim(rstInvoice("department")) %></td>
										<td width = 90px  STYLE="FONT-SIZE: 18px;"><%=trim(rstInvoice("racklocation"))%></td>
										<td width = 90px  STYLE="FONT-SIZE: 18px;"><%=rstInvoice("lastscannedLocation")%></td>
										<td width = 210px  STYLE="FONT-SIZE: 18px;"><%=rstInvoice("dateout") %></td>
										</tr>
										<!-- End modification by J.Johnston, 9Sep03-->
									<%	rstInvoice.movenext
										wend
										rstinvoice.close
										set rstinvoice = nothing
									
										end if
									%>	
									
									<tr height =50px><td></td></tr>
									<tr height=50px><td></td></tr>
									<tr height=50px><td></td></tr>
									<tr height=50px><td></td></tr>	
									<!-- till here -->	
								</table>
							</td>
						</tr>
				</table> <!-- table for border -->
			</div>
		</td>
	</tr>
	<!-- buttons -->
	<tr>
		<td align="center">
			<TABLE WIDTH="750px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
				<tr height=20px></tr>
				<tr>
					<td width=275px></td>
					<td align="center">
						<INPUT class=touch id=trackDetail name=trackDetail type=button value="" style="background-image:url(../images/search-data.gif)" disabled onClick="trackInvoice()"><br>Track Detail
					</td>
					<td width=30px></td>
					<td align="center">
						<INPUT class=touch id=view name=view type=button value="" style="background-image:url(../images/search.gif)" disabled onClick="viewInvoice()"><br>View
					</td>
					<td align="center">
						<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/cancel.gif)" onClick="cancelForm()">
					</td>
				</tr>
			</table>
		</td>
	<tr>
</table>
</form>
</BODY>
</HTML>
<%
	dim rstInvoice
	
	Function getInvoiceList()
	dim sqltxt
	
		if Trim(l_invoicenumber) <> "" and not isnull(l_invoicenumber) then
			sqltxt = "select t.ticketnumber, t.dateout, t.invoicenumber, convert(varchar, t.createddate, 101) as 'datein' , t.invoicetotal, t.nettotal" _
						& " , t.createddate , c.customername , c.multiplepickup, tc.multiplepickup as 'ticket_multipickup', tc.multiPickupCustomerName, tc.multiPickupLocation"_
						& " , dbo.pivotTicketDepartments(t.ticketnumber, ',') as 'department'" _
						& " , dbo.pivotTicketRackLocation(t.ticketnumber, ',') as 'racklocation' " _
						& ", I.trackLocation as 'lastScannedlocation'" _
						& ", t.lastmodifieddate " _
						& " from ticket t , customer c , TicketLocationtracking I, ticketcustomer tc" _
						& " where t.invoicenumber = " & dbcreateqrystring(l_invoicenumber) _
						& " and  ticketstatus in ("  & l_ticketstatus _
						& ") and t.customersequencenumber = c.customersequencenumber and t.onhold = 0 " _
						& " and t.ticketnumber = tc.ticketnumber " _
						& " and t.ticketnumber *= I.ticketnumber " _
						& "	and I.createddate = (select max(createddate)from  ticketlocationtracking " _
						& "	where t.ticketnumber = ticketnumber) order by t.CreatedDate " & l_sortorder 
						
		elseif l_customerseq <> "" then
			sqltxt = "select t.ticketnumber, t.dateout, t.invoicenumber, convert(varchar, t.createddate, 101) as 'datein' , t.invoicetotal, t.nettotal" _
						& " , t.createddate , c.customername , c.multiplepickup, tc.multiplepickup as 'ticket_multipickup', tc.multiPickupCustomerName, tc.multiPickupLocation"_
						& " , dbo.pivotTicketDepartments(t.ticketnumber, ',') as 'department'" _
						& " , dbo.pivotTicketRackLocation(t.ticketnumber, ',') as 'racklocation' " _
						& ", I.trackLocation as 'lastScannedlocation'" _
						& ", t.lastmodifieddate " _
						& " from ticket t , customer c , TicketLocationtracking I, ticketcustomer tc" _
						& " where t.customersequencenumber = " & l_customerseq  _
						& " and  ticketstatus in ("  & l_ticketstatus _
						& ") and t.customersequencenumber = c.customersequencenumber and t.onhold = 0 " _
						& " and t.ticketnumber = tc.ticketnumber " _
						& " and t.ticketnumber *= I.ticketnumber " _
						& "	and I.createddate = (select max(createddate)from  ticketlocationtracking " _
						& "	where t.ticketnumber = ticketnumber)  order by T.CreatedDate"  & l_sortorder
						
		else
			sqltxt = "select t.ticketnumber, t.dateout, t.invoicenumber, convert(varchar, t.createddate, 101) as 'datein' , t.invoicetotal, t.nettotal" _
						& " , t.createddate , c.customername , c.multiplepickup, tc.multiplepickup as 'ticket_multipickup', tc.multiPickupCustomerName, tc.multiPickupLocation"_
						& " , dbo.pivotTicketDepartments(t.ticketnumber, ',') as 'department'" _
						& " , dbo.pivotTicketRackLocation(t.ticketnumber, ',') as 'racklocation' " _
						& ", I.trackLocation as 'lastScannedlocation'" _
						& ", t.lastmodifieddate " _
						& " from ticket t , customer c , TicketLocationtracking I, ticketcustomer tc where " _
						& " ticketstatus in ("  & l_ticketstatus _
						& ") and t.customersequencenumber = c.customersequencenumber and t.onhold = 0 " _
						& " and t.ticketnumber = tc.ticketnumber " _
						& " and t.ticketnumber *= I.ticketnumber " _
						& "	and I.createddate = (select max(createddate)from  ticketlocationtracking " _
						& "	where t.ticketnumber = ticketnumber) order by T.createddate " & l_sortorder 
		end if
		
		'Response.Write sqltxt
		set rstinvoice = getdisconnectedrecordset(sqltxt)
		'Response.Write rstinvoice.recordcount
	end function
	
%>