<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!-- #include file="../include/security.asp" -->
<%
	dim query, rs
	dim heatseals
	dim n

	n = request.querystring("n")
	if n = "" then n = 0

	if n > 0 then
		query = " exec dbo.getNewHeatSeals " & n
		set rs = getdisconnectedrecordset(query)

		while not(rs.eof or rs.bof)
			if heatseals <> "" then heatseals = heatseals & ","
			heatseals = heatseals & """" & rs(0) & """"
			rs.movenext
		wend
	end if

	response.write "{""heat_seals"": [" & heatseals & "]}"
%>