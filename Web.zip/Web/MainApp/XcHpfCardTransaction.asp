<!-- #include file="../include/validateFunction.asp" -->
<!-- #include file="../include/systemsetting.asp" -->

<%
	Class XcHpfCardTransaction

        Private Property Get m_DeviceType
            m_DeviceType = "EMV"
        End Property

        Private Property Get m_Debug
            m_Debug = True
        End Property

        Private Property Get m_HpfUrl
            If m_Debug Then
                m_HpfUrl = "https://integrator.t3secure.net/hpf/hpf.aspx"
            Else
                m_HpfUrl = "https://online.t3secure.net/hpf/hpf.aspx"
            End If
        End Property

        Private Property Get m_GatewayUrl
            If m_Debug Then
                m_GatewayUrl = "https://test.t3secure.net/x-chargeweb.dll"
            Else
                m_GatewayUrl = "https://gw.t3secure.net/x-chargeweb.dll"
            End If
        End Property

        '-------------------------------------------
        ' request field getter functions
        '-------------------------------------------

        ' These are request header fields that are common to both HPF and DTG request
        Function getCommonRequestHeaderFields
            Dim terminalID

            Dim sql: sql = "SELECT creditCardDeviceID FROM dbo.StoreHardware WHERE hardwareType = 'CC' AND terminalID = " & Session("terminalID")
            Dim rs: Set rs = getDisconnectedRecordset(sql)
            
            If rs.RecordCount > 0 Then
                terminalID = rs("creditCardDeviceID")
            End If

            Dim fields: Set fields = Server.CreateObject("Scripting.Dictionary")

            fields("XWebID") = systemsetting("XWEB-XWEBID")
            fields("TerminalID") = terminalID
            fields("AuthKey") = systemsetting("XWEB-AUTHKEY")
            fields("Industry") = "RETAIL"

            Set getCommonRequestHeaderFields = fields
        End Function

        ' Request header fields specific to HPF requests
        Function getHpfRequestHeaderFields
            Dim fields: Set fields = getCommonRequestHeaderFields
            
            fields("SpecVersion") = "XWebSecure3.5"

            Set getHpfRequestHeaderFields = fields
        End Function

        ' Request header fields specific to DTG requests
        Function getDtgRequestHeaderFields
            Dim fields: Set fields = getCommonRequestHeaderFields

            fields("SpecVersion") = "XWeb3.5"
            fields("POSType") = "PC"
            fields("PinCapabilities") = "FALSE"
            fields("TrackCapabilities") = "NONE"
            
            Set getDtgRequestHeaderFields = fields
        End Function

        '-------------------------------------------
        ' request/response encode/decode functions
        '-------------------------------------------
		Function EncodeFields(fields)
			Dim i: i = 0
            Dim key

			EncodeFields = ""
			For Each key In fields.keys()
				If i > 0 Then
					EncodeFields = EncodeFields & "&"
				End If
				
				EncodeFields = EncodeFields & key & "=" & server.urlencode(fields(key))
			
				i = i + 1
			Next
		End Function
		
		Function UrlDecode(encoded)
			Dim parts, i
			Dim result

			result = replace(encoded, "+", " ")

			parts = split(result, "%")

			If isarray(parts) Then
				result = parts(0)
				For i = 0 To Ubound(parts) - 1
					result = result & Chr("&H" & Left(parts(i + 1), 2)) & Right(parts(i + 1), Len(parts(i + 1)) - 2)
				Next
			End If

			UrlDecode = result
		End Function
		
		
		Function DecodeResponse(response)
			Dim result
			Dim pairs, pair, parts
			
			Set result = Server.CreateObject("Scripting.Dictionary")
		
			pairs = split(response, "&")

			For Each pair In pairs
				parts = split(pair, "=")    
				result(UrlDecode(parts(0))) = UrlDecode(parts(1))
			Next
			
			set DecodeResponse = result
		End Function

        '-------------------------------------------
        ' HPF request functions
        '-------------------------------------------
		
        ' This method handles the shared functionality for all HPF requests
		Function BeginCardTransaction(requestFields)
			Dim result
			Dim request
			Dim responseFields
			Dim queryString

			queryString = EncodeFields(requestFields)

			Set request = Server.CreateObject("MSXML2.ServerXMLHTTP")
            request.open "GET", m_GatewayUrl & "?" & queryString, false
			request.send
				
			Set responseFields = DecodeResponse(request.responseText)

            Set result = New CardTransactionResults

            result.Success = False
            result.ResponseCode = responseFields("ResponseCode")
            result.ResponseDescription = responseFields("ResponseDescription")

            If result.ResponseCode = "100" Then
                result.Success = True
                result.OTK = responseFields("OTK")
                result.HpfUrl = m_HpfUrl & "?otk=" & result.OTK & "&AutoSubmit=ON"
            End If
    
		    Session("hpfUrl") = result.HpfUrl
	        Session("hpfOneTimeKey") = result.OTK            
		    Set BeginCardTransaction = result
		End Function
			
        ' Returns the HPF URL for credit sale transactions
		Function getCreditSaleUrl(Amount)
		    Dim fields
            Set fields = getHpfRequestHeaderFields

			fields("DuplicateMode") = "CHECKING_OFF"
			fields("TransactionType") = "CreditSaleTransaction"
			fields("Amount") = Amount
			fields("EnablePartialApprovals") = "TRUE"
			fields("ShowEMVReceipt") = "FALSE"
            fields("DeviceType") = m_DeviceType

		    Set getCreditSaleUrl = BeginCardTransaction(fields)
		End Function

        Function getCreditReturnUrl(Amount)
            Dim fields
            Set fields = getHpfRequestHeaderFields

            fields("DuplicateMode") = "CHECKING_OFF"
            fields("TransactionType") = "CreditReturnTransaction"
            fields("TransactionIDLocked") = "TRUE"
            fields("Amount") = Amount
    		fields("ShowEMVReceipt") = "FALSE"
            fields("DeviceType") = m_DeviceType

            Set getCreditReturnUrl = BeginCardTransaction(fields)
        End Function

        ' Returns the HPF URL for create alias transactions
		Function getCreateAliasUrl()
		    Dim fields
            Set fields = getHpfRequestHeaderFields		

			fields("TransactionType") = "AliasCreateTransaction"

			Set getCreateAliasUrl = BeginCardTransaction(fields)	
        End Function
					   	 
        ' Returns the results response for credit sale transactions  	   	   	
        Function getCreditSaleResultsResponse()
            Dim requestFields
            Dim queryString

            Set requestFields = getHpfRequestHeaderFields
            requestFields("ResponseMode") = "POLL"
            requestFields("OTK") = Session("hpfOneTimeKey")
            requestFields("ReceiptFormat") = "TEXT_AND_SIGNATURE"
            
            queryString = EncodeFields(requestFields)

            Dim resultsRequest: Set resultsRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")

            resultsRequest.open "GET", m_GatewayUrl & "?" & queryString, False
            resultsRequest.send

            Dim responseFields: Set responseFields = DecodeResponse(resultsRequest.responseText)

            Dim result: Set result = New CardTransactionResults

            result.Success = False
            result.ResponseCode = responseFields("ResponseCode")
            result.ResponseDescription = responseFields("ResponseDescription")

            If responseFields("ResponseCode") = "000" Then
                result.Success = True

        	    result.Amount = responseFields("Amount")
	            result.ApprovalCode = responseFields("ApprovalCode")
                result.CardType = responseFields("CardBrand")
		        result.CardNumber = responseFields("MaskedAcctNum")
		        result.CardExpDate = responseFields("ExpDate")
		        result.TransactionID = responseFields("TransactionID")
                result.FullReceiptData = formatReceiptData(responseFields("Receipt"))
            End If
    
            Set getCreditSaleResultsResponse = result
        End Function

			
        ' Returns the results response for create alias transactions
		Function getCreateAliasResultsResponse()
		    Dim fields		
			Set fields = getHpfRequestHeaderFields

			fields("ResponseMode") = "PERSIST_UNTIL_COMPLETE"
			fields("OTK") = Session("hpfOneTimeKey")
						
			Dim request
			Dim responseFields
			Dim queryString
			Dim result

			queryString = EncodeFields(fields)

			Set request = server.createobject("MSXML2.ServerXMLHTTP")
			request.open "GET", m_GatewayUrl & "?" & queryString, False
			request.send

			Set responseFields = DecodeResponse(request.responseText)

            Set result = New CardTransactionResults
	
			result.ResponseDescription = responseFields("ResponseDescription")	
			result.CardType =   responseFields("CardBrand")
			result.CardNumber = responseFields("MaskedAcctNum")
			result.CardExpDate = responseFields("ExpDate")
			result.Alias = responseFields("Alias")

			Set getCreateAliasResultsResponse = result
		End Function
	
        '-------------------------------------------
        ' DTG (Direct to gateway) request functions
        '-------------------------------------------
    
        Function processCardOnFileSaleTransaction(amount, alias, zipCode, customerPresent)
            Dim requestFields
            Dim queryString

            Set requestFields = getDtgRequestHeaderFields

            Dim customerPresentString
            If customerPresent = True Then
                customerPresentString = "TRUE"
            Else
                customerPresentString = "FALSE"
            End If
            
            requestFields("TransactionType") = "CreditSaleTransaction"
			requestFields("Amount") = amount
			requestFields("Alias") = alias
			requestFields("ZipCode") = zipCode
            requestFields("CustomerPresent") =  customerPresentString
            requestFields("CardPresent") =  "FALSE"
            requestFields("DuplicateMode") = "CHECKING_OFF"
            requestFields("ReceiptFormat") = "TEXT"

            queryString = EncodeFields(requestFields)

            Dim request: Set request = Server.CreateObject("MSXML2.ServerXMLHTTP")

            request.open "GET", m_GatewayUrl & "?" & queryString, False
            request.send

            Dim responseFields: Set responseFields = DecodeResponse(resultsRequest.responseText)

            Dim result: Set result = New CardTransactionResults

            result.Success = False
            result.ResponseCode = responseFields("ResponseCode")
            result.ResponseDescription = responseFields("ResponseDescription")

            If responseFields("ResponseCode") = "000" Then
                result.Success = True
                
        	    result.Amount = responseFields("Amount")
	            result.ApprovalCode = responseFields("ApprovalCode")
                result.CardType = responseFields("CardBrand")
		        result.CardNumber = responseFields("MaskedAcctNum")
		        result.CardExpDate = responseFields("ExpDate")
		        result.TransactionID = responseFields("TransactionID")
                result.FullReceiptData = formatReceiptData(responseFields("Receipt"))
            End If

            Set processCardOnFileSaleTransaction = result
        End Function

        ' Processes a single credit sale transaction for use in batch credit card processing
		Function processCreditBatchTransaction(Alias, Amount, Address, Zipcode)
            Set processCreditBatchTransaction = processCardOnFileSaleTransaction(amount, alias, zipCode, False)
		End Function		

        ' Updates the expiration on an on-file credit card
        Function updateAliasExpirationDate(alias, expirationDate)
            Dim fields
            Set fields = getDtgRequestHeaderFields
    
            fields("TransactionType") = "AliasUpdateTransaction"
            fields("Alias") = alias
            fields("ExpDate") = expirationDate

            Dim queryString
            Dim request
            Dim responseFields
   
            queryString = EncodeFields(fields)

            Set request = Server.CreateObject("MSXML2.ServerXMLHTTP")
            request.open "GET", m_GatewayUrl & "?" & queryString, False
			request.send

			Set responseFields = DecodeResponse(request.responseText)

            Dim result: Set result = New CardTransactionResults
            result.Success = False
            result.ResponseCode = responseFields("ResponseCode")
            result.ResponseDescription = responseFields("ResponseDescription")
            If result.ResponseCode = "005" Then
                result.Success = True
            End If

            Set updateAliasExpirationDate = result            
        End Function

        ' Voids a credit sale transaction
        Function voidTransaction(transactionID)
            Dim fields
            Set fields = getDtgRequestHeaderFields
    
            fields("TransactionType") = "CreditVoidTransaction"
            fields("TransactionID") = transactionID
            fields("ReceiptFormat") = "TEXT"

            Dim queryString
            Dim request
            Dim responseFields
    
            queryString = EncodeFields(fields)    

            Set request = Server.CreateObject("MSXML2.ServerXMLHTTP")
            request.open "GET", m_GatewayUrl & "?" & queryString, False
			request.send

			Set responseFields = DecodeResponse(request.responseText)

            Dim result
            Set result = New CardTransactionResults

            result.Success = False
            result.ResponseCode = responseFields("ResponseCode")
            result.ResponseDescription = responseFields("ResponseDescription")

            If result.ResponseCode = "000" Then
                result.Success = True
                result.Amount = (-1)*responseFields("Amount")
                result.TransactionID = responseFields("TransactionID")
                result.FullReceiptData = formatReceiptData(responseFields("Receipt"))
            End If
        
            Set voidTransaction = result
        End Function

        Private Function formatReceiptData(receiptData)
            formatReceiptData =  Replace(receiptData, Chr(10), "\par" & Chr(13) & Chr(10))
        End Function
			
	End Class
%>



