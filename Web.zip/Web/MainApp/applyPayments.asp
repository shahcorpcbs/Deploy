<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/miscSetUpObject.asp" -->	<!-- Added by J.Johnston, 6Jan2004 -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>

<%
	'***********************************************************************
	'Name   : Apply Payment
	'
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' ----------------------------------------------------------------------
    ' 06-Jan-2004	 Johnston		Modified for capturing check numbers
    ' 13-Jan-2004	 Johnston		Modified for credit card payments
	'***********************************************************************

	'COMMON variables
	dim isSubmitted
	dim l_storeid
	dim l_customerseq
	dim rstPayment
	dim l_error
	dim ObjMiscSetUp	'Added by J.Johnston, 6Jan2004
	dim checkCardNo		'Added by J.Johnston, 6Jan2004
	dim amountpaid		'Added by J.Johnston, 6Jan2004
	dim payType			'Added by J.Johnston, 7Jan2004
	dim cc_xcid
	dim cc_expiration
	dim cc_zip
	dim cc_receipt
   	dim ccProcessorDomainID
   	dim use_clearent
   	dim cc_url
   	dim cc_key
	dim promptToAddCC
	dim smsReceipt, emailReceipt

	dim trackCheckNum	'Added by J.Johnston, 6Jan2004

	dim enableXcharge	'Added by J.Johnston, 05Feb04

	dim cashDrawerCheck
    dim userIPAddress, printerIP, printerName

	cashDrawerCheck = getOptionOpenDrawer(session("storeid"), "Check")
	getCashDrawerFields()

	if not IsObject(Session("miscSetUp")) then
		initializeMiscSetup
	end if
	set ObjMiscSetUp = Session("miscSetUp")
	if not IsNull(ObjMiscSetUp.Item("CreditCardProcessorDomainID")) then
        ccProcessorDomainID = ObjMiscSetUp.Item("CreditCardProcessorDomainID")
    else
        ccProcessorDomainID = "0"
    end if
    promptToAddCC = ObjMiscSetUp.Item("promptToAddCC")

    determineProcessor


	isSubmitted = Request.QueryString("submitted")
	if isSubmitted then
	    if use_clearent then
	        addClearentCreditPayment
	    end if
		updateDatabase()
		if Request.form("cameFrom") = "cpi" then
		    Response.Redirect("customerpayment.asp?customerseq=" & l_customerseq)
		else
		    Response.Redirect("Customersearch.asp?userAction=applypayments")
	    end if
	end if

	l_storeid = Session("storeid")
	l_customerseq = trim(Request.QueryString("CustomerSeq"))
	if l_customerseq <> "" then
		session("accountCustomerSequenceNumber") = l_customerseq
	end if

	payType = Request.QueryString("type")	'Added by J.Johnston, 7Jan2004

	'Variables used for CHECK payments
	if payType = "Check" or payType = "Trade" then
		checkCardNo = Request.Form("txtCardNumber")	'Added by J.Johnston, 6Jan2004
		amountpaid = Request.QueryString("amountpaid")	'Added by J.Johnston, 6Jan2004
	end if


	getCustomerInfo()
	session("customerName") = l_custname
	Session("customerSequenceNumber") = l_customerseq

	getActivePaymentTypes()
	getReceiptOptions()

	'Following added by J.Johnston, 6Jan2004
	if Not IsObject(Session("miscSetUp")) then
		initializeMiscSetUp
	end if

	set ObjMiscSetUp = Session("miscSetUp")

	if ObjMiscSetUp.Item("captureCheckNumber") then
		trackCheckNum = "1"
	else
		trackCheckNum = "0"
	end if

	sub addClearentCreditPayment()
		dim amountPaid
		dim transactionID
		dim query
		dim clerk
		dim terminalId
		dim customerSeq
		dim rawAnswer
		dim addCCToFile, cardType, cardNumber, cardExp, token, tipAmt, paymentId

		amountPaid = Request.QueryString("amount")
		rawAnswer = Request.QueryString("rawAnswer")
		clerk = session("employeeid")
		terminalId = Session("terminalID")
		customerSeq = Session("customerSequenceNumber")
		addCCToFile = Request.QueryString("addCCToFile")
		tipAmt = 0
		if IsNumeric(Request.QueryString("tipAmt")) then
		    tipAmt = CDbl(Request.QueryString("tipAmt"))
		end if

		if len(trim(amountPaid)) > 0 then
			amountPaid = CDbl(amountPaid)
			transactionID = Request.QueryString("transactionid")

			query = "SET NOCOUNT ON; insert into cardpayment(terminalid, clerk, customersequencenumber, success, transactionid, amount, rawAnswer) "
            query = query & " values ( "
            query = query & terminalid & ", "
            query = query & clerk & ", "
            query = query & customerseq & ", "
            query = query & "1, "
            query = query & "'" & dbstr(transactionid) & "', "
            query = query & "'" & dbstr(amountPaid) & "', "
            query = query & "'" & dbstr(rawAnswer) & "'"
            query = query & " ); select scope_identity(); set nocount off"


		    dbstartTrans()
			paymentId = qryexecutewithtransandselect(query)
		    dbEndTrans()

			token = Request.QueryString("token")
			if (addCCToFile = "1") then
                cardType = Request.QueryString("cardType")
                cardNumber = Request.QueryString("cardNumber")
                cardExp = Request.QueryString("cardExp")

			    query = " update customer set "
                query = query & " creditcardnumber = '" & dbstr(token) & "', "
                query = query & " creditcardmaskednumber = '" & dbstr(cardNumber) & "', "
                query = query & " creditcardexpdate = '" & dbstr(cardExp) & "', "
                query = query & " creditcardtype = '" & dbstr(cardType) & "' "
                query = query & " where customersequencenumber = " & dbstr(customerseq)
                qryexecute query

		        dim oldToken
		        oldToken = Request.QueryString("oldToken")
		        if oldToken <> "" then
                    query = "insert into Unusedtokens (token, apiKey) values ('" & dbstr(oldToken) & "', '" & cc_key & "')"
                    qryexecute query
		        end if

            elseif token <> "" then
                query = "insert into Unusedtokens (token, apiKey) values ('" & dbstr(token) & "', '" & cc_key & "')"
		        qryexecute query
            end if

            if tipAmt > 0 then
                query = " insert into EmployeeTip(tipamt, cardpaymentid, added) " _
                     & " values ( " _
                     & dbstr(tipAmt) & ", " _
                     & paymentId & ", 1)"
                qryexecute query
            end if
		end if
	end sub

	function getOptionOpenDrawer(storeid, paymentMethod)
		dim query, rs

		query = " select donotopencashdrawer from storepaymenttype where paymenttypename = '" & paymentMethod & "'"
		query = query & " and storeid = " & storeid

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getOptionOpenDrawer = not rs("donotopencashdrawer")
		end if

	end function

    function determineProcessor()
        dim query, rs

        query = " select  Description, URL, API_Key from CreditCardProcessorDomain where CreditCardProcessorDomainID = " & ccProcessorDomainID

        set rs = getdisconnectedrecordset(query)

        if rs.recordcount > 0 then
        	if rs("Description") = "Clearent" then
        	    use_clearent = "1"
        	    cc_key = trim(rs("API_Key"))

                 query = " select API_Key from Terminal where terminalId = " & Session("terminalID")
                 set rs = getdisconnectedrecordset(query)
                 if rs("API_Key") <> "" then
 			        cc_key = trim(rs("API_Key"))
                 end if
                 cc_url = getClearentShortPath()
        	else
                use_clearent = "0"
                if rs("Description") = "XCharge" then
                    enableXcharge = "1"
                else
                    enableXcharge = "0"
                end if
            end if
        end if

    end function


    function getReceiptOptions()
        dim query, rs

        query = "select sms, email from CustomerMessageSetup where QueryId = -8 and customerId = " & Session("customerSequenceNumber")
        set rs = getdisconnectedrecordset(query)
        if rs.recordCount > 0 then
            smsReceipt = rs("sms")
            emailReceipt = rs("email")
        else
            query = "select sms, email from CustomerMessageSetup where QueryId = -8 and customerId = 0"
            set rs = getdisconnectedrecordset(query)
            if rs.recordCount > 0 then
                smsReceipt = rs("sms")
                emailReceipt = rs("email")
            end if
        end if
	end function



	function getCashDrawerFields()
	    dim query, rs
        printerIP = getPrinterShortPath()

        query = " select storehardware.cashdrawertype, isnull(printer.printername, '') as printername "
        query = query & " from storehardware "
        query = query & " left outer join printer on storehardware.cashdrawerattachedprinterid = printer.printerid "
        query = query & " where storehardware.hardwaretype = 'CD' "
        query = query & " and storehardware.terminalid = " & session("terminalid")

        set rs = getdisconnectedrecordset(query)
        if rs.recordcount > 0 then
            printerName = Replace(rs("printername"), "'", "\'")
        end if


        userIPAddress = getLocalPrinterAddress(session("terminalid"))

	end function
%>

<HTML>
<HEAD>
<TITLE>Apply Payment</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script type="text/javascript" src="/script/printing.js"></script>
<script type="text/javascript" src="/script/validation.js"></script>
<script type="text/javascript" src="/script/cashdrawer.js"></script>
<script type="text/javascript" src="/script/ccp-expresslink.js"></script>
<script type="text/javascript" src="../Script/clearent.js"></script>
<script type="text/javascript" src="../Script/json2.js"></script>
<script type="text/javascript">

	function submitForm()
	{
		if (validateForm()== true)
		{
			//Reload page
			document.applyPayment.action ="?submitted=true";
			document.applyPayment.submit();
		}

	}


	function validateField()
	{
		var amountPaid;

		if ( !isNum1( trim(document.applyPayment.txtAmountPaid.value), 0))
		{
			cbs_alert("Please enter a valid amount.");
			document.applyPayment.txtAmountPaid.focus();
			document.applyPayment.txtNewBalance.value = "";
			return false;
		}
		else
			populateNewBalance();
		return true;
	}


	function validateForm()
	{
		var changeDue;

		if	(trim(document.applyPayment.txtAmountPaid.value).length < 1 )
		{
			cbs_alert("Please enter amount paid.");
			document.applyPayment.txtAmountPaid.focus();
			return false;
		}
		if (trim(document.applyPayment.h_paymentType.value).length  == 0)
		{
			cbs_alert("Please select a mode of payment.");
			return false;
		}

		if (document.applyPayment.h_paymentType.value == "Cash")
		{

			if(parseFloat(document.applyPayment.txtAccountBalance.value) > 0 &&
				parseFloat(document.applyPayment.txtAmountPaid.value) >
				parseFloat(document.applyPayment.txtAccountBalance.value))
			{
				if(confirm("Amount paid is greater then the customer's balance.  Apply change to account?"))
				{


				}
				else
				{
					changeDue = parseFloat(document.applyPayment.txtAmountPaid.value) - parseFloat(document.applyPayment.txtAccountBalance.value);
					cbs_alert("Change due: $" + parseMoney(changeDue));
					document.applyPayment.txtAmountPaid.value = parseFloat(document.applyPayment.txtAmountPaid.value) - changeDue;
				}
			}

            var url = "http://<%=userIPAddress%><%=printerIP%>/openCashDrawer"
            OpenCashDrawer(url, '<%= printerName %>');
		}
		<% if cashDrawerCheck then %>
		else if (document.applyPayment.h_paymentType.value == "Check")
		{
            var url = "http://<%=userIPAddress%><%=printerIP%>/openCashDrawer"
            OpenCashDrawer(url, '<%= printerName %>');
		}
		<% end if %>

		return true;
	}


	function cancelForm()
	{
	    <% if trim(Request.QueryString("from")) = "cpi" then %>
            document.applyPayment.action ="customerpayment.asp?customerseq=<%=l_customerseq%>";
            document.applyPayment.submit();
	    <% else %>
            document.applyPayment.action ="accountMgmt.asp";
            document.applyPayment.submit();
		<% end if %>
	}


	function setPaymentType(element)
	{
		var y

		document.applyPayment.h_checkno.value  = ""

		if (document.applyPayment.h_paymentType.value != "" &&
			document.applyPayment.h_paymentType.value != null )
		{
			y = document.getElementById(document.applyPayment.h_paymentType.value)
			y.style.background = "lightgrey";
		}

		document.applyPayment.h_paymentType.value = ""

		var newvalue = element.id

		if (newvalue == "Check" || newvalue == "Gift Certificate" || newvalue == "Trade")
		{
			if (newvalue == "Check" || newvalue == "Trade")
			{
				if(document.applyPayment.trackCheckNum.value == 1)
				{
					document.applyPayment.action ="enterCardNumber.asp?Opage=ApplyPayments&type=" + newvalue + "&amountPaid=" + document.applyPayment.txtAmountPaid.value;
					document.applyPayment.submit();
				}
			}

			enableOkButton();
		}
		else if(newvalue == "Credit Card" && (document.applyPayment.enableXcharge.value == 1 || document.applyPayment.enableClearent.value == 1) )
		{
			if(document.applyPayment.txtAmountPaid.value == "")
			{
				cbs_alert("Enter a value into amount paid before selecting credit card.");
				return;
			}
			else
			{
				beginCreditCardPurchase(document.applyPayment.txtAmountPaid.value, "<%=session("employeeid")%>");
			}
		}
		else
		{
			enableOkButton();
		}

		document.applyPayment.h_paymentType.value = newvalue

		y = document.getElementById(document.applyPayment.h_paymentType.value)
		y.style.background = "yellow";

	}

    function clearentFailure(rawAnswer, isTimeout, orderId, amount, readingError, screenMsg) {
         $(':button').attr('disabled', false);
         document.getElementById('onFile').style.display = 'none';
         document.getElementById('cardReader').style.display = 'none';

         cbs_alert(screenMsg, cancelForm);
    }

    var nextAction;
	function clearentCardSuccess(id, amount, cardType, cardNum, expDate, authCode, rawAnswer, orderId, token, tipAmt) {
	    var addCCToFile = "0"
	    var raw = String(rawAnswer).replace(/-/g, "");
        var askToAdd = '<%=promptToAddCC%>'
        $(':button').attr('disabled', false);
        document.getElementById('onFile').style.display = 'none';
        document.getElementById('cardReader').style.display = 'none';
        nextAction = "?submitted=true" +
                         			"&transactionid=" + encodeURIComponent(id) +
                                     "&amount=" + encodeURIComponent(amount) +
                                     "&approvalCode=" + encodeURIComponent(authCode) +
                                     "&cardType=" + encodeURIComponent(cardType) +
                                     "&cardNumber=" + encodeURIComponent(cardNum) +
                                     "&cardExp=" + encodeURIComponent(expDate) +
                                     "&token=" + encodeURIComponent(token) +
                                     "&tipAmt=" + encodeURIComponent(tipAmt) +
                                     "&rawAnswer=" + encodeURIComponent(raw);

        PrintCreditCardReceipt(id);
        document.applyPayment.transactionid.value = id;

        if (token && askToAdd) {
            var cc_token = '<%=cc_xcid%>';
            var cc_expiration = '<%=cc_expiration%>';
            var msg
            if (cc_token !== '' && cc_expiration !== '')
            {
                if (cc_token !== token || cc_expiration !== expDate)
                    msg = "Do you wish to update the credit card information on file with this card?";
                else
                    msg = "Do you wish to add the credit card information to be on file?";

                cbs_confirm(msg, finishClearentSucYes, finishClearentSucNo);
                return;
            }
            else {
                msg = "Do you wish to add the credit card information to be on file?";
                cbs_confirm(msg, finishClearentSucYes, finishClearentSucNo);
                return;
            }
        }

        finishClearentSuccess(0)
	}


	function finishClearentSucYes() {
	    finishClearentSuccess(1);
	}
	function finishClearentSucNo() {
	    finishClearentSuccess(0);
	}

	function finishClearentSuccess(addCCToFile) {

	    enableOkButton();

		if (validateForm()=== true)
		{
			//Reload page
			document.applyPayment.action = nextAction +
            "&addCCToFile=" + encodeURIComponent(addCCToFile) +
            ('<%=cc_xcid%>' != '' ? "&oldToken=<%=cc_xcid%>" : '');
			document.applyPayment.submit();
		}
	}


	function credtCardSuccess(result_obj, params, result) {
		enableOkButton();
		PrintCreditCardReceipt(params.transaction_id);
		document.applyPayment.transactionid.value = params.transaction_id;
		submitForm();
	}

	function handleCardOption(cardOption) {
        clearOptionMsg();
	    var customerseq = '<%=Session("customersequencenumber")%>';
	    var amount = document.applyPayment.txtAmountPaid.value;
        var orderId = createOrderId("credit");
        $(':button').attr('disabled', true);
        if(cardOption === 0) {
            var cc_token = '<%=cc_xcid%>';
            var cc_expiration = '<%=cc_expiration%>';
           document.getElementById('onFile').style.display = 'block';
           chargeOnFileCard(amount, cc_token, cc_expiration, customerseq, '', '<%=cc_url%>', '<%=cc_key%>', '<%=cc_zip%>', orderId);
        }
        else if (cardOption === 1) {
            document.getElementById('cardReader').style.display = 'block';
            performSale(amount, '<%=cc_url%>', '<%=cc_key%>', "applyPayment", '<%=cc_zip%>', orderId);
        }
	}

		function sendStoredCardTrue() {
    	    clearConfirmMsg();
            handleCardOption(0);
    	}


	function beginCreditCardPurchase(amount, clerk) {
        var customerseq = '<%=Session("customersequencenumber")%>';

	<%if use_clearent then %>
        var cc_token = '<%=cc_xcid%>';
        var cc_expiration = '<%=cc_expiration%>';
        if (cc_token !== '' && cc_expiration !== '') {
            <% if termLicenseType = 2 then %>
                cbs_confirm('Back Office Terminals must use card on file', sendStoredCardTrue, '', 'Ok', 'Cancel');
            <% else %>
                cbs_select('Select Method', 2, 'On File|New Card', "handleCardOption");
            <% end if %>
        }
        else {
            <% if termLicenseType = 2 then %>
                cbs_alert("No card on file and cannot use card reader on back office terminal. Unable to perform transaction")
            <% else %>
            handleCardOption(1);
            <% end if %>
        }
    <% else%>

		var processor;
		var terminalid = "<%=Session("terminalID")%>";

		processor = new CreditCardProcessor();

		processor.Purchase({
			amount: amount,
			clerk: clerk,
			terminalid: terminalid,
			customerseq: customerseq,
			xc_account_id: '<%=cc_xcid%>',
			expiration: '<%=cc_expiration%>',
			zip: '<%=cc_zip%>',
			success: credtCardSuccess,
			failure: function(result_obj, params, result) {
				disableOkButton();
				cbs_alert(result_obj.result + "\\n" + result_obj.description);
			}
		});
		<% end if %>

	}

	function populateNewBalance()
	{
		var x , tempval
		var value1
		var value2

		if (document.applyPayment.txtAmountPaid.value > 0 )
		{
			tempval = document.applyPayment.txtAmountPaid.value.replace(/\./, "");
			document.applyPayment.txtAmountPaid.value = tempval.substr(0,tempval.length - 2) + "." + tempval.substr(tempval.length - 2);

			tempval = eval(applyPayment.txtAccountBalance.value - document.applyPayment.txtAmountPaid.value)
			tempval = new  Number(tempval)
			tempval= tempval.toFixed(2)
			document.applyPayment.txtNewBalance.value = tempval
		}
		else
		{
			document.applyPayment.txtNewBalance.value = "";
		}
	}


	function enableOkButton()
	{
		document.applyPayment.okButton.disabled = false;
	}

	function disableOkButton()
	{
		document.applyPayment.okButton.disabled = true;
	}



	function formatAmount(element)
	{
		var temp = cleanNumeric(element.value)
		element.value = autoFormatCurrency(temp)
	}

	function setFocusOnLoad() {
		document.applyPayment.txtAmountPaid.focus();
	}

</SCRIPT>
<STYLE type="text/css">
.account-error {
	text-align: center;
	margin: 30 150 10 150;
}

.account-error p {
	font-size: 16;
}
.freeze { pointer-events: none; }

</STYLE>

<BODY topmargin=0 leftmargin=0 onLoad="setFocusOnLoad()">

<!-- #include file="../include/banner.inc" -->

<H1>Apply Payment</H1>
<FORM id="applyPayment" name="applyPayment" action="" onsubmit="return false" method="post">
<div id="cardReader" class="overlay hidden">
  <h1 style="color: white">Waiting on Card Reader</h1>
</div>

<div id="onFile" class="overlay hidden">
  <h1 style="color: white">Transaction in Progress</h1>
</div>
<!-- <Input type=hidden name= h_checkno value= ""> -->
<Input type=hidden name= h_checkno value= "<%=checkCardNo%>"><!-- JJ added, 6Jan04 -->
<!-- <Input type=hidden name= h_paymentType value= ""> -->
<Input type=hidden name= h_paymentType value= "<%=payType%>"><!-- JJ added, 7Jan04 -->
<Input type=hidden name= paymentTypeName value= "<%=l_paymentTypename%>">
<INPUT type="hidden" name="trackCheckNum" value="<%= trackCheckNum%>"><!-- JJ added, 6Jan04 -->
<INPUT type="hidden" name="enableXcharge" value="<%= enableXcharge%>">
<INPUT type="hidden" name="enableClearent" value="<%= use_clearent%>">
<INPUT type="hidden" name="transactionid" value="">
<INPUT type="hidden" name="cameFrom" value="<%= trim(Request.QueryString("from")) %>">


<%
	if billingResponsibility <> "" then
%>

<div class="account-error">
<p style="font-size: 16">
<b><%=server.htmlencode(l_custname)%></b> is set to use <b><%=server.htmlencode(billingResponsibility)%></b>&#39;s account.
If you wish to apply a credit or charge please use <b><%=server.htmlencode(billingResponsibility)%></b>&#39;s account instead.
</p>
<button class=cancel id=cancel name=cancel onClick="cancelForm()">Cancel</button>
</div>

<%
	else
%>

<TABLE ALIGN=center WIDTH="600px" BORDER=1 CELLSPACING=1 CELLPADDING=5 >
		<tr height=20px></tr>
		<%if (len(trim(l_error)) <> 0) then %>
		<TR>
			<TD align=right STYLE="FONT-SIZE: 14px; FONT-WEIGHT: bold;color:Red">ERROR</TD>
			<TD><Font size=3px color = Red><%=l_error%></Font></TD>
		</TR>
		<%End if %>
		<TR>
			<TD align=right STYLE="FONT-SIZE: 14px; FONT-WEIGHT: bold">Customer Name</TD>
			<TD> <INPUT id=txtCustomerName name=txtCustomerName class=text style="HEIGHT: 25px; WIDTH: 250px" readonly value= "<%=Server.HTMLEncode(l_custname)%>"></TD>
		</TR>
		<TR>
			<TD align=right STYLE="FONT-SIZE: 14px; FONT-WEIGHT: bold">Account Balance</TD>
			<TD><INPUT id=txtAccountBalance name=txtAccountBalance class=text style="HEIGHT: 25px; WIDTH: 200px" readonly value= "<%=formatnumber(l_accountbalance, 2, , , false)%>"></TD>
		</TR>
		<TR>
			<TD align=right STYLE="FONT-SIZE: 14px; FONT-WEIGHT: bold">Amount Paid</TD>
			<TD>
				<INPUT id=txtAmountPaid name=txtAmountPaid class=text  onkeyup= "validateField()" style="HEIGHT: 25px; WIDTH: 200px" onKeyUp="formatAmount(this)"
				<% if not isempty(amountpaid) then %>
				value ="<%= amountpaid %>"
				<%End if %>>
			</TD>
		</TR>
		<TR>
			<TD align=right STYLE="FONT-SIZE: 14px; FONT-WEIGHT: bold">New Balance</TD>
			<TD><INPUT id=txtNewBalance name=txtNewBalance class=text style="HEIGHT: 25px; WIDTH: 200px" readonly ></TD>
		</TR>
</TABLE>
<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR height=40px>
			<TD colspan=2 align=center STYLE="FONT-SIZE: 16px; FONT-WEIGHT: bold"><Strong>Payment Type</Strong></TD>
		</TR>
		<% if rstPayment.recordcount > 0 then
				while not rstPayment.eof
		%>
			<TR>
				<TD align=center width=50%>
					<BUTTON class=std <%if payType = rstPayment("PaymentTypeName") then%>style="background:yellow"<%else%>style="background:lightgrey"<%end if%>  name="<%=rstPayment("PaymentTypeName")%>" id="<%=rstPayment("PaymentTypeName") %>" onClick="setPaymentType(this)"
					<% if (rstPayment("PaymentTypeName")="GiftCard" or rstPayment("PaymentTypeName")="Gift Certificate") then %>
						disabled
					<% end if %>><%=rstPayment("PaymentTypeName")%></button>
				</TD>
		<%
				if not rstPayment.eof then
					rstPayment.movenext
				end if
				if not rstPayment.eof then
		%>
				<TD align=center width=50%>
					<BUTTON class=std <%if payType = rstPayment("PaymentTypeName") then%>style="background:yellow"<%else%>style="background:lightgrey"<%end if%> name ="<%=rstPayment("PaymentTypeName")%>" id ="<%=rstPayment("PaymentTypeName") %>" onClick="setPaymentType(this)"
					<% if (rstPayment("PaymentTypeName")="GiftCard" or rstPayment("PaymentTypeName")="Gift Certificate") then %>
						disabled
					<% end if %>><%=rstPayment("PaymentTypeName")%></button>
				</TD>
		<%		end if
		%>
			</TR>

		<%		if not rstPayment.eof  then
					rstPayment.movenext
				end if
				wend
			end if
			rstpayment.close
			set rstPayment = nothing
		%>

		<TR height=20px></TR>
		<TR height=100px>
			<td colspan=2>
				<TABLE ALIGN=center WIDTH=100% BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<TD  align="center" colspan=2>
						<INPUT class=touchnoborder id=okButton name=okButton type=button <%if payType = "" then%>disabled<%end if%> value=""  style="background-image:url(../images/OK.gif)" onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
						<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
					</TD>
				</table>
			</td>
			<td></td>
		</TR>
	</TABLE>

<% end if %>

</FORM>

</BODY>
</HTML>


<%
	'COMMON variables
	dim l_custname
	dim l_accountbalance
	dim l_paymentTypename
	dim billingResponsibility

	function getBillingResponsibility(customerseq)
		dim query, rs

		query = " select billing.customersequencenumber, billing.customername "
		query = query & " from customer dcust inner join customer billing on dcust.billingCustomerSeq = billing.customersequencenumber "
		query = query & " where dcust.customersequencenumber = " & customerseq

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getBillingResponsibility = rs("customername")
		end if

		set rs = nothing



	end function

	function GetCustomerCardInfo(customerseq)

		dim query, rs


		query = " select "
		query = query & " isnull(creditcardnumber, '') as creditcardnumber, "
		query = query & " isnull(creditcardexpdate, '') as creditcardexpdate, "
		query = query & " isnull(shippingzipcode, '') as creditcardzip "
		query = query & " from customer where customersequencenumber = " & customerseq

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			cc_xcid = rs("creditcardnumber")
			cc_expiration = rs("creditcardexpdate")
			cc_zip = rs("creditcardzip")
		end if

		set rs = nothing

	end function

	function GetCustomerinfo()

		dim rstTemp
		dim sqltxt
		l_accountbalance = 0.00

		sqltxt = "Execute dbo.GetCustomerAccountBalance " &  session("accountCustomerSequenceNumber")

		GetCustomerCardInfo session("accountCustomerSequenceNumber")

		set rstTemp = getdisconnectedrecordset(sqltxt)

		if rstTemp.recordcount > 0 then
			l_custname =  rstTemp("CustomerName")
			l_accountbalance =  rstTemp("accountbalance")
			if isnull(l_accountbalance) then
				l_accountbalance = 0.00
			else
				l_accountbalance= cdbl(l_accountbalance)
			end if
			l_paymentTypename = ucase(rstTemp("paymentTypename"))
			if isnull(l_paymentTypename) then
				l_paymentTypename = ""
			end if
			if cdbl(rstTemp("accountbalance")) <= 0 and rstTemp("permanentaccount") = 0 and rstTemp("Temporaryaccount")  = 0 then
				l_error = "Customer is not an account holder. Cannot apply payment"
			else
				l_paymentTypename = "ON ACCOUNT"
			end if

			billingResponsibility = getBillingResponsibility(session("accountCustomerSequenceNumber"))
		end if
		rsttemp.close
		set rstTemp = nothing

	end function


	function getActivePaymentTypes()

		dim sqltxt

		sqltxt = " select * from storepaymentType where enabled=1 and paymentTypename <> 'ON ACCOUNT' and storeid = " & session("storeid") _
					& " order by displaysequence"

		set rstPayment = getdisconnectedRecordset(sqltxt)

	end function

	function updateCardPayment(transactionID, amountPaid)
	    Dim query, rs

	    query = " update cardpayment set amountapplied = "
	    query = query & " isnull(amountapplied, 0) + " & amountPaid
	    query = query & " where transactionid = '" & transactionID & "'"

	    qryexecute query
	End function


	function updatedatabase()

		dim sqltxt
		dim transactionId

		transactionID = ""
		updateCardPayment request.form("transactionid"), Request.form("txtamountpaid")
		if use_clearent then
		    transactionID = Request.QueryString("transactionid")
		end if

			'@p_storeid 		int,
        	'@p_terminalid		int,
        	'@p_employeeid 		int,
        	'@p_customerseq 		int,
        	'@p_paymentType 		varchar(64),
        	'@p_amountpaid  		money,
        	'@p_checkno		varchar(64),
        	'@p_approvalcode		varchar(32),
        	'@p_TransactionNumber	varchar(32),
        	'@p_cardTypeId		int,
        	'@p_expDate		char(4),
        	'@p_receiptnumber	varchar(50),
        	'@effectivedate	datetime


		sqltxt = "execute dbo.InsertPayment " & session("storeid")_
				& " ," & session("terminalid") _
				& " , " & session("employeeid") _
				& " ,"   & session("accountCustomerSequenceNumber") _
				& " ,"   & dbcreateqrystring(Request.form("h_paymentType")) _
				& " ,"   & Request.form("txtamountpaid") _
				& " ,"   & dbcreateqrystring(Request.form("h_checkno")) _
				& ", '' " _
				& ", " & dbcreateqrystring(transactionID) & " " _
				& ", '' " _
				& ", '' " _
				& ", '' " _ 
				
				'& ", '' " _ ' approval code
				'& ", '' " _ ' trans number 'XXXXXX'
				'& ", '' " _ ' card type id
				'& ", '' " _ ' exp date
				'& ", '' " _ ' receipt
					
		dbstartTrans()
		
		qryexecutewithtrans(sqltxt)
		
		dbendtrans()
					
	end function

%>
