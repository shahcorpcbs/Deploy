<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim isSubmitted 
	dim l_storeid
	dim l_employeeid
	dim l_action
	dim rsTicketbydate 
	
	rsTicketbydate = null
	
	l_storeid = session("storeid")
	l_employeeid = session("employeeid")
	isSubmitted = Request.QueryString("Submitted")
	if isSubmitted then
		UpdateDatabase()
		Response.Redirect "routesMenu.asp"
	end if
	
	getRoutes()
%>
<HTML>
<HEAD>
<TITLE>Check In</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function captureKeyUpEvent(element){
		
	  	if (event.keyCode == 13){
	  		event.returnValue = true;	
			addInvoiceNoToList();
		}
	}
	
	
	function cancelForm() {
		document.checkInForm.action="routesMenu.asp";
		document.checkInForm.submit();
	}
	
	function addInvoiceNoToList(){
		
		var ticketNo = document.checkInForm.txtTicketNo.value;
		ticketNo = trim(ticketNo);
		if(ticketNo.length >0){
			var oOption = document.createElement("OPTION");
			oOption.text=ticketNo;
			oOption.value=ticketNo;
			document.all.item("invoiceNumbersList").add(oOption);
		}
		document.checkInForm.txtTicketNo.value="";
		return false;
	}
	
	
	function deleteSelectedInvNo(){
		if(document.checkInForm.invoiceNumbersList.length >0){
			var index = document.checkInForm.invoiceNumbersList.selectedIndex;
			if(index >=0) {
				document.checkInForm.invoiceNumbersList.options[index]=null;
				if ( document.checkInForm.invoiceNumbersList.length > 0 )
					document.checkInForm.invoiceNumbersList[0].selected = true;
			}
		}
			
	}
	
	var oldRouteindex;
	
	function clearInvoiceList() {
	  	if (oldrouteindex != document.checkInForm.routeList.selectedIndex) {
	  		document.checkInForm.invoiceNumbersList.length   = 0;
	  			
	  	}
	  	oldrouteindex = document.checkInForm.routeList.selectedIndex 
	 }	
	  	
	 function saveRouteIndex(){
	 		oldrouteindex = document.checkInForm.routeList.selectedIndex 
	}
	
	function submitForm(){
	  	var i
	  	i = 0;
	  	if (document.checkInForm.invoiceNumbersList.length > 0 ){
	  			while (i < document.checkInForm.invoiceNumbersList.length) {
	  				document.checkInForm.invoiceNumbersList[i].selected = true;
	  				i++;
	  			}
	  			document.checkInForm.action = "?submitted=true";
	  			document.checkInForm.submit();
	  		}
		else if (document.checkInForm.routeList.selectedIndex > -1 ){
				document.checkInForm.action = "?submitted=true";
	  			document.checkInForm.submit();
		}
		else
			cancelForm();
	  }
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onLoad="saveRouteIndex()">

<!-- #include file="../include/banner.inc" -->
<H1>Check In</H1>
<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >	
	<FORM id="checkInForm" name="checkInForm" action="" onSubmit= "return addInvoiceNoToList()" method="post">
		<tr height=50px><td></td></tr>
		<tr>
			<td align=right class="label">Route Name</td>
			<td>
				<SELECT name=routeList STYLE="FONT-SIZE=16px;width:175px">
				<%
					if rsRoutelist.Recordcount > 0 then
						while not rsRoutelist.eof
				%>	
				<OPTION 
				<%if trim(Request.Form("routeList")) = trim(rsRoutelist("routenumber") ) then %>
					selected
				<% end if %>
				VALUE= "<%=trim(rsRoutelist("routenumber"))%>"><%=trim(rsRoutelist("name")) %> </option>
				<%
					rsRoutelist.movenext
					wend
						rsRoutelist.close
						set rsRoutelist = nothing
					end if 
				
				%>
				</SELECT>
			</td>
		</tr>
		<tr height=20px><td></td></tr>
		<tr>
			<td  align=right class="label" valign=top>Invoice Numbers
			</td>
			<td width=175px valign=top>
				<INPUT id=txtTicketNo name=txtTicketNo class=text onKeypress="captureKeyUpEvent(this)">
			</td>	
			<td width=30px valign=top>
				<INPUT class=touch id=addToList name=addToList type=button value="" style="background-image:url(../images/select-All-2.gif);width:30px;height:30px;" onClick="addInvoiceNoToList()">
			</td>
			<td valign=top width=200px>
				<Select multiple name=invoiceNumbersList size=10 style="width:200px;font-size=16px">
				</Select>
			</td>
			<td valign=top>
				<INPUT class=touch id=delete name=delete type=button value="" style="background-image:url(../images/Cancel-2.gif);background-position=center" onClick="deleteSelectedInvNo()"><br>Delete
			</td>
		</tr>
		<tr>
			<td></td>
			<td>
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5>
					<tr>
						<td align=center>
							<INPUT class=touch id=bttnProcessInvoices name=bttnProcessInvoices onClick = "submitForm()" type=button style="background-image:url(../images/Multiple-Tickets.gif);background-position=center" value=""><br>Process Invoices
						</td>
						<td align=center>
							<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
						</td>
					</tr>
				</table>
			</td>
			
		</tr>
	</form>
</table>
</BODY>
</HTML>
<%
	dim rsRouteList
	
	
	Function getRoutes()
	dim sqltxt
		'Modified by Mwiemann on 6/11/2003 to show routes (routenumber 0 is None)
		sqltxt = "Select * from Route where storeid = " & l_storeid & " and routenumber > 0"
		set rsRouteList = getdisconnectedrecordset(sqltxt)
	end function
	
	function UpdateDatabase()
	dim sqltxt
	dim i 
	dim invoicelist
	
		if Request.Form("invoiceNumbersList").count > 0 then
			' modified by rahul on 14th feb 2003 
			'invoicelist = "'" & dbcreateqrystring(Request.Item("invoiceNumbersList").Item(1))& "'"
			invoicelist = dbcreateqrystring(Request.Item("invoiceNumbersList").Item(1))
			' end rahul
			for i = 2 to Request.Form("invoiceNumbersList").count
				' modified by rahul on 14th feb 2003 
				'invoicelist = invoicelist & ",'" & dbcreateqrystring(Request.Form("invoiceNumbersList").Item(i)) & "'"
				invoicelist = invoicelist & ", " & dbcreateqrystring(Request.Form("invoiceNumbersList").Item(i)) 
				' end rahul
			next 
		end if
		
		
		
	sqltxt = "exec checkin_delivery " & dbcreateqrystring(Request.form("routelist")) & "," & dbcreateqrystring(invoicelist) _
				& ", " & session("terminalid")_
				& ", " & session("employeeid")_
				& "," & session("storeid")

	qryexecute sqltxt
	
	end function
%>
