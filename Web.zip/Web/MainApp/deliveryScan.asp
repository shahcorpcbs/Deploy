<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<%
	dim query, rs
	dim deliveryID
	dim enforceOrder
	
	deliveryID = getReqVar("deliveryID")
	
	enforceOrder = getReqVar("enforceOrder")
	
	if enforceOrder <> "" then
		setScanOrder enforceOrder
	else
		enforceOrder = getScanOrder()
	end if

	select case(request.querystring("useraction"))
	case "scan"
		scanDelivery deliveryID, request.querystring("invoiceNumber")
	end select
	
	function setScanOrder(order)
		dim query, rs
		
		query = " update miscsetup set deliveryscanorder = " & order & " where storeid = " & session("storeid")
		qryexecute query
			
	end function
	
	function getScanOrder()
		dim query, rs
		
		query = " select deliveryScanOrder from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getScanOrder = rs("deliveryScanOrder")
		else
			getScanOrder = 0
		end if
	
		set rs = nothing
	end function
	
	function scanDelivery(deliveryID, invoiceNumber)
		dim query, rs
		
		query = " update deliveryitem set scanned = 1 "
		query = query & " from deliveryitem inner join ticket on "
		query = query & " deliveryitem.ticketNumber = ticket.ticketNumber "
		query = query & " inner join deliverystop on "
		query = query & " deliveryitem.deliverystopid = deliverystop.deliverystopid "
		query = query & " where ticket.invoiceNumber = " & invoiceNumber
		query = query & " and deliverystop.deliveryid = " & deliveryID

		qryexecute query
	
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getTicketStatusHTML(status)
		dim result
		
		select case status
			case "AC"
				result = "Active"
			case "FI"
				result = "Finished"
			case "VO"
				result = "Voided"
		end select
		
		getTicketStatusHTML = result
	end function
	
	function getDeliveryItemStatusHTML(status)
		dim result
		
		select case status
			case 0
				result = "Ready"
			case -1
				result = "<span style=""background:#f00;color:#fff;padding:2px"">"
				result = result & "Not Delivered"
				result = result & "</span>"



		end select
		
		getDeliveryItemStatusHTML = result
	end function
	
	function getPaymentStatusHTML(status)
		dim result
		
		select case status
			case 1
				result = "<span style=""background:#f0f;color:#fff;padding:2px"">"
				result = result & "Pending"
				result = result & "</span>"
			case 2
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Pending Batch"
				result = result & "</span>"
			case 10
				result = "<span style=""background:#af0;color:#000;padding:2px"">"
				result = result & "Paid"
				result = result & "</span>"
			case 11
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Request Made"
				result = result & "</span>"
			case 12
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Waiting"
				result = result & "</span>"
			case 13
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Transaction Made"
				result = result & "</span>"
			case -11
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Missing Request"
				result = result & "</span>"
			case -12
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Process Error"
				result = result & "</span>"
			case -13
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Cancelled"
				result = result & "</span>"

		end select
	
		getPaymentStatusHTML = result
	end function


	function getTopDeliveryStop(deliveryid)
		dim query, rs
		
		query = " select top 1 deliverystop.deliverystopid from "
		query = query & " deliverystop inner join deliveryitem on "
		query = query & " deliverystop.deliverystopid = deliveryitem.deliverystopid "
		query = query & " where deliveryitem.scanned = 0 and deliverystop.deliveryid = " & deliveryid  
		query = query & " order by deliverystop.stoporder asc "

		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getTopDeliveryStop = rs("deliverystopid")
		end if
		
		set rs = nothing
	end function

	function getBottomDeliveryStop(deliveryid)
		dim query, rs
		
		query = " select top 1 deliverystop.deliverystopid from "
		query = query & " deliverystop inner join deliveryitem on "
		query = query & " deliverystop.deliverystopid = deliveryitem.deliverystopid "
		query = query & " where deliveryitem.scanned = 0 and deliverystop.deliveryid = " & deliveryid  
		query = query & " order by deliverystop.stoporder desc "

		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getBottomDeliveryStop = rs("deliverystopid")
		end if
		
		set rs = nothing
		
	end function
	
	
	function getTopInvoices(deliveryid)
		dim query, rs
		dim result
		dim deliverystopid
		
		deliverystopid = getTopDeliveryStop(deliveryid)
		
		if deliverystopid <> "" then
			query = " select ticket.invoicenumber from "
			query = query & " ticket where ticket.ticketnumber in "
			query = query & "( select deliveryitem.ticketnumber from deliveryitem "
			query = query & " where deliveryitem.scanned = 0 and deliveryitem.deliverystopid = " & deliverystopid & ")"
	
			set rs = getdisconnectedrecordset(query)
			
			while not(rs.eof or rs.bof)
				result = result & "[" & rs("invoicenumber") & "]"	
				rs.movenext
			wend
		end if
		
		getTopInvoices = result
		
		set rs = nothing
	end function
	
	
	function getBottomInvoices(deliveryid)
		dim query, rs
		dim result
		dim deliverystopid
		
		deliverystopid = getBottomDeliveryStop(deliveryid)
		
		if deliverystopid <> "" then
			query = " select ticket.invoicenumber from "
			query = query & " ticket where ticket.ticketnumber in "
			query = query & "( select deliveryitem.ticketnumber from deliveryitem "
			query = query & " where deliveryitem.scanned = 0 and deliveryitem.deliverystopid = " & deliverystopid & ")"
	
			set rs = getdisconnectedrecordset(query)
			
			while not(rs.eof or rs.bof)
				result = result & "[" & rs("invoicenumber") & "]"	
				rs.movenext
			wend
		end if
		
		getBottomInvoices = result
		
		set rs = nothing
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">


<style type="text/css">

.customer_row th {
	background:#DDD;
	border-bottom:1px solid #888;
	font-size:14;
	height:30px;
}
.customer_row tr {

}
.customer_row td {

	border:3px solid #F6F6F6;
	background:#fff;
}

.directions_row th {
	background:#AAA;

}
.directions_row tr {
	background:#DDD;
}
.directions_row td {

	border:none;
	background:#fff;
}


.customer_invoices th {

	height:20px;

}
.customer_invoices tr {
	background:#DDD;
}
.customer_invoices td {
	border:none;
}



</style>

<script language="javascript" type="text/javascript" src="/Script/validation.js"></script>

<script language="javascript" type="text/javascript">
	function exitForm() {
		if(bottomInvoices.value != "" || topInvoices.value != "") {
			if(!confirm("Some invoices not verified.  Do you wish to continue?"))
				return;
		}

	document.deliveryScan.action = "/mainapp/delivery.asp?deliveryid=<%=deliveryid%>";
	document.deliveryScan.submit();
	}
	
	function captureKey(){
	
		if (event.keyCode == 13){
			scanInvoice();
		}
	}
	
	function scanInvoice() {
		var invoiceNum;
		var enforceOrderValue;
		
		invoiceNum = invoiceNumber.value;
		
		if(invoiceNum != "" && isStrNumeric(invoiceNum)) {
			if(isInvoiceNumberValid(invoiceNum)){
				enforceOrderValue = enforceOrder.options[enforceOrder.selectedIndex].value;
                document.deliveryScan.action = "/mainapp/deliveryScan.asp?useraction=scan&enforceOrder=" + enforceOrderValue + "&deliveryid=<%=deliveryID%>&invoicenumber=" + invoiceNum;
                document.deliveryScan.submit();
			}
			else
				show_focus("Invoice out of order.", "Invoice Order", invoiceNumber);
		}
		else {
			show_focus("Invoice number must be a number only.", "CBS Error", invoiceNumber);
		}
	}
	
	function isInvoiceNumberValid(invoiceNumber) {
		switch(enforceOrder.value) {
			case "0":
				return true;
				break;
			case "1":
				return topInvoices.value.indexOf(invoiceNumber, 0) >= 0;
				break;
			case "-1":
				return bottomInvoices.value.indexOf(invoiceNumber, 0) >= 0;
				break;
		
		}

	}
	
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="invoiceNumber.focus()">
<!-- #include file="../include/banner.inc" -->

<FORM name="deliveryScan" ID="deliveryScan" METHOD=POST  style="margin:0;padding:0">
<INPUT type="hidden" value="<%=getBottomInvoices(deliveryid)%>" name="bottomInvoices" />
<INPUT type="hidden" value="<%=getTopInvoices(deliveryid)%>" name="topInvoices" />

<TABLE align="center" cellspacing="12">
	<TR>
		<TD>
			<INPUT name="invoiceNumber" onkeyup="captureKey()" />
		</TD>
		<TD>
			<SELECT name="enforceOrder">
				<OPTION value="0" <%if trim(enforceOrder) = "0" then%>selected<%end if%>>No Order</OPTION>
				<OPTION value="1" <%if trim(enforceOrder) = "1" then%>selected<%end if%>>Enforce Forward</OPTION>
				<OPTION value="-1" <%if trim(enforceOrder) = "-1" then%>selected<%end if%>>Enfoce Reverse</OPTION>
			</SELECT>
		</TD>
	</TR>
</TABLE>

<DIV class="cmdbar" style="margin-bottom:1" id="commandButtons">
		<SPAN style="float:left">
		</SPAN>

		<SPAN style="float:right">
	        <BUTTON onclick="exitForm()">Exit</BUTTON>
		</SPAN>
</DIV>	
<%
	dim totalRouteDistance
	dim totalAmount
	dim totalPayments
	
	totalRouteDistance = 0
	totalAmount = 0
	totalPayments = 0
%>

<TABLE style="width:100%" cellspacing="0" cellpadding="0" class="customer_row">

	<TR>
		<TH style="width:50px">&nbsp;</TH>
		<TH>Name</TH>
		<TH>Address</TH>
		<TH>Notes</TH>
		<TH>Invoices</TH>
	</TR>

<%


	if deliveryid <> "" then
	
	dim stopNumber
	
	stopNumber = 1
	
	query = "select deliverystop.*, customer.customername, customerdelivery.paymenttype as defaultpaymentmethod, "
	query = query & " dbo.getAccountBalance(customer.customersequencenumber, getdate()) as customerBalance from deliverystop "
	query = query & " inner join customer on deliverystop.customersequencenumber = customer.customersequencenumber "
	query = query & " inner join customerdelivery on deliverystop.customerdeliveryid = customerdelivery.id "
	query = query & " where deliverystop.deliveryid = " & deliveryid
	query = query & " order by deliverystop.stoporder, deliverystop.deliverystopid "


	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
		stopNumber = stopNumber + 1
%>

	<TR>

		<TD valign="center" align="center" style="width:50px"><h1><%=stopNumber%></h1></TD>
		<TD valign="center" align="center"><%=rs("customername")%></TD>
		<TD valign="center" align="center"><%=replace(rs("deliveryaddress"), vbcrlf, "<br>")%>&nbsp;</TD>
		<TD valign="center">
			<% if rs("deliverynotes") = "" then %>
			<center>No Notes</center>
			<% else %>
			<%=replace(rs("deliverynotes"), vbcrlf, "<br>")%>
			<% end if %>
		</TD>


<%
		dim rs2
		dim rs3
		dim deliveryAmountDue
		
		deliveryAmountDue = 0
		
		query = " select ticket.*, invoicetotal - amountpaid as amountdue, "
		query = query & " deliveryitem.deliveryitemid, deliveryitem.amountposted, "
		query = query & " deliveryitem.status, deliveryitem.scanned from deliveryitem"
		query = query & " inner join ticket on "
		query = query & " deliveryitem.ticketnumber = ticket.ticketnumber "
		query = query & " where deliverystopid = " & rs("deliverystopid")

		set rs2 = getdisconnectedrecordset(query)

		if rs2.recordcount > 0 then
		
		query = " select * from deliverypayment "
		query = query & " where deliverystopid = " & rs("deliverystopid")

		set rs3 = getdisconnectedrecordset(query)

%>

		<TD align="right" valign="top">
			<TABLE style="width:100%" cellspacing="0" class="customer_invoices">
				<TR>
					<TH>Invoice</TH>
					<TH style="width:100px">Status</TH>
					<TH align="right">Amount</TH>
				</TR>
<%
		while not(rs2.eof or rs2.bof)
%>

				<TR>
					<TD><%if rs2("scanned") then%><img src="/images/scan.gif" />&nbsp;<%end if%><%=rs2("invoicenumber")%></TD>
					<TD align="center"  style="width:100px"><%=getDeliveryItemStatusHTML(rs2("status"))%></TD>
					<TD align="right">
					
					<%=formatcurrency(rs2("amountdue"))%>
					<%if rs2("amountposted") > 0 then%>
					/<%=formatcurrency(rs2("amountposted"))%>
					<%end if%>
					</TD>
				</TR>
<%
			if rs2("status") = 0 then
			
				deliveryAmountDue = round(deliveryAmountDue + rs2("amountdue") + rs2("amountposted"), 2)
				totalAmount = round(totalAmount + rs2("amountdue"), 2)
			end if
			
			rs2.movenext
		wend

		
		while not(rs3.eof or rs3.bof)
%>

				<TR>

					<TD><B><%=rs3("paymentmethod")%></B></TD>
					<TD align="center"><B><%=getPaymentStatusHTML(rs3("status"))%></B></TD>
					<TD align="right" 
					<% if rs3("status") < 1 then %>
					style="text-decoration: line-through;color:#aaa"
					<% end if %> ><B><%=formatcurrency(-rs3("amounttobeapplied"))%></B></TD>
				</TR>
<%
			if rs3("status") > 0  then
				if rs3("status") <> 10 then
					deliveryAmountDue = round(deliveryAmountDue - rs3("amounttobeapplied"), 2)
				end if
				
				totalPayments = round(totalPayments + rs3("amounttobeapplied"), 2)
			end if
			rs3.movenext
		wend
%>

<%		if rs("customerBalance") < 0 then %>
				<TR>
					<TD><B>Account Credit</B></TD>
					<TD align="center"><B>&nbsp;</B></TD>
					<TD align="right"><B><%=formatcurrency(-rs("customerBalance"))%></B></TD>
				</TR>
<%
			deliveryAmountDue = deliveryAmountDue + rs("customerBalance")
			if deliveryAmountDue < 0 then
				deliveryAmountDue = 0
			end if
		end if %>

				<TR>
					<TD style="border-top=1px solid #DDD" colspan="2"><strong>Total</strong></TD>
					<TD align="right" style="border-top=1px solid #DDD"><%=formatcurrency(deliveryAmountDue)%></TD>
				</TR>
			</TABLE>
		</TD>
<%


		set rs2 = nothing
		set rs3 = nothing
		
		else
%>
		<TD align="center">No Invoices, Pickup Only</TD>
<%
		end if
%>

	</TR>


<%
		rs.movenext
	wend

	set rs = nothing
	
	else
	
	end if
%>

</TABLE>

</FORM>
</BODY>
</HTML>
