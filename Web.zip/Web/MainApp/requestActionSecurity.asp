<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<!--#include file="../include/json.asp"-->

<!--#include file="../include/security.asp"-->

<%
	dim query, rs
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if

	dim location
	dim action
	dim employeeid
	dim result

	employeeid = request.querystring("employeeid")
	location = request.querystring("location")
	action = request.querystring("action")

	if sec_FindPermission(location, action, employeeid, true) then
		result = 1
	else
		result = 0
	end if


	response.write returnResult(result, "OK")

	function returnResult(success, answer )
		dim result
		
		result = "{ "
		result = result & """success"": """ & JSEncode(success) & """, "
		result = result & """answer"": """ & JSEncode(answer) & """"
		result = result & "}"
		
		returnResult = result
	end function


	function JSEncode(s)
		if not isnull(s) then
			JSEncode = s
			JSEncode = Replace(JSEncode, "\", "\\") 
			JSEncode = Replace(JSEncode, """", "\""")
			JSEncode = Replace(JSEncode, vbCr, "\r")
			JSEncode = Replace(JSEncode, vbLf, "\n")
		end if
	end function 


%>