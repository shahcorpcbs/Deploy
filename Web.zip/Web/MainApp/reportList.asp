
<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%

	dim query, rs
	
	dim reportGroupID

	reportGroupID = Request.QueryString("reportGroupID")

%>

<HTML>
<HEAD>
<TITLE>Report List</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>


<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Report List for Viewing and Scheduling</H1>

<TABLE WIDTH="800px" ALIGN=center BORDER=0 CELLSPACING=7 CELLPADDING=0>


<tr style="height:30px;background: #888">
	<td colspan=2 class="label" align="center"><%=request.querystring("groupName")%></td>
</tr>
			
<%
	query = " select * from reportdomain where disabled = 0 and reportGroupID = " & reportGroupID
	query = query & " order by displaySequence "
	Set rs = getDisconnectedRecordset(query) 
	
	while not (rs.EOF or rs.BOF)
%>

		<tr >
			<td align="left" width="70px">
				<button
					class=reg
					onclick="location.href='reportParams.asp?reportID=<%= rs("reportID") %>&reportName=<%= Server.URLEncode (rs("reportName").value) %>'">
				Generate</button>
			</td>
			<td>
				<b><%=rs("reportName") %></b>
				<br><%=rs("reportDescription") %>
			</td>
		</tr>
		
	<%		
		
		rs.movenext
				
	wend

	set rs = nothing

	%>

</table>

<br>
<table width=100%>
<tr>
			<td width = 100% align=center >
				<INPUT class=touchnoborder id=close name=close type=button value="" onClick="location.href='reportGroup.asp'" 
					style="background-image:url(../images/Cancel.gif);">
			</td>

</tr>
<tr style="height: 70px"></tr>
</table>

</BODY>
</HTML>
