<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<!--#include file="../include/json.asp"-->

<!--#include file="../include/manifest.asp"-->
<%
	dim query, rs
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if
	
	select case lcase(request.querystring("a"))
	case "addinvoice"
		addInvoice request.querystring("manifestid"), request.querystring("invoicenumber")
	case "addinvoicelocation"
		addInvoiceLocation request.querystring("manifestid"), request.querystring("invoicenumber"), request.querystring("location")
	case "addlocation"
		addLocation request.querystring("manifestid"), request.querystring("invoicenumber"), request.querystring("location")
	case "createmanifest"
		createManifest request.querystring("name"), cstr(request.querystring("parentmanifestid"))
	case "removeinvoice"
		removeInvoice request.querystring("manifestid"), request.querystring("invoicenumber")
	end select


	
	function returnResult(success, answer, message, customer )
		dim result
		
		result = "{ "
		result = result & "success: """ & JSEncode(success) & """, "
		result = result & "answer: """ & JSEncode(answer) & """, "
		result = result & "message: """ & JSEncode(message) & """, "
		result = result & "customer: """ & JSEncode(customer) & """ "
		result = result & "}"
		
		returnResult = result
	end function


	function JSEncode(s)
		if not isnull(s) then
			JSEncode = s
			JSEncode = Replace(JSEncode, "\", "\\") 
			JSEncode = Replace(JSEncode, """", "\""")
			JSEncode = Replace(JSEncode, vbCr, "\r")
			JSEncode = Replace(JSEncode, vbLf, "\n")
		end if
	end function 


	function createManifest(name, parentmanifestid)
		dim manifestID
		manifestID = CBS_createManifest(name, parentmanifestid)
		response.write returnResult("1", manifestID, "", "")
	end function

	function addInvoice(manifestID, invoiceNumber)
		dim result
		result = CBS_addInvoiceToManifest(manifestID, invoiceNumber, true)
		if result < 0 then
			response.write returnResult("0", "FAILED", "", "")
		else
			response.write returnResult("1", result,  getInvoiceLocationStatus(invoiceNumber, ""), getInvoiceCustomer(invoiceNumber))
		end if
	end function
	

	function removeInvoice(manifestID, invoiceNumber)
		dim result
		result = CBS_removeInvoiceFromManifest(manifestID, invoiceNumber)
		if result < 0 then
			response.write returnResult("0", "FAILED", "", "")
		else
			response.write returnResult("1", result, "", "")
		end if
	end function
	

	function addInvoiceLocation(manifestID, invoiceNumber, location)
		dim result
		result = CBS_addInvoiceLocationToManifest(manifestID, invoiceNumber, location, true)
		if result < 0 then
			response.write returnResult("0", "FAILED", "", "")
		else
			response.write returnResult("1", result, getInvoiceLocationStatus(invoiceNumber, location), getInvoiceCustomer(invoiceNumber))
		end if
	end function

	function addLocation(manifestID, invoiceNumber, location)
		dim result
		result = CBS_addLocationToManifestInvoice(manifestID, invoiceNumber, location)
		if result < 0 then
			response.write returnResult("0", "FAILED", "", "")
		else
			response.write returnResult("1", result, getInvoiceLocationStatus(invoiceNumber, location), getInvoiceCustomer(invoiceNumber))
		end if
	end function


	function getInvoiceCustomer(invoiceNumber)
		dim query, rs
		dim terminalid
		on error resume next

		query = " select customer.customername from customer "
		query = query & " inner join ticket on customer.customersequencenumber = ticket.customersequencenumber "
		query = query & " where ticket.invoicenumber = '" & DBStr(invoiceNumber) & "'"

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getInvoiceCustomer = rs("customername")
		end if

		set rs = nothing
	end function

	function getInvoiceLocationStatus(invoiceNumber, location)
		dim query, rs
		dim terminalid
		on error resume next

		terminalid = session("terminalid")

		query = "exec CheckRackStatus " & terminalid
		query = query & ", '" & DBStr(invoiceNumber) & "'"
		query = query & ", '" & DBStr(location) & "'"
		query = query & ", ''"

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getInvoiceLocationStatus = rs("ErrorMessage")
		end if

		set rs = nothing
	end function

%>