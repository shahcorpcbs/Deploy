<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim storeId
	dim pricelistId, deptId, employeeID, empName, terminalID, storeName
	dim customerSeq, custName, custId, fullCust
	dim custPhone, areaCode, custVisitCount, routeNumber
	dim cardNo, cardId, curBal, addAmt, newBal
	dim taxCode, discountId, noOfUses, taxDesc
	dim actionString
	dim ticketNo, invoiceNo
	dim invoiceTotal, taxAmount
	dim LI
	dim taxPercent
	dim pickupInvoices,pickupInvoicesRst

	storeId = Session("storeId")
	storeName = Session("storeName")
	set session("pickupInvoices")= nothing
	set session("pickupobj") = nothing
	employeeId = session("employeeId")
	empName = Session("employeeName")
	terminalID = session("terminalId")

	actionString = Request.QueryString("userAction")
	
	select case actionString
		case "getCust"
			getCustomer()
		case "submit"
			updateGift()
			addLineItems()
			'addTicket()
			'addTicketItems()
			'gotoPickupScreen
			
			response.redirect "maintGiftCard.asp"
	end select
			
	function getCustomer()
		dim ssql
		dim rst
		
		cardNo = Request.Form("giftCardNum")
		ssql = "SELECT * FROM giftcard WHERE giftcardnumber = " & dbcreateqrystring(cardNo)
		set rst = getDisconnectedRecordset(ssql)
		if rst.Recordcount > 0 then
			cardId = rst.fields("giftcardid")
			curBal = FormatNumber(rst.fields("giftValue").value,2)
			customerSeq = rst.fields("customerSequenceNumber")

			if isNull(customerSeq) then customerSeq = 1 'counter customer

			ssql = "SELECT * FROM customer where customersequencenumber =" & customerSeq
			set rst = getDisconnectedRecordset(ssql)
			custId = trim(rst.fields("customerid"))
			custName = rst.fields("customerName")
			session("customerName") = custName
			session("customersequencenumber") = customerSeq
			fullCust = custName & " (" & custId & ")"
			getCustomerDetails

		else
			Session("errorMessage") = "Card number is not a valid gift card number."
			Response.Redirect "ErrorMessages.asp"
		end if	
	end function		
	
	sub getCustomerDetails()
		dim ssql
		dim objResultSet
		ssql = "Select IsNull(starchPreferenceName, '') as starchPreferenceName, IsNull(finishPreferenceName, '') as finishPreferenceName, isnull(defaultPriceListId, (select min(pricelistid) from pricelist)) as defaultPriceListId, " _
				& " IsNull(firstName, '') as firstName, IsNull(middleInitial,'') as middleInitial, " _
				& " IsNull(lastName, '') as lastName, Isnull(mainAreaCode, '') as mainAreaCode, " _
				& " isnull(mainPhone, '') as mainPhone, vipExpiryDate, vipQualAmount, " _
				& " vipEligible, vipQualified, referralQualified, routeNumber, dbo.getCustomerVisits(customer.customersequencenumber, null, null) as visitCount, " _
				& " IsNull(screenNotes,'') as screenNotes from customer where customerSequenceNumber=" _
				& clng(customerseq)

		Set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Recordcount > 0 then	
			objResultSet.MoveFirst
			areaCode = objResultSet.fields("mainAreaCode")
			custPhone = objResultSet.fields("mainPhone")
			if len(Trim(custPhone)) > 0 then
				if len(Trim(areaCode)) > 0 then
					custPhone = areaCode & "-"  & Mid(custPhone,1,3) & "-" & Mid(custPhone,4,len(custPhone))
				end if
			end if
			session("customermainphone") = custPhone
			custVisitCount = objResultSet.Fields("visitCount").Value
			pricelistID = objResultSet.Fields("defaultPriceListId").Value
			routeNumber = objResultSet.Fields("routeNumber").Value
		end if
	end sub

	function updateGift()
		dim ssql
		dim objRst
		dim giftProgramId 
		dim expDate
		
		giftProgramId = 1
		collectDataFromForm
		ssql = "select validDays + getDate() as expDate, taxCode from giftProgram where giftprogramid = " & giftProgramId
		set objRst = getDisconnectedRecordSet(ssql)
		if objRst.Recordcount > 0 then	
			taxCode = objRst.fields("taxCode")
			expDate = objRst.fields("expDate")
		else 
			Session("errorMessage") = "Gift Card Program has not been set up.  Please go back and set up gift card program from setup menu."
			Response.Redirect "ErrorMessages.asp"
		end if	
		
		ssql = "UPDATE giftcard SET giftvalue = " & newBal & ", expirationDate = " & dbcreateqrystring(expDate) & " where giftCardid = " & cardId
		QryExecute(ssql)

		if not (isEmpty(taxCode) or isnull(taxCode)) then
			ssql = "select * from tax where taxCode = " & taxCode & " and storeid = " & storeid
			set objRst = getDisconnectedRecordSet(ssql)
			taxPercent = objRst.Fields("taxPercent").value
			taxDesc = objRst.Fields("description").value
		else
			taxPercent = 0
			taxDesc = "" 
		end if		
	end function	

	function collectDataFromForm()
		cardNo = Request.Form("giftCardNum")
		cardId = Request.Form("giftCardID")
		curBal = Request.Form("curBal")
		addAmt = Request.Form("amtPaid")
		customerSeq = Request.Form("customerSeq")
		pricelistId = Request.Form("pricelistId")
		routeNumber = Request.Form("routeNumber")
		fullCust = Request.Form("custName") & " (" & Request.Form("custId") & ")"
		newBal = ccur(curBal) + ccur(addAmt)
	end function		
		
	function addLineItems()
		'calculate tax
		taxAmount = Round(addAmt*(CDbl(taxPercent)/100),2)
		invoiceTotal = addAmt + taxAmount
		
		set LI = server.CreateObject("ADODB.recordset")
	    LI.Fields.Append "lineNumber", adInteger
		LI.Fields.Append "parentLineNumber", adInteger
		LI.Fields.Append "deptId", adInteger, , adFldIsNullable
		LI.Fields.Append "deptName", adVarChar, 64, adFldIsNullable
		LI.Fields.Append "itemType", adVarChar, 20
		LI.Fields.Append "lineItemId", adInteger, , adFldIsNullable
		LI.Fields.Append "itemName", adVarChar, 64, adFldIsNullable
		LI.Fields.Append "originalUnitPrice", adDouble
		LI.Fields.Append "unitPrice", adDouble
		LI.Fields.Append "quantity", adInteger, , adFldIsNullable
		LI.Fields.Append "lineItemTotal", adDouble
		LI.Fields.Append "totalTax", adDouble
	    LI.Fields.Append "totalSurcharge", adDouble
		LI.Fields.Append "prepay", adDouble
		LI.Fields.Append "taxableAmt", adDouble
		LI.Fields.Append "daysToProcess", adInteger, , adFldIsNullable
		LI.Fields.Append "notes", adVarChar, 255, adFldIsNullable
		LI.Fields.Append "balance", adDouble
		LI.Fields.Append "upchargeTotal", adDouble, , adFldIsNullable
		LI.Fields.Append "colorTotal", adDouble, , adFldIsNullable
		LI.Fields.Append "patternTotal", adDouble, , adFldIsNullable
		LI.Fields.Append "discountable", adBoolean, , adFldIsNullable
		LI.Fields.Append "couponable", adBoolean, , adFldIsNullable
		LI.Fields.Append "VIPDiscountable", adBoolean, , adFldIsNullable
		LI.Fields.Append "VIPQualified", adBoolean, , adFldIsNullable
		LI.Fields.Append "parentId", adInteger, , adFldIsNullable
		LI.Fields.Append "saleOnly", adBoolean, , adFldIsNullable
		LI.Fields.Append "chargeTaxCode", adInteger, , adFldIsNullable
		LI.Fields.Append "pkgQuantity", adInteger, , adFldIsNullable
		LI.Fields.Append "peNotes", adVarChar, 255, adFldIsNullable
		LI.CursorLocation = adUseClient
		LI.Open
		Set LI.ActiveConnection = Nothing
		'Add line for Gift Card
		LI.AddNew Array("lineNumber", "parentLineNumber", "deptId", _
                "deptName", "itemType", "lineItemId", "itemName", _
                "originalUnitPrice", "unitPrice", "quantity", "lineItemTotal", _
                "totalTax", "totalSurcharge", "prepay", _
                "taxableAmt", "daysToProcess", "notes", "balance", _
                "upchargeTotal", "colorTotal", "patternTotal", _
                "discountable", "couponable", "VIPDiscountable", _
                "saleOnly", "VIPQualified", "pkgQuantity", "peNotes"), _
				Array(1, -1, deptId, "SpecialOffers", "SO", 1, "Gift Card", _
				addAmt, addAmt, 1, addAmt, taxAmount, 0, 0, _
				addAmt, Null, Null, invoiceTotal, 0, 0, 0, _
				Null, Null, Null, Null, Null, 1, Null)
		'Add line for Tax
		if not (isempty(taxCode) or isnull(taxCode)) then
			LI.AddNew Array("lineNumber", "parentLineNumber", "deptId", _
                "deptName", "itemType", "lineItemId", "itemName", _
                "originalUnitPrice", "unitPrice", "quantity", "lineItemTotal", _
                "totalTax", "totalSurcharge", "prepay", _
                "taxableAmt", "daysToProcess", "notes", "balance"), _
                Array(2, -1, deptId, "SpecialOffers", "TA", taxCode, rtrim(taxDesc), 0, 0, 1, taxAmount, 0, 0, 0, 0, 0, Null, 0)
        end if         
	end function              
	
	function addTicket()
		dim firstVisit
		dim ssql
		dim objResultSet
		
		if custVisitCount = 0 then
			firstVisit = 1
		else
			firstVisit = 0
		end if		

		ssql = "exec InsertTicket " _
			& storeid _
			& "," & dbcreateqrystring(NULL) _
			& "," & dbcreateqrystring("D") _
			& "," & dbcreateqrystring("AC") _
			& "," & priceListId _
			& "," & routeNumber _ 
			& "," & employeeId _
			& "," & dbcreateqrystring(now) _
			& "," & customerSeq _
			& "," & dbcreateqrystring(NULL) _
			& "," & dbcreateqrystring(NULL) _
			& "," & 0 _
			& "," & terminalId _
			& "," & 0 _
			& "," & invoiceTotal _
			& "," & dbcreateqrystring(NULL) _
			& "," & dbcreateqrystring(NULL) _
			& "," & firstVisit _
			& "," & 0 _
            & "," & 0 _
            & "," & 0 _
            & "," & 0 _ 
            & "," & invoiceTotal _
            & "," & 0 _
            & "," & 0 _
            & "," & 0 _
            & "," & 0 _            
            & "," & dbcreateqrystring(empName) _
            & "," & dbcreateqrystring(storeName) _
            & "," & 0 _
            & "," & dbcreateqrystring(Null)

		Set objResultSet = getDisconnectedRecordSet(ssql)
		ticketNo = objResultSet.Fields("TicketNumber").Value
		invoiceNo = objResultSet.Fields("InvoiceNumber").Value
	end function	
	
	function addTicketItems()
		Dim ssql
		
		LI.MoveFirst
		While Not LI.EOF 
			ssql = "INSERT INTO TicketLineItem(ticketNumber, lineItemNumber, " _
                & " createdByEmployeeID, lastModifiedByEmployeeID, " _
                & " parentLineNumber, displaySequence, departmentID, " _
                & " departmentName, ticketLineType, lineItemID, saleOnly, " _
                & " lineItemName, originalUnitPrice, unitPrice, quantity, " _
                & " lineItemTotal, totalTaxPercent, totalSurchargePercent, " _
                & " lineItemTaxableAmount, itemNotes, " _
                & " outsideService, totalUpchargeAmount, chargeTaxCode, packagedQuantity) VALUES(" _
                & ticketNo & "," & LI.Fields("lineNumber").Value _
                & "," & employeeId & "," & employeeId & "," & LI.Fields("parentLineNumber").Value & "," _
                & LI.Fields("lineNumber").Value & "," & LI.Fields("deptId").Value & ",'" _
                & LI.Fields("deptName").Value & "','" & LI.Fields("itemType").Value & "'," _
                & LI.Fields("lineItemId").Value & "," _
                & 0 & ",'" & LI.Fields("itemName").Value & "'," _
                & LI.Fields("originalUnitPrice").Value & "," _
                & LI.Fields("unitPrice").Value & "," & LI.Fields("quantity").Value & "," _
                & LI.Fields("lineItemTotal").Value & "," _
                & LI.Fields("totalTax").Value & "," & LI.Fields("totalSurcharge").Value & "," _
                & LI.Fields("taxableAmt").Value & "," _
                & "NULL, 0, 0, NULL, 1)"
			QryExecute(ssql)
			LI.MoveNext
		Wend
	end function	
	
	sub goToPickUpScreen()
		dim pickupObj
		dim invoicesTotalInfo
		dim invTotal
		dim totalAmtPaid
		dim amountDue
		dim totalcredits
		dim totalearlyPay
		dim ssql
		dim rackStr
		dim aInvoice
		
		customerseq=Request.Form("customerSeq")
		
		ssql = "Select distinct ticket.ticketNumber, customer.customername, ticket.customersequencenumber as customersequencenumber, " _
		& " tc.multiplepickup, tc.multiPickupCustomerName, tc.multiPickupLocation, " _
		& " invoiceNumber, convert(varchar, ticket.createdDate, 101) as 'DateIn', " _
		& " convert(varchar,dueDate,101) as 'DateDue',  invoiceTotal, IsNull(netTotal, 0) as netTotal, " _
		& " amountPaid From Ticket, Customer, ticketCustomer tc Where invoiceNumber='" & invoiceNo _
		& " ' AND ticketStatus='AC' AND invoiceType='D' AND onHold=0  " _
		& " and ticket.ticketnumber = tc.ticketnumber AND Ticket.customersequencenumber = Customer.customersequencenumber " _
		& " Order By DateIn ASC"

		set pickupInvoicesRst = getDisconnectedRecordset(ssql)
		
		invTotal = pickupInvoicesRst.Fields("invoiceTotal").value
		
		set Session("pickupInvoices") = pickupInvoicesRst
		set pickupInvoices = Server.CreateObject("Scripting.Dictionary")
		Set aInvoice = Server.CreateObject("ShahCorpComponents.pickupInvoice")
		aInvoice.DBConnectionString = Session("shahcorpDSN")
		aInvoice.ticketNumber = ticketNo
		aInvoice.invoiceNumber = pickupInvoicesRst.Fields("invoiceNumber").Value
		aInvoice.amountPaid = pickupInvoicesRst.Fields("amountPaid").Value
		aInvoice.invoiceTotal = pickupInvoicesRst.Fields("netTotal").Value
		pickupInvoices.Add ticketNo, aInvoice

		set pickupObj =Server.CreateObject("ShahCorpComponents.pickup")
		pickupObj.DBConnectionString = Session("shahcorpDSN")
		pickupObj.storeId = storeId
		pickupObj.initStorePaymentTypeInfo()
		Set pickupObj.pickupInvoices = pickupInvoices
		pickupObj.userAction = "pickup"
		pickupObj.custSeqNumber = customerSeq
		pickupObj.invoicesTotal = invTotal
		pickupObj.amountDue = invTotal
		pickupObj.populateLineItemsToDisplay
		set Session("pickupObj") = pickupObj
		Set Session("pickupInvoices") = Nothing
		Set Session("ticketDepartment") = Nothing
		Set Session("ticketRack") = Nothing
		session("invoicelist") = pickupObj.getInvoiceNosForPrinting()
		Response.Redirect "pickup.asp?target=pickup&userAction=pickup&targetPage=issueGiftCard.asp"
	end sub
	
%>	
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Gift Card Maintenance</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function goForward() {
	    clearConfirmMsg();
	    document.addValueForm.action = "?userAction=submit";
		document.addValueForm.submit();
	}
	
	function cancelForm() {
		document.addValueForm.action="maintGiftCard.asp";
		document.addValueForm.submit()
	}	
	
	function getCustomer() {
		document.addValueForm.action= "?userAction=getCust"
		document.addValueForm.submit();
	}

	function submitForm() {
		var qReturn, giftCard, addAmt, nBal
		returnValue = true;
		giftCard = document.addValueForm.giftCardNum.value;
		if (!checkFieldMissing(giftCard)) {
			returnValue = false;
			show_focus("Must enter Gift Card Number", "Gift Card Number", document.addValueForm.giftCardNum)
			return returnValue;
		}
		addAmt= document.addValueForm.amtPaid.value;
		if (!checkFieldMissing(addAmt)) {
			returnValue = false;
			show_focus("Must enter amount to add", "Add Value", document.addValueForm.amtPaid)
			return returnValue;
		}
		if (isNaN(addAmt)) {
			returnValue = false;
			show_focus("Additional amount must be numeric","Add Value", document.addValueForm.amtPaid)
			return returnValue;
		}	
		nBal = parseFloat(document.addValueForm.curBal.value) + parseFloat(addAmt);
		var msg = "New balance will be " + parseMoney(nBal) + ". Do you wish to continue?"
		cbs_confirm(msg, goForward);
	}
	
	function decimalFormat() {
		var price;
		
		price = document.addValueForm.amtPaid.value;
		price = trim(price);
		if(price.length > 0) {
			price = cleanNumeric(price);
			if(price == "")	{
				show_focus("Enter valid amount.","CBS Error", document.addValueForm.amtPaid);
				return;
			}
		}
		document.addValueForm.amtPaid.value = autoFormatCurrency(document.addValueForm.amtPaid.value);
		//captureKeyUpEvent("amtPaid"); //added by vivek on 02 Feb 2003
		
	}
	
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Add Value to Gift Card</B>
<FORM id="addValue" name="addValueForm" action="addValue.asp" method="Post">
<INPUT type="hidden" name="customerSeq" value="<%=customerSeq%>">
<INPUT type="hidden" name="pricelistId" value="<%=pricelistID%>">
<INPUT type="hidden" name="routeNumber" value="<%=routeNumber%>">
<INPUT type="hidden" name="newBal" value="<%=newBal%>">
<INPUT type="hidden" name="giftCardID" value="<%=cardId%>">
<INPUT type="hidden" name="custName" value="<%=custName%>">
<INPUT type="hidden" name="custId" value="<%=custId%>">
<TABLE ALIGN=center WIDTH=400px BORDER=1 CELLSPACING=1 CELLPADDING=10>
	<TR><TD>
	<TABLE ALIGN=center WIDTH=100% BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR height=40px><TD align=center colspan=2><b>Enter Gift Card Number and TAB to update<br>Customer and Current Balance Fields</b></td></tr>
		<TR height=40px><TD align=right width=40%>
			<LABEL for=giftCardNum>Gift Card Number&nbsp</LABEL>
			</TD>
			<TD width=60%>
			<INPUT CLASS=text name=giftCardNum style= width:160px onchange="getCustomer()" value="<%=cardNo%>">
		</TD></TR>
		<TR height=40px><TD align=right>
			<LABEL for=custName>Customer:&nbsp</LABEL>
			</TD>
			<TD>
			<b><%if fullCust = "" then Response.Write("") else Response.Write(fullCust) end if%></b>
			</TD></TR>
		<TR height=40px><TD align=right>
			<LABEL for=curBal>Current Balance&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=curBal readonly style= width:60px value="<%=curBal%>">
		</TD></TR>
		<TR height=40px><TD align=right>
			<LABEL for=amtPaid>Amount To Add&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=amtPaid style= width:60px value="<%=addAmt%>" onchange="newBalance()" onKeyup="decimalFormat();">
		</TD></TR>
		<TR height=10px><td></td></tr>
		<TR height=80px><TD ALIGN=CENTER COLSPAN=2 valign=bottom>
			<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
		</TD></TR>
	</TABLE>
	</TD></TR>
</TABLE>	
</FORM>   

</BODY>
</HTML>
