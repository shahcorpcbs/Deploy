<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim isSubmitted
	dim customerseq
	dim loyaltyid, lCardNo, lexpDate, lenable
	dim sqltxt
	dim discountid
	dim chkodq
	dim l_storeid
	dim actionString
	dim referredby
	dim referredby_CustomerName
	dim accountDiscount
	dim chkSCExempt
	dim chkTaxExempt
	
	isSubmitted = Request.QueryString("Submitted")
	referredby = Request.QueryString("referredby")
	
	customerseq = trim(Request.QueryString("customerseq"))

	if customerseq = "" then
		customerseq = session("customersequencenumber")
	else
		session("customersequencenumber") = customerseq
	end if
	
	session("prevcustomersequencenumber") = customerseq
	
	
	if isSubmitted then
		loyaltyid = Request.QueryString("loyaltyid")
		updateDatabase()	
	end if

	l_storeid = session("storeid")
	actionString=Request.QueryString("userAction")

	select case actionString
		case "getExisting"
			loyaltyId = Request.QueryString("loyaltyId")
			if IsEmpty(loyaltyId) or isNull(loyaltyId) then
				loyaltyId = "-1"
			else	
				getExistingLoyalty
			end if
		case "setaccountdiscount"
			setAccountDiscount customerseq, request.querystring("accountDiscount")
	end select	

	
	getCustDiscountInfo()
	
	
	function setAccountDiscount(customersequencenumber, accountDiscount)
		dim query, rs
		
		query = " update customer set accountdiscount = " & accountDiscount
		query = query & " where customersequencenumber = " & customersequencenumber
		
		qryexecute query
	end function
	
	sub getExistingLoyalty
		dim ssql
		dim rst
		ssql = "Select l.loyaltyid, l.name, lc.loyaltyCardid, lc.expirationDate, lc.enabled from " _
			& "loyalty l, LoyaltyCustomer lc where l.loyaltyid = lc.loyaltyid and lc.customerSequenceNumber =" & customerseq &_
			" and l.loyaltyid = "&loyaltyid
		set rst = getDisconnectedRecordset(ssql)
		lCardNo = rst.fields("loyaltyCardid")
		lexpDate = rst.fields("expirationDate")
		lenable = rst.fields("enabled")
		if (lenable) then
			lenable = 1
		else
			lenable = 0
		end if
	end sub			
	
	function getCustDiscountInfo()
		dim rstTemp
	
		sqltxt = "select OnDemandQualified, accountDiscount, taxExempt, surchargeExempt from customer where customersequencenumber = " & customerseq
	
		set rsttemp= getdisconnectedrecordset(sqltxt)
		if not rstTemp.BOF and not rstTemp.EOF then
			accountDiscount = rsttemp("accountDiscount")
			if rsttemp("surchargeExempt")  then
				chkSCExempt = "CHECKED"
			end if
			if rsttemp("taxExempt")then
				chkTaxExempt = "CHECKED"
			end if
			
			if rsttemp("OnDemandQualified") then
				chkodq = "CHECKED"
			end if
			rstTemp.close
		end if
		set rsttemp = nothing
		sqltxt = "select min(loyaltyid) as loyaltyid from loyaltyCustomer where customersequencenumber=" & customerseq
		set rstTemp = getDisconnectedRecordset(sqltxt)
		loyaltyid = rsttemp.fields("loyaltyid")
		if IsEmpty(loyaltyId) or IsNull(loyaltyId) then
			loyaltyId = "-1"
		else	
			getExistingLoyalty
		end if	
		
		if referredby = "" then
			referredby_CustomerName = ""
			
			sqltxt = "select c.customername, c.customersequencenumber from customerreferral cr, customer c where cr.customersequencenumber = " & customerseq & " and c.customersequencenumber = cr.referredby"
			
			set rsttemp= getdisconnectedrecordset(sqltxt)
			
			if rsttemp.recordcount > 0 then
				referredby_CustomerName = rsttemp("customername")
				referredby = rsttemp("customersequencenumber")
			end if
			
			set rsttemp = nothing
		else	
			sqltxt = "select customername from customer where customersequencenumber = " & referredby
			
			set rsttemp= getdisconnectedrecordset(sqltxt)
			
			if rsttemp.recordcount > 0 then
				referredby_CustomerName = rsttemp("customername")
			end if
			
			set rsttemp = nothing
		end if	
		
	end  function
	
	Function updateDatabase()
		dim discount_count
		dim i
		dim deleteDiscountIDList
		dim expireDate
		dim rs
		
		discount_count = 0
		if (customerseq <> "") and not isnull(customerseq) then
			dim  s_vip
				sqltxt = "Update customer set " _
		               & " OnDemandQualified = " & evalRequestValue(Request.Form("chkODQualification"))  _
		               & " ,taxExempt = " & evalRequestValue(Request.Form("chkTaxExempt"))  _
		               & " ,surchargeExempt = " & evalRequestValue(Request.Form("chkSCExempt"))  _
		               & " where customersequencenumber = " & customerseq

             dim query
                query = "select onDemandQualified from customer where customerSequenceNumber = " & customerseq
                set rs = getdisconnectedrecordset(query)

            'If the customer was not previously ondemandQualified and is now, reset their current level for the any coupons/credits
		    if rs("onDemandQualified") = 0 and evalRequestValue(Request.Form("chkODQualification")) = 1 then
				query = "insert into OnDemandCouponsAwarded (odcid, customersequencenumber, date, cri_value) " _
					  & " (select ondemandcoupon.id, " & customerseq & ", getdate(), " _
					  & " case ondemandcoupon.Cri_Target when 'VISITS' then cast(dbo.getCustomerVisits(" & customerseq & ", null, null) as money) " _
					  & " else dbo.getCustomerSalesWoOnAccount(" & customerseq & ", null, null) end " _
					  & " from ondemandcoupon) "
				qryexecute query
		    end if

			DbstartTrans()
			QryExecuteWithTrans(sqltxt)
      deleteDiscountIDList = ""
			discount_count = Request.Form("chkdiscount").Count
			if discount_count > 0 then
				for i = 1 to discount_count
				  sqltxt = " select discount.periodDays, discount.periodLimit, customerdiscount.discountID "
				  sqltxt = sqltxt & " from discount left outer join customerdiscount on "
          sqltxt = sqltxt & " discount.discountid = customerdiscount.discountid  AND CustomerDiscount.customerSequenceNumber = " & customerseq
          sqltxt = sqltxt & " where discount.discountid = " & Request.Form("chkdiscount")(i)

			    if deleteDiscountIDList <> "" then deleteDiscountIDList = deleteDiscountIDList & ","
			    deleteDiscountIDList = deleteDiscountIDList & Request.Form("chkdiscount")(i)

				  set rs = dbSelect(sqltxt)
				  
				  expireDate = ""
				  
				  if not isnull(rs("periodDays")) then
				    expireDate = dateadd("d", date(), rs("periodDays"))
				  end if
				  
				  if isnull(rs("discountID")) then
  					sqltxt = "insert customerdiscount (customersequencenumber, discountid, dateexpires) values (" _
  								& customerseq _
  								& "," & Request.Form("chkdiscount")(i) _
  								& "," & DbCreateQryString(expireDate) _
  								& ")"

            QryExecuteWithTrans(sqltxt)
				  end if
				  
				  set rs = nothing

					
				next  		

			end if
			
			sqltxt = " delete customerdiscount from "
      sqltxt = sqltxt & " customerdiscount inner join discount on "
      sqltxt = sqltxt & " customerdiscount.discountid = discount.discountid "
      sqltxt = sqltxt & " where customerdiscount.customersequencenumber = " & customerseq
      sqltxt = sqltxt & " and discount.periodlimit is null "
      if deleteDiscountIDList <> "" then
        sqltxt = sqltxt & " and discount.discountid not in (" & deleteDiscountIDList & ")"
      end if
      QryExecuteWithTrans(sqltxt)
      
			DbEndTrans()
			'if not (isEmpty(loyaltyId) or isNull(loyaltyId)) then
			if not (loyaltyId = -1) then
				DbstartTrans()
				sqltxt = "update loyaltycustomer set enabled = " & evalRequestValue(Request.Form("enableLoyalty")) _
					& " where customersequencenumber = " & customerseq & " and loyaltyid =" & loyaltyid
				QryExecuteWithTrans(sqltxt)
			DbEndTrans()	
			end if	

			
			if referredby <> "" then
				DbstartTrans()
				
				sqltxt = "delete customerreferral where customersequencenumber = " & customerseq
				QryExecuteWithTrans(sqltxt)
			
				sqltxt = "insert customerreferral (customersequencenumber, referredby) values(" & customerseq & ", " & referredby & ")"
				QryExecuteWithTrans(sqltxt)
				
				DbEndTrans()
			end if
		end if
		response.redirect("customerEntry.asp?mode=edit")
	end function
	
	function getAllLoyalty()
		dim ssql
		ssql = "Select l.loyaltyId, l.Name from loyalty l, " _
			& "loyaltycustomer lc where l.loyaltyid = lc.loyaltyid and lc.customersequencenumber = " & Customerseq 
		set getAllLoyalty = getDisconnectedRecordset(ssql)
	end function
	
%>
<HTML>
<HEAD>
<TITLE>Customer Discount</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">
	function submitForm(){
		var loyaltyid
		var index
		var referredBy
		referredBy = document.customerdiscountform.referredBy.value;
		loyaltyid = document.customerdiscountform.loyId.value;
		if (loyaltyid != "-1") {
			index = document.customerdiscountform.loyaltyType.selectedIndex;
			loyaltyid = document.customerdiscountform.loyaltyType[index].value;
		}
		document.customerdiscountform.action="?customerseq=<%=customerseq%>&Submitted=true&loyaltyid=" + loyaltyid + "&referredby=" + referredBy;
		document.customerdiscountform.submit();
	}

	function cancelForm(){
		document.customerdiscountform.action = "\\MainApp\\CustomerEntry.asp?mode=edit";
		document.customerdiscountform.submit();
	}
	
	function getLoyaltyDetails(){
		var loyaltyid
		var index
		index = document.customerdiscountform.loyaltyType.selectedIndex;
		loyaltyid = document.customerdiscountform.loyaltyType[index].value;
		document.customerdiscountform.action = "?customerseq=<%=customerseq%>&userAction=getExisting&loyaltyid=" + loyaltyid;
		document.customerdiscountform.submit();
	}
	function selectReferral() {
		document.customerdiscountform.action = "customersearch.asp?userAction=customerdiscount";
		document.customerdiscountform.submit();
	}
	
	function viewDiscountHistory() {
		document.customerdiscountform.action = "/MainApp/discountHistory.asp?customerseq=<%=customerseq%>"
		document.customerdiscountform.submit();
    }
	
	
	function setAccountDiscount(accountdiscount) {
		document.customerdiscountform.action = "?userAction=setaccountdiscount&accountdiscount=" + accountdiscount;
		document.customerdiscountform.submit();
	}
	
	function createAccountDiscount() {
		document.customerdiscountform.action = "/MainApp/accountDiscount.asp?customerseq=<%=customerseq%>";
		document.customerdiscountform.submit();
	}

	function viewOnDemandStatus() {
		document.customerdiscountform.action = "/MainApp/customerondemand.asp?customerseq=<%=customerseq%>";
		document.customerdiscountform.submit();
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Discount</H1>
<CENTER>
<FORM id="customerdiscountform" name="customerdiscountform" action="" method="post">
<INPUT type="hidden" name="loyId" value="<%= loyaltyId%>">
<INPUT type="hidden" name="referredBy" value="<%= referredBy%>">
<TABLE WIDTH=400PX BORDER=1 cellpadding=10>
	<TR>
	<TD align="center"">

	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<!-- discount type selection -->
		<TR>

		<TD align=center valign= top class="label">
		<input style="margin:10px;" style="width:200px;height:40px;" type="button" value="Discount History" onclick="viewDiscountHistory();">
		<input style="margin:10px;" style="width:200px;height:40px;" type="button" value="On Demand Status" onclick="viewOnDemandStatus();">
		<h6>Promotion Type<h6>

				<TABLE style="border:1px ridge; width:300px" cellspacing="0">
				<tr>
					<td>&nbsp;</td>
					<td>Name</td>
					<td>Expires</td>
				</tr>
				<%
					dim rsdiscount
					
					sqltxt = "SELECT d.DiscountName,  ISNULL(cd.discountID, - 1) AS selected, cd.DateExpires, d.periodLimit, d.discountID as id "
					sqltxt = sqltxt & " FROM Discount d INNER JOIN "
					sqltxt = sqltxt & " Customer c ON d.priceListID = c.defaultPriceListID LEFT OUTER JOIN "
					sqltxt = sqltxt & " CustomerDiscount cd ON c.customerSequenceNumber = cd.customerSequenceNumber AND d.discountID = cd.discountID "
					sqltxt = sqltxt & " WHERE (c.customerSequenceNumber = " & customerseq & ") AND (LOWER(d.discountType) = 'pr') "

					set rsdiscount = getdisconnectedrecordset(sqltxt)
					
					while not(rsdiscount.eof or rsdiscount.eof)
				%>
				
					<tr <%if not(isnull(rsdiscount("periodLimit"))) then%>style="background:#ddd"<%end if%>>
						<td>
							<input type=checkbox name=chkdiscount style="height:28px;width:28px"
							<%if rsdiscount("selected") >= 0 and not(isnull(rsdiscount("periodLimit"))) then%>
                disabled
              <%end if%>
							<% if rsdiscount("selected") >= 0 then %>
							checked
							<% end if %>
							value="<%=rsdiscount("id")%>" />
						</td>
						
						<td>
							<%=rsdiscount("DiscountName")%>
						</td>
						
						<td>
							<input style="width:75px;text-align:center" readonly  name="promotion<%=rsdiscount("id")%>exp" value="<%=rsdiscount("dateexpires")%>"   />
			<!--			<input style="width:75px;text-align:center" readonly name="promotion<%=rsdiscount("id")%>exp" value="<%=rsdiscount("dateexpires")%>"  onClick="javascript:show_calendar('customerdiscountform.promotion<%=rsdiscount("id")%>exp');" /> -->
					
						</td>
					</tr>
				<%
						rsdiscount.movenext
					wend
					
					set rsdiscount = nothing
				%>
				</table>

				</TD>

	<TD>
		<TABLE>
		<tr><td align=center>
		<span class="label">Loyalty</span><br>
		<table style="border:1px ridge;width:300px">
		<tr height=30px>
			<td></td>
			<td>
				<select name=loyaltyType style="FONT-SIZE: 15px ;Width = 190px" onChange=getLoyaltyDetails()
					<% if loyaltyId="-1" then %>
						disabled
					<% end if %>>	
					<% dim rstLoyalty
							set rstLoyalty = getAllLoyalty()
							while not rstLoyalty.eof
								if loyaltyid = rstLoyalty.Fields("LoyaltyId") then %>
								<OPTION SELECTED VALUE="<%=rstLoyalty.Fields("LoyaltyId") %>">
									<%=rstLoyalty.Fields("Name")%>
								<% else %>
									<OPTION VALUE="<%=rstLoyalty.Fields("LoyaltyId") %>">
										<%=rstLoyalty.Fields("Name") %>
								<% end if 
									rstLoyalty.movenext
							wend
					%>
				</select>
			</td>
		</tr>		
		<TR height=30px>
			<TD width=40% align=right >Card Number&nbsp&nbsp</td>
			<td ><INPUT type=text readonly name=cardNo value="<%=lcardNo%>">
			</td>
		</tr>
		<tr>	
			<td align=right>Expires on&nbsp&nbsp</td>
			<td><INPUT type=text readonly name=expDate value="<%=lexpDate%>">
		</td></tr>
		<tr>
			<td align=right>
			<input type=checkbox name=enableLoyalty STYLE="Height=28px;width=28px" value="<%=lenable%>"
				<% if  loyaltyId="-1"  then %>
					disabled
				<% end if %>
				<% if lenable = 1 then %>
					checked
				<% end if %>	></td>
			<td>Enable Loyalty</td>
		</td></tr>	
		</table>
		</td></tr>
		
		<tr><td align=center>
			<span class="label">Referral</span>
			<table style="border:1px ridge; width:300px" cellpadding=4>
			<tr>
			
			<td><input type=button onclick="selectReferral()" value="Change"></td>
			<td><input readonly style="FONT-SIZE: 15px ;Width = 190px" value="<%=referredby_CustomerName%>"></td>
			
			</tr>
			</table>
			
		</td></tr>
		
		
		<tr><td align=center>
			<span class="label">Account Discount</span>
			<table style="border:1px ridge; width:300px" cellpadding=2>
			<tr align="center">
				<td>
					<input type="button" style="width:200px;height:40px;<%if accountDiscount = 0 or accountDiscount = -1 then%>background:yellow<%end if%>" value="Use Route" onclick="setAccountDiscount(-1)" >
				</td>			
			</tr>
			<tr align="center">
				<td>
					<input type="button" style="width:200px;height:40px;<%if accountDiscount = -2 then%>background:yellow<%end if%>" value="Use Billing Customer" onclick="setAccountDiscount(-2)" >
				</td>
			</tr>
			<tr align="center">
				<td>
					<input type="button" style="width:200px;height:40px;<%if accountDiscount = -3 then%>background:yellow<%end if%>" value="Use Parent Customer" onclick="setAccountDiscount(-3)">
				</td>
			</tr>
			<tr align="center">
				<td>
					<input type="button" style="width:200px;height:40px;<%if accountDiscount > 0 then%>background:yellow<%end if%>" value="Custom" onclick="createAccountDiscount()">
				</td>
			</tr>
			</table>
			
		</td></tr>
		

		</TABLE>
	</TD>

	<TABLE>
		<TR height=40px align=bottom>
			<TD class="label">
			<INPUT type="checkbox" name=chkTaxExempt id=chkTaxExempt STYLE="Height=28px;width=28px" <%=chkTaxExempt %>>				
			&nbsp&nbsp;Tax Exempt</TD>
			<TD class="label">
				<INPUT type="checkbox" name=chkSCExempt id=chkSCExempt STYLE="Height=28px;width=28px;" <%=chkSCExempt %>>
			&nbsp&nbsp;Surcharge Exempt
			</TD>
		</TR>
		
		<TR height=40px align=bottom>
			<TD class="label">
				<INPUT type="checkbox" name=chkODQualification id=chkODQualification STYLE="Height=28px;width=28px;" <%=chkodq %>>
			&nbsp&nbsp;On Demand Qualification
			</TD>
		</TR>

	</TABLE>
	
	<TR><TD colspan="2">
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=20px></tr>
		<TR height=80px>
			 <TD align =center>
				<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif);background-position=center"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
				<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);background-position=center" onClick="cancelForm()">
			</TD>
		</TR> 
	</TABLE>
	</TD></TR>
</TABLE>	
</FORM>   
</CENTER>
</BODY>
</HTML>

