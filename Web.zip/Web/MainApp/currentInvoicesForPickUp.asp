<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("targetpage")%>
<%
	'*******************************************************************
	'Name   :Current Invoices For Pick Up
    'Author : Poonam Gupta
    'Created: 24-Jun-2002
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 24-Jun-2002    Poonam			Original version
    ' 09-Sep-2003	 Johnston		Increased font size in select table
	'*****************************************************************
	
	dim pickupInvoicesRst
	dim customerName
	dim actionString
	dim pickupInvoices
	dim alertMessage
	dim targetPage
	dim allowNoRackPickup
	
	alertMessage = ""
	customerName = session("customerName")
	actionString = Request.QueryString("userAction")
	targetPage = trim(Request.QueryString("targetPage"))
	if targetPage = "" then
		targetPage = Request.Form("targetPage")
	end if
	session("invoicelist") = ""
	
	loadMiscOptions
	
	select case actionString
		case "chooseRacked"
				chooseRacked
		case "chooseDue"
				chooseDue
		case "cancel"
				cancelForm
		case "pickup"
				getSelectedInvoicesForPickup
		case else
				getInvoicesForPickUp
	end select
	
	'functions start here
	sub loadMiscOptions()
		dim ssql
		dim rs
		
		ssql = "select allowNoRackPickup from MiscSetup where StoreId = '" & Session("StoreId") & "'"
		set rs = getdisconnectedrecordset(ssql)
		
		if not rs is nothing then
			if rs.RecordCount > 0 then
			allowNoRackPickup = rs("allowNoRackPickup")
			end if
			
			rs.Close
			set rs = nothing
		end if
		

	end sub
	
	sub chooseRacked()
		dim rackStr
		dim aInvoice
		
		Set pickupInvoicesRst = Session("pickupInvoices")
		Set pickupInvoices = Server.CreateObject("Scripting.Dictionary")
		if pickupInvoicesRst.Recordcount > 0 then
			pickupInvoicesRst.MoveFirst
			while not pickupInvoicesRst.EOF
				ticketNo = pickupInvoicesRst.Fields("ticketNumber").Value
				rackStr = getRack(ticketNo)
				if len(trim(rackStr)) > 0 then
					Set aInvoice = Server.CreateObject("ShahCorpComponents.pickupInvoice")
						aInvoice.DBConnectionString = Session("shahcorpDSN")
					aInvoice.ticketNumber = ticketNo
					aInvoice.invoiceNumber = pickupInvoicesRst.Fields("invoiceNumber").Value
					aInvoice.amountPaid = pickupInvoicesRst.Fields("amountPaid").Value
					aInvoice.invoiceTotal = pickupInvoicesRst.Fields("netTotal").Value
					'aInvoice.netTotal = pickupInvoicesRst.Fields("netTotal").Value
					pickupInvoices.Add ticketNo, aInvoice
				end if
				pickupInvoicesRst.MoveNext
			wend
			goToPickUpScreen
		end if
	end sub
	
	sub chooseDue()
		dim aInvoice
		dim dateToday
		
		dateToday = FormatDateTime(Date(), vbShortDate)
		Set pickupInvoicesRst = Session("pickupInvoices")
		Set pickupInvoices = Server.CreateObject("Scripting.Dictionary")
		if pickupInvoicesRst.Recordcount > 0 then
			pickupInvoicesRst.MoveFirst
			while not pickupInvoicesRst.EOF
				ticketNo = pickupInvoicesRst.Fields("ticketNumber").Value
				if DateDiff("d", dateToday, pickupInvoicesRst.Fields("dateDue").Value) < 0 then
					Set aInvoice = Server.CreateObject("ShahCorpComponents.pickupInvoice")
						aInvoice.DBConnectionString = Session("shahcorpDSN")
					aInvoice.ticketNumber = ticketNo
					aInvoice.invoiceNumber = pickupInvoicesRst.Fields("invoiceNumber").Value
					aInvoice.amountPaid = pickupInvoicesRst.Fields("amountPaid").Value
					aInvoice.invoiceTotal = pickupInvoicesRst.Fields("netTotal").Value
					pickupInvoices.Add ticketNo, aInvoice
				end if
				pickupInvoicesRst.MoveNext
			wend
			goToPickUpScreen
		end if
	end sub
	
	sub getSelectedInvoicesForPickup()
		dim intLoop
		dim aInvoice
		
		Set pickupInvoicesRst = Session("pickupInvoices")
		Set pickupInvoices = Server.CreateObject("Scripting.Dictionary")
		for intLoop=1 to Request.Form("select").Count
			ticketNo = Request.Form("select")(intLoop)
			pickupInvoicesRst.Filter = "ticketNumber=" & ticketNo
			if pickupInvoicesRst.RecordCount > 0 then
				Set aInvoice = Server.CreateObject("ShahCorpComponents.pickupInvoice")
						aInvoice.DBConnectionString = Session("shahcorpDSN")
				aInvoice.ticketNumber = ticketNo
				aInvoice.invoiceNumber = pickupInvoicesRst.Fields("invoiceNumber").Value
				aInvoice.amountPaid = pickupInvoicesRst.Fields("amountPaid").Value
				aInvoice.invoiceTotal = pickupInvoicesRst.Fields("netTotal").Value
				pickupInvoices.Add ticketNo, aInvoice
			end if
			pickupInvoicesRst.Filter = adFilterNone
		next
		goToPickUpScreen
	end sub
		
	sub goToPickUpScreen()
		dim pickupObj
		dim invoicesTotalInfo
		dim invoiceTotal
		dim totalAmtPaid
		dim amountDue
		dim totalcredits
		dim totalearlyPay
		if pickupInvoices.Count > 0 then
			set pickupObj =Server.CreateObject("ShahCorpComponents.pickup")
			pickupObj.DBConnectionString = Session("shahcorpDSN")
			pickupObj.storeId = Session("storeID")
			pickupObj.initStorePaymentTypeInfo()
			Set pickupObj.pickupInvoices = pickupInvoices
			pickupObj.userAction = "pickup"
			pickupObj.custSeqNumber = session("CustomerSequenceNumber")
			invoicesTotalInfo= getTotalOfAllInvoices()
			invoiceTotal = invoicesTotalInfo(0)
			totalAmtPaid = invoicesTotalInfo(1) 
			totalearlyPay = getTotalEarlyPayDiscount()
			pickupObj.invoicesTotal = invoiceTotal
			totalcredits = pickupObj.getTotalCredits()
			if invoiceTotal <= 0 then
				totalcredits = 0
				totalearlyPay = 0
			end if
			pickupObj.totalAmtPaid = totalAmtPaid
			pickupObj.amountpaid = totalAmtPaid
			pickupObj.totalamountapplied = totalAmtPaid
			pickupObj.totalCredits =  totalcredits
			pickupObj.totalEarlyPayDiscount= totalearlyPay 
			'Response.Write totalcredits
			amountDue = invoiceTotal - totalAmtPaid - totalcredits - totalearlyPay
			'Response.write amountDue
			if amountDue >= 0 then
				pickupObj.amountDue = amountDue
			else
				pickupObj.amountDue =0
				pickupObj.changeDue =   0
				pickupObj.totalChangeDue = 0
				if totalAmtPaid >= (invoiceTotal - totalearlyPay) then 
					pickupObj.changeDue =   totalAmtPaid- invoiceTotal + totalearlypay
					pickupObj.totalChangeDue = totalAmtPaid- invoiceTotal + totalearlypay
				end if
			end if
			pickupObj.populateLineItemsToDisplay

			'added by steve gagnon - to keep prepay intact
			pickupObj.addPayment totalAmtPaid, "Prepay"

			set Session("pickupObj") = pickupObj
			Set Session("pickupInvoices") = Nothing
			Set Session("ticketDepartment") = Nothing
			Set Session("ticketRack") = Nothing
			Session("customerName") = customerName
			session("invoicelist") = pickupObj.getInvoiceNosForPrinting()
			Response.Redirect "pickup.asp?target=pickup&userAction=pickup"
		else
			alertMessage = "No Invoices to pick up."
		end if
	end sub
	
	function getTotalOfAllInvoices()
		dim invoicesTotal
		dim aInvoice
		dim counter
		dim invoicesArray
		dim totalAmtPaid
		
		invoicesTotal =0 
		totalAmtPaid =0
		invoicesArray = pickupInvoices.Items
		for counter =0 to pickupInvoices.Count -1
			set aInvoice = invoicesArray(counter)
			if Round(aInvoice.invoiceTotal, 2) < 0 then
				aInvoice.invoiceTotal = 0
			end if
			invoicesTotal = invoicesTotal +  Round(aInvoice.invoiceTotal, 2)
			totalAmtPaid = totalAmtPaid + Round(aInvoice.amountPaid,2)
		next
		getTotalOfAllInvoices = Array(invoicesTotal, totalAmtPaid)
	end function
	
	function getTotalEarlyPayDiscount()
		dim ssql
		dim objRecordset
		dim TotalEarlyPayDiscount
		dim aInvoice
		dim counter
		dim invoicesArray
		dim TicketNos		
		
		invoicesArray = pickupInvoices.Items
		set aInvoice = invoicesArray(0)
		ticketnos = aInvoice.ticketNumber
		'Response.write pickupInvoices.Count
		for counter = 1 to pickupInvoices.Count - 1
			set aInvoice = invoicesArray(counter)
			ticketnos = ticketnos & ", " &  aInvoice.ticketNumber
		next
		'Response.Write ticketnos
		
		TotalEarlyPayDiscount  = 0

		ssql= "select sum(round(isnull(t.netTotal * P.Discountpercent /100, 0), 2) ) as 'TotalEarlypayDiscount' from Ticket t, TicketpaymentTerm P" _
					& " where T.ticketnumber = P.Ticketnumber " _
					& " and t.ticketnumber in (" & ticketNos &  ") and t.nettotal > 0 "
		'Response.Write ssql					
		set objRecordset = getDisconnectedrecordset(ssql)
		if objRecordset.recordcount > 0 then
			if not isNull(objRecordset.fields("TotalEarlypayDiscount")) then
				TotalEarlyPayDiscount  = formatnumber(objRecordset.fields("TotalEarlypayDiscount"), 2,0,0,0)
			end if
		end if
		objRecordset.close
		set objRecordset = nothing
		getTotalEarlyPayDiscount = TotalEarlyPayDiscount
	end function
			
	sub cancelForm()
		dim custSeqNumber
		select case targetPage
			case "pickupSearch"
				Response.Redirect "pickupSearch.asp"	
			case "customerfunctions"
				custSeqNumber = Session("customersequencenumber")
				Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
		end select
	end sub
	
	sub getInvoicesForPickUp()
		dim custSeqNumber
		dim ssql
		dim ticketNos
		dim searchType
		dim invoiceNumber
		dim objRst
		dim getCustomerDetails
		dim notify
		getCustomerDetails = false
		targetPage = Request.QueryString("targetPage")
		select case targetPage
			case "pickupSearch"
				searchType = Request.QueryString("searchtype")
				select case searchType
					case "customer"
							custSeqNumber = Request.QueryString("customersequencenumber")
							ssql = "Select customername from Customer where " _
									& " customersequencenumber=" & custSeqNumber
							set objRst = getDisconnectedRecordset(ssql)
							if objRst.recordcount > 0 then
								customerName = objRst.Fields("customername")
								session("customerName") = customerName 
								Session("customersequencenumber") = custSeqNumber
							end if
							ssql = "Select distinct ticket.ticketNumber, ticket.CreatedDate, invoiceNumber, convert(varchar, ticket.createdDate, 101) as 'DateIn', " _
									& " tc.multiplepickup, tc.multiPickupCustomerName, tc.multiPickupLocation, " _
									& " convert(varchar,dueDate,101) as 'DateDue',  invoiceTotal, IsNull(netTotal,0) as netTotal, " _
									& " amountPaid From Ticket, ticketcustomer tc Where customersequencenumber=" & custSeqNumber _
									& " AND ticketStatus='AC' AND invoiceType='D' AND onHold=0 and ticket.ticketnumber = tc.ticketnumber" _
									& " order by ticket.CreatedDate"
					case "ticket"
							getCustomerDetails = true
							invoiceNumber = Request.QueryString("invoicenumber")
							ssql = "Select distinct ticket.ticketNumber, ticket.CreatedDate, customer.customername, ticket.customersequencenumber as customersequencenumber, " _
									& " tc.multiplepickup, tc.multiPickupCustomerName, tc.multiPickupLocation, " _
									& " invoiceNumber, convert(varchar, ticket.createdDate, 101) as 'DateIn', " _
									& " convert(varchar,dueDate,101) as 'DateDue',  invoiceTotal, IsNull(netTotal, 0) as netTotal, " _
									& " amountPaid From Ticket, Customer, ticketCustomer tc Where ticket.customersequencenumber in (select customersequencenumber from ticket where invoicenumber = '" & invoiceNumber & "')" _
									& "  AND ticketStatus='AC' AND invoiceType='D' AND onHold=0  " _
									& " and ticket.ticketnumber = tc.ticketnumber AND Ticket.customersequencenumber = Customer.customersequencenumber " _
									& " order by ticket.CreatedDate"
					end select
				
			case "customerfunctions"
				custSeqNumber = Session("customersequencenumber")
				notify = Request.QueryString("notify")
				if notify = "1" then	
					ssql = "Select distinct Ticket.ticketNumber, ticket.CreatedDate, invoiceNumber, convert(varchar, ticket.createdDate, 101) as 'DateIn', " _
						& " tc.multiplepickup, tc.multiPickupCustomerName, tc.multiPickupLocation, " _
						& " convert(varchar,dueDate,101) as 'DateDue',  invoiceTotal, IsNull(netTotal, 0) as netTotal," _
						& " amountPaid From Ticket, RackAssignment, ticketcustomer tc  Where customersequencenumber=" & custSeqNumber _
						& " AND ticketStatus='AC' AND invoiceType='D' AND onHold=0 and ticket.ticketnumber = tc.ticketnumber " _
						& " AND Ticket.ticketNumber = rackAssignment.ticketNumber order by ticket.CreatedDate"
				else
					ssql = "Select distinct ticket.ticketNumber, ticket.CreatedDate, invoiceNumber, convert(varchar, ticket.createdDate, 101) as 'DateIn', " _
						& " tc.multiplepickup, tc.multiPickupCustomerName, tc.multiPickupLocation, " _
						& " convert(varchar,dueDate,101) as 'DateDue', invoiceTotal, IsNull(netTotal, 0) as netTotal, " _
						& " amountPaid From Ticket, ticketcustomer tc Where customersequencenumber=" & custSeqNumber _
						& " AND ticketStatus='AC' AND invoiceType='D' AND onHold=0 and ticket.ticketnumber = tc.ticketnumber" _
						& " order by ticket.CreatedDate"
				end if
		end select
		set pickupInvoicesRst = getDisconnectedRecordset(ssql)
		if pickupInvoicesRst.Recordcount > 0 then
			if getCustomerDetails then
				customerName = pickupInvoicesRst.Fields("customername")
				session("customerName") = customerName 
				custSeqNumber = pickupInvoicesRst.Fields("customersequencenumber")
				Session("customersequencenumber") = custSeqNumber
			end if
			ticketNos = constructTicketNosStr	
			getTicketDepartmentInfo ticketNos
			getTicketRackInfo ticketNos
		end if			
		Set Session("pickupInvoices") = pickupInvoicesRst
	end sub

	function constructTicketNosStr()
		dim ticketNos
		pickupInvoicesRst.MoveFirst
		ticketNos = pickupInvoicesRst.Fields("ticketNumber").Value
		pickupInvoicesRst.MoveNext
		while not pickupInvoicesRst.Eof
			ticketNos = ticketNos &  "," & pickupInvoicesRst.Fields("ticketNumber").Value
			pickupInvoicesRst.MoveNext
		wend
		constructTicketNosStr = ticketNos
	end function
	
	sub getTicketDepartmentInfo(ticketNos)
		dim ssql
		dim departmentRst
				
		ssql = "Select Distinct departmentName, TicketNumber From TicketLineItem " _
				& " Where ticketNumber IN(" & ticketNos & ") Order by ticketNumber"
		set departmentRst = getDisconnectedRecordset(ssql)
		Set Session("ticketDepartment") = departmentRst
	end sub
	
	sub getTicketRackInfo(ticketNos)
		dim ssql
		dim RackRst
			
		ssql ="Select ticketNumber, racklocationstart, racklocationend from  rackAssignment " _
				& " where ticketNumber IN(" & ticketNos & ") Order by ticketNumber"
		set RackRst = getDisconnectedRecordset(ssql)
		Set Session("ticketRack") = RackRst
	end sub
	
	function getRack(ticketNo)
		dim rackStr
		dim RackRst
		rackStr = ""
		set RackRst = Session("ticketRack")
		if RackRst.Recordcount > 0 then
			RackRst.Filter = "ticketNumber=" & CLng(ticketNo)
			if RackRst.RecordCount > 0 then
				RackRst.MoveFirst
				while not RackRst.Eof
					if IsNull(RackRst.Fields("racklocationend").Value) then
						if rackStr = "" then
							rackStr = RackRst.Fields("racklocationstart").Value
						else
							rackStr =   rackStr & "," & RackRst.Fields("racklocationstart").Value
						end if
					else
						if rackStr = "" then
							rackStr = RackRst.Fields("racklocationstart").Value & "-" & RackRst.Fields("racklocationend").Value
						else
							rackStr =   rackStr & "," & RackRst.Fields("racklocationstart").Value & "-" & RackRst.Fields("racklocationend").Value
						end if
					end if
					RackRst.Movenext
				wend
			end if
			RackRst.Filter = adFilterNone
		end if
			getRack = rackStr
	end function
	
	function getDepartment(ticketNo)
		dim deptStr
		dim departmentRst
		
		deptStr =""
		Set departmentRst = Session("ticketDepartment")
		if departmentRst.RecordCount > 0 then
			departmentRst.Filter = "TicketNumber=" & ticketNo
			if departmentRst.RecordCount > 0 then
				departmentRst.MoveFirst
				while not departmentRst.Eof
					if deptStr = "" then
						deptStr = departmentRst.Fields("departmentName").Value
					else
						deptStr =   deptStr & ", " & departmentRst.Fields("departmentName").Value
					end if
					departmentRst.Movenext
				wend
			end if
			departmentRst.Filter = adFilterNone
		end if
		getDepartment = deptStr
	end function
		
%>	
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Current Invoices</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	var checkboxClicked=false;
	var alertMessage = null;
	function selectRow(element) {
		var childEl;
		if(!checkboxClicked){
			childEl = element.children[0];
			var rowChildNodes = childEl.children
			for(i=0; i<rowChildNodes.length; i++){
				childEl = rowChildNodes[i];
				if(childEl.tagName == "INPUT") {
					if(childEl.checked) {
						childEl.checked=false;
						element.style.background="white";
					}
					else{
						childEl.checked=true;
						element.style.background="#DBF2F4";
					}
					break;
				}
			}
		}
		checkboxClicked=false;
	}		
	
	function selectRowForCheckBox(element) {
		var parentEl;
		parentEl=element;
		while(parentEl.tagName != "TR") {
			parentEl = parentEl.parentElement;
		}
		if (element.checked){
			parentEl.style.background="#DBF2F4";
		}else{
			parentEl.style.background="white";
		}
		checkboxClicked=true;
	}
	
	function cancelForm() {
		document.currentInvoicesForPickup.action =  "?userAction=cancel";
		document.currentInvoicesForPickup.submit();
	}
	function processSelectedInvoice() {
		var total = 0;
		var ticketNo;
		var max ;
		if (invoiceTable.rows.length > 0) {
			max = document.currentInvoicesForPickup.select.length;
			for (i = 0; i < max; i++) {
				if (document.currentInvoicesForPickup.select[i].checked) {
				

					
					ticketNo = document.currentInvoicesForPickup.select[i].value;
					total += 1;
					if(total >1)
						break;
				}
			}
			if(total >1) {
				document.currentInvoicesForPickup.action =  "?userAction=pickup";
				document.currentInvoicesForPickup.submit();
			}
			if(total == 1) {
				document.currentInvoicesForPickup.action = "detailedInvoice.asp?userAction=edit&Ticketnumber=" + ticketNo;
				document.currentInvoicesForPickup.submit();
			}
			
		}
	}
	
		
	
	function pickupSelectedInvoice(){
		var total = 0;
		var max;

		if (invoiceTable.rows.length > 0) {
			max = document.currentInvoicesForPickup.select.length;

			for (i = 0; i < max; i++) {

				if (document.currentInvoicesForPickup.select[i].checked) {

					if(!(document.currentInvoicesForPickup.allowNoRackPickup.value == "True"))
					{
						if(max > 2)
						{
							if(document.currentInvoicesForPickup.rackinfo[i].value == "")
							{
								cbs_alert("Can not continue.\nSelected invoice(s) exist without racks.");
								return false;
							}
						}
						else
						{
							if(document.currentInvoicesForPickup.rackinfo.value == "")
							{
								cbs_alert("Can not continue.\nSelected invoice(s) exist without racks.");
								return false;
							}
						}
						
						
						total ++;
					}
					else
					{
						// previous code.. weird..
						total += 1;
						if(total >0)
						break;
					}	
				}
			}
			if(total>0){
				document.currentInvoicesForPickup.action =  "?userAction=pickup";
				document.currentInvoicesForPickup.submit();
			}
		}
	}
	
	function selectAllDueInvoices() {
		var total = 0;
		var max;
		if (invoiceTable.rows.length > 0) {
			max = document.currentInvoicesForPickup.select.length;

			for (i = 0; i < max; i++) {
					if(!(document.currentInvoicesForPickup.allowNoRackPickup.value == "True"))
					{
						if(max > 2)
						{
							if(document.currentInvoicesForPickup.rackinfo[i].value == "")
							{
								cbs_alert("Can not continue.\nSome invoice(s) exist without racks.");
								return false;
							}
						}
						else
						{
							if(document.currentInvoicesForPickup.rackinfo.value == "")
							{
								cbs_alert("Can not continue.\nSome invoice(s) exist without racks.");
								return false;
							}
						}
						
						total ++;
					}
					else
					{
						// previous code.. weird..
						total += 1;
						if(total >0)
						break;
					}	
			}
			if(total>0){
				document.currentInvoicesForPickup.action =  "?userAction=chooseDue";
				document.currentInvoicesForPickup.submit();
			}
		}
	}
	
	function selectAllRackedInvoices() {
		document.currentInvoicesForPickup.action =  "?userAction=chooseRacked";
		document.currentInvoicesForPickup.submit();
	}

	function checkForAlertMessages() {

		<%
			if Len(alertMessage) > 0 then
			Response.Write "alertMessage='"
			Response.Write alertMessage
			Response.Write "'" 
			end if
		%>
		if (alertMessage != null){
			cbs_alert (alertMessage);
		}
	}
	function proceedIfSingle(){

		if(document.currentInvoicesForPickup.targetPage.value == "pickupSearch" &&
			invoiceTable.rows.length == 2)
		{
			document.currentInvoicesForPickup.select[0].checked = true;
			pickupSelectedInvoice()
		}
	}
	
	function captureKeyUpEvent(element){
		
	  	if (event.keyCode == 13){
	  		event.returnValue = true;	
			pickupSelectedInvoice();
		}
	}			
</SCRIPT>
<BODY topmargin=0 leftmargin=0 onLoad="checkForAlertMessages()">
<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Current Invoices for Pick Up</B>
<FORM id="currentInvoicesForPickup" name="currentInvoicesForPickup" action="currentInvoicesForPickUp.asp" method="post">
	<INPUT type="hidden" name="targetPage" value="<%= targetPage%>">
	<INPUT type="hidden" name="allowNoRackPickup" value="<%= allowNoRackPickup%>">
<TABLE WIDTH="98%" align=center cellspacing="2" cellpadding="0" border="0">

	<!-- list -->
	<tr>
		<td>

			<TABLE name="invoiceTable" id="invoiceTable" WIDTH="100%" style="WIDTH: 100%;background-color:#AAAAFF" BORDER=0 CELLSPACING=1 CELLPADDING=1>
			<tr  class=head  style="padding-left:10px;text-align:left;font-size=18px;width=25%">
				<th width =10px></th>
				<th width=80px align=left class="label">Invoice Number</th>
				<th align=left class="label">Customer Name</th>
				<th align=left class="label">Date In</th>
				<th align=left class="label">Date Due</th>
				<th align=left class="label">Amount</th>
				<th align=left class="label">Department</th>
				<th align=left class="label">Rack Number</th>
			</tr>
								
				<%
					dim ticketNo
					Set pickupInvoicesRst = Session("pickupInvoices")
					if pickupInvoicesRst.Recordcount > 0 then
						pickupInvoicesRst.MoveFirst
						while not pickupInvoicesRst.EOF
							ticketNo = pickupInvoicesRst.Fields("ticketNumber").Value
				%>			<!-- Following lines modified by J.Johnston, 9Sep03-->
							<!-- Original font size was 12px-->
							<tr class=data  onClick="selectRow(this)" onKeyPress="captureKeyUpEvent(this)">
								<td width=10px><input type="checkbox" name="select" id="select" onClick="selectRowForCheckBox(this)" value="<%= ticketNo%>" ></td>
								<td STYLE="FONT-SIZE: 18px;"><%= pickupInvoicesRst.Fields("invoiceNumber").Value%></td>
								<% if pickupInvoicesRst("multiplePickup") = true then %>
									<td STYLE="FONT-SIZE: 18px;"><%= pickupInvoicesRst.Fields("multiPickupCustomerName").Value%>&nbsp<%= pickupInvoicesRst.Fields("multiPickupLocation").Value%></td>
								<%else%>
									<td STYLE="FONT-SIZE: 18px;"><%= customerName%></td>
								<%end if%>
								<td STYLE="FONT-SIZE: 18px;"><%= pickupInvoicesRst.Fields("DateIn").Value%></td>
								<td STYLE="FONT-SIZE: 18px;"><%= pickupInvoicesRst.Fields("DateDue").Value%></td>
								<td STYLE="FONT-SIZE: 18px;"><%= FormatCurrency(pickupInvoicesRst.Fields("netTotal").Value,2,-1,0)%></td>
								<td STYLE="FONT-SIZE: 18px;"><%= getDepartment(ticketNo)%></td>
								<td STYLE="FONT-SIZE: 18px;"><input readonly style="FONT-SIZE: 18px; border:0px; background:transparent;" type="label" name="rackinfo" value="<%= getRack(ticketNo)%>"></td>
							</tr>
							<!-- End modification by J.Johnston, 9Sep03-->
				<%
							pickupInvoicesRst.Movenext
						wend
					end if
				%>
			</table>
		</td>
	</tr>
	<!-- buttons -->
	<tr>
		<td align="center">
			<TABLE WIDTH="750px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
				<tr height=20px></tr>
				<tr>
					<td align="center" width=100px>
						<INPUT class=touch id=selectDueInvoices name=selectDueInvoices type=button value="" style="background-image:url(../images/Select-All-4.gif);" onClick="selectAllDueInvoices();"><br>Choose All Due And Continue
					</td>
					<td align="center" width=100px>
						<INPUT class=touch id=selectAllRacked name=selectAllRacked type=button value="" style="background-image:url(../images/Select-All-3.gif);" onClick="selectAllRackedInvoices();"><br>Choose All Racked And Continue
					</td>
					<td width=200px></td>
					<td align="center">
						<INPUT class=touch id=select name=select type=button value="" style="background-image:url(../images/Select.gif);" onClick="processSelectedInvoice()"><br>Select
					</td>
					<td align="center">
						<INPUT class=touch id=pickUp name=pickUp type=button value="" style="background-image:url(../images/Pick-up.gif);" onClick="pickupSelectedInvoice()"><br>Pick Up
					</td>
					<td align="center">
						<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm()">
					</td>
					<td width=30px></td>
				</tr>
			</table>
		</td>
	<tr>
</table>
</form>
</BODY>
</HTML>
