<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->


<!--#include file="../external/include.asp" -->
<!--#include file="../include/messages.asp" -->
<%
	include getBarcodeEncoderFilename()
	function getBarcodeEncoderFilename()
		on error resume next
		getBarcodeEncoderFilename = "/include/barcode.asp"
		getBarcodeEncoderFilename = getMSVar("BarcodeEncoderFile")
	end function
%>

<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim invoicesPending
	dim useSameRackLocation
	dim rackStartLocation
	dim rackEndLocation
	dim rackPrefix
	dim overrideChecked
	
	overrideChecked = len(Request.form("Override")) > 0
	rackPrefix = getReqVar("rackPrefix")
	UseSameRackLocation = trim(Request.Form("UseSameRackLocation"))

	if rackPrefix = "" then
		rackPrefix = getRackPrefix(session("storeid"))
	end if
	
	select case lcase(Request.QueryString("useraction"))
		case "rack"
			rackInvoiceData
			
			query = "Update MiscSetup Set UseSameRackLocation = '" & UseSameRackLocation & "' where storeID = '" & Session("StoreID") & "'"
		
			QryExecute query

		case "rackinvoices"
			dim forceRacking
			
			if Request.Form("lastUserAction") = "rackinvoices" then
				forceRacking = 1
			else
				forceRacking = 0
			end if
			
			query = "exec RackPendingRackLocations "
			query = query & Session("TerminalID") & ", NULL, " & forceRacking

			QryExecute query

		case "delete"
			DbStartTrans
			
			query = "insert into RackAssignmentDeletion(storeid, employeeid, ticketnumber, racklocationstart, racklocationend) "
			query = query & " SELECT RackAssignment.storeid, " & session("employeeid") & ", RackAssignment.ticketnumber, RackAssignment.racklocationstart, RackAssignment.racklocationend "
			query = query & " FROM RackAssignment INNER JOIN "
			query = query & " Ticket ON RackAssignment.ticketNumber = Ticket.ticketNumber INNER JOIN "
			query = query & " PendingRackLocations ON Ticket.invoiceNumber = PendingRackLocations.InvoiceNumber AND "
			query = query & " RackAssignment.rackLocationStart = PendingRackLocations.StartRackLocation AND (RackAssignment.rackLocationEnd IS NULL AND "
			query = query & " PendingRackLocations.EndRackLocation IS NULL OR "
			query = query & " RackAssignment.rackLocationEnd = PendingRackLocations.EndRackLocation) "
			query = query & " WHERE pendingracklocations.racklocationid in (" & Request.QueryString("invoices") & ")"
			dbInsert query
			
			query = "DELETE rackassignment "
			query = query & " FROM rackassignment INNER JOIN "
			query = query & " Ticket ON RackAssignment.ticketNumber = Ticket.ticketNumber INNER JOIN "
			query = query & " PendingRackLocations ON Ticket.invoiceNumber = PendingRackLocations.InvoiceNumber AND "
			query = query & " RackAssignment.rackLocationStart = PendingRackLocations.StartRackLocation AND (RackAssignment.rackLocationEnd IS NULL AND "
			query = query & " PendingRackLocations.EndRackLocation IS NULL OR "
			query = query & " RackAssignment.rackLocationEnd = PendingRackLocations.EndRackLocation) "
			query = query & " WHERE pendingracklocations.racklocationid in (" & Request.QueryString("invoices") & ")"
			dbInsert query
			
			query = "delete PendingRackLocations where racklocationid in (" & Request.QueryString("invoices") & ")"
			dbInsert query
			
			DbEndTrans
		case "remove"
			query = "delete PendingRackLocations where racklocationid in (" & Request.QueryString("invoices") & ")"
			QryExecute query
		case ""
			query = "select UseSameRackLocation from MiscSetup where storeID = '" & Session("StoreID") & "'"
			set rs = getdisconnectedrecordset(query)
			if not rs.eof then
				if rs("UseSameRackLocation") then
					UseSameRackLocation = 1
				else
					UseSameRackLocation = 0
				end if
			end if
			set rs = nothing
	end select

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function
	
	function getRackPrefix(storeid)
		dim query, rs
		
		query = " select rackprefix from miscsetup where storeid = " & storeid
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getRackPrefix = rs("rackPrefix")
		end if
	end function
	
	sub rackInvoice(InvoiceNumber, StartRackLocation, EndRackLocation, validRackLocation)
		query = "exec RackInvoice "
		query = query & Session("TerminalID") & ", "
		query = query & Session("EmployeeID") & ", "
		query = query & "'" & InvoiceNumber & "', "
		
		if StartRackLocation <> "" then
			query = query & "'" & StartRackLocation & "'"
		else
			query = query & "NULL"
		end if

		if StartRackLocation <> EndRackLocation then
			query = query & ", '" & EndRackLocation & "'"
		else
			query = query & ", NULL"
		end if

		query = query & ", " & validRackLocation
		
		QryExecute query
	end sub

	function getInvoiceNumberFromTicket(ticketNumber)
		dim query, rs

		query = " select invoicenumber from ticket where ticketnumber = " & ticketNumber
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getInvoiceNumberFromTicket = rs("invoicenumber")
		end if

		set rs = nothing

	end function
	
	function getStorePrefix(storeID)
		dim query, rs

		query = " select ticketprefix from store where ticketprefix is not null and ticketprefix <> '' and storeid = " & storeID
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getStorePrefix = rs("ticketprefix")
		end if

		set rs = nothing
	end function

	sub rackInvoiceData()
		dim InvoiceNumber, StartRackLocation, EndRackLocation
		dim rackData
		dim i
		dim validRackLocation
		dim encoder
		dim storePrefix
		
		rackData = split(Request.Form("rackData"), "|")
		
		storePrefix = getStorePrefix(session("storeid"))
		
		for i = lbound(rackData) to ubound(rackData) step 4
			InvoiceNumber = rackData(i)
			StartRackLocation = rackData(i + 1)
			EndRackLocation = rackData(i + 2)
			validRackLocation = rackData(i + 3)
			
			set encoder = new BarcodeEncoder

			if encoder.LoadBarcode(InvoiceNumber) then
				if encoder.InvoiceNumber <> "" then
					InvoiceNumber = encoder.InvoiceNumber
				else
					InvoiceNumber = getInvoiceNumberFromTicket(encoder.TicketNumber)
				end if
				
				if trim(storePrefix) <> "" _
				and trim(encoder.Store) <> "" _
				and trim(storePrefix) <> trim(encoder.Store) then
					InvoiceNumber = InvoiceNumber & " from " & encoder.Store
				end if
				
			end if
				
			rackInvoice InvoiceNumber, StartRackLocation, EndRackLocation, validRackLocation

		next

		if UseSameRackLocation = "1" and not overrideChecked then
			rackStartLocation = StartRackLocation
			rackEndLocation = EndRackLocation
		else
			UseSameRackLocation = "0"
		end if	
	end sub
	
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	
%>

<HTML>
<HEAD>
<TITLE>Racking</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT LANGUAGE=javascript>

	var timer = null;
	
	function resetTimeout() {
		if(timer != null) {
			clearTimeout(timer);
			timer = setTimeout("submitRackData();", 300);
		}
	}

	function submitRackData() {
		document.racking.action ="?useraction=rack"
		document.racking.submit();
	}
	
	function isValidInvoiceNumber(str) {
	    if (str == "") {
	        return false;
	    }
	    for (var i = 0; i < str.length; i++) {
	        if (str.charAt(i) == "." || (str.charAt(i) >= "0" && str.charAt(i) <= "9")) {
				// Nothing, Its fine
	        }
			else
				return false
	    }
	    return true;
	}
	
	function isAlphaNumeric(str) {
	    if (str == "") {
	        return false;
	    }
	    for (var i = 0; i < str.length; i++) {
	        if ((str.charAt(i) >= "a" && str.charAt(i) <= "z") ||
	           (str.charAt(i) >= "A" && str.charAt(i) <= "Z") ||
	           (str.charAt(i) >= "0" && str.charAt(i) <= "9") || str.charAt(i) == " ") {
				// Nothing, Its fine
	        }
			else
				return false
	    }
	    return true;
	}

	
	
	function rackInvoice(InvoiceNumber, StartRackLocation, EndRackLocation) {
		var oldSize;
		var tInvoiceNumber;

		tInvoiceNumber = translateInvoiceNumber(InvoiceNumber);
		
		if(tInvoiceNumber != -1) {
			InvoiceNumber = tInvoiceNumber;
		}
		
		if(!isStrFriendly(InvoiceNumber) || trim(InvoiceNumber) == "")
		{
			cbs_alert("Invalid invoice number.");
			return;
		}
		if(StartRackLocation != "" && (!isAlphaNumeric(StartRackLocation) || (EndRackLocation != "" && !isAlphaNumeric(EndRackLocation))))
		{
			cbs_alert("Rack location must be alphanumeric");
			return;
		}
		
		if(timer != null) {
			clearTimeout(timer);
			timer = null;
		}


		if(document.racking.rackData.value != "")
			document.racking.rackData.value += "|"
		
		document.racking.rackData.value += InvoiceNumber + "|";
		document.racking.rackData.value += StartRackLocation + "|";
		document.racking.rackData.value += EndRackLocation + "|1";

		timer = setTimeout("submitRackData();", 300);

		resetForm();
	}

	function resetForm() {
		document.racking.InvoiceNumber.value = "";
		if(!document.racking.UseSameRackLocation.checked)
		{
			document.racking.StartRackLocation.value = "";
			document.racking.EndRackLocation.value = "";
		}
		document.racking.InvoiceNumber.focus();
	}
	
	function rackAllInvoices() {
        <%
                query = "select promptToPrintRacking from miscsetup where storeid = " & Session("StoreID")
                set rs = getdisconnectedrecordset(query)
                if rs.recordcount > 0 then
                    if rs("promptToPrintRacking") then
        %>
            if(document.racking.lastUserAction.value != "rackinvoices") {
                cbs_confirm("Do you wish to print a list of all invoices to be racked?", doPrint, finishRackAll)
                return;
            }
        <%
                    end if
                end if
                set rs = nothing
        %>
        finishRackAll();
        return false;
	}

	function doPrint() {
        clearConfirmMsg();
	    printPage();
        finishRackAll();
	}

	function finishRackAll() {
        clearConfirmMsg();
		document.racking.action = "?useraction=rackinvoices"
		document.racking.submit();
	}
	
	
	
	
	function removeSelectedInvoices() {
		var invoiceList;
		var lineVars;
		var il = document.racking;
		var len = il.elements.length;
		var i, e;
		var count;
		
		invoiceList = "";
		count = 0;

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkInvoice" && e.checked) {
				if(invoiceList != "")
					invoiceList = invoiceList + ",";

				invoiceList = invoiceList + e.value;
				++count;
		    }
		}

		if(count > 0) {
			document.racking.action = "?useraction=remove&invoices=" + invoiceList;
			document.racking.submit();
		}
		else {
			cbs_alert("Must select an invoice.");
		}
	}

	function askToDelete() {
        cbs_confirm("Are you sure you want to delete these assignments?", deleteSelectedInvoices)
	}
	
	function deleteSelectedInvoices() {
        clearConfirmMsg();
		var invoiceList;
		var lineVars;
		var il = document.racking;
		var len = il.elements.length;
		var i, e;
		var count;
		
		invoiceList = "";
		count = 0;
		
		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkInvoice" && e.checked) {
				if(invoiceList != "")
					invoiceList = invoiceList + ",";

				invoiceList = invoiceList +  e.value ;
				++count;
		    }
		}

		if(count > 0) {
			document.racking.action = "?useraction=delete&invoices=" + invoiceList;
			document.racking.submit();
		}
		else {
			cbs_alert("Must select an invoice.");
		}
	}
	
	function SetRowCheckedStatus(row, check, value) {
		if(!value)
			document.racking.chkAllInvoices.checked = false
			
		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "chkInvoice") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "chkInvoice") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}
	function SetRowChecked(r, value) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "chkInvoice") {
				SetRowCheckedStatus(r, childEl.children[0], value);
				break;
			}
			else if (childEl.name == "chkInvoice") {
				SetRowCheckedStatus(r, childEl, value);
				break;
			}
		}
	}
	
	
	function CheckAllInvoices() {
		var il = document.racking;
		var len = il.elements.length;
		var i, e;
		
		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkInvoice") {
				SetRowChecked(e.parentNode.parentNode, true);
		    }
		}
		il.chkAllInvoices.checked = true;
	}

	
	function UnCheckAllInvoices() {
		var il = document.racking;
		var len = il.elements.length;
		var i, e;
		
		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkInvoice") {
				SetRowChecked(e.parentNode.parentNode, false);
		    }
		}
		il.chkAllInvoices.checked = false;
	}
	
	function ToggleAllInvoices() {
		if(!document.racking.chkAllInvoices.checked)
			UnCheckAllInvoices();
		else
			CheckAllInvoices();
	}
	
	function translateRackNumber(rackNumber) {
		var rackPrefix = "<%=rackPrefix%>";
		var index;
		var iRackPrefix;
		var iRackNumber;
		
		index = rackNumber.indexOf("-");
		
		if(index > 0) {
			iRackPrefix = rackNumber.substring(0, index);
			iRackNumber = rackNumber.substring(index + 1);
			
			if(iRackPrefix.toUpperCase() == rackPrefix.toUpperCase())
				return iRackNumber;
			else
				return -1;
		}
		else if(rackPrefix != "")
			return -1;

		return rackNumber;
	}
	
	
	function captureKeyUpEvent(element) {
		var tRackNumber;
		var tInvoiceNumber;

		if (event.keyCode == 13) {

			event.returnValue = true;

			switch(element.name) {
				case "InvoiceNumber":
					if(document.racking.Override.checked)
						tInvoiceNumber = document.racking.InvoiceNumber.value;
					else
						tInvoiceNumber = translateInvoiceNumber(document.racking.InvoiceNumber.value);
					
					if(tInvoiceNumber == -1) {
						document.racking.InvoiceNumber.select();
						document.racking.InvoiceNumber.focus();
						break;
					}
					else {
						if(document.racking.UseSameRackLocation.checked & document.racking.StartRackLocation.value != "")
							rackInvoice(document.racking.InvoiceNumber.value,
							document.racking.StartRackLocation.value,
							document.racking.EndRackLocation.value);
						else
							document.racking.StartRackLocation.focus();
						
						if(document.racking.DoNotRack.checked)
						{
							document.racking.StartRackLocation.value = "";
							//fall through to case "StartRackLocation":
						}
						else
							break;
					}
				case "StartRackLocation":
				  
				  
					if(document.racking.Override.checked)
						tRackNumber = document.racking.StartRackLocation.value;
					else
						tRackNumber = translateRackNumber(document.racking.StartRackLocation.value);
					
					if(tRackNumber == -1) {
        		if(document.racking.rackData.value != "")
        			document.racking.rackData.value += "|"

        		document.racking.rackData.value += document.racking.InvoiceNumber.value + "|";
        		document.racking.rackData.value += document.racking.StartRackLocation.value + "|";
        		document.racking.rackData.value += document.racking.StartRackLocation.value + "|0";

						document.racking.StartRackLocation.select();
						document.racking.StartRackLocation.focus();
					}
					else {
						document.racking.StartRackLocation.value = tRackNumber;
						document.racking.EndRackLocation.value = document.racking.StartRackLocation.value;
	
						rackInvoice(document.racking.InvoiceNumber.value,
						document.racking.StartRackLocation.value,
						document.racking.EndRackLocation.value);
					}
					break;
				case "EndRackLocation":
					rackInvoice(document.racking.InvoiceNumber.value,
					document.racking.StartRackLocation.value,
					document.racking.EndRackLocation.value);
					
					break;
			}
		}
	}

	function printPage() {
		rackInput.style.display = 'none';
		cmdbar.style.display = 'none';
		invoiceList.style.overflow = "visible";
		
		window.print();

		rackInput.style.display = 'block';
		cmdbar.style.display = 'block';
		invoiceList.style.overflow = "scroll";
	}
	

	function init() {
        $('form input:not([type="submit"])').keydown(function(e) {
            if (e.keyCode == 13) {
                e.preventDefault();
                return false;
            }
        });
}

</SCRIPT>
</HEAD>
<BODY topmargin=0 leftmargin=0 style="color:black" onLoad="init();document.racking.InvoiceNumber.focus()" >
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->
<H1>Racking</H1><BR>
<FORM id="racking" name="racking" action="" method="Post" onsubmit="return false">

	<input type=hidden name="lastUserAction" value="<%=Request.QueryString("useraction")%>">
	<input type=hidden name="rackData" value="">
	<input type=hidden name="rackPrefix" value="<%=rackPrefix%>">
	
<table width=100% cellpadding=0 cellspacing=0 border=0>
	<tr><td>
	<table name="rackInput" id="rackInput" style="margin:10px;" align=center>
		<tr>
			<td>Invoice Number:</td>
			<td>
				<input style="height:25px" name="InvoiceNumber" onKeyup="captureKeyUpEvent(this)">
			</td>
			<td>Rack Location:</td>
			<td>
				<input style="height:25px" name="StartRackLocation" onKeyup="captureKeyUpEvent(this)" value="<%=rackStartLocation%>"> - <input style="height:25px" name="EndRackLocation" onKeyup="captureKeyUpEvent(this)" value="<%=rackEndLocation%>">
			</td>
		</tr>
		
		<tr>
			<td colspan=3>
			</td>
			<td>
				<input type=checkbox value="1" name="UseSameRackLocation" style="width:25px;height:25px"
				<%if UseSameRackLocation = "1" then%>
					checked
				<% end if  %>
				>Use Same Rack Location

				<input type=checkbox value="1" name="DoNotRack" style="width:25px;height:25px"
				<%if Request.Form("DoNotRack") = "1" then%>
					checked
				<% end if  %>
				>Do Not Rack
				
				<input type=checkbox value="1" name="Override" style="width:25px;height:25px"
				<%if overrideChecked then%>
					checked
				<% end if  %>
        >Override
			</td>
		</tr>
	</table>
	</td></tr>

	<tr><td>
	<div name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
		<span style="float:left">
			<button style="vertical-align: top"  onClick="rackAllInvoices()" id=button2 name=button2>Rack<br>Invoices</button>
			<button onClick="printPage();" id=button3 name=button3>Print</button>
		</span>
		<span style="float:right">
			<button  onClick="askToDelete(); return false">Delete<br>Assignment</button>
			<button  onClick="removeSelectedInvoices()">Remove<br>From List</button>
		</span>
	</div>	
	</td></tr>
	
	
	<tr ><td>
	<div name="invoiceList" id="invoiceList" style="margin:0;padding:0;">
<%
		dim rackLocation
		
		query = "select prl.*, e.employeename from PendingRackLocations prl, employee e where prl.TerminalID = " & Session("TerminalID") & " and e.employeeid = prl.employeeid order by RackLocationID desc"
		set invoicesPending = getdisconnectedrecordset(query)
%>

<%if invoicesPending.recordcount > 0 and Request.QueryString("useraction") = "rackinvoices" then%>
	<div style="color:white;background:red;text-align:center;margin:4px;padding:4px">Some invoices may not have been racked.  Rack invoices again to attempt to rack these.</div>
<%end if%>

	<TABLE class="itable" align=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0>
		<TR>
			<TH style="width:10px"><input type=checkbox  id=chkAllInvoices name=chkAllInvoices onclick="ToggleAllInvoices();"></th>
			<TH style="width:110px">Invoice</TH>
			<TH style="width:140px">Rack Location</TH>
			<TH style="width:270px">Racked By</TH>
			<TH>Status</TH>
		</TR>
		
<%
		
		while not (invoicesPending.eof or invoicesPending.bof)
		
			rackLocation = invoicesPending("StartRackLocation")
			
			if invoicesPending("StartRackLocation") <> invoicesPending("EndRackLocation") then
				rackLocation = rackLocation & "-" & invoicesPending("EndRackLocation")
			end if
		
%>
		<TR align=center>
			<td  onclick="ToggleRowChecked(this.parentNode);"><input  onclick="ToggleRowChecked(this.parentNode.parentNode);" type=checkbox id=chkInvoice name=chkInvoice value="<%=invoicesPending("racklocationid")%>"></td>
			<TD  onclick="ToggleRowChecked(this.parentNode);"><%=invoicesPending("InvoiceNumber")%></TD>
			<TD  onclick="ToggleRowChecked(this.parentNode);"><%=rackLocation%></TD>
			<TD  onclick="ToggleRowChecked(this.parentNode);"><%=invoicesPending("employeename")%></TD>
			<TD align=center <%if invoicesPending("ErrorNo") <> 0 then%>style="color:red"<%end if%>>
				<%=invoicesPending("Notes")%>
			</TD>
		</TR>
		
<%
			invoicesPending.movenext
		wend

		set invoicesPending = nothing
%>
	</TABLE>
	</div>
	</td></tr>

	
</FORM>   
</TABLE>

</BODY>
</HTML>
