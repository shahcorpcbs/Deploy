<%@ Language=VBScript %>
<%option explicit%>

<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>

<%
	'*******************************************************************
	'Name   : creditCardPickup.asp
    'Author : James Johnston
    'Created: 20-Oct-2003
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 20-Oct-2003    Johnston		Original version
	'*****************************************************************
	
dim InvoiceList
dim pickupObj, ObjMiscSetUp
dim invoicesTotal
dim ccTotal
dim custSeqNumber
dim customername
dim storeId
dim empID
dim totalInv
dim terminalId
dim sessionName
dim onFile
dim fileStatus
dim approvalCode
dim ticketNums
dim creditFormName
dim RackRst,rackStr, rackStr1, noOfRows, rackString
dim printRackInfo
dim invoicenumberchange
dim custPaymentObj
dim custCreditCardTypeID
dim custCreditCardNo
dim custCreditCardExpDate
dim custCreditCardExpMonth
dim custCreditCardExpYear
dim firstDigits, cardTypeArray
dim xChargePath
dim isPrePay
dim itemsStartIndex
dim upChargeStartIndex
dim colorsStartIndex
dim patternStartIndex
dim deptStartIndex
dim addOrEdit

InvoiceList= session("invoicelist")
set pickupObj = Session("pickupObj")
set ObjMiscSetUp = Session("miscSetUp")
ticketNums = pickupObj.getTicketNosForPrinting()
invoicesTotal = pickupObj.invoicesTotal
custSeqNumber = Session("customerSequenceNumber")
customerName = session("customername")
storeId = Session("storeID")
empID = Session("employeeID")
totalInv = totalDue()
terminalId = Session("terminalID")
sessionName = Session.SessionID
ccTotal = Request.QueryString("ccAmount")
ccTotal = formatnumber(ccTotal,2)
onFile = Request.QueryString("onFile")
fileStatus = 0
creditFormName = ""
printRackInfo = ""
noOfRows = 0
rackString = ""
xChargePath = ObjMiscSetUp.Item("XChargePath")
xChargePath = replace(xChargePath,"\","\\")
'Following added by J.Johnston, 5Dec03, for prepay
isPrePay = Request.Form("isPrePay")	
itemsStartIndex = Request.Form("ItemPageCount")
upChargeStartIndex = Request.Form("upChargePageCount")
colorsStartIndex = Request.Form("colorsPageCount")
patternStartIndex = Request.Form("PatternPageCount")
deptStartIndex = Request.Form("DeptPageCount")
addOrEdit = Request.Form("addOrEdit")
'End addition, 5Dec03

getCustomerCreditCardInfo
checkForForm

invoicenumberchange = ""

'SteveG added condition where ticketRack does not exist during prepay
if isobject(Session("ticketRack")) and not (Session("ticketRack") is nothing) then
	set RackRst = Session("ticketRack")
	noOfRows = RackRst.RecordCount
	if RackRst.RecordCount > 0 then
		RackRst.MoveFirst
		while not RackRst.EOF
			rackStr= RackRst.Fields("rackLocationStart").Value
			rackStr1 = RackRst.Fields("rackLocationStart").Value
			if not IsNull(RackRst.Fields("rackLocationEnd").Value) then
				rackStr = rackStr & " - " & RackRst.Fields("rackLocationEnd").Value
				rackStr1 = rackStr1 & " - " & RackRst.Fields("rackLocationEnd").Value
			end if
			if trim(printRackInfo) = "" then
				printRackInfo =    customername & vbcrlf 
			end if						
			if trim(invoicenumberchange) = "" or invoicenumberchange <> trim(RackRst.Fields("invoicenumber").Value)  then
				invoicenumberchange = RackRst.Fields("invoicenumber").Value
				printRackInfo = printRackInfo & vbcrlf & invoicenumberchange & vbTab & vbTab
			else
				printRackInfo =  printRackInfo & ", "
			end if							
			if len(trim(printRackInfo)) = 0 then
				printRackInfo =  printRackInfo &  rackStr
			else
				printRackInfo =  printRackInfo &  rackStr1
			end if		
			
			if len(trim(rackString))=0 then
				if len(trim(rackStr))<> 0 then
					rackString = rackStr
				else
					rackString = rackStr1
				end if
			else
				if len(trim(rackStr))<> 0 then
					rackString = rackString + ", " + rackStr
				else
					rackString = rackString + ", " + rackStr1
				end if
			end if					
			RackRst.MoveNext
													
		wend								
	end if
end if

Function getCreditCardsTypes() 
	dim sqltxt
	dim rsCreditTypes
	dim typeArray(),cardArray(15)
	dim i,x
	dim test
	i=0
	x=0
	
	sqltxt = "select creditcardTypeId, name from creditcardtypedomain where storeid = " & storeId
	set rsCreditTypes = getdisconnectedRecordset(sqltxt)
	
	if rsCreditTypes.recordcount > 0 then
		'Set array of valid first digits
		redim typeArray(rsCreditTypes.recordcount-1)
		test = rsCreditTypes.recordcount-1
		while not rsCreditTypes.EOF
			if ucase(left(rsCreditTypes.fields("name").value,2))="VI" then
				typeArray(i)=4
				cardArray(i)=x
			elseif ucase(left(rsCreditTypes.fields("name").value,2))="MA" then
				typeArray(i)=5
				cardArray(i)=x
			elseif ucase(left(rsCreditTypes.fields("name").value,2))="AM" then
				typeArray(i)=34
				cardArray(i)=x
				redim preserve typeArray(ubound(typeArray)+1)
				i=i+1
				typeArray(i)=37
				cardArray(i)=x
			elseif ucase(left(rsCreditTypes.fields("name").value,3))="DIS" then
				typeArray(i)=6
				cardArray(i)=x
			elseif ucase(left(rsCreditTypes.fields("name").value,3))="DIN" then
				typeArray(i)=30	
				cardArray(i)=x	
			elseif ucase(left(rsCreditTypes.fields("name").value,4))="CART" then
				typeArray(i)=36
				cardArray(i)=x
				redim preserve typeArray(ubound(typeArray)+1)
				i=i+1
				typeArray(i)=38
				cardArray(i)=x	
			elseif ucase(left(rsCreditTypes.fields("name").value,3))="ENR" then
				typeArray(i)=201
				cardArray(i)=x
				redim preserve typeArray(ubound(typeArray)+1)
				i=i+1
				typeArray(i)=214
				cardArray(i)=x		
			elseif ucase(left(rsCreditTypes.fields("name").value,3))="JCB" then
				typeArray(i)=213
				cardArray(i)=x
				redim preserve typeArray(ubound(typeArray)+1)
				i=i+1
				typeArray(i)=180
				cardArray(i)=x											
			end if
			i=i+1
			x=x+1
			rsCreditTypes.movenext
		wend
	
		firstDigits = join(typeArray,",")
		cardTypeArray = join(cardArray,",")
		rsCreditTypes.movefirst
	end if
	set getCreditCardsTypes = rsCreditTypes
	
End Function

sub getCustomerCreditCardInfo()
	dim custCreditCardExpDate
	if Not IsObject(Session("customerPayment")) then
		initializeCustomerPaymentInfo
	end if
	set custPaymentObj = Session("customerPayment")
	if custPaymentObj.Count > 0 then
		custCreditCardTypeID = custPaymentObj.Item("creditCardTypeId")
		custCreditCardNo = custPaymentObj.Item("creditCardNumber")
		custCreditCardExpDate = custPaymentObj.Item("creditCardExpDate")
		if not isnull(custCreditCardExpDate) then
			custCreditCardExpMonth = left(custCreditCardExpDate,2)
			custCreditCardExpYear = right(custCreditCardExpDate,2)
		end if
	end if
end sub

function totalDue()
	dim tempTotalDue
	if (formatnumber(pickupObj.getTotalAmountDue, 2)-formatnumber(pickupObj.totalAmtPaid, 2))>0 then							  
		tempTotalDue = formatnumber(pickupObj.getTotalAmountDue, 2)-formatnumber(pickupObj.getPaymentByType(""), 2)
	else
		tempTotalDue = 0.00
	end if
	totalDue = tempTotalDue
end function

function checkForForm()

	dim prnsql
	dim prnrs
	
	prnsql = "SELECT printerID, printerType, formName, numCopies, printerName, brand, model, port, baudRate, hardwareName, routeNumber "
	prnsql = prnsql & " FROM Printer, StoreHardware "
	prnsql = prnsql & " WHERE StoreHardware.hardwareID IN "
	prnsql = prnsql & " (  SELECT hardwareID "
	prnsql = prnsql & "    FROM StoreHardware "
	prnsql = prnsql & "    WHERE hardwareType = 'PR' "
	prnsql = prnsql & "    AND routeNumber is NULL "
	prnsql = prnsql & "    AND terminalID = " & Session("terminalID") & "  ) "
	prnsql = prnsql & "    AND Printer.hardwareID = StoreHardware.hardwareID "
	prnsql = prnsql & "    AND printerType = 'CREDIT CARD RECEIPT' "
	set prnrs = getDisconnectedRecordset(prnsql)
	
	IF prnrs.eof or prnrs.bof then
		creditFormName = null
	else
		creditFormName = prnrs("formName")
	end if 
	
	if isnull(creditFormName) then
		creditFormName = ""
	end if
end function

%>

<HTML>

<HEAD>

<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">

<TITLE>Process Credit Card</TITLE>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>

<script language="javascript" type="text/javascript">

	var lastFocusControl;
	var lastControl;
	var cardType;
	var accountNumber;
	var expirationDate;
	var expirationMonth;
	var expirationYear;
	var ccCustName;
	var fileName;
	var approvalCode;
	var timedOut;
	var swipeData;
	
	lastControl = "txtCCNumber";
	timedOut = false;
	
	function checkEnter(event)
	{ 	
		var code = 0;
		
		code = event.keyCode;
		if (code==13)
			submitForm("ok");
	}
	
	
	function validateEnterKey() 
	{
		return false;
	}
	
	
	//set the default focus after loading the page.
	function setFocusOnFirstControl()
	{										
		document.creditCardInfo.txtCCData.focus();	
	}
	
	
	//Set the focus on Process button.
	function setFocusOnControl()
	{				
		document.creditCardInfo.processButton.focus();
	}	
	
	

	//Set the focus on OK button when enter key pressed.
	function captureKeyUpEvent()
	{
		if (event.keyCode == 13)
		{			
			event.returnValue = true;
			setFocusOnControl();
			event.keyCode = 0;
		}
	}
	
	
	function onNumberBlur() 
	{
		document.creditCardInfo.style.cursor="default";
		//var swipeData;
		swipeData = document.creditCardInfo.txtCCData.value;
		//cbsAlert("swipeData = "+swipeData,cbsOKOnly,"JJ");
		
		if(swipeData!="")
		{
			var firstSwipeChar;
			firstSwipeChar = swipeData.substr(0,1);
		
			if(firstSwipeChar==";" || firstSwipeChar=="%") //This is a swiped card
			{
					
				var splitSwipedData;
				splitSwipedData = swipeData.split(";");	//split into 2 lines
				
				var firstLine;
				firstLine = splitSwipedData[0];	//capture 1st line
				//cbsAlert("firstLine = "+firstLine,cbsOKOnly,"JJ");
	
				var splitFirstLine;
				splitFirstLine = firstLine.split("^");	//split 1st line
		
				ccCustName = splitFirstLine[1];
				if(ccCustName=="" || ccCustName == null)
				{
					ccCustName=""
				}
		
				var secondLine;
				secondLine=splitSwipedData[1];	//capture 2nd line
				//cbsAlert("secondLine = "+secondLine,cbsOKOnly,"JJ");
		
				var splitSecondLine;
				splitSecondLine = secondLine.split("=");	//split 2nd line
		
				accountNumber = splitSecondLine[0];
				if(isNaN(accountNumber.substr(0,1)))
				{
					accountNumber="";
				}
				
				if(splitSecondLine[1]!=null)
				{
					expirationDate = splitSecondLine[1];
					expirationDate = expirationDate.substr(0,4);
					expirationDate = expirationDate.substr(2,2)+expirationDate.substr(0,2);
					//cbsAlert("expirationDate = "+expirationDate,cbsOKOnly,"JJ");
				}
				else
				{
					expirationDate="";
				}
		
				document.creditCardInfo.txtCCNumber.value = accountNumber;
				document.creditCardInfo.txtCCExpDate.value = expirationDate;
				document.creditCardInfo.txtCCCustName.value = ccCustName;
		
				var firstDigits = document.creditCardInfo.firstDigits.value;
					//cbsAlert("firstDigits = "+firstDigits,cbsOKOnly,"JJ");
				var splitFirstDigits = firstDigits.split(",");
				var cardTypeArray = document.creditCardInfo.cardTypeArray.value;
					//cbsAlert("firstDigits = "+firstDigits,cbsOKOnly,"JJ");
				var splitcardTypeArray = cardTypeArray.split(",");				
				var validtype;
				validtype = false;
					//cbsAlert("splitFirstDigits.length = "+splitFirstDigits.length,cbsOKOnly,"JJ");
						
				for (i=0;i<splitFirstDigits.length;i++)
				{
					//cbsAlert("splitFirstDigits[i] = "+splitFirstDigits[i],cbsOKOnly,"JJ");
					if(accountNumber.substr(0,1) == splitFirstDigits[i]
							|| accountNumber.substr(0,2) == splitFirstDigits[i]
							|| accountNumber.substr(0,3) == splitFirstDigits[i])
					{
						validtype = true;
						document.creditCardInfo.selCreditType.selectedIndex=splitcardTypeArray[i];
					}
				}
						
				if (validtype!=true)
				{
					cbs_alert("This is not an accepted credit card type.");
					document.creditCardInfo.selCreditType.selectedIndex=splitFirstDigits.length;
					document.creditCardInfo.txtCCNumber.value = "";
				}			
	
			}
			else	//This is NOT a swiped card
			{

			}
			
			document.creditCardInfo.txtCCData.value="";
			document.creditCardInfo.selCreditType.focus();
			return;
		}
		else
		{
			//cbsAlert("swipedate is empty",cbsOKOnly,"JJ");
			//Display additional fields
			document.creditCardInfo.txtCCcvctag.style.visibility="visible";
			document.creditCardInfo.txtCCAddresstag.style.visibility="visible";
			document.creditCardInfo.txtCCZiptag.style.visibility="visible";
			document.creditCardInfo.txtCCZip.style.visibility="visible";
			document.creditCardInfo.txtCCAddress.style.visibility="visible";
			document.creditCardInfo.txtCCcvc.style.visibility="visible";
			document.creditCardInfo.txtCCCity.style.visibility="visible";
			document.creditCardInfo.txtCCCitytag.style.visibility="visible";
			document.creditCardInfo.txtCCState.style.visibility="visible";
			document.creditCardInfo.txtCCStatetag.style.visibility="visible";
			
			accountNumber = document.creditCardInfo.txtCCNumber.value;
			//cbsAlert("accountNumber = "+accountNumber,cbsOKOnly,"JJ");
			if (accountNumber.length != "")
			{
				var firstDigits = document.creditCardInfo.firstDigits.value;
					//cbsAlert("firstDigits = "+firstDigits,cbsOKOnly,"JJ");
				var splitFirstDigits = firstDigits.split(",");
				var cardTypeArray = document.creditCardInfo.cardTypeArray.value;
					//cbsAlert("firstDigits = "+firstDigits,cbsOKOnly,"JJ");
				var splitcardTypeArray = cardTypeArray.split(",");					
				var validtype;
				validtype = false;
					//cbsAlert("splitFirstDigits.length = "+splitFirstDigits.length,cbsOKOnly,"JJ");
							
				for (i=0;i<splitFirstDigits.length;i++)
				{
					//cbsAlert("splitFirstDigits[i] = "+splitFirstDigits[i],cbsOKOnly,"JJ");

					if(accountNumber.substr(0,1) == splitFirstDigits[i]
							|| accountNumber.substr(0,2) == splitFirstDigits[i]
							|| accountNumber.substr(0,3) == splitFirstDigits[i])
					{
						validtype = true;
						document.creditCardInfo.selCreditType.selectedIndex=splitcardTypeArray[i];
					}
				}
							
				if (validtype!=true)
				{
					cbs_alert("This is not an accepted credit card type.");
					document.creditCardInfo.selCreditType.selectedIndex=splitFirstDigits.length;
					document.creditCardInfo.txtCCNumber.value = "";
				}
				//cbsAlert("accountNumber = "+accountNumber+"\nexpirationDate = "+expirationDate+"\nccCustName = "+ccCustName,cbsOKOnly,"JJonNumberBlur");
			}

		}
		
		document.creditCardInfo.txtCCData.value="";
		lastFocusControl = document.getElementById(lastControl);
		
		//cbsAlert("swipeData.substr(0,1) = "+swipeData.substr(0,1),cbsOKOnly,"JJonNumberBlur");
	}
	
	
	function setLastControl()
	{
		lastControl = document.activeElement.id;
		//cbsAlert("lastFocusControl = "+lastFocusControl,cbsOKOnly,"JJsetLastControl");
	}
	
	
	function cancelForm() 
	{
		var custSeqNumber;
		custSeqNumber = document.creditCardInfo.custSeqNumber.value;
		document.creditCardInfo.action = "";
		document.creditCardInfo.submit();		
	}	
	
	function clearAll()
	{
		document.creditCardInfo.style.cursor="default";
		document.creditCardInfo.selCreditType.value = 0;
		document.creditCardInfo.txtCCNumber.value = "";
		document.creditCardInfo.txtCCExpDate.value = "";
		document.creditCardInfo.txtCCCustName.value = "";
		document.creditCardInfo.txtCCData.value = "";
		document.creditCardInfo.txtProcessing.style.visibility="hidden";
		document.creditCardInfo.txtCCZip.style.visibility="hidden";
		document.creditCardInfo.txtCCZip.value="";
		document.creditCardInfo.txtCCAddress.style.visibility="hidden";
		document.creditCardInfo.txtCCAddress.value="";
		document.creditCardInfo.txtCCcvc.style.visibility="hidden";
		document.creditCardInfo.txtCCcvc.value="";
		document.creditCardInfo.txtCCcvctag.style.visibility="hidden";
		document.creditCardInfo.txtCCAddresstag.style.visibility="hidden";
		document.creditCardInfo.txtCCZiptag.style.visibility="hidden";
		document.creditCardInfo.txtCCCity.style.visibility="hidden";
		document.creditCardInfo.txtCCCity.value="";
		document.creditCardInfo.txtCCCitytag.style.visibility="hidden";
		document.creditCardInfo.txtCCState.style.visibility="hidden";
		document.creditCardInfo.txtCCState.value="";
		document.creditCardInfo.txtCCStatetag.style.visibility="hidden";
		document.creditCardInfo.fileStatus.value = 0;		
		accountNumber = null;
		expirationDate = null;
		ccCustName = null;
		document.creditCardInfo.processButton.disabled = false;
		//cbsAlert("In ClearAll()",cbsOKOnly,"JJ");
		removeOldFiles(fileName);	//Added by JJ, 7Jan04
		setFocusOnFirstControl();
	}
	
	
	function processCC()
	{
		var CCString;
		var tranType;
		var empID;
		var sInvoiceList;
		var ccTotal;
		var ccZip;
		var ccAddress;
		var ccCity;
		var ccState;
		var ccCVC;
		
		document.creditCardInfo.processButton.disabled = true;
		
		empID = document.creditCardInfo.empID.value;
		sInvoiceList = "";
		ccTotal = document.creditCardInfo.ccTotal.value;
		onFile = document.creditCardInfo.onFile.value;
		
		//Check for valid and needed data
		//Type of card
		if (document.creditCardInfo.selCreditType.value==0)
		{
			cbs_alert("Please select the TYPE of card.");
			document.creditCardInfo.selCreditType.focus();
			return;
		}
		//Account number or Expiration date missing
		if (document.creditCardInfo.txtCCNumber.value=="" ||
				document.creditCardInfo.txtCCExpDate.value=="")
		{
			cbs_alert("Please enter \nACCOUNT NUMBER\n and/or \nEXPIRATION DATE.");
			if (document.creditCardInfo.txtCCNumber.value=="")
			{
				document.creditCardInfo.txtCCNumber.focus();
			}
			else
			{
				document.creditCardInfo.txtCCExpDate.focus();
			}
			return;
		}
		//Account number alphanumeric
		accountNumber=document.creditCardInfo.txtCCNumber.value;
		//cbsAlert("accountNumber= "+accountNumber,cbsOKOnly,"JJ");
		if(isNaN(accountNumber))
		{
			cbs_alert("ACCOUNT NUMBER is not a number.");
			document.creditCardInfo.txtCCNumber.focus();
			return;
		}
		//Expiration date invalid
		expirationDate = document.creditCardInfo.txtCCExpDate.value;
		var result
		result = expDateCheck(expirationDate);
		//cbsAlert("result = "+result,cbsOKOnly,"JJ");
		if(result==false)
		{
			return;
		}		
		
		//Everything checks out. Build string.
		var strQCQ = '","';
		var strQ = '"';
		tranType = "C1";
		CCString = strQ+tranType+strQCQ;
		CCString = CCString + empID + strQCQ;
		CCString = CCString + sInvoiceList + strQCQ;
		CCString = CCString + accountNumber + strQCQ;
		if(swipeData!="")//swiped card
		{
			expirationDate = expirationDate.substr(2,2)+expirationDate.substr(0,2)+swipeData;
		}
		else
		{
			//Change expiration date BACK for processing
			expirationDate = expirationDate.substr(2,2)+expirationDate.substr(0,2);
		}
		CCString = CCString + expirationDate + strQCQ;
		if(swipeData!="")//swiped card
		{
			CCString = CCString + ccTotal + strQ;
		}
		else//NOT a swiped card
		{
			//Collect info from manual enter fields
			ccZip = document.creditCardInfo.txtCCZip.value;
			ccAddress = document.creditCardInfo.txtCCAddress.value;
			ccCity = document.creditCardInfo.txtCCCity.value;
			ccState = document.creditCardInfo.txtCCState.value;
			ccCVC = document.creditCardInfo.txtCCcvc.value;
			
			//Add to string
			if(ccZip!="")
			{
				CCString = CCString + ccTotal + strQCQ;
				CCString = CCString + ccZip + strQ;
			}
			else
			{
				CCString = CCString + ccTotal + strQCQ;
				CCString = CCString + "99999" + strQ;
			}
			if(ccAddress!="")
			{
				if(ccCity!="")
				{
					if(ccState!="")
					{
						ccAddress = ccAddress + " " + ccCity + " " + ccState;
						ccAddress = ccAddress.toUpperCase();
						CCString = CCString + ',"' + ccAddress + strQ;
					}
					else
					{
						ccAddress = "";
					}
				}
				else
				{
					ccAddress = "";
				}
			}
			if(ccAddress=="")
			{
				CCString = CCString + ',""'
			}
			if(ccCVC!="")
			{
				CCString = CCString + ',"' + ccCVC + strQ
			}
			else
			{
				CCString = CCString + ',""'
			}
			//CCString = CCString + ccCVC + strQ;	
		}		
		
		//cbsAlert("CCString = "+CCString,cbsOKOnly,"JJ");
		
		//NEEDS ERROR TRAPPING
		//Display msg
		//document.creditCardInfo.txtProcessing.style.visibility="visible";
		//changeMouse()		
		
		var fso = new ActiveXObject("Scripting.FileSystemObject");
		
		//Create file
		createTempFile(CCString);
		
		//Wait for set time period
		WaitTimer(2);	//Added by JJ, 7Jan04
		
		if(!fso.FileExists(fileName + ".tmp"))
		{
			clearAll();
			return;
		}
		//Rename file
		renameFile(fileName);
		//Pickup answer file
		getAnswerFile(fileName);
		if(timedOut == true)
		{
			document.creditCardInfo.style.cursor="default";
			document.creditCardInfo.txtProcessing.style.visibility="hidden";
			clearAll();	//Added 5Jan04, JJ
			return;
		}
		//Delete file
		deleteFile(fileName);
		
		document.creditCardInfo.style.cursor="default";
		
		fileStatus = document.creditCardInfo.fileStatus.value;
		//cbsAlert("fileStatus = "+fileStatus,cbsOKOnly,"JJ");
		
		var isPrePay;
		isPrePay = document.creditCardInfo.isPrePay.value;
		//cbsAlert("isPrePay = "+isPrePay,cbsOKOnly,"JJ");
		
		if(fileStatus != -1)
		{
			if(fileStatus == 1)
			{
				document.creditCardInfo.action="pickup.asp?userAction=creditCardOnFile&change=" + fileStatus+"&ccpayment=1&isPrePay="+isPrePay;
				document.creditCardInfo.submit();
			}
			else
			{
				document.creditCardInfo.action="pickup.asp?userAction=creditCardOnFile&change=" + fileStatus+"&ccpayment=1&isPrePay="+isPrePay;
				document.creditCardInfo.submit();		
			}
		}
		
	}
	
	
	function expDateCheck(expirationDate)
	{
		var d;
		var m, y;
		
		d = new Date();
		m = d.getMonth()+1;
		m = parseInt(m);
		y = d.getFullYear();
		y = parseInt(y);
		//cbsAlert("m = "+m+"\ny = "+y,cbsOKOnly,"JJ");
				
		expirationYear = 20+expirationDate.substr(2,2);
		expirationYear = parseInt(expirationYear);
		//cbsAlert("expirationYear = "+expirationYear,cbsOKOnly,"JJ");
		expirationMonth = expirationDate.substr(0,2);
		expirationMonth = parseFloat(expirationMonth);
		//cbsAlert("expirationMonth = "+expirationMonth,cbsOKOnly,"JJ");
				
		if(expirationYear <= y)
		{
			if(expirationMonth < m)
			{
				cbs_alert("This card has EXPIRED.");
				return false;
			}
		}
		
		return true;
	}


	function changeMouse()
	{
		document.creditCardInfo.style.cursor="wait";
		//cbsAlert("In changeMouse",cbsOKOnly,"JJ");
	}
	
	
	function createTempFile(CCString)
	{
		var sessionName
		sessionName = document.creditCardInfo.sessionName.value;
		
		var termName
		termName = document.creditCardInfo.terminalId.value;
		
		var pathName
		pathName = document.creditCardInfo.xChargePath.value;
		
		var fso = new ActiveXObject("Scripting.FileSystemObject");
		
		if(fso.FolderExists(pathName))
		{
			//fileName = "X:\\X-Charge\\Transactions\\"+termName+sessionName;
			fileName = pathName+"\\"+termName+sessionName;
		}
		else
		{
			cbs_alert("X-Charge Transaction folder does not exist.\nCheck path in Miscellaneous Setup.");
			return;
		}
		
		//cbsAlert("fileName = "+fileName,cbsOKOnly,"JJ");
		
		removeOldFiles(fileName);

		var a = fso.CreateTextFile(fileName+".tmp", true);
		a.WriteLine(CCString);
		a.Close();
	}
	
	
	function removeOldFiles(fileName)
	{
	  var fso, newName;
	  newName = fileName + ".tmp";
	  //cbsAlert("newName = "+newName,cbsOKOnly,"JJdeleteFile");
	  fso = new ActiveXObject("Scripting.FileSystemObject");
	  //.tmp file
	  if(fso.FileExists(newName))
	  {
		fso.DeleteFile(newName);
	  }
	  //.req file 
	  newName = fileName + ".req";
	  if(fso.FileExists(newName))
	  {
		fso.DeleteFile(newName);
	  }	  
	  //.hld file 
	  newName = fileName + ".hld";
	  if(fso.FileExists(newName))
	  {
		fso.DeleteFile(newName);
	  }	
	  //.ans file 
	  newName = fileName + ".ans";
	  if(fso.FileExists(newName))
	  {
		fso.DeleteFile(newName);
	  }		  	  
	}
		
		
	function renameFile(fileName)
	{
		var fso, f, newName;
		fso = new ActiveXObject("Scripting.FileSystemObject");
		f = fso.GetFile(fileName+".tmp");
		newName = fso.getfilename(fileName)+".req";
		//cbsAlert("newName = "+newName,cbsOKOnly,"JJ");
		f.Name=newName;
	}
	
	
	function deleteFile(fileName)
	{
	  var fso, newName;
	  newName = fileName + ".ans";
	  //cbsAlert("newName = "+newName,cbsOKOnly,"JJdeleteFile");
	  fso = new ActiveXObject("Scripting.FileSystemObject");
	  if(fso.FileExists(newName))
	  {
		fso.DeleteFile(newName);
	  }
	}


	function getAnswerFile(fileName)
	{
		var fso, newName;
		var openFile;
		var approvalMsg;
		var retVal;
		var msg;
		
		approvalMsg = "";
		timedOut = false;
		
		newName = fileName + ".ans";
		//cbsAlert("newName = "+newName,cbsOKOnly,"JJgetAnswerFile");
		
		fso = new ActiveXObject("Scripting.FileSystemObject");
		
		//Set timer
		var d, timer;
		var MinMilli = 1000 * 90;
		d = new Date();
		timer = d.getTime();
	
		//For next 30 seconds...
		do
		{
			d = new Date();
			if(fso.FileExists(newName))
			{
				break;
			}
			//cbsAlert("In WHILE\n\ntimer = "+timer+"\nd.getTime() = "+d.getTime(),cbsOKOnly,"JJ");
		}
		while(d.getTime() < (timer+MinMilli));
		
		if(fso.FileExists(newName))
		{
			var f, ts;
			f = fso.GetFile(newName);
			//cbsAlert("newName = "+newName,cbsOKOnly,"JJgetAnswerFile");
			ts = f.OpenAsTextStream(1, 0);
			approvalMsg = ts.ReadLine();
			ts.Close( );
			//cbsAlert("approvalMsg = "+approvalMsg,cbsOKOnly,"JJ");
		}
		else
		{
			cbs_alert("TRANSACTION TIMED OUT.\n\n MAKE SURE X-CHARGE and MODEM ARE WORKING PROPERLY");
			timedOut = true;
			return;
		}
		
		//Hide msg
		document.creditCardInfo.txtProcessing.style.visibility="hidden";
		
		//Display dis/approval message
		if(approvalMsg!="")
		{
			var approvalMsgLength;
			approvalMsgLength = approvalMsg.length;
			var approvalText;
			approvalText = approvalMsg.substr(2,approvalMsgLength-3);
			//cbsAlert("approvalText = "+approvalText,cbsOKOnly,"Credit Approval");
			if(approvalMsg.substr(1,1)=="Y")
			{
				approvalCode = approvalText;
				document.creditCardInfo.approvalCode.value = approvalCode;
				
				if(document.creditCardInfo.creditFormName.value != "")
				{
					PrintReceipt();
				}
				else
				{
					cbs_alert("There is no credit receipt form set in Miscellaneous Setup");
					cbs_alert("Purchase APPROVED\n\nApproval Code:  "+approvalText);
				}
				
				//if(onFile == 0 || accountNumber != document.creditCardInfo.custCreditCardNo.value)
				if((onFile == 1 || document.creditCardInfo.promptToAddCC.value) && accountNumber != document.creditCardInfo.custCreditCardNo.value)
				{
					/*if(onFile == 0)
					{
						msg = "Do you wish to set the credit card on file?";
					}
					else
					{*/
						msg = "Do you wish to change the credit card information on file?";
					//}
					
					retVal = cbsConfirm(msg, cbsQuestion + cbsYesNo, "Add CreditCard");
					if (retVal == cbsYes)
						retVal = true;
					else
						retVal = false;
							
					if (retVal) 
					{
						document.creditCardInfo.fileStatus.value = 1;
					}
					else
					{
						document.creditCardInfo.fileStatus.value = 0;
					}
				}
			}
			else
			{
				cbs_alert("Purchase DENIED\n\nReason:  "+approvalText);
				clearAll();	//Added 5Jan04, JJ
				document.creditCardInfo.fileStatus.value = -1;
				return;
			}
		}
		else
		{
		}
	}
	
	
	function PrintReceipt()
	{
		var msg;
		var ccAuthCode;
		var ccExpDate;
		var ccType;
		var ccAcctNum;
		var ccCardHolder;
		var ccTotal;
		var ticketNums;
		ticketNums = document.creditCardInfo.ticketNums.value;
		ccAuthCode = document.creditCardInfo.approvalCode.value;
		ccExpDate = document.creditCardInfo.txtCCExpDate.value;
		ccType = document.creditCardInfo.selCreditType.value;
		ccAcctNum = document.creditCardInfo.txtCCNumber.value;
		ccAcctNum = "XXXX XXXX XXXX "+ccAcctNum.substr(12,4);
		ccCardHolder = document.creditCardInfo.txtCCCustName.value;
		ccTotal = document.creditCardInfo.ccTotal.value;
		msg = "ccAuthCode = "+ccAuthCode;
		msg = msg+"\n ticketNums = "+ticketNums;
		msg = msg+"\n ccExpDate = "+ccExpDate;
		msg = msg+"\n ccType = "+ccType;	
		msg = msg+"\n ccAcctNum = "+ccAcctNum;
		msg = msg+"\n ccCardHolder = "+ccCardHolder;
		msg = msg+"\n ccTotal = "+ccTotal;	
		//cbsAlert(msg,cbsOKOnly,"JJtestFunction");
		PrintCreditReceipt(ticketNums,ccAuthCode,ccExpDate,ccType,ccAcctNum,ccCardHolder,ccTotal);//passing TICKET #, not inv #
	}
	
	
	function printRackLocations() 
	{
		var rackStrForPrint;
		rackStrForPrint = document.creditCardInfo.rackInfoForPrint.value;
		//alert(rackStrForPrint);
		PrintRackLocations(rackStrForPrint);		
	}	
	
	
	function displayProcessing()
	{
		document.creditCardInfo.style.cursor="wait";
		changeMouse();
		document.creditCardInfo.txtProcessing.style.visibility="visible";
	}
	
	
	function WaitTimer(InTime)
	{
		//JJ, 7Jan04
		//This function allows user to set a wait period.
		//Incoming parameter is the number of seconds to wait.
		//Displays the text message "PROCESSING" in the credit card form.
		//If used in another form, comment out or change the 2 lines beginning
		// with "document..."
		
		//Set timer
		var d, timer;
		var MinMilli;
		MinMilli = 1000 * InTime;
		d = new Date();
		timer = d.getTime();
	
		//For "time" number of seconds...
		do
		{
			d = new Date();
			document.creditCardInfo.txtProcessing.style.visibility="visible";
		}
		while(d.getTime() < (timer+MinMilli));
		
		document.creditCardInfo.txtProcessing.style.visibility="hidden";
	}
	
	
</script>

<BODY topmargin=0 leftmargin=0 onload="setFocusOnFirstControl();">

<center>

<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/cashdrawer.inc" -->
<!-- #include file="../include/localprinter.inc" -->

<%
'Following adds an "S" to Invoice List label if needed
dim tempString
dim searchString
searchString = ","
dim myPos
tempString = CStr(InvoiceList)
myPos = InStr(tempString,searchString)
if myPos>0 then 
	tempString = "s" 
else
	tempString = ""
end if
%>
<B class="pageHeading">&nbsp;Please swipe or enter Credit Card information</B>
</center>

<FORM id="creditCardInfo" name="creditCardInfo" action="creditCardPickup.asp" method="post" onSubmit ="return validateEnterKey();" >

	<INPUT type="hidden" name="InvoiceList" value="<%= InvoiceList%>">
	<INPUT type="hidden" name="ticketNums" value="<%= ticketNums%>">
	<INPUT type="hidden" name="custSeqNumber" value="<%= custSeqNumber%>">
	<INPUT type="hidden" name="empID" value="<%= empID%>">
	<INPUT type="hidden" name="totalInv" value="<%= totalInv%>">
	<INPUT type="hidden" name="terminalId" value="<%= terminalId%>">
	<INPUT type="hidden" name="sessionName" value="<%= sessionName%>">
	<INPUT type="hidden" name="custCreditCardTypeID" value="<%= custCreditCardTypeID%>">
	<INPUT type="hidden" name="custCreditCardNo" value="<%= custCreditCardNo%>">
	<%custCreditCardExpDate = custCreditCardExpMonth&custCreditCardExpYear%>
	<INPUT type="hidden" name="custCreditCardExpDate" value="<%= custCreditCardExpDate%>">
	<INPUT type="hidden" name="ccTotal" value="<%= ccTotal%>">
	<INPUT type="hidden" name="onFile" value="<%= onFile%>">
	<INPUT type="hidden" name="fileStatus" value="<%= fileStatus%>">
	<INPUT type="hidden" name="approvalCode" value="<%= approvalCode%>">
	<INPUT type="hidden" name="creditFormName" value="<%= creditFormName%>">	
	<INPUT type="hidden" name="rackInfoForPrint" value="<%= printRackInfo%>">	
	<INPUT type="hidden" name="xChargePath" value="<%= xChargePath%>">
	<INPUT type="hidden" name="isPrePay" value="<%= isPrePay%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="promptToAddCC" value="<%if ObjMiscSetUp.Item("promptToAddCC") then Response.Write "1" else Response.Write "0" end if%>">

	

	<INPUT id=txtCCData name=txtCCData maxLength=200 class=text style=" HEIGHT:1px; WIDTH:1px" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()" onClick="setLastControl()" onKeyPress="changeMouse()" size=5 tabindex=-1>
					
	<!-- Invoice Number, Total Due, Buttons -->
	<TABLE ALIGN=center WIDTH=90% BORDER=0 CELLSPACING=2 CELLPADDING=0 style="font-size=12pt">
		
		<!-- Invoice Numbers -->
		<TR valign=top>
			<TD class="label" align="right" style=" WIDTH: 30%"><%=""%>Invoice Number<%=tempString%>&nbsp;</TD>
			<TD align=left style=" text-align:left; font-size:12pt; font-style:normal; font-weight:bold">
				<%= InvoiceList%></TD>
				
			<TD class="label" align="right" style=" WIDTH: 15%"><%=""%>Rack<%=tempString%>&nbsp;</TD>
			<TD align=left style="HEIGHT:100%; WIDTH: 25%; text-align:left; font-size:12pt; font-style:normal; font-weight:bold">
				<%= rackString%></TD>				
		</TR>
				
		<!-- Total Due -->
		<TR>
			<TD align=right class="label" style="font-style:bold; font-weight:bold">Total Due&nbsp;</TD>
				<!--
				<%dim tempTotalDue
				  if (formatnumber(pickupObj.getTotalAmountDue, 2)-formatnumber(pickupObj.totalAmtPaid, 2))>0 then							  
					tempTotalDue = formatnumber(pickupObj.getTotalAmountDue, 2)-formatnumber(pickupObj.getPaymentByType(""), 2)
				  else
					tempTotalDue = 0.00
				  end if%>	
				 -->					
			<TD style="color:Red; text-align:left; font-size:12pt; font-style:normal; font-weight:bold">
				<!--<%= formatcurrency(tempTotalDue,2)%>-->
				$<%= formatnumber(ccTotal,2,true)%>
			</TD>
			<TD><INPUT id=txtCCAddresstag name=txtCCAddresstag class="text" align="right" style="width=100%; border-style:none; color:red;  background-color:#F7FBFC; text-align:right; VISIBILITY:hidden" value="Address * " readonly tabindex=-1></TD>
			<TD><INPUT id=txtCCAddress name=txtCCAddress maxLength=50 class=text  align=left style="WIDTH: 100%; HEIGHT: 25px; font-size=12pt; VISIBILITY:hidden" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()" onClick="setLastControl()" size=5 tabindex=5></TD>
		</TR>
		
		<!-- Card Type -->
		<TR>
			<TD class="label" align="right">Credit Card Type<font color=red> * </font>&nbsp;</TD>
			
			<TD><SELECT id=selCreditType name=selCreditType style="font-size=12pt" tabindex=1>
				<!-- <Option value = "0" ></option> -->
					<%
						dim creditCardTypes
						Set creditCardTypes = getCreditCardsTypes()
						if creditCardTypes.recordcount <> 0 then
							while not creditCardTypes.EOF
						%>
							<OPTION VALUE= "<%= creditCardTypes.Fields("creditcardTypeId").Value %>" <%if creditCardTypes.Fields("creditcardTypeId").Value = custCreditCardTypeID then %>selected<%end if%>> <%= creditCardTypes.Fields("name").Value %></OPTION>
						<%
								creditCardTypes.MoveNext
							wend
						else
						%>
							<OPTION VALUE= "1">No Credit Cards setup in Setup | Customer Setup</OPTION>
						<%
						end if
					%>	
			<Option value = "0" ></option>
			</SELECT></TD>
			<TD><input id=txtCCCitytag name=txtCCCitytag class="text" align="right" style="width=100%; border-style:none; color:red; background-color:#F7FBFC; text-align:right; VISIBILITY:hidden" value="City * " tabindex=-1 readonly></TD>
			<TD><INPUT id=txtCCCity name=txtCCCity maxLength=15 class=text align=left style="WIDTH: 100%; HEIGHT: 25px; font-size=12pt; VISIBILITY:hidden" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" size=5 tabindex=6></TD>
			<INPUT type="hidden" name="firstDigits" value="<%= firstDigits%>" tabindex=-1>
			<INPUT type="hidden" name="cardTypeArray" value="<%= cardTypeArray%>" tabindex=-1>	
		</TR>
		
		<!-- Card Number -->
		<TR>
			<TD class="label" align="right">Account Number<font color=red> * </font>&nbsp;</TD>
			<TD><INPUT id=txtCCNumber tabindex=2 name=txtCCNumber maxLength=200 class=text style=" HEIGHT: 25px; font-size=12pt" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()" onClick="setLastControl()" size=5 value=<%= custCreditCardNo%> ></TD>		
			<TD><input id=txtCCStatetag name=txtCCStatetag class="text" align="right" style="width=100%; border-style:none; color:red; background-color:#F7FBFC; text-align:right; VISIBILITY:hidden" value="State * " tabindex=-1 readonly></TD>
			<TD><INPUT id=txtCCState name=txtCCState maxLength=2 class=text align=left style="WIDTH: 20%; HEIGHT: 25px; font-size=12pt; VISIBILITY:hidden" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" size=5 tabindex=7></TD>						
		</TR>
		
		<!-- Expiration Date -->
		<TR>
			<TD class="label" align="right">Expiration Date ("mmyy")<font color=red> * </font>&nbsp;</TD>
			<TD><INPUT id=txtCCExpDate tabindex=3 name=txtCCExpDate maxLength=4 class=text style="WIDTH: 50px; HEIGHT: 25px; font-size=12pt" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" size=5 value=<%= custCreditCardExpDate%>></TD>
			<TD><input id=txtCCZiptag name=txtCCZiptag class="text" align="right" style="width=100%; border-style:none; color:red; background-color:#F7FBFC; text-align:right; VISIBILITY:hidden" value="Zip * " readonly tabindex=-1></TD>
			<TD><INPUT id=txtCCZip name=txtCCZip maxLength=5 class=text align=left style="WIDTH: 55px; HEIGHT: 25px; font-size=12pt; VISIBILITY:hidden" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" size=5 tabindex=8></TD>
		</TR>
		
		<!-- Customer Name on INVOICE -->
		<TR>
			<TD class="label" align="right">Customer Name (on Invoice)&nbsp;</TD>
			<TD align=left style=" text-align:left; font-size:12pt; font-style:normal; font-weight:normal">
				<%= customerName%></TD>
			<TD> <INPUT id=txtCCcvctag name=txtCCcvctag class=text align=right style="width=100%; border-style:none; color:red;  background-color:#F7FBFC; text-align:right; visibility=hidden" value="CVC * " readonly tabindex=-1></TD>
			<TD> <INPUT id=txtCCcvc name=txtCCcvc maxLength=5 class=text  align=left style="WIDTH: 50px; HEIGHT: 25px; font-size=12pt; VISIBILITY:hidden" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" size=5 tabindex=9></TD>				
		</TR>
		
		<!-- Customer Name on CARD -->
		<TR>
			<TD class="label" align="right" >Customer Name (on Credit Card)&nbsp;</TD>
			<TD><INPUT id=txtCCCustName name=txtCCCustName maxLength=20 class=text style="WIDTH: 250px; HEIGHT: 25px; font-size=12pt" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" size=5 tabindex=4></TD>
			<TD><INPUT id=txtProcessing name=txtProcessing class=text style="WIDTH: 125px; HEIGHT: 25px; VISIBILITY:hidden; border-style:none;  background-color:#F7FBFC; color:red"  
					 size=5 value="PROCESSING....." readonly>&nbsp;&nbsp;&nbsp;&nbsp;</TD>					
		</TR>
		
		<tr height=10><td></td><td><font color=red>Items marked with * are required.</td></tr>
		
		<!-- Buttons -->
		<tr>	
			<td align="middle" colspan=4>
				<INPUT align=right class=touch id=bttnPrintRackLocations name=bttnPrintRackLocations type=button value="" style="background-image:url(../images/Print-Rack.gif)" onClick = "printRackLocations();" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<INPUT class=touchnoborder id=processButton name=processButton type=button style="BORDER-RIGHT: deepskyblue thick outset; BORDER-TOP: silver thick ridge; FONT-WEIGHT: bold; FONT-SIZE: 12pt; BORDER-LEFT: silver thick ridge; BORDER-BOTTOM: deepskyblue thick outset; BACKGROUND-REPEAT: no-repeat; FONT-STYLE: italic; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: deepskyblue" onmousedown="displayProcessing()" onClick="processCC()" value="Process">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<INPUT class=touchnoborder id=clearButton name=clearButton type=button style="BORDER-RIGHT: thick outset; BORDER-TOP: snow thick ridge; FONT-WEIGHT: bold; FONT-SIZE: 12pt; BORDER-LEFT: snow thick ridge; BORDER-BOTTOM: thick outset; FONT-STYLE: italic; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: gainsboro; FONT-VARIANT: small-caps" onClick="clearAll()" value="Clear All">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;			
				<!--<INPUT class=touchnoborder id=okButton name=okButton type=button style="BACKGROUND-IMAGE: url(../images/ok.gif)" onClick= "" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-->
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button style="BACKGROUND-IMAGE: url(../images/Cancel.gif)" onClick="history.back()" >
				<!-- <INPUT class=touchnoborder id=testButton name=testButton type=button value="TEST" style="" onClick="testFunction()">-->				
			</td>
		</tr>
		
	</TABLE>
	
	<!-- Keyboard -->
	<table ALIGN=center width="100%">
		<tr height=20><td></td></tr>
		<TR height=20 colspan="5"></TR>
		<tr>
			<td><!-- #include file="../include/keyboard.inc" --></td>
		</tr>
				
	</table>
	
</FORM>
</BODY>
</HTML>
