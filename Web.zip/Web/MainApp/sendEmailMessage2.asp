<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 900 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
    dim query, rs
    dim customerSeq, contactPref, notificationIP
    customerSeq = getReqVar("customerSeq")

    query = "select contactPref from customer where customerSequenceNumber = " & customerSeq
    set rs = getdisconnectedrecordset(query)
    contactPref = rs("contactPref")

    notificationIP = getMessengerShortPath()


    query = "select id, message, description, subject, emailOnly from SmsMessage where message is not null and description != 'Reserved'"
    set rs = getdisconnectedrecordset(query)


	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
%>

<HTML>
<HEAD>
<TITLE>Send Email Message</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<FORM id="sendEmail" name="sendEmail" action="" method="post">
<script language="javascript" type="text/javascript" src="/Script/webui.js"> </script>
<script type="text/javascript" src="../external/jquery.js"></script>
<script language="javascript" type="text/javascript">
    function disableNew() {
        document.sendEmail.newMessage.disabled = true;
        document.sendEmail.newSubject.disabled = true;
        document.sendEmail.messageId.disabled = false;
        document.sendEmail.savedSubject.disabled = false;
        document.sendEmail.savedMessage.disabled = false;
    }
    function disableStored() {
        document.sendEmail.newMessage.disabled = false;
        document.sendEmail.newSubject.disabled = false;
        document.sendEmail.messageId.disabled = true;
        document.sendEmail.savedSubject.disabled = true;
        document.sendEmail.savedMessage.disabled = true;
    }
    function loadMessage(message, subject) {
        document.getElementById('savedMessage').value = unescape(message);
        document.getElementById('savedSubject').value = unescape(subject);
    }

    function submitForm() {
            var loc = window.location.href;
            var extraCut = 0;
            if (loc.indexOf(":80") != -1)
                extraCut = 5;
            var endStop = loc.indexOf("/mainapp")
            if (endStop == -1)
                endStop = loc.indexOf("/MainApp")

            endStop = endStop - extraCut;
            var ipAddress = loc.substring(0, endStop);

        var url = ipAddress + "<%=notificationIP%>/sendIndividualEmail?customerSeq=<%=customerseq%>";
        if($('input[name=messageType]:checked').val() === "New") {
            var newMessage = $.trim(document.getElementById('newMessage').value);
            var newSubject = $.trim(document.getElementById('newSubject').value);
            if (newMessage === "") {
                cbs_alert("Cannot send blank message");
                return;
            }
            if (newSubject === "") {
                cbs_alert("Cannot send blank subject");
                return;
            }
            url += "&employeeId=" + encodeURIComponent(<%=session("employeeID")%>);
            url += "&message=" + encodeURIComponent(newMessage);
            url += "&subject=" + encodeURIComponent(newSubject);
        }
        else {
            if (document.getElementById('messageId').value === "0") {
                cbs_alert("Must select a message to send");
                return;
            }
            url += "&messageId=" + document.getElementById('messageId').value;
        }

        //alert(url);
        $.ajax({
            type: "POST",
            url: url,
            dataType: "text",
            timeout: "3000",
            success: function(xhr) {
                cbs_alert("Email Message Sent");
                window.close();
            },
            error: function(xhr, ajaxOptions, thrownError) {
                cbs_alert("Unable to connect to CBS Messenger Service. Make sure service is running");
                window.close();
            }
        });
    }
</script>

<BODY topmargin=0 leftmargin=0>
<INPUT type="hidden" name="customerseq" value="<%=customerseq%>" />
<DIV id="statement_container">
<% if contactPref = 1 then %>
    <h6 style="color: red">Note: This customer prefers to get messages via sms</h6>
<% end if %>
<br />
<Input type=radio name=messageType value="New" onclick="disableStored()" checked>New Message
<br />
Subject: <input type="50" size="50" id="newSubject">
<br />
<textarea id="newMessage" cols="50" rows="10" ></textarea>
<br /><br />
<Input type=radio name=messageType value="Stored" onclick="disableNew()">Canned Messages
<br />
<select id="messageId" disabled onchange="if(this.options[this.selectedIndex].onclick != null){this.options[this.selectedIndex].onclick(this);}">
<option value="0"></option>
<% while not rs.eof %>
    <% if isnull(rs("emailOnly")) then %>
        <option value="<%=rs("id") %>" onclick="loadMessage('<%=escape(rs("message"))%>', '<%=(rs("subject"))%>')" ><%=rs("description")%></option>
    <% else %>
        <option value="<%=rs("id") %>" onclick="loadMessage('<%=escape(rs("message"))%> <%=escape(rs("emailOnly"))%>', '<%=escape(rs("subject"))%>')" >
            <%=rs("description")%>
        </option>
    <% end if %>
<%
	rs.movenext
	wend
	set rs = nothing
%>
</select>
<br /><br />
Subject:<input type="text" id="savedSubject" readonly disabled width="50" size="50">
<br />
<textarea id="savedMessage" name="savedMessage" readonly disabled cols="50" rows="10"></textarea>
</DIV>
<table ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR>
			<TD colspan="2" align=center>
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/OK.gif)" onClick= "submitForm()">
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onclick="window.close()">
			</TD>
		</TR>
</table>

<div style="border: 1px solid;   position: absolute;
                                                top: 8px;
                                                right: 60px;">
  <span style="font-size: 14px;"><b>Keyword Variables</b></span><br /><br />
  {storename}<br />{customername}<br />{firstname}<br />{lastname}
  <br /><br />
  <span style="font-size: 10px">Message text with these variables<br />will be replaced with the logical<br />values when sending message</span>
</div>
</BODY>
</FORM>
</HTML>

