<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<%

	const DELIVERY_STATUS_FINISH = 5
	const DELIVERY_STATUS_ADDING = 11
	const DELIVERY_STATUS_VERIFYING = 12
	const DELIVERY_STATUS_PAYMENTS1 = 13
	const DELIVERY_STATUS_MANIFEST = 14
	const DELIVERY_STATUS_UNDELIVERABLE = 15
	const DELIVERY_STATUS_PAYMENTS2 = 16

	const DELIVERY_ITEM_INVOICE_ERROR = -10
	const DELIVERY_ITEM_REMOVED = -1
	const DELIVERY_ITEM_READY = 0
	const DELIVERY_ITEM_ADDED = 1
	const DELIVERY_ITEM_STOP_WARNING = 10

	dim query
	dim currentWillCall	
	dim deliveryID
	dim deliveryDate
	
	deliveryID = getReqVar("deliveryID")
	deliveryDate = getCurrentDeliveryDate(deliveryid)
	set currentWillCall = getCurrentWillCall(deliveryID, deliveryDate)

	select case request.querystring("useraction")
	case "checkwillcall"

		if currentWillCall.recordcount <= 0 then
			response.redirect "deliveryFunction.asp?useraction=addcustomerstops&deliveryid=" & deliveryID & "&destination=" + Server.URLEncode("deliveryCCBatch.asp?useraction=checkadd&deliveryID=" & deliveryID )
		end if
	case "addselectedstops"
		addSelectedStops deliveryID
		response.redirect "deliveryFunction.asp?useraction=addcustomerstops&deliveryid=" & deliveryID & "&destination=" + Server.URLEncode("deliveryCCBatch.asp?useraction=checkadd&deliveryID=" & deliveryID )
	case "removeselectedstops"
		removeSelectedStops deliveryID
	end select
	
	
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	
	function getCurrentDeliveryDate(deliveryid)
		dim query, rs

		getCurrentDeliveryDate = Date()
		
		if deliveryid <> "" then

			query = " select min(deliverydate) as routedeliverydate from deliveryrouteassigned where deliveryid = " & deliveryid

			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				if not isnull(rs("routedeliverydate")) then
					getCurrentDeliveryDate = rs("routedeliverydate")
				end if
			end if
		end if
	end function

	function getWillCallNote(willCallID)
		dim query, rs
		
		query = " select isnull(note, 'Scheduled Stop') as note from deliverywillcall where deliverywillcallid = " & willCallID
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getWillCallNote = rs("note")
		end if
		
		set rs = nothing
	end function
	
	function addSelectedStops(deliveryID)
		dim selectedStops
		dim selectedStop
		dim customerSeq
		dim invoiceNumber
		dim fields
		dim willCallID
		
		set selectedStops = request.form("selectedStop")
	
		for each selectedStop in selectedStops
			fields = split(selectedStop, ",")

			willCallID = fields(0)
			customerSeq = fields(1)
			invoiceNumber = fields(2)

			if invoiceNumber <> "" then
				addWillCallTicket deliveryID, invoiceNumber
			end if
			
			addCustomerStop deliveryID, customerSeq, 3, getWillCallNote(willCallID)
			
			moveWillCallToDelivery willCallID, deliveryID
		next

	end function
	
	function removeSelectedStops(deliveryID)
		dim selectedStops
		dim selectedStop
		dim customerSeq
		dim invoiceNumber
		dim fields
		dim willCallID
		
		set selectedStops = request.form("selectedStop")
	
		for each selectedStop in selectedStops
			fields = split(selectedStop, ",")

			willCallID = fields(0)
			customerSeq = fields(1)
			invoiceNumber = fields(2)

			if invoiceNumber <> "" then
				removeWillCallTicket deliveryID, invoiceNumber
			end if
			
			removeCustomerStop deliveryID, customerSeq
			
			removeWillCallFromDelivery willCallID
		next
	end function
	
	function moveWillCallToDelivery(willCallID, deliveryID)
		dim query
		
		query = " update deliverywillcall set deliveryid = " & deliveryID
		query = query & " where deliverywillcallid = " & willCallID
		
		qryexecute query
	
	end function
	
	function removeWillCallFromDelivery(willCallID)
		dim query
		
		query = " update deliverywillcall set deliveryid = null "
		query = query & " where deliverywillcallid = " & willCallID
		
		qryexecute query
	
	end function
	
	function removeCustomerStop(deliveryID, customerSeq)
		dim query
		
		query = " delete deliverystop where "
		query = query & " deliveryid = " & deliveryid
		query = query & " and stoptype = 3 "
		query = query & " and customersequencenumber = " & customerSeq

		qryexecute query
	end function
	
	function removeWillCallTicket(deliveryID, invoiceNumber)
		dim query
		
		query = " delete deliveryitem where "
		query = query & " deliveryid = " & deliveryid
		query = query & " and invoicenumber = " & invoiceNumber
		
		qryexecute query
	end function
	
	function addWillCallTicket(deliveryID, invoiceNumber)
		dim query, rs

		query = " delete from deliveryitem where invoiceNumber = '" & invoiceNumber & "'"
		query = query & " and deliveryid = " & deliveryID
		qryexecute query

		query = " insert into deliveryitem (invoiceNumber, status, deliveryid) "
		query = query & " values ('" & invoiceNumber & "', 1, " & deliveryID & ")"
		qryexecute query


	end function
	
	function isStopOnDelivery(deliveryID, customerSequenceNumber, stopType)
		dim query, rs
		
		query = " select count(*) as cnt from deliverystop "
		query = query & " where deliveryid = " & deliveryid
		query = query & " and customersequencenumber = " & customerSequenceNumber
		query = query & " and stoptype = " & stoptype

		set rs = getdisconnectedrecordset(query)
		
		isStopOnDelivery = false
		
		if rs.recordcount > 0 then
			isStopOnDelivery = rs("cnt") > 0
		end if
	
		set rs = nothing
	end function
	
	function strToSQL(v)
		if isnull(v) then
			strToSQL = "null"
		else
			strToSQL = "'" & replace(v, "'", "''") & "'"
		end if
	end function
	
	function boolToSQL(v)
		if isnull(v) then
			boolToSQL = "null"
		elseif v then
			boolToSQL = 1
		else
			boolToSQL = 0
		end if
	end function
	
	function addCustomerStop(deliveryID, customerSequenceNumber, stopType, note)
		dim customerData
		
		if not isStopOnDelivery(deliveryID, customerSequenceNumber, stopType) then
		
			set customerData = getCustomerData(customerSequenceNumber, deliveryID)

			if customerData.recordcount > 0 then
				query = " insert into deliverystop ("
				query = query & " customersequencenumber, "
				query = query & " deliveryaddress, "
				query = query & " deliverynotes, "
				query = query & " routeid, "
				query = query & " customerdeliveryid, "
				query = query & " deliveryid, "
				query = query & " stoporder, "
				query = query & " deliveryphone, "
				query = query & " parentcustomersequencenumber, "
				query = query & " billingcustomersequencenumber, "
				query = query & " stopType "
				query = query & " ) "
				query = query & " values( "
				query = query & customerData("customersequencenumber") & ", "
				query = query & strToSQL(customerData("deliveryaddress")) & ", "
				query = query & strToSQL(note & "<br>" & customerData("deliverynotes")) & ", "
				query = query & customerData("routeid") & ", "
				query = query & strToSQL(customerData("customerdeliveryid")) & ", "
				query = query & deliveryID & ", "
				query = query & customerData("stopOrder") & ", "
				query = query & strToSQL(customerData("deliveryPhone")) & ", "
				query = query & strToSQL(customerData("parentCustomerSeq")) & ", "
				query = query & strToSQL(customerData("billingCustomerSeq")) & ", "
				query = query & stopType 
				query = query & ") "

				qryexecute query
			end if
		end if
	end function
	
	function getRoutesOnDelivery(deliveryID)
		dim query, rs
		if deliveryid <> "" then
			query = " select routenumber from deliveryrouteassigned where deliveryid = " & deliveryid
			set rs = getdisconnectedrecordset(query)
			
			while not(rs.eof or rs.bof)
				if getRoutesOnDelivery <> "" then getRoutesOnDelivery = getRoutesOnDelivery & ","
				getRoutesOnDelivery = getRoutesOnDelivery & rs("routenumber")
				rs.movenext
			wend
			
			set rs = nothing
		end if
	end function
	
	
	function getCustomerData(customerSequenceNumber, deliveryid)
		dim query, rs
		
		query = " select  "
		query = query & " customerdelivery.customersequencenumber, "
		query = query & " customerdelivery.deliveryaddress, "
		query = query & " customerdelivery.deliverynotes, "
		query = query & " customerdelivery.routeid, "
		query = query & " customerdelivery.id as customerdeliveryid, "
		query = query & " customerdelivery.stopOrder, "
		query = query & " customerdelivery.deliveryPhone, "
		query = query & " customer.parentCustomerSeq, "
		query = query & " customer.billingCustomerSeq "
		query = query & " from customerdelivery "
		query = query & " inner join customer on "
		query = query & " customerdelivery.customersequencenumber = customer.customersequencenumber "
		query = query & " where customerdelivery.customersequencenumber = " & customerSequenceNumber
		query = query & " and customerdelivery.active = 1 "
		if getRoutesOnDelivery(deliveryID) <> "" then
		query = query & " and customerdelivery.routeid in (" & getRoutesOnDelivery(deliveryID) & ")"
		end if
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount = 0 then
			query = " select customer.customersequencenumber, "
			query = query & " dbo.formatCustomerAddress(customer.customersequencenumber, ' ', 2) as deliveryaddress, "
			query = query & " 'SCHEDULED DELIVERY' as deliverynotes, "
			query = query & " 0 as routeid, "
			query = query & " null as customerdeliveryid, "
			query = query & " 0 as stopOrder, "
			query = query & " dbo.formatPhone(customer.mainareacode, customer.mainphone) as deliveryPhone, "
			query = query & " customer.parentCustomerSeq as parentCustomerSeq, "
			query = query & " customer.billingCustomerSeq as billingCustomerSeq "
			query = query & " from customer where customersequencenumber = " & customerSequenceNumber

			set rs = nothing
			set rs = getdisconnectedrecordset(query)
		end if

		set getCustomerData = rs
	end function	
	
	
	function getCurrentWillCall(deliveryID, deliveryDate)
		dim query
		
		query = " select  deliverywillcall.*, isnull(route.name, '') as routename, isnull(convert(varchar, isnull(deliverywillcall.scheduleddate, isnull(ticket.createddate, getdate())), 101), 'Anytime') as scheduleddate, customer.customername, isnull(ticket.invoicenumber, '') as invoicenumber from deliverywillcall "
		query = query & " inner join customer on deliverywillcall.customersequencenumber = customer.customersequencenumber "
		query = query & " left outer join ticket on deliverywillcall.ticketnumber = ticket.ticketnumber "
		query = query & " left outer join route on customer.routenumber = route.routenumber "
		query = query & " where (scheduleddate is null or datediff(d, scheduleddate, '" & deliveryDate & "') >= 0) "
		query = query & " and (ticket.ticketstatus is null or (ticket.ticketstatus = 'AC' and (ticket.duedate is null or datediff(d, ticket.duedate, '" & deliveryDate & "') >= 0))) "
		query = query & " and dbo.countPriceLaterLines(ticket.ticketnumber) = 0 and status = 0 and (deliveryid is null or deliveryid = " & deliveryid & ")"

		if deliveryID <> "" then
			query = query & " and (customer.routenumber = 0 or customer.routenumber in (select routenumber from deliveryrouteassigned where deliveryid = " & deliveryid & "))"
		end if

		query = query & " order by deliverywillcall.deliverywillcallid "

		set getCurrentWillCall = getdisconnectedrecordset(query)
	end function
	
	function getWillCallIconIMG(rs)
		select case lcase(rs("actionrequired"))
		case "pickup"
			getWillCallIconIMG = "<img src=""/Images/Route/incoming.GIF"" />"
		case "dropoff"
			getWillCallIconIMG = "<img src=""/Images/Route/outgoing.GIF"" />"
		end select
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">


<style type="text/css">

</style>

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>


<script language="javascript" type="text/javascript">

	function SetRowCheckedStatus(row, check, value) {

		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "selectedStop") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "selectedStop") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}


	function removeStops() {
		document.deliverywillcall.action = "?useraction=removeselectedstops"
		document.deliverywillcall.submit();
	}
	function continueDelivery() {
		document.deliverywillcall.action = "?useraction=addselectedstops"
		document.deliverywillcall.submit();
	}
	
	function exit() {
		document.deliverywillcall.action = "deliveryManager.asp"
		document.deliverywillcall.submit();
	}
	
	function selectAll() {
		var il = document.deliverywillcall;
		var len = il.elements.length;
		var i, e;

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "selectedStop") {
				SetRowCheckedStatus(e.parentNode.parentNode, e, !e.checked);
		    }
		}
	}


	
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->

<H1>Delivery - Will Call (1/5)</H1>

<FORM name="deliverywillcall" id="deliverywillcall" method=POST  onsubmit="return false" >

<INPUT type="hidden" name="deliveryID" value="<%=deliveryID%>" />



<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON style="vertical-align: top"onclick="selectAll()">Invert<BR>Selection</BUTTON>
		<BUTTON onclick="removeStops()">Remove</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
    <BUTTON onclick="continueDelivery()">Next</BUTTON>
	</SPAN>
</DIV>	


<table style="width:100%" class="itable" cellspacing="0">
<tr>
	<th>&nbsp;</th>
	<th>&nbsp;</th>
	<th>Customer Name</th>
	<th>Route</th>
	<th>Invoice</th>
	<th>Scheduled Date</th>
	<th>Status</th>
</tr>
<%
	set currentWillCall = getCurrentWillCall(deliveryID, deliveryDate)
	while not(currentWillCall.eof or currentWillCall.bof)
%>
<tr onclick="ToggleRowChecked(this)" >
	<td>
	<%
		dim showCheckbox
		
		if isnull(currentWillCall("deliveryid")) then
			showCheckbox = true
		elseif trim(currentWillCall("deliveryid")) = trim(deliveryid) then
			showCheckbox = true
		else
			showCheckbox = false
		end if
	
		if showCheckbox then		
	%>
	<input type="checkbox" name="selectedStop"  onclick="ToggleRowChecked(this.parentNode.parentNode);" value="<%=currentWillCall("deliverywillcallid")%>,<%=currentWillCall("customersequencenumber")%>,<%=currentWillCall("invoicenumber")%>" />
	<%
		end if
	%>
	</td>
	<td><%=getWillCallIconIMG(currentWillCall)%>&nbsp;</td>
	<td><%=Server.HTMLEncode(currentWillCall("customername"))%></td>
	<td><%=Server.HTMLEncode(currentWillCall("routename"))%></td>
	<td><%=Server.HTMLEncode(currentWillCall("invoicenumber"))%></td>
	<td><%=Server.HTMLEncode(currentWillCall("scheduleddate"))%></td>
	<td>
	<%
		if isnull(currentWillCall("deliveryid")) then
			response.write "Waiting for delivery"
		elseif trim(currentWillCall("deliveryid")) = trim(deliveryid) then
			response.write "On this delivery"
		else
			response.write "On delivery " & currentWillCall("deliveryid")
		end if
	
	%>
	</td>
</tr>
<%
		currentWillCall.movenext
	wend
	set currentWillCall = nothing
%>
</table>

</FORM>

</BODY>
</HTML>
