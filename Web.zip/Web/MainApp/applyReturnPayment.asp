﻿<%@ Language=VBScript %>
<% Option Explicit %>

<!-- #include file="../include/miscSetupObject.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/security.asp" -->
<!-- #include file="XcHpfCardTransaction.asp" -->
<!--#include file="../include/messages.asp" -->

<% sec_RequestAccess Request.QueryString("useraction") %>

<%
    '***********************************************************************
	'Name   : Apply Return Payment
	'
    'Created 17-Jun-2015
    '
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' ----------------------------------------------------------------------
    '
	'***********************************************************************

    Dim rstPayment
    Dim paymentType
    Dim customerSequenceNumber
    Dim customerName
    Dim amountPaid
    Dim returnAmount
    Dim ticketNumber
    Dim paymentNumber

    Dim dateTypeCriteria
    Dim toDateCriteria
    Dim fromDateCriteria
    Dim customerNameCriteria
    Dim invoiceNumberCriteria
    Dim paymentAmountCriteria

    If Not IsObject(Session("miscSetUp")) Then
		initializeMiscSetUp
	End If

    paymentType = Request.QueryString("paymentType")
    ticketNumber = Request.QueryString("ticketNumber")
    paymentNumber = Request.QueryString("paymentNumber")

    If Request.QueryString("userAction") = "submit" Then
        submitForm()
    Else
        saveSearchCriteria()
        getActiveReturnPaymentTypes()
        getPaymentDetails()
    End If
    
    Dim m_enableCreditCardProcessing
    Function enableCreditCardProcessing()
        If IsEmpty(m_enableCreditCardProcessing) Then
            Dim rst

            Dim sql
            sql = "SELECT CASE WHEN RTRIM(ccpd.Description) <> 'None' THEN 1 ELSE 0 END AS enableCreditCardProcessing " _
                & "FROM dbo.MiscSetup ms JOIN dbo.CreditCardProcessorDomain ccpd ON ms.CreditCardProcessorDomainID = ccpd.CreditCardProcessorDomainID " _
                & "WHERE storeID = 1"

            Set rst = getDisconnectedRecordset(sql)

            If rst.RecordCount > 0 Then
                m_enableCreditCardProcessing = rst("enableCreditCardProcessing")
            End If

            rst.Close
            Set rst = Nothing
        End If

        enableCreditCardProcessing = m_enableCreditCardProcessing
    End Function

    Sub saveSearchCriteria
        dateTypeCriteria = Request.QueryString("dateTypeCriteria")
        fromDateCriteria = Request.QueryString("fromDateCriteria")
        toDateCriteria = Request.QueryString("toDateCriteria")
        customerNameCriteria = Request.QueryString("customerNameCriteria")
        invoiceNumberCriteria = Request.QueryString("invoiceNumberCriteria")
        paymentAmountCriteria = Request.QueryString("paymentAmountCriteria")
    End Sub

	Function getActiveReturnPaymentTypes()
		Dim sql
		sql = "SELECT * FROM StorePaymentType WHERE enabled = 1 AND paymentTypename IN ('Cash', 'Credit Card') AND storeID = " & Session("storeid") & " ORDER BY displaySequence"
		Set rstPayment = getdisconnectedRecordset(sql)
	End Function

    Function getPaymentDetails()

        Dim sql
        If ticketNumber <> "" Then
            sql = "SELECT c.customerSequenceNumber, c.customerName, t.amountPaid - ISNULL(rp.reversePaymentAmount, 0) AS amountPaid FROM dbo.Ticket t JOIN dbo.Customer c ON t.customerSequenceNumber = c.customerSequenceNumber " _
                & "LEFT JOIN (SELECT rpt.TicketID, SUM(ISNULL(rpt.Amount, 0)) AS reversePaymentAmount FROM dbo.ReversePaymentTracking rpt GROUP BY rpt.TicketID) rp ON t.ticketNumber = rp.TicketID " _
                & "WHERE t.ticketNumber = " & ticketNumber
        ElseIf paymentNumber <> "" Then
            sql = "SELECT c.customerSequenceNumber, c.customerName, p.amountPaid - ISNULL(rp.reversePaymentAmount, 0) AS amountPaid FROM dbo.Payment p JOIN dbo.Customer c ON p.customerSequenceNumber = c.customerSequenceNumber " _
                & "LEFT JOIN (SELECT rpt.PaymentID, SUM(ISNULL(rpt.Amount, 0)) AS reversePaymentAmount FROM dbo.ReversePaymentTracking rpt GROUP BY rpt.PaymentID) rp ON p.paymentNumber = rp.PaymentID " _
                & "WHERE p.paymentNumber =" & paymentNumber
        End If

        If Not IsEmpty(sql) Then
            Dim rstPayment
            Set rstPayment = getDisconnectedRecordset(sql)
            
            If rstPayment.RecordCount > 0 Then
                customerSequenceNumber = rstPayment("customerSequenceNumber")
                customerName = rstPayment("customerName")
                amountPaid = rstPayment("amountPaid")
            End If
        End If
    
    End Function

    Function submitForm()
        If Request.QueryString("paymentType") = "Cash" Then
            applyCashReturn()
        End If

        Dim dateTypeCriteria: dateTypeCriteria = Request.Form("hdnDateType")
        Dim fromDateCriteria: fromDateCriteria = Request.Form("hdnFromDate")
        Dim toDateCriteria: toDateCriteria = Request.Form("hdnToDate")
        Dim customerNameCriteria: customerNameCriteria = Request.Form("hdnCustomerName")
        Dim invoiceNumberCriteria: invoiceNumberCriteria = Request.Form("hdnInvoiceNumber")
        Dim paymentAmountCriteria: paymentAmountCriteria = Request.Form("hdnPaymentAmount")

        Response.Redirect("returnPayment.asp?dateTypeCriteria=" & Server.URLEncode(dateTypeCriteria) & "&toDateCriteria=" & Server.URLEncode(toDateCriteria) & "&fromDateCriteria=" & Server.URLEncode(fromDateCriteria) & _
                          "&customerNameCriteria=" & Server.URLEncode(customerNameCriteria) & "&invoiceNumberCriteria=" & invoiceNumberCriteria & "&paymentAmountCriteria=" & Server.URLEncode(paymentAmountCriteria))
    End Function

    Function applyCashReturn()

        Dim returnAmount
        Dim employeeID
        Dim terminalID
    
        returnAmount = Request.Form("txtReturnAmount")
        employeeID = Session("employeeID")
        terminalID = Session("terminalID")

        Dim sqlTxt
        sqlTxt = "EXECUTE dbo.ReturnPayment " _
                & "@PaymentType = 'Cash', " _
                & "@ReturnAmount = " & returnAmount & ", "

        If ticketNumber <> "" Then
            sqlTxt = sqlTxt & "@TicketNumber = " & ticketNumber & ", "
        ElseIf paymentNumber <> "" Then
            sqlTxt = sqlTxt & "@PaymentNumber = " & paymentNumber & ", "
        End If

        sqlTxt = sqlTxt & "@EmployeeID = " & employeeID & ", " _
                        & "@TerminalID = " & terminalID

        DbStartTrans()
		QryExecuteWithTrans(sqltxt)
		DbEndTrans()

    End Function
    
%>

<html>
    <head>
        <title>Apply Return Payment</title>
        <link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
    </head>
    <script type="text/javascript" src="/script/printing.js"></script>
    <script type="text/javascript" src="/script/validation.js"></script>
    <script type="text/javascript" src="/script/cashdrawer.js"></script>
    <script type="text/javascript">

        function setFocusOnLoad() {
            document.applyReturnPayment.txtReturnAmount.focus();
        }

        function cancelForm() {
            var dateTypeCriteria = document.applyReturnPayment.hdnDateType.value;
            var fromDateCriteria = document.applyReturnPayment.hdnFromDate.value;
            var toDateCriteria = document.applyReturnPayment.hdnToDate.value;
            var customerNameCriteria = document.applyReturnPayment.hdnCustomerName.value;
            var invoiceNumberCriteria = document.applyReturnPayment.hdnInvoiceNumber.value;
            var paymentAmountCriteria = document.applyReturnPayment.hdnPaymentAmount.value;

            document.applyReturnPayment.action = "returnPayment.asp?dateTypeCriteria=" + encodeURIComponent(dateTypeCriteria) + "&toDateCriteria=" + encodeURIComponent(toDateCriteria) + 
                                                 "&fromDateCriteria=" + encodeURIComponent(fromDateCriteria) + "&customerNameCriteria=" + encodeURIComponent(customerNameCriteria) + 
                                                 "&invoiceNumberCriteria=" + invoiceNumberCriteria + "&paymentAmountCriteria=" + encodeURIComponent(paymentAmountCriteria);
            document.applyReturnPayment.submit();
        }

        function submitForm() {
            var paymentType = document.getElementById('hdnPaymentType').value;

            document.applyReturnPayment.action = 'applyReturnPayment.asp?userAction=submit&paymentType=' + encodeURIComponent(paymentType) + '&ticketNumber=<%=ticketNumber %>&paymentNumber=<%=paymentNumber %>';
            document.applyReturnPayment.submit();
        }

        function validateField() {
            var amountReturned;

            if (!isNum1(trim(document.applyReturnPayment.txtReturnAmount.value), 0)) {
                cbs_alert("Please enter a valid amount.");
                document.applyReturnPayment.txtRemainingAmount.value = "";
                document.applyReturnPayment.txtReturnAmount.focus();
                return false;
            } else {
                populateRemainingAmount();
            }

            if (parseFloat(document.applyReturnPayment.txtReturnAmount.value) > parseFloat(document.applyReturnPayment.txtPaymentAmount.value)) {
                cbs_alert("Return amount can only be up to the original payment amount.");
                document.applyReturnPayment.txtReturnAmount.value = "";
                document.applyReturnPayment.txtRemainingAmount.value = "";
                document.applyReturnPayment.txtReturnAmount.focus();
                return false;
            }

            return true;
        }

        function populateRemainingAmount() {
            var x, tempval
            var value1
            var value2

            if (document.applyReturnPayment.txtReturnAmount.value > 0) {
                tempval = document.applyReturnPayment.txtReturnAmount.value.replace(/\./, "");
                document.applyReturnPayment.txtReturnAmount.value = tempval.substr(0, tempval.length - 2) + "." + tempval.substr(tempval.length - 2);

                tempval = eval(document.applyReturnPayment.txtPaymentAmount.value - document.applyReturnPayment.txtReturnAmount.value)
                tempval = new Number(tempval)
                tempval = tempval.toFixed(2)
                document.applyReturnPayment.txtRemainingAmount.value = tempval
            }
            else {
                document.applyReturnPayment.txtRemainingAmount.value = "";
            }
        }

        function setReturnPaymentType(paymentType) 
        {
            if (validateField()) {
                document.getElementById('hdnPaymentType').value = paymentType;

                var selectedPaymentElement;

                var paymentTypeButtons = $(".std").filter(function() {
                    return $(this).css('background-color') == 'yellow';
                });

                if (paymentTypeButtons.length > 0) {
                    var button = paymentTypeButtons[0];
                    button.style.background = 'lightgrey';
                }
		
                selectedPaymentElement = document.getElementById(paymentType);
                selectedPaymentElement.style.background = "yellow";

                if(document.applyReturnPayment.txtReturnAmount.value == "")
                {
                    cbs_alert("Enter a value into Return Amount before selecting payment type.");
                    selectedPaymentElement.style.background = "lightgrey";
                    document.applyReturnPayment.txtReturnAmount.focus();
                    return;
                } else {
                
                    if(paymentType == "Credit Card" && <%=enableCreditCardProcessing%> == 1 )
                    {
                        beginCreditCardReturn(document.applyReturnPayment.txtReturnAmount.value);
                    }
                    else 
                    {
                        document.applyReturnPayment.okButton.disabled = false;
                    }
                }
            }
        }

        function beginCreditCardReturn(amount) {
            jQuery.ajax({
                type: 'GET',
                url: 'XWebMethods.asp?Method=processReturnPaymentTransaction&amount=' + amount + '&customerSequenceNumber=' + <%=customerSequenceNumber %> + '&ticketNumber=<%=ticketNumber %>&paymentNumber=<%=paymentNumber %>&ts=' + new Date().getTime(),
                async: true,
                dataType: 'json',
                success: function(result){
                    if (result['Success'] == true) {
                        if (result['HpfUrl']) {
                            var iframe = document.getElementById('hpfFrame');
                            iframe.src = result['HpfUrl'];
                            iframe.style.display = 'block';
                        } else {
                            creditCardSuccess(result['CardPaymentID']);
                        }
                    } else {
                        creditCardFailure(result['ResponseDescription'] + ' - Code: ' + result['ResponseCode']);
                    }
                }
            });
        }

        var iframeLoaded = false;
        function hpfFormLoaded() 
        {
            // The HPF Iframe is reloaded when the transaction is approved. We only want this run when the iframe is initally loaded, 
            // so we have to use a global variable to monitor this
            // TODO find a way to figure out when the IFrame is initally loaded that doesn't use this global variable.
            if (!iframeLoaded) {
                iframeLoaded = true;

                pollForCreditReturnResults();
            }
            
        }

        function pollForCreditReturnResults() {
            $.getJSON('XWebMethods.asp?Method=getReturnPaymentCreditCardResultsResponse&ticketNumber=<%=ticketNumber %>&paymentNumber=<%=paymentNumber %>&ts=' + new Date().getTime(), function(data) {
                var responseCode = data['ResponseCode'];
                if (responseCode == "102") {
                    setTimeout(pollForCreditReturnResults, 5000);
                } else {
                    var cardPaymentID = data['CardPaymentID'];

                    if (responseCode == "000") {
                        creditCardSuccess(cardPaymentID);
                    } else {
                        creditCardFaiure(data['ResponseDescription']);

                    }
                }
            });
        }

        function creditCardSuccess(cardPaymentID) {
            document.applyReturnPayment.okButton.disabled = false;
            PrintCreditCardReceipt(cardPaymentID);
            submitForm();
        }

        function creditCardFailure(errorMsg) {
            if (!errorMsg) {
                errorMsg = 'The credit card transaction failed.'
            }

            cbs_alert(errorMsg);

            var el = document.getElementById(document.applyReturnPayment.hdnPaymentType.value);
            el.style.background = "lightgrey";

            document.applyReturnPayment.hdnPaymentType.value = '';
        }

    </script>

    <body topmargin="0" leftmargin="0" onLoad="setFocusOnLoad();">
        <!-- #include file="../include/banner.inc" -->

        <h1>Apply Return Payment</h1>

        <form id="applyReturnPayment" name="applyReturnPayment" action="" method="POST">
            <input type="hidden" name="hdnDateType" value="<%=dateTypeCriteria %>" />
            <input type="hidden" name="hdnToDate" value="<%=toDateCriteria %>" />
            <input type="hidden" name="hdnFromDate" value="<%=fromDateCriteria %>" />
            <input type="hidden" name="hdnCustomerName" value="<%=customerNameCriteria %>" />
            <input type="hidden" name="hdnInvoiceNumber" value="<%=invoiceNumberCriteria %>" />
            <input type="hidden" name="hdnPaymentAmount" value="<%=paymentAmountCriteria %>" />
            <input type="hidden" name="hdnPaymentType" value="<%=paymentType %>" />

            <table align="center" style="margin-left:10%;margin-right:10%;width:80%" border="0" cellpadding="1">
                <tr>
                    <td style="width:40%;">
                        <table align="center" width="600px" border="1" cellspacing="1" cellpadding="5">
                            <tr height="20px"></tr>
                            <tr>
			                    <td align="right" style="font-size:14px;font-weight:bold">Customer Name</td>
			                    <td><input id="txtCustomerName" name="txtCustomerName" class="text" style="height:25px;width:250px" readonly value="<%=Server.HTMLEncode(customerName)%>"></td>
		                    </tr>
		                    <tr>
			                    <td align="right" style="font-size:14px;font-weight:bold">Ticket/Payment Amount</td>
			                    <td><input id="txtPaymentAmount" name="txtPaymentAmount" class="text" style="height:25px;width:200px" readonly value="<%=FormatNumber(amountPaid, 2, , , false)%>"></td>
		                    </tr>
		                    <tr>
			                    <td align="right" style="font-size:14px;font-weight:bold">Return Amount</td>
			                    <td>
				                    <input id="txtReturnAmount" name="txtReturnAmount" class="text" onkeyup="validateField()" style="height:25px;width:200px"
				                    <% If Not IsEmpty(returnAmount) Then %>
				                    value ="<%=returnAmount%>"
				                    <% End if %>>
			                    </td>
		                    </tr>
		                    <tr>
			                    <td align="right" style="font-size:14px;font-weight:bold">Remaining Amount</td>
			                    <td>
                                    <input id="txtRemainingAmount" name="txtRemainingAmount" class="text" style="height:25px;width:200px" readonly>
			                    </td>
		                    </tr>
                        </table>
                        <table align="center" width="300px" boder="0" cellspacing="0" cellpadding="0">
		                    <tr height="40px">
			                    <td colspan="2" align="center" style="font-size:16px;font-weight:bold"><strong>Payment Type</strong></td>
		                    </tr>
                            <tr>
		                    <% If rstPayment.RecordCount > 0 Then 
				                    While Not rstPayment.EOF 
		                    %>
				                <td align="center" width="50%">
					                <button class="std" <% If paymentType = rstPayment("PaymentTypeName") Then %>style="background:yellow"<% Else %>style="background:lightgrey"<% End If %> name="<%=rstPayment("PaymentTypeName")%>" id="<%=rstPayment("PaymentTypeName") %>" onClick="setReturnPaymentType(this.id)"><%=rstPayment("PaymentTypeName")%></button>
				                </td>
		                    <%		
					                    rstPayment.MoveNext
				                    Wend
			                    End If

			                    rstpayment.Close
			                    Set rstPayment = Nothing
		                    %>
		                    </tr>
		                    <tr height=20px></tr>
                        </table>
                    </td>
                    <td style="width:40%">
                        <table width="520px">
                	        <tr>
					            <td align="center" colspan="2" width="505px" height="305px">
						                <iframe id="hpfFrame" name="hpfFrame" src="" width="500px" height="300px" style="border: 2px solid #111111;display:none;" frameborder="1" onload="if(this.src != '') { hpfFormLoaded(); }"></iframe>
					            </td>
				            </tr>
		                    <tr height=100px>
			                    <td colspan="2">
				                    <table align="center" width="100%" border="0" cellspacing="1" cellpadding="5">
					                    <td align="center" colspan=2>
						                    <input class=touchnoborder id=okButton name=okButton type=button <% If paymentType = "" Then %>disabled<% End If %> value="" style="background-image:url(../images/OK.gif)" onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
						                    <input class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
					                    </td>
				                    </table>
			                    </td>
			                    <td></td>
		                    </tr>
	                    </table>
                    </td>
                </tr>
            </table>
        </form>
    </body>
</html>