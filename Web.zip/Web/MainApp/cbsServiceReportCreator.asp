<%@ Language=VBScript %>
<%option explicit%>
<%
	dim dbname

	dbname = request.querystring("dbname")
	if dbname = "" then dbname = "default"
%>

<!--#include file="../include/SystemStartup.asp"-->
<% selectDatabase dbname %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->
<!--#include file="../include/json.asp"-->
<!--#include file="../include/form_merge.asp"-->
<!--#include file="../include/modReportConstants.asp" -->

<%
    'On Error Resume Next

    dim query, rs, reportResult, reportType, formatType


    Dim lngBytesCount
    lngBytesCount = Request.TotalBytes
    formatType = Request.QueryString("formatType")
    reportType = Request.QueryString("type")


    'Reports from Querys
    if reportType = 1 then
        query = BytesToStr(Request.BinaryRead(lngBytesCount))

        if formatType = 2 then
            reportResult = CBS_QueryCSV(query)
        else
            reportResult = CBS_QueryHtmlTable(query)
        end if

        if Err.Number <> 0 then
            Response.Write(Err.Description)
        else
            Response.Write(reportResult)
        end if
        Response.Flush
        Response.End

    'AR Statements
	else
	    createARReport
	end if



	function createARReport()
        set Session("objRP") = Server.CreateObject("CBSReports.clsParams")
        Session("objRP").dbConnectString = Session("shahcorpDSN")
        Session("objRP").dBCommandTimeout = 0
        Session("objRP").requesterName = "STMT_RUN"
        Session("objRP").sessionStoreID = Request.Form("storeId")
        Session("objRP").storeID = Request.Form("storeId")
        Session("objRP").employeeID = Request.Form("employeeId")
        Session("objRP").sessionEmployeeID = Request.Form("employeeId")

        Session("objRP").reportNumber = Request.QueryString("reportId")
        Session("objRP").reportFormat = "HTML"
        Session("objRP").routeNumber = Request.Form("RouteId")
        Session("objRP").routeGroup = 0
        Session("objRP").priceListID = Request.Form("PriceListId")
        Session("objRP").rangeStartDate = Request.Form("startDate")
        Session("objRP").rangeEndDate = Request.Form("endDate")
        Session("objRP").showZeroBalanceStatements = Request.Form("ShowZeroBal")
        Session("objRP").includeActiveInvoices = Request.Form("IncludeActive")
        session("objRP").includeDeptDetail = Request.Form("ShowDetail")
        FillParams


        dim objReport, reportResponse
        Dim strSQL, strWHERE, objRS
        strSQL = "SELECT customerSequenceNumber FROM Customer "
        strWHERE = " WHERE (permanentAccount = 1 OR (dbo.getAccountBalance(customersequencenumber, null) > 0.005)) and (ExcludeFromAR = 0)"

        If Session("objRP").reportNumber = RPT_NBR_AR_MultiPickup_Statement Then
        	strWHERE = strWHERE & " AND multiplePickup = 1 "
        Else
        	strWHERE = strWHERE & " AND multiplePickup = 0 "
        End if

        If Session("objRP").storeID > 0 then
        	strWHERE = strWHERE & _
        	           IIf(strWHERE = "",  " WHERE ", " AND ") & _
        			   " storeID = " + CStr(Session("objRP").storeID)
        end if

        If Session("objRP").priceListID > 0 then
        	strWHERE = strWHERE & _
        	           IIf(strWHERE = "",  " WHERE ", " AND ") & _
        			   " defaultPriceListID = " + CStr(Session("objRP").priceListID)
        end if

        If Session("objRP").routeNumber >= 0 then
        	strWHERE = strWHERE & _
        	           IIf(strWHERE = "",  " WHERE ", " AND ") & _
        			   " routeNumber = " + CStr(Session("objRP").routeNumber)
        'Change for all choice for routes
        Else
        	strWHERE = strWHERE
        end if

        strWHERE = strWHERE & " ORDER BY LastName, FirstName"


        Set objRS = getDisconnectedRecordset(strSQL & " " & strWHERE)
        while (not objRS.EOF)
            Session("objRP").customerSequenceNumber = objRS("customerSequenceNumber").value
            set objReport = CreateObject("CBSReports.clsReport")
            objReport.CreateStandardReport(Session("objRP"))
            reportResponse = Session("objRP").reportStream
            objRs.MoveNext
        Wend

        Response.Write reportResponse
        if Err.Number <> 0 then
            Response.Write(Err.Description)
        else
            Response.Write("0")
        end if
        Response.Flush
        Response.End
    end function


Function BytesToStr(bytes)
    Dim Stream
    Set Stream = Server.CreateObject("Adodb.Stream")
        Stream.Type = 1 'adTypeBinary
        Stream.Open
        Stream.Write bytes
        Stream.Position = 0
        Stream.Type = 2 'adTypeText
        Stream.Charset = "iso-8859-1"
        BytesToStr = Stream.ReadText
        Stream.Close
    Set Stream = Nothing
End Function


	
	function CBS_sendEmail(toEmail, fromEmail, fromName, subject, body, source)
		dim query, rs
		
		query = " insert into emailqueue (toAddress, fromAddress, fromName, subjectLine, bodyText, source) "
		query = query & " values ("
		query = query & "  " & DbCreateQryString(toEmail)
		query = query & ", " & DbCreateQryString(fromEmail)
		query = query & ", " & DbCreateQryString(fromName)
		query = query & ", " & DbCreateQryString(subject)
		query = query & ", " & DbCreateQryString(body)
		query = query & ", " & DbCreateQryString(source)
		query = query & ")"
		
		qryexecute query
	end function
	
	function CBS_QueryCSV(query)
		dim rs
		dim result
		
		result = ""
		
		if query <> "" then
			set rs = getdisconnectedrecordset(cstr(query))
		
			if rs.recordcount > 0 then
				rs.MoveFirst
				dim i, cellValue
			  for i = 0 to rs.Fields.Count - 1
			    result = result & """" & replace(rs.Fields(i).Name, """", """""") & """"
			    if i <> rs.Fields.Count - 1 then result = result & ","
			  next
				  
				result = result & vbcrlf

				while not (rs.eof or rs.bof)
		
				  for i = 0 to rs.Fields.Count - 1
				  	if isnull(rs.Fields(i).Value) then
				  		cellValue = ""
				  	else
				  		cellValue = rs.Fields(i).Value
				  	end if
				  	
				    result = result & """" & replace(cellValue, """", """""") & """"
				    if i <> rs.Fields.Count - 1 then result = result & ","
				  next
		
				  rs.MoveNext
				  
				  if not rs.bof then result = result & vbcrlf
				wend
			end if
		
		end if			

		CBS_QueryCSV = result
	end function
	
	function CBS_QueryHtmlTable(query)
		on error resume next
		dim recordCount
		dim result
		
		result = ""
		
		if query <> "" then

			set rs = getdisconnectedrecordset(cstr(query))
			
			if err.number <> 0 then
				result = result & "<div class=""error"">Error executing query<br>" & query & "</div>"
				exit function
			end if
			
			if rs.state > 0 then
				recordCount = rs.recordcount
				
				if recordCount > 0 then
					result = result & "<DIV id=""queryresults"" name=""queryresults"" style=""width:100%;height:625px"">"
					result = result & "<TABLE class=""itable"" cellspacing=""0"">"
		
					dim i
					
					
					result = result & "<TR>"
					
					for i = 0 to rs.Fields.Count - 1
						if left(rs.Fields(i).Name, 1) <> "_" then
							result = result & "<TH style=""text-align:left"">@@@" & Server.HTMLEncode(rs.Fields(i).Name) & "</TH>"
						end if
					next
					
					result = result & "</TR>"

					rs.MoveFirst
					
					while not (rs.eof or rs.bof)
					  result = result & "<TR>"
					
					  for i = 0 to rs.Fields.Count - 1
						if left(rs.Fields(i).Name, 1) <> "_" then
						  	if isnull(rs.Fields(i).Value) then
						  		result = result & "<TD>&nbsp;</TD>"
						  	else
						   		result = result & "<TD>" & Server.HTMLEncode(rs.Fields(i).Value) & "</TD>"
						    end if
						end if
					  next
					
					  result = result & "</TR>"

					  rs.MoveNext
					wend
					result = result & "</TABLE>"
					result = result & "</DIV>"
				else
					result = result & "<div class=""warning"">No records</div>"
				end if
			end if
		else
			result = result & "<div class=""error"">No query selected</div>"
		end if

		CBS_QueryHtmlTable = result

	end function

%>
