<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->
<%
	dim query, rs
	dim customerseq
	dim employeeid
	dim storeguid

	dim customername
	dim employeename
	dim employeemessageusername
	
	dim message
	
	customerseq = getReqVar("customerseq")
	employeemessageusername = getReqVar("messageusername")
	storeguid = getReqVar("storeguid")
	customername = getReqVar("customername")
	
	select case lcase(request.querystring("useraction"))
	case "submittask"
		submitTask
	end select


	function getMessageAccountID(username)
		dim query, rs

		query = "select id from messageaccount where lower(username) = '" & lcase(username) & "'"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getMessageAccountID = rs("id")
		else
			getMessageAccountID = ""
		end if

		set rs = nothing
	end function

	sub submitTask
		dim query, rs
		dim accountnames
		dim accountname
		
		accountnames = split(request.form("toaccount"), ",")

		for each accountname in accountnames
			if getMessageAccountID(trim(accountname)) = "" then
				message = "Could not send to account name '" & accountname & "'"
				exit sub
			end if
		next

		query = "exec dbo.opentask '" & employeemessageusername & "'"
		query = query & ", " & DbCreateQryString(storeguid)
		query = query & ", " & DbCreateQryString(customerseq)
		query = query & ", " & DbCreateQryString(customername)
		query = query & ", '" & request.form("toaccount") & "', " & request.form("priority")
		query = query & ", '" & request.form("descriptiontext") & "'"
		query = query & ", " & DbCreateQryString(request.form("dateopen"))
		query = query & ", " & DbCreateQryString(request.form("datedue"))
		
		
		qryexecute(query)
	end sub





	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">
	function submitTask() {
		document.createtask.action = "?useraction=submitTask";
		document.createtask.submit();
	}
	
	function clearSubmit() {
		document.createtask.action = "";
		document.createtask.submit();
	}
	
	function showMessageBook() {
		var w = window.open("/MainApp/MessageAddressBook.asp", "MessageAddressBook", "status=no,scrollbars=yes,width=300,height=600,modal=yes");
	}
	
	function mb_callback(addresses) {
		document.createtask.toaccount.value = addresses;
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0"  <%if lcase(request.querystring("useraction")) = "submittask" then%>onload="opener.window.location.reload();window.close();"<%else%>onload="document.createtask.descriptiontext.focus()"<%end if%>>

<FORM name=createtask METHOD=POST ACTION="" style="margin:0;padding:0">

<INPUT type="hidden" name="employeeid" value="<%=employeeid%>">
<INPUT type="hidden" name="customerseq" value="<%=customerseq%>">
<INPUT type="hidden" name="storeguid" value="<%=storeguid%>">
<INPUT type="hidden" name="messageusername" value="<%=employeemessageusername%>">
<INPUT type="hidden" name="customername" value="<%=customername%>">
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="submitTask()">Submit</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="window.close()">Close</BUTTON>
	</SPAN>
</DIV>

<TABLE style="background:#F8F8F8;margin:20px">
	<TR valign="top">
		<TD><input type="button" style="width:70px" value="To:" onclick="showMessageBook()"></TD>
		<TD><INPUT name="toaccount" style="width:390px;border:1px inset;background:white" value="<%=employeemessageusername%>" ></TD>
	</TR>
	<TR valign="top">
		<TD>Customer:</TD>
		<TD><INPUT readonly style="width:390px;border:1px inset;background:white" value="<%=customername%>"></TD>
	</TR>
	<TR valign="top">
		<TD>Priority:</TD>
		<TD>
		<SELECT name="priority" style="width:390px;border:1px inset;background:white">
<%
		query = "select * from taskpriority"
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
%>
			<OPTION style="color:#<%=rs("color")%>" value="<%=rs("id")%>"><%=rs("name")%></OPTION>
<%
			rs.movenext
		wend
		
		set rs = nothing
%>
		</SELECT>

		</TD>
	</TR>

	<TR valign="top">
		<TD>Begin Date:</TD>
		<TD><INPUT name="dateopen" style="width:390px;border:1px inset;background:white" value="<%=date()%>" onClick="javascript:show_calendar('createtask.dateopen');"></TD>
	</TR>
	<TR valign="top">
		<TD>Due Date:</TD>
		<TD><INPUT name="datedue" style="width:390px;border:1px inset;background:white" value="" onClick="javascript:show_calendar('createtask.datedue');"></TD>
	</TR>
	<TR valign="top">
		<TD>Task Description:</TD>
		<TD><TEXTAREA rows=17 name="descriptiontext" id="descriptiontext" style="width:390px;border:1px inset;background:white;overflow:auto"></TEXTAREA></TD>
	</TR>
</TABLE>
	

</FORM>
</BODY>
</HTML>
