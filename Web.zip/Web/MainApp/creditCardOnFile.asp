<%@ Language=VBScript %>

<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim customerseq
	
	customerseq = session("customersequencenumber")
	
	function maskAccountNumber(AccountNumber)
		dim hideCnt
		dim sleft : sleft = 2
		dim sright : sright = 4
		dim i
		
		if len(AccountNumber) < 10 then
			sleft = 0
			sright = 2
		end if
		
		hideCnt = len(AccountNumber) - (sleft + sright)
		if hideCnt < 0 then hideCnt = 0
		
		maskAccountNumber = left(AccountNumber, sleft)
		
		for i = 1 to hideCnt - 2
			maskAccountNumber = maskAccountNumber & "X"
		next

		maskAccountNumber = maskAccountNumber & right(AccountNumber, sright)
	end function
	
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Credit Card On File</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<link rel="stylesheet" type="text/css" href="/external/ext/resources/css/ext-all.css" />
<link rel="stylesheet" type="text/css" href="/external/ext/resources/css/xtheme-gray.css" />

<script type="text/javascript" src="/external/ext/adapter/ext/ext-base.js"></script>
<script type="text/javascript" src="/external/ext/ext-all.js"></script>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript" src="/Script/validation.js"></script>

<script language="javascript" type="text/javascript" src="/Script/xchargeprocessor.js"></script>

<style type="text/css">

#c-cc {
	text-align: center;
}

#c-cc h2 {
 	margin: 3px;
 	font-size: 16;
}

#c-cc-data {
	width: 500px;
	border: 1px solid #ddd;
	margin: 6px;
}

#c-cc-data th {
	font-weight: bold;
	background: #ddd;
}

</style>

<script type="text/javascript">
	var AddCardPanel = new Ext.FormPanel({
	    labelWidth: 130,
	    frame:true,
	    bodyStyle:'padding:5px',
	    defaults: {width: 150},
	    defaultType: 'textfield',
	    items: [
	    
	    	{
	            fieldLabel: 'Account Number',
	            name: 'account',
	            allowBlank: false,
	            selectOnFocus: true,
	            listeners: {
					'specialkey': function(f,e) {
						if(e.getKey() == 13) {
							var track1, track2;
							var tracks = this.getValue().split('?');
	
							this.setValue('');
							AddCardPanel.getForm().findField('exp').setValue('');
							AddCardPanel.getForm().findField('track2').setValue('');
							
							track1 = (tracks.length > 0 ? tracks[0] + '?' : '');
							track2 = (tracks.length > 1 ? tracks[1] + '?' : '');
							
							if(tracks.length = 2 && track2.length > 16) {
	    						var fl = track2.split('=');
	    						this.setValue(fl[0].substring(1));
	    						AddCardPanel.getForm().findField('exp').setValue(fl[1].substring(0, 4));
								AddCardPanel.getForm().findField('track2').setValue(track2);
							}
							this.focus(true);
						}
					}
				}
	        },{
	            fieldLabel: 'Expiration (YYMM)',
	            name: 'exp'
	        },{
	            fieldLabel: 'Track2',
	            name: 'track2',
	            hidden: true,
	            hideLabel: true,
	            readOnly: true
	        },{
	            fieldLabel: 'XcAccountId',
	            name: 'xcaccountid',
	            hidden: true,
	            hideLabel: true,
	            readOnly: true
	        },{
	            fieldLabel: 'TransType',
	            name: 'transtype',
	            hidden: true,
	            hideLabel: true,
	            readOnly: true
	        },{
	            fieldLabel: 'CustomerSeq',
	            name: 'customerseq',
	            hidden: true,
	            hideLabel: true,
	            readOnly: true
	        }
	    ]
	});
	
	
	
	var AddCardWindow = new Ext.Window({
	    title       : 'Add Card',
	    layout      : 'fit',
	    width       : 350,
	    height      : 150,
	    closeAction :'hide',
	    plain       : true,
	    items       : AddCardPanel,
	    draggable   : false,
		resizable   : false,
		modal       : true,
	    buttons: [{
	        text     : 'Submit',
	        handler  : function() {
		    	AddCardPanel.getForm().submit({
			    	url:'creditCardActions.asp',
			    	waitMsg:'Saving Data...',
					success: function(form, action) {
						if(action.result.success != 0) {
							switch(action.result.action) {	
								case "add":
								    document.credCardOnFile.action = "/mainapp/creditcardonfile.asp";
                                    document.credCardOnFile.submit();
									break;
								case "update":
								    document.credCardOnFile.action = "/mainapp/creditcardonfile.asp";
                                    document.credCardOnFile.submit();
									break;
								case "delete":
								    document.credCardOnFile.action = "/mainapp/creditcardonfile.asp";
                                    document.credCardOnFile.submit();
									break;
							}
						}
						else {
							Ext.Msg.alert("Server Error", action.result.description);
						}
					},
					failure: function(form, action) {
						switch (action.failureType) {
						case Ext.form.Action.CLIENT_INVALID:
							Ext.Msg.alert("Failure", "Form fields may not be submitted with invalid values");
							break;
						case Ext.form.Action.CONNECT_FAILURE:
							Ext.Msg.alert("Failure", "Ajax communication failed");
							break;
						case Ext.form.Action.SERVER_INVALID:
							Ext.Msg.alert("Failure", action.result.description);
							break;
						}
					}

		    	
		    	});
		    	AddCardWindow.hide();
	        }
	    },{
	        text     : 'Cancel',
	        handler  : function() {
	            AddCardWindow.hide();
	        }
	    }]
	});
</script>

<SCRIPT type="text/javascript">
	var previousElement = null;
	var selectedAccountId = null;
	var selectedAccountNumber = null;
	var selectedExp = null;
		
	function exit() {
	    document.credCardOnFile.action = "customerpayment.asp";
	    document.credCardOnFile.submit();
	}
	
	function addCard() {
		
		if(!AddCardWindow.isVisible()) {
			AddCardWindow.show();
			AddCardWindow.setTitle("Add Card");
			
			AddCardPanel.getForm().reset();
			AddCardPanel.getForm().findField('transtype').setRawValue('add');
			AddCardPanel.getForm().findField('account').enable();
			
			AddCardPanel.getForm().findField('customerseq').setRawValue(<%=customerseq%>);
			
			AddCardPanel.getForm().findField('account').focus(true, 500);
		}
		
	}
	
	
	function updateCard() {
		if(!selectedAccountId) {
			cbs_alert("Select an account before updating.");
			return;
		}
		
		if(!AddCardWindow.isVisible()) {
			AddCardWindow.show();
			AddCardWindow.setTitle("Update Card");

			AddCardPanel.getForm().reset();
			AddCardPanel.getForm().findField('transtype').setRawValue('update');
			AddCardPanel.getForm().findField('account').setRawValue(selectedAccountNumber);
			AddCardPanel.getForm().findField('xcaccountid').setRawValue(selectedAccountId);
			AddCardPanel.getForm().findField('account').disable();
			
			AddCardPanel.getForm().findField('account').focus(true, 500);
		}
	}
	
	
	function deleteCard() {
		if(!selectedAccountId) {
			cbs_alert("Select an account before deleting.");
			return;
		}
		
		if(!AddCardWindow.isVisible()) {
			AddCardWindow.show();
			AddCardWindow.setTitle("Delete Card");
			
			AddCardPanel.getForm().reset();
			AddCardPanel.getForm().findField('transtype').setRawValue('delete');
			AddCardPanel.getForm().findField('account').setRawValue(selectedAccountNumber);
			AddCardPanel.getForm().findField('exp').setRawValue(selectedExp);
			AddCardPanel.getForm().findField('xcaccountid').setRawValue(selectedAccountId);
			AddCardPanel.getForm().findField('account').disable();
			AddCardPanel.getForm().findField('exp').disable();
			
			AddCardPanel.getForm().findField('account').focus(true, 500);
		}
	}
	

	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}
		selectedAccountId = element.getAttribute("accountid");
		selectedAccountNumber = element.getAttribute("accountnumber");
		selectedExp = element.getAttribute("exp");
		
		previousElement = element;
		
		element.className = "selected";
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="">

<!-- #include file="../include/banner.inc" -->
<FORM name="credCardOnFile" ID="credCardOnFile" METHOD=POST  style="margin:0;padding:0">
<B class="pageHeading">Credit Card On File</B>

<%
	query = "select * from xcaccount where active = 1 and customersequencenumber = " & customerseq
	set rs = getdisconnectedrecordset(query)
	
	dim cc_rs
	query = " select isnull(creditCardTypeName, '') as creditCardTypeName, "
	query = query & " isnull(creditCardNumber, '') as creditCardNumber, "
	query = query & " isnull(creditCardExpDate, '') as creditCardExpDate "
	query = query & " from customer where customersequencenumber = " & customerseq
	set cc_rs = getdisconnectedrecordset(query)
	
%>
<DIV id="c-cc">
<H2>Default Card<H3>
<TABLE id="c-cc-data" >
<TR>
	<TH>Card Type</TH>
	<TH>Card Number</TH>
	<TH>Card Expiration</TH>
</TR>
<TR>
	<TD><%=cc_rs("creditCardTypeName")%></TD>
	<TD><%=cc_rs("creditCardNumber")%></TD>
	<TD><%=cc_rs("creditCardExpDate")%></TD>
</TR>
</TABLE>
</DIV>


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="addCard()" <%if rs.recordcount > 0 then%>disabled<%end if%>>Add</BUTTON>
		<BUTTON onclick="updateCard()">Update<BR/>Expiration</BUTTON>
		<BUTTON onclick="deleteCard()">Delete</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" cellspacing="0">
	<TR>
		<TH>Card Type</TH>
		<TH>Account Number</TH>
		<TH>Expiration</TH>
	<TR>
	
<%

	while not(rs.eof or rs.bof)
%>
	<TR onclick="selectRow(this)"; accountid="<%=rs("xcaccountid")%>" accountnumber="<%=maskAccountNumber(rs("accountnumber"))%>" exp="<%=rs("expiration")%>">
		<TD><%=rs("cardtype")%></TD>
		<TD><%=maskAccountNumber(rs("accountnumber"))%></TD>
		<TD><%=rs("expiration")%></TD>
	</TR>

<%
		rs.movenext
	wend
	set rs = nothing
%>
</TABLE>
</FORM>
</BODY>
</HTML>
