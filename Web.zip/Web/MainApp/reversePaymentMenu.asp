﻿<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<html>
    <head>
        <title>Void/Return Payment Menu</title>
        <link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
    </head>
    <script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
    <script type="text/javascript">

	    function cancelForm(){
		    document.managerMenuForm.action="managerMenu.asp";
		    document.managerMenuForm.submit();
	    }	
	
	    function showVoidPayment(){
		    document.managerMenuForm.action ="voidPayment.asp";
		    document.managerMenuForm.submit();
	    }
        
	    function showReturnPayment() {
	        document.managerMenuForm.action="returnPayment.asp";
	        document.managerMenuForm.submit();
	    }	


    </script>

    <body topmargin=0 leftmargin=0>

        <!-- #include file="../include/banner.inc" -->
        <hi>Void/Return Payment Menu</hi>
        <form id="managerMenuForm" name="managerMenuForm" action="start2.asp" method="Post">
            <center>

	            <table align="center" border="0" cellspacing="2" cellpadding="0" >
		            <tr>
			            <td>
				            <button class="std" style="width:200px;height:100px;font-size:12px" name="voidPayment" onclick="showVoidPayment()">Void Payment</button>
			            </td>
			            <td>
				            <button class="std" style="width:200px;height:100px;font-size:12px" name="returnPayment" onclick="showReturnPayment()">Return Payment</button>
			            </td>
		            </tr>
		            
		            <tr height="100px">
			            <td align="center" colspan="4">
				            <input class="touchnoBorder" id="cancelButton" name="cancelButton" type="button" value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
			            </td>
		            </tr>	
		
	            </table>

            </center>
        </form>   

    </body>
</html>
