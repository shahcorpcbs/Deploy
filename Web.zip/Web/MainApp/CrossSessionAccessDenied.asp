<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<link href="/script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY topmargin=0 leftmargin=0>
<!--#include file="../include/banner.inc"-->
<p>&nbsp;</p>
<table style="background-color:#ff0000;" align=center cellspacing="1" cellpadding="0" border="0">
<tr>
    <td align="center" valign="middle" nowrap style="background-color: #FF0000;">
		<img src="../images/accessdenied.gif" alt="" width="245" height="45" border="0">
	</td>
</tr>
<tr>
    <td align="center" style="color:#2F4F4F; background-color:#ffffff; padding: 20px 20px 30px 20px;">
		Accessing the Main System from a <strong>Report Only Session</strong> is not permitted. Please close the current session 
		and start a new one.
	</td>
</tr>
</table>


</BODY>
</HTML>
