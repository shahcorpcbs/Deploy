<%@ Language=VBScript %>
<%option explicit%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->

<%sec_RequestAccess Request.QueryString("userAction")%>

<%

%>

<HTML>
<HEAD>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../script/date-picker2.js"></script>
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
	function mergeAnother() {
		document.MergeCustomerDone.action = "/mainapp/mergeCustomers.asp";
		document.MergeCustomerDone.submit();
	}
//-->
</SCRIPT>
</HEAD>
<BODY onLoad="" topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->


<FORM name="MergeCustomerDone" ID="MergeCustomerDone" method="post" ACTION="">
<TABLE WIDTH=500 STYLE="" ALIGN=center BORDER=0 CELLSPACING=1 CELLPADDING=5>

	<tr height=100px><td>&nbsp</td>
	</tr>

	<tr height=50px>
		<td width = 40% class = "label"  align=center Style="Font-weight=bold;font-size=20">Customers have been merged!</td>
	</tr>
	<tr height=50px>
		<td width = 40% class = "label"  align=center Style="Font-weight=bold;font-size=20"><BUTTON style="width:100px; height:50px;" onclick="mergeAnother()">Ok</BUTTON></td>
		
	</tr>

</TABLE>
</FORM>


</BODY>
</HTML>

<%


%>