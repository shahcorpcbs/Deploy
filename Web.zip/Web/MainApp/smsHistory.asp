<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim customerseq, custCellPhone, custName
	dim dateBegin
	dim dateEnd
	dim cnt, segCnt
	dim searchText, directSel
	dim twilioNum
	dim includeErrors
	dim pagenum, idx
	dim tableData

	cnt = 0
	segCnt = 0
	twilioNum = getMSVar("newTwilioFromNumber")
	if IsNull(twilioNum) then
        twilioNum = getMSVar("twilioFromNumber")
    end if

    if Request.QueryString("useraction") = "setHandled" then
        dim note, messageId
        note = Request.QueryString("note")
        messageId = Request.QueryString("messageId")

        query = "insert into SMSMessageHistory (TwilioResponseMessageId, EmployeeId, DateChanged, Status, Note) values ("
        query = query & messageId & ", " & session("employeeID") & ", CURRENT_TIMESTAMP, 2, '" & dbstr(note) & "' ) "
        qryexecute query

    elseif Request.QueryString("useraction") = "setUnread" then
        messageId = Request.QueryString("messageId")

        query = "insert into SMSMessageHistory (TwilioResponseMessageId, EmployeeId, DateChanged, Status) values (" _
            & messageId & ", " & session("employeeID") & ", CURRENT_TIMESTAMP, 0) "
        qryexecute query
    end if

	pagenum = Request.QueryString("pagenum")
	if pagenum = "" then pagenum = 1



    directSel = Request.QueryString("directSel")
    if directSel = "" then
        directSel = 1
    end if

    searchText = getReqVar("searchText")
	customerSeq = getReqVar("customerSeq")
	includeErrors = getReqVar("includeErrors")
	if includeErrors = "" then includeErrors = 0

	dateBegin = getReqVar("dateBegin")
	dateEnd = getReqVar("dateEnd")
	if dateBegin = "" then dateBegin = dateadd("m",-1,date())
	if dateEnd = "" then dateEnd =  dateadd("d",1,date())

	if customerseq <> "" then
	    query = "select COALESCE(cellphone, '') cell, customerName from customer where customerSequenceNumber = " & customerseq
	    set rs = getdisconnectedrecordset(query)
        custCellPhone = rs("cell")
        custName = rs("customerName")
	end if

	query = ""

    if directSel <> 2 then

        query = " select trm.id, 0 as employeeId, '' as employeeName, body, segments, dateSent as messageDate, "_
            & "'Received' as direction, c.customerName, c.customerSequenceNumber as SeqNum, fromNumber as phone, "
        query = query & " case when exists  (SELECT 1 from SMSMessageHistory smh where smh.TwilioResponseMessageId = trm.id) then "
        query = query & " case when (select top 1 status from SMSMessageHistory smh where smh.TwilioResponseMessageId = trm.id order by dateChanged desc) = 0 then 0 else "
        query = query & "  (select max(status) from SMSMessageHistory smh where smh.TwilioResponseMessageId = trm.id) end else 0 end as maxStatus, "_
            & "'' as queryName "
        query = query & " from TwilioResponseMessage trm left join Customer c on "
        query = query & " c.customerSequenceNumber = trm.customerSequenceNumber where 1 = 1 "

        if includeErrors = 0 then
            query = query & " and errorCode in (0, 11200) "
        elseif includeErrors = 2 then
            query = query & " and errorCode not in (0, 11200) "
        end if

        if customerseq <> "" then
            query = query & " and trm.customerSequenceNumber = " & customerseq
        end if

        if dateBegin <> "" then
            query = query & " and datediff(day, dateSent, '" & dateBegin & "') <= 0 "
        end if

        if dateEnd <> "" then
            query = query & " and datediff(day, dateSent, '" & dateEnd & "') >= 0 "
        end if

        if searchText <> "" then
                query = query & " and LOWER(body) like '%" & dbstr(searchText) & "%' "
        end if

    end if

    if directSel <> 1 then

        if directSel <> 2 then
            query = query & " union all ("
        end if

        query = query & " select tssac.id, tssac.employeeId, e.employeeName, message as body, segments, "_
            & "(case when Successful is null then null else lastAttempt end) as messageDate, 'Send' as direction, c.customerName, "_
            & "tssac.customerId as SeqNum,  phoneNumber as phone, queueStatus as maxStatus, qa.Name as queryName"
        query = query & " from TwilioSendSmsApiCall tssac left join Customer c on "
        query = query & " tssac.customerId = c.customerSequenceNumber  "
        query = query & " left join Employee e on tssac.employeeId = e.employeeId "_
            & " left join QueryAlert qa on tssac.qaId = qa.Id where (tssac.CustomerId is null or tssac.customerId != -1) "


        if includeErrors = 0 then
            query = query & " and (successful = 1 or successful is null)"
        elseif includeErrors = 2 then
            query = query & " and successful = 0 "
        end if

        if customerseq <> "" then
            query = query & " and tssac.customerId = " & customerseq
        end if

        if dateBegin <> "" then
            query = query & " and datediff(day, requestDate, '" & dateBegin & "') <= 0 "
        end if

        if dateEnd <> "" then
            query = query & " and datediff(day, requestDate, '" & dateEnd & "') >= 0 "
        end if

        if searchText <> "" then
                query = query & " and LOWER(convert(varchar(max), message)) like '%" & dbstr(searchText) & "%' "
        end if

        if directSel <> 2 then
                query = query & ") "
        end if
    end if

	query = query & " order by messageDate desc "
	set rs = getdisconnectedrecordset(query)
	cnt = rs.recordcount
	rs.pagesize = 40
	if cnt > 0 then
        rs.absolutepage = pagenum
    end if


    if Request.QueryString("unreading") <> "1" then
        updateStatus
    end if



    function updateStatus()
        dim query2

        query2 = "insert into SMSMessageHistory (TwilioResponseMessageId, EmployeeId, DateChanged, Status) ("_
            & "select trm.id, " & session("employeeID") & ", CURRENT_TIMESTAMP, 1 from TwilioResponseMessage trm "_
            & " where ((not exists (select TwilioResponseMessageId from SMSMessageHistory where "_
            & "TwilioResponseMessageId = trm.id and employeeId = " & session("employeeID") & ") or " _
            & "(select top 1 status from SMSMessageHistory where TwilioResponseMessageId = trm.id order by datechanged desc) = 0))"

        if customerseq <> "" then
            query2 = query2 & " and trm.customerSequenceNumber = " & customerseq
        end if

        if dateBegin <> "" then
            query2 = query2 & " and datediff(day, dateSent, '" & dateBegin & "') <= 0 "
        end if

        if dateEnd <> "" then
            query2 = query2 & " and datediff(day, dateSent, '" & dateEnd & "') >= 0 "
        end if
        query2 = query2 & ")"
        qryexecute query2


    end function

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function
%>
<HTML>
<HEAD>
<TITLE>SMS History</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">
	var previousElement = null;
	var selectedMessage = null;
	var selectedMessageId = null;
	var selectedCustSeqNum = null;
	var selectedPhoneNum = null;
	var selectedDir = null

	function viewCustomerFunctions(customerseq) {
        document.smsHistory.action = "customerfunctions.asp?customerseq=" + customerseq;
        document.smsHistory.submit();
	}

	function createActionString() {
	    var searchText = $.trim($("#searchText").val());
	    var action = "";
	    if (searchText.length > 0) {
	        action = action + "&searchText=" + encodeURIComponent(searchText)
	    }

	    var directSel = $("#directSel").val()
	    action = action + "&directSel=" + encodeURIComponent(directSel)
	    action = action + "&dateBegin=" + $("#dateBegin").val()
	    action = action + "&dateEnd=" + $("#dateEnd").val()
	    var myRadio = $("input[name=chkErrors]");
        action = action + "&includeErrors=" + myRadio.filter(":checked").val();
        <% if Request.QueryString("unreading") = "1" then %>
            action = action + "&unreading=1";
        <% end if %>
	    return action;
	}

	function update() {
		document.smsHistory.action = "?useraction=update" + createActionString();
		document.smsHistory.submit();
	}

	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}

		selectedDir = element.getAttribute("direction");
		selectedMessageId = element.getAttribute("messageId");
		selectedMessage = element.getAttribute("fullMessage");
		selectedCustSeqNum = element.getAttribute("custSeqNum");
		selectedPhoneNum = element.getAttribute("phoneNum");
		previousElement = element;

		element.className = "selected";
		document.getElementById("btnViewHistory").disabled = (selectedDir==="Sent" &&
		    (element.getAttribute("successStatus") === "True" || element.getAttribute("successStatus") == 1));
    }

    function viewFullMessage() {
	    if (selectedMessage != null) {
	        //Some characters from messages come in as weird unicodes instead of characters and break stuff
	        var cleanedMsg = selectedMessage.replace("%u2014", "-").replaceAll("%u2026", "...").replaceAll("%u2019", "'").replaceAll(/%u\d\d\d\d/g, "").replaceAll(/%A./g, "");
	        cbs_alert(decodeURIComponent(cleanedMsg))
        }
	    else
	        cbs_alert("Please Select Message")
    }

	function sendSmsMessage() {
        if ('<%=custCellPhone %>' === '') {
            cbs_alert("Customer does not have cell phone set up, please add one")
            return false;
        }
	    window.open("/mainapp/sendSmsMessage.asp?customerseq=<%=customerseq%>", "Send SMS Message", "status=no, height=600, width=700, center, edge=Sunken, help=No, resizable=yes, scroll=yes");
	}

	function replyToSmsMessage() {
	    if (selectedCustSeqNum != null) {
	            window.open("/mainapp/sendSmsMessage.asp?customerseq=" + selectedCustSeqNum + "&phoneNumber=" + selectedPhoneNum, "Send SMS Message",
	                "status=no, height=600, width=700, center, edge=Sunken, help=No, resizable=yes, scroll=yes");
	    }
	    else
	        cbs_alert("Please Select Message")
	}


	function viewSmsMessageHistory() {
	    if (selectedMessageId != null && $.trim(selectedMessageId).length > 0) {

	        if (selectedDir === "Received")
	            document.smsHistory.action = "/mainapp/smsMessageHistory.asp?customerseq=<%=customerseq%>&messageId=" +
	                selectedMessageId + createActionString();
	        else
	            document.smsHistory.action = "/mainapp/smsMessageError.asp?customerseq=<%=customerseq%>&messageId=" +
	                selectedMessageId + createActionString();
            document.smsHistory.submit();
	    }
	    else
	        cbs_alert("Please Select Message")
	}

	function setUnread(messageId) {
		document.smsHistory.action = "?useraction=setUnread&messageId=" + messageId + createActionString();
		    if (!document.smsHistory.action.includes("unreading"))
		    document.smsHistory.action = document.smsHistory.action + "&unreading=1"
		document.smsHistory.submit();
	}

    var savMsgId;
	function setHandled(messageId) {
	    savMsgId = messageId;
	    cbs_prompt("Note: ", handleNote, "", true, false);
	}

	function handleNote() {
	    var note  = document.getElementById('inputTxtArea').value;
		document.smsHistory.action = "?useraction=setHandled&messageId=" + savMsgId + "&note=" +
            encodeURIComponent($.trim(note)) + createActionString();
		document.smsHistory.submit();
	}

    function formatPhoneNumber(phoneNumberString) {
      var cleaned = ('' + phoneNumberString).replace(/\D/g, '');
      var match = cleaned.match(/^(1|)?(\d{3})(\d{3})(\d{4})$/);
      if (match) {
        var intlCode = (match[1] ? '+1 ' : '');
        return [intlCode, '(', match[2], ') ', match[3], '-', match[4]].join('');
      }
      return null;
    }

	function exit() {
        document.smsHistory.action = "/MainApp/toolsMenu.asp"
        document.smsHistory.submit();
	}
</script>

<BODY topmargin=0 leftmargin=0 onload="init()">

<!-- #include file="../include/banner.inc" -->
<H1 <% if customerseq <> "" then %> style="padding-bottom: 70px" <% end if %>>
    <% if customerseq <> "" then %>
        <SPAN style="float:left; padding-right: 35px">
            <table style="text-align: left; font-weight: bold">
            <tr><td>Sms History</td></tr>
            <% 	if customerseq <> "" then %>
                <tr>
                    <td><%= custName %></td>
                </tr>
                <tr>
                    <td id="custNumber"></td>
                </tr>
            <% end if %>
            </table>
        </SPAN>
    <% else %>
        SMS History
    <% end if %>

    <SPAN style="float:right; padding-right: 35px">
        <table style="text-align: left; font-weight: bold">
        <tr>
            <td>Store From Number:</td>
            <td id="twilioNum"></td>
        </tr>
        <tr>
            <td>Message Count:</td>
            <td><%=cnt %>*</td>
        </tr>
        <tr>
            <td>Segment Count:</td>
            <td id="segCntSpan"></td>
        </tr>
        </table>
    </SPAN>
</H1>


<FORM id="smsHistory" name="smsHistory" action="" method="post" onsubmit="return false;">
<INPUT type="hidden" name="customerseq" value="<%=customerseq%>">
<input type=hidden name="pagenum" value="<%= pagenum%>">

<table>
    <tr>
        <td>Date range</td>
        <td>
            <INPUT id="dateBegin" name="dateBegin" value="<%=dateBegin%>" readonly onclick="javascript:show_calendar('smsHistory.dateBegin');">
            to
            <INPUT id="dateEnd" name="dateEnd" value="<%=dateEnd%>" readonly onclick="javascript:show_calendar('smsHistory.dateEnd');">
        </td>
        <td rowspan="2"><BUTTON class="cmdbar" onclick="update()">Look Up</BUTTON></td>
    </tr>
    <tr>
        <td>Messages Containing</td><td> <input type="text" size="49" id="searchText" value="<%=searchText%>"></td>
    </tr>
    <tr>
        <td>Direction</td>
        <td>
            <select id="directSel" >
                <option value="0">Both</option>
                <option value="1">Received</option>
                <option value="2">Sent</option>
            </select>
        </td>
    </tr>
    <tr>
        <td>Include</td>
        <td>
            <label for="succOnly">
            <Input type=Radio name=chkErrors value="0" id="succOnly"
                <% if includeErrors = "0" then %>
                    CHECKED
                <% end if %>
                >Success Only</label>
            <label for="sAndE">
            <Input type=Radio name=chkErrors value="1" id="sAndE"
                <% if includeErrors = "1" then %>
                    CHECKED
                <% end if %>
                >Successes and Errors</label>
            <label for="errOnly">
            <Input type=Radio name=chkErrors value="2" id="errOnly"
                <% if includeErrors = "2" then %>
                    CHECKED
        <% end if %>
                >Errors Only</label>
        </td>
    </tr>
</table>
<br />
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON id="btnFullMessage" onclick="viewFullMessage()">View Full<BR>Message</BUTTON>
	</SPAN>
	<SPAN style="float:left">
		<BUTTON id="btnViewHistory" onclick="viewSmsMessageHistory()" disabled>View Status<BR>History</BUTTON>
	</SPAN>
	<% 	if customerseq <> "" then %>
		<% if getMSVar("useTwilio") then %>
            <SPAN style="float:left">
                <BUTTON id="btnSendMessage" onclick="sendSmsMessage()">Send SMS<BR>Message</BUTTON>
            </SPAN>
        <% end if %>
        <SPAN style="float:left">
            <BUTTON id="btnExport" onclick="exportMsgs()">Export</BUTTON>
        </SPAN>
        <SPAN style="float:right">
            <BUTTON onclick="viewCustomerFunctions(customerseq.value)">Exit</BUTTON>
        </SPAN>
	<% else %>
        <SPAN style="float:left">
    	    <BUTTON id="btnSendMessage" onclick="replyToSmsMessage()">Reply</BUTTON>
        </SPAN>
        <SPAN style="float:left">
            <BUTTON id="btnExport" onclick="exportMsgs()">Export</BUTTON>
        </SPAN>
        <SPAN style="float:right">
            <BUTTON onclick="exit()">Exit</BUTTON>
        </SPAN>
    <% end if %>
</DIV>

<div style="height: 640px; overflow: scroll">
<table class="itable" width="100%" cellspacing="0">
<tr>
    <% if customerseq = "" then %>
        <th>Customer</th>
        <% tableData = tableData & "Customer," %>
    <% end if %>
	<th>Date Received/Sent</th>
    <% tableData = tableData & "Date Received/Sent," %>
	<th>Direction</th>
    <% tableData = tableData & "Direction," %>
	<% if directSel <> 1 then %>
	    <th>Sent By</th>
        <% tableData = tableData & "Sent By," %>
	<% end if %>
	<th>Segments</th>
    <% tableData = tableData & "Segments," %>
	<th>Message</th>
    <% tableData = tableData & "Message," %>
	<th>Status</th>
    <% tableData = tableData & "Status" & vbCrLf %>
	<th>&nbsp;</th>
</tr>

<%
	while not(rs.eof or rs.bof) and idx < rs.pagesize
	segCnt = segCnt + cInt(rs("segments"))
%>
<tr onClick="selectRow(this)" direction="<%=rs("direction")%>" fullMessage="<%=escape(rs("body"))%>" successStatus="<%=rs("maxStatus")%>"
    custSeqNum="<%=rs("SeqNum")%>" phoneNum="<%=rs("phone")%>" messageId="<%=rs("id")%>"
<% if rs("direction") = "Received" and rs("maxStatus") = 0 then %>
        style="background-color: red"
<% end if%>
 >

    <% if customerseq = "" then %>
        <% if rs("customerName") <> "" then %>
            <td>
                <A HREF="/mainapp/customerfunctions.asp?customerseq=<%=rs("SeqNum")%>"><%=rs("customerName")%></A>
            </td>

        <% tableData = tableData & rs("customerName") & "," %>
        <% else %>
            <td>(<%=rs("phone")%>)</td>
            <% tableData = tableData & rs("phone") & "," %>
        <% end if %>
    <% end if %>
	<td><%=rs("messageDate")%></td>
    <% tableData = tableData & rs("messageDate") & "," %>
	<td><%=rs("direction")%></td>
    <% tableData = tableData & rs("direction") & "," %>
	<% if directSel <> 1 then
	    if rs("direction") = "Send" then
	        if rs("employeeId") = 0 then %>
	            <% if rs("queryName") <> "" then %>
	                <td><%=rs("queryName")%></td>
                    <% tableData = tableData & rs("queryName") & "," %>
	            <% else %>
	                <td>Scheduler Service</td>
                    <% tableData = tableData & "Scheduler Service," %>
	            <% end if %>
	        <% elseif rs("employeeId") = 2 then %>
	            <td>Auto Reply</td>
                    <% tableData = tableData & "Auto Reply," %>
	        <% else %>
	            <td><%=rs("employeeName")%></td>
                <% tableData = tableData & rs("employeeName") & "," %>
	        <% end if %>
	    <% else %>
	        <td></td>
                <% tableData = tableData & "," %>
	    <% end if %>
	<% end if %>
	<td><%=rs("segments")%></td>
    <% tableData = tableData & rs("segments") & "," %>
	<td>
    <% if customerseq = "" then %>
        <% if len(rs("body")) > 90 then %>
            <%=server.htmlencode(Left(rs("body"), 90))%>...
        <% else %>
           <%=server.htmlencode(rs("body"))%>
        <% end if %>
    <% else %>
        <% if len(rs("body")) > 120 then %>
            <%=server.htmlencode(Left(rs("body"), 120))%>...
        <% else %>
           <%=server.htmlencode(rs("body"))%>
        <% end if %>
    <% end if %>
    <% tableData = tableData & """" & rs("body") & """," %>
	</td>
        <td>
            <% if rs("direction") = "Received" then %>
                <% if rs("maxStatus") = 0 then %>
                    Unread
                <% tableData = tableData & "Unread," %>
                <% elseif rs("maxStatus") = 1 then %>
                    Read
                <% tableData = tableData & "Read," %>
                <% elseif rs("maxStatus") = 2 then %>
                    Handled
                    <% tableData = tableData & "Handled," %>
                <% elseif rs("maxStatus") = 3 then %>
                    Auto-Handled
                    <% tableData = tableData & "Auto-Handled," %>
                <% end if %>
            <% else %>
                <% if rs("maxStatus") = 0 then %>
                    Queued
                    <% tableData = tableData & "Queued," %>
                <% elseif rs("maxStatus") = 1 then %>
                    Sent
                    <% tableData = tableData & "Sent," %>
                <% else %>
                    <span style="background-color: red">Error:
                    <% if rs("maxStatus") = -1 then %>
                        Will Retry
                    <% tableData = tableData & "Error: Will Retry," %>
                    <% elseif rs("maxStatus") = -2 then %>
                        Won't Retry
                        <% tableData = tableData & "Error: Won't Retry," %>
                    <% elseif rs("maxStatus") = -3 then %>
                        Blocked Due to Limit
                        <% tableData = tableData & "Error: Blocked Due to Limit," %>
                    <% end if %>
                    </span>
                <% end if %>
            <% end if %>
        </td>
	<td>
	    <% if rs("direction") = "Received" and rs("maxStatus") < 2 then %>
	        <input type="button" value="Handled" class="btn" onclick="setHandled(<%=rs("id")%>)">
	        <input type="button" value="Unread" class="btn" onclick="setUnread(<%=rs("id")%>)">
	    <% else %>
	        &nbsp;
	    <% end if %>
    </td>
    <% tableData = tableData & vbCrLf %>
</tr>

<%
    idx = idx + 1
	rs.movenext
	wend
%>
</table>

<%
				if rs.pagecount > 1 then
%>
				<span style="float:left">
				<button style="height:50px;width:80px" onclick="prevPage()" <% if pagenum = 1 then %>disabled <%end if %>>Prev</button>
				<button style="height:50px;width:80px" onclick="nextPage()" <% if cInt(pagenum) = rs.pagecount then %>disabled <%end if %>>Next</button>

				Page
				<select onchange="goToPage(this.value)" >
<%
				for idx = 1 to rs.pagecount
%>
					<option value="<%=idx%>" <%if trim(idx) = trim(pagenum) then%>selected<%end if%>><%=idx%></option>
<%
				next
%>
				</select>
				of <%=rs.pagecount%>
				</span>
<%
				end if
%>
</div>
* Count only includes customer facing texts, not employee sms reports
<%
    if Request.QueryString("totalSegCnt") <> "" then
        segCnt = Request.QueryString("totalSegCnt")
    else
        while not(rs.eof or rs.bof)
            segCnt = segCnt + cInt(rs("segments"))
            rs.movenext
        wend
    end if
%>

<div style="height: 100px"></div>
<!-- Needs to be down here so that the segCnt is set before page creates this section -->
<script language="javascript" type="text/javascript">
	function init() {
	     $("#segCntSpan").text("<%=segCnt%>*");
	     $("#directSel").val("<%=directSel%>");
	     $("#twilioNum").text(formatPhoneNumber(<%=twilioNum%>));
	     <% if customerseq <> "" then %>
	        $("#custNumber").text(formatPhoneNumber(<%=custCellPhone%>));
	     <% end if %>
	}



    function exportMsgs() {
      var element = document.createElement('a');
      element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(`<%=Replace(tableData, "\", "\\")%>`));
      element.setAttribute('download', "SMSHistory.csv");

      element.style.display = 'none';
      document.body.appendChild(element);

      element.click();

      document.body.removeChild(element);
    }


	function nextPage() {
		document.smsHistory.action  = "?pagenum=" + (parseInt(document.smsHistory.pagenum.value) + 1) + "&totalSegCnt=<%=segCnt%>" + createActionString();
		document.smsHistory.submit();
	}

	function prevPage() {
		document.smsHistory.action  = "?pagenum=" + (parseInt(document.smsHistory.pagenum.value) - 1) + "&totalSegCnt=<%=segCnt%>" + createActionString();
		document.smsHistory.submit();
	}

	function goToPage(pagenumber) {
		document.smsHistory.action  = "?pagenum=" + pagenumber + "&totalSegCnt=<%=segCnt%>" + createActionString();
		document.smsHistory.submit();
	}


</script>
</FORM>
</BODY>
</HTML>

