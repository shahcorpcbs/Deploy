<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%

    dim autoCreateOnly
    autoCreateOnly = getMSVar("autoCreateDeliveryOnly")

	function countOpenDeliveries()
		dim query, rs
		query = " select count(*) as cnt from delivery where delivery.status <> 5 "
		set rs = getdisconnectedrecordset(query)
		countOpenDeliveries = rs("cnt")
	end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function
	
%>
<HTML>
<HEAD>
<TITLE>Delivery Manager</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function exitManager() {
		document.deliveryManager.action = "start2.asp";
		document.deliveryManager.submit();
	}
	
	function continueDelivery() {
		document.deliveryManager.action = "deliveryList.asp";
		document.deliveryManager.submit();
	}

	function viewScheduledDeliveries() {
		document.deliveryManager.action = "scheduleDelivery.asp";
		document.deliveryManager.submit();
	}


	function createNewDelivery() {
		document.deliveryManager.action = "deliverySelectRoutes.asp";
		document.deliveryManager.submit();
	}

</script>
<BODY topmargin=0 leftmargin=0>

<FORM name="deliveryManager" ID="deliveryManager" METHOD=POST  style="margin:0;padding:0">
<!-- #include file="../include/banner.inc" -->
<H1>Delivery Manager</H1>

<BR /><BR />
<BR /><BR />
<%
	dim openDeliveryCount
	
	openDeliveryCount = countOpenDeliveries()
	
	if openDeliveryCount > 0 then
%>
<DIV style="text-align:center;font-size:20;padding:10px">
	<%=openDeliveryCount%> Open Deliveries
</DIV>
<%
	end if
%>

<TABLE align="center" valign="center">
    <% if not autoCreateOnly then %>
	    <TR><TD><INPUT type="button" style="width:200px;height:50px" onclick="createNewDelivery()" value="Create New Delivery" /></TD></TR>
	<% end if %>
	<TR><TD><INPUT type="button" style="width:200px;height:50px" onclick="continueDelivery()" value="View Existing Delivery" /></TD></TR>
	<TR><TD><INPUT type="button" style="width:200px;height:50px" onclick="viewScheduledDeliveries()" value="Scheduled Pickups" /></TD></TR>
	<TR><TD><INPUT type="button" style="width:200px;height:50px" onclick="exitManager()" value="Exit" /></TD></TR>
</TABLE>
</FORM>
</BODY>
</HTML>
