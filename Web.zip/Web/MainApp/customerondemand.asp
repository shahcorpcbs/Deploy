<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%

	dim customerSeq

	customerSeq = request.querystring("customerseq")

	select case lcase(request.querystring("useraction"))
	case "update"
		updateCustomerODC customerSeq, request.querystring("odcid"), request.querystring("value")

	end select
	

	function getODCTarget(odcid)
		dim query, rs

		if odcid <> "" then
			query = " select cri_target from ondemandcoupon where id = " & odcid
			set rs = getdisconnectedrecordset(query)
	
			if rs.recordcount > 0 then
				getODCTarget = trim(rs("cri_target"))
			end if
	
			set rs = nothing
		end if
	end function

	function getODCRequired(odcid)
		dim query, rs

		if odcid <> "" then
			query = " select cri_required from ondemandcoupon where id = " & odcid
			set rs = getdisconnectedrecordset(query)
	
			if rs.recordcount > 0 then
				getODCRequired = rs("cri_required")
			end if
	
			set rs = nothing
		end if
	end function

	function getCustomerCriField(customerSeq, target, ctype)
		dim query, rs

		select case lcase(target)
		case "dollarsspent"
		    if ctype = 1 then
			    query = " select dbo.getCustomerSales(" & customerSeq & ", null, null) as val "
		    else
			query = " select dbo.getCustomerSalesWoOnAccount(" & customerSeq & ", null, null) as val "
			end if
		case "visits"
			query = " select dbo.getCustomerVisits(" & customerSeq & ", null, null) as val from customer " 
		end select

		if query <> "" then
			set rs = getdisconnectedrecordset(query)
	
			if rs.recordcount > 0 then
				getCustomerCriField = rs("val")
			end if
	
			set rs = nothing
		end if

	end function

	function updateCustomerODC(customerSeq, odcid, value)
		dim query, rs
		dim target
		dim required
		dim cri_field
		dim new_cri
		dim ctype

		query = "select type from onDemandCoupon where id = " & odcid
		set rs = getdisconnectedrecordset(query)
		ctype = rs("type")

		target = getODCTarget(odcid)
		required = getODCRequired(odcid)
		cri_field =  getCustomerCriField(customerSeq, target, ctype)

		new_cri = cri_field - value

		query = " delete ondemandcouponsawarded where odcid = " & odcid & " and customersequencenumber = " & customerSeq & " and cri_value >= " & new_cri
		qryexecute query

		query = " insert into ondemandcouponsawarded (odcid, customersequencenumber, cri_value) "
		query = query & " values ( "
		query = query & odcid
		query = query & ", " & customerSeq
		query = query & ", " & new_cri
		query = query & ")"

		qryexecute query
	end function

	function getOnDemandCouponLines(customerSeq)
		dim query, rs
		dim odcList
		dim odcAwarded
		dim result
		dim visitCount
		dim totalSales
		dim totalSalesWoAcct
		dim targetValue
		dim targetPrefix

		query = " select ondemandcoupon.id as odcid, "
		query = query & " discount.discountname, type,"
		query = query & " cri_condition, cri_required, "
		query = query & " cri_target "
		query = query & " from ondemandcoupon inner join discount on "
		query = query & " ondemandcoupon.cid = discount.discountid "
		query = query & " where ondemandcoupon.enabled = 1 "

		set odcList = getdisconnectedrecordset(query)


		query = " select odcid, isnull(max(cri_value), 0) as maxValue "
		query = query & " from ondemandcouponsawarded "
		query = query & " where customersequencenumber = " & customerSeq
		query = query & " group by odcid "

		set odcAwarded = getdisconnectedrecordset(query)

		query = " select dbo.getCustomerVisits(customersequencenumber, null, null) as visitCount, " _
		    & " dbo.getCustomerSalesWoOnAccount(customersequencenumber, null, null) as totalSalesWoAcct, " _
		    & " dbo.getCustomerSales(customersequencenumber, null, null) as totalSales from customer " _
		    & " where OnDemandQualified = 1 and customersequencenumber = " & customerSeq

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			visitCount = rs("visitCount")
			totalSales = rs("totalSales")
			totalSalesWoAcct = rs("totalSalesWoAcct")
		else
			visitCount = 0
			totalSales = 0
			totalSalesWoAcct = 0
		end if


		result = "<table class=""itable"" cellspacing=""0"">"
		result = result & "<tr>"
		result = result & "<th>&nbsp;</th>"
		result = result & "<th>Name</th>"
		result = result & "<th>Current Level</th>"
		result = result & "<th>Goal</th>"
		result = result & "</tr>"

		while not(odcList.eof or odcList.bof)
			odcAwarded.filter = " odcid = " & odcList("odcid")


			result = result & "<tr>"


			result = result & "<td><input type=""button"" value=""Update"" onclick=""updateODC(" & odcList("odcid") & ");""></td>"

			result = result & "<td>"

			if odcList("type") = 1 then
			    result = result & odcList("discountname")
			else
			    result = result & "Account Credit"
			end if

			result = result & "</td>"


            if rs.recordcount = 0 then
				select case trim(odcList("cri_target"))
				case "VISITS"
					result = result & "<td><input id=""odcid" & odcList("odcid") & """ style=""text-align:right; width:60px"" value=""0""></td><td>" & odcList("cri_required") & "</td>"
				case "DOLLARSSPENT"
					result = result & "<td><input id=""odcid" & odcList("odcid") & """ style=""text-align:right; width:60px"" value=""0""></td><td>" & formatcurrency(odcList("cri_required")) & "</td>"
				end select
			elseif odcAwarded.recordcount > 0 then
				select case trim(odcList("cri_target"))
				case "VISITS"
					result = result & "<td><input id=""odcid" & odcList("odcid") & """ style=""text-align:right; width:60px"" value=""" & trim(clng(visitCount) - clng(odcAwarded("maxValue")) & """></td><td>" & odcList("cri_required")) & "</td>"
				case "DOLLARSSPENT"
				    if odcList("type") = 1 then
					    result = result & "<td><input id=""odcid" & odcList("odcid") & """ style=""text-align:right; width:60px"" value=""" & formatnumber(cdbl(totalSales) - cdbl(odcAwarded("maxValue")),,,0) & """></td><td>" & formatcurrency(odcList("cri_required")) & "</td>"
				    else
				        result = result & "<td><input id=""odcid" & odcList("odcid") & """ style=""text-align:right; width:60px"" value=""" & formatnumber(cdbl(totalSalesWoAcct) - cdbl(odcAwarded("maxValue")),,,0) & """></td><td>" & formatcurrency(odcList("cri_required")) & "</td>"
				    end if
				end select
			else
				select case trim(odcList("cri_target"))
				case "VISITS"
					result = result & "<td><input id=""odcid" & odcList("odcid") & """ style=""text-align:right; width:60px"" value=""" & visitCount & """></td><td>" & odcList("cri_required") & "</td>"
				case "DOLLARSSPENT"
				    if odcList("type") = 1 then
					    result = result & "<td><input id=""odcid" & odcList("odcid") & """ style=""text-align:right; width:60px"" value=""" & formatnumber(totalSales, 2,,,0) & """></td><td>" & formatcurrency(odcList("cri_required")) & "</td>"
					else
					    result = result & "<td><input id=""odcid" & odcList("odcid") & """ style=""text-align:right; width:60px"" value=""" & formatnumber(totalSalesWoAcct, 2,,,0) & """></td><td>" & formatcurrency(odcList("cri_required")) & "</td>"
				    end if
				end select
			end if


			
			odcList.movenext
		wend
		
		result = result & "</table>"

		set odcList = nothing
		set odcAwarded = nothing
		
		getOnDemandCouponLines = result
	end function

%>
<HTML>
<HEAD>
<TITLE>Customer Discount</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<SCRIPT type="text/javascript">

	function updateODC(odcid) {
		var val;

		val = document.getElementById('odcid' + odcid).value;

		if (!isNum1(val, 0)){
			cbs_alert("Please enter a decimal value ");
		}
		else {
            document.demandStatus.action = "/MainApp/customerondemand.asp?useraction=update&customerseq=<%=customerseq%>&odcid=" + odcid + "&value=" + val;
            document.demandStatus.submit();
		}
	}

    function exit() {
        document.demandStatus.action = "/MainApp/customerdiscount.asp?targetpage=customerentry&customerseq=<%=customerseq%>";
        document.demandStatus.submit();
    }
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<FORM name="demandStatus" ID="demandStatus" METHOD=POST  style="margin:0;padding:0">
<!-- #include file="../include/banner.inc" -->
<H1>On Demand Status</H1>


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">

	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	


<%=getOnDemandCouponLines(customerSeq)%>

</BODY>
</HTML>

