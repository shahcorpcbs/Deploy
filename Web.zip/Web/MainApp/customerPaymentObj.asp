<%
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 5-Sep-2003	 Johnston		Added user defined prompt if account credit
	'*****************************************************************

	function initializeCustomerPaymentInfo()
		dim ObjCustPayment
		dim ssql
		dim storeId
		dim objResultSet
		dim custSeqNumber
		
		storeId =Session("storeID")
		custSeqNumber = Session("customersequencenumber")
		set ObjCustPayment = Server.CreateObject("Scripting.Dictionary")
		set Session("customerPayment") = ObjCustPayment
		ssql = "Select PaymentTypeName, " _
				& " PaymentTermsID,AccountBalance, CreditLimit, permanentAccount, " _
				& " temporaryAccount, accountBalance From Customer " _
				& " Where customerSequenceNumber=" & custSeqNumber
		set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Recordcount > 0 then
			objResultSet.MoveFirst
			ObjCustPayment.Add "PaymentTypeName", objResultSet.Fields("PaymentTypeName").Value
			ObjCustPayment.Add "PaymentTermsID", objResultSet.Fields("PaymentTermsID").Value
			ObjCustPayment.Add "AccountBalance", objResultSet.Fields("AccountBalance").Value
			ObjCustPayment.Add "CreditLimit", objResultSet.Fields("CreditLimit").Value
			ObjCustPayment.Add "permanentAccount", objResultSet.Fields("permanentAccount").Value
			ObjCustPayment.Add "temporaryAccount", objResultSet.Fields("temporaryAccount").Value
			ObjCustPayment.Add "accountBalance", objResultSet.Fields("accountBalance").Value
		end if
		
		'Following lines added by J.Johnston, 5 Sept 2003
		'Used to capture credit balance
		dim rstTemp
		dim sqltxt
		dim l_accountbalance
	
		l_accountbalance = 0.00
	
		sqltxt = "Execute dbo.GetCustomerAccountBalance " & custSeqNumber
	
		set rstTemp = getdisconnectedrecordset(sqltxt)
	
		if rstTemp.recordcount > 0 then
			l_accountbalance =  rstTemp("accountbalance")
			if isnull(l_accountbalance) then
				l_accountbalance = 0.00
			else
				l_accountbalance= cdbl(l_accountbalance)
			end if
			ObjCustPayment.Add "creditBalance", l_accountbalance 	
		end if			
		rsttemp.close
		set rstTemp = nothing	
		'End addition by J.Johnston, 5 Sept 2003				
		
		
	end function
		
%>
