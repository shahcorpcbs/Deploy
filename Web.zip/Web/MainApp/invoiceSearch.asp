<%@ Language=VBScript %>

<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>


<%
	dim actionString

	'added by steve gagnon
	'if searchstring contains a value it will be searched
	dim searchString
	dim searchResult
	dim sqlString


	actionString = Request.QueryString("userAction")
	searchString = Request.QueryString("search")

	'if anything there query for the correct ticketNumber
	if Trim(searchString) <> "" then
	
		sqlString = "SELECT ticketNumber FROM Ticket WHERE ticketStatus = 'AC' AND invoiceNumber = " & dbCreateQryString(searchString)
		set searchResult = getdisconnectedrecordset(sqlString)
	else
		set searchResult = nothing
	end if


	getKeyboardsetting()
	
%>
<HTML>
<HEAD>
<TITLE>Ticket Search</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
	<SCRIPT LANGUAGE=javascript>
	var lastFocusControl;
	<!--
		
	//-->
	</SCRIPT>

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function txtInvoiceNumber_onblur() {
	lastFocusControl = event.srcElement;
}

//-->
</SCRIPT>
</HEAD>

<script language="javascript" type="text/javascript">

	function searchInvoice(){
		var tempVal
		
		tempVal= trim(document.searchInvoiceForm.txtInvoiceId.value)
		if (tempVal == "" ){
			cbs_alert("Enter an Invoice number")
			document.searchInvoiceForm.txtInvoiceId.focus()
			return false;
			}
		 else{
		 

		
			document.searchInvoiceForm.action ="invoiceSearch.asp?search=" + document.searchInvoiceForm.txtInvoiceId.value; 
			document.searchInvoiceForm.submit();
			return true;
		}
	}
	
	function captureKeyUpEvent(){
		searchInvoice();
	}
	
	
	function setFocus(){

	<% if not searchResult is nothing then
	if searchResult.recordcount > 0 then 

		searchResult.MoveFirst
	%>
		document.searchInvoiceForm.action = "Detailedinvoice.asp?userAction=edit&Ticketnumber=" +  <% =searchResult("ticketNumber").Value %> + "&multiplePickup=0&originPage=invoicesearch";
		document.searchInvoiceForm.submit();
		return true;
	<%else%>
		cbs_alert("No records found")
	<%end if
	end if%>
	
	
	document.searchInvoiceForm.txtInvoiceId.focus()

	
	}
	
	function cancelForm(){
		document.searchInvoiceForm.action ="start2.asp"
		document.searchInvoiceForm.submit();
		
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onLoad="setFocus()"><!-- #include file="../include/banner.inc" -->
<H1>Ticket Search</H1>
<TABLE width="98%" align=center cellspacing="2" cellpadding="0" border="0" style="WIDTH: 98%">
<TR>
   <TD>
   <FORM id="searchInvoiceForm" name="searchInvoiceForm" action ="" onSubmit="captureKeyUpEvent()"  method="Post">
	<INPUT type="hidden" name="targetPage" value="<%= actionString %>">
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >

			<TR>
				<TD align=right class="label">Invoice Number</TD>
				<TD align=left >
					<INPUT id=txtInvoiceId name=txtInvoiceId class=text LANGUAGE=javascript onblur="return txtInvoiceNumber_onblur()" style  ="WIDTH:254px;HEIGHT:25px">
				</TD>

				<TD width = 50px >
					<INPUT class=touch id=searchButton name=searchButton type=button style="background-image:url(../images/search.gif)" onClick="searchInvoice()" ><BR>Search
				</TD>
				<TD width = 150px >
			 	<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
				</TD>
								
			</TR>
			<tr height=30><td></td></tr>
			<tr>
				<td colspan=4 align="left">
					<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
						<tr>
							<td>
							<% if l_keyboard  then %>
							<!-- #include file="../include/keyboard_alphabeticalOrder.inc" -->								
							<% else %>
							<!-- #include file="../include/keyboard.inc" -->
							<%end if %>
							</td>
							<td width=70></td>
						</tr>
					</TABLE>
				</td>
				
			</tr>
		</TABLE>
		<P>&nbsp;</P>
		
		
		
		<BR>
	</TD>
</TR>
</TABLE></FORM>   

</BODY>
</HTML>

<%
	dim l_keyboard
	
	function getKeyboardsetting()
	dim sqltxt
	dim rsTemp
	
	l_keyboard = false
	
	sqltxt = "select switchOnscreenKeyboardAlphabetic from Miscsetup where storeid =  " & session("storeid")
	set rsTemp = getDisconnectedrecordset(sqltxt)
	'Response.Write sqltxt
	if rsTemp.recordCount > 0 then
		if rsTemp("switchOnscreenKeyboardAlphabetic")= true then
			l_keyboard = true
		end if
	end if
	rstemp.close
	set rstemp = nothing
		
	
	end function
	
	
%>

