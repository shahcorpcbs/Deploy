<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 900 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim bodyText

	bodyText = request.querystring("bodyText")
%>

<HTML>
<HEAD>
<TITLE>SMS Message</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>


<BODY topmargin=0 leftmargin=0>


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">

	<SPAN style="float:right">
		<BUTTON onclick="window.close()" value="" >Exit</BUTTON>
	</SPAN>
</DIV>	
<DIV id="statement_container">
<%=bodyText%>
</DIV>

</BODY>
</HTML>

