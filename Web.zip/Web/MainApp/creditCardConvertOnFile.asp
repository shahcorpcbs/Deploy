<%@ Language=VBScript %>

<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim customerseq
	
	customerseq = session("customersequencenumber")
	
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Credit Card On File</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<link rel="stylesheet" type="text/css" href="/external/ext/resources/css/ext-all.css" />
<link rel="stylesheet" type="text/css" href="/external/ext/resources/css/xtheme-gray.css" />

<script type="text/javascript" src="/external/ext/adapter/ext/ext-base.js"></script>
<script type="text/javascript" src="/external/ext/ext-all.js"></script>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript" src="/Script/validation.js"></script>

<script language="javascript" type="text/javascript" src="/Script/xchargeprocessor.js"></script>


<SCRIPT type="text/javascript">

	function exit() {
        document.ccConvertOnFile.action = "start2.asp";
        document.ccConvertOnFile.submit();
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="">

<!-- #include file="../include/banner.inc" -->

<B class="pageHeading">Credit Card On File</B>
<FORM name="ccConvertOnFile" ID="ccConvertOnFile" METHOD=POST  style="margin:0;padding:0">
<%
	query = " select * from customer where creditcardonxc = 0 and creditCardNumber <> '' "
	set rs = getdisconnectedrecordset(query)
%>



<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="convertSelected()" >Convert</BUTTON>
		<BUTTON onclick="clear()">Clear</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" cellspacing="0">
	<TR>
		<TH>Customer Name</TH>
		<TH>Account Number</TH>
		<TH>Expiration</TH>
	<TR>
	
<%
	while not(rs.eof or rs.bof)
%>
	<TR customerseq="<%=rs("customersequencenumber")%>" cardnumber="<%=rs("creditCardNumber")%>" cardexp="<%=rs("creditCardExpDate")%>">
		<TD><%=Server.HTMLEncode(rs("customerName"))%></TD>
		<TD><%=Server.HTMLEncode(rs("creditCardNumber"))%></TD>
		<TD><%=Server.HTMLEncode(rs("creditCardExpDate"))%></TD>
	</TR>

<%
		rs.movenext
	wend
	set rs = nothing
%>
</TABLE>
</FORM>
</BODY>
</HTML>
