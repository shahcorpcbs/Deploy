<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->


<%

	
	class ProcessFileResult
		dim filename
		dim size
		dim dateModified
		dim message
		dim returned
		dim deleted
	end class

	dim results
	set results = CreateObject("Scripting.Dictionary")

	processFiles(Server.MapPath("/Drop/"))

	function getExtension(filename)
		dim parts
		parts = split(filename, ".")
		getExtension = parts(ubound(parts))
	end function

	Function ReadBinaryFile(FileName)
	  Const adTypeBinary = 1
	  
	  'Create Stream object
	  Dim BinaryStream
	  Set BinaryStream = CreateObject("ADODB.Stream")
	  
	  'Specify stream type - we want To get binary data.
	  BinaryStream.Type = adTypeBinary
	  
	  'Open the stream
	  BinaryStream.Open
	  
	  'Load the file data from disk To stream object
	  BinaryStream.LoadFromFile FileName
	  
	  'Open the stream And get binary data from the object
	  ReadBinaryFile = BinaryStream.Read
	End Function

	function processFiles(dir)
		dim fs
		dim folder
		dim filename
		dim file
		dim result
		dim rs
		dim fileStream

		set fs = CreateObject("Scripting.FileSystemObject")
		set folder = fs.GetFolder(dir)


		for each file in folder.Files
			set result = new ProcessFileResult

			
			result.filename = file.Name
			result.size = file.Size
			result.dateModified = file.DateLastModified

			select case getExtension(file.Name)
			case "rtf"
				result.message = saveForm(replace(file.Name, ".rtf", ""), ReadBinaryFile(dir & "\" &  file.Name))
			case "sql"
				set fileStream = fs.OpenTextFile(dir & "\" &  file.Name, 1) 
				set rs = getdisconnectedrecordset(fileStream.ReadAll)
				result.message = rs.recordcount & " records returned "
				result.returned = rsToTable(rs)
				fileStream.Close
			case else
				result.message = "nothing to do"
			end select

			results.Add result.filename, result

			
			set fileStream = nothing
		next

	end function

	function saveForm(name, rtf)
		on error resume next
		dim conn
		dim rs
		dim query

		Set conn = Server.CreateObject("ADODB.Connection")
		Set rs = Server.CreateObject("ADODB.Recordset")

		conn.Open Session("shahcorpDSN")
		'conn.BeginTrans 

		query = "SELECT * FROM Form WHERE formName = '" & name & "' AND storeID = " & session("storeid")

		rs.Open query, conn, 3, 3

		if rs.RecordCount > 0 then
			rs.Fields("formLayout") = rtf
		    rs.Update
			saveForm = "form " & name & " updated"
		else
			rs.AddNew
			rs.Fields("formName") = name
			rs.Fields("storeID") = session("storeid")
			rs.Fields("formLayout") = rtf
	        rs.Update
			saveForm = "form " & name & " added"
		end if

	     if Err.number <> 0 then 
			saveForm = "problem " & Hex(Err.number) & " with " & name & ":" & Err.Description
			'conn.RollbackTrans 	
			rs.Close
			conn.Close 
			set rs = nothing
			set conn = nothing
		else
			'conn.CommitTrans  	
			rs.Close
			conn.Close 
			set rs = nothing
			set conn = nothing
		end if


	end function

	function rsToTable(rs)
		dim result
		dim i

		if isnull(rs) then exit function

		result = "<table>"
		
		result = result & "<tr>"
		
		for i = 0 to rs.Fields.Count - 1
			if rs.Fields(i).Name = "" then
				result = result & "<th>[" & i & "]</th>"
			else
				result = result & "<th>" & rs.Fields(i).Name & "</th>"
			end if
		next
		
		result = result & "</tr>"
		
		rs.MoveFirst
		
		while not rs.eof
			result = result & "<tr>"
			
			for i = 0 to rs.Fields.Count - 1
				result = result & "<td>" & rs.Fields(i).Value & "</td>"
			next
			
			result = result & "</tr>"
			
			rs.MoveNext
		wend
		rsToTable = result
	end function

	function formatFileSize(size)
		if size < 1024 then
			formatFileSize = size & " bytes"
		elseif size < 104857600 then
			formatFileSize = round(size / 1024, 1) & " kb"
		else
			formatFileSize = round(size / 1048576, 1) & " mb"
		end if

	end function

%>



<HTML>
<HEAD>
</HEAD>

<BODY>

<TABLE>
<%
	dim result
	for each result in results.Items()
%>
	<TR>
		<TD><%=result.filename%></TD>
		<TD><%=formatFileSize(result.size)%></TD>
		<TD><%=result.dateModified%></TD>
	</TR>
	<TR>
		<TD colspan="3"><%=result.message%></TD>
	</TR>
	<TR>
		<TD colspan="3"><%=result.returned%></TD>
	</TR>
<%
	next
%>
</TABLE>

</BODY>
</HTML>
