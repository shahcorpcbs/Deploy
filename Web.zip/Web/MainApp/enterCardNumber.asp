<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim paymentType
	dim amountpaid
	dim targetPage
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim prepayAmt, isPrePay
	dim forceSigAllTimes, forceSigNoClaims, claimsCount
	dim invPrePayPercent, invoicesTotal
	dim originatingPage
	dim custSeqNumber	'Added by JJ, 6Jan04	
	dim amountApplied
	
	amountApplied = Request.QueryString("amountApplied")
	paymentType = Request.QueryString("type")
	amountpaid = Request.QueryString("amountPaid")
	isPrePay =  Request.Form("isPrePay")
	prepayAmt = Request.Form("prepayAmt")
	forceSigAllTimes = Request.Form("forceSigAllTimes")
	forceSigNoClaims = Request.Form("forceSigNoClaims")
	claimsCount = Request.Form("claimsCount")
	invPrePayPercent = Request.Form("invPrepayPercent")
	invoicesTotal = Request.Form("invoicesTotal")
	originatingPage = Request.QueryString("OPage")	'Added by JJ, 6Jan04
	if originatingPage = "ApplyPayments" then
		custSeqNumber = session("accountCustomerSequenceNumber")	'Added by JJ, 6Jan04
	else
		custSeqNumber = Session("customersequencenumber")
	end if
	
	if isPrePay ="1" then
		collectInvoiceDataFromForm
	end if
	sub collectInvoiceDataFromForm()
		targetPage = Request.Form("tPage")
		addOrEdit = Request.Form("addOrEdit")
		curr_LineNo = Request.Form("lineNumber")
		selectedDept = Request.Form("selectedDept")
		itemsStartIndex = Request.Form("ItemPageCount")
		upChargeStartIndex = Request.Form("upChargePageCount")
		colorsStartIndex = Request.Form("colorsPageCount")
		patternStartIndex = Request.Form("PatternPageCount")
		deptStartIndex = Request.Form("DeptPageCount")
		selItemId = Request.Form("selItemId")
		selUpchargeValue = Request.Form("selUpcharge")
		selColorValue = Request.Form("selColor")
		selPatternValue = Request.Form("selPattern")
		if trim(originatingPage) = "" then
			originatingPage = Request.Form("originPage")
		end if
	end sub
	
%>

<HTML>
<HEAD>
<TITLE>Card Number</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

<!--Comented By vivek on 14 Feb 2003 for Issue BSSIL-2
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
var lastFocusControl;
function txtCardNumber_onblur() {
	lastFocusControl = event.srcElement;
	document.cardNumber.okButton.focus();
}
</SCRIPT>
-->
</HEAD>
<script language="javascript" type="text/javascript">

	//Following added by J.Johnston, 25Sept03
	var lastFocusControl;
	//End addition by J.Johnston, 25Sept03
	
	function submitForm(userAction) 
	{
		var cardCheckNo
		cardCheckNo = document.cardNumber.txtCardNumber.value;
		
		if (userAction =="ok") 
		{
			if (cardCheckNo.length > 0) 
			{
				if(document.cardNumber.originPage.value == "pickup")
				{
					if(document.cardNumber.paymentType.value == "Coupon Payment")
						document.cardNumber.action = "pickup.asp?userAction=addCouponPayment&amount=" + document.cardNumber.amount.value + "&amountApplied=" + document.cardNumber.amountApplied.value;
					else
						document.cardNumber.action = "pickup.asp?userAction=cardNumber&submit=" + userAction;

					document.cardNumber.submit();
				}
				if(document.cardNumber.originPage.value == "ApplyPayments")	//Added by JJ, 6Jan04
				{
					document.cardNumber.action = "ApplyPayments.asp?customerSeq="+document.cardNumber.custSeqNumber.value+"&amountpaid="+document.cardNumber.amount.value+"&type="+document.cardNumber.paymentType.value;
					document.cardNumber.submit();
				}				
				
			}
			else 
			{
				alert("You must enter a Number");
			}
		}
		else
		{
			if(document.cardNumber.originPage.value == "pickup")
			{			
				document.cardNumber.action ="pickup.asp?userAction=cardNumber&submit=" + userAction;
				document.cardNumber.submit();
			}
		}
	}
	
	function cancelForm() 
	{

		if(document.cardNumber.originPage.value == "pickup")
		{
			document.cardNumber.action = "pickup.asp";
		}
		else if(document.cardNumber.originPage.value == "ApplyPayments")	//Added by JJ, 6Jan04
		{
			document.cardNumber.action = "ApplyPayments.asp";
			document.cardNumber.submit();
		}		
		document.cardNumber.submit();		

	}

	function checkEnter(event){ 	
		var code = 0;
		
		code = event.keyCode;
		if (code==13)
			submitForm("ok");
	}
	
	function validateEnterKey() {
		return false;
	}
	
	//Function added by vivek on 02 Feb 2003 to set the default focus on Card no Text box after loading the page.
	function setFocusOnFirstControl(){		
		{									
			document.cardNumber.txtCardNumber.focus();
		}	
	}
	
	//Function added by vivek on 02 Feb 2003 to set the focus on Ok button.
	function setFocusOnControl(){				
		document.cardNumber.okButton.focus();
	}	
	
	//Function added by vivek on 02 Feb 2003 to set the focus on OK button when enter key pressed in CardNumber Textbox.
	function captureKeyUpEvent()
	{
		
		if (event.keyCode == 13)
		{			
			submitForm('ok');
		}
	}
	
	
	function onNumberBlur() {
		lastFocusControl = document.getElementById("txtCardNumber");
	}
		
</script>

<BODY topmargin=0 leftmargin=0 onload="setFocusOnFirstControl();">
<center>

<!-- #include file="../include/banner.inc" -->
<H1>Please enter <%=paymentType%> Number</H1>
<FORM id="cardNumber" name="cardNumber" action="enterCardNumber.asp" method="post" onSubmit ="return validateEnterKey();" >
	<INPUT type="hidden" name="paymentType" value="<%= paymentType%>">
	<INPUT type="hidden" name="amount" value="<%= amountpaid%>">
	<INPUT type="hidden" name="amountApplied" value="<%= amountApplied%>">
	<INPUT type="hidden" name="isPrePay" value="<%= isPrePay%>">
	<INPUT type="hidden" name="prepayAmt" value="<%= prepayAmt%>">
	<INPUT type="hidden" name="forceSigAllTimes" value="<%= forceSigAllTimes%>">
	<INPUT type="hidden" name="forceSigNoClaims" value="<%= forceSigNoClaims%>">
	<INPUT type="hidden" name="claimsCount" value="<%= claimsCount%>">
	<INPUT type="hidden" name="invPrepayPercent" value="<%= invPrePayPercent %>">
	<INPUT type="hidden" name="invoicesTotal" value="<%= invoicesTotal %>">
	<!-- invoice hidden values-->
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	<INPUT type=hidden name="custSeqNumber" value="<%= custSeqNumber%>">
	<TABLE ALIGN=center WIDTH="450px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<tr height=50px><td width=50px></td></tr>
		<TR>
			<TD class="label"  align="right"><%=paymentType%> Number&nbsp</TD>
			<TD align=left width=300px>
				<INPUT id=txtCardNumber name=txtCardNumber maxLength=20 class=text style="width:300px;" onKeyup="captureKeyUpEvent()" onBlur="onNumberBlur()">
			</TD>
		</tr>
		<tr height=50px><td></td></tr>
		<tr>	
			<td align="center" colspan=2>
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick= "submitForm('ok')" >&nbsp&nbsp&nbsp&nbsp&nbsp
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm()" >
			</td>
		</TR>
		<table width=100%>
		<tr height=50px><td></td></tr>
		<TR height=20px colspan=5></TR>
		<tr>
			<td>
				<!-- #include file="../include/keyboard.inc" -->
			</td>
		</tr>
				
	</table>
</form>
</center>
</BODY>
</HTML>
