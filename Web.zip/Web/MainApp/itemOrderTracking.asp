<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim isSubmitted 
	dim l_status
	isSubmitted = Request.QueryString("submitted")
	
	if (isSubmitted)  then
	
		updateDatabase()
		Response.Redirect("toolsMenu.asp")
	end if
	
	if trim(session("trackemployeename") ) = "" then
		getEmployeeName()
	end if 
	
	
%>
<HTML>
<HEAD>
<TITLE>Item Order Tracking</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

function captureKeyUpEvent(element){
	
		if (event.keyCode == 13){
			event.returnValue = true;
			if (element.name == "txtTicketNo"){
				document.itemOrderTrackForm.txtLocation.focus()
				}
		
			else if (element.name == "txtLocation" )
				addItemToList()

		} 
	
	}
	
function addItemToList(){
	var newOption;
	if (trim(document.itemOrderTrackForm.txtTicketNo.value)!= "" &&
		trim(document.itemOrderTrackForm.txtLocation.value)  != "")  {
			//var i = document.itemOrderTrackForm.lstRackedItems.options.length
			//newOption = new row();
			addRow("trackList" )
			// add code for new option
			document.itemOrderTrackForm.txtTicketNo.value = ""
			document.itemOrderTrackForm.txtLocation.value = ""
			document.itemOrderTrackForm.txtTicketNo.focus()
		}
	}
	
	function createDate(){
		var tempDate
		now = new Date();
		year = now.getYear();
		if (year < 2000) year = 1900 + year;
		tempdate = ( now.getMonth() + 1 )  + "/" + now.getDate()+ "/"+ year 
		var Hours;
		var Mins;
		var Time;
		Hours = now.getHours();
		
		//alert( Hours)
		
		/*if (Hours >= 12) {
			Time = " P.M";
		}
		else {
			Time = " A.M";
		}
		if (Hours > 12) {
			Hours -= 12;
		}
		if (Hours == 0) {
			Hours = 12;
		} */
		
		
		Mins = now.getMinutes();
		//alert(Mins)
		
		if (Mins < 10) {
			Mins = "0" + Mins;
		} 
		
		tempdate = tempdate  + " " + Hours + ":" + Mins
		return tempdate
	}
	
	function addRow(tName){
		
		var x 
		x = createDate()
		var sTicket
		var stag
		sTag = document.itemOrderTrackForm.txtTicketNo.value
		
		sTicket = sTag.substring(0, sTag.indexOf("-"))
			
		var tbody = document.getElementById(tName).getElementsByTagName("TBODY")[0];
		
		var row = document.createElement("TR")
		var td1 = document.createElement("TD")
		td1.width = "100px";
		td1.appendChild(document.createTextNode(sTicket))
		var td2 = document.createElement("TD")
		td2.width = "100px";
		td2.appendChild (document.createTextNode(document.itemOrderTrackForm.txtTicketNo.value))
		var td3 = document.createElement("TD")
		td3.width = "140px";
		td3.appendChild (document.createTextNode(x))
		var td4 = document.createElement("TD")
		td4.width = "100px";
		td4.appendChild (document.createTextNode(document.itemOrderTrackForm.txtLocation.value ))
		var td5 = document.createElement("TD")
		td5.width = "120px";
		td5.appendChild (document.createTextNode(document.itemOrderTrackForm.empName.value))
		
		row.appendChild(td1);
		row.appendChild(td2);
		row.appendChild(td3);
		row.appendChild(td4);
		row.appendChild(td5);
		
		tbody.appendChild(row);
		var stemp
		if ( trim(document.itemOrderTrackForm.itemList.value) == "")
		{
			stemp = td1.innerText;
			stemp = stemp + ","  + td2.innerText;
			stemp = stemp + ","  + td3.innerText;
			stemp = stemp + ","  + td4.innerText;						
			stemp = stemp + ","  + td5.innerText;
			document.itemOrderTrackForm.itemList.value = stemp;
		}
		else{
			stemp = document.itemOrderTrackForm.itemList.value ;
			stemp = stemp + "|||"
			stemp = stemp + td1.innerText;
			stemp = stemp + ","  + td2.innerText;
			stemp = stemp + ","  + td3.innerText;
			stemp = stemp + ","  + td4.innerText;	
			stemp = stemp + ","  + td5.innerText;					
			document.itemOrderTrackForm.itemList.value = stemp;
		
		}
		

	}

	function submitForm(){
		/*var mySource = document.all("trackList");
		var myRows = mySource.rows.length;
		alert(myRows)
		if (myRows > 0 ){
		
			var myCols = mySource.rows(0).cells.length;
			alert(myCols);
			myArray = new Array(myRows)
			for (i=0; i <  myRows; i++) {
				myArray[i] = new Array(myCols)
				for (j=0; j < myCols; j++) {
					myArray[i][j] = document.all("trackList").rows(i).cells(j).innerText
					if (j  == 4)
					myArray[i][j] = myArray[i][j] + ";"
				}
			}
			document.itemOrderTrackForm.itemList.value = myArray
		} */
				
		document.itemOrderTrackForm.action = "?submitted=true"
		document.itemOrderTrackForm.submit()
	
	}

</script>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<TABLE ALIGN=center WIDTH="100%" BORDER=1 CELLSPACING=1 CELLPADDING=5 >	
<FORM id="itemOrderTrackForm" name="itemOrderTrackForm" action="" method="Post">
<input type = hidden name=itemList value="">
<input type = hidden name=empName value="<%=session("trackemployeename")%>">
	<tr>
		<td>
			<table ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5>
				<tr>
					<td class="label" width=150px>Enter Ticket or Tag #</td>
					<td>
						<INPUT id="txtTicketNo" name="txtTicketNo" class=text onKeyUp="captureKeyUpEvent(this)">
					</td>
				</tr>
				<tr>
					<td class="label" width=150px>Enter Location</td>
					<td>
						<INPUT id="txtLocation" name="txtLocation" class=text onKeyUp="captureKeyUpEvent(this)">
					</td>
				</tr>
				
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<!-- list -->
			<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5>
				<!-- header row -->
			<tr>
				<td>
					<TABLE WIDTH="680px" BORDER=0 CELLSPACING=1 CELLPADDING=5>
						<!-- heading -->
						<tr>
							<th width =100px align=left class="label">Ticket Number</th>
							<th width =100px align=left class="label">Tag Number</th>
							<th width =150px align=left class="label">Date/Time Scanned</th>
							<th width =100px align=left class="label">Location</th>
							<th width =120px align=left class="label">Employee Name</th>
							<th width=16px></th>
						</tr>
					</table>
				</td>
			</tr>
		<!-- list -->
		<tr>
			<td>
				<DIV STYLE="overflow-y:auto;height:200px; overflow-x:auto; width=680px">
						<TABLE WIDTH="100%" style="border-color:#2F4F4F;border-style:solid;background-color:white;" BORDER=1 CELLSPACING=0>
							<tr rowspan =5>
								<td>
									<TABLE id=trackList name=trackList WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=1 CELLPADDING=3>
									<tbody>
									</tbody>
									</table>
								</td>
							</tr>
					</table> <!-- table for border -->
				</div>
			</td>
		</tr>
		<!-- buttons -->
		<tr>
			<td>
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 align=center>
					<tr height=10px></tr>
					<tr>
						<td height=40px align=center>
							<INPUT class=touchnoborder id=done name=done onClick=submitForm() style="background-image:url(../images/Ok.gif)" type=button value="">&nbsp&nbsp&nbsp&nbsp&nbsp
							<INPUT class=touchnoborder id=btnCancel name=btnCancel onClick=history.back(-1) style="background-image:url(../images/Cancel.gif)" type=button value="">
						</td>	
					</tr>
				</table>
			</td>
		<tr>
	</table>
		</td>
	</tr>
	
</form>
</table>
</BODY>
</HTML>
<%

	function getEmployeeName()
	
		dim sqltxt
		dim rsTemp
		
		sqltxt = "select employeename from employee where employeeid = " & session("employeeid")
		set rsTemp = getDisconnectedRecordset(sqltxt)
		
		if rsTemp.recordcount > 0 then
			session("trackemployeename") = rstemp("employeeName")
		end if
		
		rsTemp.close
		set rsTemp = nothing
		
	end function
	

	function updateDatabase()
	dim i
	dim j
	dim orgArr
	dim rowArr
	dim sTicket
	dim sTag
	dim sDate
	dim sLocation
	dim sEmployee
	dim sqltxt
	
	orgArr = split(Request.Form("itemlist"), "|||")
	
	dbStartTrans()
	
	for i = 0 to ubound(orgarr)
	
		rowArr = split(orgarr(i), ",")
		
		sTicket = rowarr(0)
		sTag = rowarr(1)
		sDate = rowarr(2)
		sLocation = rowarr(3)
		sEmployee = rowarr(4)
		
		sqltxt =  " INSERT INTO [TicketLocationTracking]([ticketNumber], [tagNumber], [trackLocation], [createdEmployeeID], [createdDate]) "  _
				&  " select ticketnumber , "  & dbcreateqrystring(sTag) _
				&  " , " & dbcreateqrystring(sLocation) _
				&  " , " & session("employeeid")_
				&  " ,  " & dbcreateqrystring(sDate)_
				&  " from ticket where invoicenumber = " & dbcreateqrystring(sTicket)
				
		qryexecutewithtrans(Sqltxt)
		
	next 
	
	dbendTrans()

	end function

%>
