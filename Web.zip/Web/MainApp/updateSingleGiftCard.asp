<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/customerPaymentObj.asp" -->
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim storeId
	storeId = Session("storeId")

	sub getActivePaymentTypes() 
		dim ssql
		dim objRst 
		ssql = "Select paymentTypeName, imageFileName from StorePaymentType where storeId=" & clng(storeId) _
				& " And enabled=1 and paymentTypeName <> 'Gift Certificate'"
		set objRst = getDisconnectedRecordset(ssql)
		Set Session("paymentTypes") = objRst
	end sub
%>	
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Issue Single Gift Card</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		document.issueSingleGiftForm.submit();
	}
	
	function cancelForm() {
		document.issueSingleGiftForm.action="issueGiftCard.asp";
		document.issueSingleGiftForm.submit()
	}	
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Issue Gift Card</B>
<FORM id="issueSingleGiftForm" name="issueSingleGiftForm" action="start2.asp" method="Post">
<TABLE ALIGN=center WIDTH=450px BORDER=1 CELLSPACING=1 CELLPADDING=10>
	<TR><TD>
	<TABLE ALIGN=center WIDTH=100% BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR height=40px><TD align=right>
			<LABEL for=giftCardNum>Gift Card Number&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=giftCardNum style= width:60px>
		</TD></TR>
		<TR height=40px><TD align=right width=25%>
			<LABEL for=custName>Customer Name&nbsp</LABEL>
			</TD>
			<TD width=40%>
			<INPUT CLASS=text name=custName>
			</TD>
			<TD width=25% align=center>
			<INPUT CLASS=touch name=search>
		</TD></TR>
		<TR height=40px><TD align=right>
			<LABEL for=curBal>Current Balance&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=curBal style= width:60px>
		</TD></TR>
		<TR height=40px><TD align=right>
			<LABEL for=amtPaid>Amount Paid&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=amtPaid style= width:60px>
		</TD></TR>
		<TR height=10px><td></td></tr>
		<TR><td colspan=3>
		<TABLE width=100%>
		<%
		
			dim paymentTypeRst
			dim isPrePay
			getActivePaymentTypes
			set paymentTypeRst = Session("paymentTypes")
			if paymentTypeRst.RecordCount > 0 then
				paymentTypeRst.MoveFirst
				while not paymentTypeRst.eof	
		%>
				<tr>
					<TD align=center width=33%><INPUT class=touch id="<%= paymentTypeRst.Fields("paymentTypeName").Value%>" name="<%= paymentTypeRst.Fields("paymentTypeName").Value%>" type=button value="" style="background-image:url(../images/<%= paymentTypeRst.Fields("imageFileName").Value%>);" onClick="addPayment(this);" <% if isPrePay = "1" and ucase(trim(paymentTypeRst.Fields("paymentTypeName").Value)) = "ON ACCOUNT" then%> disabled <% end if%>><br><%= paymentTypeRst.Fields("paymentTypeName").Value %></TD>
		<%
				paymentTypeRst.MoveNext
				if Not paymentTypeRst.EOF then
		%>								
					<TD align=center width=33%><INPUT class=touch id="<%= paymentTypeRst.Fields("paymentTypeName").Value%>" name="<%= paymentTypeRst.Fields("paymentTypeName").Value%>" type=button value="" style="background-image:url(../images/<%= paymentTypeRst.Fields("imageFileName").Value%>);" onClick="addPayment(this);" <% if isPrePay = "1" and ucase(trim(paymentTypeRst.Fields("paymentTypeName").Value)) = "ON ACCOUNT" then%> disabled <% end if%>><br><%= paymentTypeRst.Fields("paymentTypeName").Value%></TD>
		<%
					paymentTypeRst.MoveNext
				end if
				if Not paymentTypeRst.EOF then
		%>								
					<TD align=center width=33%><INPUT class=touch id="<%= paymentTypeRst.Fields("paymentTypeName").Value%>" name="<%= paymentTypeRst.Fields("paymentTypeName").Value%>" type=button value="" style="background-image:url(../images/<%= paymentTypeRst.Fields("imageFileName").Value%>);" onClick="addPayment(this);" <% if isPrePay = "1" and ucase(trim(paymentTypeRst.Fields("paymentTypeName").Value)) = "ON ACCOUNT" then%> disabled <% end if%>><br><%= paymentTypeRst.Fields("paymentTypeName").Value%></TD>
		<%
					paymentTypeRst.MoveNext
				end if
		%>

				</tr>
		<%
				wend
			end if
		%>
		</TABLE></TD></TR>

		<tr height=30px><td></td></tr>
		<TR height=30px><TD align=right>
			<LABEL for=newBal>New Balance&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=newBal style= width:60px>
		</TD></TR>

		
		
		<TR height=100 ><TD ALIGN=CENTER COLSPAN=3 valign=bottom>
			<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
		</TD></TR>
	</TABLE>
	</TD></TR>
</TABLE>	
</FORM>   

</BODY>
</HTML>