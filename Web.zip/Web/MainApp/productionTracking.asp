<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim employeeRole
	dim stationId
	dim dateBegin
	dim dateEnd
	
	employeeRole = request.form("employeerole")
	stationId = request.form("stationId")
	dateBegin = request.form("dateBegin")
	dateEnd = request.form("dateEnd")
	
	if dateBegin = "" then
		dateBegin = dateadd("d",(1-datepart("w",date())),date())
	end if
	
	sub clear_array(arr)
		dim i
		
		for i = lbound(arr) to ubound(arr)
			arr(i) = 0
		next
	
	end sub
	
	
	function getEmployeeName(employeeId)
		dim query, rs
		
		query = " select employeename from employee where employeeid = " & employeeid
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getEmployeeName = rs("employeename")
		end if
		
		set rs = nothing
	
	end function

	function floor(x)
		dim temp

		temp = Round(x)

		if temp > x then temp = temp - 1
	
		floor = temp
	End Function
	
	function formatDuration(duration)
		dim minutes
		dim seconds
		
		duration = cdbl(duration)
		
		minutes = floor(duration / 60)
		seconds = duration mod 60
		if len(seconds) < 2 then seconds = "0" & seconds
		
		formatDuration = minutes & ":" & seconds
	
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">
	function update() {
		document.productionTracking.action = "?useraction=update";
		document.productionTracking.submit();
	}

	function SetRowCheckedStatus(row, check, value) {
				
		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "chkEmployee") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked), false);
				break;
			}
			else if (childEl.name == "chkEmployee") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked), false);
				break;
			}
		}
	}

	function exit() {
		document.productionTracking.action = "/mainapp/managermenu.asp";
		document.productionTracking.submit();
		
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<H1>Production Tracking</H1>

<FORM name="productionTracking" ID="productionTracking" METHOD=POST  style="margin:0;padding:0"> 

<SELECT name="employeerole">
	<OPTION value="">All Employee Roles</OPTION>
<%
	query = " select id, name from employeetag "
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
%>
	<OPTION value="<%=rs("id")%>" <%if trim(employeeRole) = trim(rs("id")) then%>selected<%end if%>><%=server.htmlencode(rs("name"))%></OPTION>
<%
		rs.movenext
	wend
	set rs = nothing
%>
</SELECT>

<!--

Station
<SELECT name="stationId">
	<OPTION value="">All</OPTION>
<%
	query = " select stationid, name from station "
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
%>
	<OPTION value="<%=rs("stationid")%>" <%if trim(stationId) = trim(rs("stationid")) then%>selected<%end if%>><%=server.htmlencode(rs("name"))%></OPTION>
<%
		rs.movenext
	wend
	set rs = nothing
%>
</SELECT>

-->

From
<INPUT name="dateBegin" value="<%=dateBegin%>" readonly onclick="javascript:show_calendar('productionTracking.dateBegin');">
to
<INPUT name="dateEnd" value="<%=dateEnd%>" readonly onclick="javascript:show_calendar('productionTracking.dateEnd');">


<SELECT name="dataFormat">
	<OPTION value="pieces">Pieces (Time)</OPTION>
	<OPTION value="wage" <% if request.form("dataFormat") = "wage" then %>selected<% end if %>>Time (Wage)</OPTION>
</SELECT>
<BUTTON onclick="update()">Look Up</BUTTON>



<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">

	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>

<DIV style="height: 300px;overflow:scroll">
<TABLE class="itable" cellspacing="0" cellpadding="0">
	<TR>
		<TH>&nbsp;</TH>
		<TH>Employee Name</TH>
		<TH>Sunday</TH>
		<TH>Monday</TH>
		<TH>Tuesday</TH>
		<TH>Wednesday</TH>
		<TH>Thursday</TH>
		<TH>Friday</TH>
		<TH>Saturday</TH>
		<TH><STRONG>Total</STRONG></TH>
	</TR>
<%
	dim garments(7)
	dim durations(7)
	dim wage(7)
	dim total_garments(7)
	dim total_durations(7)
	dim total_wage(7)
	dim total
	dim i
	dim current_weekday
	dim current_employee
	dim e_done
	
	query = ""
	query = query & " select "
	query = query & " GarmentTracking.EmployeeID, "
	query = query & " datepart(dw, GarmentTracking.date) as WeekDay, "
	query = query & " Employee.employeeName, "
	query = query & " Employee.employeeId, "
	query = query & " COUNT(*) as GarmentCount, "
	query = query & " SUM(GarmentTracking.Duration) as TotalDuration, "
	query = query & " isnull(Employee.HourlyWage, 0) as HourlyWage "
	query = query & " from GarmentTracking "
	query = query & " inner join Employee on GarmentTracking.EmployeeID = Employee.employeeID "
	query = query & " where employee.storeid = " & session("storeid")
	
	if employeeRole <> "" then
		query = query & " and employee.employeeid in (select distinct employeeid  from employeetagassignment where employeetagassignment.tagid = " & employeeRole & ")"
	end if
	
	if stationId <> "" then
		query = query & " and GarmentTracking.StationID = " & stationId
	end if
	
	if dateBegin <> "" then
		query = query & " and DATEDIFF(day, GarmentTracking.Date, '" & dateBegin & "') <= 0 "
	end if
	
	if dateEnd <> "" then
		query = query & " and DATEDIFF(day, GarmentTracking.Date, '" & dateEnd & "') >= 0 "
	end if
	
	query = query & " group by GarmentTracking.EmployeeID, Employee.employeeId, Employee.employeeName, Employee.HourlyWage, datepart(dw, GarmentTracking.date) "
	query = query & " order by 1, 2 "
	

	
	set rs = getdisconnectedrecordset(query)
	
	clear_array total_garments
	clear_array total_durations
	clear_array total_wage
	
	while not(rs.eof or rs.bof)	
		clear_array garments
		clear_array durations
		clear_array wage
%>

	<TR onclick="ToggleRowChecked(this)">
		<TD><INPUT type="checkbox" onclick="ToggleRowChecked(this.parentNode.parentNode);" name="chkEmployee" value="<%=rs("employeeId")%>" /></TD>
		<TD><%=server.htmlencode(rs("employeename"))%></TD>
		<%
			e_done = false

			while not e_done
				current_weekday = rs("WeekDay")
				current_employee = rs("EmployeeId")
				
				garments(current_weekday) = clng(rs("garmentcount"))
				durations(current_weekday) = cdbl(rs("totalduration"))
				wage(current_weekday) = (cdbl(rs("totalduration")) / 60.0) * cdbl(rs("hourlywage"))
				
				total_garments(current_weekday) = total_garments(current_weekday) + clng(rs("garmentcount"))
				total_durations(current_weekday) = cdbl(total_durations(current_weekday)) + cdbl(rs("totalduration"))
				total_wage(current_weekday) = cdbl(total_wage(current_weekday)) + wage(current_weekday)
				
				total_garments(0) = total_garments(0) + clng(rs("garmentcount"))
				total_durations(0) = cdbl(total_durations(0)) + cdbl(rs("totalduration"))
				total_wage(0) = cdbl(total_wage(0)) + durations(current_weekday)
				
				garments(0) = garments(0) + clng(rs("garmentcount"))
				durations(0) = cdbl(durations(0)) + cdbl(rs("totalduration"))
				wage(0) = cdbl(wage(0)) + wage(current_weekday)
				
				rs.movenext
				
				if not(rs.eof or rs.bof) then
					e_done = rs("WeekDay") <= current_weekday or rs("EmployeeId") <> current_employee
				else
					e_done = true
				end if
			
			wend
		%>
		<%
			for i = 1 to 7
		%>
		
		<% if request.form("dataFormat") = "wage" then %>
		<% if garments(i) <> 0 then %>
		<TD><%=formatDuration(durations(i)/garments(i))%> (<%=formatcurrency(wage(i))%>)</TD>
		<% else %>
		<TD>-</TD>
		<% end if %>
		<% else %>
		<% if garments(i) <> 0 then %>
		<TD><%=garments(i)%> (<%=formatDuration(durations(i)/garments(i))%>)</TD>
		<% else %>
		<TD>-</TD>
		<% end if %>
		<% end if %>
		
		<%	
			next
		%>
		<% if request.form("dataFormat") = "wage" then %>
		<% if garments(0) <> 0 then %>
		<TD><STRONG><%=formatDuration(durations(0)/garments(0))%> (<%=formatcurrency(wage(0))%>)</STRONG></TD>
		<% else %>
		<TD>-</TD>
		<% end if %>
		<% else %>
		<% if garments(0) <> 0 then %>
		<TD><STRONG><%=garments(0)%> (<%=formatDuration(durations(0)/garments(0))%>)</STRONG></TD>
		<% else %>
		<TD>-</TD>
		<% end if %>
		<% end if %>
	</TR>

<%
		
	wend
	
	set rs = nothing
%>


	<TR>
		<TD colspan="2"><STRONG>Total</STRONG></TD>
		<%
			for i = 1 to 7
		%>
		<% if request.form("dataFormat") = "wage" then %>
		<% if total_garments(0) <> 0 then %>
		<TD><STRONG><%=formatDuration(total_durations(i)/total_garments(i))%> (<%=formatcurrency(total_wage(i))%>)</STRONG></TD>
		<% else %>
		<TD>-</TD>
		<% end if %>
		<% else %>
		<% if total_garments(i) <> 0 then %>
		<TD><STRONG><%=total_garments(i)%> (<%=formatDuration(total_durations(i)/total_garments(i))%>)</STRONG></TD>
		<% else %>
		<TD>-</TD>
		<% end if %>
		<% end if %>
		<%	
			next
		
		%>
		<% if request.form("dataFormat") = "wage" then %>
		<% if total_garments(0) <> 0 then %>
		<TD><STRONG><%=formatDuration(total_durations(0)/total_garments(0))%> (<%=formatcurrency(total_wage(0))%>)</STRONG></TD>
		<% else %>
		<TD>-</TD>
		<% end if %>
		<% else %>
		<% if total_garments(0) <> 0 then %>
		<TD><STRONG><%=total_garments(0)%> (<%=formatDuration(total_durations(0)/total_garments(0))%>)</STRONG></TD>
		<% else %>
		<TD>-</TD>
		<% end if %>
		<% end if %>
	</TR>

</TABLE>

</DIV>

<DIV style="height: 330px;overflow:scroll">

<TABLE class="itable" cellspacing="0" cellpadding="0">
	<TH>Department</TH>
	<TH>Item Name</TH>
	<TH>Count (Average Duration)</TH>

<%
	dim employeeId
	for each employeeId in request.form("chkEmployee")
%>
	<TH><%=getEmployeeName(employeeId)%></TH>
<%
	next
%>


<%
	
	query = ""
	query = query & " select "
	query = query & " PriceListItem.priceListItemId, "
	query = query & " Department.name as [DeptName], "
	query = query & " PriceListItem.itemName as [ItemName], "
	query = query & " COUNT(*) as [Count], "
	query = query & " AVG(garmenttracking.duration) as [AvgDuration], "
	query = query & " isnull(Employee.HourlyWage, 0) as HourlyWage "
	query = query & " from "
	query = query & " GarmentTracking inner join HeatSealItem on GarmentTracking.HeatSealID = HeatSealItem.HeatSealID "
	query = query & " inner join PriceListItem on HeatSealItem.PriceListItemID = PriceListItem.priceListItemID "
	query = query & " inner join Department on PriceListItem.departmentID = Department.departmentID "
	query = query & " inner join Employee on GarmentTracking.employeeID = Employee.employeeID "
	query = query & " where employee.storeid = " & session("storeid")
	
	if employeeRole <> "" then
		query = query & " and employee.employeeid in (select distinct employeeid  from employeetagassignment where employeetagassignment.tagid = " & employeeRole & ")"
	end if
	
	if stationId <> "" then
		query = query & " and GarmentTracking.StationID = " & stationId
	end if

	if dateBegin <> "" then
		query = query & " and DATEDIFF(day, GarmentTracking.Date, '" & dateBegin & "') <= 0 "
	end if

	if dateEnd <> "" then
		query = query & " and DATEDIFF(day, GarmentTracking.Date, '" & dateEnd & "') >= 0 "
	end if
	
	
	query = query & " group by "
	query = query & " PriceListItem.priceListItemID, "
	query = query & " PriceListItem.itemName, "
	query = query & " Department.name, "
	query = query & " Employee.HourlyWage "
	query = query & " order by 2, 1 "
	
	set rs = getdisconnectedrecordset(query)
	
	
	query = ""
	query = query & " select "
	query = query & " PriceListItem.priceListItemId, "
	query = query & " GarmentTracking.employeeId, "
	query = query & " COUNT(*) as [Count], "
	query = query & " AVG(garmenttracking.duration) as [AvgDuration], "
	query = query & " isnull(Employee.HourlyWage, 0) as HourlyWage "
	query = query & " from "
	query = query & " GarmentTracking inner join HeatSealItem on GarmentTracking.HeatSealID = HeatSealItem.HeatSealID "
	query = query & " inner join PriceListItem on HeatSealItem.PriceListItemID = PriceListItem.priceListItemID "
	query = query & " inner join Department on PriceListItem.departmentID = Department.departmentID "
	query = query & " inner join Employee on GarmentTracking.employeeID = Employee.employeeID "
	query = query & " where employee.storeid = " & session("storeid")
	
	if employeeRole <> "" then
		query = query & " and employee.employeeid in (select distinct employeeid  from employeetagassignment where employeetagassignment.tagid = " & employeeRole & ")"
	end if
	
	if stationId <> "" then
		query = query & " and GarmentTracking.StationID = " & stationId
	end if

	if dateBegin <> "" then
		query = query & " and DATEDIFF(day, GarmentTracking.Date, '" & dateBegin & "') <= 0 "
	end if

	if dateEnd <> "" then
		query = query & " and DATEDIFF(day, GarmentTracking.Date, '" & dateEnd & "') >= 0 "
	end if
	
	query = query & " group by "
	query = query & " PriceListItem.priceListItemID, "
	query = query & " GarmentTracking.employeeId, "
	query = query & " Employee.HourlyWage "
	
	dim crs
	set crs = getdisconnectedrecordset(query)
	
	
	while not(rs.eof or rs.bof)
%>
  <TR>
  	<TD><%=server.htmlencode(rs("DeptName"))%></TD>
    <TD><%=server.htmlencode(rs("ItemName"))%></TD>
  	<TD><%=server.htmlencode(rs("Count"))%> (<%=formatDuration(rs("AvgDuration"))%>)</TD>
<%
	for each employeeId in request.form("chkEmployee")
		crs.filter = "priceListItemId = " & rs("priceListItemId") & " and employeeid = " & employeeId
		
		if crs.recordcount > 0 then
		crs.movefirst
%>
		<TD <%if cdbl(crs("AvgDuration")) > cdbl(rs("AvgDuration")) then%>style="color: red"<%else%>style="color: green"<%end if%>>
			<% if request.form("dataFormat") = "wage" then %>
			<STRONG><%=formatDuration(crs("AvgDuration"))%> (<%=formatcurrency(cdbl(crs("AvgDuration")) * cdbl(crs("hourlywage")))%>)</STRONG>
			<% else %>
			<STRONG><%=server.htmlencode(crs("Count"))%> (<%=formatDuration(crs("AvgDuration"))%>)</STRONG>
			<% end if %>
		</TD>
<%
		else
%>
	<TD>&nbsp;</TD>
<%
		end if
	next
%>
  	
  </TR>


<%
		rs.movenext
	wend
	
	set rs = nothing

%>

</TABLE>
</DIV>

</FORM>
</BODY>
</HTML>
