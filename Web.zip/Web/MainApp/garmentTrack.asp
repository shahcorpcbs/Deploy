<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/EmployeeSecurity.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<% 
	dim query, rs
	dim invoicenumber
	dim ticketnumber
	
	ticketnumber = request.querystring("ticketnumber")
	invoicenumber = getInvoiceNumberFromTicket(ticketnumber)

	function getInvoiceNumberFromTicket(ticketNumber)
		dim query, rs

		if ticketNumber <> "" then
			query = " select invoicenumber from ticket where ticketnumber = " & ticketNumber
			set rs = getdisconnectedrecordset(query)
	
			if rs.recordcount > 0 then
				getInvoiceNumberFromTicket = rs("invoicenumber")
			end if
	
			set rs = nothing
		end if
	end function
	
	function getTicketNumber(invoiceNumber)
		dim query, rs
		
		query = " select ticketnumber from ticket where invoicenumber = '" & dbstr(invoiceNumber) & "'"
		set rs = getdisconnectedrecordset(query)
		
		getTicketNumber = 0
		
		if rs.recordcount > 0 then
			getTicketNumber = rs("ticketnumber")
		end if
		
		set rs = nothing
	end function
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Track Invoice</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
	function exit() {
		document.trackInv.action = "/mainapp/customerfunctions.asp";
		document.trackInv.submit();
	}
</script>


</HEAD>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Track Invoice <%=invoicenumber%></B>

<FORM name="trackInv" ID="trackInv" METHOD=POST  style="margin:0;padding:0">
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH>Date</TH>
		<TH>Employee</TH>
		<TH>Description</TH>
		<TH>Invoice Total</TH>
		<TH>Amount Paid</TH>
	</TR>
	<%
		query = " select ticketevent.date,ticketevent.description, isnull(employee.employeename, '') as employeename, isnull(invoicetotal, 0) as invoicetotal, isnull(amountpaid, 0) as amountpaid from ticketevent "
		query = query & " left outer join employee on ticketevent.employeeid = employee.employeeid "
		query = query & " where ticketevent.ticketnumber = " & ticketnumber
		query = query & " order by [date] "
		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
	%>
	<TR>
		<TD><%=Server.HTMLEncode(rs("date"))%></TD>
		<TD><%=Server.HTMLEncode(rs("employeename"))%></TD>
		<TD><%=Server.HTMLEncode(rs("description"))%></TD>
		<TD><%=formatcurrency(rs("invoicetotal"))%></TD>
		<TD><%=formatcurrency(rs("amountpaid"))%></TD>
	</TR>
	<%
			rs.movenext
		wend
		set rs = nothing
	%>
</TABLE>

</FORM>
</BODY>
</HTML>
