<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim isSubmitted 
	dim rsPriceTable
	dim rsdepartment
	dim rscolor
	dim rsPattern
	dim rsUpcharge
	dim rstSearch
	
	isSubmitted = Request.QueryString("submitted")
	if (isSubmitted ) then
		session("pricelist") = Request.Form("priceTable")
		session("ticketStatus") = Request.Form("ticketStatus")
		if len(trim(session("pricelist"))) > 0 then 
			Response.Redirect("garmentsearch.asp?useraction=create")
		end if 
	end if
	
	dim l_pricelistId
	dim l_departmentid
	
	getPriceList()
	
	l_pricelistId = 0
	
	
	
%>
<HTML>
<HEAD>
<TITLE>Garment Search Results</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	var previousElement=null;
	
	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.style.background="white";
		}
		childEl = element.children[0];
		var rowChildNodes = childEl.children
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if(childEl.tagName == "INPUT") {
				childEl.checked=true;
				break;
			}
		}
		previousElement =element;
		element.style.background="#DBF2F4";
		 
	}
	
	function submitForm(useraction){
		document.garmentSearchForm.action = "?submitted=true"
		document.garmentSearchForm.submit()
	
	}
	
	function cancelForm(){
		document.garmentSearchForm.action = "toolsMenu.asp"
		document.garmentSearchForm.submit()
	
	}
		
</SCRIPT>

<BODY topmargin=0 leftmargin=0  >
<!-- #include file="../include/banner.inc" -->
<H1>Garment Search </H1>
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLPADDING=1 >
		<FORM id="garmentSearchForm" name="garmentSearchForm" action="" method = "post">
		<tr>
		<td>
			<table ALIGN=center width = 100%  BORDER=0 CELLSPACING=1 CELLPADDING=5>
			<tr  height= 80px>
			<td width = 200px ></td>
			</tr>
				<tr>
					<td></td>
					<td class="label" width=80px>Price Table</td>
					<TD>
						<SELECT name="priceTable" STYLE="FONT-SIZE: 14px;width = 200px"  >
						<%
							if isobject(rspricetable) then
								if rspricetable.recordcount > 0 then
								while not rspricetable.BOF and not rspricetable.EOF
						%>	
							<OPTION 
								<% if trim(rspricetable("PriceListId")) = trim(Request.form("priceTable")) then %>
										selected
								<%	l_pricelistId = trim(rspricetable("PriceListId"))
								elseif  clng(l_pricelistId = 0 )then
									l_pricelistId = trim(rspricetable("PriceListId"))
								%>	
									selected
								<%	end if
								%>
								VALUE= "<%=rspricetable("PriceListId") %>"><%=rspricetable("Name") %>
							</option>
						<%
								rspricetable.MoveNext
								wend
								end if
								rspricetable.close
								set rspricetable = nothing
							end if
						%>
					</SELECT>

					</TD>
					</tr>

				<tr>
					<td></td>
					<td class="label" width=80px>Invoice Status</td>
					<TD>

					<SELECT name="ticketStatus">
					  <OPTION value="ac,od">Active Invoices</OPTION>
					  <OPTION value="fi">Inactive Invoices</OPTION>
					  <OPTION value="ac,od,fi">All Invoices</OPTION>
					</SELECT>
					
					</TD>
					</tr>
					
					<tr height = 40px><td></td>
					</tr>
					<tr><td></td><td></td>
					<td>
							<table border = 0>	
							<tr>			
							<td align=center>
								<INPUT class=touchnoborder id=done name=done type=button value="" style="background-image:url(../images/ok.gif);" onClick="submitForm();">	
							</td>
							<td width= 20px></td>												
							<td align= right>
								<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm();">	
							</td>
							</tr>
							</table>
					</td>						
					</tr>
							
			</table>
			
			</td>
			<tr>
		</form>
	</table>
</BODY>
</HTML>

<%
	function  getpriceList()
	dim sqltxt
		sqltxt = "Select pricelistid, name from Pricelist where storeid = " & session("storeid")
		set rspricetable = getDisconnectedRecordset(sqltxt)
	end function
%>