<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim storeId
	dim custSeqNumber
	dim paymenttermid
	dim custPaymentObj
	dim acctBalance
	dim creditLimit
	dim amountpaid
	dim targetPage
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim prepayAmt, isPrePay
	dim forceSigAllTimes, forceSigNoClaims, claimsCount
	dim invPrePayPercent, invoicesTotal
	dim originatingPage
	
	storeId = Session("storeID")	
	custSeqNumber = Session("customersequencenumber")
	paymenttermid =""
	acctBalance =""
	creditLimit =""
	amountpaid = Request.QueryString("amountPaid")
	isPrePay =  Request.Form("isPrePay")
	prepayAmt = Request.Form("prepayAmt")
	forceSigAllTimes = Request.Form("forceSigAllTimes")
	forceSigNoClaims = Request.Form("forceSigNoClaims")
	claimsCount = Request.Form("claimsCount")
	invPrePayPercent = Request.Form("invPrepayPercent")
	invoicesTotal = Request.Form("invoicesTotal")
	if isPrePay ="1" then
		collectInvoiceDataFromForm
	end if
	sub collectInvoiceDataFromForm()
		targetPage = Request.Form("tPage")
		addOrEdit = Request.Form("addOrEdit")
		curr_LineNo = Request.Form("lineNumber")
		selectedDept = Request.Form("selectedDept")
		itemsStartIndex = Request.Form("ItemPageCount")
		upChargeStartIndex = Request.Form("upChargePageCount")
		colorsStartIndex = Request.Form("colorsPageCount")
		patternStartIndex = Request.Form("PatternPageCount")
		deptStartIndex = Request.Form("DeptPageCount")
		selItemId = Request.Form("selItemId")
		selUpchargeValue = Request.Form("selUpcharge")
		selColorValue = Request.Form("selColor")
		selPatternValue = Request.Form("selPattern")
		originatingPage = Request.Form("originPage")
	end sub
	
			
	function getPaymentTerms()
		dim ssql
		dim rsPaymentTerm
		ssql = "select PaymentTermsID, PaymentName from PaymentTermsDomain where storeid =" & storeId
		set rsPaymentTerm= getDisconnectedRecordset(ssql)
		set getPaymentTerms = rsPaymentTerm
	end function
	
	
	
%>
<HTML>
<HEAD>
<TITLE>Customer Account</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		var valid;
		
		valid = validateFields();
		if (valid == true) {
			document.customerAccount.action = "pickup.asp?userAction=addTempAccount";
			document.customerAccount.submit();
		}
	}
	
	function validateFields() {
		var valid;
		var acctBalance;
		var creditLimit;
		
		valid = true;
		creditLimit =document.customerAccount.txtCreditLimit.value;
		creditLimit = trim(creditLimit);
		if (creditLimit.length > 0) {
			creditLimit = cleanNumeric(creditLimit);
			if(creditLimit == "")	{
				show_focus("Enter valid Credit Limit.", "Credit Limit", document.customerAccount.txtCreditLimit);
				valid = false;
			}
		}else{
			document.customerAccount.txtCreditLimit.value =0;
		}
		return valid;
	}
	
	function decimalFormat() {
		var price;
		
		price = document.customerAccount.txtCreditLimit.value;
		price = trim(price);
		if(price.length > 0) {
			price = cleanNumeric(price);
			if(price == "")	{
				show_focus("Enter valid amount.", "Credit Limit", document.customerAccount.txtCreditLimit);
				return;
			}
		}
		document.customerAccount.txtCreditLimit.value = autoFormatCurrency(document.customerAccount.txtCreditLimit.value);
	}
	
</script>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Account Information</H1>
<FORM id="customerAccount" name="customerAccount" action="accountInfo.asp" method="post">
	<INPUT type="hidden" name="amount" value="<%= amountpaid%>">
	<INPUT type="hidden" name="isPrePay" value="<%= isPrePay%>">
	<INPUT type="hidden" name="prepayAmt" value="<%= prepayAmt%>">
	<INPUT type="hidden" name="forceSigAllTimes" value="<%= forceSigAllTimes%>">
	<INPUT type="hidden" name="forceSigNoClaims" value="<%= forceSigNoClaims%>">
	<INPUT type="hidden" name="claimsCount" value="<%= claimsCount%>">
	<INPUT type="hidden" name="invPrepayPercent" value="<%= invPrePayPercent %>">
	<INPUT type="hidden" name="invoicesTotal" value="<%= invoicesTotal %>">
	<!-- invoice hidden values-->
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	<TABLE ALIGN=center WIDTH="500px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=20px><td></td></tr>
		<tr>
			<TD align="center" class="label" align="center">Payment Terms
			</TD>
			<TD align=left>
				<SELECT name=paymentTerms STYLE="font-size:14px;">
					<%
						dim rsPaymentTerm
						set rsPaymentTerm = getPaymentTerms
						while not rsPaymentTerm.EOF
					%>	
							<OPTION VALUE= "<%=rsPaymentTerm("PaymentTermsID")%>"><%= rsPaymentTerm("PaymentName") %>
					<%
							rsPaymentTerm.MoveNext
						wend
					%>
				</SELECT>
			</TD>
		</TR>
		
		<!-- Account Balance -->
		<!--<TR>
			<TD class="label" align="center">Account Balance</TD>
			<TD align=left>
				<INPUT id=txtAccountBalance name=txtAccountBalance class=text style="HEIGHT: 25px; WIDTH: 254px" value="<%=acctBalance%>">
			</TD> 
		</TR>-->	
		
		<!-- Credit Limit -->
		<TR>
			<TD class="label" align="center">Credit Limit</TD>
			<TD align=left>
				<INPUT id=txtCreditLimit name=txtCreditLimit class=text style="HEIGHT: 25px; WIDTH: 100px" value="<%=creditLimit%>" onKeyup="decimalFormat();">
			</TD>
		</TR>
		
		<!-- buttons -->
		<TR>
			<TD></TD>
			<TD align=center>
				<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align="center" width=60px>
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick= "submitForm()">
						</td>
						<td align="center" width=60px>
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="history.back(-1)">
						</td>
						<td width=150px></td>
					</tr>
			</TD>
		</TR>     
	</table>
</BODY>
</HTML>

