<!--#include file="../include/SystemStartup.asp"-->
<%
	dim version : version = "14.4.2"
	dim dbname : dbname = request.querystring("dbname")
	if dbname = "" then dbname = "default"
	dim bannertext : bannertext = request.querystring("bannertext")
	selectDatabase dbname
	dim connectToService : connectToService = 1

%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!-- #include file="../include/systemsetting.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->

<%		
	dim query, rs, dbSpaceLow
	dim storeid
	dim terminalid
	dim terminalname
	dim expresslinkpath
	dim unreadMessages
	
	dim expresslinkpurchase : expresslinkpurchase = replace(systemsetting("XCHARGE-PURCHASE"), vbcrlf, "")
	dim expresslinkvaultpurchase : expresslinkvaultpurchase = replace(systemsetting("XCHARGE-VPURCHASE"), vbcrlf, "")
	dim expresslinkadd : expresslinkadd = replace(systemsetting("XCHARGE-VADD"), vbcrlf, "")
	dim expresslinkupdate : expresslinkupdate = replace(systemsetting("XCHARGE-VUPDATE"), vbcrlf, "")
	dim expresslinkdelete : expresslinkdelete = replace(systemsetting("XCHARGE-VDELETE"), vbcrlf, "")
	dim expresslinkauth : expresslinkauth = "/USERID:" & replace(systemsetting("XCHARGE-USERNAME"), vbcrlf, "") & " /PASSWORD:" & replace(systemsetting("XCHARGE-PASSWORD"), vbcrlf, "") & " "
	dim expresslinkopt : expresslinkopt = ""
	
	storeid = Request.Cookies("storeID")
	terminalid = Request.Cookies("terminalID")
	
	if lcase(systemsetting("XCHARGE-FILLZIP")) = "yes" then
		expresslinkopt = "/ZIP:@@@ZIP "
	end if
	
	expresslinkpurchase = replace(expresslinkpurchase, "@@@AUTH", expresslinkauth)
	expresslinkvaultpurchase = replace(replace(expresslinkvaultpurchase, "@@@AUTH", expresslinkauth), chr(13), "")
	expresslinkadd = replace(expresslinkadd, "@@@AUTH", expresslinkauth)
	expresslinkupdate = replace(expresslinkupdate, "@@@AUTH", expresslinkauth)
	expresslinkdelete = replace(expresslinkdelete, "@@@AUTH", expresslinkauth)
	
	expresslinkpurchase = replace(expresslinkpurchase, "@@@OPT", expresslinkopt)
	expresslinkvaultpurchase = replace(expresslinkvaultpurchase, "@@@OPT", expresslinkopt)
	expresslinkadd = replace(expresslinkadd, "@@@OPT", expresslinkopt)
	expresslinkupdate = replace(expresslinkupdate, "@@@OPT", expresslinkopt)
	expresslinkdelete = replace(expresslinkdelete, "@@@OPT", expresslinkopt)
	
	if storeid = "" then
        Response.Redirect "/MainApp/GetStoreTerminal.asp"
    end if

	if terminalid <> "" then
		query = " select name, description, expresslinkpath from terminal where terminalid = " & terminalid
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			terminalname = rs("name")
			expresslinkpath = Replace(rs("expresslinkpath"), "\", "\\")
		end if
	end if

        dim useSms, useEmail, commonIP, printerIP
        useSms = getMSVar("useTwilio")
        useEmail = getMSVar("useEmail")

        commonIP = getCommonShortPath()
        printerIP = getPrinterShortPath()

        dim userIPAddress, guiServicePort
        userIPAddress = getLocalPrinterAddress(session("terminalid"))
        guiServicePort = getGUIServicePort()

        'checkDBSpace

        function checkDBSpace
            dbSpaceLow = 0
            query = "SELECT (size/128.0 - CAST(FILEPROPERTY(name, 'SpaceUsed') AS INT)/128.0) / (size/128.0) * 100 AS FreeSpacePer " _
                & "	FROM sys.database_files where DB_NAME() = 'shahcorp' and type IN (0)"
           set rs = getdisconnectedrecordset(query)
           if rs.recordcount > 0 then
                if cint(rs("FreeSpacePer")) < 5 then
                    dbSpaceLow = 1
                end if
           end if
        end function


	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & storeid
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

%>
<!DOCTYPE html PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html>
	<head>
		<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
		<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-STORE">
		<META HTTP-EQUIV="EXPIRES" CONTENT="0">
		<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">

		<title>Cleaner Business Systems</title>
        <link rel="shortcut icon" href="#"/>

		<link rel="stylesheet" type="text/css" href="/style/banner.css" />
        <link rel="stylesheet" href="/style/overlay.css" type="text/css">
		<script type="text/javascript" src="../External/jquery.js"></script>
		<script type="text/javascript" src="../Script/webui.js"></script>
		<!--[if !IE]>-->
		<script type="text/javascript" src="../Script/nonIEMethods.js"></script>
        <!--<![endif]-->
		<style type="text/css">
			body {
				overflow: hidden;
			}
		</style>
		
		<script type="text/javascript">
			var terminalID = '';
			var employeeID = '';
			var storeStatsTimer = null;
			var loginCallback = null;
			var loginRC = true;
			var pending_transactions = {};
			<% if getMSVar("playSmsSound") then %>
			var audio = new Audio("../External/newSmsSound.mp3");
			var lastSmsCnt = -1;
			<% end if %>
			var testing = false;

			function setEmployeeID(id) {
				employeeID = id;
			}
			
			function setTerminalID(id) {
				terminalID = id;
				
				if(storeStatsTimer == null) {
					StoreStatsPulse();	
				}
			}
			
			function get_page() {
				var result = unescape(frames['content_frame'].location.href);

				if(result.indexOf('?') !== -1)
					result = result.substring(0, result.indexOf('?'));
					
				result = result.substr(result.lastIndexOf('/') + 1);

				return result.toLowerCase();
			}



			function LoginKeyDown() {
				if(event.keyCode == 13) {
					AttemptLogin();
				} else {
					$("#login_prompt").html("");
				}
			}
			
			function SelectDatabase(dbname) {
				location.href = "/mainapp/start.asp?dbname=" + encodeURIComponent(dbname);
			}

			function exit() {
				page = get_page();

				if(page == "start3.asp" || page == "getstoreterminal.asp") {
					//window.close();
				}
				else {
					document.all.content_frame.src = "start2.asp";
					$("#home").css("background", "url('/static/images/banner_home.png')");
				}	
			}

			function OnLoadStart() {
				$("#home").css("background", "url('/static/images/banner_home.png')");

				UpdateStoreStats()
				<% if dbSpaceLow = 1 then %>
                    document.getElementById("ooWarningMsg").innerHTML = "Warning: Your Database Space is Running Low. <br> Please Contact Shah Support.";
                    document.getElementById('okOnlyWarning').style.display = 'block';
				<% end if %>
			}
			
			function Logout() {
				$("#employeeStats").html("");	
				$("#employeeStats").toggleClass("logged-in", false);
			}
			

			function Login(callback, rc) {
				if(rc === undefined)
					rc = 1;
				else
					rc = (rc ? 1 : 0);
					
			
				loginRC = rc;
				loginCallback = callback;
				
				$("#content-overlay").show();
				$("#login_window").show();
				$("#login_password").val("");	
				$("#login_password").focus();	
				$("#login_prompt").html("");
			}
			
			function ConfirmLogin() {
				CancelLogin();
				if(loginCallback) {
					$("#home").css("background", "url('/static/images/banner_home.png')");
					loginCallback(0);
				}
			}
			
			function AttemptLogin() {
				var password = $("#login_password").val();
				jQuery.getJSON("/mainapp/loginEmployeeAction.asp?rc=" + loginRC + "&dbname=<%=dbname%>&password=" + encodeURIComponent(password), function(rs) {
					if(rs.employee.employee_id != "") {
						var content = "<strong style=\"font-size:18\">" + rs.employee.employee_name + "</strong>";
						if(rs.employee.unread_messages == 1) {
							content += "<br>1 message to read.";
						}
						else if(rs.employee.unread_messages > 0) {
							content += "<br>" + rs.employee.unread_messages + " messages to read.";
						}
						
						$("#employeeStats").html(content);
						$("#employeeStats").toggleClass("logged-in", true);
					
						ConfirmLogin();
					} else {
						$("#login_prompt").html(rs.employee.error);
						$("#login_password").val("");
						$("#login_password").focus();		
					}
				});
			}
			
			function CancelLogin() {
				$("#content-overlay").hide();
				$("#login_window").hide();
			}
			
			
			function StoreStatsPulse() {
				UpdateStoreStats();
				
				if(storeStatsTimer != null) {
					clearTimeout(storeStatsTimer);
				}
                <% if connectToService = 1 then %>
				checkIfServerServiceAvail();
				checkIfLocalAvail();
				checkIfGUIAvail();
				<% end if %>

				storeStatsTimer = setTimeout("StoreStatsPulse()", 180000);
			}
			
			
			function UpdateStoreStats() {
				jQuery.getJSON("/mainapp/getTerminalInfo.asp?dbname=<%=dbname%>&terminalID=" + terminalID, function(rs) {
					var content = "<ul>";

					<% if dbname = "default" then %>
					content += "<li><strong style=\"font-size:18\">" + rs.store.store_name + "</strong></li>";
					<% else %>
					content += "<li><strong style=\"font-size:18\"><%=dbname%></strong></li>";
					<% end if %>
					content += "<li><span onclick=\"loadIframe('sa', '../MainApp/Startpage/Custom.asp?formid=1')\">" + rs.store.pcs_past_due + " pieces not finished.</span>";
					if (rs.store.unreadMessages > 0) {
					    content += "<span class=\"badge\" onclick='checkSmsMessages()'>" + rs.store.unreadMessages + "</span>";
					    <% if getMSVar("playSmsSound") then %>
					    if (lastSmsCnt != -1 && lastSmsCnt != rs.store.unreadMessages)
					        audio.play();
					    <% end if %>
					}
					<% if getMSVar("playSmsSound") then %>
					lastSmsCnt = rs.store.unreadMessages;
					<% end if %>
					content += "</li></ul>";
					$("#storeStats").html(content);
				});
			}

            function loadIframe(iframeName, url)
            {
                if (window.frames['content_frame'].frames[iframeName])
                    window.frames['content_frame'].frames[iframeName].location = url;
            }


			function checkSmsMessages() {
                Login(function(eid) {
                    frames["content_frame"].location.href = "/mainapp/smsHistory.asp";
                    UpdateStoreStats();
                });
			}

			function ajaxError(XMLHttpRequest, textStatus, errorThrown) {

			}

			function PrintForm(formType, keyType, key, args) {
				var options = { terminalID: terminalID,	employeeID: employeeID,	type: formType };
				if(keyType === "ticketnumber") {
					options = jQuery.extend(options, {ticketnumber: key}, args);
				}
				else if(keyType === "invoicenumber") {
					options = jQuery.extend(options, {invoicenumber: key}, args);
				}
				else if(keyType === "customerseq") {
					options = jQuery.extend(options, {customerSeq: key}, args);
				}
				else if(keyType === "hsn") {
					options = jQuery.extend(options, {hsn: key}, args);
				}
				else if(keyType === "transactionid") {
					options = jQuery.extend(options, {transactionId: key}, args);
				}
				else if(keyType === "voidpaymentid") {
					options = jQuery.extend(options, {voidpaymentId: key}, args);
				}

				if (args === 'electronic') {
				    jQuery.getJSON("/mainapp/getPrintingParams.asp?electronic=1&dbname=<%=dbname%>", options, printJobs);
				}
				else {
				    jQuery.getJSON("/mainapp/getPrintingParams.asp?dbname=<%=dbname%>", options, printJobs);
				}
			}

			function printJobs(pj) {
				var i, j;
				var job;

				for(i = 0; i < pj.jobs.length; i++) {
					job = pj.jobs[i];

					if (testing) {
                        console.log("inside print jobs");
                        console.log(job)
					}
					for (var n = 0; n < job.copies; n++) {
                        if (job.smsPrompt === "1" || job.prompt) {
                            var msg;
                            if (job.smsPrompt === "1")
                                msg = "Receipt sent electronically to customer. Print " + job.description + " as well?";
                            else {
                                if (job.copies > 1)
                                    msg =  "Print " + job.description + " (Copy " + (n + 1) + ")?";
                                else
                                    msg =  "Print " + job.description + "?";
                            }
                            var title = "Printing"
                            printJobNonIE(job, msg, title);
                        }
                        else {
                            nonIEStartJob(job);
                        }
					}
				}
			}


			function showSearchResults(text) {
				page = get_page();
				
				if(page == "getstoreterminal.asp") {
					cbs_alert("Must select a terminal before searching.");
				}
				else if(page == "start3.asp" || page == "login.asp") {
					Login(function(eid) {
						frames["content_frame"].location.href = "/mainapp/customersearch.asp?targetpage=CustomerFunctions&smartsearch=" + encodeURIComponent(text);
					});
				}
				else {
					frames['content_frame'].location.href = "/mainapp/customersearch.asp?targetpage=CustomerFunctions&smartsearch=" + encodeURIComponent(text);
				}
			}
			
			function beginSearch() {
				if (event.keyCode == 13){
				    hideSearch();
					showSearchResults(this.value);
				}
			}

			function hideSearch() {
				$('#banner-search-string').unbind('blur', hideSearch);
				$('#banner-search-string').unbind('keyup', beginSearch);
				$('#banner-search-box').hide('fast');
			}
			
			function showSearch() {
				CancelLogin();
				$('#banner-search-string').val('');
				$('#banner-search-box').show('fast', function() {
					$('#banner-search-string').focus();
					$('#banner-search-string').bind('blur', hideSearch);
					$('#banner-search-string').bind('keyup', beginSearch);
				});
			}

			$(document).ready(function() {
				jQuery.ajaxSetup({cache: false, error: ajaxError});
				$("#content-overlay").css("opacity", "0.9");
			});

			function showMessages() {
				if(employeeID != "") {
					var w = window.open("/mainapp/messaging/viewport.asp?employeeID=" + employeeID, "Messaging", "status=no,fullscreen=no,scrollbars=no,width=600,height=600");
				}
			}

			function BeginExpressLinkTransaction(transaction_type, params) {
				var transaction_id;
				var valueMap = "";
				var baseRequest;

				switch(transaction_type) {
				case "purchase":
					if(params.xc_account_id != '') {
                        baseRequest = "<%= expresslinkvaultpurchase %>"
                        valueMap = '"@@@XCACCOUNTID":"' + params.xc_account_id + '", "@@@EXP":"' +  params.expiration + '", '
					}
					else {
						baseRequest = "<%= expresslinkpurchase %>";
					}
					valueMap = valueMap + '"@@@RECEIPT":"' + (params.receipt ? params.receipt : "") + '", "@@@AMOUNT":"'
					    + params.amount + '", "@@@CLERK":"' + params.clerk + '", "@@@ZIP":"' + params.zip + '"';
					break;
				case "add-card":
				    baseRequest = "<%= expresslinkadd %>";
					break;
				case "update-card":
				    baseRequest = "<%= expresslinkupdate %>";
				    valueMap = '"@@@XCACCOUNTID":"' + params.xc_account_id + '"'
					break;
				case "delete-card":
				    baseRequest = "<%= expresslinkdelete %>";
				    valueMap = '"@@@XCACCOUNTID":"' + params.xc_account_id + '"'
					break;
				}

				valueMap = "{" + valueMap + "}";
                if (testing) {
                    console.log("baseRequest = " + baseRequest);
                    console.log("valueMap = " + valueMap);
                    console.log("<%= expresslinkpath %>")
				}

				transaction_id = generateUUID();
                var url = "http://<%=userIPAddress%>:<%= guiServicePort %>/rest/xcharge/performRequest?msgString=" + encodeURIComponent(baseRequest)
                    + "&uuid=" + encodeURIComponent(transaction_id) + "&xchargeLoc=" + encodeURIComponent("<%= expresslinkpath %>");
                if (testing) {
                    console.log("trans_id = " + transaction_id);
                    console.log(url);
                }

			params.transaction_id = transaction_id;
			params.transaction_type = transaction_type;
			pending_transactions[transaction_id] = params;

            $.ajax({
                type: "POST",
                url: url,
                data :valueMap,
                timeout: "120000",
                contentType: "application/json; charset=utf-8",
                success: function(xhr) {
                    try {
                        if (testing) {
                            console.log("Got return " + xhr);
                        }
                        ExpressLink_Answer(transaction_id, xhr)
                    }
                    catch (e) {
                        if (testing) {
                            console.log(e);
                            console.log(xhr);
                        }
                        cbs_alert("ERROR handling response" + e.message);
                    }
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    //console.log(xhr);
                    if (xhr.readyState == 4) {
                        cbs_alert("Error connecting to xcharge service: " + xhr.statusText);
                    }
                    else
                        cbs_alert("Error running xcharge transaction: " + xhr.body);
                    if (testing) {
                        console.log(xhr);
                        console.log(ajaxOptions);
                        console.log(thrownError);
                    }
                    ExpressLink_Answer(transaction_id, null)
                }
            });


				
				return transaction_id;
			}

            function generateUUID() { // Public Domain/MIT
                var d = new Date().getTime();//Timestamp
                var d2 = ((typeof performance !== 'undefined') && performance.now && (performance.now()*1000)) || 0;//Time in microseconds since page-load or 0 if unsupported
                return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                    var r = Math.random() * 16;//random number between 0 and 16
                    if(d > 0){//Use timestamp until depleted
                        r = (d + r)%16 | 0;
                        d = Math.floor(d/16);
                    } else {//Use microseconds since page-load if supported
                        r = (d2 + r)%16 | 0;
                        d2 = Math.floor(d2/16);
                    }
                    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(32);
                });
            }
			
			
			function ExpressLink_Answer(requestid, result) {
				var params = pending_transactions[requestid];

				jQuery.getJSON("/script/ccp-expresslink.asp",
					{
						transaction_type: params.transaction_type,
						transaction_id: params.transaction_id,
						answer: result	
					},
					function(result_obj) {
						try {
							if(result_obj.success == "1") {
								if(params.success) params.success(result_obj, params, result);
							}
							else {
								if(params.failure) params.failure(result_obj, params, result);
							}
						}
						catch(err) {
							alert("Credit card transaction failed to complete!");
						}
						
						delete pending_transactions[requestid];
					}
				);
			}

    function checkIfServerServiceAvail() {
        var loc = window.location.href;
        var extraCut = 0;
        if (loc.indexOf(":80") != -1)
            extraCut = 5;
        var endStop = loc.indexOf("/mainapp")
        if (endStop == -1)
            endStop = loc.indexOf("/MainApp")

        endStop = endStop - extraCut;
        var ipAddress = loc.substring(0, endStop);
        var url = ipAddress + "<%=commonIP%>/status?version=<%=version%>";

        try {
        $.ajax({
                type: "GET",
                url: url,
                dataType: "text",
                timeout: "1500",
                success: function(xhr) {
                    document.getElementById('servSrvActive').style.background = 'black';
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    document.getElementById('servSrvActive').style.background = 'red';
                }
            });
        } catch (exception) {
            document.getElementById('servSrvActive').style.background = 'red';
        }
    }

    function checkIfLocalAvail() {
        var url = "http://<%=userIPAddress%><%=printerIP%>/status";

        try {
        $.ajax({
                type: "GET",
                url: url,
                dataType: "text",
                timeout: "1500",
                success: function(xhr) {
                    document.getElementById('localSrvActive').style.background = 'black';
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    document.getElementById('localSrvActive').style.background = 'red';
                }
            });
        } catch (exception) {
            document.getElementById('localSrvActive').style.background = 'red';
        }
    }

    function checkIfGUIAvail() {
        var url = "http://<%=userIPAddress%>:<%= guiServicePort%>/status";

        try {
        $.ajax({
                type: "GET",
                url: url,
                dataType: "text",
                timeout: "1500",
                success: function(xhr) {
                    document.getElementById('localGUiActive').style.background = 'black';
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    document.getElementById('localGUiActive').style.background = 'red';
                    //console.clear();
                }
            });
        } catch (exception) {
            document.getElementById('localGUiActive').style.background = 'red';
        }
    }

    function clearStartMsg() {
        document.getElementById('okOnlyWarning').style.display = 'none';
    }
		</script>
	</head>
<body style="padding:0; margin:0;" >

	<div id="banner">
	<object title="Server Service" style="height:5px;width:5px;background:red;position:absolute;z-index: 2; left: 0; top:0;position:absolute;z-index: 2" id="servSrvActive">
    </object>
	<object title="Local Service" style="height:5px;width:5px;background:red;position:absolute;z-index: 2; left: 7px; top:0;" id="localSrvActive">
	</object>
	<object title="GUI Service" style="height:5px;width:5px;background:red;position:absolute;z-index: 2; left: 14px; top:0;" id="localGUiActive">
	</object>
	<a href="#" download id="downloadLink"></a>
	<div id="okOnlyWarning" class="overlay" style="display: none; text-align: center">
      <h1 id="ooWarningMsg" style="color: white"></h1>
      <BUTTON style="width: 100px; height: 45px; color: black" onclick="clearStartMsg(); return false;">OK</BUTTON>
    </div>


		<div id="home" onclick="exit()">
			<span>Home</span>
		</div>

		<div id="logo">
			<span>Cleaner Business Systems</span>
			<span class="version" style="color: whitesmoke; font-size: 9px; vertical-align: bottom; padding-top: 3px; white-space: nowrap">Version <%=version%> Type:
			<% if termLicenseType <> "" then %>
                <% if termLicenseType = 1 then %>
                    Full
                <% elseif termLicenseType = 2 then %>
                    Office
                <% end if
			end if %>
			</span>
		</div>
		
		<% if bannertext <> "" then %>
		<div id="banner-text">
			<%=server.htmlencode(bannertext)%>
		</div>
		<% end if %>

		<div id="navBlock">
			<ul>
				<li onclick="showSearch()">Search</li>
			</ul>
		</div>
		
		<div id="storeStats" <%if dbname <> "default" then%>class="not-default"<%end if%>>

		</div>
		<div id="employeeStats" onclick="showMessages()">

		</div>

		<% if trim(request.querystring("bannertext")) <> "" then %>
		<div id="bannerText">
			<%=server.htmlencode(request.querystring("bannertext"))%>
		</div>
		<% end if %>
		
	</div>
	
	<div id="banner-search-box">
		<img src="/static/icons/16x16/page_find.gif" />
		<input id="banner-search-string" />
	</div>


	<div id="main-content" style="height:768px;">
		<div id="login_window">

			<div id="login_form">
				<h3>Employee password:</h3>
				<input id="login_password" name="login_password" type="password" onkeyup="LoginKeyDown()" />
				<div id="login_prompt" ></div>
				<div id="login_commands" >
					<button onclick="AttemptLogin()">Login</button>
					<button onclick="CancelLogin()">Cancel</button>
				</div>
			</div>
		</div>

		

		<iframe name="content_frame" id="content_frame" src="start2.asp?dbname=<%=dbname%>" style="width:100%; height:95%; overflow:scroll" frameborder="0">
			<p>Your browser does not support iframes.</p>
		</iframe>

		<div id="content-overlay">
		
		</div>
	

	</div>
</body>
</html>