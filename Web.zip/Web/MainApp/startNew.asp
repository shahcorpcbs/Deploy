<style type="text/css">
	#banner #bannerText {
		text-align: center;
		font: 22px arial;
		position: absolute;
		left: 115px;
		top: 17px;
		margin: 0px;
		width: 180px;
		color: #fff;
		background: #d33;
	}
</style>
 <script language="javascript" type="text/javascript">

    //Feels like there should be an easier way to do this rather than setting it constantly
    //but with terminalFunctions being in an iframe I can't get it to set focus if we click within that frame
    //const intervalId = setInterval(setSearchFocus, 300);

</script>

<TABLE BORDER="0" CELLPADDING="0" CELLSPACING="0" STYLE="width:100%;height:100%">
<TR><TD VALIGN="TOP" style="width:170px;background:fff;">

<TABLE style="margin-bottom:10px;margin-top:10px;width:100%">
	<TR>
		<TD style="border-bottom:3px solid #EEE" COLSPAN="2"><B>Views</B></TD>
	</TR>
	<TR style="cursor:pointer" onmousedown="return loadIframe('sa', '../MainApp/Startpage/NewTerminalFunctions.asp');">
		<TD style="width:40px" align="right"><IMG SRC="/images/redesign/home.png"></TD>
		<TD>Home</TD>
	</TR>
	<TR style="cursor:pointer" onmousedown="return loadIframe('sa', '../MainApp/Startpage/StoreActivity.asp');">
		<TD style="width:40px" align="right"><IMG SRC="/images/redesign/view_text.png"></TD>
		<TD>Store Activity</TD>
	</TR>
	<TR style="cursor:pointer" onmousedown="return loadIframe('sa', '../MainApp/Startpage/NotesTracker.asp?useraction=defaultsearch');">
		<TD style="width:40px" align="right"><IMG SRC="/images/redesign/note.png"></TD>
		<TD>Invoice Notes</TD>
	</TR>
</TABLE>

<%
	query = "select formid, name from startpageform where storeid = " & session("storeid")
	set rs = getdisconnectedrecordset(query)

	if rs.recordcount > 0 then
%>
<TABLE style="margin-bottom:10px;margin-top:10px;width:100%">
	<TR>
		<TD style="border-bottom:3px solid #EEE" COLSPAN="2"><B>Alerts</B></TD>
	</TR>

<%
	while not (rs.eof or rs.bof)
%>
	<TR style="cursor:pointer" onmousedown="return loadIframe('sa', '../MainApp/Startpage/Custom.asp?formid=<%=rs("formid")%>');">
		<TD style="width:40px" align="right"><IMG SRC="/images/redesign/alerts.png"></TD>
		<TD><%=rs("name")%></TD>
	</TR>
<%
		rs.movenext
	wend
%>
</TABLE>
<%
	end if
	set rs = nothing
%>


<% if printOnHomeScreen then %>
<TABLE style="margin-bottom:10px;margin-top:10px;width:100%">
	<TR>
		<TD style="border-bottom:3px solid #EEE" COLSPAN="2"><B>Tools</B></TD>
	</TR>
	<TR style="cursor:pointer" onmouseup="printTags();">
		<TD style="width:40px" align="right"><IMG SRC="/images/redesign/print.png"></TD>
		<TD>Print Tags</TD>
	</TR>

	<TR style="cursor:pointer" onmouseup="printInvoice();">
		<TD style="width:40px" align="right"><IMG SRC="/images/redesign/print.png"></TD>
		<TD>Print Invoice</TD>
	</TR>
</TABLE>
<% end if %>


</TD><TD VALIGN="TOP" style="">

<TABLE STYLE="width:100%;margin:10px;margin-top:20px;border-spacing:25px; ">
<TR><TD ALIGN="CENTER" COLSPAN="2" style="padding-bottom: 15px; padding-top:5px">
<INPUT id="smartQuery" name="smartQuery" autocomplete="off" autofocus onkeyup="CaptureKey(this.value);" onblur="setSearchFocus()" placeholder="Search"
    STYLE="BORDER:2px solid #000;width:95%; height:50px;margin-right:10px;border-radius: 25px; font-size:50px;text-align:center"><BR />
</TD></TR>
<TR><TD ALIGN="CENTER" style="border:solid; border-radius: 25px; width:50%">
<% if termLicenseType = 1 then %>
<A style="text-decoration:none;color:black; width:100%;display:block;" HREF="javascript:Login('/mainapp/racking.asp')"><IMG style="border:none" SRC="/images/<%=rackingIconPath%>"><BR><B>Racking</B></A>
<% else %>
<A style="text-decoration:none;color:black;width:100%;display:block;" HREF="javascript:Login('/mainapp/customersearch.asp?targetpage=CustomerFunctions')"><IMG style="border:none" SRC="/images/<%=custIconPath%>"><BR><B>Customer Functions</B></A>
<% end if %>
</TD><TD ALIGN="CENTER" style="border:solid; border-radius: 25px; width:50%">
<A style="text-decoration:none;color:black; width:100%;display:block;padding:5px" HREF="javascript:Login('/mainapp/managerMenu.asp')"><IMG style="border:none" SRC="/images/<%=manIconPath%>"><BR><B>Manager</B></A>
</TD></TR>
</TABLE>

<IFRAME name="sa" NORESIZE SCROLLING="AUTO" FRAMEBORDER="0" HEIGHT="550px" WIDTH="100%" style="padding-right:20px;padding-left:10px;" SRC="../MainApp/Startpage/NewTerminalFunctions.asp?routeVersion=<%=getRouteVersion(session("storeid"))%>"></IFRAME>

</TD></TR>
</TABLE>