<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<% sec_RequestAccess Request.QueryString("userAction") %>

<%
    dim query, rs


 
    function buildCustomerSeqCVS()
        dim  rs, query
        dim criteria
      
        criteria = buildCriteria()

        
        buildCustomerSeqCVS = ""
        
        if criteria <> "" then
            query = "select customersequencenumber from customer where isactive = 1 and " & criteria

            set rs = getdisconnectedrecordset(query)

            if rs.recordcount > 0 then
                while not rs.eof
                    buildCustomerSeqCVS = Append(buildCustomerSeqCVS, rs("customersequencenumber"), ",")
                    rs.movenext
                wend
            end if

            set rs = nothing
        end if
    end function

    function Append(pre, post, divider)
        if post <> "" then
            if pre <> "" then
                Append = pre & divider & post
            else
                Append = pre & post
            end if
            
        else
            Append = pre
        end if
    end function
    
    function buildCriteria()
        buildCriteria = ""
        buildCriteria = Append(buildCriteria, cri_ms(), " and ")
        buildCriteria = Append(buildCriteria, cri_ic(), " and ")
        buildCriteria = Append(buildCriteria, cri_e(), " and ")
        buildCriteria = Append(buildCriteria, cri_r(), " and ")
        buildCriteria = Append(buildCriteria, cri_ci(), " and ")
        buildCriteria = Append(buildCriteria, cri_rt(), " and ")
    end function
    
    function cri_ms()
        if Request.Form("msValue") <> "" and Request.Form("msDateBegin") <> "" and Request.Form("msDateEnd") <> "" then
            cri_ms = " dbo.getCustomerSales(customersequencenumber, "
            cri_ms = cri_ms & "'" & Request.Form("msDateBegin") & "', "
            cri_ms = cri_ms & "'" & Request.Form("msDateEnd") & "') "
            cri_ms = cri_ms & Request.Form("msMoreOrLess") & " "
            cri_ms = cri_ms & Request.Form("msValue") & " "
        end if
    end function
    
    function cri_ic()
        if Request.Form("icValue") <> "" and Request.Form("icDateBegin") <> "" and Request.Form("icDateEnd") <> "" then
            cri_ic = " dbo.getCustomerVisits(customersequencenumber, "
            cri_ic = cri_ic & "'" & Request.Form("icDateBegin") & "', "
            cri_ic = cri_ic & "'" & Request.Form("icDateEnd") & "') "
            cri_ic = cri_ic & Request.Form("icMoreOrLess") & " "
            cri_ic = cri_ic & Request.Form("icValue") & " "
        end if
    end function
    
    function cri_ci()
        if Request.Form("ciValue") <> "" and Request.Form("ciDateBegin") <> "" and Request.Form("ciDateEnd") <> "" then
            cri_ci = " dbo.getCustomerOpenInvoices(customersequencenumber, "
            cri_ci = cri_ci & "'" & Request.Form("ciRackedOrNot") & "', "
            cri_ci = cri_ci & "'" & Request.Form("ciDateBegin") & "', "
            cri_ci = cri_ci & "'" & Request.Form("ciDateEnd") & "') "
            cri_ci = cri_ci & Request.Form("ciMoreOrLess") & " "
            cri_ci = cri_ci & Request.Form("ciValue") & " "
        end if
    end function
    
    
    
    function cri_e()
        if Request.Form("eType") <> "" and Request.Form("eDateBegin") <> "" and Request.Form("eDateEnd") <> "" then
            cri_e = " " & Request.Form("eType") & " between "
            cri_e = cri_e & "convert(datetime, '" & Request.Form("eDateBegin") & "') and "
            cri_e = cri_e & "dateadd(day, 1, convert(datetime, '" & Request.Form("eDateEnd") & "')) "
        end if
    end function
    
    function cri_rt()
        if Request.Form("rtNumber") = "" then
        
        elseif Request.Form("rtNumber") = "all" then
            cri_rt = " routeNumber > 0 "
        elseif Request.Form("rtNumber") > 0 then
            cri_rt = " routeNumber = " & Request.Form("rtNumber") & " "
        end if
    end function
    
    function cri_r()
        if Request.Form("rValue") <> "" then
            cri_r = "dbo.getCustomerRating(customersequencenumber) * 100.00 "
            cri_r = cri_r & Request.Form("rMoreOrLess") & " "
            cri_r = cri_r & Request.Form("rValue") & " "
        end if
    end function
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Advance Customer Search</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

<style>
<!--

.txtNumber {
   width:50px;
   text-align:right;
}

.txtDate {
   width:76px;
   text-align:center;
}
-->
</style>

</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">

	function selectDate(element) {

		show_calendar("advCustomerSearch." + element.name);
	}
	function submitForm() {
	    document.advCustomerSearch.action = "?useraction=submit";
	    document.advCustomerSearch.submit();
	}   
	function cancelForm() {
	    document.advCustomerSearch.action = "managerMenu.asp";
	    document.advCustomerSearch.submit();
	}   
    function printOnLoad() {
        var customerSeqs;
        var customerSeqList;
        
        
        if(document.advCustomerSearch.slipSeqNumbers.value != "")
        {
            if(document.advCustomerSearch.slipPrinter.value == "@text")
            {
            

                document.advCustomerSearch.slipContents.value = PrintCustomerSlips(
                document.advCustomerSearch.slipSeqNumbers.value,
                "",
                document.advCustomerSearch.slipForm.value
                );
                    
                    
	            document.advCustomerSearch.action = "formSaveAs.asp?form=slipContents";
	            document.advCustomerSearch.submit();
            }
            else
            {
                customerSeqList = document.advCustomerSearch.slipSeqNumbers.value;
                customerSeqs = customerSeqList.split(",");
            
		        if (cbsConfirm("Continue printing " + customerSeqs.length + " " + document.advCustomerSearch.slipForm.value + "(s) on " + document.advCustomerSearch.slipPrinter.value + "?",
		            cbsQuestion + cbsYesNo, "Printing") == cbsYes) {
                    PrintCustomerSlips(
                    document.advCustomerSearch.slipSeqNumbers.value,
                    document.advCustomerSearch.slipPrinter.value,
                    document.advCustomerSearch.slipForm.value
                    );
		        }
		    }
        }
        else if (document.advCustomerSearch.slipPrinter.value != "")
        {
            cbsAlert("0 results");
        }
    }
    
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="PopulateLocalPrinters(document.getElementById('printername'), '');printOnLoad();">
<!-- #include file="../include/localprinter.inc" -->
<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">&nbsp;Advance Customer Search</B>
<FORM id="advCustomerSearch" name="advCustomerSearch" action="start.asp" method="Post">

<input type=hidden name="slipSeqNumbers" value="<%=buildCustomerSeqCVS()%>">
<input type=hidden name="slipPrinter" value="<%=Request.Form("printername")%>">
<input type=hidden name="slipForm" value="<%=Request.Form("formname")%>">
<input type=hidden name="slipContents" value="">

<center>
<table class=optTable cellpadding=3 style="display:block">

<tr>
    <td><b>Money Spent</b></td>

    <td>
        <select name="msMoreOrLess">
            <option value=">=">More</option>
            <option value="<">Less</option>
        </select>
        than
        <input name="msValue" class=txtNumber></input>
        dollars
    </td>
    
    <td>
        between <input name="msDateBegin" onclick="selectDate(this);" class=txtDate></input> and <input name="msDateEnd" onclick="selectDate(this);" class=txtDate></input>
    </td>
</tr>

<tr>
    <td><b>Invoices Out</b></td>
    <td>
        <select name="icMoreOrLess">
            <option value=">=">More</option>
            <option value="<">Less</option>
        </select>
        than
        <input name="icValue" class=txtNumber></input>
    </td>
    <td>
        between <input name="icDateBegin" onclick="selectDate(this);" class=txtDate></input> and <input name="icDateEnd" onclick="selectDate(this);" class=txtDate></input>
    </td>
</tr>

<tr>
    <td><b>Event</b></td>

    <td>
        <select name="eType">
            <option value=""></option>
            <option value="birthdate">Birthday</option>
            <option value="createddate">Sign Up</option>
            <option value="lastvisited">Last Visit</option>
        </select>
        occurred
    </td>
    
    <td>
        between <input name="eDateBegin" onclick="selectDate(this);" class=txtDate></input> and <input name="eDateEnd" onclick="selectDate(this);" class=txtDate></input>
    </td>
</tr>





<tr>
    <td><b>Open Invoices</b></td>

    <td>
        <select name="ciRackedOrNot">
            <option value="-1">All</option>
            <option value="1">Racked</option>
            <option value="0">Not Racked</option>
        </select>
        due
        <select name="ciMoreOrLess">
            <option value=">=">More</option>
            <option value="<">Less</option>
        </select>
        than
        <input name="ciValue" class=txtNumber></input>
    </td>
    
    <td>
        between <input name="ciDateBegin" onclick="selectDate(this);" class=txtDate></input> and <input name="ciDateEnd" onclick="selectDate(this);" class=txtDate></input>
    </td>
</tr>

<!--
<tr>
    <td><b>Dropped Off</b></td>

    <td>
        <select name="doMoreOrLess">
            <option value=">=">More</option>
            <option value="<">Less</option>
        </select>

        then
        <input name="doValue" class=txtNumber></input>
        pieces of
        <select name="doDepartment">
<%
        query = "select distinct name from department where storeid = " & session("storeid")
        set rs = GetDisconnectedRecordset(query)
        
        if rs.recordcount > 0 then
            while not rs.eof
%>
            <option value="<%=rs("name")%>"><%=rs("name")%></option>
<%
            rs.movenext
            wend
        end if
        set rs = nothing
%>
        </select>
    </td>
    
    <td>
        between <input name="doDateBegin" onclick="selectDate(this);" class=txtDate></input> and <input name="doDateEnd" onclick="selectDate(this);" class=txtDate></input>
    </td>
</tr>
-->







<tr>
    <td><b>Rating</b></td>
    
    <td>
        <select name="rMoreOrLess">
            <option value=">=">More</option>
            <option value="<">Less</option>
        </select>

        than
        <input name="rValue" class=txtNumber></input>
    </td>
</tr>



<tr>
    <td><b>Route</b></td>
    
    <td>
        <select name="rtNumber">
            <option value=""></option>
            <option value="all">All</option>
        <%
            query = "select routenumber, name from route where storeid = " & session("storeid")
            set rs = getdisconnectedrecordset(query)
            
            while not(rs.eof or rs.bof)
        %>
            <option value="<%=rs("routeNumber")%>"><%=rs("name")%></option>
        <%
            rs.movenext
            wend
            set rs = nothing
        %>
        </select>
    </td>
</tr>


<tr>

    <td><b>Output</b></td>
    
    <td colspan=2>
        <select name="formname">
            <option>invoice</option>
            <option>tag</option>
<%
        query = "select FormName from form where storeid = " & session("storeid")
        set rs = GetDisconnectedRecordset(query)
        
        if rs.recordcount > 0 then
            while not rs.eof
%>
            <option value="<%=rs("FormName")%>"><%=rs("FormName")%></option>
<%
            rs.movenext
            wend
        end if
        set rs = nothing
%>
        </select>
        on
        <select name="printername">
            <option value="@text">Text File</option>
        </select>
    </td>
</tr>

<tr>
	<td colspan=3 align="center">
		<input type="button" value="Cancel" onclick="cancelForm();" style="width:100px;height:50px;margin-top:40px;"></input>
		<input type="button" value="Ok" onclick="submitForm();" style="width:100px;height:50px;margin-top:40px;"></input>
	</td>
</tr>

</table>



</center>

</FORM>   
</BODY>
</HTML>
