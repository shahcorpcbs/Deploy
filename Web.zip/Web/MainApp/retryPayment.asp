<%@ Language=VBScript %>
<%option explicit%>
<% Server.ScriptTimeout = 2 %>
<%
	dim dbname
	
	dbname = request.querystring("dbname")
	if dbname = "" then dbname = "default"
%>

<!--#include file="../include/SystemStartup.asp"-->
<% selectDatabase dbname %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->
<!--#include file="../include/json.asp"-->

<%
    On Error Resume Next
    dim query, rs
	dim pickupObj, tickets, customerseq, empId, terminalId, amountPaid
	dim cardNumber, cardExp, cardType, transactionID, i, storeId


	query = "select storeId from store"
	set rs = getdisconnectedrecordset(query)
	storeId = rs("storeId")


    customerseq = Request.QueryString("customerseq")
    amountPaid = Request.QueryString("amountPaid")
    empId =  Request.QueryString("empId")
    terminalId =  Request.QueryString("terminalId")
    cardNumber =  Request.QueryString("cardNumber")
    cardExp =  Request.QueryString("cardExp")
    cardType = "''"
    transactionID =  Request.QueryString("transactionID")


    set pickupObj =Server.CreateObject("ShahCorpComponents.pickup")


		pickupObj.initPickupObject
		pickupObj.DBConnectionString = Session("shahcorpDSN")
		pickupObj.storeId = storeId
		pickupObj.initStorePaymentTypeInfo()
		pickupObj.userAction = "prepay"
		pickupObj.custSeqNumber = customerseq

		tickets = split(Request.QueryString("Ticketnumber"), ",")
		for i = lbound(tickets) to ubound(tickets)
		    pickupObj.addInvoiceToPrepay tickets(i)
		next


        pickupObj.addPayment amountPaid, "Credit Card", cardNumber, cardExp, cardType,, transactionID, transactionID


        pickupObj.applyPayments empId, terminalId, pickupObj.constructTicketNosString() , -1

        dim invNum
        invNum = pickupObj.getTicketNosForPrinting()

		if Err.Number <> 0 then
			Response.Write(Err.Description)
	    else
	        Response.Write("1")
		end if
		Response.Flush
		Response.End
%>