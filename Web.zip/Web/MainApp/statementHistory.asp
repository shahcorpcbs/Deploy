<%@ Language=VBScript %>

<%option explicit%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	
	on error resume next

	dim objRSarStatementHistory
	dim customerSequenceNumber
		
	customerSequenceNumber = IIf(isNumeric(session("customersequencenumber")), CLng(session("customersequencenumber")), 0)
	if customerSequenceNumber < 1 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add -1,  "You must first select a customer before the system can display the Account Receivable Statement History."
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")	
	end if
	
	'	Getting Account Receivable Statement History for all Stores and Date Ranges in this release.
	'	In the future, if filtering is to be done, the SP already has these parameters.
	Set objRSarStatementHistory = getDisconnectedRecordset( _
			"EXECUTE dbo.GetStatementHistoryList @customerSequenceNumber = " & customerSequenceNumber ) 

	if not objRSarStatementHistory is nothing then
		if objRSarStatementHistory.RecordCount > 0 then
			Call GetReportParams(RPT_NBR_AR_Statement, true, RPT_Requester_Name_Statement_History, 0)
		end if
	end if
	
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & "-Function= Account Receivable Statement History. Error while getting the list of Account Receivable Statement History."
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if

%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Account Receivable Statement History</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript">
	var previousElement=null;
	var l_accountStatementID = null;
	
	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.style.background="white";
		}
		childEl = element.children[0];
		var rowChildNodes = childEl.children
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if(childEl.tagName == "INPUT") {
				childEl.checked=true;
				l_accountStatementID = childEl.value;
				document.arStatementHistory.view.disabled  = false
				break;
			}
		}
		previousElement =element;
		element.style.background="#DBF2F4";
		 
	}
		
	function viewStatement() {

		//document.arStatementHistory.action = "statementView.asp?accountStatementID=" +  l_accountStatementID;
		document.arStatementHistory.action = "report.asp?source=statementhistory&accountStatementID=" +  l_accountStatementID;
		document.arStatementHistory.submit();
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->

<B class="pageHeading">&nbsp;Account Receivable Statement History</B>

<FORM id="arStatementHistory" name="arStatementHistory" action="" method="post">
	<input type="hidden" name="reportID" value="<%= Session("objRP").reportNumber%>">
	<input type="hidden" name="storeID" value="<%= Session("objRP").storeID %>">

<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=0>
	<tr>
		<td align="center">
			<TABLE WIDTH="750px" BORDER=0 CELLSPACING=1 CELLPADDING=5>
				<!-- heading -->
				<tr>
					<th width =40px align=left class="label">ID</th>
					<th width =130px align=left class="label">Run Date</th>
					<th width =65px align=left nowrap class="label">Period Start</th>
					<th width =65px align=left nowrap class="label">Period End</th>
				</tr>
			</table>
		</td>
	</tr>
	<!-- list -->
	<tr>
		<td align="center">
			<DIV STYLE="overflow-y:auto;height:300px; overflow-x:auto; width=750px">
					<TABLE WIDTH="100%" style="border-color:#2F4F4F;border-style:solid;background-color:white;" BORDER=1 CELLSPACING=0>
						<tr rowspan =5>
							<td>
								<TABLE WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=3>
									<%while not objRSarStatementHistory.eof 
									%>	
										
											<tr onClick="selectRow(this)">
											<td width=25px><input type="radio" visible=false name="select" id="select" value ="<%=objRSarStatementHistory("accountStatementID")%>"><%=objRSarStatementHistory("accountStatementID")%></td>
											<td width = 140px  STYLE="FONT-SIZE: 12px;"><%= objRSarStatementHistory("statementRunDate") %></td>
											<td width = 70px  STYLE="FONT-SIZE: 12px;"><%=objRSarStatementHistory("statementRangeStartDate") %></td>
											<td width = 65px  STYLE="FONT-SIZE: 12px;"><%=objRSarStatementHistory("statementRangeEndDate") %></td>
										</tr>

									<%	objRSarStatementHistory.MoveNext
										wend
										
										objRSarStatementHistory.Close
										set objRSarStatementHistory = Nothing

									%>	
									
								</table>
							</td>
						</tr>
				</table> <!-- table for border -->
			</div>
		</td>
	</tr>
	<!-- buttons -->
	<tr>
		<td align="center">
			<TABLE WIDTH="750px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
				<tr height=20px></tr>
				<tr>
					<td align="center">
						<INPUT class=touchnoborder id=view name=view type=button value="" disabled style="background-image:url(../images/OK.gif)" onClick="viewStatement()">
					</td>
					<td align="center">
						<INPUT class=touchnoborder id=close name=close type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="location.href='customerfunctions.asp'">
					</td>
				</tr>
			</table>
		</td>
	<tr>
</TABLE>
</FORM>
</BODY>
</HTML>
