<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 360 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/form_merge.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim queryName
	dim queryTransformed
	dim query, rs
	dim userQueryID
	dim formID
	dim formTemplate
	
	userQueryID = getReqVar("userQueryID")
	queryTransformed = getReqVar("query")
	queryName = getReqVar("queryName")
	formID = getReqVar("formID")
	
	formTemplate = getHTMLForm(formID)
	
	select case lcase(request.querystring("useraction"))
		case "sendemail"
			emailMergedForm queryName, queryTransformed, formTemplate, request.form("emailField"), request.form("fromEmail"), request.form("fromName"), request.form("subject")
	end select
	
	function emailMergedForm(queryName, query, formTemplate, emailField, fromEmail, fromName, subject)
		on error resume next
		dim counter
		dim recordCount
		dim formParams
		dim toEmail
    
		if query <> "" then

			set rs = getdisconnectedrecordset(query)
			
			if err.number <> 0 then
				exit function
			end if
			
			if rs.state > 0 then
				recordCount = rs.recordcount
				
				if recordCount > 0 then
					set formParams = getFormParams(formTemplate)

					rs.MoveFirst
					
					counter = 1
					while not (rs.eof or rs.bof)
					  toEmail = rs(trim(emailField))
					  if toEmail <> "" then
  					  sendEmail toEmail, fromEmail, fromName, subject, transformQuery(formTemplate, formParams, rs), subject
  
  						if counter mod 50 = 0 then response.flush
  						counter = counter + 1
						end if
						
					  rs.MoveNext
					wend
				end if
			end if
		end if

	end function
	
	function sendEmail(toEmail, fromEmail, fromName, subject, body, source)
		dim query, rs
		
		query = " insert into emailqueue (toAddress, fromAddress, fromName, subjectLine, bodyText, source) "
		query = query & " values ("
		query = query & "  " & DbQryString(toEmail)
		query = query & ", " & DbQryString(fromEmail)
		query = query & ", " & DbQryString(fromName)
		query = query & ", " & DbQryString(subject)
		query = query & ", " & DbQryString(body)
		query = query & ", " & DbQryString(source)
		query = query & ")"
		
		qryexecute query

	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function writeMergedForm(query, formTemplate)
		on error resume next
		dim counter
		dim recordCount
		dim formParams
		
		if query <> "" then

			set rs = getdisconnectedrecordset(query)
			
			if err.number <> 0 then
				response.write "<div class=""error"">Error executing query<br>" & query & "</div>"
				exit function
			end if
			
			if rs.state > 0 then
				recordCount = rs.recordcount
				
				if recordCount > 0 then
					set formParams = getFormParams(formTemplate)

					rs.MoveFirst
					
					counter = 1
					while not (rs.eof or rs.bof)
						response.write "<DIV class=""mergedform"" style=""page-break-after:always"">" & transformQuery(formTemplate, formParams, rs) & "</DIV>"
					  
						if counter mod 50 = 0 then response.flush
						counter = counter + 1
						
					  rs.MoveNext
					wend
				else
					response.write "<div class=""warning"">No records</div>"
				end if
			end if
		else
			response.write "<div class=""error"">No query selected</div>"
		end if

		exit function

	end function
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function getHTMLForm(formID)
		dim query, rs
		
		if formID <> "" then
			query = " select html from htmlform where formid = " & formID
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getHTMLForm = rs("html") 
			end if
		end if
	end function
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
%>

<HTML>
<HEAD>
<TITLE>Merge Query</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>


<STYLE  type="text/css" >
.mergedform {

	border: 1px inset;
	background: white;
	padding: 3px;
	margin: 3px;
}

</STYLE>
 
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT LANGUAGE="javascript" >


	function runQuery(userQueryID, query) {
		document.queryMerge.action  = "querydb.asp?userQueryID=" + userQueryID + "&query=" + encodeURIComponent(query);
		document.queryMerge.submit();
	}


	function exitQuery() {
		document.queryMerge.action  = "querylist.asp";
		document.queryMerge.submit();
	}
	function openForm(formID) {
		document.queryMerge.formID.value = formID;
		document.queryMerge.action = "?useraction=openform&formID=" + formID;
		document.queryMerge.submit();
	}
	
	function printResults() {
		var result_window = window.open('','','width=300,height=300');
		result_window.document.open("text/html");
		result_window.document.write(document.getElementById('results').innerHTML);
		result_window.document.close();
		result_window.print();
		result_window.close();
	}
	
	function emailResults(userQueryID, query) {
		document.queryMerge.action = "queryEmailParams.asp?userQueryID=" + userQueryID + "&query=" + encodeURIComponent(query);
		document.queryMerge.submit();
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->

<FORM name="querydb" ID="queryMerge" METHOD=POST  style="margin:0;padding:0"> 
<INPUT type="hidden" name="queryName" value="<%=Server.URLEncode(queryName)%>" />
<INPUT type="hidden" name="query" value="<%=queryTransformed%>" />
<INPUT type="hidden" name="userQueryID" value="<%=userQueryID%>" />
<INPUT type="hidden" name="formID" value="<%=formID%>" />

<H1>Results</H1><BR />
<BR />

<TABLE>
	<TR>
		<TD>
			Existing Forms:<BR />
			<SELECT name="selectedFormID" onchange="openForm(selectedFormID.value);">
			<OPTION value="">Select Form</OPTION>
			<%
				query = "select formid, name from htmlform"
				set rs = getdisconnectedrecordset(query)
				
				while not(rs.eof or rs.bof)
			%>
				<OPTION value="<%=rs("formid")%>" <%if trim(formid) = trim(rs("formid")) then%>selected<%end if%>><%=Server.HTMLEncode(rs("name"))%></OPTION>
			<%
					rs.movenext
				wend
				set rs = nothing
			%>
			</SELECT>
		</TD>
	</TR>
</TABLE>



<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="printResults()" value="" >Print</BUTTON>
		<!--<BUTTON onclick="emailResults(userQueryID.value, query.value)" value="" >Email</BUTTON>-->
	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="runQuery(userQueryID.value, query.value)" value="" >Exit</BUTTON>
	</SPAN>
</DIV>	


<DIV id="results">
<%
	writeMergedForm queryTransformed, formTemplate
%>
</DIV>

</FORM>
</BODY>
</HTML>

