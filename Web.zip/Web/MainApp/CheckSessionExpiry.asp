<%

	Dim displayLogin	
	
	displayLogin = True
	
	If Trim(Session("employeeID")) <> "" Then
		If CLng(Session("employeeID")) > 0 Then
			displayLogin = False
		End If
	End If

	if displayLogin then
		Response.Redirect "start2.asp"
	end if
		
%>
