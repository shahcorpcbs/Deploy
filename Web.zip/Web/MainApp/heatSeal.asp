<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	'***********************************************************************
	'Name   :Heat Seal
    'Author : Poonam Gupta
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 11-Sept-2002    Poonam		Original Version
    ' 19-Sept-2002    Poonam		Validations for heat seal numbers
    ' 20-Sept-2002    Poonam		Numeric validations for heat seal numbers
    '***********************************************************************

	dim invoice
	dim invLineItems, invItemDescriptors
	dim itemsHeatSealInfo
	'invoice details
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim dueDateSet
	dim dueDate
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim targetPage, originatingPage
	dim actionString
	dim counter
	dim itemQuantity
	dim itemName
	dim exists, heatsealNumber
	dim deptName, deptId
	dim itemId
	dim lineNumber
	dim sInvoicenumber
	dim custSeqNumber
	dim datalines
	dim hsStart, hsEnd
	dim hsLengthMin, hsLengthMax
	dim ppPopup

	on error resume next
	set invoice = Session("invoice")
	custSeqNumber = Session("customersequencenumber")
	curr_LineNo = Request.Form("lineNumber")
	selectedDept = Request.Form("selectedDept")
	itemsStartIndex = Request.Form("ItemPageCount")
	upChargeStartIndex = Request.Form("upChargePageCount")
	colorsStartIndex = Request.Form("colorsPageCount")
	patternStartIndex = Request.Form("PatternPageCount")
	addOrEdit = Request.Form("addOrEdit")
	deptStartIndex = Request.Form("DeptPageCount")
	selItemId = Request.Form("selItemId")
	selUpchargeValue = Request.Form("selUpcharge")
	selColorValue = Request.Form("selColor")
	selPatternValue = Request.Form("selPattern")
	'targetPage = Request.QueryString("targetPage")
	originatingPage = Request.Form("originPage")
	datalines = Request.Form("datalines")
	actionString = Request.QueryString("userAction")
	sinvoicenumber = session("invoicelist")
	hsStart = Request.Form("hsStart")
	hsEnd = Request.Form("hsEnd")
	hsLengthMin = getMSVar("healSealMinSize")
	hsLengthMax = getMSVar("healSealMaxSize")
	ppPopup = getMSVar("prepayPopupOnDetailPage")

	if isEmpty(hsStart) or hsStart = "" then
		initializeHSValues
	end if

	if actionString = "submit" then
		updateHeatSealInfo
	end if

	sub initializeHSValues()
		dim query
		dim rs
		query = "Select starths, endhs from validheatsealranges"
		set rs = getDisconnectedRecordset(query)

		if rs.Recordcount > 0 then
		while not(rs.eof or rs.bof)
			if hsStart = "" then
				hsStart = rs("starths")
				hsEnd = rs("endhs")
			else
				hsStart = hsStart + "|" + rs("starths")
				hsEnd = hsEnd + "|" + rs("endhs")
			end if
			rs.movenext
		wend
		set rs=nothing
		end if
	end sub

	sub updateHeatSealInfo()
		dim intLoop, intLoop2
		dim itemName
		dim lineNumber
		dim hsNumber
		dim itemId
		dim itemInfo
		dim itemSplitArray
		dim validate
		if Request.Form("select").Count > 0 then
     		validate = validateHeatSealNumber()
			if validate then
				' delete existing heat seal details
				invoice.clearExistingHeatSealInfo
				for intLoop=1 to Request.Form("select").Count
					itemInfo = Request.Form("select")(intLoop)
					itemSplitArray = Split(itemInfo,"|||")
					itemId = itemSplitArray(0)
					itemName = itemSplitArray(1)
					fieldCounter = itemSplitArray(2)
					lineNumber = itemSplitArray(3)
					for intLoop2 = 1 to fieldCounter
						hsNumber = Request.Form(lineNumber&"txtHeatSealNo"&intLoop2)
						if IsEmpty(hsNumber) or hsNumber = "" then
							hsNumber = -1
						end if
						invoice.addHeatSealInfoForItem lineNumber, hsNumber, itemName, itemId
					next
				next
				goBackToDetailedInvoice
			end if
		else
            Session("errorMessage") = "No heat seals entered. Go back and correct the problem."
            Response.Redirect "invoiceErrorMessages.asp"
		end if
	end sub

	sub goBackToDetailedInvoice()
		Response.Redirect "detailedInvoice.asp?userAction=fromHeatSeal" _
								& "&addOrEdit=" & addOrEdit & "&lineNo=" & curr_LineNo _
								& "&dept=" & selectedDept & "&upIndex=" & upChargeStartIndex _
								& "&cIndex=" & colorsStartIndex & "&pIndex=" & patternStartIndex _
								& "&itIndex=" & itemsStartIndex & "&deptIndex=" & deptStartIndex _
								& "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
								& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue _
								& "&needHS=No&prepay=" & Request.QueryString("prepay")
	end sub

	function validateHeatSealNumber()
		dim ssql
		dim objResultSet
		dim intLoop, intLoop2
		dim retval
		dim hsNos
		dim hsNumber
		dim hsCount
		dim counter
		dim tempHSNumber()
		dim itemInfo
		dim itemSplitArray
		dim lineNumber
		dim occurence
           dim temp

		retval =true
		hsNos = ""
		hsCount = 0
		on error resume next
		Redim tempHSNumber(Request.Form("select").Count)
		if err.number <> 0 then
			Response.Write err.Description
		end if
		'getting heat seal numbers from the data page
		for intLoop=1 to Request.Form("select").Count
			itemInfo = Request.Form("select")(intLoop)
			itemSplitArray = Split(itemInfo,"|||")
			itemId = itemSplitArray(0)
			itemName = itemSplitArray(1)
			fieldCounter = itemSplitArray(2)
			lineNumber = itemSplitArray(3)
			for intLoop2 = 1 to fieldCounter
			hsNumber = Request.Form(lineNumber&"txtHeatSealNo"&intLoop2)
				if Not IsEmpty(hsNumber) And  hsNumber <> "" then
					hsNos =  hsNos & "'" & hsNumber & "',"
					tempHSNumber(hsCount) = hsNumber
					hsCount = hsCount + 1
				end if
			next
		next
		hsNos = Left(hsNos, Len(hsNos) - 1)
		intLoop =1

		'looking for duplicate heat seal numbers
		while intLoop <= Request.Form("select").Count and retval
			itemInfo = Request.Form("select")(intLoop)
			itemSpliArray = Split(itemInfo,"|||")
			fieldCounter = itemSplitArray(2)
			lineNumber = itemSplitArray(3)
			for intLoop2 = 1 to fieldCounter
				hsNumber = Request.Form(lineNumber&"txtHeatSealNo"&intLoop2)
				occurence = 0
                        if tempHSNumber(counter) = hsNumber then
                              occurence = occurence + 1
                              if occurence > 1 then
                                    retval = false
                                    Session("errorMessage") = hsNumber &  " entered more than once. Go back and correct the problem."
                                    Response.Redirect "invoiceErrorMessages.asp"
                                    exit for
                              end if
                        end if
			next
			intLoop = intLoop +1
		wend


		'Before checking the heatseal numbers in the database, insert missing ones.
		InsertMissingHeatSealNumbers

		'looking for heat seal numbers that exist but were not entered correctly
		if retval and hsCount > 0 then
			ssql = "Select heatSealID from TaggedPiece where " _
					& " heatSealID IN (" & hsNos & ")"
			set objResultSet = getDisconnectedRecordset(ssql)
			if objResultSet.Recordcount =0 then
				retval =false
				Session("errorMessage") = hsNos & " are invalid heat seal number(s). Go back and enter new number(s)."
				Response.Redirect "invoiceErrorMessages.asp"
			else
				if objResultSet.Recordcount < hsCount then
					retval =false
					hsNos = ""
					for intLoop=1 to Request.Form("select").Count
						itemInfo = Request.Form("select")(intLoop)
						itemSplitArray = Split(itemInfo,"|||")
						fieldCounter = itemSplitArray(2)
						lineNumber = itemSplitArray(3)
						for intLoop2 = 1 to fieldCounter
							hsNumber = Request.Form(lineNumber&"txtHeatSealNo"&intLoop2)
							objResultSet.Filter = "heatSealID=" & hsNumber
							if err.number <> 0 then
								Response.Write err.Description
							end if
							if objResultSet.Recordcount = 0 then
								if hsNos = "" then
									hsNos = hsNumber
								else
									hsNos = hsNos & ", " & hsNumber
								end if
							end if
							objResultSet.Filter = ""
						next
					next
					Session("errorMessage") = hsNos &  " are invalid heat seal number(s). Go back and enter new number(s)."
					Response.Redirect "invoiceErrorMessages.asp"
				end if
			end if
		end if
		validateHeatSealNumber = retval
	end function



%>
<HTML>
<HEAD>
<TITLE>Heat Seal</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript">
	var checkboxClicked=false;
	function selectRow(element) {
		var childEl;
		if(!checkboxClicked){
			childEl = element.children[0];
			var rowChildNodes = childEl.children
			for(i=0; i<rowChildNodes.length; i++){
				childEl = rowChildNodes[i];
				if(childEl.tagName == "INPUT") {
					if(childEl.checked) {
						childEl.checked=false;
						element.style.background="#F7FBFC";
					}
					else{
						childEl.checked=true;
						element.style.background="#DBF2F4";
					}
					break;
				}
			}
		}
		checkboxClicked=false;
	}

	function selectRowForCheckBox(element) {
		var parentEl;
		parentEl=element;
		while(parentEl.tagName != "TR") {
			parentEl = parentEl.parentElement;
		}
		if (element.checked){
			parentEl.style.background="#DBF2F4";
		}else{
			parentEl.style.background="#F7FBFC";
		}
		checkboxClicked=true;
	}

	function submitForm() {
		var valid;

		valid = validateHeatSeals();
		if (valid){
			document.heatSealForm.okButton.disabled = true;
			<% if ppPopup = 1 then %>
			    cbs_confirm("Do you want to prepay this invoice", doneYes, doneNo);
			<% else %>
			    doDone(false);
			<% end if %>
		}
	}

	function doneYes() {
        clearConfirmMsg();
        doDone(true);
	}

	function doneNo() {
        clearConfirmMsg();
        doDone(false);
	}

    function doDone(sendToPrepay) {
	    if (sendToPrepay)
		    document.heatSealForm.action = "?userAction=submit&prepay=1";
		else
            document.heatSealForm.action = "?userAction=submit";
		document.heatSealForm.submit();
    }



	function validateHeatSeals(){
		var hsList, hsCount;
		var hsNumber;
		var intloop;

		for (intloop=1; intloop<document.heatSealForm.length; intloop++) {
			var e = document.heatSealForm.elements[intloop];
			if ((e.type == "text") || (e.type == "textarea")) {
				if ((e.value == null) || (e.value == "") || isBlank(e.value)) {
					show_focus("Please enter heat seal numbers in all boxes.", "Heat Seal Number",  e);
					return false;
				}
				else if (!isStrInteger(e.value)) {
					show_focus("Please enter numeric heat seal numbers in all boxes.", "Heat Seal Number", e);
					return false;
				}
				else if (trim(e.value).length < <%= hsLengthMin %> || trim(e.value).length > <%= hsLengthMax %>) {
				    <% if hsLengthMin = hsLengthMax then %>
				    show_focus("Heat Seal number must be <%= hsLengthMin %> digits long.", "Heat Seal Number", e);
				    <% else %>
					show_focus("Heat Seal number must be between <%= hsLengthMin %> and <%= hsLengthMax %> digits long.", "Heat Seal Number", e);
					<% end if %>
					return false;
				}
				else if (!isValidRange(e.value)) {
					show_focus("Heat Seal number is not within the valid range.  Possible bad scan or wrong heat seal scanned.","Heat Seal Number", e);
					return false;
				}
			}
		}
		return true;
	}

	function setFocusHS()
	{
		 //$("#hs:last").focus();
		 $('form table input#hs[value=""]:first').focus();
	}

	function isValidRange(hs)
	{
		var hs1Str = document.heatSealForm.hsStart.value;
		var hs2Str = document.heatSealForm.hsEnd.value;
		var hs1, hs2, i, isValid;
		hs1 = hs1Str.split("|");
		hs2 = hs2Str.split("|");
		isValid = false;

		for(i=0; i<hs1.length; i++)  {
			isValid = isValid || (hs >= hs1[i] && hs <= hs2[i]);
			}

		return isValid;
	}



	function checkEnter()
	{
		var code = 0;
		code = event.keyCode;
		if (code==13)
		{
			event.keyCode = 9;
            var $this = $(event.target);
            var index = parseFloat($this.attr('data-index'));
            $('[data-index="' + (index + 1).toString() + '"]').focus();
		}
	}


	function cancelHeatSeal() {
		document.heatSealForm.action = "detailedInvoice.asp";
		document.heatSealForm.submit();
	}


</script>

<BODY topmargin=0 leftmargin=0 onLoad="setFocusHS();">
<!-- #include file="../include/banner.inc" -->
<H1>Heat Seal Information&nbsp;<%=sInvoicenumber%>&nbsp;</H1>
<FORM id="heatSealForm" name="heatSealForm" action="heatSeal.asp" method="post" onSubmit="return false">
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<INPUT type="hidden" name="txtDueDate" value="<%= dueDate %>">
	<INPUT type="hidden" name="isDueDateSet" value="<%= dueDateSet %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	<INPUT type="hidden" name="hsStart" value="<%= hsStart %>">
	<INPUT type="hidden" name="hsEnd" value="<%= hsEnd %>">
	<TABLE ALIGN=center WIDTH="800px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >

		<tr align=left>
			<td></td>
			<th>Department</th>
			<th>Item</th>
			<th>Heat Seal Number</th>
		</tr>
		<%
			dim fieldCounter, cnt
			set invLineItems = invoice.lineItems

			if invLineItems.RecordCount > 0 then
				invLineItems.Filter = "itemType='IT'"
				datalines = invLineItems.RecordCount
				cnt = 0
				if invLineItems.RecordCount > 0 then
					fieldCounter = 1
						set itemsHeatSealInfo =  invoice.rstHeatSealInfo
						if itemsHeatSealInfo.Recordcount > 0 then
							itemsHeatSealInfo.MoveFirst
							while not itemsHeatSealInfo.eof
								itemsHeatSealInfo.Fields("used") = 0
							itemsHeatSealInfo.Movenext
							wend
						end if
					invLineItems.MoveFirst
					while not invLineItems.EOF
						if Not invLineItems.Fields("saleOnly").Value then
							counter = 1
							itemQuantity = invLineItems.Fields("quantity").Value * invLineItems.Fields("pkgQuantity").Value
							itemName = invLineItems.Fields("itemName").Value
							deptName = invLineItems.Fields("deptName").Value
							itemID = invLineItems.Fields("lineItemId").Value
							deptId = invLineItems.Fields("deptId").Value
							lineNumber = invLineItems.Fields("lineNumber").Value

							while counter <= itemQuantity
					            cnt = cnt + 1
					            if doesDeptUseHS(deptId) then
								exists = false
								heatsealNumber = ""
									if itemsHeatSealInfo.RecordCount > 0 then
										itemsHeatSealInfo.Filter = "lineNumber=" & lineNumber
										if itemsHeatSealInfo.Recordcount > 0 then
											itemsHeatSealInfo.Movefirst
											while not itemsHeatSealInfo.Eof and not exists
												if itemsHeatSealInfo.Fields("used") = 0 then
													exists = true
													itemsHeatSealInfo.Fields("used") =1
													heatsealNumber = itemsHeatSealInfo.Fields("heatSealID").Value
												end if
												itemsHeatSealInfo.MoveNext
											wend
										end if
										itemsHeatSealInfo.Filter = ""
									end if            %>

									<% if counter = 1 then %>
										<tr>
										<td>
											<input type="hidden" checked name="select" id="select"  value="<%= itemId & "|||" & itemName & "|||" & itemQuantity & "|||" & lineNumber%>" >
										</td>
										<td class="label"><%= deptName%></td>
										<td class="label"><%= itemName%></td>
									<% end if %>
														<td>
	                                                       	<INPUT id="hs" name="<%=lineNumber & "txtHeatSealNo" & counter%>"  data-index="<%=cnt%>" class=text style="width:200px;" onKeyDown="checkEnter();" value="<% if heatsealNumber <> -1 then Response.Write heatsealNumber end if%>"<% if heatsealNumber <> -1 and heatsealNumber <> "" then %> readonly <%end if %>>
	                                            		</td>

			<%                         if counter = itemQuantity then    %>
									   </tr>
			<%
									      set invItemDescriptors = invoice.lineItems.clone()
									      if invItemDescriptors.RecordCount > 0 then
									            invItemDescriptors.Filter = "itemType in ('CO','PA','UP')"
									            invItemDescriptors.Filter = "parentlinenumber = " & lineNumber
									            if invItemDescriptors.RecordCount > 0 then
									                  invItemDescriptors.MoveFirst
									                  while not invItemDescriptors.EOF    %>
									                        <tr><td></td><td></td>
									                              <td> <input name="<%=lineNumber & "desc"%>" type=hidden value="<%=invItemDescriptors.Fields("itemType").Value & "|||" & invItemDescriptors.Fields("itemName").Value%>"> <%=invItemDescriptors.Fields("itemName").Value%>
									                              </td>
									                        </tr>
									<%                invItemDescriptors.MoveNext
									                  wend
									            end if
									            end if
									      end if
									end if
									counter =  counter + 1
								wend
							end if
						invLineItems.MoveNext
						wend
					end if
				end if
		%>
	</table>
	<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=20px><td></td></tr>
		<tr>
			<td align="center" width="60px">
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick= "submitForm()">
			</td>
			<td align="center" width="60px">
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelHeatSeal();">
			</td>
		</tr>

	</table>

	<INPUT type="hidden" name="fieldCounter" value="<%= fieldCounter %>">
	<INPUT type="hidden" name="datalines" value="<%= datalines %>">
</BODY>
</HTML>

<%


function InsertMissingHeatSealNumbers()
	'Extract heat seal numbers entered by the user.
	'Check to see if they exist in the database, HeatSealItem table.
	'If they don't exist, INSERT them.

	dim intLoop, intLoop2, intLoop3
	dim itemName
	dim hsNumber
	dim itemId
	dim itemInfo
	dim itemSplitArray
	dim sqltxt
	dim newTaggedItemID
	dim lineNumber
	dim descInfo
	dim descSplitArray
	dim descType
	dim descName
	if Request.Form("select").Count > 0 then
		for intLoop=1 to Request.Form("select").Count
			itemInfo = Request.Form("select")(intLoop)
			itemSplitArray = Split(itemInfo,"|||")
			itemId = itemSplitArray(0)
			itemName = itemSplitArray(1)
			fieldCounter = itemSplitArray(2)
			lineNumber = itemSplitArray(3)
			'Inserting Item into TaggedItem
			sqltxt = "SET NOCOUNT ON;"
            sqltxt = sqltxt & "insert into TaggedItem(occupationpercent,pricelistItemID) "_
            	   & " VALUES( 25*" & fieldcounter & ","_
            	   & itemID & ");"
            sqltxt = sqltxt & "SELECT SCOPE_IDENTITY();SET NOCOUNT OFF;"
            dbstartTrans()
            newTaggedItemID = QryExecuteWithTransAndSelect(sqltxt)
            dbEndTrans()
            'Inserting Item Descriptors into TaggedItemDescriptor
            for intLoop2 = 1 to Request.Form(lineNumber&"desc").Count
            	descInfo = Request.Form(lineNumber&"desc")(intLoop2)
            	descSplitArray = Split(descInfo,"|||")
            	descType = descSplitArray(0)
            	descName = descSplitArray(1)
            	sqltxt = "insert into TaggedItemDescriptor(taggedItemID, descriptorName, descriptorType) "_
            		   & " VALUES( " & newTaggedItemID & ",'" & descName & "','" & descType & "')"
            	on error resume next
            	OpenConnection
            	dbInsert sqltxt
            	CloseConnection
               if err.number <> 0 then
                     Session("errorMessage") = "Error while saving TaggedItemDescriptors : " & err.Description
                     Response.Redirect "invoiceErrorMessages.asp"
               end if
            next
	 		for intLoop3 = 1 to fieldCounter
	            hsNumber = Request.Form(lineNumber&"txtHeatSealNo"&intLoop3)
	            if Not IsEmpty(hsNumber) or Trim(hsNumber) <> "" then
	                  'Check and insert
	                  If Not IsHeatSealExisting(hsNumber) Then
	                        Dim isql
	                        isql = "INSERT INTO TaggedPiece(heatSealID, TaggedItemID) " & _
	                                 " VALUES('" & hsNumber & "', " & newTaggedItemID & ")"
	                        on error resume next
	                        OpenConnection
	                        dbInsert isql
	                        CloseConnection
	                        if err.number <> 0 then
	                              Session("errorMessage") = "Error while saving heatseal numbers : " & err.Description
	                              Response.Redirect "invoiceErrorMessages.asp"
	                        end if
	                  else
	                        isql = "update TaggedPiece set taggeditemid = " & newTaggedItemID & _
	                                 " where heatsealid = '" & hsNumber & "'"
	                        on error resume next
	                        OpenConnection
	                        QryExecute isql
	                        CloseConnection
	                        if err.number <> 0 then
	                              Session("errorMessage") = "Error while updating heatseal numbers : " & err.Description
	                              Response.Redirect "invoiceErrorMessages.asp"
	                        end if
	                  End If
	            end if
			next
		next
	else
		'Response.Write "No heatseals"
	end if

end function

Function IsHeatSealExisting(hsn)
	Dim sql, rs

	IsHeatSealExisting = False

	sql = "SELECT COUNT(heatSealID) as 'cnt' FROM TaggedPiece WHERE heatSealID = '" & hsn & "'"
	'Response.Write sql & "<BR>"
	Set rs = getDisconnectedRecordSet(sql)
	if not rs is nothing and not rs.EOF and not rs.BOF then
		rs.MoveFirst
		IsHeatSealExisting = (clng(rs("cnt").Value) > 0)
	end if
	'Response.Write "IsHeatSealExisting = " & IsHeatSealExisting & "<BR>"
End Function

    function doesDeptUseHS(deptId)
        dim query, rs
        query = "select useHeatSeals from Department where departmentId = " & deptId
        set rs = getdisconnectedrecordset(query)
        doesDeptUseHS = rs("useHeatSeals")
    end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

%>