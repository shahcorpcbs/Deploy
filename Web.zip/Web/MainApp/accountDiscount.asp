<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<%
	dim query, rs
	dim accountDiscountID
	dim customerSeq
	dim routeNumber

	customerSeq = getReqVar("customerSeq")
	routeNumber = getReqVar("routeNumber")
	accountDiscountID = getReqVar("accountDiscountID")
	
	if accountDiscountID = "" then
		accountDiscountID = getAccountDiscountForTarget()
	end if
	
	select case lcase(request.querystring("useraction"))
	case "add"
		accountDiscountID = getAccountDiscountID()
		addAccountDiscount accountDiscountID, request.form("departmentName"), request.form("lineType"), request.form("discount")
		assignAccountDiscountToTarget accountDiscountID
	case "remove"
		removeSelectedItems request.form("selectedItem")
	case "exit"
		returnToOrigin
	end select

	function returnToOrigin()
		if customerSeq <> "" then
			response.redirect "customerdiscount.asp?customerseq=" & customerSeq
		elseif routeNumber <> "" then
			response.redirect "/setup/RouteAddEdit.asp?routeid=" & routeNumber
		else
			response.redirect "start2.asp"
		end if
	
	end function

	function removeSelectedItems(accountDiscountItemIDs)
		dim query

		query = " delete accountdiscountitem where accountdiscountitemid in (" & accountDiscountItemIDs & ")"

		qryexecute query
	end function
	
	function addAccountDiscount(accountDiscountID, departmentName, lineType, discount)
		dim query, rs

		
		if accountDiscountID <> "" then
		
			query = " delete accountdiscountitem where "
			query = query & " accountDiscountID = " & accountDiscountID

			if trim(departmentName) <> "" then
				query = query & " and departmentName = " & DbCreateQryString(departmentName)
			else
				query = query & " and departmentName is null "
			end if

			if trim(lineType) <> "" then
				query = query & " and lineItemType = " & DbCreateQryString(lineType)
			else
				query = query & " and lineItemType is null "
			end if

			qryexecute query

			query = " insert into accountdiscountitem (accountDiscountID, departmentName, lineItemType, discount) "
			query = query & " values ( "
			query = query & accountDiscountID
			query = query & ", " & DbCreateQryString(departmentName)
			query = query & ", " & DbCreateQryString(lineType)
			query = query & ", " & discount
			query = query & " ) "

			qryexecute query
		end if
	end function

	function getAccountDiscountForTarget()
		dim query, rs
		
		if customerSeq <> "" then
			query = " select accountDiscount from customer where customersequencenumber = " & customerSeq
		elseif routeNumber <> "" then
			query = " select accountDiscountID as accountDiscount from route where routeNumber = " & routeNumber
		end if

		if query <> "" then
			set rs = getdisconnectedrecordset(query)
			if rs.recordcount > 0 then
				if rs("accountDiscount") > 0 then
					getAccountDiscountForTarget = rs("accountDiscount")
				end if
			end if
		end if
	end function
	
	function assignAccountDiscountToTarget(accountDiscountID)
		dim query, rs
		
		if customerSeq <> "" then
			query = " update customer set accountDiscount = " & accountDiscountID
			query = query & " where customersequencenumber = " & customerSeq
		elseif routeNumber <> "" then
			query = " update route set accountDiscountID = " & accountDiscountID
			query = query & " where routeNumber = " & routeNumber
		end if

		if query <> "" then
			qryexecute query
		end if
	end function
		
	function getTargetName()
		dim query, rs
		
		if customerSeq <> "" then
			query = " select customername as name from customer where customersequencenumber = " & customerSeq
		elseif routeNumber <> "" then
			query = " select name from route where routenumber = " & routeNumber
		end if
		
		getTargetName = "UNKNOWN"
		
		if query <> "" then
			set rs = getdisconnectedrecordset(query)
			if rs.recordcount > 0 then
				getTargetName = rs("name")
			end if
			set rs = nothing
		end if
	end function
		
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	function getAccountDiscountID()
		if accountDiscountID = "" then accountDiscountID = createNewAccountDiscount("")
		getAccountDiscountID = accountDiscountID
	end function
	

	function createNewAccountDiscount(description)
		dim query, rs
		
		openConnection
		
		query= " insert into AccountDiscount (Description) "
		query = query & " values ('" & DBStr(description)& "')"
	
		
		dbInsert query
	
		set rs = dbSelect("select @@IDENTITY as NewID")
		createNewAccountDiscount = rs("NewID")
	
		set rs = nothing
		
		closeConnection
	end function
%>

<html>
<head>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT language="javascript" type="text/javascript">

	function exit() {
		document.accountDiscount.action = "?useraction=exit";
		document.accountDiscount.submit();
	}
	
	function addItem() {
		document.accountDiscount.action = "?useraction=add";
		document.accountDiscount.submit();
	}
	
	
	function removeSelectedItems() {
		document.accountDiscount.action = "?useraction=remove";
		document.accountDiscount.submit();
	}
	
	function SetRowCheckedStatus(row, check, value) {

		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "selectedItem") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "selectedItem") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}
	
</SCRIPT>


</head>

<body STYLE="margin:0;padding:0" onload="accountDiscount.discount.focus()">
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->

<H1>Account Discount For <%=Server.HTMLEncode(getTargetName())%></H1>

<form id="accountDiscount" name="accountDiscount" method="post" onsubmit="return false">

<input type="hidden" name="accountDiscountID" value="<%=accountDiscountID%>">
<input type="hidden" name="customerSeq" value="<%=customerSeq%>">
<input type="hidden" name="routeNumber" value="<%=routeNumber%>">

<table cellpadding="5">
	<tr>
		<td>
			Department<br />
			<select name="departmentName">
				<option value="">All</option>
			<%
				query = " select distinct name as departmentname from department "
				set rs = getdisconnectedrecordset(query)
			
				while not(rs.eof or rs.bof)
			%>
				<option value="<%=rs("departmentname")%>"><%=Server.HTMLEncode(rs("departmentname"))%></option>
			<%
					rs.movenext
				wend
				set rs = nothing
			%>
			</select>
		</td>
		<td>
			Line Type<br />
			<select name="lineType">
				<option value="">All</option>
			<%
				query = " select ticketlinetype, ticketlinetypename from ticketlinetypedomain "
				set rs = getdisconnectedrecordset(query)
			
				while not(rs.eof or rs.bof)
			%>
				<option value="<%=rs("ticketlinetype")%>"><%=Server.HTMLEncode(rs("ticketlinetypename"))%></option>
			<%
					rs.movenext
				wend
				set rs = nothing
			%>
			</select>
		</td>
		<td>
			Discount<br />
			<input name="discount" style="width:50px">
		</td>
		<td>
			<input type="button" style="width:100px;height:40px" value="Add" onclick="addItem()" >
		</td>
	</tr>
</table>

<div name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<span style="float:left">
		<button onclick="removeSelectedItems()">Remove</button>
	</span>
	<span style="float:right">
		<button onclick="exit()">Exit</button>
	</span>
</div>	

<table class="itable" width="100%" cellspacing="0" cellpadding="0">
<tr>
	<th>&nbsp;</th>
	<th align="left">Department</th>
	<th align="left">Line Type</th>
	<th align="left">Discount</th>
</tr>

<%
	if accountDiscountID <> "" then
	
	query = " select accountdiscountitemid, discount, isnull(departmentname, 'All') as departmentname, isnull(ticketlinetypedomain.ticketlinetypename, 'All') as ticketlinetypename  from accountdiscountitem "
	query = query & " left outer join ticketlinetypedomain on accountdiscountitem.lineitemtype = ticketlinetypedomain.ticketlinetype "
	query = query & " where accountdiscountid = " & accountDiscountID

	set rs = getdisconnectedrecordset(query)

	while not(rs.eof or rs.bof)
%>
<tr onclick="ToggleRowChecked(this)" >
	<td><input type="checkbox" name="selectedItem" onclick="ToggleRowChecked(this.parentNode.parentNode);" value="<%=rs("accountdiscountitemid")%>" /></td>
	<td><%=Server.HTMLEncode(rs("departmentname"))%></td>
	<td><%=Server.HTMLEncode(rs("ticketlinetypename"))%></td>
	<td><%=Server.HTMLEncode(rs("discount") & "%")%></td>
</tr>
<%
		rs.movenext
	wend
	set rs = nothing
	
	end if
%>


</table>

</form>
</body>
</html>
