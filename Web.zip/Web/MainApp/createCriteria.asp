<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->

<%
    dim query, rs
    dim isSubmitted
    dim criteriaID

    isSubmitted = Request.QueryString("submitted")

	if isSubmitted then
		buildCustomerSeqCVS()
		Response.Redirect "chooseTemplate.asp"
	end if
		    
    function buildCustomerSeqCVS()
        dim  rs, query, query2
        dim criteria
      
		'Write criteria to the database
        query = "insert into MarketingLettersCriteria(dateRan, searchName, msDateBegin, msDateEnd, msMoreOrLess, msValue, " 
        query = query & "icDateBegin, icDateEnd, icMoreOrLess, icValue, eType, eDateBegin, eDateEnd, ciDateBegin, ciDateEnd, ciRackedOrNot, "
        query = query & "ciMoreOrLess, ciValue, rMoreOrLess, rValue, rtNumber, expired, expDate) "
        query = query & "values(getdate(), '" & Request.Form("sName") & "'"
        if Request.Form("msValue") <> "" and Request.Form("msDateBegin") <> "" and Request.Form("msDateEnd") <> "" then
			query = query & ",convert(datetime, '" & Request.Form("msDateBegin") & "')"
			query = query & ",convert(datetime, '" & Request.Form("msDateEnd") & "')"
			query = query & ",'" & Request.Form("msMoreOrLess") & "', " & Request.Form("msValue") 
		else
			query = query & ",null, null, null, null"
		end if
        if Request.Form("icValue") <> "" and Request.Form("icDateBegin") <> "" and Request.Form("icDateEnd") <> "" then
			query = query & ",convert(datetime, '" & Request.Form("icDateBegin") & "')"
			query = query & ",convert(datetime, '" & Request.Form("icDateEnd") & "')"
			query = query & ",'" & Request.Form("icMoreOrLess") & "', " & Request.Form("icValue") 
		else
			query = query & ",null, null, null, null"
		end if
        if Request.Form("eType") <> "" and Request.Form("eDateBegin") <> "" and Request.Form("eDateEnd") <> "" then
			query = query & ", '" & Request.Form("eType") & "'"
			query = query & ",convert(datetime, '" & Request.Form("eDateBegin") & "')"
			query = query & ",convert(datetime, '" & Request.Form("eDateEnd") & "')"
		else
			query = query & ",null, null, null"
		end if
        if Request.Form("ciValue") <> "" and Request.Form("ciDateBegin") <> "" and Request.Form("ciDateEnd") <> "" then
			query = query & ",convert(datetime, '" & Request.Form("ciDateBegin") & "')"
			query = query & ",convert(datetime, '" & Request.Form("ciDateEnd") & "')"
			query = query & ",'" & Request.Form("ciRackedOrNot") & "','" & Request.Form("ciMoreOrLess") & "', " & Request.Form("ciValue") 
		else
			query = query & ",null, null, null, null, null"
		end if
        if Request.Form("rValue") <> "" then
			query = query & ",'" & Request.Form("rMoreOrLess") & "'"
			query = query & "," & Request.Form("rValue")
		else
			query = query & ",null, null"
		end if				
        if Request.Form("rtNumber") <> "" then
			query = query & ",'" & Request.Form("rtNumber") & "'"
        else
			query = query & ",null"
		end if
		if Request.Form("expired") = "1" then
			query = query & ",'" & Request.Form("expired") & "'"
			query = query & ",convert(datetime, '" & Request.Form("expDate") & "')) "
		else
			query = query & ",null,null)"
		end if		
		'Response.Write("query: "+query)
		qryexecute query		
		
		query = "select scope_identity() as criteriaID"
		set rs = getDisconnectedRecordSet(query)
		if rs.recordcount > 0 then
			criteriaID = rs("criteriaID")
		end if
		set rs = nothing	

        criteria = buildCriteria()
        'Response.Write("criteria:  "+criteria)

	    buildCustomerSeqCVS = ""
        
        if criteria <> "" then
            query = "delete from marketingLettersCSN"
            qryexecute query

            query = "select customersequencenumber from customer where " & criteria        
            set rs = getdisconnectedrecordset(query)

            if rs.recordcount > 0 then
                while not rs.eof
					query2 = "insert into marketingLettersCSN values(" & rs("customerSequenceNumber") & ")"
					qryexecute query2
	                'buildCustomerSeqCVS = Append(buildCustomerSeqCVS, rs("customersequencenumber"), ",")
                    rs.movenext
                wend
            end if
 
            set rs = nothing
            
        end if
    end function

    function Append(pre, post, divider)
        if post <> "" then
            if pre <> "" then
                Append = pre & divider & post
            else
                Append = pre & post
            end if
            
        else
            Append = pre
        end if
    end function
    
    function buildCriteria()
        buildCriteria = ""
        buildCriteria = Append(buildCriteria, cri_ms(), " and ")
        buildCriteria = Append(buildCriteria, cri_ic(), " and ")
        buildCriteria = Append(buildCriteria, cri_e(), " and ")
        buildCriteria = Append(buildCriteria, cri_r(), " and ")
        buildCriteria = Append(buildCriteria, cri_ci(), " and ")
        buildCriteria = Append(buildCriteria, cri_rt(), " and ")
        buildCriteria = Append(buildCriteria, cri_exp(), " and ")
    end function
    
    function cri_ms()
        if Request.Form("msValue") <> "" and Request.Form("msDateBegin") <> "" and Request.Form("msDateEnd") <> "" then
            cri_ms = " dbo.getCustomerSales(customersequencenumber, "
            cri_ms = cri_ms & "'" & Request.Form("msDateBegin") & "', "
            cri_ms = cri_ms & "'" & Request.Form("msDateEnd") & "') "
            cri_ms = cri_ms & Request.Form("msMoreOrLess") & " "
            cri_ms = cri_ms & Request.Form("msValue") & " "
        end if
    end function
    
    function cri_ic()
        if Request.Form("icValue") <> "" and Request.Form("icDateBegin") <> "" and Request.Form("icDateEnd") <> "" then
            cri_ic = " dbo.getCustomerVisits(customersequencenumber, "
            cri_ic = cri_ic & "'" & Request.Form("icDateBegin") & "', "
            cri_ic = cri_ic & "'" & Request.Form("icDateEnd") & "') "
            cri_ic = cri_ic & Request.Form("icMoreOrLess") & " "
            cri_ic = cri_ic & Request.Form("icValue") & " "
        end if
    end function
    
    function cri_ci()
        if Request.Form("ciValue") <> "" and Request.Form("ciDateBegin") <> "" and Request.Form("ciDateEnd") <> "" then
            cri_ci = " dbo.getCustomerOpenInvoices(customersequencenumber, "
            cri_ci = cri_ci & "'" & Request.Form("ciRackedOrNot") & "', "
            cri_ci = cri_ci & "'" & Request.Form("ciDateBegin") & "', "
            cri_ci = cri_ci & "'" & Request.Form("ciDateEnd") & "') "
            cri_ci = cri_ci & Request.Form("ciMoreOrLess") & " "
            cri_ci = cri_ci & Request.Form("ciValue") & " "
        end if
    end function
    
    function cri_e()
        if Request.Form("eType") <> "" and Request.Form("eDateBegin") <> "" and Request.Form("eDateEnd") <> "" then
            cri_e = " " & Request.Form("eType") & " between "
            cri_e = cri_e & "convert(datetime, '" & Request.Form("eDateBegin") & "') and "
            cri_e = cri_e & "convert(datetime, '" & Request.Form("eDateEnd") & "') "
        end if
    end function
    
    function cri_rt()
        if Request.Form("rtNumber") = "" then
        
        elseif Request.Form("rtNumber") = "all" then
            cri_rt = " routeNumber > 0 "
        elseif Request.Form("rtNumber") >= 0 then
            cri_rt = " routeNumber = " & Request.Form("rtNumber") & " "
        end if
    end function
    
    function cri_r()
        if Request.Form("rValue") <> "" then
            cri_r = "dbo.getCustomerRating(customersequencenumber) * 100.00 "
            cri_r = cri_r & Request.Form("rMoreOrLess") & " "
            cri_r = cri_r & Request.Form("rValue") & " "
        end if
    end function
    
    function cri_exp()
		if Request.Form("expired") = "1" then
			cri_exp ="dbo.getCustomerCCExpiryDate(customersequencenumber) < "
            cri_exp = cri_exp & "convert(datetime, '" & Request.Form("expDate") & "') "
			
		end if
	end function
			
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Create Marketing List Criteria</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

<style>
<!--

.txtNumber {
   width:50px;
   text-align:right;
}

.txtDate {
   width:76px;
   text-align:center;
}
-->
</style>

</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">

	function selectDate(element) {

		show_calendar("marketingCriteria." + element.name);
	}
	
	function submitForm() {
		if (validateForm() == true) {		
			document.marketingCriteria.action = "?submitted=true";
			document.marketingCriteria.submit();
		}	
	}   

	function isSpace(obj) {
		if(obj.value.indexOf(' ') != -1){
			cbsAlert("Name cannot contain a space",cbsExclamation,"Enter search name (no spaces)");
			obj.focus();
		}
	}
	
	function validateForm() {
		if (trim(document.marketingCriteria.sName.value).length < 1){
			cbsAlert("Please enter a name to save search",cbsExclamation,"Enter search name");
			document.marketingCriteria.sName.focus();
			return false;
		}
		if (trim(document.marketingCriteria.rValue.value).length > 0){
			if((document.marketingCriteria.rValue.value > 99) || (document.marketingCriteria.rValue.value < 1)){
				cbsAlert("Please enter a value between 1 and 99",cbsExclamation,"Enter rating value");
				document.marketingCriteria.rValue.focus();
				return false;
			}
			return true;
		}	 
		return true;
	}
	
	function cancelForm() {
	    document.marketingCriteria.action = "managerMenu.asp";
	    document.marketingCriteria.submit();
	}   
    
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/localprinter.inc" -->
<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">&nbsp;Create Marketing List Criteria</B>
<FORM id="marketingCriteria" name="marketingCriteria" action="" method="Post">
	<INPUT type=hidden name=isSubmitted value=<%=isSubmitted%>>
<center>
<table class=optTable cellpadding=3 style="display:block">

<tr>
    <td><b>Money Spent</b></td>

    <td>
        <select name="msMoreOrLess">
            <option value=">=">More</option>
            <option value="<">Less</option>
        </select>
        than
        <input name="msValue" class=txtNumber></input>
        dollars
    </td>
    
    <td>
        between <input name="msDateBegin" onclick="selectDate(this);" class=txtDate></input> and <input name="msDateEnd" onclick="selectDate(this);" class=txtDate></input>
    </td>
</tr>

<tr>
    <td><b>Invoices Out</b></td>
    <td>
        <select name="icMoreOrLess">
            <option value=">=">More</option>
            <option value="<">Less</option>
        </select>
        than
        <input name="icValue" class=txtNumber></input>
    </td>
    <td>
        between <input name="icDateBegin" onclick="selectDate(this);" class=txtDate></input> and <input name="icDateEnd" onclick="selectDate(this);" class=txtDate></input>
    </td>
</tr>

<tr>
    <td><b>Event</b></td>

    <td>
        <select name="eType">
            <option value=""></option>
            <option value="birthdate">Birthday</option>
            <option value="createddate">First Visit</option>
            <option value="lastvisited">Last Visit</option>
        </select>
        occurred
    </td>
    
    <td>
        between <input name="eDateBegin" onclick="selectDate(this);" class=txtDate></input> and <input name="eDateEnd" onclick="selectDate(this);" class=txtDate></input>
    </td>
</tr>

<tr>
    <td><b>Open Invoices</b></td>

    <td>
        <select name="ciRackedOrNot">
            <option value="-1">All</option>
            <option value="1">Racked</option>
            <option value="0">Not Racked</option>
        </select>
        due
        <select name="ciMoreOrLess">
            <option value=">=">More</option>
            <option value="<">Less</option>
        </select>
        than
        <input name="ciValue" class=txtNumber></input>
    </td>
    
    <td>
        between <input name="ciDateBegin" onclick="selectDate(this);" class=txtDate></input> and <input name="ciDateEnd" onclick="selectDate(this);" class=txtDate></input>
    </td>
</tr>

<tr>
    <td><b>Rating</b></td>
    
    <td>
        <select name="rMoreOrLess">
            <option value=">=">More</option>
            <option value="<">Less</option>
        </select>

        than
        <input name="rValue" class=txtNumber></input>
    </td>
</tr>

<tr>
    <td><b>Route</b></td>
    
    <td>
        <select name="rtNumber">
            <option value=""></option>
            <option value="all">All</option>
        <%
            query = "select routenumber, name from route where storeid = " & session("storeid")
            set rs = getdisconnectedrecordset(query)
            
            while not(rs.eof or rs.bof)
        %>
            <option value="<%=rs("routeNumber")%>"><%=rs("name")%></option>
        <%
            rs.movenext
            wend
            set rs = nothing
        %>
        </select>
    </td>
</tr>

<tr>
    <td><b>Expired Credit Cards</b></td>
    
    <td>
        <select name="expired">
            <option value=""></option>
            <option value="1">Expired</option>
        </select>
        before <input name="expDate" onclick="selectDate(this);" class=txtDate></input>        
    </td>
</tr>

<tr>
    <td><b>Save Search as (Name)</b></td>
    
    <td>
        <input name="sName" onKeyUp="isSpace(this)" ></input>        
    </td>
</tr>


<tr>
	<td colspan=3 align="center">
		<input type="button" value="Cancel" onclick="cancelForm();" style="width:100px;height:50px;margin-top:40px;"></input>
		<input type="button" value="Ok" onclick="submitForm();" style="width:100px;height:50px;margin-top:40px;"></input>
	</td>
</tr>

</table>

</center>

</FORM>   
</BODY>
</HTML>