<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%

    dim query, rs
    dim cc_url, cc_key
	dim cardPaymentId, paymentType, paymentNumber, custSeqNum
	dim isSubmitted

	cardPaymentId = Request.QueryString("cardPaymentId")
	paymentNumber = Request.QueryString("paymentNumber")
	paymentType = Request.QueryString("paymentType")
    isSubmitted = Request.QueryString("submitted")

    if isSubmitted then
        if paymentType = "Credit Card" then
            addCCVoid
        end if
        addPaymentVoid
        Response.Redirect("cardPaymentVoidList.asp")
    end if



    if paymentType = "Credit Card" then

        query = " select rawanswer, isnull(customer.customername, '') as customername, cardpayment.customerSequenceNumber as custSeqNum from cardpayment "
        query = query & " left outer join customer on cardpayment.customersequencenumber = customer.customersequencenumber "
        query = query & " where cardpaymentId = " & cardPaymentId
        set rs = getdisconnectedrecordset(query)

		dim raw
		raw = rs("rawanswer")

        if Left(raw, 1) = chr(34) then
            raw = Left(raw, Len(raw) - 1)
            raw = Right(raw, Len(raw) - 1)
			raw = replace(raw, "\", "")
        end if
        if Left(raw, 1) = "," then
            raw = Right(raw, Len(raw) - 2)
        end if


        custSeqNum = rs("custSeqNum")
        determineProcessor

    else
        query = " select isnull(customer.customername, '') as customername, "
        query = query & " paymentDate, amountPaid, payment.paymentTypeName, checkOrCardNumber from payment "
        query = query & " left outer join customer on payment.customersequencenumber = customer.customersequencenumber "
        query = query & " where paymentNumber = " & paymentNumber
        set rs = getdisconnectedrecordset(query)

    end if


    sub addPaymentVoid
    on error resume next

        Dim data, httpRequest, postResponse
        dim notificationIP

        notificationIP = getMessengerShortPath()


        query = "update payment set reversed = 1 where paymentNumber = " & paymentNumber
        qryexecute query

        query = "EXECUTE dbo.VoidPayment @PaymentType = '" & paymentType &"', "
        query = query & "@SalePaymentNumber = " & paymentNumber & ", "
        query = query & "@EmployeeID = " & session("employeeid") & ", "
        query = query & "@TerminalID = " & Session("terminalID")
        if paymentType = "Credit Card" then
            query = query & ", @CardPaymentID = " & cardPaymentId
        end if

        qryexecute query

    if paymentType = "Credit Card" then
        data = "cardPaymentId=" & cardPaymentId
    else
        data = "paymentNumber=" & paymentNumber
    end if

    if isMessengerEnabled() then
        on error resume next
        Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
        httpRequest.Open "POST", getMessengerFullPath("main") & "/voidCreated", False
        httpRequest.SetRequestHeader "Content-Type", "application/x-www-form-urlencoded"
        httpRequest.Send data
        postResponse = httpRequest.ResponseText
    end if

    end sub


	sub addCCVoid()
		dim amountVoided
		dim clerk
		dim terminalId
		dim customerSeq
		dim rawAnswer
		dim pickupObj

		rawAnswer = Request.QueryString("rawAnswer")
		clerk = session("employeeid")
		terminalId = Session("terminalID")
		customerSeq = Request("customerSequenceNumber")
        amountVoided = Request.QueryString("amount")

		query = " insert into cardvoid(cardpaymentId, terminalid, clerk, customersequencenumber, success, amount, rawAnswer) "
        query = query & " values ( "
		query = query & cardPaymentId & ", "
		query = query & terminalid & ", "
		query = query & clerk & ", "
		query = query & customerseq & ", "
		query = query & " 1, "
		query = query & "'" & dbstr(amountVoided) & "', "
		query = query & "'" & dbstr(rawAnswer) & "'"
		query = query & " ) "

		qryexecute query

        query = "update cardpayment set reversed = 1 where cardpaymentid = " & cardPaymentId
        qryexecute query

        query = "select targetRefNumber from PaymentTracking where sourceRefNumber = " & paymentNumber
        set rs = getdisconnectedrecordset(query)
        if rs("targetRefNumber") <> "" then
            query = " insert into ticketlog(ticketNumber, logDate, logType, logComment, additions, storeName, employeeName, terminalId) "
            query = query & " values ( '"
            query = query & rs("targetRefNumber") & "', "
            query = query & "current_timestamp, "
            query = query & "'V', "
            query = query & "'Voided: credit card void', "
            query = query & dbstr(-1 * amountVoided) & ", "
            query = query & "'" & dbstr(session("storeName")) & "', "
            query = query & "'" & dbstr(session("employeename")) & "', "
            query = query & "'" & dbstr(Session("terminalID")) & "'"
            query = query & " ) "
            qryexecute query
        end if

        query = "delete TicketLineItem from TicketLineItem tli left out join EmployeeTip et on et.TicketNumber = "  _
            & "tli.TicketNumber and et.LineItemNumber = tli.LineItemNumber where et.CardPaymentId = " & cardPaymentId
        qryexecute query
        query = "delete EmployeeTip where CardPaymentId = " & cardPaymentId
        qryexecute query
	end sub



    function determineProcessor()
        dim query, rs

        query = " select  Description, URL, API_Key from CreditCardProcessorDomain where CreditCardProcessorDomainID = "
        query = query & "(select top 1 CreditCardProcessorDomainID from MiscSetup)"

        set rs = getdisconnectedrecordset(query)

        if rs.recordcount > 0 then
            if rs("Description") = "Clearent" then
                cc_key = trim(rs("API_Key"))

                query = " select API_Key from Terminal where terminalId = " & Session("terminalID")
                set rs = getdisconnectedrecordset(query)
                if rs("API_Key") <> "" then
			        cc_key = trim(rs("API_Key"))
                end if
                cc_url = getClearentShortPath()
            end if
        end if
    end function
  %>
  <HTML>
  <HEAD>
  <TITLE>Void Payment</TITLE>
  <link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
  <link href="../script/greyscale.css" rel="stylesheet" type="text/css">
  </HEAD>

  <script type="text/javascript" src="/script/webui.js"></script>
  <script type="text/javascript" src="../Script/clearent.js"></script>
  <script type="text/javascript" src="../Script/printing.js"></script>
  <script type="text/javascript" src="../Script/json2.js"></script>
  <script type="text/javascript">

  	function voidTransaction(){
  	    <% if paymentType = "Credit Card" then %>
            $(':button').attr('disabled', true);
            document.getElementById('cardReader').style.display = 'block';
            sendVoidRequest('<%=cc_url%>', '<%=cc_key%>', jsonObj.id)
        <% else %>
            document.voidPaymentForm.action ="?submitted=true" +
                "&paymentType=<%= paymentType %>" +
                "&cardPaymentId=" + encodeURIComponent(<%= cardPaymentId %>) +
                "&paymentNumber=" + encodeURIComponent(<%= paymentNumber %>);
            document.voidPaymentForm.submit();
        <% end if %>
  	}

  	function cancelForm(){
		document.voidPaymentForm.action = "/mainapp/cardPaymentVoidList.asp";
		document.voidPaymentForm.submit();
  	}

    var savAnswer;
  	function voidPaymentSuccess(rawAnswer) {
  	    $(':button').attr('disabled', false);
  	    document.getElementById('cardReader').style.display = 'none';
  	    cbs_alert("Transaction voided", leaveScreen);
  	    savAnswer = rawAnswer;
  	}

  	function leaveScreen() {
  	    clearAlertMsg();
  	    <% if paymentType = "Credit Card" then %>
            PrintCreditCardVoidReceipt('<%= cardPaymentId %>');
            document.voidPaymentForm.action ="?submitted=true" +
                "&amount=" + encodeURIComponent(jsonObj.amount) +
                "&cardPaymentId=" + encodeURIComponent(<%= cardPaymentId %>) +
                "&paymentNumber=" + encodeURIComponent(<%= paymentNumber %>) +
                "&paymentType=<%= paymentType %>" +
                "&customerSequenceNumber=" + encodeURIComponent(<%= custSeqNum %>) +
                "&rawAnswer=" + encodeURIComponent(savAnswer);
                document.voidPaymentForm.submit();
		<% end if %>
  	}

  	function clearentVoidFailed() {
  	    $(':button').attr('disabled', false);
        document.getElementById('cardReader').style.display = 'none';
  	}

  var jsonObj;
  function init() {
    <% if paymentType = "Credit Card" then %>
        jsonObj = JSON.parse('<%= raw %>');
        document.getElementById('tdAmt').innerHTML = jsonObj.amount;
        document.getElementById('tdCT').innerHTML = jsonObj.cardtype;
        document.getElementById('tdLF').innerHTML = "XXXXXXXXXXXX" + jsonObj.lastfour;
        document.getElementById('tdExp').innerHTML = jsonObj.expdate;
        document.getElementById('tdAC').innerHTML = jsonObj.authorizationcode;
    <% end if %>
  }

  </SCRIPT>


  <STYLE type="text/css">
  .freeze { pointer-events: none; }

  .hidden { display: none; }

  .overlay {
    position: absolute;
    z-index: 100;
    padding: 20px;
    background: black;
    color: white;
    border: solid 1px #ccc;
    width: 300px;
    top: 45%;
    left: 35%;
    right: 0;
    margin: auto;
  }
  </STYLE>


  <BODY topmargin=0 leftmargin=0 onLoad="init();">

  <!-- #include file="../include/banner.inc" -->

  <H1>Payment Info</H1>
  <div id="cardReader" class="overlay hidden">
    <h1 style="color: white">Waiting on Response</h1>
  </div>

  <FORM id="voidPaymentForm" name="voidPaymentForm" action="" method="post">

  	<TABLE ALIGN=center BORDER=0 CELLSPACING=10 CELLPADDING=5 style="border:2px ridge" >
  	<th colspan="2">Are You Sure You Want To Void This Transaction?</th>
  	<tr><th style="font-size: 12px" colspan="2">Original invoice(s) will be updated unless set to picked up<br />Consider doing a reverse pickup first if invoice was picked up</th></tr>
  		<TR>
  			<TD class="label" align="right">Customer</TD>
  			<TD align=left> <%= rs("customername") %> </TD>
  		</TR>
  		<% if paymentType = "Credit Card" then %>
            <TR>
                <TD class="label" align="right">Amount</TD>
                <TD align=left id="tdAmt"></TD>
            </TR>
            <TR>
                <TD class="label" align="right">Card Type</TD>
                <TD align=left id="tdCT"></TD>
            </TR>
            <TR>
                <TD class="label" align="right">Card</TD>
                <TD align=left  id="tdLF"></TD>
            </TR>
            <TR>
                <TD class="label" align="right">Expiration Date</TD>
                <TD align=left id="tdExp"> </TD>
            </TR>
            <TR>
                <TD class="label" align="right">Approval Code</TD>
                <TD align=left id="tdAC"></TD>
            </TR>
  		<% else %>
            <TR>
                <TD class="label" align="right">Amount</TD>
                <TD align=left> <%= formatcurrency(rs("amountPaid")) %> </TD>
            </TR>
            <TR>
                <TD class="label" align="right">Payment Date</TD>
                <TD align=left> <%= rs("paymentDate") %> </TD>
            </TR>
            <% if paymentType = "Check" then %>
                <TR>
                    <TD class="label" align="right">Check Number</TD>
                    <TD align=left> <%= rs("checkOrCardNumber") %> </TD>
                </TR>
            <% end if %>

  		<% end if %>
		<TR>
			<TD colspan="2" align=center>
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/OK.gif)" onClick= "voidTransaction()">
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
			</TD>
		</TR>

  	</TABLE>


  </FORM>

  </BODY>
  </HTML>
