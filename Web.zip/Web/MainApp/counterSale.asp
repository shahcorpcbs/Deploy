<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	'****************************************
	'Name   :Counter Sale
    'Author : Poonam Gupta
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 17-Jul-2002    Poonam			Original Version
	'*****************************************************************
	const maxItemsCount = 29
	const maxSubItemCount = 7
	const maxCouponsCount =12
	const maxDeptCount =4
	dim invoice
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim custSeqNumber, custPriceList, custPhone, customerName
	dim actionString
	dim selectedDept
	dim storeId
	dim addOrEdit
	dim curr_LineNo
	dim ObjMiscSetUp
	dim ticketNumber
	dim alertMessage
	dim selItemId
	dim selUpchargeValue, selPatternValue, selColorValue
	dim multiplePickup
	dim upchargeSet
	dim colorSet
	dim patternSet
	
	alertMessage =""
	if Not IsObject(Session("miscSetUp")) then
		initializeMiscSetUp
	end if
	set ObjMiscSetUp = Session("miscSetUp")

	Session("customername") =""
	session("customermainphone") = ""
	storeId = Session("storeId")
	custPriceList = Session("priceList")
	actionString = Request.QueryString("userAction")
	setStartIndexForPaging
	selectedDept = Request.Form("selectedDept")
	curr_LineNo = Request.Form("lineNumber")
	addOrEdit = Request.Form("addOrEdit")
	custSeqNumber = session("customersequencenumber")
	selItemId = Request.Form("selItemId")
	selUpchargeValue = Request.Form("selUpcharge")
	selColorValue = Request.Form("selColor")
	selPatternValue = Request.Form("selPattern")

	if actionString = "create" then
		set invoice = Server.CreateObject("ShahCorpComponents.invoice")
	else
		set invoice = Session("invoice")
	end if

	Select case actionString
			case "create"
						addOrEdit ="add"
						invoice.DBConnectionString = Session("shahcorpDSN")
						set Session("invoice") = invoice
						invoice.isAdd = true
						invoice.amountPaid = 0
						invoice.counterSaleOnly = true
						initialize
						invoice.custSeqNumber = custSeqNumber
						invoice.starchPref = ""
						invoice.finishPref = ""
						invoice.multiPickUpCustName	= ""
						invoice.multiPickUpLoc = ""
						invoice.loadCustomerPreferences custSeqNumber, ""
			case "addshortcutitem"
						addShortcutItem
			case "getItemDetails"
						getItemDetails Request.QueryString("itemId"), Request.QueryString("quantity")
			case "changeQuantity"
						changeQuantity

			case "deleteItem"
						deleteItem
			case "clearInvoice"
					set invoice = Session("invoice")
					invoice.clearInvoice
					if addOrEdit = "edit" then
						invoice.isAdd = false
					end if
					invoice.counterSaleOnly = true
			case "overridePrice"
					overrideLinePrice
			case "addCharge"
					addCharge

			case "getCommonItems"
						set invoice = Session("invoice")
						getCommonItems
			case "addUpcharge"
							addUpCharge
			case "addColor"
							addColor

			case "addPattern"
							addPattern
			case "changeDept"
						set invoice = Session("invoice")
						selectedDept = Request.Form("selectedDept")
						getItemsForDept
			case "getCoupons"
						getCoupons
			case "addCoupon"
						' from coupons page
						addCoupon
			case "nextPage"
					set invoice = Session("invoice")
			case "done"
					'checkForOnDemandCoupon
					invoiceDone
					checkForSplit
			case "newInvoiceNo"
					saveInvoiceWithInvNo
			case "nosplit"
					saveInvoiceWithNoSplit
			case "split"
					saveInvoiceWithSplitAndInvNo
			case "hold"
					holdInvoice
			case "edit"
				ticketNumber = Request.QueryString("ticketNumber")
				addOrEdit ="edit"
				set invoice = Server.CreateObject("ShahCorpComponents.invoice")
				invoice.DBConnectionString = Session("shahcorpDSN")
				set Session("invoice") = invoice
				invoice.getExistingDetails ticketNumber
				if err.number <> 0 then
					set errorList =  Server.CreateObject("Scripting.Dictionary")
					errorList.Add err.number,err.description & " Edit Invoice"
					set session("errorList") = errorList
					Response.redirect("../include/error.asp")
				end if
				invoice.counterSaleOnly = true
				custSeqNumber = invoice.custSeqNumber
				Session("customersequencenumber") = custSeqNumber
				initialize
			case "returnFromNotes"
					attachNotes
			case "cancel"
					'Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
					Response.Redirect "start2.asp"
			case "fromPickup"
					fromPickup
			case "fromOnDemandCoupons"
				fromOnDemandCoupons
			case "getSubItems"
				getSubItems
	end select



	' functions start here


	sub addShortcutItem()
		dim itemid

		itemid = covertShortcutToItem(Request.QueryString("shortcut"))

		if itemid <> "" then
			getItemDetails itemid, 1
		end if
	end sub

	function covertShortcutToItem(shortcut)
		dim query, rs

		covertShortcutToItem = ""

		query = "select pricelistitemid from pricelistitem where saleonly = 1 and itemshortcut = '" & shortcut & "'"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			covertShortcutToItem = rs("pricelistitemid")
		end if

		set rs = nothing
	end function



	sub getSubItems()
		dim lineNo
		dim itemId
		set invoice = Session("invoice")
		lineNo = Request.QueryString("lineNo")
		curr_LineNo = lineNo
		itemId = invoice.getItemIdForLineNo(lineNo)
		if itemId <> -1 then
			getDistinctUpcharges itemId
			getDistinctColors itemId
			getDistinctPatterns itemId
			selUpchargeValue = ""
			selPatternValue = ""
			selColorValue =""
		end if
	end sub

	sub fromOnDemandCoupons()
		dim submit

		set invoice = Session("invoice")
		submit = Request.QueryString("submit")
		if submit = "yes" then
			invoice.applyOnDemandCoupons =true
		else
			invoice.applyOnDemandCoupons = false
		end if
		invoiceDone
		checkForSplit
	end sub

	'sub checkForTags()
	'	dim tagsSameAsInvNos

	'	if ObjMiscSetUp.Count > 0 then
	'		tagsSameAsInvNos = ObjMiscSetUp.Item("sameTagInvNumber")
	'	else
	'		tagsSameAsInvNos = true
	'	end if
	'	if tagsSameAsInvNos then
	'		saveInvoiceToDatabase true
	'	else
	'		Response.Redirect "addTagNumber.asp?addOrEdit=" & addOrEdit
	'	end if
	'end sub

	sub saveInvoiceToDatabase()
		dim empId
		dim terminalId
		dim empName
		dim storeName
		dim invNumber
		dim transactionchangedue
		dim pickupObj
		on error resume next
		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")
		invoice.saveInvoice addOrEdit, empId, terminalId, 0, empName, storeName, true
		
		if trim(request.querystring("useraction")) = "fromPickup" then
			set pickupObj = session("pickupObj")
			pickupObj.applyPayments empId, terminalId, "'" & invoice.getTicketNosForPrinting() & "'" , -1
			transactionchangedue = pickupObj.getChangeDue()
		end if

		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale saveInvoiceToDatabase"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		invNumber = invoice.getTicketNosForPrinting()
		Response.Redirect "customerfunctions.asp?userAction=print&addOrEdit=" _
							& addOrEdit & "&ticketNumber=" & invNumber _
							& "&invoiceType=C&customerseq=" & custSeqNumber _
							& "&totalchangedue=" & transactionchangedue
	end sub

	sub fromPickup()
		dim submit
		dim pickupObj
		
		submit = Request.QueryString("submit")
		
		if trim(request.querystring("useraction")) = "fromPickup" and trim(request.querystring("submit")) <> "cancel" then
			set pickupObj = session("pickupObj")

			If cdbl(pickupObj.getAmountPaid()) >= 0.01 Then
				invoice.applyPrepay True
				invoiceDone
			End If
		End If
		
		if submit = "done" then
			checkForAutoInvNumbers
		else
			cancelDoneOperation
		end if
	end sub

	sub cancelDoneOperation()
		on error resume next
		invoice.cancelDoneOperation
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function=Counter Sale cancelDoneOperation"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub saveInvoiceWithSplitAndInvNo()
		' from prompt to split yes when auto invoice no is set to true
		on error resume next
		set invoice = Session("invoice")
		invoice.splitInvoice addOrEdit
		checkForPrepay
	end sub

	sub attachNotes()
		on error resume next
		dim selLineNo
		dim itemNotes
		selLineNo = Request.Form("selLineNo")
		itemNotes = Request.Form("itemNotes")
		set invoice = Session("invoice")
		invoice.attachNotes selLineNo, itemNotes
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale attachNotes"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub initialize()
		curr_LineNo = ""
		selectedDept =-1
		selItemId =-1
		selUpchargeValue = ""
		selPatternValue = ""
		selColorValue =""
		getCustomerDetails
		invoice.priceListId = custPriceList
		invoice.setStoreDays storeId
		getCommonItems
		getAllDepartments
	end sub

	sub saveInvoiceWithSplit()
		dim autoInvNos

		on error resume next
		if ObjMiscSetUp.Count > 0 then
			autoInvNos = ObjMiscSetUp.Item("useAutomaticInvoiceNumbers")
		else
			autoInvNos = false
		end if
		set invoice = Session("invoice")
		if autoInvNos then
			saveInvoice	true
		else
			Response.Redirect "multipleInvoiceNos.asp?targetPage=counterSale&addOrEdit=" & addOrEdit _
									& "&onHold=0&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
									& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
									& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
									& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
									& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue
		end if
	end sub

	sub saveInvoiceWithNoSplit()
		' when the user selects no split in split prompt & auto invoice no. is set to true
		set invoice = Session("invoice")
		invoice.splitTheInvoice = false
		if addOrEdit = "add" then
			invoice.invoiceNo =""
		end if
		checkForPrepay
		'saveInvoice false
	end sub

	sub saveInvoiceWithInvNo()
		dim Inv_submit
		dim invoiceNumber
		dim inv_onHold
		dim empId
		dim terminalId
		dim empName
		dim storeName
		on error resume next
		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")
		set invoice = Session("invoice")
		Inv_submit = Request.QueryString("submit")
		curr_LineNo = Request.QueryString("lineNo")
		selectedDept = Request.QueryString("dept")
		if not IsEmpty(Request.QueryString("itIndex")) then
			itemsStartIndex = clng(Request.QueryString("itIndex"))
		else
			itemsStartIndex =0
		end if
		if not IsEmpty(Request.QueryString("upIndex")) then
			upChargeStartIndex = clng(Request.QueryString("upIndex"))
		else
			upChargeStartIndex =0
		end if
		if not IsEmpty(Request.QueryString("cIndex")) then
			colorsStartIndex = clng(Request.QueryString("cIndex"))
		else
			colorsStartIndex =0
		end if
		if not IsEmpty(Request.QueryString("pIndex")) then
			patternStartIndex = clng(Request.QueryString("pIndex"))
		else
			patternStartIndex =0
		end if
		addOrEdit = Request.QueryString("addOrEdit")
		if not IsEmpty(Request.QueryString("deptIndex")) then
			deptStartIndex = clng(Request.QueryString("deptIndex"))
		else
			deptStartIndex =0
		end if
		selItemId = Request.QueryString("selItemId")
		selUpchargeValue = Request.QueryString("selUp")
		selPatternValue = Request.QueryString("selPattern")
		selColorValue = Request.QueryString("selColor")
		inv_onHold = Request.QueryString("onHold")
		if Inv_submit = "ok" then
			invoiceNumber = Request.QueryString("invNo")
			invoice.invoiceNo =invoiceNumber
			saveInvoice false
		else
			cancelDoneOperation
		end if
	end sub

	sub checkForOnDemandCoupon()
		dim applyOnDemandCoupons
		dim promptForOnDemand

		on error resume next
		set invoice = Session("invoice")
		applyOnDemandCoupons = invoice.needToApplyOnDemandCoupon()
		if applyOnDemandCoupons then
			if ObjMiscSetUp.Count > 0 then
				promptForOnDemand = ObjMiscSetUp.Item("promptForOnDemandCoupons")
			else
				promptForOnDemand = false
			end if
			if promptForOnDemand then
				Response.Redirect "promptForOnDemandCoupons.asp?addOrEdit=" & addOrEdit _
								& "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
								& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
								& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
								& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
								& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue
			else
				invoiceDone
				checkForSplit
			end if
		else
			invoiceDone
			checkForSplit
		end if
	end sub

	sub invoiceDone()
		dim oneDiscount
		dim taxCodes

		on error resume next
		set invoice = Session("invoice")
		if ObjMiscSetUp.Count > 0 then
			oneDiscount = ObjMiscSetUp.Item("oneDiscountPerInvoice")
		else
			oneDiscount = false
		end if
		invoice.tagsSameAsInvNos = true
		if not IsObject(Session("taxCodes")) then
			getTaxCodes
		end if
		set taxCodes = Session("taxCodes")

		invoice.invoiceDone oneDiscount, taxCodes

		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale -invoiceDone:invoiceDone"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		
	end sub

	sub checkForSplit()
		dim splitPrompt
		dim splitInvoice

		on error resume next
		if ObjMiscSetUp.Count > 0 then
			splitPrompt = ObjMiscSetUp.Item("promptBefoerInvSpli")
		else
			splitPrompt =false
		end if
		splitInvoice = invoice.isSplitInvoice()
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice checkForSplit-isSplitInvoice"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		if splitInvoice =true then
			if splitPrompt = true then
				Response.Redirect "promptToSplit.asp?targetPage=counterSale&addOrEdit=" & addOrEdit _
								& "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
								& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
								& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
								& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
								& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue
			else
				invoice.splitInvoice addOrEdit
			end if
		end if
		checkForPrepay
	end sub

	sub checkForPrepay()
		dim prePayAmt
		dim fullPrepay
		dim splitTheInvoice

		fullPrepay = true
		prePayAmt = invoice.getInvoiceAmountToPay()


		if prePayAmt <=0 then
			splitTheInvoice = invoice.splitTheInvoice
			if splitTheInvoice then
				saveInvoiceWithSplit
			else
				checkForAutoInvNumbers
			end if
		else
			gotoPickUpScreen prePayAmt
		end if

	end sub

	sub checkForAutoInvNumbers()
		dim autoInvNos

		if ObjMiscSetUp.Count > 0 then
			autoInvNos = ObjMiscSetUp.Item("useAutomaticInvoiceNumbers")
		else
			autoInvNos = false
		end if
		if autoInvNos = true then
			if addOrEdit ="add" then
				invoice.invoiceNo =""
			end if
			saveInvoice false
		else
			select case addOrEdit
				case "add"
					Response.Redirect "newInvoiceNumber.asp?addOrEdit=" & addOrEdit _
									& "&onHold=0&targetPage=counterSale" _
									& "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
									& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
									& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
									& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
									& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue
				case "edit"
					saveInvoice false
			end select
		end if
	end sub

	sub saveInvoice(updateMainInvNo)
		dim invoicesDictionary
		dim invoicesArray
		dim counter
		dim aInvoice
		dim splitTheInvoice

		on error resume next
		splitTheInvoice = invoice.splitTheInvoice
		if splitTheInvoice then
			set invoicesDictionary = invoice.invoicesDictionary
			if addOrEdit = "add" then
				invoice.invoiceNo = ""
			end if
			invoicesArray = invoicesDictionary.Items
			for counter=0 to invoicesDictionary.Count-1
				set aInvoice = invoicesArray(counter)
				aInvoice.invoiceNo =""
			next
		end if
		'checkForTags
		saveInvoiceToDatabase
	end sub

	sub getTaxCodes()
		dim objResultSet
		dim ssql
		on error resume next
		ssql = "Select taxCode, description, taxPercent FROM Tax Where storeID=" & clng(storeId)
		set objResultSet = getDisconnectedRecordset(ssql)
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale getTaxCodes"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		set Session("taxCodes") = objResultSet
	end sub

	sub gotoPickUpScreen(amountDue)
		dim pickupObj
		dim prepayAmt

		
		set pickupObj = Server.CreateObject("ShahCorpComponents.pickup")
		
		pickupObj.DBConnectionString = Session("shahcorpDSN")
		pickupObj.storeId = storeId
		pickupObj.initStorePaymentTypeInfo()
		pickupObj.userAction = "prepay"
		pickupObj.addOrEdit = addOrEdit
		pickupObj.custSeqNumber = custSeqNumber
		pickupObj.storeId = storeId
		'prepayAmt = invoice.getPrePayAmount()
		prepayAmt = amountDue
		
		pickupObj.addInvoiceObjToPickup invoice
		set Session("pickupObj") = pickupObj

		Response.Redirect "pickup.asp?targetPage=counterSale&userAction=prepay&addOrEdit=" & addOrEdit _
							& "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
							& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
							& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
							& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
							& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue
	end sub


	sub deleteItem()
		dim selLineNo
		on error resume next
		selLineNo = Request.QueryString("itemId")
		set invoice = Session("invoice")
		invoice.deleteItem selLineNo
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale deleteItem"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub addCharge()
		dim chgDesc
		dim amount
		dim taxCode
		dim countAs
		on error resume next
		chgDesc = Request.Form("txtchargedesc")
		amount = Request.Form("txtcharge")
		taxCode = Request.Form("taxrates")
		countAs = Request.Form("countas")
		set invoice = Session("invoice")
		invoice.addChargeLineNew storeid, custpricelist, amount, chgDesc, countAs, selectedDept
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale addCharge"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub overrideLinePrice()
		dim selLine
		dim newPrice
		on error resume next
		selLine = Request.Form("itemIdToChange")
		newPrice = Request.Form("txtPrice")
		set invoice = Session("invoice")
		invoice.overRidePrice newPrice, selLine
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale overrideLinePrice"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub changeQuantity()
		dim quantity
		dim selLineNo
		on error resume next
		selLineNo = Request.QueryString("itemId")
		quantity = Request.QueryString("quantity")
		set invoice = Session("invoice")
		invoice.changeQuantity quantity, selLineNo
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale changeQuantity"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub addCoupon()
		dim couponId
		on error resume next
		couponId = Request.QueryString("couponId")
		set invoice = Session("invoice")
		invoice.addCoupon couponId
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale addCoupon"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub

	sub getCoupons()
		dim tempVal
		dim coupons
		dim oneDiscount
		dim upSet
		dim cSet
		dim patSet
		dim couponRst

		'upSet = Request.Form("upchargeSet")
		'cSet = Request.Form("colorSet")
		'patSet = Request.Form("patternSet")
		on error resume next
		oneDiscount = false
		set invoice = Session("invoice")
		if ObjMiscSetUp.Count > 0 then
			oneDiscount = ObjMiscSetUp.Item("oneDiscountPerInvoice")
		end if
		tempVal =true
		if oneDiscount then
			if invoice.vipQualified then
				tempVal =false
				alertMessage = "Can not add coupons as the customer is vip qualified & only one discount is allowed."
			else
				tempVal  = invoice.isFirstCoupon()
				if err.number <> 0 then
					set errorList =  Server.CreateObject("Scripting.Dictionary")
					errorList.Add err.number,err.description & "-Function= Counter Sale getCoupons-isFirstCoupon"
					set session("errorList") = errorList
					Response.redirect("../include/error.asp")
				end if
				if not tempVal then
					alertMessage = "There exists one coupon and only one discount is allowed"
				end if
			end if
		else
			if invoice.vipQualified then
				tempVal = invoice.isVipValidWithOtherOffer()
				if err.number <> 0 then
					set errorList =  Server.CreateObject("Scripting.Dictionary")
					errorList.Add err.number,err.description & "-Function= Counter Sale getCoupons-isVipValidWithOtherOffer"
					set session("errorList") = errorList
					Response.redirect("../include/error.asp")
				end if
				if Not tempVal then
					alertMessage = "Customer is vip qualified and vip is not valid with other offers."
				end if
			end if
			if tempVal then
				if Not invoice.isFirstCoupon then
					tempVal = invoice.validateCouponAdd()
					if err.number <> 0 then
						set errorList =  Server.CreateObject("Scripting.Dictionary")
						errorList.Add err.number,err.description & "-Function= Counter Sale getCoupons-validateCouponAdd"
						set session("errorList") = errorList
						Response.redirect("../include/error.asp")
					end if
					if not tempVal then
						alertMessage = "There exists one coupon on the invoice which is not valid with other offer"
					end if
				end if
			end if
		end if
		if tempVal then
			invoice.getQualifyingCoupons
			if err.number <> 0 then
				set errorList =  Server.CreateObject("Scripting.Dictionary")
				errorList.Add err.number,err.description & "-Function= Counter Sale getCoupons-getQualifyingCoupons"
				set session("errorList") = errorList
				Response.redirect("../include/error.asp")
			end if
			Set couponRst = invoice.getDisplayCouponRst()
			if err.number <> 0 then
				set errorList =  Server.CreateObject("Scripting.Dictionary")
				errorList.Add err.number,err.description & "-Function= Counter Sale getCoupons-getDisplayCouponRst"
				set session("errorList") = errorList
				Response.redirect("../include/error.asp")
			end if
			if couponRst.RecordCount > 0 then
				couponRst.PageSize =maxCouponsCount
				Set Session("displayCoupons")= couponRst
				Response.Redirect "allCoupons.asp?targetPage=counterSale&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
								& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
								& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
								& "&addOrEdit=" & addOrEdit & "&deptIndex=" & deptStartIndex _
								& "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
								& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue

								'& "&upSet=" & upSet & "&cSet=" & cSet _
								'& "&patSet=" & patSet & "&page=detail"
			else
				alertMessage = "No Qualifying Coupons to add."
			end if
		end if
	end sub

	sub addUpCharge()
		dim quantity
		dim groupSimilarItems
		on error resume next
		selUpchargeValue = Request.QueryString("upchargeid")
		quantity = Request.QueryString("quantity")
		set invoice = Session("invoice")
		if ObjMiscSetUp.Count > 0 then
			groupSimilarItems = ObjMiscSetUp.Item("groupSimilarItems")
		else
			groupSimilarItems = true
		end if
		invoice.addUpcharge curr_LineNo, selUpchargeValue, quantity , groupSimilarItems
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale addUpCharge"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		upchargeSet = 1
	end sub

	sub addColor()
		dim quantity
		dim groupSimilarItems
		on error resume next
		selColorValue= Request.QueryString("colorid")
		quantity = Request.QueryString("quantity")
		set invoice = Session("invoice")
		if ObjMiscSetUp.Count > 0 then
			groupSimilarItems = ObjMiscSetUp.Item("groupSimilarItems")
		else
			groupSimilarItems = true
		end if
		invoice.addColor curr_LineNo, selColorValue, quantity , groupSimilarItems
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale addColor"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		colorSet =1
	end sub

	sub addPattern()
		dim quantity
		dim groupSimilarItems
		on error resume next
		selPatternValue= Request.QueryString("patternid")
		quantity = Request.QueryString("quantity")
		set invoice = Session("invoice")
		if ObjMiscSetUp.Count > 0 then
			groupSimilarItems = ObjMiscSetUp.Item("groupSimilarItems")
		else
			groupSimilarItems = true
		end if
		invoice.addPattern curr_LineNo, selPatternValue, quantity , groupSimilarItems
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale addPattern"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		patternSet =1
	end sub

	sub getItemDetails(selitemid, quantity)
		dim groupSimilarItems
		on error resume next

		if ObjMiscSetUp.Count > 0 then
			groupSimilarItems = ObjMiscSetUp.Item("groupSimilarItems")
		else
			groupSimilarItems = true
		end if
		set invoice = Session("invoice")
		curr_LineNo = invoice.addItem (selItemId, groupSimilarItems, quantity)
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Counter Sale getItemDetails"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		getDistinctUpcharges selItemId
		getDistinctColors selItemId
		getDistinctPatterns selItemId
		selUpchargeValue = ""
		selPatternValue = ""
		selColorValue =""
	end sub

	sub setStartIndexForPaging()
		upChargeStartIndex = Request.Form("upChargePageCount")
		patternStartIndex = Request.Form("patternPageCount")
		colorsStartIndex = Request.Form("colorsPageCount")
		itemsStartIndex = Request.Form("ItemPageCount")
		deptStartIndex = Request.Form("DeptPageCount")
		if(IsEmpty(upChargeStartIndex)) OR upChargeStartIndex =0 then
			upChargeStartIndex=1
		else
			upChargeStartIndex=Int(upChargeStartIndex)

		end if
		if(IsEmpty(patternStartIndex)) Or patternStartIndex=0 then
			patternStartIndex=1
		else
			patternStartIndex=Int(patternStartIndex)
		end if
		if(IsEmpty(colorsStartIndex)) Or colorsStartIndex=0 then
			colorsStartIndex=1
		else
			colorsStartIndex=Int(colorsStartIndex)
		end if
		if(IsEmpty(itemsStartIndex)) Or itemsStartIndex=0 then
			itemsStartIndex=1
		else
			itemsStartIndex=Int(itemsStartIndex)
		end if
		if(IsEmpty(deptStartIndex)) Or deptStartIndex=0 then
			deptStartIndex=1
		else
			deptStartIndex=Int(deptStartIndex)
		end if
	end sub

	sub getCustomerDetails()
		dim ssql
		dim objResultSet
		dim areaCode

		ssql = "GetCounterSaleCustomer " & storeId
		Set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Recordcount > 0 then
			objResultSet.MoveFirst
			if IsNull(objResultSet.fields("defaultpriceListId").Value) then
				Response.Redirect "start2.asp"
			else
				custPriceList = objResultSet.fields("defaultpriceListId").Value
				custSeqNumber = objResultSet.Fields("customerSequenceNumber")
				Session("priceList") = custPriceList
				Session("customersequencenumber") = custSeqNumber
			end if
		end if
	end sub



	sub getItemsForDept()
		dim ssql
		dim itemsRst
		ssql = "select priceListItemID, itemName, price, imageFileName from PriceListItem where departmentID=" _
				& clng(selectedDept) & " AND priceListID=" & clng(custPriceList) _
				& " AND disabled=0 and saleOnly=1 Order by displaySequence"
		set itemsRst = getDisconnectedRecordset(ssql)
		if itemsRst.Recordcount > 0 then
			itemsRst.PageSize = maxItemsCount
		end if
		Set Session("ItemsToBeShown")= itemsRst
		selItemId =-1
		selUpchargeValue =""
		selColorValue = ""
		selPatternValue =""
	end sub

	sub getCommonItems()
		dim commResultSet
		dim ssql
		ssql ="Select priceListItemID, itemName, price, imageFileName From PriceListItem Where " _
			  & " commonItem=1 AND disabled =0 AND priceListId =" & clng(custPriceList) _
			  & " And saleOnly=1 Order by displaySequence"
		set commResultSet = getDisconnectedRecordset(ssql)
		if commResultSet.Recordcount > 0 then
			commResultSet.PageSize = maxItemsCount
		end if
		Set Session("ItemsToBeShown")= commResultSet
	End sub



	sub getAllDepartments()
		dim ssql
		dim objResultSet
		ssql = "Select distinct d.departmentID, d.name, d.splitInvoice, d.imageFileName , d.displaySequence from Department  D , pricelistitem P where " _
				& " d.storeId =" & clng(storeId) & " AND d.disabled=0 " _
				& " And d.priceListId=" & clng(custPriceList) _
				& " and d.priceListId = p.priceListId and d.departmentid = p.departmentid and p.saleonly = 1 " _
				& " Order by d.displaySequence"

		Set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.RecordCount > 0 then
			objResultSet.PageSize = maxDeptCount
		end if
		set Session("departmentMaster") = objResultSet
	end sub

	sub getDistinctUpcharges(selItemId)
        dim ssql
        dim upChargeRst
        ssql ="Select descriptorName, price, imageFileName From itemDescriptorPrice where descriptorType='UP' " _
				& " AND priceListItemId =" & clng(selItemId) _
				& " AND disabled=0  Order by displaySequence"
		set upChargeRst = getDisconnectedRecordset(ssql)
        upChargeRst.PageSize = maxSubItemCount
		Set Session("upcharges")= upChargeRst
    End sub

	sub getDistinctColors(selItemId)
        dim ssql
        dim colorsRst
        ssql ="Select descriptorName, imageFileName From itemDescriptorPrice where descriptorType='CO' " _
				& " AND priceListItemId =" & clng(selItemId) _
				& " AND disabled=0  Order by displaySequence"
		set colorsRst = getDisconnectedRecordset(ssql)
		colorsRst.PageSize = maxSubItemCount
		Set Session("colors")= colorsRst
	End sub

	sub getDistinctPatterns(selItemId)
		dim ssql
		dim patternRst
        ssql ="Select descriptorName, imageFileName From itemDescriptorPrice where descriptorType='PA' " _
				& " AND priceListItemId =" & clng(selItemId) _
				& " AND disabled=0  Order by displaySequence"
        set patternRst = getDisconnectedRecordset(ssql)
        patternRst.PageSize = maxSubItemCount
		Set Session("patterns")= patternRst
	End sub

function checkIfDeptExists(deptId)
	dim retval
	dim counter
	dim maxCount

	retval = false
	maxCount = ubound(deptIds)
	if ubound(deptIds) > 0 then
		for counter =1 to maxCount
			'Response.Write "deptId =" & deptIds(counter)
			if deptId = deptIds(counter) then
				retval = true
				exit for
			end if
		next
	end if
	checkIfDeptExists = retval
 end function

%>
<HTML>
<HEAD>
<TITLE>Counter Sale Invoice</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
	var lastFocusControl;
function txtAmountEntered_onblur() {
	lastFocusControl = event.srcElement;
}

//-->
</SCRIPT>
</HEAD>
<script language="JavaScript" src="../script/date-picker.js"></script>
<script language="javascript" type="text/javascript">
	var previousElement=null;
	var alertMessage = null;

	function submitForm() {
		var forceValues;
		var itemCount;
		itemCount = document.counterSale.txtTotal.value;
		//forceValues = validateForceSubItems();
		forceValues = true;
		if (forceValues == true) {
			if (itemCount > 0) {
				document.counterSale.action= document.counterSale.action + "?userAction=done";
				document.counterSale.submit();
			}else{
				cbs_alert("Must have at least a servicable item on the invoice.")
			}
		}
	}

	function showAddCharge() {
		var itemCount;
		var selDeptId;

		itemCount = document.counterSale.txtTotal.value;

		if (itemCount == 0){
			selDeptId = document.counterSale.selectedDept.value;
			if (selDeptId == -1) {
				cbs_alert("Must select a department before adding charge");
				return false;
			}
		}
		document.counterSale.action="addCharge.asp?targetPage=counterSale";
		document.counterSale.submit();
	}

	function showAllCoupons() {
		var forceValues;
		//forceValues = validateForceSubItems();
		forceValues = true;
		if (forceValues == true) {
			document.counterSale.action=document.counterSale.action + "?userAction=getCoupons";
			document.counterSale.submit();
		}
	}
	function selectRow(element) {
		var childEl;
		var lineNo;
		if (previousElement == null){
			deselectSelectedRow();
		} else{
			previousElement.style.background="white";
		}
		if (element.name == "main"){
			childEl = element.children[0];
		}
		else {
			childEl = element.children[1];
		}
		var rowChildNodes = childEl.children
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if(childEl.tagName == "INPUT") {
				childEl.checked=true;
				break;
			}
		}
		previousElement =element;
		element.style.background="#DBF2F4";
		if (element.title == "IT") {
			document.counterSale.upChargePageCount.value = eval(0);
			document.counterSale.colorsPageCount.value = eval(0);
			document.counterSale.PatternPageCount.value = eval(0);
			if(childEl.tagName == "INPUT"){
				if (invoiceTable.rows.length > 0) {
					if(invoiceTable.rows.length ==2)
					{
						if(document.counterSale.select.checked) {
							lineNo = document.counterSale.select.value;
						}
					}
					else{
						for (var i = 0; i < document.counterSale.select.length; i++) {
							if(document.counterSale.select[i].checked){
								lineNo = document.counterSale.select[i].value;
								break;
							}
						}
					}
				}
				document.counterSale.action =  "?userAction=getSubItems&lineNo=" + lineNo;
				document.counterSale.submit();
			}
		}
	}

	function deselectSelectedRow() {
		var currLineNo;
		currLineNo = document.counterSale.lineNumber.value;
		if (currLineNo.length > 0) {
			for(var i=0; i<invoiceTable.rows.length; i++){
				invoiceTable.rows[i].style.background =	"white";
			}
		}
	}

	function getItemDetails(element) {
		var itemId
		var currentLineNo
		var submit
		var itemName
		var price
		var quantity = document.counterSale.txtAmountEntered.value;
		submit = false;
		currentLineNo = document.counterSale.lineNumber.value;
		document.counterSale.upChargePageCount.value = eval(0);
		document.counterSale.colorsPageCount.value = eval(0);
		document.counterSale.PatternPageCount.value = eval(0);
		itemId = element.id;
		itemName = element.name;
		price = element.title;
		if (currentLineNo == ""){
			submit = true;
		}
		else {
				//submit =validateForceSubItems();
				submit = true;
		}
		if (submit == true) {
			DisplayItem(itemName, price);
			document.counterSale.action =  "?userAction=getItemDetails&itemId=" + itemId + "&quantity=" + quantity;
			document.counterSale.submit();
		}
	}

	function validateForceSubItems(){
		if(document.counterSale.forceUpcharges.value == "True" && document.counterSale.upchargeSet.value == "0") {
			cbs_alert("Select an upcharge");
			return false;
		}
		if(document.counterSale.forceColors.value == "True" && document.counterSale.colorSet.value == "0") {
			cbs_alert("Select a color");
			return false;
		}
		if(document.counterSale.forcePatterns.value == "True" && document.counterSale.patternSet.value == "0") {
			cbs_alert("Select a pattern");
			return false;
		}
		return true;
	}

	function nextUpChargePage() {
		document.counterSale.upChargePageCount.value = eval(eval(document.counterSale.upChargePageCount.value) + eval(1));
		document.counterSale.action =  "?userAction=nextPage";
		document.counterSale.submit();
	}

	function nextColorPage() {
		document.counterSale.colorsPageCount.value = eval(eval(document.counterSale.colorsPageCount.value) + eval(1));
		document.counterSale.action =  "?userAction=nextPage";
		document.counterSale.submit();
	}

	function nextPatternsPage() {
		document.counterSale.PatternPageCount.value = eval(eval(document.counterSale.PatternPageCount.value) + eval(1));
		document.counterSale.action =  "?userAction=nextPage";
		document.counterSale.submit();
	}

	function nextItemsPage() {
		document.counterSale.ItemPageCount.value = eval(eval(document.counterSale.ItemPageCount.value) + eval(1));
		document.counterSale.action =  "?userAction=nextPage";
		document.counterSale.submit();
	}

	function nextDeptPage() {
		document.counterSale.DeptPageCount.value = eval(eval(document.counterSale.DeptPageCount.value) + eval(1));
		document.counterSale.action =  "?userAction=nextPage";
		document.counterSale.submit();
	}

	function setSelectedUpCharge(element) {
		var selectedUpCharge;
		var price;
		var quantity = document.counterSale.txtAmountEntered.value;
		selectedUpCharge = element.name;
		price = element.title;
		ShowUpcharge(selectedUpCharge, price);
		document.counterSale.action =  "?userAction=addUpcharge&upchargeid=" + selectedUpCharge + "&quantity=" + quantity;
		document.counterSale.submit();
	}

	function setSelectedColor(element) {
		var selectedColor;
		var quantity = document.counterSale.txtAmountEntered.value;
		selectedColor = element.name;
		document.counterSale.action =  "?userAction=addColor&colorid=" + selectedColor + "&quantity=" + quantity;
		document.counterSale.submit();

	}

	function setSelectedPattern(element) {
		var selectedPattern;
		var quantity = document.counterSale.txtAmountEntered.value;
		selectedPattern = element.name;
		document.counterSale.action =  "?userAction=addPattern&patternid=" + selectedPattern + "&quantity=" + quantity;
		document.counterSale.submit();

	}

	function changeQuantity(){
		var selItemID = null;
		var quantity = document.counterSale.txtAmountEntered.value;
		if(quantity.length>0 && invoiceTable.rows.length > 0) {
			if(invoiceTable.rows.length ==2)
				{
					if(document.counterSale.select.checked) {
						selItemID = document.counterSale.select.value;
					}
				}
			else{
				for (var i = 0; i < document.counterSale.select.length; i++) {
					if(document.counterSale.select[i].checked){
						selItemID = document.counterSale.select[i].value;
						break;
					}
				}
			}
			if(selItemID != null) {
				if (!checkInt(quantity)) {
					show_focus("Must enter all numbers.", "Quantity",  document.counterSale.txtAmountEntered);
					return false;
				}else{
					document.counterSale.action =  "?userAction=changeQuantity&itemId=" + selItemID + "&quantity=" + quantity;
					document.counterSale.submit();
				}
			}
		}
	}

	function deleteItems() {
		var selItemID = null;
		if (invoiceTable.rows.length > 0) {
			if(invoiceTable.rows.length ==2)
				{
					if(document.counterSale.select.checked) {
						selItemID = document.counterSale.select.value;
					}
				}
			else{
				for (var i = 0; i < document.counterSale.select.length; i++) {
					if(document.counterSale.select[i].checked){
						selItemID = document.counterSale.select[i].value;
						break;
					}
				}
			}
			if(selItemID != null) {
				document.counterSale.action =  "?userAction=deleteItem&itemId=" + selItemID;
				document.counterSale.submit();
			}
		}
	}

	function clearInvoice()	{
		var itemCount;
		itemCount = document.counterSale.txtTotal.value;
		if (itemCount > 0) {
			document.counterSale.action =  "?userAction=clearInvoice";
			document.counterSale.submit();
		}
	}

	function populateCommonItems(){
		document.counterSale.ItemPageCount.value = eval(0);
		document.counterSale.selectedDept.value =-1;
		document.counterSale.lineNumber.value ="";
		document.counterSale.action =  "?userAction=getCommonItems";
		document.counterSale.submit();

	}

	function showOverRidePrice() {
		var selItemID = null;

		if (invoiceTable.rows.length > 0) {
			if(invoiceTable.rows.length ==2)
				{
					if(document.counterSale.select.checked) {
						selItemID = document.counterSale.select.value;
					}
				}
			else{
				for (var i = 0; i < document.counterSale.select.length; i++) {
					if(document.counterSale.select[i].checked){
						selItemID = document.counterSale.select[i].value;
						break;
					}
				}
			}
			if(selItemID != null) {
				document.counterSale.action = "overRidePrice.asp?targetPage=counterSale&selectedItemId=" + selItemID;
				document.counterSale.submit();
			}
		}
	}

	function setSelectedDept(d_element) {
		document.counterSale.ItemPageCount.value = eval(0);
		document.counterSale.lineNumber.value =""
		document.counterSale.selectedDept.value = d_element.id;
		document.counterSale.action =  "?userAction=changeDept";
		document.counterSale.submit();
	}

	function hideScrollBars(){
		document.body.style.overflow='hidden';
	}

	function checkForAlertMessages() {
		hideScrollBars();
		<%
			if Len(alertMessage) > 0 then
			Response.Write "alertMessage='"
			Response.Write alertMessage
			Response.Write "'"
			end if
		%>
		if (alertMessage != null){
			cbs_alert (alertMessage);
		}
		lastFocusControl = eval(document.counterSale.txtAmountEntered);
	}

	function showItemNotes() {
		var lineNumber;
		lineNumber = null;
		if (invoiceTable.rows.length > 0) {
			if(invoiceTable.rows.length ==2)
			{
				if(document.counterSale.select.checked) {
					lineNumber = document.counterSale.select.value;
				}
			}
			else{
				for (var i = 0; i < document.counterSale.select.length; i++) {
					if(document.counterSale.select[i].checked){
						lineNumber = document.counterSale.select[i].value;
						break;
					}
				}
			}
			if(lineNumber!= null){
				document.counterSale.action = "ItemNotes.asp?lineNumber=" + lineNumber + "&targetPage=counterSale";
				document.counterSale.submit();
			}

		}
	}

	function cancelForm() {
		document.counterSale.action = "?userAction=cancel";
		document.counterSale.submit();
	}

	function previousDeptPage() {
		document.counterSale.DeptPageCount.value = eval(1);
		document.counterSale.action =  "?userAction=nextPage";
		document.counterSale.submit();
	}

	function prevPatternsPage() {
		document.counterSale.PatternPageCount.value = eval(1);
		document.counterSale.action =  "?userAction=nextPage";
		document.counterSale.submit();
	}

	function prevUpChargePage() {
		document.counterSale.upChargePageCount.value = eval(1);
		document.counterSale.action =  "?userAction=nextPage";
		document.counterSale.submit();
	}

	function prevColorPage() {
		document.counterSale.colorsPageCount.value = eval(1);
		document.counterSale.action =  "?userAction=nextPage";
		document.counterSale.submit();
	}

	function prevItemsPage() {
		document.counterSale.ItemPageCount.value = eval(1);
		document.counterSale.action =  "?userAction=nextPage";
		document.counterSale.submit();
	}

	function addShortcutItem(shortcut) {
		document.counterSale.action = "?userAction=addshortcutitem" +
										"&shortcut=" + shortcut;
		document.counterSale.submit();
	}

	function captureKeyup(element){
		if (event.keyCode == 13){
			addShortcutItem(document.counterSale.itemShortcut.value);
		}
	}

	function selectShortcutItem() {
		var field;
		field = document.counterSale.itemShortcut;
		field.select();
		field.focus();
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0 onLoad="checkForAlertMessages();selectShortcutItem();">

<!-- #include file="../include/customerDisplay.inc" -->
<!-- #include file="../include/banner.inc" -->

<H1>Counter Sale Invoice</H1>
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 style="border-top:2px ridge gray;border-bottom:2px ridge gray"  style="background:#FFF" >
		<FORM id="counterSale" name="counterSale" action="CounterSale.asp" method="post"><input type="hidden" name="Horde" value="ab0903842b449d92d9b1a109f6656666" /><input type="hidden" name="Horde" value="be1dba8a9aae1ade8cfde782ce21e53a" />
			<INPUT type="hidden" name="targetPage" value="<%= actionString %>">
			<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
			<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
			<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
			<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
			<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
			<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
			<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
			<INPUT type="hidden" name="upchargeSet" value="1">
			<INPUT type="hidden" name="colorSet" value="1">
			<INPUT type="hidden" name="patternSet" value="1">
			<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
			<INPUT type="hidden" name="isDueDateSet" value="1">
			<input type="hidden" name="functionID" id="functionID" value="">
			<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
			<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
			<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
			<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
		<tr>
				<td valign=top style="border-right:2px ridge gray"> <!-- first  column -->
					<TABLE ALIGN=center WIDTH="100%" BORDER=0  CELLPADDING=4 CELLSPACING=0>
						<tr>
							<td style="background-color:#6698FF;">
								<%
									dim deptRst
									dim lStart, noOfElements
									set deptRst =  Session("departmentMaster")
									if deptRst.RecordCount > 0 then
										lStart =deptStartIndex
										noOfElements = deptRst.PageCount
										deptRst.AbsolutePage = lStart
										'While Not (deptRst.Eof Or deptRst.AbsolutePage <> lStart )

								%>

								<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=2 style="background-color:#6698FF;font-size:10px;">
									<tr align=center>
										<td valign=top>
											<!--<INPUT class=touch id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" type=button value="" style="width:35px;height:35px;background-image:url(../uploadedImages/<%= deptRst.Fields("imageFileName")%>);-->
											<BUTTON class=small id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>"
											<%
												if clng(selectedDept) = deptRst.Fields("departmentID") then
											%>
												border:2px inset #CCCCCC;
											<%
												end if
											%>
											 onClick="setSelectedDept(this)"><%if deptRst.Fields("imageFileName") <> "" then%><img src="../uploadedImages/<%= deptRst.Fields("imageFileName")%>"><br><%end if%><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>
										</td>
										<%
											deptRst.MoveNext
											if Not deptRst.eof then
										%>
											<td valign=top>
												<!--<INPUT class=touch id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" type=button value="" style="width:35px;height:35px;background-image:url(../uploadedImages/<%= deptRst.Fields("imageFileName")%>);-->
												<BUTTON class=small id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>"
												<%
													if clng(selectedDept) = deptRst.Fields("departmentID") then
												%>
													border:2px inset #CCCCCC;
												<%
													end if
												%>
												 onClick="setSelectedDept(this)"><%if deptRst.Fields("imageFileName") <> "" then%><img src="../uploadedImages/<%= deptRst.Fields("imageFileName")%>"><br><%end if%><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>
											</td>
										<%
											deptRst.MoveNext
											end if
											if lStart < noOfElements then
										%>
												<td valign=top>
													<!--<INPUT class=touch id=otherDept name=otherDept type=button value="" style="width:35px;height:35px;background-image:url(/static/icons/24x24/next.png);" onClick="nextDeptPage();"><br>Other Dept.-->
													<BUTTON class=small  id=otherDept name=otherDept onClick="nextDeptPage();"><img src="/static/icons/24x24/next.png"><br>Other Dept</button>
												</td>
										<%
											else
												if lStart > 1 And lStart >= noOfElements then
										%>
												<td valign=top>
													<!--<INPUT class=touch id=previous name=previous type=button value="" style="width:35px;height:35px;background-image:url(/static/icons/24x24/previous.png);" onClick="previousDeptPage();"><br>Previous-->
													<BUTTON class=small  id=previous name=previous onClick="previousDeptPage();"><img src="/static/icons/24x24/previous.png"><br>Previous</button>
												</td>
										<%
												end if
											end if
										%>
									</tr>
									<tr align=center>
										<%
											if Not deptRst.eof then
										%>
											<td valign=top>
												<!--<INPUT class=touch id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" type=button value="" style="width:35px;height:35px;background-image:url(../uploadedImages/<%= deptRst.Fields("imageFileName")%>);-->
												<BUTTON class=small id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>"
												<%
													if clng(selectedDept) = deptRst.Fields("departmentID") then
												%>
													border:2px inset #CCCCCC;
												<%
													end if
												%>
												 onClick="setSelectedDept(this)"><%if deptRst.Fields("imageFileName") <> "" then%><img src="../uploadedImages/<%= deptRst.Fields("imageFileName")%>"><br><%end if%><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>
											</td>
										<%
											deptRst.MoveNext
											end if
											if Not deptRst.eof then
										%>
											<td valign=top>
												<!--<INPUT class=touch id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" type=button value="" style="width:35px;height:35px;background-image:url(../uploadedImages/<%= deptRst.Fields("imageFileName")%>);-->
												<BUTTON class=small id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>"
												<%
													if clng(selectedDept) = deptRst.Fields("departmentID") then
												%>
													border:2px inset #CCCCCC;
												<%
													end if
												%>
												 onClick="setSelectedDept(this)"><%if deptRst.Fields("imageFileName") <> "" then%><img src="../uploadedImages/<%= deptRst.Fields("imageFileName")%>"><br><%end if%><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>
											</td>
										<% end if%>
											<td valign=top>
												<!--<INPUT class=touch id=bttnCommonItems name=bttnCommonItems type=button value="" style="width:35px;height:35px;background-image:url(../images/Commercial-1.gif);-->
												<BUTTON class=small id=bttnCommonItems name=bttnCommonItems
												<%
													if clng(selectedDept) = -1 then
												%>
													border:2px inset #CCCCCC;
												<%
													end if
												%>
												 onClick="populateCommonItems()">Common<br>Items</button>
											</td>
									</tr>

								</table>
								<% end if%>
							</td>
							<td style="border-left:2px ridge gray;" valign=top >
								<TABLE ALIGN=center  BORDER=0 CELLPADDING=2 style="font-size:10px;">
									<tr>
										<td>
											<!--<INPUT class=touch id=overridePrice name=overridePrice type=button value="" style="width:35px;height:35px;background-image:url(../images/Add-Charge.gif);" onClick="showOverRidePrice()"><br>Override Price-->
											<BUTTON class=small style="width:90px;height:50px;" id=overridePrice name=overridePrice onClick="showOverRidePrice()"><img src="/static/icons/24x24/edit.png"><br>Override Price</button>
										</td>
										<td>
											<!--<INPUT class=touch id=addCharge name=addCharge type=button value="" style="width:35px;height:35px;background-image:url(../images/Add-Money.gif);" onClick="showAddCharge();"><br>Add Charge-->
											<BUTTON class=small style="width:90px;height:50px" id=addCharge name=addCharge onClick="showAddCharge();"><img src="/static/icons/24x24/add.png"><br>Add Charge</button>
										</td>
										<!--<td>
											<INPUT class=touch id=bttnholdTicket name=bttnholdTicket type=button value="" style="width:35px;height:35px" onClick="holdTicket();"><br>Hold Ticket
										</td> -->
										<td>
											<!--<INPUT class=touch id=coupons name=coupons type=button value="" style="width:35px;height:35px;background-image:url(../images/Coupon.gif);" onClick="showAllCoupons();"><br>Coupons-->
											<BUTTON class=small style="width:90px;height:50px" id=coupons name=coupons onClick="showAllCoupons();"><img src="/static/icons/24x24/discount.png"><br>Coupons</button>
										</td>
									</tr>
									<tr>
										<!--<td>
											<INPUT class=touch id=heatseal name=heatseal type=button value="" style="width:35px;height:35px"><br>Heat Seal
										</td> -->
										<td>
											<!--<INPUT class=touch id=deleteItem name=deleteItem type=button value="" style="width:35px;height:35px;background-image:url(../images/Cancel-Data.gif);" onClick="deleteItems();"><br>Delete Item-->
											<BUTTON class=small style="width:90px;height:50px" id=deleteItem name=deleteItem onClick="deleteItems();"><img src="/static/icons/24x24/remove.png"><br>Delete Item</button>
										</td>
										<td>
											<!--<INPUT class=touch id=bttnClearInvoice name=bttnClearInvoice type=button value="" style="width:35px;height:35px;background-image:url(../images/New-Data-Blank.gif);" onClick="clearInvoice();"><br>Clear Invoice-->
											<BUTTON class=small style="width:90px;height:50px" id=bttnClearInvoice name=bttnClearInvoice onClick="clearInvoice();"><img src="/static/icons/24x24/clear.png"><br>Clear Invoice</button>
										</td>
										<td>
											<!--<INPUT class=touch id=Notes name=Notes type=button value="" style="width:35px;height:35px;background-image:url(../images/Notes.gif);" onClick="showItemNotes();"><br>Notes-->
											<BUTTON class=small style="width:90px;height:50px" id=Notes name=Notes onClick="showItemNotes();"><img src="/static/icons/24x24/note.png"><br>Notes</button>
										</td>
									</tr>
								</table>
							</td>
						</tr> <!-- first column first row ends-->
						<tr>
							<td  style="border-top:2px ridge gray">
								<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=1 >
									<TR valign=center>
										<TD align=center valign=center>
											<INPUT id=txtAmountEntered name=txtAmountEntered class=text maxlength="5" style="WIDTH: 140px;vertical-align:middle;" onblur="return txtAmountEntered_onblur()">
										</TD>

										<TD>
											<BUTTON style="width:60px;height:30px;" name=quantity id=quantity onClick="changeQuantity()">Qty</button>
										</TD>
									</TR>

									<tr height=10px><td></td></tr>
									<TR>
										<TD colspan=2 style="vertical-align:middle;text-align:center;height:100px">
											<!-- #include file="../include/integerPad.inc" -->
										</TD>
									</TR>
								</table>
							</td>
							<!-- items area -->
							<td  style="border-top:2px ridge gray;border-left:2px ridge gray;" valign=top >
								<INPUT style="width:450px" name="itemShortcut" onkeyup="captureKeyup(this);" value="<%=request.querystring("shortcut")%>">
								<TABLE   id="itemsTable" name="itemsTable" WIDTH="450" BORDER=0 CELLSPACING=1 CELLPADDING=1 >
									<tbody>
										<%
										dim commonItemsCount, iStartIndex
										dim colsCounter
										dim commItems
										Set commItems = Session("ItemsToBeShown")
										if commItems.RecordCount > 0 then
											iStartIndex = itemsStartIndex
											commonItemsCount = commItems.PageCount
											commItems.AbsolutePage = iStartIndex
											While Not (commItems.Eof Or commItems.AbsolutePage <> iStartIndex )
												colsCounter=1
									%>
										<tr>
											<%
												while colsCounter<=5 And Not (commItems.Eof Or commItems.AbsolutePage <> iStartIndex )
												colsCounter =colsCounter+1

											%>
											<td height=45px width=50px valign="top" align="center">
												<BUTTON class=small id="<%= commItems.Fields("priceListItemId")%>" name="<%= commItems.Fields("itemName")%>" title="<%= commItems.Fields("price")%>" style="
												<%
													if clng(selItemId) = commItems.Fields("priceListItemId").Value  then
												%>
													border:2px inset #CCCCCC;

												<%
													end if
												%>
												background: #FFFFFF url(../uploadedImages/<%=commItems.Fields("imageFileName")%>) no-repeat top;
												height:60px;
												width:85px;
												"

												onClick="getItemDetails(this)"><span style="background:#f3f3f3;width:100%;border-top:1px solid gray;margin-top:36px"><%= WordTrim(commItems.Fields("itemName"), 15)%></span></button>
											</td>
											<%
												commItems.MoveNext
												wend
											wend
												if iStartIndex < commonItemsCount then
											%>
												<td width=50px align="center" valign="top">
													<!--<INPUT class=touch  id="moreItems" name="moreItems" type=button value="" style="width:35px;height:35px;background-image:url(/static/icons/24x24/next.png);" onClick="nextItemsPage();"><br>More-->
													<BUTTON class=small id=moreItems name=moreItems style="width:65px;height:50px" onClick="nextItemsPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/next.png"><br>More</button>
												</td>

											<%
												else
													if iStartIndex > 1 And iStartIndex >= commonItemsCount then

											%>
													<td width=50px align="center" valign="top">
														<!--<INPUT class=touch  id="prevItems" name="prevItems" type=button value="" style="width:35px;height:35px;background-image:url(/static/icons/24x24/previous.png);" onClick="prevItemsPage();"><br>Previous-->
														<BUTTON class=small id=prevItems name=prevItems style="width:65px;height:50px" onClick="prevItemsPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/previous.png"><br>Previous</Button>
													</td>
											<%
													end if
												end if
											%>
										</tr>
									<%
										end if
									%>
									</tbody>
								</table>
							</td>
						</tr>
						<tr  style="height:180px">
							<td style="background:#FFF" style="border-top:2px ridge gray" colspan=2>
								<TABLE  style="background:#FFF" width=415 BORDER=0 CELLSPACING=1 CELLPADDING=1>
									<tr height=50>
										<td style="width:70px" >Upcharges</td>
										<%
											dim distinctUpcharges
											dim upChargeValue
											 if curr_LineNo <> "" then
												Set distinctUpcharges = Session("upcharges")
												if distinctUpcharges.Recordcount > 0 then
													lStart = upChargeStartIndex
													noOfElements = distinctUpcharges.PageCount
													distinctUpcharges.AbsolutePage = lStart
													while Not (distinctUpcharges.Eof Or distinctUpcharges.AbsolutePage <> lStart )
														upChargeValue = distinctUpcharges.Fields("descriptorName")
											%>
													<td align="center" style="width:45px">
														<BUTTON class=small id="<%= upChargeValue%>" name="<%= upChargeValue%>" title="<%= distinctUpcharges.Fields("price")%>" style="
														<%
															if selUpchargeValue = upChargeValue then
														%>
															border:2px inset #CCCCCC;
														<%
															end if
														%>
														background: #FFFFFF url(../uploadedImages/<%= distinctUpcharges.Fields("imageFileName")%>) no-repeat top;
														" onClick="setSelectedUpCharge(this);"><span style="background:#f3f3f3;width:100%;border-top:1px solid gray;margin-top:26px"><%= WordTrim(upChargeValue, 15)%></span></button>
													</td>
											<%
														distinctUpcharges.MoveNext
														wend
													if lStart < noOfElements then
												%>
													<td  style="width:45px" align="center">
														<BUTTON class=small id=moreUpCharge name=moreUpCharge onClick="nextUpChargePage();" style="background:#dcdcdc"><img src="/static/icons/24x24/next.png"><br>More</button>
													</td>
											<%
													else
														if lStart > 1 And lStart >= noOfElements then

											%>
														<td  style="width:45px" align="center">
															<BUTTON class=small id=prevUpCharge name=prevUpCharge onClick="prevUpChargePage();" style="background:#dcdcdc"><img src="/static/icons/24x24/previous.png"><br>Previous</BUTTON>
														</td>
											<%
														end if
													end if
												end if
											end if
										%>
											<td>&nbsp;</td>
									</tr>
									<tr height=50>
										<td style="width:70px" >Colors</td>
										<%
											dim distinctColors, colorValue
											if curr_LineNo <> "" then
												Set distinctColors = Session("colors")
												if distinctColors.Recordcount > 0 then
													lStart = colorsStartIndex
													noOfElements = distinctColors.PageCount
													distinctColors.AbsolutePage = lStart
													while Not (distinctColors.Eof Or distinctColors.AbsolutePage <> lStart )
														colorValue = distinctColors.Fields("descriptorName")
												%>
														<td height=45px style="width:45px"  align="center">
															<BUTTON class=small id="<%= colorValue%>" name="<%= colorValue%>" style="
															<%
																if selColorValue = colorValue then
															%>
																border:2px inset #CCCCCC;
															<%
																end if
															%>
															background=<%= Replace(colorValue," ", "")%>;
															" onClick="setSelectedColor(this);"><span style="background:#f3f3f3;width:100%;border-top:1px solid gray;margin-top:26px"><%= WordTrim(colorValue,15)%><span></button>
														</td>
												<%
														distinctColors.MoveNext
													wend
													if lStart < noOfElements then
												%>
													<td style="width:45px" align="center">
														<BUTTON class=small id=moreColors name=moreColors onClick="nextColorPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/next.png"><br>More</button>
													</td>
											<%
													else
														if lStart > 1 And lStart >= noOfElements then

											%>
															<td  style="width:45px" align="center">
																<BUTTON class=small id=prevColors name=prevColors onClick="prevColorPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/previous.png"><br>Previous</button>
															</td>
											<%
														end if
													end if
												end if
											end if
										%>
										<td>&nbsp;</td>
									</tr>
									<tr height=50>
										<td style="width:70px" >Patterns</td>
										<%
											dim distinctPatterns
											dim patternValue
											if curr_LineNo <> "" then
												Set distinctPatterns = Session("patterns")
												if distinctPatterns.Recordcount > 0 then
													lStart = patternStartIndex
													noOfElements = distinctPatterns.PageCount
													distinctPatterns.AbsolutePage = lStart
													while Not (distinctPatterns.Eof Or distinctPatterns.AbsolutePage <> lStart )
														patternValue = distinctPatterns.Fields("descriptorName")
												%>
														<td height=45px style="width:45px" align="center">
															<BUTTON class=small id="<%= patternValue%>" name="<%= patternValue%>" style="
															<%
																if selPatternValue = patternValue then
															%>
																border:2px inset #CCCCCC;
															<%
																end if
															%>
															background: #FFFFFF url(../uploadedImages/<%= distinctPatterns.Fields("imageFileName")%>);
															" onClick="setSelectedPattern(this);"><span style="background:#f3f3f3;width:100%;border-top:1px solid gray;margin-top:26px"><%= WordTrim(patternValue,15)%></span></button>
														</td>
												<%
														distinctPatterns.MoveNext
													wend
													if lStart < noOfElements then
												%>
													<td  style="width:45px" align="center">
														<BUTTON class=small id=morePatterns name=morePatterns onClick="nextPatternsPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/next.png"><br>More</button>
													</td>
											<%
													else
														if lStart > 1 And lStart >= noOfElements then
											%>
														<td style="width:45px" align="center">
															<BUTTON class=small id=prevPatterns name=prevPatterns onClick="prevPatternsPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/previous.png"><br>Previous</button>
														</td>
											<%
														end if
													end if
												end if
											end if
										%>
										<td>&nbsp;</td>
									</tr>
								</table>
							</td>
						</tr>
					</table><!-- first part table ends here -->
				</td><!-- first  column ends-->
				<!-- second column -->
				<td valign=top>
					<TABLE WIDTH="275px" BORDER=0 CELLSPACING=0 CELLPADDING=0>
						<tr>
							<!-- list -->
							<td valign=top>
								<DIV STYLE="overflow-y:auto;height:420px; overflow-x:auto; width:290px;background:white;border:1px solid gray">
									<TABLE WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=0>
										<tr rowspan =5>
											<td>
												<TABLE name="invoiceTable" id ="invoiceTable" WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=3>

													<%


														dim displayRst
														dim displayAsEntered
														dim cloneRst
														dim checkItem
														dim varBookMark
														dim currDeptId
														dim displayDeptName, deptName

														Redim deptIds(0)
														set displayRst = invoice.lineItems
														if displayRst.RecordCount > 0 then
															set cloneRst = displayRst.Clone
															if ObjMiscSetUp.Count > 0 then
																displayAsEntered = ObjMiscSetUp.Item("displayItemsAsEntered")
															else
																displayAsEntered =true
															end if
															if Not displayAsEntered then
																displayRst.Sort = "itemName ASC"
															end if

															displayRst.MoveFirst
															while not displayRst.eof
																if not isNull(displayRst.Fields("deptId").Value) then
																	currDeptId = displayRst.Fields("deptId").Value
																	if not checkIfDeptExists(currDeptId) then
																		displayDeptName = false
																		Redim Preserve deptIds(UBound(deptIds)+1)
																		deptIds(UBound(deptIds)) = currDeptId
																		varBookMark = displayRst.Bookmark
																		displayRst.Filter = "deptId=" & currDeptId
																		deptName = displayRst.Fields("deptName").Value
																		while not displayRst.eof
																		checkItem =false
																		select case displayRst.Fields("itemType")
																				case "IT"

														%>
																					<%
																						if  Not displayDeptName then
																					%>
																							<tr name="dept" style="color=#B22222;">
																								<td class="label" colspan="4"><%= deptName%></td>
																							</tr>
																					<%
																							displayDeptName = true
																						end if

																						if IsNumeric(curr_LineNo) then
																							if clng(curr_LineNo) =  displayRst.Fields("lineNumber").Value then
																								checkItem = true
																							end if
																						end if
																					%>
																					<tr name="main" title="IT" onClick="selectRow(this);" <% if checkItem then%>style="background-color=#C2DACD;" <%end if %>>
																						<td colspan=2><input type="radio" name="select" id="select" value="<%=displayRst.Fields("lineNumber")%>"
																							<% if checkItem then%> checked <%end if %>
																						></td>
																						<td class="label" width="30px" align=center><%= displayRst.Fields("quantity")%></td>
																						<td class="label"><%= displayRst.Fields("itemName")%></td>
																						<td class="label" width="50px" align=right><%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
																					</tr>

																<%
																					cloneRst.Filter ="parentLineNumber=" & displayRst.Fields("lineNumber")
																					if cloneRst.Recordcount > 0 then
																						cloneRst.MoveFirst
																						while not cloneRst.Eof
																%>
																						<tr name="sub" onClick="selectRow(this);">
																							<td width=10px></td>
																							<td><input type="radio" name="select" id="select" value="<%= cloneRst.Fields("lineNumber")%>"></td>
																							<td class="label" width="30px" align=center><%= cloneRst.Fields("quantity")%></td>
																							<td class="label"><%= cloneRst.Fields("itemName")%></td>
																							<td class="label" width="50px" align=right><%= FormatCurrency(cloneRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
																						</tr>


																<%
																							cloneRst.MoveNext
																						wend
																				end if
																				cloneRst.Filter = adFilterNone
																		case "CU"
																					if  Not displayDeptName then
																%>
																						<tr name="dept" style="color=#B22222;">
																							<td></td>
																							<td class="label"><%= deptName%></td>
																							<td></td>
																							<td></td>
																						</tr>
																<%
																						displayDeptName = true
																					end if
																%>

																				<tr name="main" onClick="selectRow(this);">
																					<td colspan=2><input type="radio" name="select" id="select" value="<%= displayRst.Fields("lineNumber")%>"></td>
																					<td class="label" width="30px" align=center><%= displayRst.Fields("quantity")%></td>
																					<td class="label"><%= displayRst.Fields("itemName")%></td>
																					<td class="label" width="50px" align=right>-<%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
																				</tr>

													<%
																		case "AC"
																				if  Not displayDeptName then
													%>
																					<tr name="dept" style="color=#B22222;">
																						<td></td>
																						<td class="label"><%= deptName%></td>
																						<td></td>
																						<td></td>
																					</tr>
													<%
																					displayDeptName = true
																				end if
													%>
																				<tr name="main" onClick="selectRow(this);" style="color=#FF4500;">
																					<td colspan=2><input type="radio" name="select" id="select" value="<%= displayRst.Fields("lineNumber")%>"></td>
																					<td class="label" width="30px" align=center><%= displayRst.Fields("quantity")%></td>
																					<td class="label"><%= displayRst.Fields("itemName")%></td>
																					<td class="label" width="50px" align=right><%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
																				</tr>
												<%
																	end select
																	displayRst.MoveNext
																wend
																displayRst.Filter = ""
																displayRst.Bookmark = varBookMark
															end if
														end if
														displayRst.MoveNext
													wend
												displayRst.MoveFirst
												displayRst.Filter = "deptId=Null"
												while not displayRst.eof
										%>
													<tr name="main" onClick="selectRow(this);" style="color:#996633;">
														<td colspan=2><input type="radio" name="select" id="select" value="<%= displayRst.Fields("lineNumber")%>"></td>
														<td class="label" width="30px" align=center><%= displayRst.Fields("quantity")%></td>
														<td class="label"><%= displayRst.Fields("itemName")%></td>
														<td class="label" width="50px" align=right>-<%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2,-1,0)%></td>
													</tr>

										<%
													displayRst.MoveNext
												wend
												displayRst.Filter = ""
												end if
										%>

												</table>
											</td>
										</tr>
									</table> <!-- table for border -->
								</div>
							</td>
						</tr>
						<!-- list row ends here -->
						<tr style="background:#FFF">
							<td>
								<TABLE WIDTH="290px" BORDER=0 CELLSPACING=0 CELLPADDING=2 style="background:#FFF" >
									<tr>
										<td align=left class="label" width=100px>Total Price</td>
										<td align="right">
											<INPUT id=txtTotalPrice name=txtTotalPrice class=text style="WIDTH: 100px;height:22px;text-align:right;" value="<%= FormatCurrency(invoice.getTotalPriceForDisplay(),2, -1,0) %>" readonly>
										</td>
									</tr>
									<tr>
										<td align=left class="label" width=100px>Total Pieces</td>
										<td align="right">
											<INPUT id=txtTotal name=txtTotal class=text style="WIDTH: 100px;text-align:right;" value="<%= invoice.getTotalItemCount() %>" readonly>
										</td>
									</tr>
									<tr>
										<td colspan=2 Style = "MARGIN-top: 20px">
											<TABLE WIDTH="275px" BORDER=0 CELLSPACING=1 CELLPADDING=0  style="background:#FFF">
												<tr>
													<td align=center>
														<INPUT class=touchnoborder id=done name=done type=button value="" style="background-image:url(../images/ok.gif);" onClick="submitForm();">
														<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm();">
													</td>

												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table><!-- main table for 2nd column -->
				</td>
			</tr><!-- main table row -->
		</FORM>
	</TABLE>

</BODY>
</HTML>