<%@ Language=VBScript %>
<% Server.ScriptTimeout = 360 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<%
	dim query, rs
	dim queryName
	dim cellValue
	dim counter
	
	query = request.querystring("query")
	queryName = request.querystring("queryName")
	if queryName = "" then queryName = "results"
	
	if query = "" then response.end

	response.ContentType = "application/octet-stream"
	response.AddHeader "Content-Disposition", "attachment; filename=" & queryName & ".csv"

	set rs = getdisconnectedrecordset(query)

	if rs.recordcount > 0 then
		rs.MoveFirst
		
	  for i = 0 to rs.Fields.Count - 1
	    response.write """" & replace(rs.Fields(i).Name, """", """""") & """"
	    if i <> rs.Fields.Count - 1 then response.write ","
	  next
		  
		response.write vbcrlf
		
		
		counter = 1
		
		while not (rs.eof or rs.bof)

		  for i = 0 to rs.Fields.Count - 1
		  	if isnull(rs.Fields(i).Value) then
		  		cellValue = ""
		  	else
		  		cellValue = rs.Fields(i).Value
		  	end if
		  	
		    response.write """" & replace(cellValue, """", """""") & """"
		    if i <> rs.Fields.Count - 1 then response.write  ","
		  next

		  rs.MoveNext
		  
		  if not rs.bof then response.write vbcrlf
		  
			if counter mod 50 = 0 then response.flush
			counter = counter + 1
		wend
	end if

	response.end			
%>
