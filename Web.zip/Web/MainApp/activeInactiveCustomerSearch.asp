<%@ Language=VBScript %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim actionString
	dim l_storeid 
	dim isSubmitted 
	
	l_storeid = session("storeid")
		
	session("customersequencenumber") = null
	isSubmitted = Request.QueryString("Submitted")
	
	if (isSubmitted ) then
		dim str
		
		actionString = Request.QueryString("userAction")	
		
		if (actionstring ="search") then
		
			str= "activeInactiveCustomers.asp" & "?name=" & urlencode(Request.Form("txtcustomername"))_
					& "&customerid=" & urlencode(Request.Form("txtcustomerid"))	_
					& "&inactiveDays=" & urlencode(Request.Form("txtDaysInactive"))	_
					& "&userAction=results"
					Response.Redirect(str)
					
		end if
	end if
	
	actionString = Request.QueryString("userAction")
	dim L_routeid 

	GetMiscInfo()
	getKeyboardsetting()
	%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<HTML>
<HEAD>
<TITLE>Customer Search</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
	<SCRIPT LANGUAGE=javascript>
	var lastFocusControl;
	<!--
		
	//-->
	</SCRIPT>

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function txtCustomerName_onblur() {
	lastFocusControl = event.srcElement;
}

function txtCustomerId_onblur() {
	lastFocusControl = event.srcElement;
}

//-->
</SCRIPT>
</HEAD>

<script language="javascript" type="text/javascript">

	function cancelForm(){
	
	 	document.actInactSearchForm.action = "ManagerMenu.asp";
		document.actInactSearchForm.submit();
	}
	
	function searchCustomer(){
        var sCustomerid
        var sName;
        var retVal;

		sCustomerid = trim(document.actInactSearchForm.txtCustomerId.value)
		sName = trim(document.actInactSearchForm.txtCustomerName.value)
		var inactiveDays = trim(document.actInactSearchForm.txtDaysInactive.value)
		if (sCustomerid == "" && sName == "" && inactiveDays == ""){
		    var msg = "Search criteria could result in a large number of records. Would you like to revise your search criteria?";
            cbs_confirm(msg, setDefaultSearch, noLargeResult);
        }
        else
            noLargeResult();
	}

	function noLargeResult() {
	        clearConfirmMsg();
			document.actInactSearchForm.action =document.actInactSearchForm.action + "?Submitted=true&useraction="+"search" ;
			document.actInactSearchForm.submit();
	}


	
	function setDefaultSearch(){
	    clearConfirmMsg();
		if (document.actInactSearchForm.defaultSearch.value =="CUSTOMERID") 
			document.actInactSearchForm.txtCustomerId.focus();
		else
			document.actInactSearchForm.txtCustomerName.focus();
		
	}
	
	function captureKeyup(element){
	
		if (event.keyCode == 13){
			searchCustomer()
		}
		else if (element.name == "txtCustomerName" ){
			//validatePhone()
		}
	}
	
		
	function formatPhoneOnFocus(element){
	
		var tempval
			
		tempval = new String(trim(element.value))
		
		tempval= tempval.replace(")", "")
		
		tempval= tempval.replace("(", "")
		
		element.value = tempval.replace("-", "")
		
		objName=element.name;
		
		objThis=element;
		
		if (element.value == "" || isNum1(element.value, 0))
			validatePhone();

		}
	
	var objName;
	var objValue;
	var objThis;
	
	function validatePhone(){
	
		if (testphone(objThis) == false)
			return true;
			
		
		objValue=objThis.value
		
		if(objValue.length==3){
		
			pp=objValue;
			d4=objValue.indexOf('(')
			d5=objValue.indexOf(')')
			if(d4==-1){
				pp="("+pp;
			}
			if(d5==-1){
				pp=pp+")";
			}
	
			document.actInactSearchForm.txtCustomerName.value="";
			document.actInactSearchForm.txtCustomerName.value=pp;
		}

		if(objValue.length>3){
		
			d1=objValue.indexOf('(')
			d2=objValue.indexOf(')')
			if (d2==-1){
				l30=objValue.length;
				p30=objValue.substring(0,4);
				//alert(p30);
				p30=p30+")"
				p31=objValue.substring(4,l30);
				pp=p30+p31;
				//alert(p31);
				document.actInactSearchForm.txtCustomerName.value="";
				document.actInactSearchForm.txtCustomerName.value=pp;
			}
		}
		
		if(objValue.length>5){
		
			p11=objValue.substring(d1+1,d2);
			if(p11.length>3){
				p12=p11;
				l12=p12.length;
				l15=objValue.length
				//l12=l12-3
				p13=p11.substring(0,3);
				p14=p11.substring(3,l12);
				p15=objValue.substring(d2+1,l15);
				document.actInactSearchForm.txtCustomerName.value="";
				pp="("+p13+")"+p14+p15;
				document.actInactSearchForm.txtCustomerName.value=pp;
				//obj1.value="";
				//obj1.value=pp;
			}
			l16=objValue.length;
			p16=objValue.substring(d2+1,l16);
			l17=p16.length;
			if(l17>3&&p16.indexOf('-')==-1){
			
				p17=objValue.substring(d2+1,d2+4);
				p18=objValue.substring(d2+4,l16);
				p19=objValue.substring(0,d2+1);
				//alert(p19);
				pp=p19+p17+"-"+p18;
				document.actInactSearchForm.txtCustomerName.value="";
				document.actInactSearchForm.txtCustomerName.value=pp;
				//obj1.value="";
				//obj1.value=pp;
			}
		}
		
			
	}
	
	
	function testphone(obj1){
		retval = false
		objValue=obj1.value
		//alert(p)
		objValue=objValue.replace("(","")
		objValue=objValue.replace(")","")
		objValue=objValue.replace("-","")
		//alert(isNaN(p))
		if (isNum1(objValue, 0) )
			retval = true;
		
		return retval
}

		
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onLoad ="setDefaultSearch()">
<!-- #include file="../include/banner.inc" -->
<H1>Customer Search</H1>
<center>
<TABLE width="100%" align=center cellspacing="2" cellpadding="0" border="0" style="WIDTH: 100%">
<TR>
   <TD>
   <FORM id="actInactSearchForm" name="actInactSearchForm"  action="" method="Post">
   <input type="hidden" name="functionID" id="functionID" value="">
	<INPUT type="hidden" name="defaultSearch" value="<%=defaultsearch%>">
	
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=0 >
			<TR>
				<TD class="label" align=right>Customer Lastname&nbsp;or&nbsp;Phone Number&nbsp
			    </TD>
				<TD>
					<INPUT id=txtCustomerName name=txtCustomerName 
			        class=text LANGUAGE=javascript onFocus= "formatPhoneOnFocus(this)" onKeyUp="captureKeyup(this)" onblur="return txtCustomerName_onblur()" 
					style="HEIGHT: 25px; WIDTH: 255px">
				</TD>
				<TD valign=middle rowspan="2">
					<INPUT style="width:100px;height:50px" id=searchButton name=searchButton type=button value="Search" onclick="searchCustomer()" />
					<INPUT style="width:100px;height:50px" id=cancelButton name=cancelButton type=button value="Cancel" onClick="cancelForm()" />
				</TD>
				
			</TR>
			<TR>
				<TD align=right class="label">Customer ID&nbsp</TD>
				<TD >
					<INPUT id=txtCustomerId name=txtCustomerId class=text LANGUAGE=javascript onkeyup="captureKeyup(this)" onblur="return txtCustomerId_onblur()"  style="HEIGHT: 25px; WIDTH: 254px">
				</TD>

			</TR>
			<TR>
				<TD align=right class="label">Inactive X Days</TD>
				<TD >
					<INPUT type="number" onkeypress="return (event.charCode == 8 || event.charCode == 0 || event.charCode == 13) ? null : event.charCode >= 48 && event.charCode <= 57"
					    min="0" step="1" id=txtDaysInactive name=txtDaysInactive class=text LANGUAGE=javascript onkeyup="captureKeyup(this)" onblur="return txtCustomerId_onblur()"  style="HEIGHT: 25px; WIDTH: 254px">
				</TD>

			</TR>
			<tr height=30px><td></td></tr>
			<tr>
				<td colspan=4 align="center">
					<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=0 >
						<tr>
							<% if l_keyboard  then %>
							<!-- #include file="../include/keyboard_alphabeticalOrder.inc" -->								
							<% else %>
							<!-- #include file="../include/keyboard.inc" -->
							<%end if %>
							<td width=70px></td>
						</tr>
					</table>
				</td>
				
			</tr>
		</TABLE>
		<P>&nbsp;</P>
		
		
		
		<BR>
	</TD>
</TR>
</TABLE></FORM>   
</center>
</BODY>
</HTML>
<%
	Function GetMiscInfo()
		dim sqltxt 
		sqltxt = "select * from customersetupoptions where storeid = " & l_storeid
		set rstMisc = GetDisconnectedRecordset(sqltxt)
		if not rstMisc.bof and not rstMisc.eof then
			defaultSearch = rstMisc("DefaultSearchMethod")	
		end if
	end function
	
%><%
	dim l_keyboard
	
	function getKeyboardsetting()
	dim sqltxt
	dim rsTemp
	
	l_keyboard = false
	
	sqltxt = "select switchOnscreenKeyboardAlphabetic from Miscsetup where storeid =  " & session("storeid")
	set rsTemp = getDisconnectedrecordset(sqltxt)
	'Response.Write sqltxt
	if rsTemp.recordCount > 0 then
		if rsTemp("switchOnscreenKeyboardAlphabetic")= true then
			l_keyboard = true
		end if
	end if
	rstemp.close
	set rstemp = nothing
		
	
	end function
	
	
	
%>
