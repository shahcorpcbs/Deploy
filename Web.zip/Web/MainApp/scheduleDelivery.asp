<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 900 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
    dim query, rs


	select case lcase(request.querystring("useraction"))
		case "unschedule"
		
			unschedule request.querystring("deliverywillcallid")
	end select

	if request.querystring("customerseq") <> "" then
		schedulePickUp request.querystring("customerseq"), Date(), "Scheduled Pickup"
	end if

	function unschedule(deliverywillcallid)
		dim query, rs
		
		if deliverywillcallid <> "" then
			query = " update deliverywillcall set status = -1 "
			query = query & " where status = 0 and actionrequired = 'PICKUP' "
			query = query & " and deliverywillcallid = " & deliverywillcallid
			
			qryexecute query
		end if
	end function


	function unschedulePickUp(customerSequenceNumber)
		dim query, rs
		
		if customerSequenceNumber <> "" then
			query = " update deliverywillcall set status = -1 "
			query = query & " where status = 0 and actionrequired = 'PICKUP' "
			query = query & " and customersequencenumber = " & customersequencenumber
			
			qryexecute query
		end if
	end function

	function schedulePickUp(customerSequenceNumber, scheduledDate, note)
		dim query, rs
		
		if scheduledDate <> "" then
			unschedulePickUp customerSequenceNumber
			
			query = " insert into deliverywillcall (customersequencenumber, actionrequired, scheduledDate, note) "
			query = query & " values (" & customerSequenceNumber
			query = query & ", 'PICKUP'"
			query = query & ", '" & scheduledDate & "'"
			query = query & ", " & DbCreateQryString(note)
			query = query & ")"


			qryexecute query
		end if
	end function


%>
<html>
<head>
<title>Route Setup</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">

</head>

<script type="text/javascript">
	var previousElement = null;
	var deliveryWillCallID = null;


	function exit() {
		document.scheduleDelivery.action = '/mainapp/deliveryManager.asp';
		document.scheduleDelivery.submit();
	}

	function unschedule() {
		if(deliveryWillCallID) {
			document.scheduleDelivery.action = '/mainapp/scheduledelivery.asp?useraction=unschedule&deliverywillcallid=' + deliveryWillCallID;
		    document.scheduleDelivery.submit();
		}
		else {
			cbs_alert("Select a delivery to unschedule.");
		}
	}

	function selectRow(element) {
		var childEl;

		if (previousElement !=null){
			previousElement.className="";
		}

		deliveryWillCallID = element.getAttribute("deliveryWillCallID");

		previousElement =element;
		
		element.className = "selected";
	}
	
	function addCustomer() {
		document.scheduleDelivery.action = "/mainapp/customersearch.asp?targetPage=scheduledelivery";
		document.scheduleDelivery.submit();
	}
</script>




<body topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Schedule Delivery</H1>


<form id="scheduleDelivery" name="scheduleDelivery" action="" Method="post" onSubmit="return false">

	<div name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
		<span style="float:left">
			<button style="vertical-align: top" onclick="addCustomer()">Add<br>Customer</button>
			<button onclick="unschedule()">Unschedule</button>
		</span>
		<span style="float:right">
			<button onclick="exit()">Exit</button>
		</span>
	</div>
	

    <table class="itable" border="0" cellspacing="0">
        <tr>
			<th>Action</th>
			<th>Date</th>
            <th>Customer</th>
			<th>Route</th>
			<th>Status</th>
        </tr>
<%
		query = " select deliverywillcall.*, customer.customername, route.name as routename, case status when 0 then 'Active' else '' end as statustext from "
		query = query & " deliverywillcall "
		query = query & " inner join customer on deliverywillcall.customersequencenumber = customer.customersequencenumber "
		query = query & " inner join route on customer.routenumber = route.routenumber "
		query = query & " where status >= 0 and deliveryid is null "
		query = query & " and datediff(d, scheduleddate, getdate()) <= 14 "
		query = query & " order by deliverywillcall.status desc, scheduleddate desc "

		set rs = getdisconnectedrecordset(query)

		while not (rs.eof or rs.bof)
%>
        <tr onclick="selectRow(this)" deliveryWillCallID="<%=rs("deliveryWillCallID")%>" <%if rs("status") < 0 then%>style="color:#aaa"<%end if%>>
			<td><%=rs("actionrequired")%></td>
			<td><%=rs("scheduleddate")%></td>
            <td><%=rs("customername")%></td>
			<td><%=rs("routename")%></td>
			<td><%=rs("statustext")%></td>
        </tr>
<%
			rs.movenext
		wend

		set rs = nothing
%>
	</table>

</form>
</body>
</html>
