<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	
	dim storeId
	dim custFinishPref
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim dueDateSet
	dim dueDate
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim targetPage
	dim invoicePref
	dim invoice
	on error resume next
	custFinishPref = Session("finishPref")
	set invoice = Session("invoice")
	invoicePref = invoice.finishPref
	storeId = Session("storeID")
	
	curr_LineNo = Request.Form("lineNumber")
	selectedDept = Request.Form("selectedDept")
	itemsStartIndex = Request.Form("ItemPageCount")
	upChargeStartIndex = Request.Form("upChargePageCount")
	colorsStartIndex = Request.Form("colorsPageCount")
	patternStartIndex = Request.Form("PatternPageCount")
	addOrEdit = Request.Form("addOrEdit")
	dueDateSet = Request.Form("isDueDateSet")
	dueDate = Request.Form("txtDueDate")
	deptStartIndex = Request.Form("DeptPageCount")
	selItemId = Request.Form("selItemId")
	selUpchargeValue = Request.Form("selUpcharge")
	selColorValue = Request.Form("selColor")
	selPatternValue = Request.Form("selPattern")
	targetPage = Request.QueryString("targetPage")
	
	sub getAllFinishPref()
		dim ssql
		dim objResultSet
		ssql ="SELECT finishPreferenceName, imageFileName FROM StoreFinishPreference where storeid=" & clng(storeId) _ 
				& " AND enabled=1 Order by displaySequence" 
		Set objResultSet = getDisconnectedRecordset(ssql)
		set Session("finishPrefMaster") = objResultSet
	end sub
%>

<HTML>
<HEAD>
<TITLE>Invoice Number</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript">
	function setFinishPref(element){
		var prefName;
		var custPref;
		var changeCustPref;
		var targetPage;

		custPref = document.finishPref.CustFinishPref.value;
		targetPage = document.finishPref.tPage.value;
		prefName = element.name;
		if (prefName != custPref)
		    cbs_confirm("Would you like to change " + custPref + " preference to " + prefName, changeYes, changeNo);
		else
            finishSetFinish(targetPage, prefName, "no");
	}

	function changeYes() {
        clearConfirmMsg();
		var targetPage = document.finishPref.tPage.value;
		var prefName = element.name;
        finishSetFinish(targetPage, prefName, "yes");
	}
	function changeNo() {
        clearConfirmMsg();
		var targetPage = document.finishPref.tPage.value;
		var prefName = element.name;
        finishSetFinish(targetPage, prefName, "no");
	}

	function finishSetFinish(targetPage, prefName, changeStatus) {
            if (targetPage =="detail"){
                document.finishPref.action = "detailedInvoice.asp?userAction=changeFinishPref&pref=" + prefName + "&changeStatus=" +  changeStatus;
            }else{
                if (targetPage =="quick") {
                    document.finishPref.action = "quickinvoice.asp?userAction=changeFinishPref&pref=" + prefName + "&changeStatus=" +  changeStatus;
                }
            }
            document.finishPref.submit();
	}

</script>

<BODY topmargin=0 leftmargin=0>
	<!-- #include file="../include/banner.inc" -->
<H1>Select Starch Preference</H1>
	<FORM id="finishPref" name="finishPref" action="finishPreferences.asp" method="post">
		<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
		<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
		<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
		<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
		<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
		<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
		<INPUT type="hidden" name="couponPageCount" value="<%= couponStartIndex %>">
		<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
		<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
		<INPUT type="hidden" name="CustFinishPref" value="<%= custFinishPref %>">
		<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
		<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
		<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
		<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
		<INPUT type="hidden" name="tPage" value="<%= targetPage%>">
		<TABLE ALIGN=center WIDTH="150px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
			<%
				dim rst
				set rst = Session("finishPrefMaster")
				if rst.Recordcount > 0 then
					rst.MoveFirst
					while not rst.Eof
			%>
						<tr>
							<td align=center>
								<button style="width:90px;height:40px;" style="background:white" id="<%= rst.Fields("finishPreferenceName") %>" name="<%= rst.Fields("finishPreferenceName") %>" onClick="setFinishPref(this);"
								<%
									 if invoicePref = rst.Fields("finishPreferenceName") then
								%>
									style="border:2px inset #CCCCCC;"
								<%
									end if
								%>
								>
								<%= rst.Fields("finishPreferenceName") %>
								</button>
							</td>
						</tr>
			<%
						rst.MoveNext
					wend
				end if
			%>
			<tr>
				<td align=center>
					<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="history.back(-1);">
				</td>
			</tr>
		</table>
	</FORM>
</body>
</HTML>
