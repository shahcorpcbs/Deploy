<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
    dim customerseq
    dim canSms, canEmail, blackListed, twilioNum
    dim query2, rs2, sms, email
    dim hasManualValues, setOption

	customerseq = session("customersequencenumber")
    setOption = trim(Request.QueryString("option"))


	if trim(Request.QueryString("useraction")) = "submit" then
		SaveFormData()
	end if

    canSms = getMSVar("useTwilio")
    canEmail = getMSVar("useEmail")
    twilioNum = getMSVar("twilioFromNumber")


    hasManualValues = 0
    query = "select id from CustomerMessageSetup where customerId = " & customerseq
    set rs = getdisconnectedrecordset(query)
    if rs.recordcount > 0 then
        hasManualValues = 1
    end if

	query = "select twilioBlackList from Customer where customerSequenceNumber = " & customerseq
	set rs = getdisconnectedrecordset(query)
	blackListed = rs("twilioBlackList")

    if blackListed then
        twilioNum = getMSVar("twilioFromNumber")
    end if

    function SaveFormData()
        dim query2, currId
        query = "delete CustomerMessageSetup where CustomerId = " & customerseq
        qryexecute query


        if setOption = 1 then
        query = "select id from QueryAlert where messageTypeId in (2, 3)"
        set rs = getdisconnectedrecordset(query)
        while not(rs.eof or rs.bof)
            currId = rs("id")

            sms = trim(Request.QueryString("chkSmsReport" & currId))
            email = trim(Request.QueryString("chkEmailReport" & currId))

                query2 = "insert into CustomerMessageSetup (CustomerId, QueryId, Sms, Email) values (" _
                    & customerseq & ", " & currId & ", " & sms & ", " & email & ")"
                qryexecute query2


        rs.movenext
        wend
        end if


		Response.redirect("CustomerEntry.asp?mode=edit")
    end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function
%>

<html>
<head>
<title>Customer Notification SetUp</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</head>
<SCRIPT type="text/javascript" >
	function init() {
	     $("#twilioNum").text(formatPhoneNumber(<%=twilioNum%>));
	     <% if hasManualValues = 1 then %>
	        $("#sourceM").attr('checked', true);
	        setFieldsForCustomer();
	     <% else %>
	        $("#sourceD").attr('checked', true);
	        setFieldsForDefault();
	     <% end if %>
	}

	function selChange(option) {
	    $("#sourceM").attr('checked', true);
        var checkboxes = $(this).closest('form').find(':checkbox');
        $('input[type=checkbox]').each(function () {
            if (this.id != 'chkSmsReport-10') {
                if (option == 2) {
                    if (this.id.indexOf("chkSms") != -1)
                        this.checked = true;
                }
                else if (option == 3) {
                    if (this.id.indexOf("chkEmail") != -1)
                        this.checked = true;
                }
                else
                    this.checked = (option == 1);
                this.disabled = false;
            }
        });
	}

	function sourceChange(option) {
        if (option == 0)
            setFieldsForDefault();
        else
            setFieldsForCustomer();
	}


    function setFieldsForCustomer() {
        <%
            query = "select id from QueryAlert where messageTypeId in (2, 3) and id != -10"
            set rs = getdisconnectedrecordset(query)
            while not(rs.eof or rs.bof)
                sms = 0
                email = 0

                if hasManualValues = 1 then
                    query2 = "select sms, email from CustomerMessageSetup where queryId = " & rs("id") & " and customerId = " & customerseq
                    set rs2 = getdisconnectedrecordset(query2)
                    if rs2.recordCount > 0 then
                        sms = rs2("sms")
                        email = rs2("email")
                   end if
                end if
         %>

        <% if hasManualValues = 1 then %>
             $("#chkSmsReport<%=rs("id")%>").attr('checked', '<%= sms %>' === 'True');
             $("#chkEmailReport<%=rs("id")%>").attr('checked', '<%= email %>' === 'True');
         <% end if %>

         $("#chkSmsReport<%=rs("id")%>").attr('disabled', false);
         $("#chkEmailReport<%=rs("id")%>").attr('disabled', false);

        <%
            rs.movenext
            wend
        %>

    }

    function setFieldsForDefault() {
        <%
            query = "select id from QueryAlert where messageTypeId in (2, 3) and id != -10"
            set rs = getdisconnectedrecordset(query)
            while not(rs.eof or rs.bof)
                sms = 0
                email = 0
                query2 = "select sms, email from CustomerMessageSetup where queryId = " & rs("id") & " and customerId = 0"
                set rs2 = getdisconnectedrecordset(query2)
                if rs2.recordCount > 0 then
                    sms = rs2("sms")
                    email = rs2("email")
               end if
         %>

         $("#chkSmsReport<%=rs("id")%>").attr('checked', '<%= sms %>' === 'True');
         $("#chkSmsReport<%=rs("id")%>").attr('disabled', true);
         $("#chkEmailReport<%=rs("id")%>").attr('checked', '<%= email %>' === 'True');
         $("#chkEmailReport<%=rs("id")%>").attr('disabled', true);

        <%
            rs.movenext
            wend
        %>
	}

    function formatPhoneNumber(phoneNumberString) {
      var cleaned = ('' + phoneNumberString).replace(/\D/g, '');
      var match = cleaned.match(/^(1|)?(\d{3})(\d{3})(\d{4})$/);
      if (match) {
        var intlCode = (match[1] ? '+1 ' : '');
        return ['(', match[2], ') ', match[3], '-', match[4]].join('');
      }
      return null;
    }

function submitForm() {

        var option = $("input[name=source]:checked").val();

        if (option == 1) {
    var reports = '';
    <%
        query = "select id from QueryAlert where messageTypeId in (2, 3)"
        set rs = getdisconnectedrecordset(query)
        while not(rs.eof or rs.bof)
    %>


        reports = reports + "&chkSmsReport<%=rs("id")%>=" + ($("#chkSmsReport<%=rs("id")%>").is(":checked") ? "1" : "0") +
                "&chkEmailReport<%=rs("id")%>=" + ($("#chkEmailReport<%=rs("id")%>").is(":checked") ? "1" : "0");
    <%
        rs.movenext
        wend
    %>
            document.editCustomerNotificationForm.action = "?useraction=submit&option=1" +
	    "&customerseq=<%=customerseq%>" + reports;
        }
        else
            document.editCustomerNotificationForm.action = "?useraction=submit&option=0&customerseq=<%=customerseq%>";

	document.editCustomerNotificationForm.submit();
}

function cancelForm() {
		document.editCustomerNotificationForm.action = "\CustomerEntry.asp?mode=edit&customerseq=<%=customerseq%>";
		document.editCustomerNotificationForm.submit();
}

</SCRIPT>
<body topmargin=0 leftmargin=0 onload="init()"><!-- #include file="../include/banner.inc" -->

<form name="editCustomerNotificationForm" action="" method="post" style="margin:0px">
<H1>Edit Customer Notifications</H1>
<% if blackListed then %>
    <span style="text-align: center; width: 100%; font-size: 14px">Note: Customer has requested not to receive sms messages.
    If they wish to start receiving them again, have them text 'start' to number <span id="twilioNum"></span></span>
<% end if %>
	<TABLE  ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=30px></tr>
		<tr style="text-align: left">
		    <th>Source:</th>
		    <td style="white-space: nowrap;"><input type="radio" name="source" id="sourceD" value="0" onClick="sourceChange(0)"><label for="sourceD">Default Settings</label></td>
		    <td style="white-space: nowrap;"><input type="radio" name="source" id="sourceM" value="1" onClick="sourceChange(1)"><label for="sourceM">Manually Set</label></td>
        </tr>
		<tr style="text-align: left">
		    <% if not canSms or not canEmail then %>
		    <th></th>
		    <% end if %>
		    <td style="white-space: nowrap;"><input type="radio" name="sel_choice" id="sel_all" value="0" onClick="selChange(1)"><label for="sel_all">Select All</label></td>
		    <% if canSms and canEmail then %>
		        <td style="white-space: nowrap;"><input type="radio" name="sel_choice" id="sel_allSMS" value="0" onClick="selChange(2)"><label for="sel_allSMS">Select All SMS</label></td>
		        <td style="white-space: nowrap;"><input type="radio" name="sel_choice" id="sel_allEmail" value="0" onClick="selChange(3)"><label for="sel_allEmail">Select All Email</label></td>
		    <% end if %>
		    <td style="white-space: nowrap;"><input type="radio" name="sel_choice" id="sel_none" value="1" onClick="selChange(0)"><label for="sel_none">Select None</label></td>
        </tr>


        <tr style="text-align: left">
            <th></th>
            <th>Message</th>
            <% if canSms then %>
                <th>SMS<br />Notification</th>
            <%end if %>
            <% if canEmail then %>
                <th>Email Notification</th>
            <% end if %>
        </tr>
        <tr><td style="white-space: nowrap; font-weight: bold">Transactions:</td></tr>
        <%
            query = "select id, name, triggerType from QueryAlert where messageTypeId in (2, 3) and groupType = 1 order by id desc"
            set rs = getdisconnectedrecordset(query)

            while not(rs.eof or rs.bof)
        %>
            <tr <% if rs("triggerType") = 0 then %>style="display: none" <% end if %>><td></td>
                <td style="white-space: nowrap;"><%= rs("name") %></td>
                    <% if rs("id") = "-10" then %>
                        <td><INPUT type=checkbox id="chkSmsReport<%=rs("id")%>" checked disabled> </TD>
                        <td> </TD>
                    <% else %>
                        <% if canSms then %>
                            <td><INPUT type=checkbox id="chkSmsReport<%=rs("id")%>"> </TD>
                       <% end if  %>
                       <% if canEmail then %>
                        <td> <INPUT type=checkbox id="chkEmailReport<%=rs("id")%>"> </TD>
                       <% end if %>
                   <% end if %>
            </tr>
        <%
            rs.movenext
            wend
            set rs = nothing
        %>


        <tr><td style="white-space: nowrap; font-weight: bold; padding-top: 40px">Customer Service:</td></tr>
        <%
            query = "select id, name, triggerType from QueryAlert where messageTypeId in (2, 3) and groupType = 2 order by id desc"
            set rs = getdisconnectedrecordset(query)

            while not(rs.eof or rs.bof)
        %>
            <tr <% if rs("triggerType") = 0 then %>style="display: none" <% end if %>><td></td>
                <td><%= rs("name") %></td>
                    <% if canSms then %>
                        <td><INPUT type=checkbox id="chkSmsReport<%=rs("id")%>"> </TD>
                   <% end if  %>
                   <% if canEmail then %>
                    <td> <INPUT type=checkbox id="chkEmailReport<%=rs("id")%>"> </TD>
                   <% end if %>
            </tr>
        <%
            rs.movenext
            wend
            set rs = nothing
        %>


        <tr><td style="white-space: nowrap; font-weight: bold; padding-top: 40px">Delivery:</td></tr>
        <%
            query = "select id, name, triggerType from QueryAlert where messageTypeId in (2, 3) and groupType = 3 order by id desc"
            set rs = getdisconnectedrecordset(query)

            while not(rs.eof or rs.bof)
        %>
            <tr <% if rs("triggerType") = 0 then %>style="display: none" <% end if %>><td></td>
                <td style="white-space: nowrap;"><%= rs("name") %></td>
                    <% if canSms then %>
                        <td><INPUT type=checkbox id="chkSmsReport<%=rs("id")%>"> </TD>
                   <% end if  %>
                   <% if canEmail then %>
                    <td> <INPUT type=checkbox id="chkEmailReport<%=rs("id")%>"> </TD>
                   <% end if %>
            </tr>
        <%
            rs.movenext
            wend
            set rs = nothing
        %>



		<tr height=30px></tr>
		<tr>
			<TD colspan="6">
				<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick="submitForm()">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton style="background-image:url(../images/Cancel.gif)" type=button value="" onClick="cancelForm()">
						</TD>
					</tr>
				</table>
			</TD>
		</tr>
		<tr height=100px><td></td></tr>
</table>

</form>

</body>
</html>
