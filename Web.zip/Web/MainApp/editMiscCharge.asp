<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->

<%sec_RequestAccess Request.QueryString("useraction")%>

<%
	dim isSubmitted
	dim startDate
	dim endDate
		isSubmitted = Request.QueryString("submitted")
		if (isSubmitted) then
			updateDatabase()
		end if 
		
	getCharges()
	
%>
<HTML>
<HEAD>
<TITLE>Edit Misc Charges</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="JavaScript" src="../script/webui.js"></script>
<script language="javascript" type="text/javascript">

	var previousElement=null;
	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.style.background="white";
		}
		childEl = element.children[0];
		var rowChildNodes = childEl.children
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if(childEl.tagName == "INPUT") {
				childEl.checked=true;
				break;
			}
		}
		previousElement =element;
		element.style.background="#DBF2F4";
		
		var mRows = document.all("chargelist").rows.length
		if (mRows > 0 ){
			document.editMiscCharges.editAmount.disabled = false
			document.editMiscCharges.editDesc.disabled = false
			if (mRows == 1){
				document.editMiscCharges.selectedChargeType.value = ""
				document.editMiscCharges.selectedChargeType.value=document.editMiscCharges.typeofcharge.value;
				
			}
			else {
				var i
				i = 0;
				while ( i < document.all("select").length){
					if (document.all("select").item(i).checked) {
						document.editMiscCharges.selectedChargeType.value = ""
						document.editMiscCharges.selectedChargeType.value= document.editMiscCharges.typeofcharge(i).value;
					break;
					}
				i++	
				}	
			}	
		}
		 
	}
	
	function changeAmount(){
        cbs_prompt("Enter new Charge Amount", handleChangeAmt, "0.00", false, true);
	}

	function handleChangeAmt() {
        clearPromptMsg();
        var amt = document.getElementById('inputTxtLine').value
		if (amt!= null ) {
			if (isNum1(trim(amt), 1)){
                document.editMiscCharges.action = "?Submitted=true&userAction=Amount&Amount=" + cleanNumeric(amt);
                document.editMiscCharges.submit();
			}
		}
		else
		    return false;
	}
	
	function changeDescription(){
	    cbs_prompt("Enter new Charge Description", handleChangeDescr);
	}

	function handleChangeDescr() {
        clearPromptMsg();
        var desc = document.getElementById('inputTxtLine').value
		if (desc!= null   ) {
			document.editMiscCharges.action = "?Submitted=true&userAction=description&Description=" + trim(desc);
			document.editMiscCharges.submit();
		}
		else
		    return false;
	}


	function getCharges(){
		document.editMiscCharges.action = "?userAction=getcharges";
		document.editMiscCharges.submit();	
		
	}
	
	function cancelForm() {
		document.editMiscCharges.action = "customerfunctions.asp";
		document.editMiscCharges.submit();
	}
	
	function getTodaysDate(){
			var now ;
			var x
			now = new Date();
			
			x = formatString(now.getMonth()+ 1)  + "/" + formatString(now.getDate()) + "/" + now.getFullYear()
			return x;
	}
	
	function getpastDate(){
			var now ;
			var x
			now = new Date();
			now.setMonth(now.getMonth()-3)
			x = formatString(now.getMonth()+ 1 )  + "/" +formatString( now.getDate()) + "/" + now.getFullYear()
			return x;
		}
	
	
	function formatString(element){
		var x
		x = String(element)
		if (x.length < 2) 
			x = "0" + x; 
		return (x);
	
	
	}
	
		
	function setDateOnLoad(){
	
		if (document.editMiscCharges.txtFromDate.value =="" ) 
			document.editMiscCharges.txtFromDate.value = getpastDate()
			
		if (document.editMiscCharges.txtToDate.value =="" ) {
			document.editMiscCharges.txtToDate.value =getTodaysDate()
			getCharges();	
		}
	}	
		
</script>
<BODY topmargin=0 leftmargin=0 onLoad="setDateOnLoad()">
<!-- #include file="../include/banner.inc" -->
<H1>Edit Miscellaneous Charge</H1>
<FORM id="editMiscCharges" name="editMiscCharges" action="" method="Post">
<input type= hidden name=selectedChargeType value = "">
<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5>
	<Tr>
		<TD align=center   class="label">From Date
		<INPUT id=txtFromDate valign=top name=txtFromDate  readonly class=text style="HEIGHT: 25px; WIDTH: 130px;vertical-align=top" value = "<%=startdate%>">
		<INPUT class=touch valign=top id=FromDate name=FromDate type=button  style="width:25px;height:25px;" style="vertical-align=top;background-image:url(../images/Calender.gif)" onClick="javascript:show_calendar('editMiscCharges.txtFromDate');">
		</TD>
		<td> </td>
	</tr>
		
	<tr>
			<TD align=center class="label" >&nbsp;&nbsp;To Date
			<INPUT valign=top id=txtToDate name=txtToDate  readonly class=text style="HEIGHT: 25px; WIDTH: 130px;vertical-align=top" value = "<%=enddate%>">
			<INPUT valign=top class=touch id=ToDate name=ToDate type=button  style="width:25px;height:25px;" style="vertical-align=top;background-image:url(../images/Calender.gif)" onClick="javascript:show_calendar('editMiscCharges.txtToDate');">
			</TD>
			<td align = left >
			<INPUT  class=touch id=showCharges name=showCharges type=button value="" style="vertical-align=top;background-image:url(../images/Search-data.gif)" onClick="getCharges()"><br>&nbsp;&nbsp;&nbsp;
			</td>
	</tr>
	<!-- header row -->
	<tr>
		<td align="center" >
			<TABLE WIDTH="500px" BORDER=0 CELLSPACING=1 CELLPADDING=5>
			
				<!-- heading -->
				<tr>
					<th width=25px></th>
					<th width =120px align=left class="label">Date</th>
					<th width =450px align=left class="label">Description</th>
					<th width =120px align=left class="label">Amount</th>
					<th width=16px></th>
				</tr>
			</table>
		</td>
			<td width = 100px></td>
	</tr>
	<!-- list -->
	<tr>
		<td align="center">
			<DIV STYLE="overflow-y:auto;height:200px; overflow-x:auto; width=600px">
					<TABLE WIDTH="100%" style="border-color:#2F4F4F;border-style:solid;background-color:white;" BORDER=1 CELLSPACING=0>
						<tr rowspan =5>
							<td>
								<TABLE id="chargelist" name = "chargelist" WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=3>
								<!-- to be removed while coding -->	
									<% if isobject(rstcharge) then
										if rstcharge.recordcount > 0 then
									
										While not rstcharge.eof 
									%>
									<tr onClick="selectRow(this)" >
									<td width=25px><input type="radio" name="select" id="select" style="height=28px;width=28px" value= "<%=rstCharge("chargeid")%>"></td>
										<td width = 120px  STYLE="FONT-SIZE: 12px;" ><%=rstCharge("effectivedate")%></td>
										<td width = 320px  STYLE="FONT-SIZE: 12px;" ><%=rstCharge("chargedescription")%></td>
										<td width = 120px  STYLE="FONT-SIZE: 12px;" ><input type=hidden name = typeofcharge value = "<%=rstcharge("chargetype")%>">
										<% if rstcharge("chargetype") = "C" then %>
											<%=-rstCharge("chargeamount")%>
										<%else %>
											<%=rstCharge("chargeamount")%>
										<% end  if%>
										</td>
										<td width = 16px></td>
									</tr>
									<% rstCharge.movenext
										wend
										end if
										set rstcharge = nothing
										End if
									%>
								</table>
							</td>
						</tr>
				</table> <!-- table for border -->
			</div>
		</td>
		<td width = 100px valign=top>
			<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
				<tr>
				<!--	<td><INPUT class=touch id=delete name=delete type=button value=""><br>Delete</td>-->
				</tr>
				<tr>
					<td>					
						<INPUT class=touch id=editAmount name=editAmount type=button value="" style="background-image:url(../images/Edit-Money.gif)" disabled onClick = "changeAmount()"><br>Edit Amount
					</td>
				</tr>
				<tr>
					<td>					
						<INPUT class=touch id=editDesc name=editDesc type=button value="" disabled style="background-image:url(../images/Edit.gif)" onClick = "changeDescription()"><br>Edit Description
					</td>
				</tr>
			</table>	
		</td>
	</tr>
	<!-- buttons -->
	<tr>
		<td align="center">
			<TABLE WIDTH="500px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
				<tr height=20px></tr>
				<tr>
					<td width=30%></td>
					<td  width=100px align="center">
						<INPUT class=touchnoborder id=ok name=ok type=button value="" style="background-image:url(../images/OK.gif)" onClick="cancelForm()">
					</td>
					<td align="center">
						<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm();">
					</td>
					<td width=100px></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</form>
</BODY>
</HTML>
<%
	dim rstCharge
	
	
	function getCharges()
		dim sqltxt
		
		startdate = trim(Request.Form("txtFromDate"))
		enddate = trim(Request.Form("txtToDate"))
		
		sqltxt = "SELECT [chargeID], [chargeType],[chargeDescription], [chargeAmount], convert(varchar, effectiveDate, 101) as 'effectivedate' from [MiscCharge] " _
					& " where internaltransaction = 0 and customersequencenumber = " & session("customerSequenceNumber")_
					& " and  convert(varchar, effectiveDate, 112) between convert(varchar, cast(  " & dbcreateqrystring(startdate)_
					& "  as datetime), 112) and convert(varchar, cast(  " & dbcreateqrystring(enddate) &  " as datetime), 112) " _
					& " union "_
					& " SELECT [financeChargeID] as 'chargeid', 'FC' as 'chargetype',  'finance charge' as  'chargeDescription' ,[financechargeAmount]  as 'chargeAmount' ,  "_
					& " convert(varchar, chargedate, 101) as 'effectivedate' from [FinanceCharge] " _
					& " where customersequencenumber = " & session("customerSequenceNumber")_
					& " and convert(varchar, chargedate, 112) between convert(varchar, cast(  " & dbcreateqrystring(startdate)_
					& "  as datetime), 112) and convert(varchar, cast(  " & dbcreateqrystring(enddate) &  " as datetime), 112)"
					
		'	Response.Write sqltxt
		'	Response.End
			
		set rstCharge = getdisconnectedrecordset(sqltxt)
		
	end function
	
	function updateDatabase()
	dim sqltxt
	dim strAction
	dim strdescription
	dim strAmount
	
	strAction = Request.QueryString("userAction")

	if (strAction = "description") then
	
			strDescription = Request.QueryString("Description")
			
			sqltxt = "Exec dbo.EditMiscChargeDescription "  & Request.Form("select") _
					& " , '" & strDescription _
					& " ', " & dbcreateQrystring(Request.Form("selectedChargeType"))
			'Response.Write sqltxt
			dbstartTrans()
			
			qryExecuteWithTrans(sqltxt)
			
			dbendTrans()
			
	elseif (strAction = "Amount") then
	
			strAmount = Request.QueryString("Amount")
			sqltxt = "Exec dbo.EditMiscCharges "  & Request.Form("select") _
					& " , " & dbcreateQrystring(Request.Form("selectedChargeType"))_
					& " , " & strAmount _
					& " , " & session("employeeid")_
					& " , " & session("CustomerSequenceNumber")_
					& ", " & session("storeid")
			'Response.Write sqltxt
			dbstartTrans()
			
			qryExecuteWithTrans(sqltxt)
			
			dbendTrans()
	end if
		
	 end function
%>