<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!--#include file="../include/messages.asp" -->

<HTML>
<HEAD>
<TITLE>Report</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

<SCRIPT LANGUAGE="JavaScript">

	var intervalID = 0
	var oSaveAs
	//var isReady=false;

	function ScheduleReport() {
		parent.reportbody.focus();
		window.open("reportFrequency.asp?" + Math.random() + "=" + Math.random(), "_parent"); //, "fullscreen=yes,status=yes,toolbar=yes,menubar=yes,location=no,titlebar=yes");
	}

	function closeTimedWindow() {

		if (intervalID > 0) {
			oSaveAs.close();
			clearInterval(intervalID);
		}
		else {
			cbs_alert("closeTimedWindow called, but interval id is not > 0");
		}
	}


	function SaveReport() {
		parent.reportbody.focus();
		//oSaveAs = window.open("reportSaveAs.asp", "reportSaveAs", "fullscreen=no,resizable=no,status=no,toolbar=no,menubar=no,location=no,titlebar=no");
		document.reportFooter.action = "reportSaveAs.asp";
		document.reportFooter.submit();
	}

</SCRIPT>

</HEAD>

<FORM name="reportFooter" ID="reportFooter" METHOD=POST  style="margin:0;padding:0">
<P>

<TABLE WIDTH=100% style="background:#EEE" ALIGN=center BORDER=0 CELLSPACING=0 CELLPADDING=0>
<TR style="height:47px">

	<TD WIDTH = 50% align=center>&nbsp;&nbsp;
		<input type="button" value="Print" style="height:40px;width:80px" name=Print title="Print Report" onClick="parent.reportbody.focus();parent.reportbody.print();">
		<input type="button" value="Save" style="height:40px;width:80px" id=SaveAs name=SaveAs title="Save Report to File" onClick="SaveReport();">
	</TD>

	<TD WIDTH = 50% align=center>&nbsp;&nbsp;
<!--		<INPUT class=touch id=ReportList name=ReportList type=button title="Go back to Menu" value="" onClick="history.go(-2);" 
			style="background-image:url(../images/Reports.gif);">
-->
			&nbsp;&nbsp;&nbsp;
			<% if request.querystring("source") = "statementhistory" then %>
			<INPUT style="height:40px;width:80px" id=Back name=Back title="Go back and Change Report Parameters" type=button value="Cancel" onClick="window.parent.location.href = '/mainapp/statementHistory.asp'">
			<% else %>
			<% if session("objRP").reportnumber <= 2 then %>
			<INPUT style="height:40px;width:80px" id=Back name=Back title="Go back and Change Report Parameters" type=button value="Cancel" onClick="window.parent.location.href = '/mainapp/employeemenu.asp'">
			<% else %>
			<INPUT style="height:40px;width:80px" id=Back name=Back title="Go back and Change Report Parameters" type=button value="Cancel" onClick="window.parent.location.href = '/mainapp/reportParams.asp?reportID=<%=session("objRP").reportnumber%>&requesterName=<%=request.querystring("requesterName")%>'">
			<% end if %>
			<% end if %>
	</TD>

</TR>
</TABLE>
</FORM>
</HTML>
