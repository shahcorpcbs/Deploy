<%@ Language=VBScript %>

<% Option Explicit %>

<%
	Session("storeID") = 1
	Session("terminalID") = 46
	Session("employeeID") = 2
	Session("customerSequenceNumber") = 24
%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/messages.asp" -->

<HTML>
<HEAD>
	<STYLE>
		BODY {
			color:#111111;
			background-color:#FFFFFF;
			font-family:Tahoma;
			font-size:11px;
		}
		TABLE {
			color:#CDCAc6;
			background-color:#111111;
			font-family:Tahoma,Arial;
			font-size:11 px;
		}
		TD {
			color:#111111;
			background-color:#CDCAc6;
			font-family:Tahoma,Arial;
			font-size:11px;
		}
		input {
			color:#111111;
			font-family:Tahoma,Arial;
			font-size:11px;
		}
	</STYLE>

<SCRIPT LANGUAGE=javascript>
<!--
	function SetPickupSignatureID(sigid) {
		cbs_alert("SignatureId = " + sigid);
	}
	function setCreditCardSignatureId(sigid, apcode) {
		cbs_alert("SignatureId = " + sigid + "\nApproval Code = " + apcode);
	}
//-->
</SCRIPT>

</HEAD>
<BODY >
<!-- #include file="../include/signaturepad.inc" -->
	
<h2>SignaturePad Test Page</h2>
<FORM action="" method=get id=form1 name=form1>
<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=6>
	<TR>
		<TD align=center><INPUT type=button id=dct name=dct value="Do Credit Card Transaction" onClick="DoCreditCardTransaction(123.5);" ></TD>
		
	</TR>
	<TR>
		<TD align=center><INPUT type=button id=pickup name=pickup value="Pickup Signature" onClick="CapturePickupSignature();" ></TD>
	</TR>
	
</TABLE>

	
</FORM>

</BODY>
</HTML>
