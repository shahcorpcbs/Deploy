<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim targetPage
	dim lineNumber
	dim screenNotes
	dim userAction
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim colorSet, upchargeSet, patternSet
	dim dueDateSet
	dim dueDate
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim originatingPage
	
	targetPage = Request.QueryString("targetPage")
	
	select case targetPage
		case "quick"
				'userAction = Request.QueryString("userAction")
				dueDateSet = Request.QueryString("isDueDateSet")
				lineNumber = Request.QueryString("lineNumber")
				deptStartIndex = Request.Form("DeptPageCount")
				addOrEdit = Request.Form("addOrEdit")
				screenNotes = Session("ScreenNotes")
				if IsEmpty(screenNotes)  then
					screenNotes = ""
				end if
		case "detail"
				lineNumber = Request.QueryString("lineNumber")	
				dueDateSet = Request.Form("isDueDateSet")
				dueDate = Request.Form("txtDueDate")
				curr_LineNo = Request.Form("lineNumber")
				selectedDept = Request.Form("selectedDept")
				itemsStartIndex = Request.Form("ItemPageCount")
				upChargeStartIndex = Request.Form("upChargePageCount")
				colorsStartIndex = Request.Form("colorsPageCount")
				patternStartIndex = Request.Form("PatternPageCount")
				deptStartIndex = Request.Form("DeptPageCount")
				addOrEdit = Request.Form("addOrEdit")
				upchargeSet = Request.Form("upchargeSet")
				colorSet = Request.Form("colorSet")
				patternSet = Request.Form("patternSet")
				selItemId = Request.Form("selItemId")
				selUpchargeValue = Request.Form("selUpcharge")
				selColorValue = Request.Form("selColor")
				selPatternValue = Request.Form("selPattern")
				originatingPage = Request.Form("originPage")
				screenNotes = Session("ScreenNotes")
				if IsEmpty(screenNotes)  then
					screenNotes = ""
				end if
	
end select
	
		
%>
<HTML>
<HEAD>
<TITLE>Customer Screen Notes</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm() {
		var page
		
		page = document.screenNotesForm.tPage.value;
		
		switch(page){
			case "quick":
				document.screenNotesForm.action ="quickinvoice.asp"
				break;
			case "detail":
				document.screenNotesForm.action ="detailedInvoice.asp"
				break;
		}
		document.screenNotesForm.submit();
			
	}
</script>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Customer Screen Notes</H1>
<FORM id="screenNotesForm" name="screenNotesForm" action="customerScreenNotes.asp" method="post">
	<INPUT type="hidden" name="isDueDateSet" value="<%= dueDateSet %>">
	<INPUT type="hidden" name="selLineNo" value="<%= lineNumber %>">
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="upchargeSet" value="<%= upchargeSet %>">
	<INPUT type="hidden" name="colorSet" value="<%= colorSet %>">
	<INPUT type="hidden" name="patternSet" value="<%= patternSet %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<INPUT type="hidden" name="txtDueDate" value="<%= dueDate %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
			<tr height=50px><td></td></tr>
			<TR>
				<TD align="center">
					<TEXTAREA rows="20" cols="60" name="itemNotes" readonly><%= screenNotes%></TEXTAREA>
				</TD>
			</TR>
			<TR>
				<TD align="center">
					<TABLE ALIGN=center WIDTH="400px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
						<!--<td align="center">
							<INPUT class=touch id=editButton name=editButton type=button value=""><br>Edit
						</td>-->
						<td align="center">
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick="history.back(-1);">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="history.back(-1);">
						</td>
					</table>
			   </TD>
			</TR>     
	</TABLE>
</FORM>   

</BODY>
</HTML>