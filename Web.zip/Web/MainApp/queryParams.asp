<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%

	class Param
		dim paramName
		dim paramType
		dim paramDefault
		dim startPosition
		dim endPosition
	end class
	
	dim query, rs
	dim queryTemplate
	dim queryTransformed
	dim params
	dim userQueryID
	dim missingValues
	
	userQueryID = getReqVar("userQueryID")
	queryTemplate = getUserQuery(userQueryID)
	set params = getQueryParams(queryTemplate)

	select case lcase(request.querystring("useraction"))
	case "submit"
		runQuery
	case "runquery"
		if ubound(params.items) < 0 then
			runQuery
		end if
	case "restore"

	end select
	
	function runQuery()
		missingValues = getMissingQueryValues(queryTemplate, params, request.form)
		if missingValues = "" then
			queryTransformed = transformQuery(queryTemplate, params, request.form)
			response.redirect "querydb.asp?userQueryID=" & userQueryID & "&query=" & Server.URLEncode(queryTransformed)
		end if
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getUserQuery(userqueryid)
		dim query, rs
		
		query = " select query from userquery where userqueryid = " & userqueryid
		set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
			getUserQuery = rs("query")
		end if
	end function

	function getMissingQueryValues(query, params, values)
		dim item
		dim value
		dim missing
		
		for each item in params.items
			if item.paramType <> "" and values(replace(item.paramName, "@", "")) = "" then
				if missing <> "" then missing = missing & ", "
				missing = missing & item.paramName
			end if
		next
		
		getMissingQueryValues = missing
	end function
		
	function transformQuery(query, params, values)
		dim item
		dim result
		dim offset
		dim rside
		dim lside
		dim value

		result = query
		offset = 0
		
		for each item in params.items
			lside = left(result, item.startPosition + offset - 1)
			rside = mid(result, item.endPosition + offset)
			
			value = values(replace(item.paramName, "@", ""))
			
			offset = offset - (item.endPosition - item.startPosition) + len(value)

			result = lside & value & rside
		next
		
		transformQuery = result
		
	end function
	
	sub addParam(params, paramName, paramType, paramDefault, startPosition, endPosition)
		dim newParam
		'dim idx
		dim originalName
		
		originalName = paramName
		
		'idx = 1
		
		while params.exists(paramName)
			paramName = paramName & "@"
		wend
		
		set newParam = new Param

		newParam.paramName = paramName
		newParam.paramType = paramType
		newParam.paramDefault = paramDefault
		newParam.startPosition = startPosition
		newParam.endPosition = endPosition
		
		params.add paramName, newParam

	end sub
	
	function legalIDChar(ch)
		dim legal
		dim idx
		
		legal = "abcdefghijklmnopqrstuvwxyz1234567890_"
		idx = 1
		
		while idx <= len(legal)
			if mid(legal, idx, 1) = lcase(ch) then
				legalIDChar = true
				exit function
			end if
			idx = idx + 1
		wend
		
		legalIDChar = false
		
	end function
	
	function getQueryParams(query)
		dim idx
		dim idxStart
		dim paramName
		dim paramType
		dim paramDefault
		dim varPrefix
		dim typePrefix
		dim result

		varPrefix = "@"
		typePrefix = ":"
		
		set result = CreateObject("Scripting.Dictionary")

		idx = instr(1, query, varPrefix, 1)

		while idx > 0
			paramName = ""
			paramType = ""
			paramDefault = ""

			idxStart = idx
			idx = idx + len(varPrefix)
			
			while idx <= len(query) and legalIDChar(mid(query, idx, 1))
				paramName = paramName & mid(query, idx, 1)
				idx = idx + 1
			wend

			if mid(query, idx, 1) = typePrefix then
				idx = idx + len(typePrefix)
				while idx <= len(query) and legalIDChar(mid(query, idx, 1))
					paramType = paramType & mid(query, idx, 1)
					idx = idx + 1
				wend
				if mid(query, idx, 1) = typePrefix then
					idx = idx + len(typePrefix)
					while idx <= len(query) and legalIDChar(mid(query, idx, 1))
						paramDefault = paramDefault & mid(query, idx, 1)
						idx = idx + 1
					wend
				end if
			end if
			
			addParam result, paramName, paramType, paramDefault, idxStart, idx

			idx = instr(idx, query, varPrefix, 1)
		wend

		set getQueryParams = result
	end function
	
	function getSQLDropdown(query, name, default)
		dim rs

		set rs = getdisconnectedrecordset(query)
		
		getSQLDropdown = "<SELECT name=""" & name & """>"
		
		while not(rs.eof or rs.bof)
			getSQLDropdown = getSQLDropdown & "<OPTION value=""" & rs("value") & """"
			if trim(rs("value")) = trim(default) then
				getSQLDropdown = getSQLDropdown & "selected"
			end if
			getSQLDropdown = getSQLDropdown & ">"
			getSQLDropdown = getSQLDropdown & Server.HTMLEncode(rs("name"))
			getSQLDropdown = getSQLDropdown & "</OPTION>"
			rs.movenext
		wend
		
		getSQLDropdown = getSQLDropdown & "</SELECT>"
	end function
	
	function getRouteDropdown(storeID, name, default)
		dim query
		
		query = "select name, routenumber as [value] from route where activeroute = 1 and storeid = " & storeID & " union select 'All',-1 order by [value] "

		getRouteDropdown = getSQLDropdown(query, name, default)
	end function

	function getOnDemandDropdown(storeID, name, default)
	    dim query
	    query = "select concat(cri_condition, ' ', cri_required, ' ', cri_target) name, ID as [value] from OnDemandCoupon where type = 2 "
	    getOnDemandDropdown = getSQLDropdown(query, name, default)
	end function

	function getCustomerSourceDropdown(storeID, name, default)
		dim query
		
		query = "select name, customersourceid as [value] from customersourcedomain where storeid = " & storeID & " order by [value] " 

		getCustomerSourceDropdown = getSQLDropdown(query, name, default)
	end function
	
	function getPricelistDropdown(storeID, name, default)
		dim query
		
		query = "select name, pricelistid as [value] from pricelist where storeid = " & storeID & " union select 'All',0 order by 2"
		
		getPricelistDropdown = getSQLDropdown(query, name, default)
	end function
	
	function getStoreDropdown(name, default)
		dim query
		
		query = "select name, storeid as [value] from store"
		
		getStoreDropdown = getSQLDropdown(query, name, default)
	end function

	function getEmployeeDropdown(storeID, name, default)
		dim query
		
		query = "select employeename as [name], employeeid as [value] from employee where storeid = " & storeID
		query = query & " union select 'All',0 order by 2 "
		
		getEmployeeDropdown = getSQLDropdown(query, name, default)
	end function

	function getPaymentDropdown(name, default)
		dim query
		query = "select 'Check' as [name], 'check' as [value] union select 'Cash' as [name], 'cash' as [value] "
		query = query & " union select 'Credit Card' as [name], 'cc' as [value] union select 'On Account' as [name], 'onacct' as [value]"

		getPaymentDropdown = getSQLDropdown(query, name, default)

	end function

	function getBitDropdown(name, default)
		dim query
		
		query = "select 'No' as [name], 0 as [value] union select 'Yes' as [name], 1 as [value] "

		getBitDropdown = getSQLDropdown(query, name, default)
	end function
	
	function getParamField(param, default)
		if default = "" then
			default = item.paramDefault
		end if
		
		select case param.paramType
		case "customer"
			getParamField = "<INPUT name=""" & item.paramName & """ value=""" & default & """ readonly>"
			getParamField = getParamField & "<INPUT type=""button"" value=""Search"" onclick=""customerSearch('" & item.paramName & "')"">"
		case "employee"
			getParamField = getEmployeeDropdown(session("storeid"), item.paramName, default)
		case "store"
			getParamField = getStoreDropdown(item.paramName, default)
		case "pricelist"
			getParamField = getPricelistDropdown(session("storeid"), item.paramName, default)
		case "route"
			getParamField = getRouteDropdown(session("storeid"), item.paramName, default)
		case "number"
			getParamField = "<INPUT name=""" & item.paramName & """ value=""" & default & """ onblur=""validateNumber(this)"">"
		case "bit"
			getParamField = getBitDropdown(item.paramName, default)
		case "payment"
			getParamField = getPaymentDropdown(item.paramName, default)
		case "date"
		  if default = "" then default = Date()
			getParamField = "<INPUT name=""" & item.paramName & """ value=""" & default & """ readonly onclick=""javascript:show_calendar('queryParams." & item.paramName & "');"">"
		case "customersource"
			getParamField = getCustomerSourceDropdown(session("storeid"), item.paramName, default)
		case "ondemand"
		    getParamField = getOnDemandDropdown(session("storeid"), item.paramName, default)
		case else
			getParamField = "<INPUT name=""" & item.paramName & """ value=""" & default & """>"
		end select

	end function
	
%>

<HTML>
<HEAD>
<TITLE>Query Parameters</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT LANGUAGE="javascript" >
	function validateNumber(o) {
	
	}
	
	function customerSearch(paramName) {
		document.queryParams.action = "?useraction=customersearch&name=" + paramName;
		document.queryParams.submit();
	}

	function submitForm() {
		document.queryParams.action = "?useraction=submit";
		document.queryParams.submit();
	}
	
	function exit() {
		document.queryParams.action = "querylist.asp";
		document.queryParams.submit();
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Query Parameters</H1>

<FORM name="queryParams" ID="queryParams" METHOD=POST action="queryParams.asp?useraction=submit"  style="margin:0;padding:0"> 
<INPUT type="hidden" name="userQueryID" value="<%=userQueryID%>" />

<BR>
<% if missingValues <> "" then%>
<div class="error">Missing: <%=missingValues%></div>
<% end if %>


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="submitForm()">Run</BUTTON>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH>Name</TH>
		<TH>Value</TH>
	</TR>
<%
	dim item
	dim listedParameters
	
	set listedParameters = Server.CreateObject("Scripting.Dictionary")
	
	if ubound(params.items) >= 0 then
	for each item in params.items
		if not listedParameters.exists(replace(item.paramName, "@", "")) then
			listedParameters.add item.paramName, ""
%>
	<TR>
		<TD><%=Server.HTMLEncode(Replace(item.paramName, "_", " ") )%></TD>	
		<TD>
			<%=getParamField(item, request.form(item.paramName))%>

		</TD>	
	</TR>
<%
		end if
	next
	else
%>
	<TR>
		<TD colspan="2">This query does not have any parameters.</TD>
	</TR>
<%
	end if
%>
</TABLE>


</FORM>
</BODY>
</HTML>

