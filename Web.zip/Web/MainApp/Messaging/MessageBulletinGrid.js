
MessageBulletinGrid = function(employeeID, config) {
	this.employeeID = employeeID;

    Ext.apply(this, config);

    this.store = new Ext.data.Store({
	    remoteSort: true,
	    proxy: new Ext.data.HttpProxy({ url: 'actions.asp?a=getBulletinMessages' }),
		baseParams: {employeeID: this.employeeID},
	    reader: new Ext.data.JsonReader(
			{
	            root: 'rows',
	            totalProperty: 'recordcount',
	            id: 'messagebulletinid'
	        },
	        ['messagebulletinid', 'body', 'employeename', {name: 'datecreated', type: 'date'}])
    });
    
    this.store.setDefaultSort('messagebulletinid', 'desc');

    this.columns = [{
        header: "Employee",
        id: 'employeename',
        dataIndex: 'employeename',
        width: 100,
        sortable:false
      },{
        header: "Date",
        dataIndex: 'datecreated',
        width: 50,
        renderer:  this.formatDate,
        sortable:false
    }];

    MessageBulletinGrid.superclass.constructor.call(this, {
        region: 'center',
        id: 'bulletin-grid',
        loadMask: {msg:'Loading Messages...'},
		autoExpandColumn: 'sendername',
        viewConfig: {
            forceFit:true,
            enableRowBody:true,
            showPreview:false,
            getRowClass : this.applyRowClass
        }

    });

};

Ext.extend(MessageBulletinGrid, Ext.grid.GridPanel, {

    loadMessages : function() {
        this.store.load();
    },
    applyRowClass: function(record, rowIndex, p, ds) {
        var xf = Ext.util.Format;
        p.body = '<p>' + xf.ellipsis(record.data.body, 200) + '</p>';
        return 'x-grid3-row-expanded';
    },

    formatDate : function(date) {
        if (!date) {
            return '';
        }
        var now = new Date();
        var d = now.clearTime(true);
        var notime = date.clearTime(true).getTime();
        if (notime == d.getTime()) {
            return 'Today ' + date.dateFormat('g:i a');
        }
        d = d.add('d', -6);
        if (d.getTime() <= notime) {
            return date.dateFormat('D g:i a');
        }
        return date.dateFormat('n/j g:i a');
    }
});