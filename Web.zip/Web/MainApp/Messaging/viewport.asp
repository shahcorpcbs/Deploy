<%
	dim employeeid
	
	employeeid = request.querystring("employeeid")
	
	if employeeid = "" then employeeid = 0
	

%>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>Messages</title>
	
	<link rel="stylesheet" type="text/css" href="/external/ext/resources/css/ext-all.css" />
	<link rel="stylesheet" type="text/css" href="/external/ext/resources/css/xtheme-gray.css" />
	<link rel="stylesheet" type="text/css" href="messaging.css" />
	
	<script type="text/javascript" src="/external/ext/adapter/ext/ext-base.js"></script>
	
	<script type="text/javascript" src="/external/ext/ext-all.js"></script>
	
	
	<script type="text/javascript" src="TabCloseMenu.js"></script>
	<script type="text/javascript" src="MessageFormPanel.js"></script>
	<script type="text/javascript" src="TaskFormPanel.js"></script>
	<script type="text/javascript" src="MessageBulletinFormPanel.js"></script>
	<script type="text/javascript" src="MessageGrid.js"></script>
	<script type="text/javascript" src="MessageTaskGrid.js"></script>
	<script type="text/javascript" src="MessageBulletinGrid.js"></script>
	<script type="text/javascript" src="MessagePanel.js"></script>
	<script type="text/javascript" src="messaging.js"></script>
	
	<script language="javascript" type="text/javascript">
		Ext.BLANK_IMAGE_URL = '/external/ext/resources/images/default/s.gif';
		
		Ext.QuickTips.init();
		
		Ext.onReady(function(){
		
				var mp = new MessagePanel(<%=employeeid%>, {});

				var mainPanel = new Ext.Viewport({
			        layout:'border',
					items:mp
				
				});
		});
	</script>

</head>
<body>

</body>
</html>
