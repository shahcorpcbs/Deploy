

<%@ Language=VBScript %>
<%option explicit%>

<% Response.AddHeader "Pragma", "no-cache" %>
<% Response.Expires = -1 %>

<!--#include file="../../include/QueryDatabase.asp"-->
<!--#include file="../../include/json.asp"-->
<%

	dim query, rs
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if
	
	dim partial
	
	partial = request.form("query")
	
	query = " select dbo.getEmployeeMessageName(employeeid) as name, employeeid from employee "
	query = query & " where employeestatus = 'A' "
	if partial <> "" then
		query = query & " and dbo.getEmployeeMessageName(employeeid) like '" & partial & "%'"
	end if
	
	set rs = getdisconnectedrecordset(query)
	
	response.write rsToJSON(rs, limit, start)

	set rs = nothing

%>
