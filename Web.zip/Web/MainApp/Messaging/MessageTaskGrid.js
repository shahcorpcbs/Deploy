
MessageTaskGrid = function(viewer, config) {
    this.viewer = viewer;
	this.employeeID = viewer.getEmployeeID();

    Ext.apply(this, config);

    this.store = new Ext.data.Store({
	    remoteSort: true,
	    proxy: new Ext.data.HttpProxy({ url: 'messageTaskList.json.asp' }),
		baseParams: {employeeID: this.employeeID},
	    reader: new Ext.data.JsonReader(
			{
	            root: 'rows',
	            totalProperty: 'recordcount',
	            id: 'messagetaskid'
	        },
	        ['messagetaskid', 'body', 'priority', 'subject', 'employeeopened', {name: 'datecreated', type: 'date', dateFormat: 'timestamp'}, {name: 'datedue', type: 'date', dateFormat: 'timestamp'}])
    });
    
    this.store.setDefaultSort('priority', 'desc');

    this.columns = [
		{
			id: 'priority',
			header: "Priority",
			dataIndex: 'priority',
			width: 100,
			renderer:  this.formatPriority,
			sortable:false
		},{
			id: 'subject',
			header: "Subject",
			dataIndex: 'subject',
			width: 100,
			sortable:false
		},{
			header: "Opened",
			dataIndex: 'employeeopened',
			width: 100,
			sortable:false
		},{
			id: 'datedue',
			header: "Date Due",
			dataIndex: 'datedue',
			width: 100,
			renderer:  this.formatDate,
			sortable:false
    }];


    MessageTaskGrid.superclass.constructor.call(this, {
        region: 'center',
        id: 'task-grid',
        loadMask: {msg:'Loading tasks...'},

        sm: new Ext.grid.RowSelectionModel({
            singleSelect:true
        }),

        viewConfig: {
            forceFit:true
        },
		bbar: new Ext.PagingToolbar({
		            pageSize: 25,
		            store: this.store,
		            displayInfo: true,
		            displayMsg: 'Tasks {0} - {1} of {2}',
		            emptyMsg: "No tasks"
				})

    });

};

Ext.extend(MessageTaskGrid, Ext.grid.GridPanel, {
    loadTasks : function() {
        this.store.load();
    },
    formatDate : function(date) {

        if (!date) {
            return '';
        }
		var d = new Date();

		date = date.add('h', d.getTimezoneOffset()/60);

        return date.dateFormat('D m/d/y');
    },

    formatPriority: function(value, p, record) {
	    return String.format('{0}', record.data.priority);
    }
});