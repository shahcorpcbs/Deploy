

MessagePanel = function(employeeID) {
	this.employeeID = employeeID;


    this.viewTaskTemplate = new Ext.Template(
        '<p class="preview-body">{body}</p>'
    );
				
    this.viewTaskPanel = new Ext.Panel({
        id: 'view-task',
        region: 'south',
        autoScroll: true,
		html: '',
		height: 300
    });

    this.messageTaskGrid = new MessageTaskGrid(this, {
        tbar:[{
            text:'New',
            iconCls: 'task-new',
            handler: this.newTask,
            scope:this
        },
        '-',
		{
            text:'Close',
            iconCls: 'task-close',
            handler: this.closeTask,
            scope:this
        },
        '-',
		{
            text:'Reload',
            iconCls: 'task-reload',
            handler: function() { this.messageTaskGrid.loadTasks() },
            scope:this
        }]
    });


    this.messageGrid = new MessageGrid(this, {
        tbar:[{
            text:'New',
            iconCls: 'message-new',
            handler: this.newMessage,
            scope:this
        },
        '-',
		{
            text:'Delete',
            iconCls: 'message-delete',
            handler: this.deleteMessage,
            scope:this
        },
        '-',
        {
            pressed: false,
            enableToggle:true,
            text:'Show Summary',
            iconCls: 'message-summary',
            scope:this,
            toggleHandler: function(btn, pressed){
                this.messageGrid.togglePreview(pressed);
            }
        },
		{
            text:'Reload',
            iconCls: 'message-reload',
            handler: function() { this.messageGrid.loadMessages() },
            scope:this
        }]
    });

    this.messageBulletinGrid = new MessageBulletinGrid(this.employeeID);
    this.messageBulletinForm = new MessageBulletinFormPanel(this.employeeID);
    
    MessagePanel.superclass.constructor.call(this, {
        id:'messaging-tabs',
        activeTab:0,
        region:'center',
        margins:'0 5 5 0',
        resizeTabs:true,
        tabWidth:120,
        minTabWidth: 100,
        enableTabScroll: true,
        plugins: new Ext.ux.TabCloseMenu(),
        items:[
	        {
	            title:'Messages',
	            layout:'border',
	            items: this.messageGrid,
	            listeners: {activate: this.messageGrid.loadMessages, scope: this.messageGrid}
	            
	        },
	        {
	            title:'Tasks',
	            layout:'border',
	            items: [
					this.messageTaskGrid,
					this.viewTaskPanel
				],
	            listeners: {activate: this.messageTaskGrid.loadTasks, scope: this.messageTaskGrid}
	            
	        },
			{
		     	title: 'Bulletin',
	            layout:'border',
	            items: [
	            	this.messageBulletinGrid,
					{
						id:'bottom-addBulletinMessage',
						layout:'fit',
						height: 300,
						split: true,
						border:false,
						region:'south',
						collapsed: true,
						items:this.messageBulletinForm,
						listeners: {collapse: this.messageBulletinGrid.loadMessages, scope: this.messageBulletinGrid}
		            }
	            ],
	            listeners: {activate: this.messageBulletinGrid.loadMessages, scope: this.messageBulletinGrid}
	        }
    	]
    });


    this.messageGrid.on('rowdblclick', this.openMessage, this);
    this.messageTaskGrid.on('click', this.viewTask, this);



}


Ext.extend(MessagePanel, Ext.TabPanel, {
	getEmployeeID : function() {
		return this.employeeID;
	},
	newTask : function() {
        var tab;

		tab = new TaskFormPanel(this.getEmployeeID(), {
            id: Ext.id(),
            title: 'New Task',
            tabTip: 'New Task',
            closable:true
		});

		tab.on('destroy', function() {  this.remove(tab, false); }, this);
		
        this.add(tab);
		
		this.setActiveTab(tab);
	},
	newMessage : function() {
        var tab;

		tab = new MessageFormPanel(this.getEmployeeID(), {
            id: Ext.id(),
            title: 'New Message',
            tabTip: 'New Message',
            closable:true
		});

		tab.on('destroy', function() {  this.remove(tab, false); }, this);
		
        this.add(tab);
		
		this.setActiveTab(tab);
	},
    openMessage : function(record){
		var gsm = this.messageGrid.getSelectionModel();
        record = (record && record.data) ? record : gsm.getSelected();
        var d = record.data;
        var tab;
        if(!(tab = this.getItem(id))){

			tab = new MessageFormPanel(this.getEmployeeID(), {
                id: 'message' + d.messageid,
                title: d.subject,
                tabTip: d.subject,
                closable:true
			});

			tab.on('destroy', function() {  this.remove(tab, false); }, this);
			
            this.add(tab);

			tab.loadMessage(d.messageid);
        }
        this.setActiveTab(tab);
    },
    viewTask : function(record){
		var gsm = this.messageTaskGrid.getSelectionModel();
        record = (record && record.data) ? record : gsm.getSelected();
        var d = record.data;

		this.viewTaskTemplate.overwrite(this.viewTaskPanel.body, d);

    },
    deleteMessage : function(){
        Ext.MessageBox.confirm('Confirm', 'Are you sure you want to delete the message?', this.deleteMessageCall, this);
    },
    deleteMessageCall : function(btn) {
		var record;
	    if(btn == 'yes') {
	        record = this.messageGrid.getSelectionModel().getSelected();
			
			Ext.Ajax.request({
			   url: 'actions.asp?a=deleteMessage',
			   success: function() { this.messageGrid.loadMessages() },
			   scope: this,
			   params: { messageID: record.data.messageid }
			});

	        
    	}
    },
    closeTask : function(){
        Ext.MessageBox.confirm('Confirm', 'Are you sure you want to close this task?', this.closeTaskCall, this);
    },
    closeTaskCall : function(btn) {
	    var record;
	    if(btn == 'yes') {
	        record = this.messageTaskGrid.getSelectionModel().getSelected();

			Ext.Ajax.request({
			   url: 'actions.asp?a=closeTask',
			   success: function() { Ext.DomHelper.overwrite(this.viewTaskPanel.body, ""); this.messageTaskGrid.loadTasks(); },
			   scope: this,
			   params: { messageTaskID: record.data.messagetaskid }
			});

	        
    	}
    }
});
