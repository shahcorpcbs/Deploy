<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../../include/QueryDatabase.asp"-->
<!--#include file="../../include/json.asp"-->

<%
	dim query, rs
	dim messageID
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if
	
	messageID = request.querystring("messageID")
	
	if messageID = "" then messageID = request.form("messageID")
	
	if messageID = "" then messageID = "null"

	query = " update message set received = getdate() where message.messageid = " & messageID
	qryexecute query
	
	query = " select message.*,   dbo.getEmployeeMessageName(sender.employeeid) as senderName, dbo.getEmployeeMessageName(recipient.employeeid) as recipientName from message "
	query = query & " left outer join employee sender on message.fromemployeeid = sender.employeeid "
	query = query & " left outer join employee recipient on message.toemployeeid = recipient.employeeid "
	query = query & " where message.messageid = " & messageID

	set rs = getdisconnectedrecordset(query)
	
	response.write rsToJSON(rs, limit, start)

	set rs = nothing

%>