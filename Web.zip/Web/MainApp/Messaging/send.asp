<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../../include/querydatabase.asp" -->
<!-- #include file="../../include/validatefunction.asp" -->
<%


	dim fromEmployeeID
	dim previousMessageID
	dim recipientNames
	dim messageSubject
	dim messageBody
	
	dim employeeID
	dim recipientName
	dim recipientNamesArray
	dim query, rs
	dim errorMessage
	
	fromEmployeeID = request.form("fromEmployeeID")
	previousMessageID = request.form("previousMessageID")
	recipientNames = request.form("to")
	messageSubject = request.form("subject")
	messageBody = request.form("body")
	
	
	
	recipientNamesArray = split(recipientNames, ",")
	
	checkRecipients recipientNamesArray

	for each recipientName in recipientNamesArray
		if trim(recipientName) <> "" then
			employeeID = getEmployeeID(trim(recipientName))
			if employeeID <> "" then
				query = " insert into message (previousmessageid, fromemployeeid, toemployeeid, body, subject) "
				query = query & " values (" 
				query = query & " " & DbCreateQryNumeric(previousMessageID)
				query = query & ", " & DbCreateQryNumeric(fromEmployeeID)
				query = query & ", " & DbCreateQryNumeric(employeeID)
				query = query & ", " & DbCreateQryString(messageBody)
				query = query & ", " & DbCreateQryString(messageSubject)
				query = query & ")"

				qryexecute query
			end if
		end if

	next
	
	returnResult 1, "Message sent"
	


	
	
	

	function getEmployeeID(name)
		dim query, rs
		
		query = " select employeeid from employee where dbo.getEmployeeMessageName(employeeid) = '" & name & "'"
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getEmployeeID = rs("employeeid")
		end if
	
		set rs = nothing
	end function

	
	function checkRecipients(recipientNamesArray)
	
		dim recipientName
		dim employeeID
		dim missingNames
		
		for each recipientName in recipientNamesArray
			if trim(recipientName) <> "" then
				employeeID = getEmployeeID(trim(recipientName))
				if employeeID = "" then
					if missingNames <> "" then missingNames = missingNames & ", "
					missingNames = missingNames & recipientName
				end if
			end if
		next

		if missingNames <> "" then
			returnResult 0, "Could not send to: " & missingNames
		end if
	end function
	function JSEncode(s)
		if not isnull(s) then
			JSEncode = s
			JSEncode = Replace(JSEncode, "\", "\\") 
			JSEncode = Replace(JSEncode, """", "\""")
			JSEncode = Replace(JSEncode, vbCr, "\r")
			JSEncode = Replace(JSEncode, vbLf, "\n")
		end if
	end function 
	
	function returnResult(success, answer )
		response.write "{ "
		response.write "success: """ & JSEncode(success) & """, "
		response.write "answer: """ & JSEncode(answer) & """ "
		response.write "}"
		response.end
	end function

%>
