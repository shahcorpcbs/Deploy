<%@ Language=VBScript %>
<%option explicit%>

<% Response.AddHeader "Pragma", "no-cache" %>
<% Response.Expires = -1 %>

<!--#include file="../../include/QueryDatabase.asp"-->
<!--#include file="../../include/json.asp"-->
<%

	dim query, rs
	dim employeeid
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if
	
	employeeid = request.querystring("employeeid")
	
	if employeeid = "" then employeeid = request.form("employeeid")
	
	if employeeid = "" then employeeid = "null"

	query = " select left(message.body, 100) as preview, message.body, message.messageid, message.subject, DATEDIFF(s, '01/01/1970', sent) as datesent, isnull(DATEDIFF(s, '01/01/1970', received), 0) as datereceived,  dbo.getEmployeeMessageName(sender.employeeid) as senderName from message "
	query = query & " left outer join employee sender on message.fromemployeeid = sender.employeeid "
	query = query & " left outer join employee recipient on message.toemployeeid = recipient.employeeid "
	query = query & " where status > 0 "
	query = query & " and toemployeeid = " & employeeid
	query = query & " order by case isnull(received, 0) when 0 then 0 else 1 end, message.messageid desc " 

	set rs = getdisconnectedrecordset(query)
	
	response.write rsToJSON(rs, limit, start)

	set rs = nothing

%>