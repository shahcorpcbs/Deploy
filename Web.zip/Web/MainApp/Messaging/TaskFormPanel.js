
TaskFormPanel = function(employeeID, config) {
	this.employeeID = employeeID;
	Ext.apply(this, config)


	this.assignToCombo = new Ext.form.ComboBox({
		                fieldLabel: 'Assigned To',
		                name:'assignToEmployeeID',
		                store: new Ext.data.Store({
						    proxy: new Ext.data.HttpProxy({ url: 'recipient.json.asp' }),
						    reader: new Ext.data.JsonReader(
								{
						            root: 'rows',
						            totalProperty: 'recordcount',
						            id: 'employeeid'
						        },
						        ['employeeid', 'name'])
		                }),
		                valueField: 'employeeid',
		                displayField: 'name',
		                triggerAction: 'all',
		                emptyText: 'Select assigment',
		                selectOnFocus: true,
		                anchor:'50%',
		                editable: false
		            });

	this.priorityCombo = new Ext.form.ComboBox({
		                fieldLabel: 'Priority',
		                name:'priority',
		                store: new Ext.data.Store({
						    proxy: new Ext.data.HttpProxy({ url: 'actions.asp?a=getTaskPriorities' }),
						    reader: new Ext.data.JsonReader(
								{
						            root: 'rows',
						            totalProperty: 'recordcount',
						            id: 'priority'
						        },
						        ['priority', 'label'])
		                }),
						hiddenName: 'priority',
		                valueField: 'priority',
		                displayField: 'label',
		                triggerAction: 'all',
		                emptyText: 'Select priority',
		                selectOnFocus: true,
		                anchor:'50%',
		                editable: false
		            });

    TaskFormPanel.superclass.constructor.call(this, {
		url:'actions.asp?a=createTask',
        labelAlign: 'top',
        frame:true,
        bodyStyle:'padding:5px 5px 0',
        viewConfig: {
            forceFit:true
        },

        reader : new Ext.data.JsonReader(
			{
	            root: 'rows',
	            totalProperty: 'recordcount',
	            id: 'messagetaskid'
	        },
	        ['messagetaskid', 'subject', 'priority', 'datedue', 'body', 'assignedto']
        ),

        items: [
			{
				xtype:'hidden',
                name: 'messagetaskid'
            },

			this.assignToCombo,
			{
				xtype:'textfield',
				fieldLabel: 'Subject',
				name: 'subject',
				allowBlank:false,
				anchor:'50%'
			},
			this.priorityCombo,
			new Ext.form.DateField({
				fieldLabel: 'Date Due',
				name: 'datedue',
				width:190,
				allowBlank:false
			})

            ,
            {
	            xtype:'htmleditor',
	            id:'body',
	            fieldLabel:'Body',
	            height:200,
				anchor:'98%',
				allowBlank:false
            }
        ],

        buttons: [{
            text: 'Create',
			handler: this.createTask,
			scope: this
        },{
            text: 'Close',
			handler: this.destroy,
			scope: this
        }]
    });
}

Ext.extend(TaskFormPanel, Ext.FormPanel, {
	createTask : function() {
		var form = this.getForm();

		if(form.isValid()) {
			form.submit({
				scope: this,
				waitMsg: 'Please wait',
				params: {'employeeEntered' : this.employeeID},
				failure: function(frm, act) {
					Ext.MessageBox.alert('Sending', 'Error creating task.');
				},
				success: function(frm, act) {
					if(act.result.success != 0)
						this.assignTaskToEmployee(act.result.answer, this.assignToCombo.getValue());
					else
						Ext.MessageBox.alert('Creating task', act.result.answer)
				}
			});
		}
		else
			Ext.MessageBox.alert('Creating task', 'Form not complete.')
	},
	assignTaskToEmployee : function(messageTaskID, employeeID) {
		Ext.Ajax.request({
			scope: this,
			url: 'actions.asp?a=assignEmployeeToTask',
			params: { messageTaskID: messageTaskID, employeeID: employeeID, notifyOnClose: 0 },
			success: function(frm, act) {
				this.destroy();
			}
		});
	},
	closeTask : function() {
		this.destroy();
	}

});