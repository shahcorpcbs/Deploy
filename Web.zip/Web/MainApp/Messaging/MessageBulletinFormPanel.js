
MessageBulletinFormPanel = function(employeeID, config) {
	this.employeeID = employeeID;
	Ext.apply(this, config)
    MessageBulletinFormPanel.superclass.constructor.call(this, {
		url:'actions.asp?a=addMessageBulletin',
        labelAlign: 'top',
        frame:true,
        bodyStyle:'padding:5px 5px 0',
        viewConfig: {
            forceFit:true
        },

        items: [

			new Ext.form.DateField({
                fieldLabel: 'Date to expire',
                name: 'dateExpires',
                width:190,
                allowBlank:false
            }),
			{
	            xtype:'htmleditor',
	            id:'body',
	            fieldLabel:'Body',
	            height:200,
				anchor:'98%',
				allowBlank:false
            }
        ],

        buttons: [{
            text: 'Send',
			handler: this.sendMessage,
			scope: this
        },{
            text: 'Close',
			handler: this.closeMessage,
			scope: this
        }]
    });
}

Ext.extend(MessageBulletinFormPanel, Ext.FormPanel, {

	sendMessage : function() {
		var form = this.getForm();

		if(form.isValid()) {
			form.submit({
				scope: this,
				waitMsg: 'Sending',
				params: {'employeeid' : this.employeeID},
				failure: function(frm, act) {
					Ext.MessageBox.alert('Sending', 'Error sending message.');
				},
				success: function(frm, act) {
					if(act.result.success != 0)
						this.closeMessage();
					else
						Ext.MessageBox.alert('Sending', act.result.answer)
				}
			});
		}
		else
			Ext.MessageBox.alert('Sending', 'Form not complete.')
	},
	closeMessage : function() {
		this.ownerCt.collapse(false);
	}

});