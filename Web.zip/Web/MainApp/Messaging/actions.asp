<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../../include/QueryDatabase.asp"-->
<!--#include file="../../include/json.asp"-->
<!-- #include file="../../include/validatefunction.asp" -->

<%
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if
	
	select case request.querystring("a")
	case "deleteMessage"
		deleteMessage
	case "getBulletinMessages"
		response.write getBulletinMessages()
	case "addMessageBulletin"
		response.write addMessageBulletin()
	case "getTaskPriorities"
		response.write getTaskPriorities()
	case "createTask"
		response.write createTask()
	case "assignEmployeeToTask"
		response.write assignEmployeeToTask()
	case "getMessageTask"
		response.write getMessageTask(request.querystring("employeeID"), request.querystring("messageTaskID"))

	case "closeTask"
		closeTask
	end select
	
	dim query, rs

	function JSEncode(s)
		if not isnull(s) then
			JSEncode = s
			JSEncode = Replace(JSEncode, "\", "\\") 
			JSEncode = Replace(JSEncode, """", "\""")
			JSEncode = Replace(JSEncode, vbCr, "\r")
			JSEncode = Replace(JSEncode, vbLf, "\n")
		end if
	end function 
	
	function returnResult(success, answer )
		dim result
		
		result = "{ "
		result = result & "success: """ & JSEncode(success) & """, "
		result = result & "answer: """ & JSEncode(answer) & """ "
		result = result & "}"
		
		returnResult = result
	end function
	
	
	function getTaskPriorities()
		dim query, rs
		
		query = " select messagetaskpriorityid as priority, label, hexcolor from messagetaskpriority "
		set rs = getdisconnectedrecordset(query)
		
		getTaskPriorities = rsToJSON(rs, limit, start)
		
		set rs = nothing
	end function
	
	
	function createTask()
		dim query, rs
		dim employeeOpened
		dim subject
		dim body
		dim priority
		dim dateDue
		dim messageTaskID

		employeeOpened = request.form("employeeEntered")
		subject = request.form("subject")
		body = request.form("body")
		priority = request.form("priority")
		dateDue = request.form("dateDue")


		query = " insert into messagetask (subject, messageTaskPriorityID, employeeOpened, dateDue, body) "
		query = query & " values (" 
		query = query & " " & DbCreateQryString(subject)
		query = query & ", " & DbCreateQryNumeric(priority)
		query = query & ", " & DbCreateQryNumeric(employeeOpened)
		query = query & ", " & DbCreateQryString(dateDue)
		query = query & ", " & DbCreateQryString(body)
		query = query & ")"

		openConnection
		dbInsert query
		set rs = dbselect("select SCOPE_IDENTITY() as messageTaskID")
		messageTaskID = rs("messageTaskID")
		set rs = nothing
		closeconnection

		createTask = returnResult(1, messageTaskID)
	end function

	function assignEmployeeToTask()
		dim query, rs
		dim employeeID
		dim messageTaskID
		dim notifyOnClose

		employeeid = request.form("employeeID")
		messageTaskID = request.form("messageTaskID")
		notifyOnClose = request.form("notifyOnClose")
		if notifyOnClose = "" then notifyOnClose = 0

		query = " delete messagetaskassignment where "
		query = query & " employeeid = " & employeeID
		query = query & " and messageTaskID = " & messageTaskID

		qryexecute query

		query = " insert into messagetaskassignment (employeeID, messageTaskID, notifyOnClose) "
		query = query & " values (" & employeeid & ", " & messageTaskID & ", " & notifyOnClose & ")"

		qryexecute query

		assignEmployeeToTask = returnResult(1, query)
	end function



	function addMessageBulletin()
		dim query, rs
		dim employeeID
		dim body
		dim dateExpires
		
		dateExpires = request.form("dateExpires")
		body = request.form("body")
		employeeID = request.form("employeeID")
		
		query = " insert into messagebulletin (employeeid, body, dateexpires) "
		query = query & " values (" 
		query = query & " " & DbCreateQryNumeric(employeeID)
		query = query & ", " & DbCreateQryString(body)
		query = query & ", " & DbCreateQryString(dateExpires)
		query = query & ")"
		
		qryexecute query
		
		addMessageBulletin = returnResult(1, "Message added")
	end function
	
	
	function deleteMessage()
		dim query, rs
		dim messageID
		
		messageID = request.form("messageID")
		
		query = " update message set status = 0 where messageid = " & messageID
		
		qryexecute query
	end function
	

	function closeTask()
		dim query, rs
		dim messageTaskID
		
		messageTaskID = request.form("messageTaskID")
		
		query = " update messagetask set dateclosed = getdate() where messageTaskID = " & messageTaskID
		
		qryexecute query
	end function
	

	function getBulletinMessages() 
		dim query, rs
		
		query = " select messagebulletin.messagebulletinid, messagebulletin.body, employee.employeename, messagebulletin.datecreated from messagebulletin  "
		query = query & " inner join employee on messagebulletin.employeeid = employee.employeeid "
		query = query & " where (messagebulletin.dateexpires is null or datediff(day, messagebulletin.dateexpires, getdate()) <= 0 ) "
		query = query & " order by messagebulletinid "
		
		set rs = getdisconnectedrecordset(query)

		getBulletinMessages = rsToJSON(rs, limit, start)

		set rs = nothing
	end function
	

	function getMessageTask(employeeID, messageTaskID)

		dim query, rs

		query = " select messageTask.messageTaskID, "
		query = query & " messageTask.subject, "
		query = query & " messageTaskPriority.label as priority, "
		query = query & " messageTask.dateDue, "
		query = query & " messageTask.body "
		query = query & " from messageTask "
		query = query & " inner join messageTaskPriority on messageTask.messageTaskPriorityID = messageTaskPriority.messageTaskPriorityID "
		query = query & " where messageTask.messageTaskID = " & messageTaskID
	
		set rs = getdisconnectedrecordset(query)
		
		getMessageTask = rsToJSON(rs, limit, start)

	end function
%>