<%@ Language=VBScript %>
<%option explicit%>

<% Response.AddHeader "Pragma", "no-cache" %>
<% Response.Expires = -1 %>

<!--#include file="../../include/QueryDatabase.asp"-->
<!--#include file="../../include/json.asp"-->
<%

	dim query, rs
	dim employeeid
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if
	
	employeeid = request.querystring("employeeid")
	
	if employeeid = "" then employeeid = request.form("employeeid")
	
	if employeeid = "" then employeeid = "null"

	query = " select messageTaskPriority.label as priority, messagetask.body, messagetask.messagetaskid, messagetask.subject, DATEDIFF(s, '01/01/1970', messagetask.datecreated) as datecreated, isnull(DATEDIFF(s, '01/01/1970', messagetask.datedue), 0) as datedue,  employee.employeename as employeeopened from "
	query = query & " messagetask inner join employee on messagetask.employeeopened = employee.employeeid "
	query = query & " inner join messagetaskassignment on messagetask.messagetaskid = messagetaskassignment.messagetaskid "
	query = query & " inner join messageTaskPriority on messageTask.messageTaskPriorityID = messageTaskPriority.messageTaskPriorityID "
	query = query & " where messagetaskassignment.employeeid = " & employeeid
	query = query & " and messagetask.dateclosed is null "
	query = query & " order by messagetask.priority "

	set rs = getdisconnectedrecordset(query)
	
	response.write rsToJSON(rs, limit, start)

	set rs = nothing

%>