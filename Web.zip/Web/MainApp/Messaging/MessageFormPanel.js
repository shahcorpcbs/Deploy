
MessageFormPanel = function(employeeID, config) {
	this.employeeID = employeeID;
	Ext.apply(this, config)
    MessageFormPanel.superclass.constructor.call(this, {
		url:'send.asp',
        labelAlign: 'top',
        frame:true,
        bodyStyle:'padding:5px 5px 0',
        viewConfig: {
            forceFit:true
        },

        reader : new Ext.data.JsonReader(
			{
	            root: 'rows',
	            totalProperty: 'recordcount',
	            id: 'messageid'
	        },
	        ['messageid', 'subject', 'body', {name: 'to', mapping: 'sendername'}, 'previousmessageid']
        ),

        items: [
			{
				xtype:'hidden',
                name: 'previousmessageid'
            },
            new Ext.form.ComboBox({
                fieldLabel: 'To',
                name:'to',
                store: new Ext.data.Store({
				    proxy: new Ext.data.HttpProxy({ url: 'recipient.json.asp' }),
				    reader: new Ext.data.JsonReader(
						{
				            root: 'rows',
				            totalProperty: 'recordcount',
				            id: 'employeeid'
				        },
				        ['employeeid', 'name'])
                }),
                valueField: 'name',
                displayField: 'name',
                typeAhead: true,
                triggerAction: 'all',
                emptyText: 'Select a recipient',
                selectOnFocus: true,
                anchor:'50%'
            }),
			{
				xtype:'textfield',
                fieldLabel: 'Subject',
                name: 'subject',
				allowBlank:false,
				anchor:'50%'
            },{
	            xtype:'htmleditor',
	            id:'body',
	            fieldLabel:'Body',
	            height:200,
				anchor:'98%',
				allowBlank:false
            }
        ],

        buttons: [{
            text: 'Send',
			handler: this.sendMessage,
			scope: this
        },{
            text: 'Close',
			handler: this.destroy,
			scope: this
        }]
    });
}

Ext.extend(MessageFormPanel, Ext.FormPanel, {
    loadMessage : function(messageID) {
        this.load({url:'message.json.asp?messageID=' + messageID, waitMsg:'Loading'});
    },
	sendMessage : function() {
		var form = this.getForm();

		if(form.isValid()) {
			form.submit({
				scope: this,
				waitMsg: 'Sending',
				params: {'fromemployeeid' : this.employeeID},
				failure: function(frm, act) {
					Ext.MessageBox.alert('Sending', 'Error sending message.');
				},
				success: function(frm, act) {
					if(act.result.success != 0)
						this.destroy();
					else
						Ext.MessageBox.alert('Sending', act.result.answer)
				}
			});
		}
		else
			Ext.MessageBox.alert('Sending', 'Form not complete.')
	},
	closeMessage : function() {
		this.destroy();
	}
	
	
});