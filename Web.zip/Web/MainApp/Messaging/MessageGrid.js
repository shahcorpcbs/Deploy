
MessageGrid = function(viewer, config) {
    this.viewer = viewer;
	this.employeeID = viewer.getEmployeeID();

    Ext.apply(this, config);

    this.store = new Ext.data.Store({
	    remoteSort: true,
	    proxy: new Ext.data.HttpProxy({ url: 'messageList.json.asp' }),
		baseParams: {employeeID: this.employeeID},
	    reader: new Ext.data.JsonReader(
			{
	            root: 'rows',
	            totalProperty: 'recordcount',
	            id: 'messageid'
	        },
	        ['messageid', 'subject', 'preview', 'body', 'sendername', 'datereceived', {name: 'datesent', type: 'date', dateFormat: 'timestamp'}])
    });
    this.store.setDefaultSort('datesent', 'desc');

    this.columns = [{
        id: 'subject',
        header: "Subject",
        dataIndex: 'subject',
        sortable:false,
        width: 420,
        renderer: this.formatSubject
      },{
        header: "Sender",
        dataIndex: 'sendername',
        width: 100,
        hidden: true,
        sortable:false
      },{
        id: 'datesent',
        header: "Date",
        dataIndex: 'datesent',
        width: 150,
        renderer:  this.formatDate,
        sortable:false
    }];

    MessageGrid.superclass.constructor.call(this, {
        region: 'center',
        id: 'topic-grid',
        loadMask: {msg:'Loading Messages...'},

        sm: new Ext.grid.RowSelectionModel({
            singleSelect:true
        }),

        viewConfig: {
            forceFit:true,
            enableRowBody:true,
            showPreview:false,
            getRowClass : this.applyRowClass
        },
		bbar: new Ext.PagingToolbar({
		            pageSize: 25,
		            store: this.store,
		            displayInfo: true,
		            displayMsg: 'Messages {0} - {1} of {2}',
		            emptyMsg: "No messages"
				})

    });

    this.on('rowcontextmenu', this.onContextClick, this);
};

Ext.extend(MessageGrid, Ext.grid.GridPanel, {

    onContextClick : function(grid, index, e){
    },

    onContextHide : function(){
    },

    loadMessages : function() {
        this.store.load();
    },

    togglePreview : function(show){
        this.view.showPreview = show;
        this.view.refresh();
    },

    applyRowClass: function(record, rowIndex, p, ds) {
        if (this.showPreview) {
            var xf = Ext.util.Format;
            p.body = '<p>' + xf.ellipsis(xf.stripTags(record.data.preview), 200) + '</p>';
            return 'x-grid3-row-expanded';
        }
        return 'x-grid3-row-collapsed';
    },

    formatDate : function(date) {

        if (!date) {
            return '';
        }
		var d = new Date();

		date = date.add('h', d.getTimezoneOffset()/60);

        return date.dateFormat('D m/d/y');
    },

    formatSubject: function(value, p, record) {
		if(record.data.datereceived > 0)
	        return String.format(
	                '<div class="subject"><b>{0}</b><span class="sender">{1}</span></div>',
	                value, record.data.sendername
	                );
		else
	        return String.format(
	                '<div class="subject-new"><b>{0}</b><span class="sender">{1}</span></div>',
	                value, record.data.sendername
	                );
    }
});