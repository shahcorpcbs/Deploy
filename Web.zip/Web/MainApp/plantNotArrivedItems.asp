<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs, direction
	direction = Request.QueryString("direction")

	query = "select id, TicketNumber, InvoiceNumber, CustomerName, Departments, NumOfPieces, DueDate, ScannedDate  " _
	    & " from PlantManifestItem pmi where status = " & direction & " order by scannedDate"
	set rs = getdisconnectedrecordset(query)
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" src="../external/jquery-3.4.1.js"></script>
<script language="javascript" type="text/javascript">

	function exit() {
		document.plantMissing.action = "/mainapp/plantManifests.asp";
		document.plantMissing.submit();
	}
	
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->
<FORM name="plantMissing" ID="plantMissing" METHOD=POST  style="margin:0;padding:0" onSubmit="return false">


<H1>Unarrived Items</H1>
<BR><BR>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="clear: both;margin-bottom:0">
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE id="items" class="itable" cellspacing="0" >
<TR id="thead">
	<TH>Last Scanned Date</TH>
	<TH>Invoice</TH>
	<TH>Due Date</TH>
	<TH>Customer</TH>
	<TH>Pieces</TH>
	<TH>Others From Connection Arrived</TH>
</TR>
<%
	while not(rs.eof or rs.bof)
%>
<tr>
    <td><%= rs("ScannedDate")%></td>
    <td><%= rs("invoiceNumber")%></td>
    <td><%= rs("DueDate")%></td>
    <td><%= rs("CustomerName")%></td>
    <td><%= rs("NumOfPieces")%></td>
    <td>
    <%
        dim connectionId, query2, rs2
        query2 = "select sch.id from StoreConnectionHistory sch, ConnectionItemsLink cil where cil.connectionId = sch.id " _
            & "and sch.messageType = " & direction & " and cil.itemId = " & rs("id")
        set rs2 = getdisconnectedrecordset(query2)
        connectionId = rs2("id")
        query2 = "select ticketNumber from PlantManifestItem pmi, ConnectionItemsLink cil where pmi.id = cil.itemId " _
            & "and cil.connectionId = " & connectionId & " and status = " & (direction + 1)
        set rs2 = getdisconnectedrecordset(query2)
        if rs2.recordcount > 0 then %>
        Yes
        <% else %>
        No
        <% end if %>
    </td>
</tr>
<%
	rs.movenext
	wend
%>

</TABLE>

</FORM>
</BODY>
</HTML>
