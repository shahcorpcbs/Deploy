<%@ Language=VBScript %>
<% option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim customerseq
	dim storeguid
	dim messageusername
	dim customername
	dim taskid
	
	customername = getReqVar("customername")
	messageusername = getReqVar("messageusername")
	storeguid = getReqVar("storeguid")
	taskid = getReqVar("taskid")
	
	customerseq = getReqVar("customerseq")
	if len(trim(customerseq)) = 0 then customerseq = session("customersequencenumber")

	select case lcase(request.querystring("useraction"))
		case "addnewnote"
			addNewNote
		case "closetask"
			addTaskNote taskid, request.querystring("note")
			closeTask taskid, messageusername
		case "addtasknote"
			addTaskNote taskid, request.querystring("note")
	end select


	sub addTaskNote(taskid, note)
		dim query
		
		query = "update task set description = description "
		query = query & " + Char(13) + Char(10) + Char(13) + Char(10) + '-- Appended by " & messageusername & " on " & date() & " -----' + Char(13) + Char(10) "
		query = query & " + '" & note & "'"
		query = query & " where id = " & taskid

		
		qryexecute query
	end sub
	
	sub addNewNote()
		dim query
		
		query = "insert into customernote (customersequencenumber, storeguid, source, note)"
		query = query & " values (" & customerseq
		query = query & ", '" & storeguid
		query = query & "', '" & messageusername
		query = query & "', '" & request.form("newnotetext") & "'"
		query = query & ")"

		qryexecute query
	end sub
	
	function closeTask(taskid, messageusername)
		dim query
		
		query = "update task set dateclosed = getdate(), "
		query = query & " employeeclosed = '" & messageusername & "'"
		query = query & " where id = " & taskid

		qryexecute query
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getBrightness(col)
		dim r, g, b
		
		r = clng("&H" & left(col, 2))
		g = clng("&H" & mid(col, 3, 2))
		b = clng("&H" & right(col, 2))

		getBrightness = 0.3 * r + 0.59 * g + 0.11 * b
	end function
	
	function fontContrastColor(col)
		if getBrightness(col) > 128 then
			fontContrastColor = "000000"
		else
			fontContrastColor = "ffffff"
		end if
	end function
	
	function getTaskDueDate(taskid)
		dim query, rs
		
		query = "select isnull(convert(varchar, datedue, 101), '') as duedate from task where id = " & taskid
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getTaskDueDate = rs("duedate")
		end if
	
		set rs = nothing
	end function
	
	function getTaskStatus(taskid)
		dim query, rs
		
		query = "select dateclosed from task where id = " & taskid
		set rs = getdisconnectedrecordset(query)
		
		if isnull(rs("dateclosed")) then
			getTaskStatus = "Open"
		else
			getTaskStatus = "Closed"
		end if
		
		set rs = nothing
	end function
	
	function jsGotoTask(taskid)
		jsGotoTask = "javascript:gotoTask(" & taskid & ");"
	end function
	
	
    Function linkTasks(messagetext)
        Dim place
        Dim ns
        Dim nl
        Dim replaceWith
        Dim dd


        If InStr(messagetext, "Task:") Then
            Do While InStr(messagetext, "Task:")
                place = InStr(messagetext, "Task:")
                ns = place + Len("Task:")
                nl = 0
                
                While IsNumeric(Mid(messagetext, ns, nl + 1)) And (ns + nl) <= Len(messagetext)
                    nl = nl + 1
                Wend

                dd = clng(Mid(messagetext, ns, nl))
                
                replaceWith = "<a href=""" & jsGotoTask(dd) & """>Task " & dd & " (" & getTaskStatus(dd) & ")</a>"
                
                messagetext = Mid(messagetext, 1, place - 1) & replaceWith & Mid(messagetext, place + Len("Task:") + nl, Len(messagetext))
                
                linkTasks = messagetext

            Loop
        Else
            linkTasks = messagetext
        End If

    End Function
    
	function getClaimStatus(claimid)
		dim query, rs
		
		query = "select claimstatus from claim where claimid = " & claimid
		set rs = getdisconnectedrecordset(query)
		
		if rs("claimstatus") = "O" then
			getClaimStatus = "Open"
		else
			getClaimStatus = "Closed"
		end if
		
		
		set rs = nothing
	end function
    
	function jsGotoClaim(claimid)
		jsGotoClaim = "javascript:gotoClaim(" & claimid & ");"
	end function
	
	Function linkClaims(messagetext)
        Dim place
        Dim ns
        Dim nl
        Dim replaceWith
        Dim dd


        If InStr(messagetext, "Claim:") Then
            Do While InStr(messagetext, "Claim:")
                place = InStr(messagetext, "Claim:")
                ns = place + Len("Claim:")
                nl = 0
                
                While IsNumeric(Mid(messagetext, ns, nl + 1)) And (ns + nl) <= Len(messagetext)
                    nl = nl + 1
                Wend

                dd = clng(Mid(messagetext, ns, nl))
                
                replaceWith = "<a href=""" & jsGotoClaim(dd) & """>Claim " & dd & " (" & getClaimStatus(dd) & ")</a>"
                
                messagetext = Mid(messagetext, 1, place - 1) & replaceWith & Mid(messagetext, place + Len("Claim:") + nl, Len(messagetext))
                
                linkClaims = messagetext

            Loop
        Else
            linkClaims = messagetext
        End If

    End Function
%>
<HTML>
<HEAD>
<TITLE>Customer Notes</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript">

	function addNewNote() {
		if(document.customerNotesform.newNoteText.value != "")
		{
			document.customerNotesform.action = "?useraction=addnewnote"
			document.customerNotesform.submit()
		}
		else
			cbs_alert("Empty notes are not allowed")
	}
	
	function createNewTask() {
		var w = window.open("/MainApp/createtask.asp?storeguid=<%=storeguid%>&customerseq=<%=customerseq%>&messageusername=<%=messageusername%>&customername=<%=URLEncode(customername)%>", "Task", "status=no,fullscreen=no,scrollbars=no,width=550,height=500");
	}
	
	
	function captureNewNote(){
		if (event.keyCode == 13){
			addNewNote()
		}
	}

	var savTaskId
	function closeTask(taskid) {
	    savTaskId = taskId;
		cbs_prompt("Closing task " + taskid + ".", handleTaskResolution)
	}

	function handleTaskResolution() {
        clearPromptMsg();
	    var taskResolution = document.getElementById('inputTxtLine').value
		if (taskResolution != null) {
			document.customerNotesform.action = "?useraction=closetask&taskid=" + savTaskId + "&note=" + taskResolution;
			document.customerNotesform.submit()
		}
	}

	function selectTask(taskid) {
		document.customerNotesform.action = "?useraction=selecttask&taskid=" + taskid;
		document.customerNotesform.submit()
	}
	
	function appendNote(taskid) {
	    savTaskId = taskId;
		cbs_prompt("Enter note", handleAppendNote, "", true);
	}

	function handleAppendNote() {
        clearPromptMsg();
	    var note = document.getElementById('inputTxtArea').value
		if(note != null)
		{
			document.customerNotesform.action = "?useraction=addtasknote&taskid=" + savTaskId + "&note=" + note;
			document.customerNotesform.submit()
		}
	}
	
	function gotoTask(taskid) {
		document.customerNotesform.action = "?taskid=" + taskid;
		document.customerNotesform.submit()
	}
	
	function gotoClaim(claimid) {
		parent.viewClaim(document.customerNotesform.storeguid.value, claimid);
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0 style="background:white; width: 100%">

<FORM id="customerNotesform" name="customerNotesform" action="" method="post" style="padding:0;margin:0">

<INPUT type=hidden name="storeguid" value="<%=storeguid%>" >
<INPUT type=hidden name="customerseq" value="<%=customerseq%>">
<INPUT type=hidden name="messageusername" value="<%=messageusername%>">
<INPUT type=hidden name="customername" value="<%=Server.HTMLEncode(customername)%>">
<INPUT type=hidden name="taskid" value="<%=taskid%>">

<TABLE style="width:100%" cellpadding="0" cellspacing="0" border="0"  style="background:white">

<TR valign="top">
<TD>
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin:0;">
	<SPAN style="float:left">
		<BUTTON onclick="createNewTask()">Add Task</BUTTON>
	</SPAN>
	
	<SPAN style="float:right;padding-top:6px;padding-right:5px">
		<TEXTAREA style="overflow:auto" style="width:300px;" name="newNoteText" ></TEXTAREA>
		<input type="button" value="Add Note" onclick="addNewNote()" style="height:40px; vertical-align: top">
	</SPAN>
</DIV>


<DIV style="margin:0;padding:0;overflow:auto;height:560px">

<TABLE class="itable" style="width:100%" cellpadding="0" cellspacing="0" border="0">
	<TR align="left">
		<TH align="center" style="width:100px;">Status</TH>
		<TH style="width:120px" align="center">Date</TH>
		<TH style="width:250px">From</TH>
		<TH style="width:520px">Note</TH>
	</TR>
	
<%
	query = "select task.*, taskpriority.name as taskpriorityname, isnull(task.employeeopened, 'Unknown') as employeeopened, convert(varchar, task.datecreated, 101) as datecreated, taskpriority.color as prioritycolor from "
	query = query & " task inner join customertask on "
	query = query & " task.id = customertask.taskid "
	query = query & " inner join taskpriority on "
	query = query & " task.priority = taskpriority.id "
	query = query & " where customertask.customersequencenumber = " & customerseq
	query = query & " and customertask.storeguid = '" & storeguid & "'"
	query = query & " and task.dateclosed is null "
	query = query & " and (task.dateopen is null or datediff(day, task.dateopen, getdate()) >= 0) "
	query = query & " order by task.id desc"
	set rs = getdisconnectedrecordset(query)
	
	
	while not(rs.eof or rs.bof)
%>
	<TR align="left" style="cursor:pointer" onclick="selectTask(<%=rs("id")%>)"  <%if trim(cstr(rs("id"))) = trim(cstr(taskid)) then%>style="background:#EEE"<%end if%>>
		<TD align="center"
		style="margin:3px;background-color:#<%=rs("prioritycolor")%>; color:#<%=fontContrastColor(rs("prioritycolor"))%>">
		Task <%=rs("id")%></TD>
		<TD style="width:240px" align="center"><%=rs("datecreated")%></TD>
		<TD style="width:180px" ><%=rs("employeeopened")%></TD>
		<TD style="width:450px"><%
			if len(rs("description")) > 130 then
				response.write left(rs("description"), 130) & "..."
			else
				response.write rs("description")
			end if
		%>
		</TD>
	</TR>
<%
		rs.movenext
	wend
	
	set rs = nothing
%>
	
<TR>
	<TD colspan="4" style="height:10px;background:#ddd;border-top:1px solid #888;border-bottom:1px solid #eee">&nbsp;</TD>
</TR>
<%
	query = "select customernote.*, convert(varchar, customernote.datecreated, 100) as datecreated, customernote.source "
	query = query & " from customernote "
	query = query & " where customernote.customersequencenumber = " & customerseq
	query = query & " and storeguid = '" & storeguid & "'"
	query = query & " order by convert(datetime, datecreated) desc"
	set rs = getdisconnectedrecordset(query)
	
	
	while not(rs.eof or rs.bof)
%>
	<TR>
		<TD style="width:100px;"></TD>
		<TD style="width:240px"><%=rs("datecreated")%></TD>
		<TD style="width:180px"><%=rs("source")%></TD>
		<TD style="width:450px"><%=linkClaims(linkTasks(rs("note")))%></TD>
	</TR>
<%
		rs.movenext
	wend
	
	set rs = nothing
%>
</TABLE>
</DIV>

</TD>
<TD style="border-left:2px groove;background:white;width:300px;">


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin:0">
	<SPAN style="float:left">
		<%if taskid <> "" then%><BUTTON onclick="appendNote(<%=taskid%>)">Append<BR>Note</BUTTON><%end if%>
		<%if taskid <> "" then%><BUTTON onclick="closeTask(<%=taskid%>)">Close<BR>Task</BUTTON><%end if%>
	</SPAN>
	
	<SPAN style="float:right;">

	</SPAN>
</DIV>

<%
	if taskid <> "" then
		query = "select task.*, taskpriority.name as taskpriorityname, isnull(task.employeeopened, 'Unknown') as employeeopened, convert(varchar, task.datecreated, 101) as datecreated, taskpriority.color as prioritycolor from "
		query = query & " task inner join customertask on "
		query = query & " task.id = customertask.taskid "
		query = query & " inner join taskpriority on "
		query = query & " task.priority = taskpriority.id "
		query = query & " where task.id = " & taskid

		
		set rs = getdisconnectedrecordset(query)
%>

<TABLE style="width:100%;background:#CCC;border-bottom:2px groove">
<TR>
	<TD colspan="2">
		<INPUT name="taskname" readonly style="width:100%;text-align:center" value="Task <%=taskid%>">
	</TD>
</TR>

<TR>
	<TD width="60px">Priority:</TD>
	<TD><INPUT name="taskpriority" readonly style="width:100%" value="<%=rs("taskpriorityname")%>"></TD>
</TR>

<TR>
	<TD width="60px">From:</TD>
	<TD><INPUT name="tasksource" readonly style="width:100%" value="<%=rs("employeeopened")%>"></TD>
</TR>

<TR>
	<TD width="60px">Date:</TD>
	<TD><INPUT name="taskdate" readonly style="width:100%" value="<%=rs("datecreated")%>"></TD>
</TR>

<TR>
	<TD width="60px">Date Due:</TD>
	<TD><INPUT name="taskdate" readonly style="width:100%" value="<%=rs("datedue")%>"></TD>
</TR>


</TABLE>

<DIV style="padding:5px;overflow:auto;height:440px">
<%=replace(rs("description"), vbcrlf, "<br>")%>
</DIV>
<%
	end if
%>

</TD>
</TR>
</TABLE>



</FORM>   

</BODY>
</HTML>

