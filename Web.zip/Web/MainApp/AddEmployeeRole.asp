<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim isSubmitted 
	dim l_storeid
	dim l_mode 
	dim l_roleid
	dim l_name
	dim l_level 
	
	issubmitted = Request.QueryString("submitted")
	l_storeid = session("storeid")
	l_roleid = Session("Roleid")
	
	if issubmitted then
		updatedatabase()
		Response.Redirect("employeeRole.asp")
	end if
	
	l_mode = Request.QueryString("mode")
	
	if l_mode = "edit" then
		getRoleInfo()
		
	end if
	
	
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	
	function submitForm() {
		if( trim(document.AddRoles.txtname.value) == "" || 
			trim(document.AddRoles.txtlevel.value) == "" )
			cbs_alert("Please enter a valid value for name and security level ");
		else {
		document.AddRoles.action = "?Submitted=true"
		document.AddRoles.submit();
		}
	}	
	
	function validateSecurityLevel(element){
		if ( !checkInt(element.value)){
			cbs_alert("Please enter a Numeric value ");
			element.focus();
		}
	}		
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Add/Edit Roles</H1>
<FORM id="AddRoles" name="AddRoles" action="" Method = "post">
<input type=hidden name="mode" value ="<%=l_mode%>">
<TABLE WIDTH="550" BORDER=0 CELLSPACING=0 CELLPADDING=0 align=center ><!-- header row -->
<tr><td align=left valign=top>
	<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 >
	<tr><td>
		<TABLE width = 100% border="0" cellpadding="7" cellspacing="0">
		<tr>
			<td width = 200px align = right class=label >Name</td>
			<TD><INPUT Class = text name="txtname"  maxlength = 64 value="<%=l_name%>"></TD>
		</tr>
		<tr>
			<td width = 200px align= right class=label >Security Level</td>
			<TD><INPUT Class = text name="txtlevel" onblur ="validateSecurityLevel(this)" value="<%=l_Level%>"></TD>
		</tr>
		</table>
	
	</td></TR>
	<TR><td align =center ><br><br>
		<INPUT class = touchnoborder name=OK type=button value=""   style="background-image:url(../images/OK.gif)" onClick="submitForm()" >
		</td>
		<td align= left><br><br>
		<INPUT class = touchnoborder name=cancel type=button value=""   style="background-image:url(../images/Cancel.gif)" onClick="history.back(-1)" >
	 </td></tr>
	</TABLE><br>
	</td></tr></table>
</FORM>
		
</BODY>
</HTML>
<%
	function getRoleinfo()
	
	dim sqltxt
	dim rsttemp
		sqltxt = "select * from Employeerole where roleid = " & l_roleid
		set rsttemp = getDisconnectedRecordset(sqltxt)
		if not rstTemp.bof and not rstTemp.eof then
			l_name = rsttemp("name")
			l_level = rstTemp("securitylevel")
			rsttemp.close
			set rstTemp =nothing
		end if
		
	end function
	
	function updateDatabase()
	dim sqltxt
	
	l_mode = Request.Form("mode")
	if l_mode = "edit" then
		sqltxt = "update employeerole set " _
				 & "[name] = " & dbcreateqrystring(Request.form("txtname")) _
				 & ",[securitylevel]= " & dbcreateqrynumeric(Request.form("txtlevel"))_
				 & " where roleid = " & L_roleid
				 
		dbstarttrans()
		
		QryexecutewithTrans(sqltxt)
		
		dbendtrans()
		
	elseif l_mode = "add" then
		sqltxt = "insert  employeerole ([name] ,[securitylevel],storeid) Values (" _
				& dbcreateqrystring(Request.form("txtname"))& ","& dbcreateqrynumeric(Request.form("txtlevel")) & "," & l_storeid _
				 & " ) "
		dbstarttrans()
		
		QryexecutewithTrans(sqltxt)
		
		dbendtrans()
		end if
	
	end function

%>
