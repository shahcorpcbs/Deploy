<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	'******************************************************************************
	'Name	: InactivateTicket.asp
	'==============================================================================
	' Date			Changed By		Change Log
    ' -----------------------------------------------------------------------------
	' 26-Sep-2003	MWiemann		Created 	
	'******************************************************************************
	dim l_storeid
	dim l_terminalid
	dim isSubmitted 
	dim actionString
	dim l_status
	dim objresult  
	dim name
	dim savedname
	dim invoiceNumber
	dim savedInvoiceNumber
	dim totalcount	
	dim status
	dim voidReason
	dim employeeId
	dim employeename
	dim voidApplied
	dim reqVoidReason
	dim ObjMiscSetup
	
	if not IsObject(Session("miscSetUp")) then
		initializeMiscSetup
	end if
	set ObjMiscSetup = Session("miscSetUp")	
	if ObjMiscSetup.Count > 0 then
		reqVoidReason = ObjMiscSetup.Item("requireVoidReason")
		if reqVoidReason then
			reqVoidReason = 1
		else
			reqVoidReason = 0
		end if		
	else
		reqVoidReason = 1
	end if		
	
	actionString = trim(Request.QueryString("userAction"))
	l_storeid = Session("storeid")
	l_terminalid = Session("terminalid")
	isSubmitted = Request.QueryString("submitted")
	invoiceNumber = Request.QueryString("invoicenumber")
	savedInvoiceNumber = invoiceNumber
	employeeId = Session("employeeid")
	employeeName = session("employeename")
	voidApplied = 1
	
	if actionString="results" then
		refreshView()
	end if
		
	if isSubmitted then
		UpdateDatabase()
		refreshView()
	end if

%>

<HTML>
<HEAD>
<TITLE>Activate Inactivate Customers</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript">
	function submitForm(element) {
		var reqVoidReason;
		var voidReason;
		var savedinvoice;
		var handled = false;

		switch (element){
			case "ok":
				document.inactivateTicketForm.action="InactivateTicketSearch.asp";
			case "cancel":
				document.inactivateTicketForm.action="InactivateTicketSearch.asp";
				break;
			case "makeActive":
				savedinvoice = document.inactivateTicketForm.savedInvoice.value;
				handled = true;
				cbs_prompt("New rack location for invoice " + savedinvoice + ".", handleMakeActive);
				break;	
			case "makeInActive":
				reqVoidReason = document.inactivateTicketForm.reqVoidReason.value;

				if (reqVoidReason == "1"){
				    handled = true;
					cbs_prompt("Enter the reason for voiding the invoice", handleMakeInactivewReason)
				}
				else{
					voidReason = "None"
				}
				savedinvoice = document.inactivateTicketForm.savedInvoice.value;
				document.inactivateTicketForm.action="?Submitted=true&status=inactive&invoicenumber=" + savedinvoice + "&voidReason=" + voidReason;
				break;
		}

		if (!handled)
		    document.inactivateTicketForm.submit();
	}


	function handleMakeInactivewReason() {
        clearPromptMsg();
	    var voidReason  = document.getElementById('inputTxtLine').value;
        var savedinvoice = document.inactivateTicketForm.savedInvoice.value;
		document.inactivateTicketForm.action="?Submitted=true&status=inactive&invoicenumber=" + savedinvoice + "&voidReason=" + voidReason;
		document.inactivateTicketForm.submit();
	}

	function handleMakeActive() {
	    var rackLocation  = document.getElementById('inputTxtLine').value;
	    var savedinvoice = document.inactivateTicketForm.savedInvoice.value;
		if(!rackLocation) {
		    return;
		}
		document.inactivateTicketForm.action="?Submitted=true&status=active&invoicenumber=" + savedinvoice + "&rack=" + encodeURIComponent(rackLocation);
		document.inactivateTicketForm.submit();
	}
	
	
	function selectAll(){
	var i;
	var x;
	i = 0
		if ( document.inactivateTicketForm.select != null){
			if (document.inactivateTicketForm.select.length >0 ) {
				while (i <= document.inactivateTicketForm.select.length) {
					if (! document.inactivateTicketForm(i).disabled) {
						if (document.inactivateTicketForm(i).checked )
							document.inactivateTicketForm(i).checked = false
						else
						document.inactivateTicketForm(i).checked = true
					}
					i++;
				}
			}
		}
	}
	
</script>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Void Invoice</H1>
<FORM id="inactivateTicketForm" name="inactivateTicketForm" action="" method="post" onsubmit="return false">
	<INPUT type="hidden" name="savedInvoice" value="<%=savedInvoiceNumber%>">
	<INPUT type="hidden" name="isSubmitted" value="<%=isSubmitted%>">
	<INPUT type="hidden" name="reqVoidReason" value="<%=reqVoidReason%>">
	<TABLE ALIGN=center WIDTH="930px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<tr height=40px></tr>
		<!-- header row -->
		<tr>
			
			<td align=left>
				<TABLE WIDTH="930px" BORDER=0 CELLSPACING=0 CELLPADDING=0>
					<tr class=head>
						<TD  style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:15%">Invoice No</TD>
						<TD  style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:25%">Customer Name</TD>
						<TD  style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:14%">Date In</TD>
						<TD  style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:14%">Date Due</TD>
						<TD  style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:12%">Amount</TD>
						<TD  style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:10%;">Status</TD>
						<td width=5%></td>
					</tr>
				</TABLE>
				<DIV STYLE="overflow-y:auto;height:100px; width=930px">
				<TABLE WIDTH="930px" BORDER=0 CELLSPACING=0 CELLPADDING=0>

					<%
						'Response.Write " going to retrieved results "
				
						if objresult.recordcount <=0 then %>
						<tr>
						<td colspan=7 style="FONT-SIZE: 18px;">
							Search criteria could not find any matching active invoices
						</td>
						</tr>	
					<%	else
			
						while not objresult.EOF
									
					%>
					
					<TR class=data>
						<TD style="padding-left:5px;text-align:left;FONT-SIZE: 18px;width:15%"><%=objresult("invoiceNumber")%>&nbsp</TD>
						<TD style="padding-left:5px;text-align:left;FONT-SIZE: 18px;width:25%"><%=cstr(objresult("customername"))%>&nbsp</TD>
						<TD style="padding-left:5px;text-align:left;FONT-SIZE: 18px;width:14%"><%=objresult("datein")%>&nbsp</TD>
						<TD style="padding-left:5px;text-align:left;FONT-SIZE: 18px;width:14%"><%=objresult("datedue")%>&nbsp</TD>
						<TD style="padding-left:5px;text-align:left;FONT-SIZE: 18px;width:12%"><%=formatCurrency(objresult("invoiceTotal"))%>&nbsp</TD>
						<TD style="padding-left:5px;text-align:left;FONT-SIZE: 18px;width:10%;"><%=objresult("ticketstatus")%>&nbsp</TD>
						<% if voidApplied = 0 and status="Active" then %>
						<TD style="padding-left:10px:text-align:left;FONT-SIZE: 18px;width:5%;color:red;">*&nbsp</TD>
						<%else%>
						<td width=5%></td>
						<% end if %>
					</TR>	
					<%
							objresult.movenext
						wend
						objresult.close
						set objresult = nothing
					end if
					if voidApplied = 0 and status="Active" then %>
					<TR class=data>
						<td colspan=7 style="FONT-SIZE: 18px;color:red;">* Invoice has payments applied, it cannot be voided
					</tr>	
					<% end if
					%>
				</table>
				</div>	
			</td>
		</tr>
		<TR HEIGHT=50px><TD></TD></TR>
		<TR>
			<td align="center">
				<BUTTON class=std id=makeActive name=makeActive onClick="submitForm(this.name)"
					<%if totalcount = 0 or status = "Active" then %>
						disabled
					<%end if%>>Reverse Pickup</button>
					&nbsp;&nbsp&nbsp&nbsp&nbsp

				<BUTTON class=std id=makeInActive name=makeInActive onClick="submitForm(this.name)"
					<%if totalcount = 0 or status = "Void" then %>
						disabled
					<%end if%>
					>Void Invoice</button>

			</td>
		</tr>
		<tr height=20px></tr>
		<tr height=100px>
			<td align="center" colspan=3>
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=2>
					<tr>
						<td align="center">
							<INPUT class=touchnoborder id=ok name=ok type=button  style="background-image:url(../images/Ok.gif)" value="" onClick="submitForm(this.name)">
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</form>
</BODY>
</HTML>
<%

	function RefreshView()
	dim sqltxt
	
		sqltxt = "Select distinct ticket.ticketNumber, customer.customername, ticket.customersequencenumber as customersequencenumber, " _
			& " tc.multiplepickup, tc.multiPickupCustomerName, tc.multiPickupLocation, " _
			& " case when ticketstatus = 'AC' then 'Active' when ticketstatus = 'FI' then 'Finished' when ticketstatus = 'VO' then 'Void' end as ticketstatus, "_
			& " invoiceNumber, convert(varchar, ticket.createdDate, 101) as 'DateIn', " _
			& " convert(varchar,dueDate,101) as 'DateDue',  invoiceTotal, IsNull(netTotal, 0) as netTotal, " _
			& " amountPaid From Ticket, Customer, ticketCustomer tc Where invoiceNumber='" & invoiceNumber _
			& " ' AND invoiceType in ('D','Q') AND onHold=0 "  _
			& " and ticket.ticketnumber = tc.ticketnumber AND Ticket.customersequencenumber = Customer.customersequencenumber " _
			& " Order By DateIn ASC"		
			
		set objresult = getdisconnectedrecordset(sqltxt)
		if objresult.recordcount > 0 then 
			totalcount = objresult.recordcount
			status = objresult("ticketstatus").value
		end if
	end function

	function UpdateDatabase()
	on error resume next
	dim sqltxt
	dim totalcount
	Dim i	
		totalcount = Request.Form("select").count
	
		l_status = Request.QueryString("status")
		voidReason = Request.QueryString("voidReason")
		
		if Request.Form("savedInvoice") <> "" then
			if l_status = "inactive" then
				dbstartTrans()
				sqltxt  = "execute VoidTicket @invoiceNumber='" & Request.Form("savedInvoice") & "',@employeeid=" & employeeid & ",@employeename='" _
							 & employeename & "',@voidReason='" & voidReason & "',@storeid=" & l_storeid & ",@terminalid=" & l_terminalid
				voidApplied = QryExecuteWithTransAndSelect(sqltxt)
					'If voidApplied = 1 then the ticket was voided, if it is 0 then the void was not applied as the ticket had payments on it.
				DbEndTrans()

                    Dim data, httpRequest, postResponse


                    if isMessengerEnabled() then
                        on error resume next

                        data = "invoiceNum=" & Request.Form("savedInvoice") & "&employeeId=" & session("employeeid")_
                            & "&reason=" & Server.URLEncode(voidReason)

                        Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
                        httpRequest.Open "POST", getMessengerFullPath("main") & "/invVoidCreated", False
                        httpRequest.SetRequestHeader "Content-Type", "application/x-www-form-urlencoded"
                        httpRequest.Send data
                        postResponse = httpRequest.ResponseText
                    end if
			elseif l_status = "active" then	
				dbstartTrans()
				sqltxt  = "execute ReactivateTicket @invoiceNumber='" & Request.Form("savedInvoice") & "',@rackLocation='" & Request.QueryString("rack")  & "',@employeeid=" & employeeid & _
						",@employeename='" & employeename  & "',@storeid=" & l_storeid & ",@terminalid=" & l_terminalid
				QryExecuteWithTrans(sqltxt)
				DbEndTrans()
			end if
		end if

	end function
%>

