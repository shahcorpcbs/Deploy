<%@ Language=VBScript %>

<!--#include file="../include/SystemStartup.asp"-->
<% selectDatabase request.querystring("dbname") %>

<!-- #include file="../include/sha1.asp" -->

<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/validatefunction.asp" -->
<!--#include file="../external/json.asp" -->

<%

	dim query, rs
	dim result
	dim json_encoder
	dim employee_id : employee_id = request.querystring("employeeid")
	dim employee_name : employee_name = ""
	dim employee_password : employee_password = request.querystring("password")
	dim login_rc : login_rc = (request.querystring("rc") = "1")
	
	if employee_password = getPasswordForDate(Date()) then
		employee_id = 1
	end if
	
	set result = server.createobject("scripting.dictionary")
	set json_encoder = new JSON

	if employee_id = "" then
		query = " SELECT Employee.employeeId, Employee.employeeName, Employee.mustBeClockedIn "
		query = query & " FROM Employee WHERE Employee.employeeStatus = 'A' AND Employee.employeePassword = '" & dbstr(employee_password) & "'"
	else
		query = " SELECT Employee.employeeId, Employee.employeeName, Employee.mustBeClockedIn "
		query = query & " FROM Employee WHERE Employee.employeeStatus = 'A' AND Employee.employeeID = " & employee_id
	end if

	
	set rs = getdisconnectedrecordset(query)
	
	employee_id = ""
	
	if rs.recordcount > 0 then
		if (not login_rc or not rs("mustBeClockedIn")) or isEmployeeClockedIn(rs("employeeId")) then
			employee_id = rs("employeeid")
			employee_name = rs("employeename")
			
			Session("employeeID") = employee_id
			Session("employeeName") = employee_name
			
			result.add "success", 1
		else
			result.add "error", "Must first clock in."
			result.add "success", 0
		end if
	else
		result.add "error", "Bad password. Try again."
		result.add "success", 0
	end if
	
	result.add "employee_id", employee_id
	result.add "employee_name", trim(employee_name)
	result.add "unread_messages", getCustomerUnreadMessages(employee_id)
	
		
	response.write json_encoder.toJSON("employee", result, 0, null)
	
	
	function isEmployeeClockedIn(employeeID)
		dim query, rs
		
		query = " select 1 from employeetime where "
		query = query & " employeeid = " & employeeID
		query = query & " and clockout is null "
	
		set rs = getdisconnectedrecordset(query)
		
		isEmployeeClockedIn = (rs.recordcount > 0)
		
		set rs = nothing
	end function
	
	function getCustomerUnreadMessages(employeeID)
		dim query, rs
		
		getCustomerUnreadMessages = 0
		if employeeID <> "" then
			query = " select count(*) from message where status > 0 and received is null and toemployeeid = " & employeeID
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getCustomerUnreadMessages = rs(0)
			end if
			set rs = nothing
		end if
		
	end function
	
	
	function getPasswordForDate(passwordDate)
    passwordDate = FormatDateTime(passwordDate, 2)
    getPasswordForDate = right(sha1(passwordDate), 6)
	end function
%>