<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
    dim query, rs
    dim customerDeliveryID
	dim mapURL
	dim deliveryAddress
	dim routeRef
	dim customerSeq

	routeRef = getReqVar("routeRef")
	customerDeliveryID = getReqVar("customerDeliveryID")
	deliveryAddress = getCustomerDeliveryAddress(customerDeliveryID)
	customerSeq = getReqVar("customerSeq")

	
    select case lcase(Request.QueryString("userAction"))
		case "change"
			changeAddress customerDeliveryID
		case "validate"
			validateAddress customerDeliveryID
    end select
	
	if deliveryAddress <> "" then
		mapURL = mapAddress(deliveryAddress)
	end if
	function changeAddress(customerDeliveryID)
		response.redirect "/MainApp/customerDelivery.asp?deliveryId=" & customerDeliveryID & "&routeRef=" & routeRef & "&customerSeq=" & customerSeq
	end function
	
	function validateAddress(customerDeliveryID)
		dim query, rs
		
		query = " update customerdelivery set addressmapped = 1 where id = " & customerdeliveryid
		qryexecute query
		
		goToRef
	end function
	
	sub goToRef()
		dim query, rs
		
		
		if routeRef <> "" then
			Response.Redirect "/setup/routesetup.asp?routeNumber=" & routeRef
		else
			Response.Redirect "/mainapp/customerdeliverylist.asp"
		end if

	end sub
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getCustomerDeliveryAddress(customerDeliveryID)
		dim query, rs
		
		query = " select deliveryaddress from customerdelivery where id = " & customerdeliveryid
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getCustomerDeliveryAddress = rs("deliveryaddress")
		end if
	
	end function

    function getNewMapFilename(description)
		dim path
		dim query, rs

		openConnection
		
		query= "INSERT INTO GeneratedMap (Description) VALUES ('" & description & "')"
		dbInsert query

		set rs = dbSelect("select @@IDENTITY as NewID")
		getNewMapFilename = rs("NewID")

		set rs = nothing
		
		closeConnection
    end function

	function getStoreAddress(storeid)
		dim query, rs
		dim result
		
		query = "select isnull(streetaddress1, '') as streetaddress1, "
		query = query & " isnull(streetaddress2, '') as streetaddress2, "
		query = query & " isnull(city, '') as city, "
		query = query & " isnull(state, '') as state, "
		query = query & " isnull(zipcode, '') as zipcode "
		query = query & " from store where storeid = " & storeid
		
		set rs = getdisconnectedrecordset(query)
			
		getStoreAddress = ""
		
		if rs.recordcount > 0 then
			result = trim(rs("streetaddress1"))
			if trim(rs("streetaddress2")) <> "" then
				result = result & vbcrlf & trim(rs("streetaddress2"))
			end if
			result = result & vbcrlf
			result = result & trim(rs("city")) & " " & trim(rs("state")) & ", " & trim(rs("zipcode"))
		end if
		
		set rs = nothing
		
		getStoreAddress = result
	end function

    function mapAddress(address)
        dim connector
        dim mp
		dim generatedmapid
		dim path
		dim physicalpath
		
        set connector = Server.CreateObject("MapServer.Connector")
        set mp = connector.MapPointController

        mp.ClearRoute

		mp.AddRouteStop cstr(getStoreAddress(session("storeid"))), "1"
        mp.AddRouteStop cstr(address), "2"
		mp.CalculateRoute
		
		generatedmapid = getNewMapFilename("Route Map")
		
		path = "/Maps/" & generatedmapid & ".png"
		physicalpath = Request.ServerVariables("APPL_PHYSICAL_PATH") & "Maps\" & generatedmapid & ".png"

		mp.SaveMapAsGif cstr(physicalpath), 600, 500

		mapAddress = path
		
        set rs = nothing
        set mp = nothing
        set connector = nothing
    end function

%>
<html>
<head>
<title>Validate Delivery Address</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</head>

<script language="javascript" type="text/javascript">
	
	function changeAddress() {
		document.validateDeliveryAddress.action = "?useraction=change";
		document.validateDeliveryAddress.submit();
	}
	
	function validateAddress() {
		document.validateDeliveryAddress.action = "?useraction=validate";
		document.validateDeliveryAddress.submit();
	}
	
</script>




<body topmargin=0 leftmargin=0 style="color:black"><!-- #include file="../include/banner.inc" -->
<H1>Validate Delivery Address</H1>
<form id="validateDeliveryAddress" name="validateDeliveryAddress" action="" Method="post">
<input type="hidden" name="customerDeliveryID" value="<%=customerDeliveryID%>" />
<input type="hidden" name="routeRef" value="<%=routeRef%>" />
<input type="hidden" name="customerSeq" value="<%=customerSeq%>" />
<table align="center">

	<tr>
		<td>
			<%=replace(deliveryAddress, vbcrlf, "<br />")%>
		</td>
		<td align="right">
			<input style="height:40px;width:80px" type="button" onclick="changeAddress()" value="Change" />
			<input style="height:40px;width:80px" type="button" onclick="validateAddress()" value="Validate" />
		</td>
	</tr>

	<tr>
		<td colspan="2" align="center">
			<img src="<%=mapURL%>" />
		</td>
	</tr>
</table>


</form>
</body>
</html>
