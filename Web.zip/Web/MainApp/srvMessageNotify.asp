<%@ Language=VBScript %>
<!--#include file="../include/QueryDatabase.asp"-->
<%
	dim query, rs
	dim accountname
	dim accountid
	dim storeguid
	dim storename
	
	acccountname = request.querystring("accountname")
	accountid = getMessageAccountID(acccountname)
	storeguid = request.querystring("storeguid")
	storename = request.querystring("storename")

	if acccountname <> "" then
		updateMessageAccountStore
	end if
	
	function getMessageAccountID(username)
		dim query, rs

		query = "select id from messageaccount where lower(username) = '" & lcase(username) & "'"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getMessageAccountID = rs("id")
		else
			getMessageAccountID = ""
		end if

		set rs = nothing
	end function
	
	function getMessageServerURL()
		dim query, rs
		
		query = "select isnull(messageServerURL, '') as messageServerURL from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getMessageServerURL = trim(rs("messageServerURL"))
		
		set rs = nothing
	end function
	
	function updateMessageAccountStore()
		dim query, rs
		dim doupdate
		
		query = "select count(*) as cnt from messageaccountstore where messageaccountid = " & accountid & " and storeguid = '" & storeguid & "'"
		set rs = getdisconnectedrecordset(query)
		
		doupdate = rs("cnt") > 0
		set rs = nothing
		
		if doupdate then
			query = "update messageaccountstore set datelastseen = getdate() where messageaccountid = " & accountid & " and storeguid = '" & storeguid & "'"
		else
			query = "insert into messageaccountstore (messageaccountid, storeguid, storename)"
			query = query & " values ("
			query = query & accountid
			query = query & ", " & "'" & storeguid & "'"
			query = query & ", " & "'" & storename & "'"
			query = query & ")"
		end if
		
		qryexecute query
	end function
%>
<HTML>
<HEAD>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<SCRIPT language="javascript" type="text/javascript">
	function viewMessage(id) {
		var w = window.open("<%=getMessageServerURL()%>/MainApp/MessageView.asp?messageid=" + id, "MessageView", "status=no,scrollbars=no,width=600,height=600,modal=yes");
	}
	
	function composeMessage() {
		var w = window.open("<%=getMessageServerURL()%>/MainApp/MessageCompose.asp?fromaccount=<%=acccountname%>", "MessageCompose", "status=no,scrollbars=no,width=600,height=600,modal=yes");
	}
	
	function viewHistory() {
		var w = window.open("<%=getMessageServerURL()%>/MainApp/MessageHistory.asp?accountname=<%=acccountname%>", "MessageCompose", "status=no,scrollbars=yes,width=900,height=600,modal=yes");
	}
	
	function createTask() {
		var w = window.open("<%=getMessageServerURL()%>/MainApp/createtask.asp?messageusername=<%=acccountname%>", "MessageCompose", "status=no,scrollbars=no,width=600,height=600,modal=yes");
	}
	
	function jumpToCustomerManagement(storeguid, customerseq, taskid) {
		parent.jumpToCustomerManagement(storeguid, customerseq, taskid);
	}

</SCRIPT>
</HEAD>
<BODY STYLE="margin:0;padding:0">



<%if accountid <> "" then%>
<%

	function getTaskCount()
		dim query, rs
		
		query = "select count(*) as cnt from "
		query = query & " employeetask inner join task on "
		query = query & " employeetask.taskid = task.id "
		query = query & " where employeetask.employeemessageid = '" & acccountname & "'"
		query = query & " and task.dateclosed is null"
		
		set rs = getdisconnectedrecordset(query)
		getTaskCount = rs("cnt")
		
		set rs = nothing
	end function
	
	query = "select messageitem.*, messageaccount.username as fromaccountname from messageitem inner join messageaccount on messageitem.fromaccount = messageaccount.id where toaccount = " & accountid & " and datereceived is null order by datesent desc"
	set rs = getdisconnectedrecordset(query)
%>

<%

	if rs.recordcount > 0 then
			response.write "<span style="""">Unread Messages</span><hr>"
	end if
	
	while not (rs.eof or rs.bof)
		response.write "<input type=""button"" style=""width:100%;height:40px;margin:2px"" onclick=""javascript:viewMessage(" & rs("id") & ")"" value=""" & rs("subjecttext") & " (" & rs("fromaccountname") & ")"" />"
		rs.movenext
	wend
%>
<%end if%>

</BODY>
</HTML>
