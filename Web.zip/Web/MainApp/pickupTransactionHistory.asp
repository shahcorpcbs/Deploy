<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim ticketNo
	dim pickUpDate
	dim pickUpTime
	dim totalAdditions
	dim totalCoupons
	dim storeInfo
	dim totalPayments
	dim totalOverRides
	dim empName
	dim totalDiscounts
	dim sInvoiceNumber
	dim objPayments
	dim strpayment
	ticketNo = Request.QueryString("ticketNo")
	sInvoiceNumber = Request.QueryString("invoiceNo")
	getPickUpTranHistory
	getPayments
	
	sub getPickUpTranHistory()
		dim ssql
		dim objResultSet
		
		ssql = "SELECT top 1 ticket.dateOut, logDate, isnull(additions, 0) as additions, isnull(coupons, 0) as coupons, isnull(discounts, 0) as discounts, storeName, isnull(payments, 0) as payments, isnull(overriddenAmount, 0) as overriddenAmount, " _
				& " employeeName FROM TicketLog " _
				& " inner join ticket on " _
				& " ticketlog.ticketnumber = ticket.ticketnumber " _
				& " Where ticketlog.ticketNumber=" & CLng(ticketNo) _
				& " And logType='P' " _
				& " order by logDate desc " 
				
		set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Recordcount > 0 then
			objResultSet.MoveFirst
			pickUpDate = FormatDateTime(objResultSet.Fields("dateOut").Value, vbShortDate)
			pickUpTime = FormatDateTime(objResultSet.Fields("dateOut").Value, vbLongTime)
			totalAdditions = formatcurrency(objResultSet.Fields("additions").Value)
			totalCoupons = formatcurrency(objResultSet.Fields("coupons").Value)
			totalDiscounts = formatcurrency(objResultSet.Fields("discounts").Value)
			storeInfo = objResultSet.Fields("storeName").Value
			totalPayments = formatcurrency(objResultSet.Fields("payments").Value)
			totalOverRides = formatcurrency(objResultSet.Fields("overriddenAmount").Value)
			empName = objResultSet.Fields("employeeName").Value
		end if
	end sub
	
	sub getPayments()
		dim ssql
		dim objResultSet
		
		ssql = "SELECT t.onAccountamount, p.amountpaid, p.paymentTypename, pg.paymentGroupDescription " _
				& " FROM TicketLog t, payment P, paymentgroup pg Where t.ticketNumber=" & CLng(ticketNo) _
				& " And logType='P' and t.paymentgroupnumber = pg.paymentGroupNumber and t.paymentgroupnumber *= p.paymentgroupnumber" 
	
		set objPayments =getdisconnectedrecordset(ssql)
	end sub
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Pick Up Transcation History</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function cancelForm(){
		var ticketNo;
		ticketNo = document.pickupTranHistoryForm.ticketNumber.value;
		document.pickupTranHistoryForm.action="finishedInvoices.asp?userAction=fromDetail&ticketNumber=" +  ticketNo;
		document.pickupTranHistoryForm.submit();
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Pick Up Invoice Transaction History
<%=sInvoiceNumber%></B>
<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >	
<FORM id="pickupTranHistoryForm" name="pickupTranHistoryForm" action="pickupTransactionHistory.asp" method="post">
	<INPUT type="hidden" name="ticketNumber" value="<%= ticketNo %>">
	<tr height=20px></tr>
	<tr>
		<td>
			<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
				<TR>
					<TD align=right class="label">Pick Up Date</TD>
					<TD>
						<INPUT id=txtPickupDt name=txtPickupDt class=text value="<%= pickUpDate%>" readonly>
					</TD>
				</TR>
				
				<TR>
					<TD align=right class="label">Pick Up Time</TD>
					<TD>
						<INPUT id=txtPickupTime name=txtPickupTime class=text value="<%= pickUpTime%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Additions</TD>
					<TD>
						<INPUT id=txtAdditions name=txtAdditions class=text value="<%= totalAdditions%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Coupons</TD>
					<TD>
						<INPUT id=txtDiscount name=txtDiscount class=text value="<%= totalCoupons%>" readonly>
					</TD>
				</TR>
				
				<TR>
					<TD align=right class="label">Discount</TD>
					<TD>
						<INPUT id=txtDiscount name=txtDiscount class=text value="<%= totalDiscounts%>" readonly>
					</TD>
				</TR>
				
				<TR>
					<TD align=right class="label">Payments</TD>
					<TD>
						<INPUT id=txtPayments name=txtPayments class=text value="<%= totalPayments%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Payment Details</TD>
					<TD>
						<SELECT name=txtPayments id=txtPayments size=4 style="width:175px;">
						<% if objPayments.recordcount >0 then
							if objPayments("onAccountamount")>0 then
								strpayment  = formatCurrency(objPayments("onAccountamount") ) & " " & "On Account" %>
								<option><%=strpayment%></option>
							<%end if %>
							<%while not objPayments.eof
									if objPayments("amountpaid") > 0 then
										strpayment = formatCurrency(objPayments("amountPaid"), 2) & " " & objPayments("paymentTypeName") & " " & objPayments("paymentGroupDescription") %>
										<option><%=strpayment%></option>
								<%end if  
							objPayments.movenext
							wend
						END if
						objPayments.close
						set objPayments = nothing	
						%>
													
						
						</select>
						
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Over Rides</TD>
					<TD>
						<INPUT id=txtOverRide name=txtOverRide class=text value="<%= totalOverRides%>" readonly>
					</TD>
				</TR>
				
				<TR>
					<TD align=right class="label">Employee Name</TD>
					<TD>
						<INPUT id=txtEmpName name=txtEmpName class=text value="<%= empName%>" readonly>
					</TD>
				</TR>
			</TABLE>
		</td>
	</tr>
	<tr>
		<td>
			<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<TR>
						<td width=45%></td>
						<TD align=center width=40px>
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick="history.back(-1);">
						</td>
						<td width=25px>
						<td align=center width=40px>
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onclick="history.back(-1);">
						</TD>
						<td width=35%></td>
					</TR>     
			</TABLE>
		</td>
	</tr>
</FORM>   
</table>
</BODY>
</HTML>

