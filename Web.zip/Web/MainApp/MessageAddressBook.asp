<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/sha1.asp"-->
<!--#include file="../include/messages.asp" -->

<%
	dim query, rs
	dim fromaccount
	
	fromaccount = request.querystring("fromaccount")
	
	function getMessageServerURL()
		dim query, rs
		
		query = "select isnull(messageServerURL, '') as messageServerURL from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getMessageServerURL = trim(rs("messageServerURL"))
		
		set rs = nothing
	end function
	
	function isMessageUserAtStore(username, StoreGUID)
		dim query, rs
		
		query = "select count(*) account_count from messageaccountstore "
		query = query & " inner join messageaccount on "
		query = query & " messageaccountstore.messageaccountid = messageaccount.id "
		query = query & " where messageaccount.username = '" & username & "' and storeguid = '" & StoreGUID & "'"
		
		set rs = getdisconnectedrecordset(query)
		
		isMessageUserAtStore = (rs("account_count") > 0)
		
		set rs = nothing
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
<LINK href="../External/checktree/checktree.css" rel="stylesheet" type="text/css">


<STYLE type="text/css">

.storeDiv {

	height:30px;
	text-align:center;
	background:#DADADA;
	font-size:16;
	font-weight:bold;
	padding-top:5px;
	cursor:pointer;
	border:1px outset;
	
}
#accountDiv {

	height:30px;
	text-align:left;
	font-size:14;
	background: #eee;
	padding:5px;
}


</STYLE>


<script type="text/javascript" src="../External/checktree/checktree.js"></script>
 
<SCRIPT language="javascript" type="text/javascript">

	var employeemenu = new CheckTree('employeemenu');

	function reportAccountList() {
		var accountlist = document.messageaddressbook.messageaccount;
		var resultString;
		
		resultString = "";
		
		if(!(document.messageaddressbook.messageaccount)) {
			cbs_alert("No employees chosen");
			return false;
		}
		for(var i = 0; i < accountlist.length; ++i) {
			if(accountlist[i].checked)
			{
				if(resultString != "")
					resultString = resultString + ", "
				
				resultString = resultString + accountlist[i].value;
			}
		}
		
		
		window.opener.mb_callback(resultString);
		return true;
	}
	function SetRowCheckedStatus(row, check, value) {
		if(!value)
			document.messageaddressbook.messageaccount.checked = false
			
		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "messageaccount") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "messageaccount") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}
	
	function toggleStoreDiv(objname) {
		var obj;
		obj = document.getElementById(objname);
		obj.style.display = (obj.style.display == "none" ? "block" : "none");
	}
	


</SCRIPT>


</HEAD>

<BODY STYLE="margin:0;padding:0;background:#FFF">

<FORM id="messageaddressbook" name="messageaddressbook" method="post" style="margin:0;padding:0;">

<INPUT type="hidden" name="messageaccount" value="" checked="false" />

<TABLE style="width:100%" cellspacing="0" cellpadding="0">
<TR><TD style="width:50%">
<INPUT style="width:100%;height:50px" type="button" value="Cancel" onclick="window.close()">
</TD><TD style="width:50%">
<INPUT style="width:100%;height:50px" type="button" value="Ok" onclick="if(reportAccountList())window.close();">
</TD></TR>
</TABLE>

<DIV style="text-align:center;background:#CCC;font-size:16;padding:6px;">
Select Employee
</DIV>

<div>
<%
	dim laststorename
	dim counter
	
	query = "select messageaccount.username, messageaccountstore.storename, messageaccountstore.storeguid from "
	query = query & " messageaccount inner join messageaccountstore "
	query = query & " on messageaccount.id = messageaccountstore.messageaccountid "
	query = query & " where datediff(day, messageaccountstore.datelastseen, getdate()) <= 14 "
	query = query & " order by messageaccountstore.storename"
	
	set rs = getdisconnectedrecordset(query)
	
	counter = 1
	
	while not(rs.bof or rs.eof)

		if rs("storename") <> laststorename then
%>
		</div><div class="storeDiv" onclick="toggleStoreDiv('storediv<%=counter%>')" ><%=rs("storename")%></div><div id="storediv<%=counter%>" <%if not isMessageUserAtStore(rs("username"), rs("storeguid")) then%>style="display:none"<%end if%> >
<%
		end if
%>
		<div id="accountDiv" onclick="ToggleRowChecked(this)" >
			<input name="messageaccount" type="checkbox" value="<%=rs("username")%>" onclick="ToggleRowChecked(this.parentNode);" />
			<%=rs("username")%>
		</div>
<%
		laststorename = rs("storename")
		
		counter = counter + 1
		rs.movenext
	wend
	set rs = nothing
	
%>
</div>


</FORM>
</BODY>
</HTML>
