<%@ Language=VBScript %>
<% option explicit %>
<!-- #include file="../include/SystemStartup.asp" -->
<% if request.querystring("db") <> "" then
	selectDatabase request.querystring("db")
	end if
%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!-- #include file="../include/services.asp" -->

<%
	const vbUpperCase = 1
	const vbLowerCase = 2
	const vbProperCase = 3
	const vbWide = 4
	const vbNarrow = 8
	const vbKatakana = 16
	const vbHiragana = 32
	const vbUnicode = 64
	const vbFromUnicode = 128


	dim storeid : storeid = request.querystring("storeid")
	dim formname : formname = request.querystring("formname")
	dim transactionid : transactionid = request.querystring("transactionid")
	dim voidpaymentid : voidpaymentid = request.querystring("voidpaymentid")
	dim formType


	dim fields : set fields = server.createobject("scripting.dictionary")
	dim rawform

	if formname <> "" then
		rawForm = getRawForm(formname, storeid)
	end if


	loadGlobalFields

	if transactionid <> "" then
		loadTransactionFields transactionid
	end if

	if voidpaymentid <> "" then
		loadVoidTransactionFields voidpaymentid
	end if

	if request.querystring("cust") then
		loadCustomerFields request.querystring("cust")
	end if

	if request.querystring("emp") then
		loadEmployeeFields request.querystring("emp")
	end if

	if request.querystring("tnum") then
		loadTicketFields request.querystring("tnum")
	end if


	rawForm = transform(rawForm, fields)


    dim query, rs, httpRequest, postResponse, notificationIP
    notificationIP = getPrinterShortPath()

    if notificationIP <> "" then
        Dim params, userIPAddress

        userIPAddress = getLocalPrinterAddress(session("terminalid"))


        Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
        if Request.QueryString("type") <> "pdf" then
            query = "select printerName, u200, u200Type from Printer where printerId = " & Request.QueryString("pid")
            set rs = getdisconnectedrecordset(query)
            params = "/text?requestPrinterName=" & replace(Server.HTMLEncode(rs("printerName")), "\", "%5") _
                & "&textType=" & formType & "&driver=" _
                & Server.HTMLEncode(Request.QueryString("driver")) & "&isU200=" & Server.HTMLEncode(rs("u200")) _
                & "&u200Type=" & Server.HTMLEncode(rs("u200Type"))
        else
            params = "/text?textType=pdf"

        end if

        httpRequest.Open "POST", "http://" & userIPAddress & notificationIP & params, False
        httpRequest.SetRequestHeader "Content-Type", "text/plain"
        httpRequest.Send Server.HTMLEncode(rawForm)
        postResponse = httpRequest.ResponseText

    end if


	'response.addheader "Content-Disposition", "inline;filename=" & formname & ".rtf"
	'response.contenttype = "text/rtf"
	'response.write rawForm
	response.end






	function transform(form, fields)
		dim fieldName
		dim result

		result = form

		for each fieldName in fields.keys
			result = replace(result, fieldName, fields(fieldName))
		next

		transform = result
	end function




	function regField(fieldname, value)
		fields.add fieldname, cstr(value)
	end function


	function loadGlobalFields()
		regField "@@@TRATIME", FormatDateTime(Now, 3)
		regField "@@@TRADATE", FormatDateTime(Now, 2)
	end function


	function loadCustomerFields(customerseq)
		' TODO
	end function

	function fixName(customerName)
		'HOEPPNER/CURT M
		dim parts

		parts = split(customerName, "/")


		if ubound(parts) > lbound(parts) then
			fixName = trim(parts(ubound(parts))) & " " & trim(parts(lbound(parts)))
		else
			fixName = trim(customerName)
		end if

	end function

	function loadTicketFields(ticketnumber)
		dim query, rs

		query = " select invoicenumber, convert(varchar(8), createddate, 1) as createddate from ticket "
		query = query & " where ticketnumber = " & ticketnumber

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then

			regField "@@@TNUM", rs("invoicenumber")
			regField "@@@CREDATE", rs("createddate")

		end if

		set rs = nothing
	end function

	function loadEmployeeFields(employeeid)
		dim query, rs
		dim firstname
		dim lastname

		query = " select isnull(firstname, '') as firstname, isnull(lastname, '') as lastname from employee "
		query = query & " where employeeid = " & employeeid

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			firstname = trim(rs("firstname"))
			lastname = trim(rs("lastname"))

			regField "@@@EFN", firstname
			regField "@@@ELN", lastname
			regField "@@@EFI", left(firstname, 1)
			regField "@@@ELI", left(lastname, 1)

		end if

		set rs = nothing
	end function

	function loadCustomerFields(customerseq)
		dim query, rs
		dim firstname
		dim lastname

		query = " select isnull(firstname, '') as firstname, isnull(lastname, '') as lastname from customer "
		query = query & " where customersequencenumber in (" & customerseq & ")"

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			firstname = trim(rs("firstname"))
			lastname = trim(rs("lastname"))

			regField "@@@CFN", firstname
			regField "@@@CLN", lastname
			regField "@@@CFI", left(firstname, 1)
			regField "@@@CLI", left(lastname, 1)

		end if

		set rs = nothing
	end function

	function loadTransactionFields(transactionid)
		dim query, rs
		dim result_nodes
		dim xml_doc
		dim node
		dim customerName
		dim receiptText
		dim jsonObj

		query = " select isnull(cardpayment.rawanswer, '') as rawanswer, customer.customername, employee.firstname as efn, employee.lastname as eln from cardpayment "
		query = query & " inner join customer on cardpayment.customersequencenumber = customer.customersequencenumber "
		query = query & " left outer join employee on cardpayment.clerk = employee.employeeid "
		query = query & " where cardpayment.transactionid = '" & dbstr(transactionid) & "'"

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then

			customerName = rs("customername")
			if (Left(rs("rawanswer"), 1) = "{") or (Left(rs("rawanswer"), 2) = chr(34) & "{") then
			    dim raw
			    raw = rs("rawanswer")
                if Left(raw, 1) = chr(34) then
                    raw = Left(raw, Len(raw) - 1)
                    raw = Right(raw, Len(raw) - 1)
                end if


                set jsonObj = JSon.parse(raw)
                receiptText = createClearentReceiptData(jsonObj)
                if formType = "html" then
                    regField "@@@CCRECEIPTDATA", Replace(receiptText, Chr(10), "<br />")
                else
                    regField "@@@CCRECEIPTDATA", Replace(receiptText, Chr(10), "\par" & Chr(13) & Chr(10))
                end if

            else
				set xml_doc = server.createobject("MSXML2.DOMDocument")
				if xml_doc.loadXML(rs("rawanswer")) then

					set result_nodes = xml_doc.selectNodes("//XCEXPRESSLINKRESULT/*")

					for each node in result_nodes
						select case ucase(node.nodeName)
							case "NAME" ' HOEPPNER/CURT M
								customerName = fixName(node.text)
							case "RESULT" ' SUCCESS
							case "TYPE" ' Purchase
							case "APPROVALCODE" ' TRNING
								regField "@@@CCAUTHCODE", node.text
							case "SWIPED" ' F
							case "CLERK" ' 1
							case "XCTRANSACTIONID" ' TRAINING1234
							case "ACCOUNT" ' XXXXXXXXXXXX1111
								regField "@@@CCACCTNUM", node.text
							case "EXPIRATION" ' 1010
								regField "@@@CCEXPDATE", node.text
							case "ACCOUNTTYPE" ' VISA
								regField "@@@CCTYPE", node.text
							case "AMOUNT" ' 3.50
								regField "@@@CCTOTAL", node.text
							case "RECEIPT"
								regField "@@@CCRECEIPTDATA", Replace(node.text, Chr(10), "\par" & Chr(13) & Chr(10))

							end select
					next
				end if
			end if
			regField "@@@EFN", rs("efn")
			regField "@@@EFI", left(ltrim(rs("efn")), 1)
			regField "@@@ELN", rs("eln")
			regField "@@@ELI", left(ltrim(rs("eln")), 1)

			regField "@@@CCCARDHOLDER", customerName
		end if

		set rs = nothing
	end function

	function loadVoidTransactionFields(cardpaymentId)
		dim query, rs
		dim result_nodes
		dim xml_doc
		dim node
		dim customerName
		dim receiptText
		dim jsonObj
		

		query = " select isnull(cardvoid.rawanswer, '') as rawanswer, amount, customer.customername, employee.firstname as efn, employee.lastname as eln from cardvoid "
		query = query & " inner join customer on cardvoid.customersequencenumber = customer.customersequencenumber "
		query = query & " left outer join employee on cardvoid.clerk = employee.employeeid "
		query = query & " where cardvoid.cardpaymentId = '" & dbstr(cardpaymentId) & "'"

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then

			customerName = rs("customername")
			if (Left(rs("rawanswer"), 1) = "{") or (Left(rs("rawanswer"), 2) = chr(34) & "{") then
			    dim raw
			    raw = rs("rawanswer")
                if Left(raw, 1) = chr(34) then
                    raw = Left(raw, Len(raw) - 1)
                    raw = Right(raw, Len(raw) - 1)
                end if


                set jsonObj = JSon.parse(raw)
                receiptText = createClearentVoidReceiptData(jsonObj, rs("amount"))
                regField "@@@CCRECEIPTDATA", Replace(receiptText, Chr(10), "\par" & Chr(13) & Chr(10))
			end if
			


			regField "@@@EFN", rs("efn")
			regField "@@@EFI", left(ltrim(rs("efn")), 1)
			regField "@@@ELN", rs("eln")
			regField "@@@ELI", left(ltrim(rs("eln")), 1)

			regField "@@@CCCARDHOLDER", customerName
		end if

		set rs = nothing
	end function



	function getRawForm(formname, storeid)
		dim query, rs
		dim oVB6
		formType = "rtf"

		query = "select formlayout, type"
		query = query & " from form "
		query = query & " where formname = '" & dbstr(formname) & "'"
		if storeid <> "" then
			query = query & " and storeid = " & clng(storeid)
		end if

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			set oVB6 = Server.CreateObject("ShahCorpComponents.HelperFunctions")

			if rs("type") = "text/html" then
			    formType = "html"
                getRawForm = trim(oVB6.ASPStrConv(rs("formLayout"), vbUnicode))
			else
			    getRawForm = oVB6.ASPStrConv(rs("formLayout").Value, vbUnicode)
			end if

		end if

	end function

%>
<script runat="server" language="javascript" src="../Script/clearent.js" ></script>
<script runat="server" language="javascript" src="../Script/json2.js"></script>