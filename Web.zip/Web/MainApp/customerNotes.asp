<%@ Language=VBScript %>
<% option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim isSubmitted
	dim isCancel 
	dim l_customerseq
	
	isSubmitted = Request.QueryString("Submitted")
	isCancel = Request.QueryString("Cancel")
	
	if isSubmitted then
		updateDatabase()
		screenRedirection()
	end if
	
	if isCancel then
		screenRedirection()
	end if
	
	
	dim l_screenNotes
	dim l_Invoicenotes
	dim l_showwindow
	dim notesdate

	l_customerseq= Request.QueryString("customerseq")
	
	if len(trim(l_customerseq)) = 0 then
		l_customerseq= session("customersequencenumber")
	end if
	
	getNotesInfo()
%>
<HTML>
<HEAD>
<TITLE>Customer Notes</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		var scrNotesLen = parseInt(document.customerNotesform.screenNotes.value.length);
		var invNotesLen = parseInt(document.customerNotesform.invoiceNotes.value.length);

		if(scrNotesLen > 200) {
			cbs_alert("Screen notes is " + (scrNotesLen - 200) + " characters beyond the limit. Please shorten the screen notes field.");
			return false;
		}
		if(invNotesLen > 200) {
			cbs_alert("Invoice notes is " + (invNotesLen - 200) + " characters beyond the limit. Please shorten the invoice notes field.");
			return false;
		}
		
		document.customerNotesform.action= "?submitted=true" + "&customerseq=" + document.customerNotesform.customerSeq.value ;
		document.customerNotesform.submit();
	}
	function cancelForm(){
		document.customerNotesform.action = "?cancel=true"
		document.customerNotesform.submit()
	}
	
	function showCustomerNotes() {
	//	var w = window.open("customerStats.asp?customerseq=<%=l_customerseq%>", "CustomerNotes", "status=no,fullscreen=no,scrollbars=no,width=800,height=400");
		document.customerNotesform.action = "customerStats.asp?customerseq=<%=l_customerseq%>";
		document.customerNotesform.submit()
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Customer Notes</H1>
<FORM id="customerNotesform" name="customerNotesform" action="" method="post">

<INPUT type=hidden name="targetPage" value="<%=Request.QueryString("targetpage")%>" >
<INPUT type=hidden name="customerSeq" value="<%=l_customerseq%>">
<INPUT type=hidden name="routeid" value="<%=Request.QueryString("Routeid")%>">
<INPUT type="hidden" name="lineNumber" value="<%= Request.form("lineNumber")%>">
<INPUT type="hidden" name="selectedDept" value="<%=  Request.form("selectedDept")%>">
<INPUT type="hidden" name="upChargePageCount" value="<%=  Request.form("upChargePageCount") %>">
<INPUT type="hidden" name="colorsPageCount" value="<%=  Request.form("colorsPageCount") %>">
<INPUT type="hidden" name="PatternPageCount" value="<%=  Request.form("PatternPageCount") %>">
<INPUT type="hidden" name="ItemPageCount" value="<%=  Request.form("ItemPageCount") %>">
<INPUT type="hidden" name="addOrEdit" value="<%=  Request.form("addOrEdit") %>">
<INPUT type="hidden" name="upchargeSet" value="<%=  Request.form("upchargeSet") %>">
<INPUT type="hidden" name="colorSet" value="<%=  Request.form("colorSet") %>">
<INPUT type="hidden" name="patternSet" value="<%=  Request.form("patternSet") %>">
<INPUT type="hidden" name="DeptPageCount" value="<%=  Request.form("DeptPageCount") %>">
<INPUT type="hidden" name="selItemId" id="selItemId" value="<%=  Request.form("selItemId")%>">
<INPUT type="hidden" name="selUpcharge" id="selUpcharge" value="<%=  Request.form("selUpcharge")%>">
<INPUT type="hidden" name="selColor" id="selColor" value="<%=  Request.form("selColor")%>">
<INPUT type="hidden" name="selPattern" id="selPattern" value="<%=  Request.form("selPattern")%>">
<INPUT type="hidden" name="originPage" value="<%= Request.form("originPage") %>">
<INPUT type="hidden" name="selDeptId" value="<%=  Request.form("selDeptId")%>">
<INPUT type="hidden" name="fromCustSeqNum" value="<%=  Request.QueryString("fromCustSeqNum")%>">

	
<CENTER>
	<TABLE>
		<TR>
			<TH>Screen Notes</TH>
			<TH>Invoice Notes</TH>
		</TR>

		<TR>
			<TD><TEXTAREA rows=5 cols=30 style="overflow:auto" id=screenNotes name=screenNotes><%=l_screennotes%></TEXTAREA></TD>
			<TD><TEXTAREA rows=5 cols=30 style="overflow:auto" id=invoiceNotes name=invoiceNotes><%=l_invoicenotes%></TEXTAREA></TD>
		</TR>

		<TR>
			<TD>
				<INPUT type="checkbox" name="showOnEachAccess"  STYLE="Height=28px;width=28px" <%=l_showwindow%>> Show Notes Each Access<BR>
			</TD>
			
			<TD align="right">
				<INPUT type="button" style="width:100px;height:50px" value="View Stats" onclick="showCustomerNotes()" />
			</TD>
		</TR>

		<TR style="height:100px">
			<TD colspan="2" align="center">
			 	<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/OK.gif)" onClick= "submitForm()">
			 	<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value=""  style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
			</TD>
		</TR>
	</TABLE>
</CENTER>
	
	

</FORM>   

</BODY>
</HTML>
<%


	function getNotesInfo()
	dim sqltxt 
	dim rsnotes 
		
		sqltxt = "SELECT  screennotes, invoiceNotes, "_
					&	"notesEditDate, showNotesOnEachAccess FROM Customer where customersequencenumber = " & l_customerseq
		
		set rsnotes = GetDisconnectedRecordset(sqltxt)
		
		if not rsnotes.bof and not rsnotes.eof Then
		
			l_screenNotes = rsNotes("screennotes")
			l_InvoiceNotes = rsNotes("invoicenotes")
			
			if not isnull(rsnotes("noteseditdate")) then
				notesdate = formatdateTime(rsnotes("noteseditdate"),2)
			end if
			
			if rsnotes("showNotesOnEachAccess") then
				l_showwindow= "CHECKED"
			end if
		end if
		
	end function
	
	function updateDatabase()
	dim sqltxt
	dim customerseq
		customerseq = Request.Form("customerseq")
		if len(trim(customerseq)) > 0  then
		
			sqltxt = "Update customer set " _
				& "screenNotes = " & dbcreateqrystring(Request.Form("screennotes")) _
				& ",invoiceNotes = " & dbcreateQryString(Request.Form("invoiceNotes")) _
				& ",noteseditDate =" & "Getdate()" _
				& ",shownotesoneachaccess = " & evalRequestValue(Request.form("showOnEachAccess")) _
				& "where customersequencenumber = " & customerseq
				'& ",vipEligible = " & evalRequestValue(Request.form("chkVIPEligible")) _
				
				
			DbStartTrans()
			
			QryexecuteWithTrans(Sqltxt)
			
			DbEndTrans()
		end if
		'Response.write stargetpage
		
		
	end function

	function screenRedirection()
	
	dim sTargetpage
	dim customerseq
	dim straction
	
		customerseq = Request.Form("customerseq")
		stargetpage = lcase(Request.form("targetpage"))

		select case stargetpage
			case "customerdiscount"
				if isSubmitted then
					response.redirect("/mainapp/customerdiscount.asp?targetpage=customerentry&customerseq=" & session("prevcustomersequencenumber") & "&referredby=" & customerseq)
				else
					response.redirect("/mainapp/customerdiscount.asp?customerseq=" & session("prevcustomersequencenumber") )
				end if
			case "customerentry"
				response.redirect("customerEntry.asp?mode=edit&customerseq=" & customerseq)
			case "customerfunctions"
				response.redirect("customerFunctions.asp?Customerseq=" & customerseq)
			case "changecustomerfunctions"
				response.redirect("customerFunctions.asp?Customerseq=" & customerseq)
			case "applypayments"
				response.redirect("ApplyPayments.asp?Customerseq=" & customerseq)
			case "issuecharge"
				response.redirect("IssueCreditOrCharge.asp?Customerseq=" & customerseq)
			case "runstatements"
				response.redirect("runStatements.asp?Customerseq=" & customerseq)
			case "route"
				response.redirect("/setup/RouteAddEdit.asp?Customerseq=" & customerseq & "&routeid=" & Request.Form("routeid"))
			case "routesetup"
				response.redirect("/setup/routeSetup.asp?userAction=adddelivery&customerseq=" & customerseq)
			case "quick"
				straction= "quickInvoice.asp?userAction=fromCustomerNotes&addorEdit="& Request.Form("addorEdit") & "&selDept=" & Request.Form("selDeptId")& "&deptPageCount=" & Request.Form("DeptPageCount")
				response.redirect(straction)
			case "detail"
			straction= "detailedInvoice.asp?userAction=fromCustomerNotes&addOrEdit=" & Request.Form("addOrEdit") & "&lineNo=" &  Request.Form("lineNumber") & "&dept=" &  Request.Form("selectedDept") & "&upIndex=" & Request.Form("upChargePageCount") & "&cIndex=" & Request.Form("colorsPageCount") & "&pIndex=" & Request.Form("PatternPageCount") & "&itIndex=" & Request.Form("ItemPageCount")  & "&deptIndex=" & Request.Form("DeptPageCount") & "&selItemId=" & Request.Form("selItemId") & "&selUp=" & Request.Form("selUpcharge") & "&selColor="& Request.Form("selColor") & "&selPattern="&  Request.Form("selPattern") & "&cset="& Request.Form("colorset") & "&pset=" & Request.Form("patternset")&  "&upset=" & Request.Form("upchargeset") & "&originpage="  & Request.Form("originpage")
				response.redirect(straction)
			case "pickup"
				straction = "customerfunctions.asp?customerseq="& customerseq
				response.redirect(straction)
			case "scheduledelivery"
				response.redirect("scheduleDelivery.asp?Customerseq=" & customerseq)
			case "reportparams"
				response.redirect("/mainapp/reportParams.asp?customerSequenceNumber=" & customerseq)
			case "mergecustfrom"
				response.redirect("/mainapp/mergeCustomers.asp?fromPage=searchFrom&fromCustSeqNum=" & customerseq)
			case "mergecustto"
				response.redirect("/mainapp/mergeCustomers.asp?fromPage=searchTo&toCustSeqNum=" & customerseq & "&fromCustSeqNum=" & Request.Form("fromCustSeqNum"))
			case else
				response.redirect("customerFunctions.asp?customerseq=" & customerseq)
		end select 
	
	
	end function
%>
