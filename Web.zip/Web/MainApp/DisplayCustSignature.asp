<%@ Language=VBScript %>
<!-- #include file="../include/QueryDatabase.asp" -->

<%
	dim ssql
	dim objRst
	dim ticketNumber
	ticketNumber = Request.QueryString("ticketNumber")
	ssql = "Select signature from Signature, SignatureTracking where refType='TI' " _
			& " AND refNumber="  & ticketNumber & " And Signature.signatureId = SignatureTracking.signatureId"
	set objRst = getDisconnectedRecordset(ssql)
	if objRst.Recordcount > 0 then
		Response.Buffer = true
		Response.Clear
		Response.ContentType = "image/bmp"
		Response.BinaryWrite(objRst.Fields("signature"))
	else
		Response.Write "No Signature to display"
	end if
%>