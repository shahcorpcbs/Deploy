<%@ Language=VBScript %>
<% option explicit %>

<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="CheckSessionExpiry.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%

Session("objRP").outputDirectory = Server.MapPath("\") & "\ReportOutFiles\"
Call UpdateSessionParams



%>

<%
	function getWeekDropDown(previousSelection)
	
		getWeekDropDown = "<option value=1" & IIf(previousSelection = 1, " selected ", " ") & ">Sunday" & _
				"<option value=2" & IIf(previousSelection = 2, " selected ", " ") & ">Monday" & _
				"<option value=3" & IIf(previousSelection = 3, " selected ", " ") & ">Tuesday" & _
				"<option value=4" & IIf(previousSelection = 4, " selected ", " ") & ">Wednesday" & _
				"<option value=5" & IIf(previousSelection = 5, " selected ", " ") & ">Thursday" & _
				"<option value=6" & IIf(previousSelection = 6, " selected ", " ") & ">Friday" & _
				"<option value=7" & IIf(previousSelection = 7, " selected ", " ") & ">Saturday"
				
	end function

	function getMonthDropDown(previousSelection)
		
		Dim returnString
		Dim i
				
		returnString = "<option value=1>First Day"
		for i=2 to 31
			returnString = returnString & _
				"<option " 
			if i = previousSelection then
				returnString = returnString & " selected "
			end if
			returnString = returnString &  "value=" & i & ">" & i
		next

		returnString = returnString & "<option "
		if i = previousSelection then
			returnString = returnString & " selected "
		end if
		returnString = returnString & " value=32>Last Day"
		
		getMonthDropDown = returnString
	end function
	
%>
<HTML>
<HEAD>
<TITLE>Frequency</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function submitForm() {
		if (document.frequencyForm.scheduleName.value == "") {
			alert("You must enter a name for the schedule.");
			document.frequencyForm.scheduleName.focus();
			return false;
		}

		if (document.frequencyForm.autoEmail.checked == true && document.frequencyForm.emailAddresses.value == "") {
			alert("If you select the option to send EMail, you must also specify at least one EMail Address.");
			document.frequencyForm.emailAddresses.focus();
			return false;
		}

		if (document.frequencyForm.autoSaveAs.checked == true && document.frequencyForm.saveAsDir.value == "") {
			alert("If you select the option to store output files in a directory, you must also specify a directory.");
			document.frequencyForm.saveAsDir.focus();
			return false;
		}

		if (document.frequencyForm.autoEmail.checked == false && 
		    document.frequencyForm.autoSaveAs.checked == false && 
		    document.frequencyForm.autoPrint.checked == false ) {
			alert("You must check at least one of Print, EMail, or Store in Directory options.");
			document.frequencyForm.saveAsDir.focus();
			return false;
		}
		document.frequencyForm.submit();
	}

</SCRIPT>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->

<H1>Set Schedule Information for - <%= Session("objRP").reportName %></H1>
<FORM id="frequencyForm" name="frequencyForm" action="reportFrequencyResponse.asp" method="Post">

    <table>
		<tr>
		<td STYLE="color:#3200A4;">
			Please enter the Schedule Frequency and Output Destination and press OK button. 
			Note that the information is not saved till you press the OK button.<br>
		</td>
		</tr>
   </table>

	<TABLE ALIGN=center WIDTH="600px" BORDER=4 CELLSPACING=1 CELLPADDING=5 >

		<tr height=30px>			
			<td class="label">Name of the Schedule
			</td>
			<td class="label" nowrap colspan=2>
				<input type="text" size=40 maxlen=1024 name="scheduleName" id="scheduleName" value="<%=Session("objRP").scheduleName%>">
			</td>
		</tr>

		<tr height=30px>
			
			<td class="label" nowrap colspan=3>
				<input type="radio" name="frequencyType" id="frequencyType" value="DA" 
				<% if Session("objRP").frequencyType = "DA" then %>
				 checked
				<% end if%>
				>Daily
			</td>
		</tr>
		<tr height=30px>
			
			<td class="label" nowrap>
				<input type="radio" name="frequencyType" id="frequencyType" value="BI"
				<% if Session("objRP").frequencyType = "BI" then %>
				 checked
				<% end if%>
				>Bi-Weekly
			</td>
			<td>
				<select name="biweeklyDayOfWeek1" id="biweeklyDayOfWeek1" style="font-size:14px;">
					<% 
					if Session("objRP").frequencyType = "BI" then 
						Response.Write getWeekDropDown(Session("objRP").frequencyValue1) 
					else
						Response.Write getWeekDropDown(0) 
					end if
					%>
				</select>
			</td>
			<td><strong>and &nbsp;</strong>
				<select name="biweeklyDayOfWeek2" id="biweeklyDayOfWeek2" style="font-size:14px;">
					<% 
					if Session("objRP").frequencyType = "BI" then 
						Response.Write getWeekDropDown(Session("objRP").frequencyValue2) 
					else
						Response.Write getWeekDropDown(0) 
					end if
					%>
				</select>
			</td>
		</tr>
		<tr height=30px>
			
			<td class="label" nowrap>
				<input type="radio" name="frequencyType" id="frequencyType" value="WE"
				<% if Session("objRP").frequencyType = "WE" then %>
				 checked
				<% end if%>
				>Weekly
			</td>
			<td colspan=2>
				<select name="weeklyFrequencyValue1" id="weeklyFrequencyValue1" style="font-size:14px;">
					<% 
					if Session("objRP").frequencyType = "WE" then 
						Response.Write getWeekDropDown(Session("objRP").frequencyValue1)
					else
						Response.Write getWeekDropDown(0) 
					end if
					%>
				</select>
			</td>
		</tr>
		<tr height=30px>
			
			<td class="label" nowrap>
				<input type="radio" name="frequencyType" id="frequencyType" value="SM"
				<% if Session("objRP").frequencyType = "SM" then %>
				 checked
				<% end if%>
				>Semi-Monthly
			</td>
			<td>
				<select name="semiMonthlyFrequencyValue1" id="semiMonthlyFrequencyValue1" style="font-size:14px;">
					<% 
					if Session("objRP").frequencyType = "SM" then 
						Response.Write getMonthDropDown(Session("objRP").frequencyValue1)
					else
						Response.Write getMonthDropDown(0)
					end if
					%>
				</select>
			</td>
			<td><strong>and &nbsp;</strong>
				<select name="semiMonthlyFrequencyValue2" id="semiMonthlyFrequencyValue2" style="font-size:14px;">
					<% 
					if Session("objRP").frequencyType = "SM" then 
						Response.Write getMonthDropDown(Session("objRP").frequencyValue2)
					else
						Response.Write getMonthDropDown(0)
					end if
					%>
				</select>
			</td>
		</tr>
		<tr height=30px>
			
			<td class="label" nowrap>
				<input type="radio" name="frequencyType" id="frequencyType" value="MO"
				<% if Session("objRP").frequencyType = "MO" then %>
				 checked
				<% end if%>
				>Monthly
			</td>
			<td colspan=2>
				<select name="monthlyFrequencyValue1" id="monthlyFrequencyValue1" style="font-size:14px;">
					<% 
					if Session("objRP").frequencyType = "MO" then 
						Response.Write getMonthDropDown(Session("objRP").frequencyValue1)
					else
						Response.Write getMonthDropDown(0)
					end if
					%>
				</select>
			</td>
		</tr>
		<tr height=30px>
			
			<td class="label" nowrap colspan=3>
				<input type="radio" name="frequencyType" id="frequencyType" value="QU"
				<% if Session("objRP").frequencyType = "QU" then %>
				 checked
				<% end if%>
				>Quarterly
			</td>
		</tr>

		<tr height=30px>			
			<td class="label" nowrap colspan=3>
				<input type="checkbox" name="autoPrint" id="autoPrint" value="1" 
				<% if Session("objRP").outputPrintInd = true then %>
				checked
				<% end if %>
				>Automatically Print
			</td>
		</tr>
		
		<tr height=30px>			
			<td class="label">
				<input type="checkbox" name="autoEmail" id="autoEmail" value="1" <%= IIf(Session("objRP").outputEmail <> "", " checked ", " ") %>>EMail to
			</td>
			<td class="label" nowrap colspan=2>
				<input type="text" size=40 name="emailAddresses" id="emailAddresses" value="<%=Session("objRP").outputEmail%>">
			</td>
		</tr>

		<tr height=30px>			
			<td class="label">
				<input type="checkbox" name="autoSaveAs" id="autoSaveAs" value="1" <%= IIf(Session("objRP").outputDirectory <> "", " checked ", " ") %>>Store in the following Directory
			</td>
			<td class="label" nowrap colspan=2>
				<input type="text" size=40 name="saveAsDir" id="saveAsDir" value="<%=Session("objRP").outputDirectory%>">
			</td>
		</tr>
	</table>

	<TABLE ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr>
			<td width = 50% align=right >
				<INPUT class=touchnoborder id=ok name=ok type=button value="" onClick="submitForm();" 
					style="background-image:url(../images/Ok.gif);">
			</td>
			<td width = 50% align=left >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<INPUT class=touchnoborder id=close name=close type=button value="" onClick="history.back(-1);" 
					style="background-image:url(../images/Cancel.gif);">
			</td>
		</tr>
	</table>
</form>
</BODY>
</HTML>
