<%@ Language=VBScript %>
<%option explicit%>
<%
	dim dbname
	
	dbname = request.querystring("dbname")
	if dbname = "" then dbname = "default"
%>

<!--#include file="../include/SystemStartup.asp"-->
<% selectDatabase dbname %>

<!--#include file="../include/QueryDatabase.asp"-->
<!-- #include file="../include/ValidateFunction.asp" -->

<%
    dim ticketNum, invoice
	ticketNum = request.querystring("ticketNum")
	set invoice = Server.CreateObject("ShahCorpComponents.invoice")
	invoice.DBConnectionString = Session("shahcorpDSN")
	invoice.LoadDefaults
	invoice.getExistingDetails ticketNum
	invoice.calculateSurcharges
    invoice.recalculatePrepay
    invoice.saveInvoice "edit", 1, 1, 0, "", "", True

%>

