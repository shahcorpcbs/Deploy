<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim l_storeid
	dim isSubmitted 
	dim l_action
	dim actionstring
	dim i 
	dim L_error
	dim l_messageid
	dim l_hourlywage
	dim l_phone

	
	
	l_storeid = Session("storeid")
	isSubmitted = Request.QueryString("submitted")
	
	actionstring= Request.QueryString("useraction")
	if isSubmitted then
		updateDatabase()
	end if
	
	
	if actionstring = "edit" then
		getEmployeeInfo()
	end if

%>

<HTML>
<HEAD>
<TITLE>Add Employee</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function validateFields(){
		if (trim(document.addEmployeeForm.txtEmpLastName.value) == "" ||
			trim(document.addEmployeeForm.txtEmpFirstName.value) == ""){
			cbs_alert("Please enter a valid value for FirstName and lastname");
			return false
		}
		else
		{
			if (trim(document.addEmployeeForm.txtEmpPasswd.value) == "") {
			    cbs_confirm("Are you sure you want to use a blank password?", addEmployee);
                return false;
            }
		}
		return true;
	}

	function formatAreacodeOnFocus(element){
		var tempval
		tempval = new String(trim(element.value))
		tempval= tempval.replace(")", "")
		tempval= tempval.replace("(", "")
		element.value = tempval
		element.select()

	}

	function formatAreacodeOnBlur(element){
		var tempval
		tempval = new String(trim(element.value))
		if (tempval.length >= 3 ) {
			tempval= tempval.replace(")", "")
			tempval= tempval.replace("(", "")
			element.value = tempval
			element.value = "(" + tempval.substring(0,3) + ")"
			if (element.name == "txtMainAreaCode" )
				document.addEmployeeForm.txtMainPhone.focus()
			else
				document.addEmployeeForm.txtAltPhone.focus()
		}


	}

	function formatPhoneOnKeyUp(element){
    		var tempval
    		var tempx
    		tempval = new String(ltrim(element.value))
    		tempval = tempval.replace("-", "")
    		if (tempval.length > 3){
    				element.value = tempval.substring(0, 3) + "-" + tempval.substring(3)
    		}
    	}

    function checkEmployeeFields() {
	    if (validateFields())
	        addEmployee();
    }

	function addEmployee(){
        clearConfirmMsg();
		switch(document.addEmployeeForm.targetPage.value) 
			{
				case "add":
						document.addEmployeeForm.action ="?Submitted=true&useraction=employeeManagement.asp";
						break;
				case "edit":
						document.addEmployeeForm.action ="?Submitted=true&useraction=employeeList.asp";
						break;
		}
		document.addEmployeeForm.submit();
	}

	function deductHours() {
		if(document.addEmployeeForm.deductTime.checked) {
			document.addEmployeeForm.StdBreaksHours.disabled=false;
			document.addEmployeeForm.StdBreaksMin.disabled=false;
			document.addEmployeeForm.StdLunchHours.disabled=false;
			document.addEmployeeForm.StdLunchMin.disabled=false;
			document.addEmployeeForm.DeductBreaksHours.disabled=false;
			document.addEmployeeForm.DeductBreaksMin.disabled=false;
			document.addEmployeeForm.DeductLunchHours.disabled=false;
			document.addEmployeeForm.DeductLunchMin.disabled=false;
		}else{
			document.addEmployeeForm.StdBreaksHours.disabled=true;
			document.addEmployeeForm.StdBreaksMin.disabled=true;
			document.addEmployeeForm.StdLunchHours.disabled=true;
			document.addEmployeeForm.StdLunchMin.disabled=true;
			document.addEmployeeForm.DeductBreaksHours.disabled=true;
			document.addEmployeeForm.DeductBreaksMin.disabled=true;
			document.addEmployeeForm.DeductLunchHours.disabled=true;
			document.addEmployeeForm.DeductLunchMin.disabled=true;
		}
	}
	
	function populateCurrentAccessLevel(userSelection){
		document.addEmployeeForm.txtCurrentAccessLevel.value=userSelection;
	}
	
	function cancelForm(){
	
		switch(document.addEmployeeForm.targetPage.value) 
			{
				case "add":
						document.addEmployeeForm.action ="employeeManagement.asp";
						break;
				case "edit":
						document.addEmployeeForm.action ="employeeList.asp";
						break;
		}
		document.addEmployeeForm.submit();
		
	}
	
	function selectRoles() {
		document.addEmployeeForm.action = "editemployeeroles.asp?originPage=addnewemployee&employee=<%=session("setupEmployeeid")%>";
		document.addEmployeeForm.submit();
	
	}
	

	
	function updateMessageID(messageid) {
		document.addEmployeeForm.MessageID.value = messageid;
	}
	function setFocus() {
		document.addEmployeeForm.txtEmpFirstName.focus();
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0 onLoad="deductHours();setFocus();formatPhoneOnKeyUp(document.getElementById('txtMainPhone'));">
<%
	dim formTitle
	if actionString="add" then
		formTitle ="Add New Employee"
	else
		formTitle ="Edit Employee"	
	end if	
%>
<!-- #include file="../include/banner.inc" -->
<H1>&nbsp;<%= formTitle%></H1>
<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=0>	
<FORM id="addEmployeeForm" name="addEmployeeForm" action="" method="post">
	<INPUT type="hidden" name="targetPage" value="<%= actionString %>">
	<tr>
		<td>
			<table ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=2>
			<% if len(trim(l_error)) > 0 then %>
				<tr>
					<td align=right class="label"><b><font color=red>Error</font></td>
					<td align=left class="label"><b><font color=red><%=l_error%></font></td>
				</tr>
			<% end if %>
				<tr>
					<td width="50%" align=right class="label">Employee First Name<b><font color=red>*</td>
					<td>
						<INPUT id=txtEmpFirstName name=txtEmpFirstName style="width:250px" maxlength = 64 class=text value="<%=l_firstname%>">
					</td>
				</tr>
				<tr>
					<td align=right class="label">Employee Last Name<b><font color=red>*</font></td>
					<td>
						<INPUT id=txtEmpLastName name=txtEmpLastName style="width:250px" maxlength = 64 class=text value="<%=l_Lastname%>">
					</td>
				</tr>
				<tr>
					<td align=right class="label">Internal Email Address</td>
					<td>
						<INPUT id=txtEmail name=txtEmail class=text style="width:250px" maxlength = 255 value="<%=l_email%>">
					</td>
				</tr>
				<tr>
					<td align=right class="label">Employee Password<b><font color=red>*</font></td>
					<td>
						<INPUT type="password" id=txtEmpPasswd name=txtEmpPasswd class=text style="width:250px" maxlength = 20 value="<%=l_passwd%>"> 
					</td>
				</tr>
			</table>
			

		</td>
		
		<td valign="top">
			<table>
				<% if session("setupEmployeeid") <> "" then %>
				
				<tr>
					<td align=right class="label">Employee Roles</td>
					<td>
					<INPUT readonly class=text style="width:250px" maxlength = 20 value="<%
							getEmpRoles()
							if rstRoles.Recordcount > 0 then
								while not rstRoles.eof 
									Response.write trim(rstRoles("EmployeeRoleName")) & " "
									rstRoles.movenext
								Wend
							end if
						%>"> 
						<input type=button onclick="selectRoles();" value="Modify">
					</td>
				</tr>
				<% end if %>

				<tr>
					<td align=right class="label">Hourly Wage</td>
					<td>
						<INPUT class=text name="HourlyWage" style="width:250px" maxlength=20 value="<%=l_hourlywage%>"> 
					</td>
				</tr>
				<tr>
					<td align=right class="label">Employee ID</td>
					<td>
						<INPUT class=text name="assignedID" style="width:250px" maxlength=10 value="<%=l_assignedID%>"> 
					</td>
				</tr>
				<tr>
					<td align=right class="label">Department</td>
					<td>
						<select style="font-size:16;width:260px;" name=selectdept onchange="selectDept()">
					<%	dim query,rs
						query = "select empDeptID, name from employeeDepartment"
						set rs = getdisconnectedrecordset(query)
						
						while not (rs.eof or rs.bof)
					%>
							<option <%if trim(rs("empDeptID") =l_empDeptID) then%>selected<%end if%> value = "<%=rs("empDeptID")%>">
									<%=rs("name")%>
							</option>
					<%	
							rs.movenext
						wend
						
						set rs = nothing
					%>
						</select>						
					</td>
				</tr>
				<tr>
					<td align=right class="label">Employee Phone</td>
					<td>
                        <INPUT id=txtMainAreaCode name=txtMainAreaCode  style="HEIGHT: 25px; WIDTH:50px" maxlength = 5  onclick="this.select()" onFocus="formatAreacodeOnFocus(this)" onBlur = "formatAreacodeOnBlur(this)"  onKeyup = "formatAreacodeOnBlur(this)" value="<%=Left(l_phone, 3)%>" size="20">
                        <INPUT id=txtMainPhone name=txtMainPhone  style="HEIGHT: 25px; WIDTH:200px" maxlength = 8 onkeyup= "formatPhoneOnKeyUp(this)"  value="<%=Right(l_phone, 7)%>" size="20" tabindex="4">
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td align=center colspan=2>
			<br />
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<table ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=3>
				<tr>
					<td class="label" colspan=2 align="center">
						<INPUT type="checkbox" id=deductTime name=deductTime style="height=28px;width=28px" onClick="deductHours()"
						<%if l_deduct then %>
							CHECKED
						<%end if %>
						>Deduct Time for Employee Breaks
					</td>
					
					<td class="label" colspan=2 align="center">
						<INPUT type="checkbox" id=mustBeClockedIn name=mustBeClockedIn style="height=28px;width=28px""
						<%if l_mustBeClockedIn then %>
							CHECKED
						<%end if %>
						>Employee Must Be Clocked In
					</td>
				</tr>
				<tr>
					<td colspan=2 style="font-size:14px;font-weight:bold;" align=center><strong>Standard Breaks</strong></td>
					<td colspan=2 style="font-size:14px;font-weight:bold;" align=center><strong>Lunch</strong></td>
				</tr>
				<tr>
					<td align=center class="label" colspan=2>For Every Continuous Period of:</td>
					<td align=center class="label" colspan=2>For Every Continuous Period of:</td>
				</tr>
				<tr>
					<td align=right>Hours:
						<select name="StdBreaksHours" style="width:40px;font-size:14px" >
							<%
								'Response.Write int(l_SBreak/60)
								for i=0 to 12
							%>
								<option value="<%= i%>"
								<%if i = int(l_SBreak/60 ) then %>
									SeLected
								<%end if %>
								><%= i%>
							<%
								next
							%>
						</select>
					</td>
					<td>Minutes:
						<select name="StdBreaksMin" style="width:40px;font-size:14px" >
							<%
								for i=0 to 59
							%>
								<option value="<%= i%>"
								<%if i = (l_SBreak mod 60 ) then %>
									SeLected
								<%end if %>
								><%= i%>
							<%
								next
							%>
						</select>
					</td>
					<td align=right>Hours:
						<select name="StdLunchHours" style="width:40px;font-size:14px" >
							<%
								for i=0 to 12
							%>
								<option value="<%= i%>"
								<%if i = int(l_LBreak /60 ) then %>
									SeLected
								<%end if %>
								><%= i%>
							<%
								next
							%>
						</select>
					</td>
					<td>Minutes:
						<select name="StdLunchMin" style="width:40px;font-size:14px" >
							<%
								for i=0 to 59
							%>
								<option value="<%= i%>"
								<%if i = (l_LBreak mod 60 ) then %>
									SeLected
								<%end if %>
								><%= i%>
							<%
								next
							%>
						</select>
					</td>
				</tr>
				<tr>
					<td align=center class="label" colspan=2>Deduct</td>
					<td align=center class="label" colspan=2>Deduct</td>
				</tr>
				<tr>
					<td align=right>Hours:
						<select name="DeductBreaksHours" style="width:40px;font-size:14px" >
							<%
								for i=0 to 12
							%>
								<option value="<%= i%>"
								<%if i =int( l_SDeduct /60 ) then %>
									SeLected
								<%end if %>
								><%= i%>
							<%
								next
							%>
						</select>
					</td>
					<td>Minutes:
						<select name="DeductBreaksMin" style="width:40px;font-size:14px" >
							<%
								for i=0 to 59
							%>
								<option value="<%= i%>"
								<%if i = (l_SDeduct mod 60 ) then %>
									SeLected
								<%end if %>
								><%= i%>
							<%
								next
							%>
						</select>
					</td>
					<td align=right>Hours:
						<select name="DeductLunchHours" style="width:40px;font-size:14px" >
							<%
								for i=0 to 12
							%>
								<option value="<%= i%>"
								<%if i = int(l_LDeduct / 60 ) then %>
									SeLected
								<%end if %>
								><%= i%>
							<%
								next
							%>
						</select>
					</td>
					<td>Minutes:
						<select name="DeductLunchMin" style="width:40px;font-size:14px" >
							<%
								for i=0 to 59
							%>
								<option value="<%= i%>"
								<%if i = (l_Ldeduct mod 60 ) then %>
									SeLected
								<%end if %>
								><%= i%>
							<%
								next
							%>
						</select>
					</td>	
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<table ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=1>
				<tr>
					<td align=center>	
						<INPUT class=touchnoborder id=add name=add type=button value="" style="background-image:url(../images/OK.gif)" onClick="checkEmployeeFields()">&nbsp&nbsp&nbsp&nbsp&nbsp
						<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" onClick=cancelForm()>
					</td>
					<td></td>
				</tr>
			</table>
		</td>
	</tr>
</form>
</table>
</BODY>
</HTML>
<%
	dim l_status
	dim l_firstname
	dim l_lastName
	dim l_email
	dim l_emproleid
	dim l_deduct
	dim l_passwd
	dim l_SBreak
	dim l_SDeduct
	dim l_LBreak
	dim l_LDeduct
	dim l_mustBeClockedIn
	dim l_assignedID
	dim l_empDeptID
	
	Function getEmployeeInfo()
	dim sqltxt
	dim rstEmp
	DIM l_employeeid 
	
	l_employeeid = Request.QueryString("employee")
	if l_employeeid = "" then
		l_employeeid  = session("setupEmployeeid")
	end if
	
	sqltxt =  "SELECT [storeID], [employeeStatus], [roleID], [firstName], [middleInitial], " _
				& "	[lastName], [birthDate], [email], [deductTimeForBreaks], " _
				& " [standardBreakBasedMinutes], [standardBreakDeductionMinutes], "_
				& " [lunchBreakBasedMinutes], [lunchBreakDeductionMinutes], [accessCode], " _
				& " [employeepassword], [linesOfHistory], [createdDate], [createdEmployeeID], [MustBeClockedIn]," _
				& " [MessageAccount], [HourlyWage], [assignedID], [empDeptID], [phone] FROM Employee where employeeid =  " & l_employeeid
	set rstEmp = GetDisconnectedRecordset(sqltxt)
	
	if not rstEmp.bof and not rstEmp.Eof then
		l_Status = rstEmp("employeeStatus")
		l_firstname = rstEmp("firstName")
		l_lastName = rstEmp("lastName")
		l_email = rstEmp("email")
		l_emproleid = rstEmp("roleID")
		l_deduct = rstEmp("deductTimeForBreaks")
		l_passwd = rstEmp("employeepassword")		
		l_Sbreak =  rstEmp("standardBreakBasedMinutes")
		l_SDeduct = rstEmp("standardBreakDeductionMinutes")
		l_LBreak = rstEmp("lunchBreakBasedMinutes")
		L_LDeduct = rstEmp("lunchBreakDeductionMinutes")
		l_mustBeClockedIn = rstEmp("MustBeClockedIn")
		l_messageid = rstEmp("MessageAccount")
		if not isnull(rstEmp("HourlyWage")) then l_hourlywage = rstEmp("HourlyWage") 
		l_assignedID = rstEmp("assignedID")
		l_empDeptID = rstEmp("empDeptID")
		l_phone = rstEmp("phone")
	end if
	
	rstEmp.close
	set rstEmp = nothing
	
	end function

	dim rstRoles
	
	Function getEmpRoles()
	dim sqltxt 
	
		sqltxt = "Select distinct employeetag.name as EmployeeRoleName from employeetag inner join employeetagassignment on employeetag.id = employeetagassignment.tagid where employeetagassignment.terminalid = " & session("terminalid") 
	
		if session("setupEmployeeid") = "" then
			sqltxt = sqltxt & " and employeetagassignment.employeeid = -1"
		else
			sqltxt = sqltxt & " and employeetagassignment.employeeid = " & session("setupEmployeeid")
		end if
		
		set rstRoles = GetDisconnectedRecordset(sqltxt)
	end function
	
	Function UpdateDatabase()
	dim sqltxt
	dim l_mode
	dim l_managerid
	DIM l_employeeid 
	dim rstPassword
	l_employeeid  = session("setupEmployeeid")
	dim realPhone

	realPhone = replace(Request.form("txtMainAreacode"),  "(","") & replace(Request.form("txtMainPhone"), "-","")
	realPhone = trim(replace(realPhone, ")",""))



		
	l_managerid = session("employeeid")
	
	L_mode = Request.Form("targetpage")
	
	actionstring = l_mode
	
	if l_mode = "edit" then
			sqltxt = "select  employeeid from employee where employeepassword = '" & request.Form("txtEmpPasswd") & "'" _
						& " and employeeid <> " &  L_employeeid 
	else  
			sqltxt = "select  employeeid from employee where employeepassword = '" & request.Form("txtEmpPasswd") & "'"
	end if
						
	set rstpassword = getdisconnectedrecordset(sqltxt)
	if rstpassword.recordcount > 0 then
		L_error = "Could not change password. Please use a different password"
		rstpassword.close
		set rstpassword = nothing
		exit function
	end if
	rstpassword.close
	set rstpassword = nothing
	
	
	if l_mode = "edit" then
		
			
		sqltxt = "Update employee set " _
					& "  firstName=" & dbcreateQryString(request.Form("txtEmpfirstName"))_
					& ", lastName=" & dbcreateQryString(request.Form("txtEmplastName")) _
					& ", email=" & dbcreateQryString(request.Form("txtemail"))_
					& ", employeepassword='" & request.Form("txtEmpPasswd") & "'" _
					& ", deductTimeForBreaks=" & evalRequestValue(request.Form("deductTime")) _
					& ", standardBreakBasedMinutes=" & CalcuateBreakTime(request.Form("StdBreaksHours"),request.Form("StdBreaksMin"))_
					& ", standardBreakDeductionMinutes=" & CalcuateBreakTime(request.Form("DeductBreaksHours"),request.Form("DeductBreaksMin"))_
					& ", lunchBreakBasedMinutes=" & CalcuateBreakTime(request.Form("StdLunchHours"),request.Form("StdLunchMin")) _
					& ", lunchBreakDeductionMinutes=" & CalcuateBreakTime(request.Form("DeductLunchHours"),request.Form("DeductLunchMin" )) _
					& ", MustBeClockedIn=" & evalRequestValue(request.Form("MustBeClockedIn")) _
					& ", MessageAccount=" & dbcreateQryString(request.Form("MessageID")) _
					& ", HourlyWage=" & DbCreateQryNumeric(request.Form("HourlyWage")) _
					& ", assignedID=" & evalRequestValue(Request.Form("assignedID")) _
					& ", empDeptID=" & dbcreateQryString(Request.Form("selectdept")) _
					& ", phone=" & dbcreateQryString(realPhone) _
					& " where employeeid = " & L_employeeid 
					'Response.Write sqltxt
		dbstartTrans()
		qryexecutewithtrans(sqltxt)
		dbEndTrans()
		Response.Redirect(Request.QueryString("useraction")& "?useraction=editEmployee")
	
		
	elseif l_mode = "add" then
	
		sqltxt = " set nocount on;INSERT INTO [Employee]( [storeID], [employeeStatus], [roleID], "_
					& " [firstName], [middleInitial], [lastName], [birthDate], [email], "_
					& "	[deductTimeForBreaks], [standardBreakBasedMinutes], [standardBreakDeductionMinutes],"_
					& " [lunchBreakBasedMinutes], [lunchBreakDeductionMinutes], [accessCode], "_
					& "[employeepassword], [linesOfHistory], [createdDate], [createdEmployeeID], [MustBeClockedIn], [HourlyWage], " _
					& "[assignedID], [empDeptID], [phone]) VALUES( "_
					& l_storeid _
					& "," & "'A', '1'" _
					& "," & dbcreateQryString(request.Form("txtEmpfirstName")) _
					& "," & "''" _
					& "," & dbcreateQryString(request.Form("txtEmplastName")) _
					& "," & "NULL" _
					& "," & dbcreateQryString(request.Form("txtemail"))_
					& "," & evalRequestValue(request.Form("deductTime")) _
					& "," & CalcuateBreakTime(request.Form("StdBreaksHours"),request.Form("StdBreaksMin"))_
					& "," & CalcuateBreakTime(request.Form("DeductBreaksHours"),request.Form("DeductBreaksMin"))_
					& "," & CalcuateBreakTime(request.Form("StdLunchHours"),request.Form("StdLunchMin")) _
					& "," & CalcuateBreakTime(request.Form("DeductLunchHours"),request.Form("DeductLunchMin" )) _
					& "," & "NULL" _
					& ",'" & request.Form("txtEmpPasswd") & "'" _
					& "," & "NULL" _
					& "," & "getdate()" _
					& "," & l_managerid _
					& "," & evalRequestValue(request.Form("MustBeClockedIn")) _
					& "," & DbCreateQryNumeric(request.Form("HourlyWage")) _
					& "," & evalRequestValue(Request.Form("assignedID")) _
					& "," & dbcreateQryString(Request.Form("selectdept")) _
					& "," & dbcreateQryString(realPhone) _
					& ");select scope_identity();set nocount off"
						
		dbstartTrans()
		'Response.write sqltxt
		session("setupEmployeeid") = qryexecutewithtransandselect(sqltxt)
		
		dbEndTrans()
		Response.Redirect(Request.QueryString("useraction"))
	end if
	
	end function
	
	function CalcuateBreakTime(vhour, vmin)
		'Response.Write vhour
		'Response.Write vmin
		CalcuateBreakTime = 60 * vhour + vmin
		'Response.Write CalcuateBreakTime
	end function
%>
