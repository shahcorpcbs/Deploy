<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim isSubmitted 
	dim rstSearch
	dim enableLotTags
	dim query, rs
	
	enableLotTags = isLotTagsEnabled()
	
	isSubmitted = Request.QueryString("submitted")
	
	if (isSubmitted)  then
		if trim(Request.Form("txtTagNo") <> "") then
			doSearch()
		end if 
	end if
	
	
	function isLotTagsEnabled()
		dim query, rs
		
		query = " select enablelottags from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			isLotTagsEnabled = rs("enablelottags")
		end if
		
		set rs = nothing
	end function
%>

<HTML>
<HEAD>
<TITLE>Tag Search</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script LANGUAGE="JavaScript">

	function validateForm() {
		returnValue = true;
		var tagNumber
		
		tagNumber = document.tagSearchForm.txtTagNo.value;
		if (!checkFieldMissing(tagNumber)) {
			returnValue = false;
			show_focus("Tag Number can not be blank", "Tag Number Number", document.tagSearchForm.txtTagNo)
			return returnValue;
		}
		return returnValue;
	}
	
	function submitForm(){
		if (validateForm()) {
			document.tagSearchForm.action = "?submitted=true"
			document.tagSearchForm.submit();
		}
	}
	
	function cancelForm(){
		document.tagSearchForm.action = "toolsMenu.asp"
		document.tagSearchForm.submit();
	}
	
	function moveFocus(obj) {
	<% if enableLotTags then %>
		if (event.keyCode == 13){
			if(obj.name == "txtLotNo") {

				document.tagSearchForm.txtTagNo.focus();
				document.tagSearchForm.txtTagNo.select();
			}
		}
	<% end if %>
	}
	
	
	function focusOnLoad() {
	<% if enableLotTags then %>
		document.tagSearchForm.txtLotNo.focus();
		document.tagSearchForm.txtLotNo.select();
	<% else %>
		document.tagSearchForm.txtTagNo.focus();
		document.tagSearchForm.txtTagNo.select();
	<% end if %>
	}
	
	function checkSubmit(obj) {
		if (event.keyCode == 13){
			submitForm();
		}
	}
	
	function SmartSearch(msg) {
		document.tagSearchForm.action = "/mainapp/searchresults.asp?targetpage=CustomerFunctions&smartsearch=" + msg;
		document.tagSearchForm.submit();
	}
</script>
<BODY topmargin=0 leftmargin=0 onload="focusOnLoad();">

<!-- #include file="../include/banner.inc" -->
<FORM id="tagSearchForm" name="tagSearchForm" action="" method="Post">

<table>
	<tr>
		<% if enableLotTags then %>
		<td>
			Lot<br />
			<INPUT name="txtLotNo"  value="<%=Request.Form("txtLotNo")%>" onkeyup="moveFocus(this)">
		</td>
		<% end if %>
		
		<td>
			Tag<br />
			<INPUT name="txtTagNo" onkeyup="checkSubmit()" value="<%=Request.Form("txtTagNo")%>">
		</td>
		
		<td>
			Color<br />
			<SELECT name="colorFilter">
				<OPTION value="" <%if Request.Form("colorFilter") = "" then%>selected<%end if%>>Any</OPTION>
<%
				query = " select name from lotcolor order by sequenceorder"
				set rs = getdisconnectedrecordset(query)
				
				while not (rs.eof or rs.bof)
%>
				<OPTION value="<%=rs("name")%>" <%if Request.Form("colorFilter") = rs("name") then%>selected<%end if%>><%=rs("name")%></OPTION>
<%
					rs.movenext
				wend
				set rs = nothing
%>
			</SELECT>
		</td>
		
		<td>
			Start Date<br />
			<input style="width:80px" value="<%=Request.Form("ticketStartDate")%>" onClick="javascript:show_calendar('tagSearchForm.ticketStartDate');" name="ticketStartDate" />
		</td>

		<td>
			End Date<br />
			<input style="width:80px" value="<%=Request.Form("ticketEndDate")%>" onClick="javascript:show_calendar('tagSearchForm.ticketEndDate');" name="ticketEndDate" />
		</td>

		
		<td style="width:150px;" align="right">
			<input type="button" style="width:100px;height:50px" value="Search" onclick="submitForm()" />
		</td>
	</tr>
</table>
			
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="cancelForm()">Exit</BUTTON>
	</SPAN>
</DIV>	
			
<TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 class="itable">
	<tr>
		<% if enableLotTags then %>
		<th align=left class="label">Lot Number</th>
		<% end if %>
		
		<th align=left class="label">Tag Number</th>
		<th align=left class="label">Invoice Number</th>
		<th align=left class="label">Creation Date</th>
		<th align=left class="label">Invoice Status</th>
		<th align=left class="label">Customer Name</th>
		<th align=left class="label">Department</th>
		<th align=left class="label">Due Date</th>
		<th></th>
	</tr>
	
	<% if isobject(rstSearch) then 
		if rstSearch.recordcount > 0 then
			while not rstSearch.eof
	%>
	<tr onclick="javascript:SmartSearch('<%=rstSearch("invoicenumber")%>')" style="cursor:pointer" >
	<% if enableLotTags then %>
	<td align=left ><%=rstSearch("lotnumber")%></td>
	<% end if %>
	<td align=left ><%=rstSearch("tagnumber")%></td>
	<td align=left ><%=rstSearch("invoicenumber")%></td>
	<td align=left ><%=rstSearch("createddate")%></td>
	<td align=left ><%=rstSearch("ticketstatus")%></td>
	<td align=left ><%=rstSearch("customername")%></td>
	<td align=left ><%=rstSearch("departmentName")%></td>
	<td align=left ><%=rstSearch("duedate")%></td>
	</tr>
	<%
		 rstSearch.movenext
		 wend
		 end if
		 rstSearch.close
		 set rstSearch = nothing
		end if
	%>
</TABLE> <!-- table for border -->


</FORM>

</BODY>
</HTML>
<%

	function doSearch()
		dim sqltxt
		dim colorFilter
		dim ticketStartDate
		dim ticketEndDate
		
		sqltxt = " SELECT DISTINCT "
		sqltxt = sqltxt & " g.tagNumber, t.invoiceNumber, t.createdDate, c.customerName, g.lotNumber, "
		sqltxt = sqltxt & " CASE ticketstatus WHEN 'AC' THEN 'Active' WHEN 'FI' THEN 'Finished' WHEN 'VO' THEN 'Void' END AS 'TicketStatus', dbo.pivotTicketDepartments(g.ticketNumber, ', ') as departmentName, t.duedate "
		sqltxt = sqltxt & " FROM Ticket t INNER JOIN "
		sqltxt = sqltxt & " TicketTag g ON t.ticketNumber = g.ticketNumber INNER JOIN "
		sqltxt = sqltxt & " Customer c ON t.customerSequenceNumber = c.customerSequenceNumber "
		sqltxt = sqltxt & " WHERE (LTRIM(g.tagNumber) LIKE '" & DBStr(Request.Form("txtTagNo"))& "%') "

		colorFilter = Request.Form("colorFilter")
		ticketStartDate = Request.Form("ticketStartDate")
		ticketEndDate = Request.Form("ticketEndDate")
		
		if colorFilter <> "" then
			sqltxt = sqltxt & " AND tagColor = '" & DBStr(colorFilter) & "'"
		end if
		
		if ticketStartDate <> "" then
			sqltxt = sqltxt & " AND datediff(day, t.createdDate, '" & ticketStartDate & "') <= 0 "
		end if
		
		if ticketEndDate <> "" then
			sqltxt = sqltxt & " AND datediff(day, t.createdDate, '" & ticketEndDate & "') >= 0 "
		end if
		
		if enableLotTags and Request.Form("txtLotNo") <> "" then
		sqltxt = sqltxt & " AND (g.lotNumber = " & DBStr(Request.Form("txtLotNo")) & ") "
		end if
		
		sqltxt = sqltxt & " ORDER BY t.createdDate DESC "

		set rstSearch = getDisconnectedRecordset(sqltxt)
		
	end function
	

	
%>
