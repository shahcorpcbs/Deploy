<%@ Language=VBScript %>
<%option explicit%>
<%
	dim dbname
	
	dbname = request.querystring("dbname")
	if dbname = "" then dbname = "default"
%>

<!--#include file="../include/SystemStartup.asp"-->
<% selectDatabase dbname %>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->

<!-- #include file="../include/form_merge.asp" -->

<%




	dim query, rs
	dim SMTPServer
	dim SMTPPort
	dim SMTPUsername
	dim SMTPPassword
	dim SMTPAuthentication
	dim messageID
	
	messageID = request.querystring("messageID")
	
	if messageID <> "" then
		loadSMPTSettings
		if sendMarkedMessages(messageID, SMTPServer, SMTPPort, SMTPUsername, SMTPPassword) then
			returnResult 1, "Message sent"
		end if
		response.end
	else
		loadSMPTSettings
		sendAllOutgoing
		response.end
	end if

	function loadSMPTSettings()
		dim query, rs
		if session("storeid") <> "" then
			query = "select smtpaddress, smtpport, smtpusername, smtppassword, SMTPAuthentication from store where storeid = " & session("storeid")
		else
			query = "select smtpaddress, smtpport, smtpusername, smtppassword, SMTPAuthentication from store "
		end if
		set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
			SMTPServer = rs("smtpaddress")
			SMTPPort = rs("smtpport")
			SMTPUsername = rs("smtpusername")
			SMTPPassword = rs("smtppassword")
			SMTPAuthentication = rs("SMTPAuthentication")
		end if
	end function



	function sendAllOutgoing()
		dim query, rs
		dim counter
		
		query = " select messageid "
		query = query & " from emailqueue "
		query = query & " where (sentdate is null) "

		set rs = getdisconnectedrecordset(query)
		
		response.write "["
		
		counter = 1
		while not(rs.eof or rs.bof)
			if counter > 1 then
				response.write ","
			end if
			sendMarkedMessages rs("messageid"), SMTPServer, SMTPPort, SMTPUsername, SMTPPassword
			counter = counter + 1
			rs.movenext
		wend
		response.write "]"
		
		response.end
				
		set rs = nothing
	end function
	
	
	function addFieldParameter(fields, name, value)
		if fields.exists(name) then
			fields.remove name
		end if
		fields.add name, value
	end function

	function transformMessage(messageID, body)
		dim query, rs
		dim rs_f
		dim param_name
		dim fields
		dim i
		
		query = " select * from messageparam where messageid = " & messageID
		set rs = getdisconnectedrecordset(query)
		
		
		
		if rs.recordcount > 0 then
			set fields = server.createobject("scripting.dictionary")
		
			while not(rs.eof or rs.bof)
				param_name = rs("name")
				if left(param_name, 3) = "@@@" then
					addFieldParameter fields, mid(param_name, 4), rs("value")
				else
					select case lcase(rs("name"))
					case "employeeid"
						query = ""
					case "customerseq"
						query = " select * "
						query = query & " from customerfields where customersequencenumber = " & rs("value")
					case "ticketnumber"
						query = " select invoicenumber as [Invoice_Number], "
						query = query & " convert(varchar, createddate, 101) as [Invoice_Dropoff] "
						query = query & " from ticket where ticketnumber = " & rs("value")
					case else
						query = ""
					end select
					if query <> "" then
						set rs_f = getdisconnectedrecordset(query)
						if rs_f.recordcount > 0 then
						  for i = 0 to rs_f.Fields.Count - 1
						  	if not isnull(rs_f.Fields(i).Value) then
								addFieldParameter fields, rs_f.Fields(i).Name, rs_f.Fields(i).Value
						  	end if
						  next					
						end if
					end if
				end if
				
				rs.movenext
			wend
			
			dim form_params
			set form_params = getFormParams(body)
			transformMessage = transformQuery(body, form_params, fields)
		else
			transformMessage = body
		end if
	end function
	


	
	function sendMarkedMessages(messageID, SMTPServer, SMTPPort, SMTPUsername, SMTPPassword)
		dim query, rs
		dim addressFrom
		dim addressTo
		dim subject
		dim body

		query = "SET TEXTSIZE 2147483647; select toaddress, fromaddress, isnull(subjectline, '') as subjectline, isnull(bodytext, '') as bodytext from emailqueue where messageID = " & messageID
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			addressFrom = rs("fromaddress")
			addressTo = rs("toaddress")
			subject = rs("subjectline")
			body = transformMessage(messageID, rs("bodytext"))
			if sendEmail(SMTPServer, SMTPPort, SMTPUsername, SMTPPassword, addressFrom, addressTo, subject, body) then
				markMessageSent messageID
				sendMarkedMessages = true
			else
				returnResult 0, Err.Description
				sendMarkedMessages = false
			end if
		end if

	end function



	
	function markMessageSent(messageID)
		dim query, rs
		
		query = " update emailqueue set sentdate = getdate() where messageid = " & messageID

		qryexecute query
	end function





	
	function sendEmail(SMTPServer, SMTPPort, SMTPUsername, SMTPPassword, addressFrom, addressTo, subject, body)
		dim objEmail
		on error resume next
		set objEmail = Server.CreateObject("CDO.Message")
		objEmail.From = addressFrom
		objEmail.To = addressTo
		objEmail.Subject = subject
		objEmail.HTMLBody = body
		objEmail.Configuration.Fields.Item _
		    ("http://schemas.microsoft.com/cdo/configuration/sendusing") = 2
		    
		if SMTPUsername <> "" then
			if SMTPAuthentication = 0 then
				objEmail.Configuration.Fields.Item _
				("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 1
			elseif SMTPAuthentication = 1 then
				objEmail.Configuration.Fields.Item _
				("http://schemas.microsoft.com/cdo/configuration/smtpusessl") = true
				objEmail.Configuration.Fields.Item _
				("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 1
			elseif SMTPAuthentication = 2 then
				objEmail.Configuration.Fields.Item _
				("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 0
			elseif SMTPAuthentication = 3 then
				objEmail.Configuration.Fields.Item _
				("http://schemas.microsoft.com/cdo/configuration/smtpusessl") = true
				objEmail.Configuration.Fields.Item _
				("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 0
			end if

			objEmail.Configuration.Fields.Item _
			("http://schemas.microsoft.com/cdo/configuration/sendusername") = SMTPUsername
			objEmail.Configuration.Fields.Item _
			("http://schemas.microsoft.com/cdo/configuration/sendpassword") = SMTPPassword
		else
			objEmail.Configuration.Fields.Item _
			("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 0
		end if
		
		objEmail.Configuration.Fields.Item _
		    ("http://schemas.microsoft.com/cdo/configuration/smtpserver") = SMTPServer
		objEmail.Configuration.Fields.Item _
		    ("http://schemas.microsoft.com/cdo/configuration/smtpserverport") = SMTPPort
		objEmail.Configuration.Fields.Update
		objEmail.Send
		sendEmail = (Err.Number = 0)
	end function















	
	


	function JSEncode(s)
		if not isnull(s) then
			JSEncode = s
			JSEncode = Replace(JSEncode, "\", "\\") 
			JSEncode = Replace(JSEncode, """", "\""")
			JSEncode = Replace(JSEncode, vbCr, "\r")
			JSEncode = Replace(JSEncode, vbLf, "\n")
		end if
	end function 
	
	function returnResult(success, answer )
		response.write "{ "
		response.write """success"": """ & JSEncode(success) & """, "
		response.write """answer"": """ & JSEncode(answer) & """ "
		response.write "}"

	end function

%>
