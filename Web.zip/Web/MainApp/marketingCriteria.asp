<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<HTML>
<HEAD>
<TITLE>Choose Customer Dataset Menu</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		document.lookupListForm.submit();
	}
	
	function cancelForm(){
		document.lookupListForm.action="start2.asp";
		document.lookupListForm.submit();
	}	
	
	function useExistingCriteria(){
		document.lookupListForm.action ="criteriaList.asp";
		document.lookupListForm.submit();
	}
	
	function createNewCriteria(){
		document.lookupListForm.action ="createCriteria.asp";
		document.lookupListForm.submit();
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Choose Customer Dataset Menu</H1>
<FORM id="lookupListForm" name="lookupListForm" action="start2.asp" method="Post">
<CENTER>

	<TABLE ALIGN=center BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR height=50px><td></td>
		</TR>
		<TR>
			<TD>
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=accountMgmt onclick="createNewCriteria()"><!--<img src="">-->Create New Criteria</BUTTON>
			</TD>
		</TR>
		<TR>
			<TD>
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=inactiveCust onclick="useExistingCriteria()"><!--<img src="">-->Use Existing Criteria</button>
			</TD>	
		</TR>
		<TR height=100px>
			<TD align=center colspan=4>
				<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
			</TD>
		</TR>	
		
	</TABLE>

</CENTER>
</FORM>   

</BODY>
</HTML>