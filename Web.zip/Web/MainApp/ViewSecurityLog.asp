<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query
	dim rs
	dim useraction

	useraction = trim(Request.QueryString("useraction"))
%>
<HTML>
<HEAD>
<TITLE>Security Log</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">


	function viewLog() {
		document.slog.action = "?useraction=viewlog";
		document.slog.submit();
	}
	
	function cancelForm(){
		document.slog.action ="employeeManagement.asp";
		document.slog.submit();
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Security Log</H1>
<FORM id="slog" name="slog"  Method = "post">

<div style="color:black;width:95%;margin-left:5%;text-align:center;">

	Date range from
	<INPUT valign=top name=txtFromDate  readonly class=text style="HEIGHT: 25px; WIDTH: 130px" value="<%=Request.Form("txtFromDate")%>">
	<INPUT class=touch name=FromDate type=button value="" style="background-image:url(../images/calender.gif);width:25px;height:25px" onClick="javascript:show_calendar('slog.txtFromDate');">
	to
	<INPUT id=txtToDate name=txtToDate  readonly class=text style="HEIGHT: 25px; WIDTH: 130px" value="<%=Request.Form("txtToDate")%>">
	<INPUT class=touch name=ToDate type=button value="" style="background-image:url(../images/calender.gif);width:25px;height:25px" onClick="javascript:show_calendar('slog.txtToDate');">
	
	<br>
	
	<select name="lstEmployees" size="10" multiple style="width=450;font-size=16px" >
	<%
		query = "select * from employee order by employeename"
		set rs = getdisconnectedrecordset(query)
		
		while not (rs.eof or rs.bof)
	%>
		<option value=<%=rs("employeeid")%>><%=rs("employeeName")%></option>
	<%	
			rs.movenext
		wend
		set rs = nothing
		
	%>				
	</select>
	<select name="lstFunctions" size="10" multiple style="width=450;font-size=16px" >
	<%
		query = "select * from employeefunction order by name"
		set rs = getdisconnectedrecordset(query)
		
		while not (rs.eof or rs.bof)
	%>
		<option value=<%=rs("id")%>><%=rs("name")%></option>
	<%	
			rs.movenext
		wend
		set rs = nothing
		
	%>			
	</select>

	<br><br />
	<!--input type=button style="width:200;height:50;" value="View Log" onclick="viewLog()">
	<input type=button style="width:200;height:50;" value="Cancel" onclick="cancelForm()" -->
	<input class="touch" id="select" name="select" type="button" value="View Log"  onclick="viewLog()">
	<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()"></td></tr>
	<br>
	<%
		dim empFilter, fnFilter, trFilter
		
		if useraction = "viewlog" then
			query = "select sl.*, ef.name as efname, e.employeename from securitylog sl, employeefunction ef, employee e where ef.location = sl.location and ef.action = sl.action and sl.employeeid = e.employeeid"
		
			empFilter = makeEmployeeFilter()
			fnFilter = makeFunctionFilter()
			trFilter = makeTimeRangeFilter()
			
			if empFilter <> "" then
				query = query & " AND (" & empFilter & ") "
			end if
		
			if fnFilter <> "" then
				query = query & " AND (" & fnFilter & ") "
			end if

			if trFilter <> "" then
				query = query & " AND (" & trFilter & ") "
			end if
			
			query = query & " ORDER BY sl.date DESC"
			
			set rs = getdisconnectedrecordset(query)

	%>
			<table style="border:1px solid gray;width:900px;" cellpadding=2 border=1>
				<tr>
					<th>Employee</th>
					<th>Time</th>
					<th>Function</th>
					<th>Result</th>
				</tr>
	<%
			while not (rs.eof or rs.bof)
				dim actionDenied
				
				actionDenied = InStr(rs("result"), "Denied")

	%>
				<tr <%if actionDenied then%>style="background:red;color:white;"<%end if%>>
					<td><%=rs("employeename")%></td>
					<td><%=rs("date")%></td>
					<td><%=rs("efname")%></td>
					<td><%=rs("result")%></td>
				</tr>
	<%
			
				rs.movenext
			wend

	%>
			</table>
	<%
			set rs = nothing
		end if
	%>
	
	
</div>

</FORM>
</BODY>
</HTML>

<%
	function makeEmployeeFilter()
		dim count
		dim filter
		dim i
		
		count = clng(Request.Form("lstEmployees").count)
		
		if count > 0 then
			filter = " sl.employeeID IN ('" & Request.Form("lstEmployees")(1) & "'"
					
			for i = 2 to count	
				filter = filter & ",'" & Request.Form("lstEmployees")(i) & "'"
			next
			
			filter = filter & ")"
		else
			filter = ""
		end if
		makeEmployeeFilter = filter
	end function
	
	function makeFunctionFilter()
		dim count
		dim filter
		dim i
		
		count = clng(Request.Form("lstFunctions").count)
		
		if count > 0 then
			filter = " ef.id IN ('" & Request.Form("lstFunctions")(1) & "'"
					
			for i = 2 to count	
				filter = filter & ",'" & Request.Form("lstFunctions")(i) & "'"
			next
			
			filter = filter & ")"
		else
			filter = ""
		end if
		
		makeFunctionFilter = filter
	end function
	
	function makeTimeRangeFilter()
		dim rStart, rEnd
		dim result
		
		rStart = Request.Form("txtFromDate")
		rEnd = Request.Form("txtToDate")
		
		if rStart <> "" then
			result = "sl.date >= '" & rStart & "'"
		end if
		
		if rEnd <> "" then
			if result <> "" then
				result = result & " AND "
			end if
			result = result & "sl.date <= dateadd(dd, 1, convert(datetime, '" & rEnd & "'))"
		end if
		
		makeTimeRangeFilter = result
	end function

%>
