<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim isSubmitted 
	
		isSubmitted = Request.QueryString("submitted")
		if isSubmitted then
			if Request.QueryString("userAction") ="add" then
				updatedatabase()
				Response.Redirect("purchasing.asp")
			else
				getSaleQty()
			end if
		end if
		
	
	getsalesInventory()
%>

<HTML>
<HEAD>
<TITLE>Purchasing</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function submitForm(useraction){
		//alert(document.purchasing.inventoryItems.selectedIndex)
		if (document.purchasing.inventoryItems.length > 0 ){
			document.purchasing.action="?Submitted=true&userAction=" + useraction;
			document.purchasing.submit();	
		}
	}
	
	function validateQty(element){
		if ( !checkInt(element.value)){
			cbs_alert("Please enter a Numeric value ");
			element.focus();
		}
	}
	function cancelForm(){
		document.purchasing.action="managerMenu.asp";
		document.purchasing.submit();	
	}
	
	function enableButton(){
		if (document.purchasing.inventoryItems.length > 0 )  
			document.purchasing.okButton.disabled = false;
		else	
			document.purchasing.okButton.disabled = true;
		
	
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0 onload = "enableButton()">
<!-- #include file="../include/banner.inc" -->
<H1>Purchasing</H1>
<FORM id="purchasing" name="purchasing" action="" method="post">
	<TABLE ALIGN=center WIDTH="500px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px></tr>
		<tr>
			<td class="label">Inventory Items</td>
			<td>
				<select id=inventoryItems name=inventoryItems style="width:200px;" onChange ="submitForm('qty')">
				<% if rstSales.recordcount > 0 then
					while not rstSales.eof
				%>
					<option
				<%	if trim(l_priceitemid) = trim(rstSales("pricelistitemid")) then %>
						SELECTED
				<%end if %>	
					value= "<%=rstSales("pricelistitemid")%>"><%=rstSales("itemname")%></option>
				<% rstsales.movenext
					wend
					RstSales.close
					set rstsales = nothing
					end if
				%>
				</select>
			</td>
			<td class="label">Quantity</td>
			<td>
				<INPUT id=txtQuantity name=txtQuantity class=text style="WIDTH: 75px" onblur = "validateQty(this)">
			</td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td class="label">In Stock</td>
			<td>
				<INPUT id=txtStock name=txtStock class=text style="WIDTH: 75px" readonly value="<%=g_qty%>">
			</td>
		</tr>
		<tr height=30px></tr>
		<tr>
			<td></td>
			<TD>
				<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center> 
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick= "submitForm('add')">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton style="background-image:url(../images/Cancel.gif)" type=button value="" onClick="cancelForm()">
						</TD>
					</tr>
				</table>
			</TD>	
		</tr>
	</table>
</form>
</BODY>
</HTML>
<%
	dim rstSales
	dim g_qty
	dim l_priceitemid
	
	function getSaleQty()
	dim sqltxt
	dim l_itemid
	dim rstTemp
	
		l_itemid = Request.Form("inventoryItems")
		if len(trim(l_itemid)) = 0 then
			l_itemid = l_priceitemid
		end if
		l_priceitemid = l_itemid
		sqltxt = "select isnull(InventoryQuantity , 0) as 'InventoryQuantity' from pricelistitem  where pricelistitemid =" & l_itemid
		'Response.Write sqltxt
		set rstTemp = getdisconnectedrecordset(sqltxt)
		if rstTemp.recordcount > 0 then
			g_qty = rstTemp("InventoryQuantity")
			rstTemp.close
			set rstTemp = nothing
		end if
		'Response.Write "cccc"
	'Response.Write g_qty
	end function
	
	function getsalesInventory()
	dim sqltxt
		sqltxt = "Select pricelistitemid, itemname from pricelistitem where saleonly = 1" 
		
		l_priceitemid = Request.Form("inventoryItems")
		
		set rstSales = getdisconnectedrecordset(sqltxt)
		if rstSales.recordcount > 0 then
			if l_priceitemid = "" then
				l_priceitemid = rstsales("pricelistitemid")
			end if
			getSaleQty()
			rstsales.movefirst
		end if
	end function


	function updatedatabase()
	dim sqltxt
	dim l_itemid
	dim l_qty
	
		l_itemid = trim(Request.Form("inventoryItems"))
		l_priceitemid = l_itemid
		l_qty = Request.Form("txtQuantity")
		if  len(trim(l_qty)) = 0 then
			l_qty = 0
		end if
		sqltxt = "update pricelistitem set InventoryQuantity = isnull(InventoryQuantity , 0) + " & l_qty & " where pricelistitemid =" & l_itemid
		'Response.Write sqltxt
		dbstarttrans()
		qryexecutewithtrans(sqltxt)
		dbendtrans()
	end function
%>
