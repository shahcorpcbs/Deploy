<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>

<%
	'****************************************
	'Name   :Garment Search
    'Author : Poonam Gupta
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 20-Sept-2002	Poonam			Original Version
	'*****************************************************************
		
	const maxItemsCount = 29
	const maxSubItemCount = 7
	const maxCouponsCount =12
	const maxDeptCount =4
	dim invoice
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim actionString
	dim selectedDept
	dim storeId
	dim curr_LineNo
	dim selItemId
	dim selUpchargeValue, selPatternValue, selColorValue
	dim originatingPage
	dim custPriceList
	dim alertMessage
			
	alertMessage = ""
	storeId = Session("storeId")
	custPriceList = Session("priceList")
	'custPriceList = 1
	actionString = Request.QueryString("userAction")
	setStartIndexForPaging
	selectedDept = Request.Form("selectedDept")
	curr_LineNo = Request.Form("lineNumber")
	selItemId = Request.Form("selItemId")
	selUpchargeValue = Request.Form("selUpcharge")
	selColorValue = Request.Form("selColor")
	selPatternValue = Request.Form("selPattern")
	originatingPage = Request.Form("originPage")
	Select case actionString 
			case "create"
						set invoice = Server.CreateObject("ShahCorpComponents.garmentSearch")
						invoice.DBConnectionString = Session("shahcorpDSN")
						set Session("gsinvoice") = invoice
						initialize
			case "getItemDetails"
						getItemDetails	
			case "changeQuantity"
						changeQuantity
					
			case "deleteItem"
						deleteItem
			case "clearInvoice"
					set invoice = Session("gsinvoice")
					invoice.clearInvoice
			case "getCommonItems"
						set invoice = Session("gsinvoice")
						getCommonItems
			case "addUpcharge"
							addUpCharge
			case "addColor"
							addColor
			
			case "addPattern"
							addPattern
			case "changeDept"
						set invoice = Session("gsinvoice")
						selectedDept = Request.Form("selectedDept")
						getItemsForDept
			case "nextPage"					
					set invoice = Session("gsinvoice")
			
			case "getSubItems"
				getSubItems
				
			case "done"
				Response.Redirect "garmentsearchresults.asp"
			
			case "cancel"
					set Session("gsinvoice") = nothing
					set invoice = nothing
					Response.Redirect "garmentsearch1.asp"
	end select
	
	' functions start here
	
	sub searchItems()
		set invoice = Session("gsinvoice")
	end sub
	
	sub getSubItems()
		dim lineNo
		dim itemId
		set invoice = Session("gsinvoice")
		lineNo = Request.QueryString("lineNo")
		curr_LineNo = lineNo
		itemId = invoice.getItemIdForLineNo(lineNo)
		if itemId <> -1 then
			getDistinctUpcharges itemId
			getDistinctColors itemId
			getDistinctPatterns itemId
			selUpchargeValue = ""
			selPatternValue = ""
			selColorValue =""	
		end if
	end sub
	
		
	sub initialize()
		curr_LineNo = ""
		selectedDept =-1
		selItemId =-1
		selUpchargeValue = ""
		selPatternValue = ""
		selColorValue =""
		invoice.priceListId = custPriceList
		getCommonItems
		getAllDepartments
	end sub
	
	sub deleteItem()
		dim selLineNo
		on error resume next
		selLineNo = Request.QueryString("itemId")
		set invoice = Session("gsinvoice")
		invoice.deleteItem selLineNo
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice deleteItem"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub
	
	sub changeQuantity()
		dim quantity
		dim selLineNo
		on error resume next
		selLineNo = Request.QueryString("itemId")
		quantity = Request.QueryString("quantity")
		set invoice = Session("gsinvoice")
		invoice.changeQuantity quantity, selLineNo
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice changeQuantity"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub
	
	sub addUpCharge()
		dim quantity
		
		on error resume next
		selUpchargeValue = Request.QueryString("upchargeid")
		quantity = Request.QueryString("quantity")
		set invoice = Session("gsinvoice")
		invoice.addUpcharge curr_LineNo, selUpchargeValue, quantity
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice addUpCharge"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub
	
	sub addColor()
		dim quantity
		
		on error resume next
		selColorValue= Request.QueryString("colorid")
		quantity = Request.QueryString("quantity")
		set invoice = Session("gsinvoice")
		invoice.addColor curr_LineNo, selColorValue, quantity
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice addColor"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub
	
	sub addPattern()
		dim quantity
		
		on error resume next
		selPatternValue= Request.QueryString("patternid")
		quantity = Request.QueryString("quantity")
		set invoice = Session("gsinvoice")
		invoice.addPattern curr_LineNo, selPatternValue, quantity
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice addPattern"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	end sub
	
	sub getItemDetails()		
		dim groupSimilarItems
		dim quantity
		on error resume next	
		selItemId = Request.QueryString("itemId")
		quantity = Request.QueryString("quantity")
		set invoice = Session("gsinvoice")		
		curr_LineNo = invoice.addItem (selItemId, quantity)
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Detailed Invoice getItemDetails"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		getDistinctUpcharges selItemId
		getDistinctColors selItemId
		getDistinctPatterns selItemId		
		selUpchargeValue = ""
		selPatternValue = ""
		selColorValue =""
	end sub
	
	sub setStartIndexForPaging()
		upChargeStartIndex = Request.Form("upChargePageCount")
		patternStartIndex = Request.Form("patternPageCount")
		colorsStartIndex = Request.Form("colorsPageCount")
		itemsStartIndex = Request.Form("ItemPageCount")
		deptStartIndex = Request.Form("DeptPageCount")
		if(IsEmpty(upChargeStartIndex)) OR upChargeStartIndex =0 then
			upChargeStartIndex=1
		else
			upChargeStartIndex=Int(upChargeStartIndex)
			
		end if
		if(IsEmpty(patternStartIndex)) Or patternStartIndex=0 then
			patternStartIndex=1
		else
			patternStartIndex=Int(patternStartIndex)
		end if
		if(IsEmpty(colorsStartIndex)) Or colorsStartIndex=0 then
			colorsStartIndex=1
		else
			colorsStartIndex=Int(colorsStartIndex)
		end if
		if(IsEmpty(itemsStartIndex)) Or itemsStartIndex=0 then
			itemsStartIndex=1
		else
			itemsStartIndex=Int(itemsStartIndex)
		end if
		if(IsEmpty(deptStartIndex)) Or deptStartIndex=0 then
			deptStartIndex=1
		else
			deptStartIndex=Int(deptStartIndex)
		end if
	end sub
	
	
	sub getItemsForDept()
		dim ssql
		dim itemsRst
		ssql = "select priceListItemID, itemName, price, imageFileName from PriceListItem where departmentID=" _
				& clng(selectedDept) & " AND priceListID=" & clng(custPriceList) _
				& " AND disabled=0 Order by displaySequence"
		set itemsRst = getDisconnectedRecordset(ssql)
		if itemsRst.Recordcount > 0 then
			itemsRst.PageSize = maxItemsCount
		end if
		Set Session("ItemsToBeShown")= itemsRst
		selItemId =-1
		selUpchargeValue =""
		selColorValue = ""
		selPatternValue =""
	end sub
			
	sub getCommonItems()
		dim commResultSet
		dim ssql
		ssql ="Select priceListItemID, itemName, price, imageFileName From PriceListItem Where " _
			  & " commonItem=1 AND disabled =0 AND priceListId =" & clng(custPriceList) _
			  & " Order by displaySequence"
		set commResultSet = getDisconnectedRecordset(ssql)
		if commResultSet.Recordcount > 0 then
			commResultSet.PageSize = maxItemsCount
		end if
		Set Session("ItemsToBeShown")= commResultSet
	End sub
	
	
	
	sub getAllDepartments()
		dim ssql
		dim objResultSet
		ssql = "Select departmentID, name, splitInvoice, imageFileName from Department where " _
				& " storeId =" & clng(storeId) & " AND disabled=0 " _
				& " And priceListId=" & clng(custPriceList) _
				& " And name <> 'SpecialOffers' " _
				& " Order by displaySequence" 
		Set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.RecordCount > 0 then
			objResultSet.PageSize = maxDeptCount
		end if
		set Session("departmentMaster") = objResultSet
	end sub
	
	sub getDistinctUpcharges(selItemId)
        dim ssql
        dim upChargeRst
        ssql ="Select descriptorName, price, imageFileName From itemDescriptorPrice where descriptorType='UP' " _
				& " AND priceListItemId =" & clng(selItemId) _
				& " AND disabled=0  Order by displaySequence"
		set upChargeRst = getDisconnectedRecordset(ssql)
        upChargeRst.PageSize = maxSubItemCount
		Set Session("upcharges")= upChargeRst
    End sub
	
	sub getDistinctColors(selItemId)
        dim ssql
        dim colorsRst
        ssql ="Select descriptorName, imageFileName From itemDescriptorPrice where descriptorType='CO' " _
				& " AND priceListItemId =" & clng(selItemId) _
				& " AND disabled=0  Order by displaySequence"
		set colorsRst = getDisconnectedRecordset(ssql)
		colorsRst.PageSize = maxSubItemCount
		Set Session("colors")= colorsRst
	End sub
    
	sub getDistinctPatterns(selItemId)
		dim ssql
		dim patternRst
        ssql ="Select descriptorName, imageFileName From itemDescriptorPrice where descriptorType='PA' " _
				& " AND priceListItemId =" & clng(selItemId) _
				& " AND disabled=0  Order by displaySequence"
        set patternRst = getDisconnectedRecordset(ssql)
        patternRst.PageSize = maxSubItemCount
		Set Session("patterns")= patternRst
	End sub
    
%>
<HTML>
<HEAD>
<TITLE>Detailed Invoice</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
	var lastFocusControl;
function txtAmountEntered_onblur() {
	lastFocusControl = event.srcElement;
}
	
//-->
</SCRIPT>
</HEAD>
<script language="JavaScript" src="../script/date-picker.js"></script>
<script language="javascript" type="text/javascript">
	var previousElement=null;
	var alertMessage = null;	
	
	function submitForm() {
		var itemCount;
		
		itemCount = document.garmentSearch1.txtTotal.value;
		if (itemCount > 0) {
			document.garmentSearch1.action= document.garmentSearch1.action + "?userAction=done";
			document.garmentSearch1.submit();
		}else{
			cbs_alert("Must have at least a servicable item on the invoice.")
		}
		
	}
		
	
	function selectRow(element) {
		var childEl;
		var lineNo;
		var currentLineNo;
		var submit;
		if (previousElement == null){
			deselectSelectedRow();
		} else{
			previousElement.style.background="white";
		}
		if (element.name == "main"){
			childEl = element.children[0];
		}
		else {
			childEl = element.children[1];
		}
		var rowChildNodes = childEl.children
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if(childEl.tagName == "INPUT") {
				childEl.checked=true;
				break;
			}
		}
		previousElement =element;
		//element.style.background="#DBF2F4";
		element.style.background="#C2DACD";
		if (element.title == "IT") {
			document.garmentSearch1.upChargePageCount.value = eval(0);
			document.garmentSearch1.colorsPageCount.value = eval(0);
			document.garmentSearch1.PatternPageCount.value = eval(0);
			if(childEl.tagName == "INPUT"){
				if (invoiceTable.rows.length > 0) {
					if(invoiceTable.rows.length ==1) 
					{
						if(document.garmentSearch1.select.checked) {
							lineNo = document.garmentSearch1.select.value;
						}
					}
					else{
						for (var i = 0; i < document.garmentSearch1.select.length; i++) {
							if(document.garmentSearch1.select[i].checked){
								lineNo = document.garmentSearch1.select[i].value;
								break;
							}
						}
					}
				}
				document.garmentSearch1.action = "?userAction=getSubItems&lineNo=" + lineNo;
				document.garmentSearch1.submit();
			}
		}
	}
	
	function deselectSelectedRow() {
		var currLineNo;
		var i
		currLineNo = document.garmentSearch1.lineNumber.value;
		if (currLineNo.length > 0) {
			for(var i=0; i<invoiceTable.rows.length; i++){
				invoiceTable.rows[i].style.background =	"white";
			}
		}
	}
	
	function getItemDetails(element) {
		var itemId
		var itemName
		var price
		var quantity = document.garmentSearch1.txtAmountEntered.value;
		
		document.garmentSearch1.upChargePageCount.value = eval(0);
		document.garmentSearch1.colorsPageCount.value = eval(0);
		document.garmentSearch1.PatternPageCount.value = eval(0);
		itemId = element.id;
		itemName = element.name;
		price = element.title;
		DisplayItem(itemName, price);
		document.garmentSearch1.action = "?userAction=getItemDetails&itemId=" + itemId + "&quantity=" + quantity;
		document.garmentSearch1.submit();
	}
	
		
	function nextUpChargePage() {
		document.garmentSearch1.upChargePageCount.value = eval(eval(document.garmentSearch1.upChargePageCount.value) + eval(1));
		document.garmentSearch1.action = "?userAction=nextPage";
		document.garmentSearch1.submit();
	}
	
	function nextColorPage() {
		document.garmentSearch1.colorsPageCount.value = eval(eval(document.garmentSearch1.colorsPageCount.value) + eval(1));
		document.garmentSearch1.action = "?userAction=nextPage";
		document.garmentSearch1.submit();
	}
	
	function nextPatternsPage() {
		document.garmentSearch1.PatternPageCount.value = eval(eval(document.garmentSearch1.PatternPageCount.value) + eval(1));
		document.garmentSearch1.action = "?userAction=nextPage";
		document.garmentSearch1.submit();
	}
	
	function nextItemsPage() {
		document.garmentSearch1.ItemPageCount.value = eval(eval(document.garmentSearch1.ItemPageCount.value) + eval(1));
		document.garmentSearch1.action = "?userAction=nextPage";
		document.garmentSearch1.submit();
	}
	
	function nextDeptPage() {
		document.garmentSearch1.DeptPageCount.value = eval(eval(document.garmentSearch1.DeptPageCount.value) + eval(1));
		document.garmentSearch1.action = "?userAction=nextPage";
		document.garmentSearch1.submit();
	}
	
	function setSelectedUpCharge(element) {
		var selectedUpCharge;
		var price;
		var quantity = document.garmentSearch1.txtAmountEntered.value;
		selectedUpCharge = element.name;
		price = element.title;
		ShowUpcharge(selectedUpCharge, price);
		document.garmentSearch1.action = "?userAction=addUpcharge&upchargeid=" + selectedUpCharge + "&quantity=" + quantity;
		document.garmentSearch1.submit();
	}
	
	function setSelectedColor(element) {
		var selectedColor;
		var quantity = document.garmentSearch1.txtAmountEntered.value;
		selectedColor = element.name;
		document.garmentSearch1.action = "?userAction=addColor&colorid=" + selectedColor + "&quantity=" + quantity;
		document.garmentSearch1.submit();
		
	}
	
	function setSelectedPattern(element) {
		var selectedPattern;
		var quantity = document.garmentSearch1.txtAmountEntered.value;
		selectedPattern = element.name;
		document.garmentSearch1.action = "?userAction=addPattern&patternid=" + selectedPattern + "&quantity=" + quantity;
		document.garmentSearch1.submit();
		
	}
	
	function changeQuantity(){
		var selItemID = null;
		var quantity = document.garmentSearch1.txtAmountEntered.value;
		if(quantity.length>0 && invoiceTable.rows.length > 0) {
			if(invoiceTable.rows.length ==1) 
				{
					if(document.garmentSearch1.select.checked) {
						selItemID = document.garmentSearch1.select.value;
					}
				}
			else{
				for (var i = 0; i < document.garmentSearch1.select.length; i++) {
					if(document.garmentSearch1.select[i].checked){
						selItemID = document.garmentSearch1.select[i].value;
						break;
					}
				}
			}
			if(selItemID != null) {
				if (!checkInt(quantity)) {
					show_focus("Must enter all numbers.", "CBS Error", document.garmentSearch1.txtAmountEntered);
					return false;
				}else{
					document.garmentSearch1.action = "?userAction=changeQuantity&itemId=" + selItemID + "&quantity=" + quantity;
					document.garmentSearch1.submit();
				}
			}
		}
		
	}
	
	function deleteItems() {
		var selItemID = null;
		if (invoiceTable.rows.length > 0) {
			if(invoiceTable.rows.length ==1) 
				{
					if(document.garmentSearch1.select.checked) {
						selItemID = document.garmentSearch1.select.value;
					}
				}
			else{
				for (var i = 0; i < document.garmentSearch1.select.length; i++) {
					if(document.garmentSearch1.select[i].checked){
						selItemID = document.garmentSearch1.select[i].value;
						break;
					}
				}
			}
			if(selItemID != null) {
				document.garmentSearch1.action = "?userAction=deleteItem&itemId=" + selItemID;
				document.garmentSearch1.submit();
			}
		}
	}
	
	function clearInvoice()	{
		var itemCount;
		itemCount = document.garmentSearch1.txtTotal.value;
		if (itemCount > 0) {
			document.garmentSearch1.action = "?userAction=clearInvoice";
			document.garmentSearch1.submit();
		}
	}
	
	function populateCommonItems(){
			
		document.garmentSearch1.ItemPageCount.value = eval(0);
		document.garmentSearch1.selectedDept.value =-1;
		document.garmentSearch1.lineNumber.value ="";
		document.garmentSearch1.action = "?userAction=getCommonItems";
		document.garmentSearch1.submit();				
			
	}
		
	function setSelectedDept(d_element) {
	
		document.garmentSearch1.ItemPageCount.value = eval(0);
		document.garmentSearch1.lineNumber.value =""
		document.garmentSearch1.selectedDept.value = d_element.id;
		document.garmentSearch1.action = "?userAction=changeDept";
		document.garmentSearch1.submit();
		
	}
	
		
	function hideScrollBars(){
		document.body.style.overflow='hidden';
	}
	
	function checkForAlertMessages() {
		hideScrollBars();
		<%
			if Len(alertMessage) > 0 then
			Response.Write "alertMessage='"
			Response.Write alertMessage
			Response.Write "'" 
			end if
		%>
		if (alertMessage != null){
			cbs_alert (alertMessage);
		}
		lastFocusControl = eval(document.garmentSearch1.txtAmountEntered);
	}
	
		
	function cancelForm() {
		document.garmentSearch1.action =document.garmentSearch1.action + "?userAction=cancel";
		document.garmentSearch1.submit();
	}
	
	function previousDeptPage() {
		document.garmentSearch1.DeptPageCount.value = eval(1);
		document.garmentSearch1.action = "?userAction=nextPage";
		document.garmentSearch1.submit();
	}
	
	function prevPatternsPage() {
		document.garmentSearch1.PatternPageCount.value = eval(1);
		document.garmentSearch1.action = "?userAction=nextPage";
		document.garmentSearch1.submit();
	}
	
	function prevUpChargePage() {
		document.garmentSearch1.upChargePageCount.value = eval(1);
		document.garmentSearch1.action = "?userAction=nextPage";
		document.garmentSearch1.submit();
	}
	
	function prevColorPage() {
		document.garmentSearch1.colorsPageCount.value = eval(1);
		document.garmentSearch1.action = "?userAction=nextPage";
		document.garmentSearch1.submit();
	}
	
	function prevItemsPage() {
		document.garmentSearch1.ItemPageCount.value = eval(1);
		document.garmentSearch1.action = "?userAction=nextPage";
		document.garmentSearch1.submit();
	}
	
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onLoad="checkForAlertMessages();">

<!-- #include file="../include/customerDisplay.inc" -->
<!-- #include file="../include/banner.inc" -->

<H1>Detailed Invoice</H1>
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 style="border-top:2px ridge gray;border-bottom:2px ridge gray"  style="background:#FFF" >
		<FORM id="garmentSearch1" name="garmentSearch1" action="garmentSearch.asp" method="post">
			<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
			<INPUT type="hidden" name="targetPage" value="<%= actionString %>">
			<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
			<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
			<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
			<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
			<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
			<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
			<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
			<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
			<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
			<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
			<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
		<tr>
				<td valign=top style="border-right:2px ridge gray"> <!-- first  column -->
					<TABLE ALIGN=center WIDTH="100%" BORDER=0  CELLPADDING=4 CELLSPACING=0>
						<tr>
							<td style="background-color:#6698FF;">
								<%	
									dim deptRst
									dim lStart, noOfElements
									set deptRst =  Session("departmentMaster")
									if deptRst.RecordCount > 0 then
										lStart =deptStartIndex
										noOfElements = deptRst.PageCount
										deptRst.AbsolutePage = lStart
										'While Not (deptRst.Eof Or deptRst.AbsolutePage <> lStart )
											
								%>
									
								<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=2 style="background-color:#6698FF;font-size:10px;">
									<tr align=center>
										<td valign=top>
											<!--<INPUT class=touch id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" type=button value="" style="width:35px;height:35px;background-image:url(../uploadedImages/<%= deptRst.Fields("imageFileName")%>);-->
											<BUTTON class=small id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" style="
											<%
												if clng(selectedDept) = deptRst.Fields("departmentID") then
											%>
												border:2px inset #CCCCCC;
											<%
												end if
											%>
											" onClick="setSelectedDept(this)"><%if deptRst.Fields("imageFileName") <> "" then%><img src="../uploadedImages/<%= deptRst.Fields("imageFileName")%>"><br><%end if%><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>										</td>
										<% 
											deptRst.MoveNext
											if Not deptRst.eof then
										%>
											<td valign=top>
												<!--<INPUT class=touch id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" type=button value="" style="width:35px;height:35px;background-image:url(../uploadedImages/<%= deptRst.Fields("imageFileName")%>);-->
												<BUTTON class=small id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" style="
												<%
													if clng(selectedDept) = deptRst.Fields("departmentID") then
												%>
													border:2px inset #CCCCCC;
												<%
													end if
												%>
											" onClick="setSelectedDept(this)"><%if deptRst.Fields("imageFileName") <> "" then%><img src="../uploadedImages/<%= deptRst.Fields("imageFileName")%>"><br><%end if%><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>											</td>
										<% 
											deptRst.MoveNext
											end if 
											if lStart < noOfElements then
										%>
												<td valign=top>
													<!--<INPUT class=touch id=otherDept name=otherDept type=button value="" style="width:35px;height:35px;background-image:url(../images/bluearrow.gif);" onClick="nextDeptPage();"><br>Other Dept.-->
													<BUTTON class=small  id=otherDept name=otherDept onClick="nextDeptPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/next.png"><br>Other Dept</button>												</td>
										<%
											else
												if lStart > 1 And lStart >= noOfElements then
										%>
												<td valign=top>
													<!--<INPUT class=touch id=previous name=previous type=button value="" style="width:35px;height:35px;background-image:url(../images/logout.gif);" onClick="previousDeptPage();"><br>Previous-->
													<BUTTON class=small  id=previous name=previous onClick="previousDeptPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/previous.png"><br>Previous</button>
												</td>
										<%		
												end if
											end if
										%>
									</tr>
									<tr align=center>
										<%
											if Not deptRst.eof then
										%>
											<td valign=top>
												<!--<INPUT class=touch id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" type=button value="" style="width:35px;height:35px;background-image:url(../uploadedImages/<%= deptRst.Fields("imageFileName")%>);-->
												<BUTTON class=small id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" onClick="setSelectedDept(this)" style="
												<%
													if clng(selectedDept) = deptRst.Fields("departmentID") then
												%>
													border:2px inset #CCCCCC;
												<%
													end if
												%>
												"><%if deptRst.Fields("imageFileName") <> "" then%><img src="../uploadedImages/<%= deptRst.Fields("imageFileName")%>"><br><%end if%><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>
											</td>
										<% 
											deptRst.MoveNext
											end if 
											if Not deptRst.eof then
										%>
											<td valign=top>
												<!--<INPUT class=touch id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" type=button value="" style="width:35px;height:35px;background-image:url(../uploadedImages/<%= deptRst.Fields("imageFileName")%>);-->
												<BUTTON class=small id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("name")%>" onClick="setSelectedDept(this)" style="
												<%
													if clng(selectedDept) = deptRst.Fields("departmentID") then
												%>
													border:2px inset #CCCCCC;
												<%
													end if
												%>
												"><%if deptRst.Fields("imageFileName") <> "" then%><img src="../uploadedImages/<%= deptRst.Fields("imageFileName")%>"><br><%end if%><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>
											</td>
										<% end if%>
											<td valign=top>
												<!--<INPUT class=touch id=bttnCommonItems name=bttnCommonItems type=button value="" style="width:35px;height:35px;background-image:url(../images/Commercial-1.gif);-->
												<BUTTON class=small id=bttnCommonItems name=bttnCommonItems style="
												<%
													if clng(selectedDept) = -1 then
												%>
													border:2px inset #CCCCCC;
												<%
													end if
												%>
												" onClick="populateCommonItems()">Common<br>Items</button>
											</td>
									</tr>
									
								</table>
								<% end if%>
							</td>
							<td style="border-left:2px ridge gray;" valign=center >
								<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLPADDING=0 style="font-size:10px;">
									<tr>
										<td width=20% align=center>
											<!--<INPUT class=touch id=deleteItem name=deleteItem type=button value="" style="width:35px;height:35px;background-image:url(../images/Cancel-Data.gif);" onClick="deleteItems();"><br>Delete Item-->
											<BUTTON class=small id=deleteItem name=deleteItem style="width:90px;height:50px;font-size:11px" onClick="deleteItems();"><img src="/static/icons/24x24/remove.png"><br>Delete Item</BUTTON>
										</td>
										<td width=20% align=center>
											<!--<INPUT class=touch id=bttnClearInvoice name=bttnClearInvoice type=button value="" style="width:35px;height:35px;background-image:url(../images/New-Data-Blank.gif);" onClick="clearInvoice();"><br>Clear Invoice-->
											<BUTTON class=small id=bttnClearInvoice style="width:90px;height:50px;font-size:11px" name=bttnClearInvoice onClick="clearInvoice();"><img src="/static/icons/24x24/clear.png"><br>Clear Invoice</BUTTON>
										</td>
									</tr>
								</table>
							</td>
						</tr> <!-- first column first row ends-->
						<tr style="height:400px" >
							<td  style="border-top:2px ridge gray">
								<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=1 >
									<TR valign=center>
										<TD align=center valign=center>
											<INPUT id=txtAmountEntered name=txtAmountEntered class=text maxlength="5" style="WIDTH: 140px;vertical-align:middle;" onblur="return txtAmountEntered_onblur()">
										</TD>
										
										<TD>
											<BUTTON style="width:60px;height:30px;" name=quantity id=quantity onClick="changeQuantity()">Qty</button>
										</TD>
									</TR>
									
									<tr height=10px><td></td></tr>
									<TR>
										<TD colspan=2 style="vertical-align:middle;text-align:center;height:100px">
											<!-- #include file="../include/integerPad.inc" -->
										</TD>
									</TR>
								</table>
							</td>
							<!-- items area -->
							<td  style="border-top:2px ridge gray;border-left:2px ridge gray;" valign=top >
								<TABLE   id="itemsTable" name="itemsTable" WIDTH="450" BORDER=0 CELLSPACING=1 CELLPADDING=1 >
									<tbody>
										<%
										dim commonItemsCount, iStartIndex
										dim colsCounter
										dim commItems
										Set commItems = Session("ItemsToBeShown")
										if commItems.RecordCount > 0 then
											iStartIndex = itemsStartIndex
											commonItemsCount = commItems.PageCount
											commItems.AbsolutePage = iStartIndex
											While Not (commItems.Eof Or commItems.AbsolutePage <> iStartIndex )
												colsCounter=1
									%>
										<tr>
											<%
												while colsCounter<=5 And Not (commItems.Eof Or commItems.AbsolutePage <> iStartIndex )
												colsCounter =colsCounter+1
																																			
											%>
											<td height=45px width=50px valign="top" align="center">
												<BUTTON class=small id="<%= commItems.Fields("priceListItemId")%>" name="<%= commItems.Fields("itemName")%>" title="<%= commItems.Fields("price")%>"  style="
												<%
													if clng(selItemId) = commItems.Fields("priceListItemId").Value  then
												%>
													border:2px inset #CCCCCC;
													
												<%
													end if
												%>
												background: #FFFFFF url(../uploadedImages/<%=commItems.Fields("imageFileName")%>) no-repeat top;
												height:60px;
												width:85px;
												"
												
												onClick="getItemDetails(this)"><span style="background:#f3f3f3;width:100%;border-top:1px solid gray;margin-top:36px"><%= WordTrim(commItems.Fields("itemName"), 15)%></span></button>
											</td>
											<%
												commItems.MoveNext
												wend
											wend
												if iStartIndex < commonItemsCount then
											%>
												<td width=50px align="center" valign="top">
													<!--<INPUT class=touch  id="moreItems" name="moreItems" type=button value="" style="width:35px;height:35px;background-image:url(../images/bluearrow.gif);" onClick="nextItemsPage();"><br>More-->
													<BUTTON class=small id=moreItems name=moreItems style="width:65px;height:50px" onClick="nextItemsPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/next.png"><br>More</button>
												</td>
									
											<%
												else
													if iStartIndex > 1 And iStartIndex >= commonItemsCount then
													
											%>
													<td width=50px align="center" valign="top">
														<!--<INPUT class=touch  id="prevItems" name="prevItems" type=button value="" style="width:35px;height:35px;background-image:url(../images/previous.gif);" onClick="prevItemsPage();"><br>Previous-->
														<BUTTON class=small id=prevItems name=prevItems style="width:65px;height:50px" onClick="prevItemsPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/previous.png"><br>Previous</Button>
													</td>	
											<%
													end if
												end if
											%>	
										</tr>
									<% 
										end if
									%>
									</tbody>
								</table>
							</td>
						</tr>
						<tr  style="height:180px">
							<td style="background:#FFF" style="border-top:2px ridge gray" colspan=2>
								<TABLE  style="background:#FFF" width=415 BORDER=0 CELLSPACING=1 CELLPADDING=1>
									<tr height=50>
										<td style="width:70px" >Upcharges</td>
										<%
											dim distinctUpcharges
											dim upChargeValue
											 if curr_LineNo <> "" then
												Set distinctUpcharges = Session("upcharges")
												if distinctUpcharges.Recordcount > 0 then
													lStart = upChargeStartIndex
													noOfElements = distinctUpcharges.PageCount
													distinctUpcharges.AbsolutePage = lStart
													while Not (distinctUpcharges.Eof Or distinctUpcharges.AbsolutePage <> lStart )
														upChargeValue = distinctUpcharges.Fields("descriptorName")
											%>
													<td align="center" style="width:45px">
														<BUTTON class=small id="<%= upChargeValue%>" name="<%= upChargeValue%>" title="<%= distinctUpcharges.Fields("price")%>" style="
														<%
															if selUpchargeValue = upChargeValue then
														%>
															border:2px inset #CCCCCC;
														<%
															end if
														%>
														background: #FFFFFF url(../uploadedImages/<%= distinctUpcharges.Fields("imageFileName")%>) no-repeat top;
														" onClick="setSelectedUpCharge(this);"><span style="background:#f3f3f3;width:100%;border-top:1px solid gray;margin-top:26px"><%= WordTrim(upChargeValue, 15)%></span></button>
													</td>
											<%
														distinctUpcharges.MoveNext
														wend
													if lStart < noOfElements then
												%>
													<td  style="width:45px" align="center">
														<BUTTON class=small id=moreUpCharge name=moreUpCharge onClick="nextUpChargePage();" style="background:#dcdcdc"><img src="/static/icons/24x24/next.png"><br>More</button>
													</td>
											<%
													else
														if lStart > 1 And lStart >= noOfElements then
														
											%>
														<td  style="width:45px" align="center">
															<BUTTON class=small id=prevUpCharge name=prevUpCharge onClick="prevUpChargePage();" style="background:#dcdcdc"><img src="/static/icons/24x24/previous.png"><br>Previous</BUTTON>
														</td>
											<%
														end if
													end if
												end if
											end if
										%>
											<td>&nbsp;</td>
									</tr>
									<tr height=50>
										<td style="width:70px" >Colors</td>
										<%
											dim distinctColors, colorValue
											if curr_LineNo <> "" then
												Set distinctColors = Session("colors")
												if distinctColors.Recordcount > 0 then
													lStart = colorsStartIndex
													noOfElements = distinctColors.PageCount
													distinctColors.AbsolutePage = lStart
													while Not (distinctColors.Eof Or distinctColors.AbsolutePage <> lStart )
														colorValue = distinctColors.Fields("descriptorName")
												%>
														<td height=45px style="width:45px"  align="center">
															<BUTTON class=small id="<%= colorValue%>" name="<%= colorValue%>" style="
															<%
																if selColorValue = colorValue then
															%>
																border:2px inset #CCCCCC;
															<%
																end if
															%>
															background=<%= Replace(colorValue," ", "")%>;
															" onClick="setSelectedColor(this);"><span style="background:#f3f3f3;width:100%;border-top:1px solid gray;margin-top:26px"><%= WordTrim(colorValue,15)%><span></button>
														</td>
												<%
														distinctColors.MoveNext
													wend
													if lStart < noOfElements then
												%>
													<td style="width:45px" align="center">
														<BUTTON class=small id=moreColors name=moreColors onClick="nextColorPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/next.png"><br>More</button>
													</td>
											<%
													else
														if lStart > 1 And lStart >= noOfElements then
														
											%>
															<td  style="width:45px" align="center">
																<BUTTON class=small id=prevColors name=prevColors onClick="prevColorPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/previous.png"><br>Previous</button>
															</td>
											<%	
														end if
													end if
												end if
											end if
										%>
										<td>&nbsp;</td>
									</tr>
									<tr height=50>
										<td style="width:70px" >Patterns</td>
										<%
											dim distinctPatterns
											dim patternValue
											if curr_LineNo <> "" then
												Set distinctPatterns = Session("patterns")
												if distinctPatterns.Recordcount > 0 then
													lStart = patternStartIndex
													noOfElements = distinctPatterns.PageCount
													distinctPatterns.AbsolutePage = lStart
													while Not (distinctPatterns.Eof Or distinctPatterns.AbsolutePage <> lStart )
														patternValue = distinctPatterns.Fields("descriptorName")
												%>
														<td height=45px style="width:45px" align="center">
															<BUTTON class=small id="<%= patternValue%>" name="<%= patternValue%>" style="
															<%
																if selPatternValue = patternValue then
															%>
																border:2px inset #CCCCCC;
															<%
																end if
															%>
															background: #FFFFFF url(../uploadedImages/<%= distinctPatterns.Fields("imageFileName")%>);
															" onClick="setSelectedPattern(this);"><span style="background:#f3f3f3;width:100%;border-top:1px solid gray;margin-top:26px"><%= WordTrim(patternValue,15)%></span></button>
														</td>
												<%
														distinctPatterns.MoveNext
													wend
													if lStart < noOfElements then
												%>
													<td  style="width:45px" align="center">
														<BUTTON class=small id=morePatterns name=morePatterns onClick="nextPatternsPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/next.png"><br>More</button>
													</td>
											<%
													else
														if lStart > 1 And lStart >= noOfElements then
											%>
														<td style="width:45px" align="center">
															<BUTTON class=small id=prevPatterns name=prevPatterns onClick="prevPatternsPage();" style="background:#dcdcdc"><img src="/static/icons/24x24/previous.png"><br>Previous</button>
														</td>
											<%	
														end if
													end if
												end if
											end if
										%>
										<td>&nbsp;</td>
									</tr>
								</table>
							</td>
						</tr>
					</table><!-- first part table ends here -->
				</td><!-- first  column ends-->
				<!-- second column -->
				<td>
					<TABLE WIDTH="290px" BORDER=0 CELLSPACING=0 CELLPADDING=0>
						<tr>
							<!-- list -->
							<td valign=top>
								<DIV STYLE="overflow-y:auto;height:420px; overflow-x:auto; width:290px;background:white;border:1px solid gray">
									<TABLE WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=0>
										<tr rowspan =5>
											<td>
												<TABLE name="invoiceTable" id ="invoiceTable" WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=2>
													<tr >
														<td width=17px></td>
														<td width="15px"></td>																
														<td class="label" width="30px" align=center></td>
														<td class="label"></td>
													</tr>
													<%
														

														dim displayRst
														dim displayAsEntered
														dim cloneRst
														dim checkItem
														set displayRst = invoice.lineItems
														if displayRst.RecordCount > 0 then
															set cloneRst = displayRst.Clone
															displayRst.MoveFirst
															while not displayRst.eof
															checkItem =false
															select case displayRst.Fields("itemType")
																	case "IT"
									
														%>
																			<%
																				if IsNumeric(curr_LineNo) then
																					if clng(curr_LineNo) =  displayRst.Fields("lineNumber").Value then
																						checkItem = true	
																					end if
																				end if
																			%>	
																			<tr name="main" title="IT" onClick="selectRow(this);" <% if checkItem then%>style="background-color=#C2DACD;" <%end if %>>
																				<td width="30px" colspan=2><input type="radio" name="select" id="select" value="<%=displayRst.Fields("lineNumber")%>"
																					<% if checkItem then%> checked <%end if %>
																				></td>
																				<td class="label" width="30px" align=center><%= displayRst.Fields("quantity")%></td>
																				<td class="label"><%= displayRst.Fields("itemName")%></td>
																			</tr>															

														<%
																			cloneRst.Filter ="parentLineNumber=" & displayRst.Fields("lineNumber")
																			if cloneRst.Recordcount > 0 then
																				cloneRst.MoveFirst
																				while not cloneRst.Eof
														%>
																				<tr name="sub" onClick="selectRow(this);">
																					<td width=15px></td>
																					<td width="15px"><input type="radio" name="select" id="select" value="<%= cloneRst.Fields("lineNumber")%>"></td>																
																					<td class="label" width="30px" align=center><%= cloneRst.Fields("quantity")%></td>
																					<td class="label"><%= cloneRst.Fields("itemName")%></td>
																				</tr>
																																					
										
														<%	
																					cloneRst.MoveNext																
																				wend
																		end if
																		cloneRst.Filter = adFilterNone																	
																end select
														displayRst.MoveNext
													wend
												end if
										%>
													
												</table>
											</td>
										</tr>
									</table> <!-- table for border -->
								</div>
							</td>
						</tr>
						<!-- list row ends here -->
						<!-- preferences start here -->
						<tr>
							<td>
								<TABLE WIDTH="290px" BORDER=0 CELLSPACING=1 CELLPADDING=2 style="background:white;" >
									<tr>
										<td align=left class="label" width=100px>Total Pieces</td>
										<td align=right>
											<INPUT id=txtTotal name=txtTotal class=text style="WIDTH: 100px;height:22px;text-align:right;" value="<%= invoice.getTotalItemCount()%>" readonly>
										</td>
									</tr>
									<tr>
										<td colspan=2 align="center">

														<INPUT class=touchNoBorder id=done name=done type=button value="" style="background-image:url(../images/ok.gif);" onClick="submitForm();">
														<INPUT class=touchNoBorder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm();">	
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table><!-- main table for 2nd column -->
				</td>
			</tr><!-- main table row -->
		</FORM>   
	</TABLE>
	
</BODY>
</HTML>
