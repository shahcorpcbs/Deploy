<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
  dim pageTitle
  dim table
  dim tableName

  pageTitle = Request.QueryString("title")
  tableName = trim(Request.QueryString("table"))
  
  if tableName <> "" then
     set table = Session(tableName)
  end if


%>

<HTML>
<HEAD>
<TITLE><% =pageTitle %></TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<SCRIPT LANGUAGE="javascript" >
 	function okay() {
  	    document.viewTable.action = 'checkout.asp';
        document.viewTable.submit();
	}

	function printTable(){
		viewTable.printButton.style.display = 'none';
		viewTable.okayButton.style.display = 'none';

		window.print();

		viewTable.printButton.style.display = 'block';
		viewTable.okayButton.style.display = 'block';
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<FORM name="viewTable" ID="viewTable" METHOD=POST  style="margin:0;padding:0">
<H1><% =pageTitle %></H1>
<TABLE WIDTH=90% BORDER=2 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT: 50px">

<%
  dim i

  if not table is nothing and table.RecordCount > 0 then


    Response.Write("<TR>")

    for i = 0 to table.Fields.Count - 1
      Response.write("<TD>" & table.Fields(i).Name & "</TD>")
    next

    Response.Write("</TR>")

    table.MoveFirst

    while not table.eof
      Response.Write("<TR>")

      for i = 0 to table.Fields.Count - 1
        Response.write("<TD>" & table.Fields(i).Value & "</TD>")
      next

      Response.Write("</TR>")

      table.MoveNext
    wend


  end if

%>

	</TABLE>
      <TABLE WIDTH="90%" BORDER=0 CELLSPACING=1 CELLPADDING=5 Style = "MARGIN-LEFT: 50px">
		<tr>
		<td  align = center>
			<INPUT class=touch   id=printButton name=printButton type=button onClick="printTable()" style="background-image:url(../images/Print-Invoice.gif);background-position=center"value=""><br>
		</td>
                <td  align = center>
		        <INPUT class=touchnoborder id=okayButton type=okayButton value="" style="background-image:url(../images/Ok.gif)" name=okay onClick="okay()">
                </td>


                </tr>
		</table>
</FORM>
</BODY>
</HTML>

