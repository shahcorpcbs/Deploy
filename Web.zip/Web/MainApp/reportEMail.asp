<%@ Language=VBScript %>
<% option explicit %>

<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!-- #include file="CheckSessionExpiry.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%	
		
%>


<HTML>

<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">

<TITLE>EMail Report</TITLE>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>

<script language="javascript" type="text/javascript">

	function submitForm() {
		if (validateParameters()) {		
			document.reportEMailForm.submit();
		}	
	}

	function validateParameters() {

		// Validate only if the form variable is defined.

		if (reportEMailForm.emailTo != null) {
				// Validate only if something is entered.
				if (reportEMailForm.emailTo.value == "") {
					cbs_alert("You must enter at least one email id of the recipient");
					reportEMailForm.emailTo.focus();
					return (false);
				}
		}

		return (true);

	}


</SCRIPT>

<script language="JavaScript" src="../script/validation.js"></script>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->

<B class="pageHeading">EMail Report - <%= Session("objRP").reportName %></B>

<FORM id="reportEMailForm" name="reportEMailForm" action="reportEMailResponse.asp" method="POST">

	<input type="hidden" name="reportID" value="<%= Session("objRP").reportNumber%>">
	<input type="hidden" name="storeID" value="<%= Session("objRP").storeID %>">
	<!-- 
	<TABLE ALIGN=center WIDTH="400px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
	-->
	
	<TABLE ALIGN=center VALIGN=center BORDER=4 CELLSPACING=1 CELLPADDING=5 >

			<tr height=35px width=100%>
				<td width = 50% class = "label" align=right Style="Font-weight=normal">To: </td>
				<td width = 50% ><INPUT type=text  size=40 Maxlength="1024" id=emailTo name=emailTo value="" tabindex=1>
				</td>
			</tr>

		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>

		<tr>
			<td width = 50% align=right >
				<INPUT  tabindex=2 class=touchnoborder id=ok name=ok type=button value="" onClick="submitForm();" 
					style="background-image:url(../images/Ok.gif);">
			</td>
			<td width = 50% align=left >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<INPUT  tabindex=2 class=touchnoborder id=close name=close type=button value="" onClick="history.back(-1);" 
					style="background-image:url(../images/Cancel.gif);">
			</td>
		</tr>
			
	</table>
</form>
</BODY>
</HTML>
