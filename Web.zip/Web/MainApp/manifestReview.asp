<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp" -->

<!-- #include file="../include/manifest.asp" -->

<!-- #include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim manifestId
	
	manifestId = getReqVar("manifestId")
	inventoryid = getReqVar("inventoryid")
	
	select case lcase(request.querystring("useraction"))
	case "reverse"
		reverseInvoices
	case "rack"
	    rackInvoices
	end select

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	function reverseInvoices
	    dim manifestItems, currMi
		manifestItems = split(Request.QueryString("items"), "|")
		for each currMi in manifestItems
		    query = "select InvoiceNumber, Location from ManifestItem where manifestItemId = " & currMi
            set rs = getdisconnectedrecordset(query)

				dbstartTrans()
				sqltxt  = "execute ReactivateTicket @invoiceNumber='" & rs("InvoiceNumber") & "', @rackLocation='" _
				    & dbstr(rs("Location"))  & "',@employeeid=" & session("employeeid") & ",@employeename='" _
					& session("employeename")  & "',@storeid=" & Session("storeid") & ",@terminalid=" & Session("terminalID")
				QryExecuteWithTrans(sqltxt)
				DbEndTrans()
		next
	end function

	function rackInvoices
	    dim manifestItems, currMi
		manifestItems = split(Request.QueryString("items"), "|")
		for each currMi in manifestItems
		    query = "select InvoiceNumber, Location from ManifestItem where manifestItemId = " & currMi
            set rs = getdisconnectedrecordset(query)

            query = "insert into PendingRackLocations (terminalId, employeeId, InvoiceNumber, StartRackLocation, EndRackLocation, Notes, ErrorNo) " _
                & " values ('" & Session("terminalID") & "', " & session("employeeid") & ", " & rs("InvoiceNumber") _
                & ", '" & dbstr(rs("Location")) & "', null, 'From manifest " & manifestId & "', 0)"
            qryexecute query
		next

        dim currSetting
        query = "select overridePreviousRackLocation from MiscSetup"
        set rs = getdisconnectedrecordset(query)
        currSetting = rs("overridePreviousRackLocation")

        'Doing it on this page auto overrides previous locations
        if currSetting = 0 then
            query = "Update MiscSetup set overridePreviousRackLocation = 1"
            qryexecute query
        end if

		dbstartTrans()
		sqltxt  = "execute RackPendingRackLocations @employeeid=" & session("employeeid") & ", @terminalid=" _
		    & Session("terminalID")  & ", @ForceRacking=0"
		QryExecuteWithTrans(sqltxt)
		DbEndTrans()


        if getReqVar("supNotif") = 1 then
            query = "Update RackAssignment set suppressNotification = 1 where ticketNumber in " _
                & "(select ticketNumber from Ticket where invoiceNumber in " _
                & "(select invoiceNumber from ManifestItem where ManifestId = " & manifestId & "))"
                qryexecute query
        end if

        if currSetting = 0 then
            query = "Update MiscSetup set overridePreviousRackLocation = 0"
            qryexecute query
        end if

	end function



	function getStoreName()
		dim query, rs

		query = "select name from store where storeid = " & Session("storeid")
		set rs = getdisconnectedrecordset(query)

		getStoreName = rs("name")

		set rs = nothing
	end function

	function getInventoryDescription(inventoryid)
		dim query, rs

		if inventoryid = "" then exit function

		query = " select manifest.name "
		query = query & " from inventory inner join manifest on inventory.manifestid = manifest.manifestid "
		query = query & " where inventory.inventoryid = " & inventoryid

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getInventoryDescription = rs(0)
		end if

		set rs = nothing


	end function
%>


<HTML>
<HEAD>


<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<LINK href="../style/manifest.css" rel="stylesheet" type="text/css">

<script language="javascript" src="../external/jquery-3.4.1.js"></script>

<script language="javascript" type="text/javascript">

    	function showMatchedItems() {
    		var matchedItems = document.getElementById('t_matched');
    		var showButton = document.getElementById('a_show_matched');
    		var hideButton = document.getElementById('a_hide_matched');

    		matchedItems.style.display = '';
    		showButton.style.display = 'none';
    		hideButton.style.display = 'block';

    	}
    	function hideMatchedItems() {
    		var matchedItems = document.getElementById('t_matched');
    		var showButton = document.getElementById('a_show_matched');
    		var hideButton = document.getElementById('a_hide_matched');

    		matchedItems.style.display = 'none';
    		showButton.style.display = 'block';
    		hideButton.style.display = 'none';
    	}

	function closeInv() {
        document.manifest_review.action = "/mainapp/manifestCreate.asp?useraction=close&inventoryid=<%=inventoryid%>";
        document.manifest_review.submit();
	}

	function exit() {
	    document.manifest_review.action = "/mainapp/manifestCreate.asp";
	    document.manifest_review.submit();
	}

function selectAll(type)
{
    var checkboxes;
    if (type == 1)
        checkboxes = document.getElementsByName('ico_check');
    else if (type == 2)
         checkboxes = document.getElementsByName('crl_check');
    else if (type == 3)
         checkboxes = document.getElementsByName('nr_check');

  for(var i=0, n=checkboxes.length;i<n;i++)
    checkboxes[i].checked = true;
}

function selectNone(type)
{
    var checkboxes;
    if (type == 1)
        checkboxes = document.getElementsByName('ico_check');
    else if (type == 2)
         checkboxes = document.getElementsByName('crl_check');
    else if (type == 3)
         checkboxes = document.getElementsByName('nr_check');

    for(var i=0, n=checkboxes.length;i<n;i++)
        checkboxes[i].checked = false;
}

function reversePickup()
{
    var selected = getSelected("ico_check")
    if (selected == "") {
        cbs_alert("Select items to reverse pickup");
        return;
    }
	document.manifest_review.action = "?useraction=reverse&items=" + selected;
	document.manifest_review.submit();
}

var selectedItems;
function rerack()
{
    selectedItems = getSelected("crl_check")
    if (selectedItems == "") {
        cbs_alert("Select items to rerack");
        return;
    }

    cbs_select('Should order ready notifications go out for these items?', 3, 'Yes|No|Cancel', 'doRack');
}

function rack()
{
    selectedItems = getSelected("nr_check")
    if (selectedItems == "") {
        cbs_alert("Select items to rack");
        return;
    }
    cbs_select('Should order ready notifications go out for these items?', 3, 'Yes|No|Cancel', 'doRack');
}

function doRack(option)
{
    clearOptionMsg()
	console.log(option)
    if (option == 2)
        return;

	document.manifest_review.action = "?useraction=rack&items=" + selectedItems + "&supNotif=" + option;
	document.manifest_review.submit();

}


function getSelected(type) {

    var selected = "";
    var checkboxes = document.getElementsByName(type);
    for(var i=0, n=checkboxes.length;i<n;i++) {
        if (checkboxes[i].checked) {
            if (selected == "")
                selected = checkboxes[i].value;
            else
                selected = selected + "|" + checkboxes[i].value;
        }
    }
    return selected;
}

    var options = "Cancel|Matched Inventory|Missing Inventory|Incorrectly Checked Out|Changed Rack Location|All";
	function printResults() {
	    cbs_select("Print what section:", 1, options, "handlePrintChoice");
	}

	function handlePrintChoice(returnVal) {
        clearOptionMsg();
	    var invType = options.split("|")[returnVal]
		var content = "";

		if(invType && invType != "Cancel") {
			switch(invType) {
				case "All":
					var inventoryEl = document.getElementById("inventory_content");
					content += inventoryEl.outerHTML;

					break;
				case "Matched Inventory":
					var inventoryEl = document.getElementById("store_content");
					content += inventoryEl.outerHTML;

					var inventoryEl = document.getElementById("matched_content");
					content += inventoryEl.outerHTML;

					break;
				case "Missing Inventory":
					var inventoryEl = document.getElementById("store_content");
					content += inventoryEl.outerHTML;

					var inventoryEl = document.getElementById("missing_content");
					content += inventoryEl.outerHTML;

					break;
				case "Incorrectly Checked Out":
					var inventoryEl = document.getElementById("store_content");
					content += inventoryEl.outerHTML;

					var inventoryEl = document.getElementById("ico_content");
					content += inventoryEl.outerHTML;

					break;
				case "Changed Rack Location":
					var inventoryEl = document.getElementById("store_content");
					content += inventoryEl.outerHTML;

					var inventoryEl = document.getElementById("cr_content");
					content += inventoryEl.outerHTML;

					break;
			}

			var print_window = window.open('','','width=600,height=600');
			print_window.document.open("text/html");
			print_window.document.write('<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">');
			print_window.document.write('<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">');
			print_window.document.write('<LINK href="../style/manifest.print.css" rel="stylesheet" type="text/css">');
			print_window.document.write(content);
			print_window.document.close();
			print_window.onafterprint = function() {
			    print_window.close();
            }
			print_window.print();

		}
	}


</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<FORM name="manifest_review" ID="manifest_review" METHOD=POST  style="margin:0;padding:0" onsubmit="return false;">

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON style="vertical-align:top" onclick="printResults()">Print</BUTTON>
		<BUTTON onclick="closeInv()">Close<BR/>Inventory</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>

<div id="inventory_content" style="margin-left: 10px">
<h1>Inventory #<%=inventoryid%></h1>


<div id="store_content">
	<div><b>Store:</b> <%=getStoreName()%></div>
	<div><b>Date:</b> <%=Date() & " " & Time()%></div>
	<div><b>Description:</b> <%=getInventoryDescription(inventoryid)%> </div>
	<div><b>Manifest:</b> <%=manifestid%></div>
	<div><b>Note:</b> Reracking will override any previous rack location</div>
</div>

<div class="inv_sec" id="matched_content">
<%
	query = "select mi.invoicenumber, isnull(mi.location, '') as location, isnull(customer.customername, '') as customername " _
	    & "from manifestitem mi left outer join ticket t on mi.invoicenumber = t.invoicenumber " _
	    & "left outer join customer on t.customersequencenumber = customer.customersequencenumber, " _
	    & "RackAssignment ra where ra.ticketNumber = t.ticketNumber and t.invoiceNumber = mi.invoiceNumber and ra.rackLocationStart = mi.Location " _
	    & "and mi.ManifestID = " & manifestId
		
	set rs = getdisconnectedrecordset(query)
%>
	<h2>Matched Inventory (<%=rs.recordcount%> items)</h2>

	<table id="t_matched" style="display:none" class="itable" cellspacing="0">
		<tr>
			<th>Invoice Number</th>
			<th>Location</th>
			<th>Customer</th>
		</tr>

<%	
	while not (rs.eof or rs.bof)
%>
		<tr>
			<td><%=Server.HTMLEncode(rs("invoicenumber"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("location"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("customername"))%>&nbsp;</td>
		</tr>
<%
		rs.movenext
	wend
%>
	</table>

<% if rs.recordcount > 0 then %>
	<div><a id="a_show_matched" href="javascript:showMatchedItems()">Show matched items</a></div>
	<div><a id="a_hide_matched" style="display:none" href="javascript:hideMatchedItems()">Hide matched items</a></div>

<% end if %>
</div>



<input type="hidden" name="inventoryid" value="<%=inventoryid%>" />
<input type="hidden" name="manifestId" value="<%=manifestId%>" />

<div class="inv_sec" id="ico_content">
<%
	query = " select manifestitem.manifestitemid, manifestitem.invoicenumber, isnull(manifestitem.location, '') as location, " _
	    & "isnull(customer.customername, '') as customername, isnull(ticket.dateout, '') as dateout from manifestitem "
	query = query & " inner join manifest on  manifestitem.manifestid = manifest.manifestid "
	query = query & " inner join ticket on manifestitem.invoicenumber = ticket.invoicenumber "
	query = query & " inner join customer on ticket.customersequencenumber = customer.customersequencenumber "
	query = query & " where manifestitem.manifestid = " & manifestId & " and ticketStatus = 'FI'"
	query = query & " order by case dbo.isint(manifestitem.location) when 1 then cast(manifestitem.location as int) else 10000000 end "

		
	set rs = getdisconnectedrecordset(query)
%>

    <% if rs.recordcount > 0 then %>
	<h2>Incorrectly Checked Out (<%=rs.recordcount%> items)</h2>
    <DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
        <SPAN style="float:left">
            <table>
                <tr>
                    <td>
                        <BUTTON onclick="reversePickup()">Reverse Pickup</BUTTON>
                    </td>
                    <td>
                         <input type="radio" name="sel_ICO" id="sel_allICO" onclick="selectAll(1)"><label for="sel_allICO">Select All</label><br />
                         <input type="radio" name="sel_ICO" id="sel_noneICO" onclick="selectNone(1)"><label for="sel_noneICO">Select None</label>
                     </td>
                </tr>
            </table>
        </SPAN>
    </DIV>
	
	<table class="itable" cellspacing="0">
		<tr>
            <th></th>
			<th>Invoice Number</th>
			<th>Location</th>
			<th>Date Out</th>
			<th>Customer</th>
		</tr>

        <%
            while not (rs.eof or rs.bof)
        %>
		<tr>
			<td><input type="checkbox" name="ico_check" value="<%=rs("manifestitemid")%>"/></td>
			<td><%=Server.HTMLEncode(rs("invoicenumber"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("location"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("dateout"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("customername"))%>&nbsp;</td>
		</tr>
<%
		rs.movenext
	wend
	set rs = nothing
%>
	</table>
<% end if %>
</div>


<div class="inv_sec" id="cr_content">
<%
	query = "select manifestitem.manifestitemid,  manifestitem.invoicenumber, isnull(manifestitem.location, '') as location, " _
	    & "ra.rackLocationStart as previouslocation, isnull(customer.customername, '') as customername from manifestitem "
	query = query & " inner join ticket on manifestitem.invoicenumber = ticket.invoicenumber "
	query = query & " inner join customer on ticket.customersequencenumber = customer.customersequencenumber "
	query = query & " inner join RackAssignment ra on ra.InvoiceNumber = manifestitem.InvoiceNumber "
	query = query & " where manifestitem.manifestid = " & manifestId
	query = query & " and manifestitem.invoicestatus = 'open' "
	query = query & " and manifestitem.location <> ra.rackLocationStart "
	query = query & " order by case dbo.isint(manifestitem.location) when 1 then cast(manifestitem.location as int) else 10000000 end "

	
	set rs = getdisconnectedrecordset(query)
%>

    <% if rs.recordcount > 0 then %>
	<h2>Changed Rack Location (<%=rs.recordcount%> items)</h2>

    <DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
        <SPAN style="float:left">
            <table>
                <tr>
                    <td>
                        <BUTTON onclick="rerack()">Rerack</BUTTON>
                    </td>
                    <td>
                         <input type="radio" name="sel_crl" id="sel_allcrl" onclick="selectAll(2)"><label for="sel_allcrl">Select All</label><br />
                         <input type="radio" name="sel_crl" id="sel_nonecrl" onclick="selectNone(2)"><label for="sel_nonecrl">Select None</label>
                     </td>
                </tr>
            </table>
        </SPAN>
    </DIV>
	
	<table class="itable" cellspacing="0">
		<tr>
            <th></th>
			<th>Invoice Number</th>
			<th>Old Location</th>
			<th>New Location</th>
			<th>Customer</th>
		</tr>

<%	
	while not (rs.eof or rs.bof)
%>
		<tr>
			<td><input type="checkbox" name="crl_check" value="<%=rs("manifestitemid")%>"/></td>
			<td><%=Server.HTMLEncode(rs("invoicenumber"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("previouslocation"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("location"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("customername"))%>&nbsp;</td>
		</tr>
<%
		rs.movenext
	wend
	set rs = nothing
%>
	</table>
<% end if %>

<%
	query = "select manifestitem.manifestitemid,  manifestitem.invoicenumber, isnull(manifestitem.location, '') as location, " _
	    & "isnull(customer.customername, '') as customername from manifestitem "
	query = query & " inner join ticket on manifestitem.invoicenumber = ticket.invoicenumber "
	query = query & " inner join customer on ticket.customersequencenumber = customer.customersequencenumber "
	query = query & " where manifestitem.manifestid = " & manifestId
	query = query & " and manifestitem.invoicestatus = 'open' "
	query = query & " and manifestitem.invoiceNumber not in (select invoiceNumber from RackAssignment)"
	query = query & " order by case dbo.isint(manifestitem.location) when 1 then cast(manifestitem.location as int) else 10000000 end "


	set rs = getdisconnectedrecordset(query)
%>

    <% if rs.recordcount > 0 then %>
	<h2>Not Previously Racked (<%=rs.recordcount%> items)</h2>

    <DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
        <SPAN style="float:left">
            <table>
                <tr>
                    <td>
                        <BUTTON onclick="rack()">Rack</BUTTON>
                    </td>
                    <td>
                         <input type="radio" name="sel_nr" id="sel_allnr" onclick="selectAll(3)"><label for="sel_allnr">Select All</label><br />
                         <input type="radio" name="sel_nr" id="sel_nonenr" onclick="selectNone(3)"><label for="sel_nonenr">Select None</label>
                     </td>
                </tr>
            </table>
        </SPAN>
    </DIV>

	<table class="itable" cellspacing="0">
		<tr>
            <th></th>
			<th>Invoice Number</th>
			<th>Location</th>
			<th>Customer</th>
		</tr>

<%
	while not (rs.eof or rs.bof)
%>
		<tr>
			<td><input type="checkbox" name="nr_check" value="<%=rs("manifestitemid")%>"/></td>
			<td><%=Server.HTMLEncode(rs("invoicenumber"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("location"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("customername"))%>&nbsp;</td>
		</tr>
<%
		rs.movenext
	wend
	set rs = nothing
%>
	</table>
<% end if %>
</div>


<div class="inv_sec" id="missing_content">
<%
    query = "select ra.invoiceNumber, rackLocationStart + (case when rackLocationend  is null then '' else ' - ' + rackLocationEnd end) as location, " _
        & "isnull(customer.customername, '') as customername, " _
        & "isnull(ticket.invoicetotal, 0) - isnull(ticket.amountpaid, 0) as invoicebalance " _
        & "from RackAssignment ra " _
	    & "left outer join ticket on ra.invoicenumber = ticket.invoicenumber " _
	    & "left outer join customer on ticket.customersequencenumber = customer.customersequencenumber " _
	    & "where ra.pickedUp = 0 and ticket.ticketStatus not in ('VO', 'FI') and ra.invoiceNumber not in " _
	    & "(select invoiceNumber from manifestItem where manifestId = " & manifestId & ")"

	set rs = getdisconnectedrecordset(query)
%>
	<h2>Missing Inventory (<%=rs.recordcount%> items)</h2>

	<table class="itable" cellspacing="0">
		<tr>
			<th>Invoice Number</th>
			<th>Balance</th>
			<th>Previous Location</th>
			<th>Customer</th>
		</tr>

<%
	while not (rs.eof or rs.bof)
%>
		<tr>
			<td><%=Server.HTMLEncode(rs("invoicenumber"))%>&nbsp;</td>
			<td><%=formatcurrency(rs("invoicebalance"))%>&nbsp;</td>
			<td><%=rs("location")%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("customername"))%>&nbsp;</td>
		</tr>
<%
		rs.movenext
	wend
	set rs = nothing
%>
	</table>
</div>




</div>


</BODY>
</HTML>
