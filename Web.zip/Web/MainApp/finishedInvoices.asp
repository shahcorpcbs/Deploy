<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/customerPaymentObj.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim ticketNumber
	dim RackRst
	dim custSeqNumber
	dim actionString
	dim invoice
	dim rackStr
	dim sInvoicenumber
	'Following added by J.Johnston, 20Nov03
	dim storeId
	dim ccAuthCode
	dim ccExpDate
	dim ccType
	dim ccTypeName
	dim ccAcctNum
	dim ccCardHolder
	dim ccTotal		
	dim ccNOTCC
	'End addition, 20Nov03
	dim query
	dim rs
	
	ticketNumber = getReqVar("TicketNumber")
	
	custSeqNumber = Session("customerSequenceNumber")
	'Following added by J.Johnston, 20Nov03
	storeId = Session("storeID")
	ccNOTCC = 0
	'End addition, 20Nov03
	
	select case lcase(request.querystring("useraction"))
	case "prevticket"
		ticketNumber = getPrevTicket(custSeqNumber, ticketNumber)
	case "nextticket"
		ticketNumber = getNextTicket(custSeqNumber, ticketNumber)
	end select
	
	if IsEmpty(actionString) then	
		getCustomerDetails
		getPickupDetails
		getCreditCardDetails
		set invoice = Server.CreateObject("ShahCorpComponents.invoice")
		invoice.DBConnectionString = Session("shahcorpDSN")
		set Session("invoice") = invoice
		invoice.getExistingDetails ticketNumber
		sInvoicenumber = invoice.invoiceNo
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & " Edit Invoice"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
	else
		set invoice = Session("invoice")
	end if
	
	function getNextTicket(custSeqNumber, ticketNumber)
		dim query, rs
		
		query = " select min(ticketnumber) as nextTicketNumber from ticket where "
		query = query & " ticketnumber > " & ticketNumber
		query = query & " and customersequencenumber = " & custSeqNumber
		query = query & " and ticketstatus = 'FI' "

		set rs = getdisconnectedrecordset(query)
		
		if not isnull(rs("nextTicketNumber")) then
			getNextTicket = rs("nextTicketNumber")
		else
			getNextTicket = ticketnumber
		end if
		
		set rs = nothing
	end function
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	function getPrevTicket(custSeqNumber, ticketNumber)
		dim query, rs
		
		query = " select max(ticketnumber) as prevTicketNumber from ticket where "
		query = query & " ticketnumber < " & ticketNumber
		query = query & " and customersequencenumber = " & custSeqNumber
		query = query & " and ticketstatus = 'FI' "

		set rs = getdisconnectedrecordset(query)
		
		if not isnull(rs("prevTicketNumber")) then
			getPrevTicket = rs("prevTicketNumber")
		else
			getPrevTicket = ticketnumber
		end if
		
		set rs = nothing
	end function
	
	sub getPickupDetails()
		dim ssql
		dim objRst
		dim logDate
		dim pickupDate
		dim pickupEmployee
		dim pickupTime
		ssql = "Select logDate, employeeName from TicketLog inner join ticket on ticketlog.ticketnumber = ticket.ticketnumber " _
				& " Where ticketlog.ticketNumber = " & ticketNumber _
				& " and ticket.ticketstatus = 'FI' " _
				& " And ticketlog.logType='P'" _
				& " order by ticketlog.logdate desc "
		set objRst = getDisconnectedRecordset(ssql)
		if objRst.Recordcount > 0 then
			logDate = objRst.Fields("logDate").Value
			pickupEmployee = objRst.Fields("employeeName").Value
			pickUpDate = FormatDateTime(logDate, vbShortDate)
			pickUpTime = FormatDateTime(logDate, vbLongTime)
		else
			pickupDate =""
			pickupTime = ""
			pickupEmployee = ""
		end if
		Session("pickupdate") = pickupDate
		Session("pickuptime") = pickupTime
		Session("pickupEmp")= pickupEmployee
	end sub
	
	sub getCustomerDetails()
		dim ssql
		dim objRst
		dim custAreaCd
		dim custPhone
		
		ssql = "Select customerName, mainPhone, mainAreaCode, IsNull(starchPreferenceName, '') as starchPreferenceName , " _
				& " IsNull(finishPreferenceName, '') as finishPreferenceName FROM Customer Where customerSequenceNumber =" _
				& custSeqNumber
		set objRst = getDisconnectedRecordset(ssql)
		if objRst.Recordcount > 0 then
			Session("customername") = objRst.Fields("customerName").Value
			if IsNull(objRst.Fields("mainAreaCode").Value) then
				custAreaCd = ""
			else
				custAreaCd  = objRst.Fields("mainAreaCode").Value
			end if
			if IsNull(objRst.Fields("mainPhone").Value) then
				custPhone = ""
			else
				custPhone  = objRst.Fields("mainPhone").Value
			end if
			if Len(custAreaCd) > 0 then
				custAreaCd = "(" & custAreaCd & ") "
			end if
			Session("customermainphone") = custAreaCd & custPhone
			Session("starchPref") = objRst.Fields("starchPreferenceName").Value
			Session("finishPref") = objRst.Fields("finishPreferenceName").Value
		end if
	end sub
	
	
	'Following procedure added by J.Johnston, 20NOV03
	sub getCreditCardDetails()
		dim ssql
		dim objRst	
		
		ccCardHolder = Session("customername")
		
		ssql = "select pay.* " _
				& "from Payment pay join PaymentTracking pt on (pay.paymentNumber = pt.sourceRefNumber) " _
				& "where pt.sourceRefType = 'PA' "  _
				& "and pt.targetRefType = 'TI' " _
				& "and pay.paymentTypeName = 'Credit Card' " _
				& "and pt.targetRefNumber = " & ticketNumber
		set objRst = getDisconnectedRecordset(ssql)
		if objRst.Recordcount > 0 then
		
			if isnull(objRst.Fields("approvalCode").value) then
				ccAuthCode = ""
			else
				ccAuthCode = objRst.Fields("approvalCode").value
			end if
			
			if isnull(objRst.Fields("creditCardExpiryDate").value) then
				ccExpDate = ""
			else
				ccExpDate = objRst.Fields("creditCardExpiryDate").value
			end if
			
			if isnull(objRst.Fields("creaditCardTypeID").value) then
				ccType = ""
			else
				ccType = objRst.Fields("creaditCardTypeID").value
			end if
			
			if isnull(objRst.Fields("checkOrCardNumber").value) then
				ccAcctNum = ""
			else
				ccAcctNum = objRst.Fields("checkOrCardNumber").value
			end if
						
			if isnull(objRst.Fields("amountPaid").value) then
				ccTotal = ""
			else
				ccTotal = objRst.Fields("amountPaid").value
			end if
			
		else
			ccNOTCC = 1
			ccAuthCode = ""
			ccExpDate = ""
			ccType = ""
			ccAcctNum = ""
			ccCardHolder = ""
			ccTotal = ""
				
		end if
		
		if ccType <> "" then
			ssql = "select creditcardTypeId, name from creditcardtypedomain " _
					& " where storeid = " & storeId _
					& " and creditcardTypeId = " & ccType
			set objRst = getDisconnectedRecordset(ssql)
			if objRst.Recordcount > 0 then
				if isnull(objRst.Fields("name").value) then
					ccTypeName = ""
				else
					ccTypeName = objRst.Fields("name").value
				end if
			else
				ccTypeName = ""
			end if
		end if
		
		if ccAcctNum <> "" then
			ccAcctNum = "XXXX XXXX XXXX "+ right(ccAcctNum,4)
		end if
		
		if ccTotal <> "" then
			ccTotal = formatcurrency(ccTotal,2)
		end if
		
		
	end sub	
	
	
	function getAllRackLocations()
		dim ssql
		
		ssql = " select rackAssignment.racklocationstart, "
		ssql = ssql & " rackAssignment.racklocationend, "
		ssql = ssql & " rackAssignment.rackedDate, "
		ssql = ssql & " employee.employeename "
		ssql = ssql & " from rackAssignment inner join employee on "
		ssql = ssql & " rackAssignment.rackedEmployeeID = employee.employeeID "
		ssql = ssql & " where ticketNumber=" & ticketNumber
		
		set getAllRackLocations = getDisconnectedRecordset(ssql)
	end function
	
	function getAllRackLocationDeletions()
		dim ssql
		
		ssql = " select rackAssignmentDeletion.racklocationstart, "
		ssql = ssql & " rackAssignmentDeletion.racklocationend, "
		ssql = ssql & " rackAssignmentDeletion.deletionDate, "
		ssql = ssql & " employee.employeename "
		ssql = ssql & " from rackAssignmentDeletion inner join employee on "
		ssql = ssql & " rackAssignmentDeletion.employeeid = employee.employeeID "
		ssql = ssql & " where rackAssignmentDeletion.ticketNumber=" & ticketNumber
		
		set getAllRackLocationDeletions = getDisconnectedRecordset(ssql)
	end function
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Finished Invoices</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript" src="/Script/printing.js"></script>

<script language="javascript" type="text/javascript">

	function viewPrev() {
		document.finishedInvoices.action="?userAction=prevticket";
		document.finishedInvoices.submit();
	}
	
	function viewNext() {
		document.finishedInvoices.action="?userAction=nextticket";
		document.finishedInvoices.submit();
	}
	
	function creationTranHistory(){
		var ticketNo;
		var invoiceNo;
		
		ticketNo = document.finishedInvoices.ticketNumber.value;
		invoiceNo = document.finishedInvoices.invoiceNumber.value;
		
		document.finishedInvoices.action="CreationTransactionHistory.asp?ticketNo=" + ticketNo + "&invoiceNo="+ invoiceNo;
		document.finishedInvoices.submit();
	}
	function editTranHistory(){
		var ticketNo;
		var invoiceNo;
		ticketNo = document.finishedInvoices.ticketNumber.value;
		invoiceNo = document.finishedInvoices.invoiceNumber.value;
		document.finishedInvoices.action="editTransactionHistory.asp?ticketNo=" + ticketNo + "&invoiceNo="+ invoiceNo;;
		document.finishedInvoices.submit();
	}
	function pickUpTranHistory(){
		var ticketNo;
		var invoiceNo;
		ticketNo = document.finishedInvoices.ticketNumber.value;
		invoiceNo = document.finishedInvoices.invoiceNumber.value;
		document.finishedInvoices.action="pickupTransactionHistory.asp?ticketNo=" + ticketNo + "&invoiceNo="+ invoiceNo;
		document.finishedInvoices.submit();
	}
	function viewTicketLog(){
		var ticketNo;
		var invoiceNo;
		ticketNo = document.finishedInvoices.ticketNumber.value;
		invoiceNo = document.finishedInvoices.invoiceNumber.value;
		document.finishedInvoices.action="viewTicketLog.asp?ticketNumber=" + ticketNo + "&invoiceNumber="+ invoiceNo;
		document.finishedInvoices.submit();
	}
	function cancelForm() {
		document.finishedInvoices.action = "customerfunctions.asp";
		document.finishedInvoices.submit();
	}
	
	function printPickupReceipt() {
		var ticketNo;
		ticketNo = document.finishedInvoices.ticketNumber.value;

		PrintPickupInvoice(ticketNo);
	}

	
	//Following function added by J.Johnston, 19NOV03
	function PrintCCReceipt()
	{

	}	
	
</SCRIPT>
<script language="JavaScript" src="../script/date-picker.js"></script>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->

<B class="pageHeading">Finished Invoice
<%=sInvoicenumber%>&nbsp;</B>
	<TABLE ALIGN=center WIDTH="100%" BORDER=0  CELLPADDING=1 >
	<FORM id="finishedInvoices" name="finishedInvoices" action="" method="post">
		<INPUT type="hidden" name="ticketNumber" value="<%= ticketNumber %>">
		<INPUT type="hidden" name="invoiceNumber" value="<%= sInvoicenumber %>">
		<!-- Following added by J.Johnston, 20Nov03-->
		<INPUT type="hidden" name="ccAuthCode" value="<%= ccAuthCode %>">
		<INPUT type="hidden" name="ccExpDate" value="<%= ccExpDate %>">
		<INPUT type="hidden" name="ccType" value="<%= ccType %>">
		<INPUT type="hidden" name="ccAcctNum" value="<%= ccAcctNum %>">
		<INPUT type="hidden" name="ccCardHolder" value="<%= ccCardHolder %>">
		<INPUT type="hidden" name="ccTotal" value="<%= ccTotal %>">
		<INPUT type="hidden" name="ccNOTCC" value="<%= ccNOTCC %>">
		<!-- End addition, 20Nov03-->
		
		<TR>
			<td valign=top>
				<TABLE ALIGN=center WIDTH="100%" BORDER=0  CELLPADDING=1>
					<tr height=150px></tr>

					<tr>
						<td height=50px align="center"> 
							<INPUT class=touch id=ticketLog name=ticketLog type=button value="" style="background-image:url(../images/Multiple-Tickets.gif);" onClick="viewTicketLog()"><br>Ticket Log
						</td>
					</tr>
				</table>
			</td>
			<td valign=top>
				<TABLE ALIGN=center WIDTH="100%" BORDER=0  CELLPADDING=1>
					<tr height=20px><td valign=bottom class="label">Pickup Details</td></tr>
					<tr>
						<td>
							<TABLE ALIGN=center WIDTH="100%" BORDER=1  CELLPADDING=1>
								<tr height=30px>
									<td class="label">&nbsp;<%= Session("pickupdate") %></td>
								</tr>
								<tr height=30px>
									<td class="label">&nbsp;<%= Session("pickuptime")%></td>
								</tr>
								<tr height=30px>
									<td class="label">&nbsp;<%= Session("pickupEmp")%></td>
								</tr>
							</table>
						</td>
					</tr>

          <%
            query = " select claimreceipt.*, isnull(note, '') as note from claimreceipt "
            query = query & " inner join ticketlog on claimreceipt.claimreceiptid = ticketlog.claimreceiptid "
            query = query & " where ticketlog.ticketnumber = " & ticketnumber
            
            set rs = getdisconnectedrecordset(query)
            
            if not (rs.eof or rs.bof) then
          %>
					<tr>
						<td>
							<TABLE ALIGN=center WIDTH="100%" class="itable"  CELLPADDING=1>
							  <tr><th colspan="2">Claim Receipt:</th></tr>
								<tr><td style="width:150px">Name:</td><td><%= rs("name") %></td>&nbsp;</tr>
								<tr><td style="width:150px">Relationship:</td><td><%= rs("relationship") %>&nbsp;</td></tr>
								<tr><td style="width:150px">Identification Type:</td><td><%= rs("identificationType") %>&nbsp;</td></tr>
								<tr><td style="width:150px">Identification:</td><td><%= rs("identification") %>&nbsp;</td></tr>
								<tr><td style="width:150px">Phone Number:</td><td><%= rs("phonenumber") %>&nbsp;</td></tr>
								<tr><td valign="top" style="width:150px">Note:</td><td><%=replace(rs("note"), vbcrlf, "<br>") %>&nbsp;</td></tr>
							</table>
							<br>
						</td>
					</tr>
					<%
					  end if
					  
					  set rs = nothing
					%>
					<tr>
					<td align="center">

  					To view signature(s) print pickup receipt
  					<table style="width:100%">
  					  <tr>
  					    <td align="center">
  					      <INPUT class=touch id=printPickUp name=printPickUp type=button value="" style="background-image:url(../images/Print-Invoice.gif);" onClick="printPickupReceipt();"><br>Print Pickup Receipt
  					    </td>
  					    <td align="center">
  					      <!--<INPUT class=touch id=printCCReceipt name=printCCReceipt type=button value="" style="background-image:url(../images/Print-Invoice.gif);" onClick="PrintCCReceipt();"><br>Print Credit Card Receipt -->
  					    </td>
  					  </tr>
  					</table>
					</td>
					</tr>
					<!-- End addition, 19Nov03 -->
					
				</table>	
			</td>
			<td align="center">
				<!-- 3rd column -->
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0>
					<!-- header row -->
					<tr>
						<td align=center>
							<TABLE WIDTH="265px" BORDER=0 CELLSPACING=1 CELLPADDING=2 >
								<tr height=55px>
									<td align="center">
										<INPUT style="width:100px;height:50px" type=button onClick="viewPrev()" value="Previous">
									</td>
									<td align="center">
										<INPUT style="width:100px;height:50px" type=button onClick="viewNext()" value="Next">
									</td>
								</tr>
							</table>
						</td>
					</tr>
					
					<tr>
						<td class="label" align=center>Rack Locations</td>
					</tr>
					<tr>
						<td align=center>
							<SELECT name=rackLocations size=7 style="width:265px;">
								<%
										set RackRst = getAllRackLocations()
										if RackRst.RecordCount > 0 then
											RackRst.MoveFirst
											while not RackRst.EOF
								%>
											</OPTION>
												<OPTION Value="">
												<% 

													rackStr = RackRst.Fields("rackedDate").Value
													rackStr = rackStr & "                  " & RackRst.Fields("employeename").Value
													
													Response.Write rackStr
												%>
											</OPTION>
											
											<OPTION Value="">
												<% 
													rackStr = RackRst.Fields("rackLocationStart").Value
													if not IsNull(RackRst.Fields("rackLocationEnd").Value) then
														rackStr = rackStr & " - " & RackRst.Fields("rackLocationEnd").Value
													end if

													Response.Write rackStr
												%>

											
														
								<%
												RackRst.MoveNext
											wend
										end if
								%>
								
								<%
										set RackRst = getAllRackLocationDeletions()
										if RackRst.RecordCount > 0 then
											RackRst.MoveFirst
											while not RackRst.EOF
								%>
											</OPTION>
												<OPTION Value="">
												<% 

													rackStr = RackRst.Fields("deletionDate").Value
													rackStr = rackStr & "                  " & RackRst.Fields("employeename").Value
													
													Response.Write rackStr
												%>
											</OPTION>
											
											<OPTION Value="">
												<% 
													rackStr = RackRst.Fields("rackLocationStart").Value
													if not IsNull(RackRst.Fields("rackLocationEnd").Value) then
														rackStr = rackStr & " - " & RackRst.Fields("rackLocationEnd").Value
													end if

													Response.Write "DELETE " & rackStr 
												%>

											
														
								<%
												RackRst.MoveNext
											wend
										end if
								%>
							</SELECT>
						<td>
					</tr>
					<!-- customer name & phone -->
					<tr>
						<td align=center>
							<TABLE WIDTH="265px" BORDER=0 CELLSPACING=0 CELLPADDING=0>
								<tr>
									<td class="label" align=center style="border-top:1px solid black; border-left:1px solid black; border-right:1px solid black;height:20px;">&nbsp;<%= Server.HTMLEncode(Session("customername"))%></td>
									
								</tr>
								<tr>
									<td class="label" align=center style="border-left:1px solid black; border-right:1px solid black;border-bottom:1px solid black;height:20px;">&nbsp;<%= Session("customermainphone")%></td>
									
								</tr>
								
							</table>
						</td>
						
					</tr>
					
					<!-- list -->
					<tr>
						<td align=center>
							<DIV STYLE="overflow-y:auto;height:200px; overflow-x:auto; width=265px">
									<TABLE WIDTH="100%" style="border-color:#2F4F4F;border-style:solid;background-color:white;" BORDER=1 CELLSPACING=0>
										<tr rowspan =5>
											<td>
												<TABLE WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=3>
												<%
													dim displayRst
													dim cloneRst
													set displayRst = invoice.lineItems
													if displayRst.RecordCount > 0 then
														set cloneRst = displayRst.Clone
														displayRst.MoveFirst
														while not displayRst.eof
															select case displayRst.Fields("itemType")
																case "IT"
												%>
																	<tr name="main">
																		<!-- <td colspan=2><input type="radio" name="select" id="select" value="<%=displayRst.Fields("lineNumber")%>"></td> -->
																		<td class="label"><%= displayRst.Fields("itemName")%></td>
																		<td class="label" width="50px" align=right><%= displayRst.Fields("quantity")%></td>
																		<td class="label" width="50px" align=right><%= displayRst.Fields("lineItemTotal").Value%></td>
																	</tr>
																	<%
																	cloneRst.Filter ="parentLineNumber=" & displayRst.Fields("lineNumber")
																	if cloneRst.Recordcount > 0 then
																		cloneRst.MoveFirst
																		while not cloneRst.Eof
																	%>
																	<tr name="sub">
																		<!-- <td><input type="radio" name="select" id="select" value="<%= cloneRst.Fields("lineNumber")%>"></td> -->																
																		<td class="label">&nbsp;&nbsp;&nbsp;<%= cloneRst.Fields("itemName")%></td>
																		<td class="label" width="50px" align=right><%= cloneRst.Fields("quantity")%></td>
																		<td class="label" width="50px" align=right><%= cloneRst.Fields("lineItemTotal").Value%></td>
																	</tr>
																	
																<%
																		cloneRst.MoveNext																
																		wend
																	end if
																	cloneRst.Filter = adFilterNone
																case "CU"
																%>
																	<tr name="main">
																		<!-- <td colspan=2><input type="radio" name="select" id="select" value="<%= displayRst.Fields("lineNumber")%>"></td> -->																					
																		<td class="label"><%= displayRst.Fields("itemName")%></td>
																		<td class="label" width="50px" align=right><%= displayRst.Fields("quantity")%></td>
																		<td class="label" width="50px" align=right><%= displayRst.Fields("lineItemTotal").Value%></td>
																	</tr>
																<%					
																	case "AC"
																%>
																		<tr name="main" onClick="selectRow(this);">
																			<!-- <td colspan=2><input type="radio" name="select" id="select" value="<%= displayRst.Fields("lineNumber")%>"></td> -->																				
																			<td class="label"><%= displayRst.Fields("itemName")%></td>
																			<td class="label" width="50px" align=right><%= displayRst.Fields("quantity")%></td>
																			<td class="label" width="50px" align=right><%= displayRst.Fields("lineItemTotal").Value%></td>
																		</tr>																

																
												<%
															end select
															displayRst.MoveNext
														wend	
													end if
												%>
												</table>
											</td>
										</tr>
								</table> <!-- table for border -->
							</div>
						</td>
					</tr>
					<!-- buttons -->
					<tr>
						<td align=center>
							<TABLE WIDTH="265px" BORDER=0 CELLSPACING=1 CELLPADDING=2 >
								<tr height=10px></tr>
								<!-- starch preference row -->
								<tr>
									<td class="label">Starch Preference</td>
									<td class="label"><%= Session("starchPref")%></td>
								</tr>
								<!-- finisf preference -->
								<tr>
									<td  class="label">Finish Preference</td>
									<td class="label"><%= Session("finishPref")%></td>
								</tr>
								<tr>
									<td align=left class="label">Date Due</td>
									<td class="label"><%= invoice.InvDueDate%></td>
								</tr>
								<tr height=55px>
									<td colspan=2 align="center">
										<INPUT style="width:100px;height:50px" type=button onClick="cancelForm();" value="Exit">
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table> <!-- 3rd column ends -->
			</td>
		</tr>
		</form>
	</table>
</BODY>
</HTML>
