<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<%
	dim query, rs
	dim taskid
	dim taskrs
	dim messageusername
	
	taskid = request.querystring("taskid")
	messageusername = request.querystring("messageusername")
	
	select case lcase(request.querystring("useraction"))
		case "closetask"
			addTaskNote taskid, request.querystring("note")
			closeTask taskid, messageusername
		case "addtasknote"
			addTaskNote taskid, request.querystring("note")
	end select

	function closeTask(taskid, messageusername)
		dim query
		
		query = "update task set dateclosed = getdate(), "
		query = query & " employeeclosed = '" & messageusername & "'"
		query = query & " where id = " & taskid

		qryexecute query
	end function

	
	
	query = "select * from task where id = " & taskid
	
	set taskrs = getdisconnectedrecordset(query)
	
	
	
	function getEmployeeAssignedToTask(taskid)
		dim query, rs
		dim result
		
		result = ""
		query = "select employeemessageid from employeetask where taskid = " & taskid
		set rs = getdisconnectedrecordset(query)
		while not(rs.eof or rs.bof)
			if result <> "" then
				result = result & ", "
			end if
			result = rs("employeemessageid")
			rs.movenext
		wend
		set rs = nothing
		
		getEmployeeAssignedToTask = result
	end function
	
	
	function getCustomerAssignedToTask(taskid)
		dim query, rs
		dim result
		
		result = ""
		query = "select customername from customertask where taskid = " & taskid
		set rs = getdisconnectedrecordset(query)
		while not(rs.eof or rs.bof)
			if result <> "" then
				result = result & ", "
			end if
			result = rs("customername")
			rs.movenext
		wend
		set rs = nothing
		
		getCustomerAssignedToTask = result
	end function
	
	function getTaskStatus(taskid)
		dim query, rs
		
		query = "select isnull(convert(varchar, dateclosed), 'Open') as status from task where id = " & taskid
		set rs = getdisconnectedrecordset(query)
		
		getTaskStatus = rs("status")
		
		set rs = nothing
	end function
	
	function getTaskDueDate(taskid)
		dim query, rs
		
		query = "select isnull(convert(varchar, datedue, 101), '') as duedate from task where id = " & taskid
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getTaskDueDate = rs("duedate")
		end if
	
		set rs = nothing
	end function
	

	sub addTaskNote(taskid, note)
		dim query
		
		query = "update task set description = description "
		query = query & " + Char(13) + Char(10) + Char(13) + Char(10) + '-- Appended by " & messageusername & " on " & date() & " -----' + Char(13) + Char(10) "
		query = query & " + '" & note & "'"
		query = query & " where id = " & taskid

		
		qryexecute query
	end sub
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript">
	function closeTask() {
		if(confirm("Close task <%=taskid%>?"))
		{
		    document.viewTask.action = "viewtask.asp?useraction=closetask&taskid=<%=taskid%>&messageusername=<%=messageusername%>"
            document.viewTask.submit();
		}
	}
	
	function closeTask() {
		cbs_prompt("Closing task <%=taskid%>.", handleCloseTask, '', true);
	}

	function handleCloseTask() {
        clearPromptMsg();
	    var taskResolution  = document.getElementById('inputTxtArea').value;
		if (taskResolution != null) {
			document.viewTask.action = "viewtask.asp?useraction=closetask&taskid=<%=taskid%>&messageusername=<%=messageusername%>&note=" + taskResolution;
            document.viewTask.submit();
		}
	}
	
	function appendNote() {
		cbs_prompt("Enter note", handleAddingNote, "", true);
	}

	function handleAddingNote() {
        clearPromptMsg();
	    var note  = document.getElementById('inputTxtArea').value;
		if(note != null)
		{
			document.viewTask.action = "viewtask.asp?useraction=addtasknote&taskid=<%=taskid%>&messageusername=<%=messageusername%>&note=" + note;
			document.viewTask.submit();
		}
	}
	

</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" <%if request.querystring("useraction") = "closetask" then%>onload="opener.window.location.reload();window.close();"<%end if%>>
<FORM name="viewTask" ID="viewTask" METHOD=POST  style="margin:0;padding:0">
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="closeTask()">Close Task</BUTTON>
		<BUTTON onclick="appendNote()">Append<BR>Note</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="window.close()">Close</BUTTON>
	</SPAN>
</DIV>

<TABLE style="background:#F8F8F8;margin:20px">
	<TR valign="top">
		<TD>To:</TD>
		<TD><INPUT readonly style="width:390px;border:1px inset;background:white" value="<%=getEmployeeAssignedToTask(taskrs("id"))%>"></TD>
	</TR>
	<TR valign="top">
		<TD>Customer:</TD>
		<TD><INPUT readonly style="width:390px;border:1px inset;background:white" value="<%=getCustomerAssignedToTask(taskrs("id"))%>"></TD>
	</TR>
	<TR valign="top">
		<TD>Status:</TD>
		<TD><INPUT readonly style="width:390px;border:1px inset;background:white" value="<%=getTaskStatus(taskrs("id"))%>"></TD>
	</TR>
	<TR valign="top">
		<TD>Due Date:</TD>
		<TD><INPUT readonly style="width:390px;border:1px inset;background:white" value="<%=getTaskDueDate(taskrs("id"))%>"></TD>
	</TR>
	<TR valign="top">
		<TD>Task Description:</TD>
		<TD>
			<DIV style="width:390px;height:320px;border:1px inset;background:white;overflow:auto">
			<%=replace(taskrs("description"), vbcrlf, "<br>")%>
			</DIV>
		</TD>
	</TR>
</TABLE>
	

</FORM>
</BODY>
</HTML>

<%
	set taskrs = nothing

%>
