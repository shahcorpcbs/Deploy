<%@ Language=VBScript %>
<!--#include file="../include/customerPaymentObj.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/codecs.inc" -->
<!--#include file="../include/ValidateFunction.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%

		dim ObjMiscSetUp, query, rs
		dim ccProcessorDomainID, cc_url, cc_key

        query = "update paymentbatch set Answer = 'test55' where batchId = 5"
        qryexecute query


%>
