<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/messages.asp" -->

<%

	dim ticketNumbers
	dim destination
	dim colorChange
	
	destination = Session("invoiceRedirect")

	ticketNumbers = request.querystring("ticketNumbers")

	Session("invoiceQueryString") = Request.QueryString
	
	function isInt(input)
		dim i, d
		
		isInt = true
		
		for i=1 to len(input)
			d = Mid(input,i,1)
			if Asc(d) < 48 OR Asc(d) > 57 then
				isInt = false
				exit for
			end if
		next
	
	end function

	function getTagColorCode(colorName)
		dim query, rs
		
		query = " select hexcolor from lotcolor where name = '" & trim(colorName) & "'"
		set rs = getdisconnectedrecordset(query)
		
		
		if rs.recordcount > 0 then
			getTagColorCode = "#" & rs("hexcolor")
		else
			getTagColorCode = colorName
		end if
	
		set rs = nothing
	end function
	
	
	function promptColorChange(newColor)
		if colorChange <> "" then
			colorChange = colorChange & ", "
		end if
		
		colorChange = colorChange & newColor
	
	end function
	
	function formatTicketTagBlock(department, startTagNumber, endTagNumber, lotNumber, lotColor)
		dim result

		result = "<DD style=""background:" & getTagColorCode(lotColor) & """>"
		
		result = result & "<span class=""department"">" & department & "</span>"
		
		if lotNumber <> "" then			
			result = result & lotNumber & "/"
		end if
	
		if startTagNumber <> "" then
			result = result & startTagNumber
			
			if startTagNumber <> endTagNumber then
				result = result & "-" & endTagNumber
			end if

			if startTagNumber = 0 and trim(lotColor) <> "" then
				promptColorChange "Change tag color to " & trim(lotColor) & "."
			end if
		else
			result = result & endTagNumber
		end if
	
		if trim(lotColor) <> "" then			
			result = result & " (" & trim(lotColor) & ")"
		end if
		
		result = result & "</DD>"
		
		formatTicketTagBlock = result
	end function
	
	function getHeaderForTag(rs)
		dim result
		
		getHeaderForTag = rs("invoiceNumber") & " " & rs("lotName") & "|" & rs("departmentName")
	
	end function
	
	function getTagsAsCSV(ticketNumbers)
		Dim query, rs
		Dim lastTagNumber
		Dim lastTagColor
		Dim groupFirstTagNumber
		Dim lastLotNumber
		dim result
		dim lastLotHeader
		dim currentLotHeader
		dim lastPrintedLotHeader
		dim lastLotHeaderParts
		dim lastPrintedLotHeaderParts
		
		lastTagNumber = ""
		lastTagColor = ""
		lastLotNumber = ""
		groupFirstTagNumber = ""
		lastLotHeader = ""
		lastPrintedLotHeader = ""
		currentLotHeader = ""
		
		query = "SELECT  ticket.invoiceNumber, Department.name as departmentName, tickettag.lotID, lotNumber, tickettag.ticketNumber, tagNumber AS TagNumber, isnull(tagColor, '') as tagColor, isnull(Lot.name, '') as lotName FROM TicketTag "
		query = query & " INNER JOIN Ticket ON TicketTag.ticketNumber = Ticket.ticketNumber "
		query = query & " LEFT OUTER JOIN Department ON TicketTag.departmentID = Department.departmentID "
		query = query & " LEFT OUTER JOIN Lot ON TicketTag.lotID = Lot.ID "
		query = query & " LEFT OUTER JOIN LotDefault ON Lot.lotDefaultID = LotDefault.lotDefaultID "
		query = query & " WHERE TicketTag.ticketNumber IN (" & ticketNumbers & ") "
		query = query & " ORDER BY Lot.lotDefaultID, TicketTag.ticketNumber, Department.departmentID, lotNumber, tagColor, "
		query = query & " CASE dbo.isInt(tagNumber) "
		query = query & " WHEN 0 THEN -1 "
		query = query & " ELSE cast(tagNumber as integer) "
		query = query & " END "

		Set rs = getDisconnectedRecordset(query)

		if rs.RecordCount > 0 then

			lastTagNumber = rs("tagNumber")
			lastTagColor = rs("tagcolor")
			lastLotNumber = rs("lotNumber")
			currentLotHeader = getHeaderForTag(rs)
			lastLotHeader = currentLotHeader
			lastPrintedLotHeader = "|"
			lastPrintedLotHeaderParts = split(lastPrintedLotHeader, "|")
			lastLotHeaderParts = split(lastLotHeader, "|")
			

						
			if isInt(lastTagNumber)	then groupFirstTagNumber = lastTagNumber
			

			rs.MoveNext

			while not (rs.eof or rs.bof)
				currentLotHeader = getHeaderForTag(rs)
				lastLotHeaderParts = split(lastLotHeader, "|")

				if isInt(lastTagNumber) then
					if trim(lastLotNumber) = trim(rs("lotNumber")) _
					and trim(lastTagColor) = trim(rs("tagcolor")) _
					and trim(clng(lastTagNumber) + 1) = trim(rs("tagNumber")) _
					and lastLotHeader = currentLotHeader  then
						lastTagNumber = rs("tagNumber")
						lastTagColor = rs("tagcolor")
						lastLotNumber = rs("lotNumber")
						lastLotHeader = currentLotHeader
					else

					'response.write lastLotHeaderParts(0) & "=" & lastPrintedLotHeaderParts(0) & "<br>"
					
						if lastLotHeaderParts(0) <> lastPrintedLotHeaderParts(0) then
							result = result & "<DT>" & lastLotHeaderParts(0) & "</DT>"
							lastPrintedLotHeader = lastLotHeader
							lastPrintedLotHeaderParts = split(lastPrintedLotHeader, "|")
						end if
						
						
						result = result & formatTicketTagBlock(lastLotHeaderParts(1), groupFirstTagNumber, lastTagNumber, lastLotNumber, lastTagColor)
		
						lastTagNumber = rs("tagNumber")
						lastTagColor = rs("tagcolor")
						lastLotNumber = rs("lotNumber")
						lastLotHeader = currentLotHeader
						
						if isInt(lastTagNumber)	then
							groupFirstTagNumber = lastTagNumber
						else
							groupFirstTagNumber = ""
						end if
					end if
				else
				
					if lastLotHeaderParts(0) <> lastPrintedLotHeaderParts(0) then
						result = result & "<DT>" & lastLotHeaderParts(0) & "</DT>"
						lastPrintedLotHeader = lastLotHeader
						lastPrintedLotHeaderParts = split(lastPrintedLotHeader, "|")
					end if
					
					result = result & formatTicketTagBlock(lastLotHeaderParts(1), groupFirstTagNumber, lastTagNumber, lastLotNumber, lastTagColor)
	
					lastTagNumber = rs("tagNumber")
					lastTagColor = rs("tagcolor")
					lastLotNumber = rs("lotNumber")
					lastLotHeader = currentLotHeader
					
					if isInt(lastTagNumber)	then
						groupFirstTagNumber = lastTagNumber
					else
						groupFirstTagNumber = ""
					end if
				end if

				rs.MoveNext
			wend

			lastLotHeaderParts = split(lastLotHeader, "|")
			
			if lastLotHeaderParts(0) <> lastPrintedLotHeaderParts(0) then
				result = result & "<DT>" & lastLotHeaderParts(0) & "</DT>"
				lastPrintedLotHeader = lastLotHeader
			end if
						
			result = result & formatTicketTagBlock(lastLotHeaderParts(1), groupFirstTagNumber, lastTagNumber, lastLotNumber, lastTagColor)
	
		end if
		
		getTagsAsCSV = result
	end function
	
	
	function getInvoiceNumbers(ticketNumbers)
		dim query, rs
		dim result
		
		query = " select invoicenumber from ticket where ticketnumber in (" & ticketNumbers & ")"

		set rs = getdisconnectedrecordset(query)
		
		while not (rs.eof or rs.bof)
			if result <> "" then result = result & ","
			result = result & rs("invoicenumber")
			rs.movenext
		wend

		set rs = nothing
		
		getInvoiceNumbers = result
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">



<STYLE  type="text/css" >
	#TicketTagList {
		margin: 10px;
	}
	#TicketTagList .department {
		width: 200px;
		overflow: hidden;
		border-right: 1px dotted black;

		margin-right: 10px;
	}
	#TicketTagList DD {
		padding: 5px;
		font-size: 18px;
	}
	#TicketTagList DT {
		padding: 5px;
		font-size: 20px;
		font-weight: bold;
	}
	#TicketTagContainer  {
		padding: 20px;
	}
	#TicketTagContainer h3 {
		margin: 0;
		padding: 0;
	}
</STYLE>

 
<script language="javascript" type="text/javascript">
	
	function 	promptColorChange() {
			var el;
			el = document.getElementById('colorChange');
			if(el) {
				if(el.value != '') {
					cbs_alert(el.value);	
				}
			}
	}

	function exit() {
		document.addLotTags.action = "<%=destination%>";
		document.addLotTags.submit();
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="promptColorChange();">
<!-- #include file="../include/banner.inc" -->
<FORM name="addLotTags" ID="addLotTags" METHOD=POST  style="margin:0;padding:0">
<H1>Invoice Tags</H1>
<BR /><BR />
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">

	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<%
	if ticketNumbers <> "" then 
%>
<div id="TicketTagContainer">
<DL id="TicketTagList">
<%=getTagsAsCSV(ticketNumbers)%>
</DL>
</div>
<%
	end if
%>

<% if colorChange <> "" then %>
<div style="text-align:center; border-top: 2px solid black; font-size: 30; font-weight: bold"><%=colorChange%></div>
<% end if %>

<INPUT type="hidden" id="colorChange" name="colorChange" value="<%=colorChange%>">
</FORM>
</BODY>
</HTML>
