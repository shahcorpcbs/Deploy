<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim ticketNo
	dim creationDate
	dim creationTime
	dim totalAdditions
	dim totalCoupons
	dim storeInfo
	dim totalPayments
	dim totalOverRides
	dim empName
	dim totalDiscounts
	dim sInvoicenumber
	dim strpayment
	dim objPayments
	
	ticketNo = Request.QueryString("ticketNo")
	sInvoiceNumber = Request.QueryString("invoiceNo")
	getCreationTranHistory
	getPayments
	
	sub getCreationTranHistory()
		dim ssql
		dim objResultSet
		
		ssql = "SELECT logDate, additions, coupons, discounts, storeName, payments, overriddenAmount, " _
				& " employeeName FROM TicketLog Where ticketNumber=" & CLng(ticketNo) _
				& " And logType='C'" 
				
		set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Recordcount > 0 then
			objResultSet.MoveFirst
			creationDate = FormatDateTime(objResultSet.Fields("logDate").Value, vbShortDate)
			creationTime = FormatDateTime(objResultSet.Fields("logDate").Value, vbLongTime)
			totalAdditions = formatcurrency(objResultSet.Fields("additions").Value)
			totalCoupons = formatcurrency(objResultSet.Fields("coupons").Value)
			totalDiscounts = formatcurrency(objResultSet.Fields("discounts").Value)
			storeInfo = objResultSet.Fields("storeName").Value
			totalPayments = objResultSet.Fields("payments").Value
			totalOverRides = formatcurrency(objResultSet.Fields("overriddenAmount").Value)
			empName = objResultSet.Fields("employeeName").Value
		end if
	end sub
	
	sub getPayments()
		dim ssql
		dim objResultSet
		
		ssql = "SELECT t.onAccountamount, p.amountpaid, p.paymentTypename " _
				& " FROM TicketLog  t , payment P Where t.ticketNumber=" & CLng(ticketNo) _
				& " And logType='C'and t.paymentgroupnumber *= p.paymentgroupnumber" 
	
		set objPayments =getdisconnectedrecordset(ssql)

		
	end sub
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Creation Transcation History</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function cancelForm(){
		var ticketNo;
		ticketNo = document.creationTranHistoryForm.ticketNumber.value;
		document.creationTranHistoryForm.action="finishedInvoices.asp?userAction=fromDetail&ticketNumber=" +  ticketNo;
		document.creationTranHistoryForm.submit();
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Creation Invoice Transaction History
<%=sInvoicenumber%></B>
<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >	
<FORM id="creationTranHistoryForm" name="creationTranHistoryForm" action="CreationTransactionHistory.asp" method="post">
	<INPUT type="hidden" name="ticketNumber" value="<%= ticketNo %>">
	<tr height=20px></tr>
	<tr>
		<td>
			<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
				<TR>
					<TD align=right class="label">Creation Date</TD>
					<TD>
						<INPUT id=txtCreationDt name=txtCreationDt class=text value="<%= creationDate%>" readonly>
					</TD>
				</TR>
				
				<TR>
					<TD align=right class="label">Creation Time</TD>
					<TD>
						<INPUT id=txtCreationTime name=txtCreationTime class=text value="<%= creationTime%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Additions</TD>
					<TD>
						<INPUT id=txtAdditions name=txtAdditions class=text value="<%= totalAdditions%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Coupons</TD>
					<TD>
						<INPUT id=txtCoupons name=txtCoupons class=text value="<%= totalCoupons%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Discounts</TD>
					<TD>
						<INPUT id=txtDiscount name=txtDiscount class=text value="<%= totalDiscounts%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Store Info</TD>
					<TD>
						<INPUT id=txtStoreInfo name=txtStoreInfo class=text value="<%= storeInfo%>" readonly>
					</TD>
				</TR>
				
				<TR>
					<TD align=right class="label">Payments</TD>
					<TD>
						<INPUT id=txtPayments name=txtPayments  class=text value="<%= totalPayments%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Payment Details</TD>
					<TD>
						<SELECT name=txtPayments id=txtPayments size=4 style="width:175px;">
						<% if objPayments.recordcount >0 then
							if objPayments("onAccountamount")>0 then
								strpayment  = formatCurrency(objPayments("onAccountamount") ) & " " & "On Account" %>
								<option><%=strpayment%></option>
							<%end if %>
							<%while not objPayments.eof
									if objPayments("amountpaid") > 0 then
										strpayment = formatCurrency(objPayments("amountPaid"), 2) & " " & objPayments("paymentTypeName")%>
										<option><%=strpayment%></option>
								<%end if  
							objPayments.movenext
							wend
						END if
						objPayments.close
						set objPayments = nothing	
						%>
													
						
						</select>
						
					</TD>
				</TR>
				
				<TR>
					<TD align=right class="label">Over Rides</TD>
					<TD>
						<INPUT id=txtOverRide name=txtOverRide class=text value="<%= totalOverRides%>" readonly>
					</TD>
				</TR>
				
				<TR>
					<TD align=right class="label">Employee Name</TD>
					<TD>
						<INPUT id=txtEmpName name=txtEmpName class=text value="<%= empName%>" readonly>
					</TD>
				</TR>
			</TABLE>
		</td>
	</tr>
	<tr>
		<td>
			<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<TR>
						<td width=45%></td>
						<TD align=center width=40px>
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button style="background-image:url(../images/ok.gif);" onclick="cancelForm();">
						</td>
						<td width=25px>
						<td align=center width=40px>
							<INPUT class=touchnoborder id=okButton name=okButton type=button style="background-image:url(../images/Cancel.gif);" onClick="cancelForm();">
						</TD>
						<td width=35%></td>
					</TR>     
			</TABLE>
		</td>
	</tr>
</FORM>   
</table>
</BODY>
</HTML>

