<%@ Language=VBScript %>
<%option explicit%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("userAction")%>

<%

	dim query, rs, connectionId, storeType
	dim connStoreName, connIP, useraction

	connectionId = Request.QueryString("connectionId")
	useraction = trim(request.querystring("useraction"))

    query = "select storeType from store"
    set rs = getdisconnectedrecordset(query)
    storeType = cInt(rs("storeType"))

	if (useraction = "update") then
		updateDatabase()
	elseif userAction = "create" then

	end if

	query = "select StoreName, IPAddress from StoreConnectionHistory where id = " & connectionId
	set rs = getdisconnectedrecordset(query)

    connStoreName = rs("StoreName")
    connIP = rs("IPAddress")


    function updateDatabase
        dim selectedSetupId
        selectedSetupId = Request.QueryString("selectedSetupId")

        query = "update StoreConnectionHistory set StoreId = " & selectedSetupId
        qryexecute query

        if storeType = 1 then
            query = "update DropStoreSetup "
        else
            query = "update PlantStoreSetup "
        end if
        query = query & "set ipAddress = (select IPAddress from StoreConnectionHistory where id = " _
            & connectionId & "), StoreName = (Select StoreName from StoreConnectionHistory where id = " _
            & connectionId & ") where id = " & selectedSetupId

        qryexecute query

        Response.Redirect("/mainapp/plantManifests.asp")
    end function

%>

<HTML>
<HEAD>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript">


function connectSetup() {
    if ($("#setupIdSel").val() == "0" || $("#setupIdSel").val() == "") {
        cbs_alert("Select Setup")
        return;
    }

	document.connectManifest.action = "?useraction=update&connectionId=<%=connectionId%>&selectedSetupId=" + $("#setupIdSel").val();
	document.connectManifest.submit();
}

function createNewSetup() {

	document.connectManifest.action = "/setup/editPlantSetup.asp?connectionId=<%=connectionId%>";
	document.connectManifest.submit();
}

function cancel() {
	document.connectManifest.action = "/mainapp/plantManifests.asp";
	document.connectManifest.submit();
}



</script>
<BODY onLoad="" topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Assign Connection to Store</H1>

<FORM name="connectManifest" ID="connectManifest" method="post" ACTION="">
<TABLE WIDTH=500 STYLE="" ALIGN=center BORDER=0 CELLSPACING=1 CELLPADDING=5>

	<tr height=100px><td>&nbsp</td></tr>

	<tr height=50px>
	    <th>Unassigned Connection</th>
	    <th style="text-align: left"> <% if storeType = 1 then %>Drop<% else %>Plant<% end if %> Store Setups</th>
	</tr>
	<tr>
	    <td style="white-space: nowrap; padding-right: 50px"><%=connStoreName %> (<%= connIP %>) </td>
	        <td >
                    <select style="font-size: larger" id="setupIdSel" >
                    <option value="0">Select</option>
                        <% if storeType = 1 then
                            query = "select id, nickName, ipAddress from DropStoreSetup "
                        else
                            query = "select id, nickName, ipAddress from PlantStoreSetup "
                        end if
                        set rs = getdisconnectedrecordset(query)
                        while not(rs.eof or rs.bof)
                        %>
                        <option value='<%= rs("id")%>'>
                        <%= rs("nickName")%> (<%= rs("ipAddress")%>)</option>
                        <%
                        	rs.movenext
                        	wend
                        %>
                    </select>
            <td>
    </tr>
	<tr height=75px><td>&nbsp</td></tr>
	<TR>
		<TD COLSPAN="2" ALIGN="center">
			<INPUT Style="height:50px;width:100px" type="button" Value="Connect" onClick="connectSetup();">
			<INPUT Style="height:50px;width:100px; white-space: normal; vertical-align: top" type="button" Value="Create New Setup" onClick="createNewSetup();">
			<INPUT Style="height:50px;width:100px" type="button" Value="Cancel" onClick="cancel();">
		</TD>
	</TR>
</TABLE>
</FORM>


</BODY>
</HTML>
