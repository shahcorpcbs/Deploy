<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/messages.asp" -->

<%
	dim fromaccount
	dim message
	dim messagetext
	dim toaccount
	dim subjecttext
	
	fromaccount = getReqVar("fromaccount")
	messagetext = request.form("messagetext")
	toaccount = request.form("toaccount")
	subjecttext = request.form("subjecttext")
	
	select case lcase(request.querystring("useraction"))
	case "sendmessage"
		sendMessage
	case "reply"
		fillReply request.querystring("messageid")
	end select
	
	
	sub fillReply(messageid)
		dim query, rs
		
		query = "select messageitem.*, fromaccount.username as fromusername, toaccount.username as tousername "
		query = query & " from messageitem inner join messageaccount as fromaccount on messageitem.fromaccount = fromaccount.id "
		query = query & " inner join messageaccount as toaccount on messageitem.toaccount = toaccount.id "
		query = query & " where messageitem.id = " & messageid

		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			fromaccount = rs("tousername")
			toaccount = rs("fromusername")
			messagetext = vbcrlf & vbcrlf & vbcrlf & "-- Original Message  " & rs("datereceived") & " ----------------- " & vbcrlf
			messagetext = messagetext & rs("messagetext")
			subjecttext = "re: " & rs("subjecttext")
		end if
	
		set rs = nothing
	end sub
	
	
	
	sub sendMessage
		dim query, rs
		dim fromaccountid
		dim toaccountid
		dim messagetext
		dim subjecttext
		dim accountnames
		dim accountname
		
		accountnames = split(request.form("toaccount"), ",")
		
		
		
		for each accountname in accountnames
			if getMessageAccountID(trim(accountname)) = "" then
				message = "Could not send to account name '" & accountname & "'"
				exit sub
			end if
		next
		
		
		for each accountname in accountnames
			fromaccountid = getMessageAccountID(trim(fromaccount))
			toaccountid = getMessageAccountID(trim(accountname))
			messagetext = request.form("messagetext")
			subjecttext = request.form("subjecttext")
			
			query = "insert into messageitem (fromaccount, toaccount, messagetext, subjecttext) "
			query = query & "values (" & fromaccountid
			query = query & "," & toaccountid
			query = query & ",'" & messagetext & "'"
			query = query & ",'" & subjecttext & "'"
			query = query & ")"
	
			qryexecute query
		next

	end sub
	
	
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	
	function getMessageAccountID(username)
		dim query, rs

		query = "select id from messageaccount where lower(username) = '" & lcase(username) & "'"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getMessageAccountID = rs("id")
		else
			getMessageAccountID = ""
		end if

		set rs = nothing
	end function
	
	function getMessageServerURL()
		dim query, rs
		
		query = "select isnull(messageServerURL, '') as messageServerURL from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getMessageServerURL = trim(rs("messageServerURL"))
		
		set rs = nothing
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">


<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<SCRIPT language="javascript" type="text/javascript">
	function sendMessage() {
		var charactersRemaining;

		charactersRemaining = getMaxMessageLength() - getMessageLength();
		var handled = false;

		//alert("Inside send message");
		if(charactersRemaining < 0)
		    cbs_confirm("Message is over the 4000 character limit.  Continue sending the message with the last " + -charactersRemaining + " characters removed?", trimAndSend)
		else
            finishSendMessage(charactersRemaining);
	}

	function trimAndSend() {
        clearConfirmMsg();
        messagecompose.messagetext.value = messagecompose.messagetext.value.substr(0, 4000);
        finishSendMessage(0);
	}

    function finishSendMessage(charactersRemaining) {
		if(charactersRemaining >= 0) {
			messagecompose.subjecttext.value = messagecompose.subjecttext.value.substr(0, 250);
			document.messagecompose.action = "?useraction=sendmessage"
			document.messagecompose.submit();
		}
    }

	function showMessageBook() {
		var w = window.open("<%=getMessageServerURL()%>/MainApp/MessageAddressBook.asp?fromaccount=<%=fromaccount%>", "MessageAddressBook", "status=no,scrollbars=yes,width=300,height=600,modal=yes");
	}
	
	function mb_callback(addresses) {
		document.messagecompose.toaccount.value = addresses;
	}
	
	function updateRemainingLength(src, dest, max) {
		dest.value = max - src.length;
	}
	
	function getMessageLength() {
		return messagecompose.messagetext.value.length;
	}
	
	function getMaxMessageLength() {
		return messagecompose.maxMessageCharacters.value;
	}
	
	
</SCRIPT>


</HEAD>

<BODY STYLE="margin:0;padding:0;background:#F8F8F8"
<%if lcase(request.querystring("useraction")) = "sendmessage" and message = "" then%>onload="window.close();"
<%else%>onload="updateRemainingLength(messagecompose.messagetext.value, messagecompose.remainingLength, messagecompose.maxMessageCharacters.value);document.messagecompose.messagetext.focus();"<%end if%>>

<FORM id="messagecompose" name="messagecompose" method="post" style="margin:0;padding:0;">

<input type="hidden" id="maxMessageCharacters" value="4000" />

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="sendMessage()">Send</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="window.close()">Close</BUTTON>
	</SPAN>
</DIV>



<table style="background:#F8F8F8;margin:20px">
<% if message <> "" then %>
	<tr>
		<td></td><td><span style="color:red"><%=message%></td>
	</tr>
<% end if %>
	<tr>
		<td>From:</td><td><input name="fromaccount" style="width:500px;border:1px inset;background:white" readonly value="<%=fromaccount%>"></td>
	<tr>

	<tr>
		<td><input style="width:60px" type="button" value="To:" onclick="showMessageBook()"></td><td><input name="toaccount" style="width:500px;border:1px inset;background:white" value="<%=toaccount%>"></td>
	<tr>

	<tr>
		<td>Subject:</td><td><input name="subjecttext" id="subjecttext" style="width:500px;border:1px inset;background:white" value="<%=subjecttext%>"></td>
	</tr>
	
	<tr>
		<td></td><td><textarea name="messagetext" id="messagetext" style="width:500px;border:1px inset;background:white;height:400px;overflow:auto" scroll="auto" onkeyup="updateRemainingLength(this.value, remainingLength, maxMessageCharacters.value)" ><%=messagetext%></textarea></td>
	</tr>
	
	<tr>
		<td></td><td><input id="remainingLength" value="4000" style="width:50px;text-align:right" readonly /> characters remaining.</td>
	</tr>
</table>

</FORM>
</BODY>
</HTML>
