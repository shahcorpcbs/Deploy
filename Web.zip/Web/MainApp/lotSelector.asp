<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim isSubmitted
	dim userAction
	dim ticketno
	dim lotid
	dim lotRst
	dim pieces
	dim tNo
	dim tNos
	dim dept
	dim lotField
	dim tData
	dim tPart

	isSubmitted = Request.QueryString("submitted")
	userAction = Request.QueryString("userAction")
	ticketNo = Request.QueryString("txtTicketNo")
	tNos = split(ticketNo, ",")

 	if (isSubmitted) then
 		for each tNo in tNos
 		    lotField = "lot"&tNo
 			tData = Request.Form(lotField)
 			tPart = split(tData,"|")
			lotid = tPart(0)
			pieces = tPart(1)
			if (userAction = "add") then
				updateDatabase()
			end if
		next
		Response.Redirect "customerfunctions.asp"
	end if


	session("s_errmessage") = ""


	function getValidLots(ticketno)

		dim sqltxt, allDepts, totPieces, wherepart, whereclause, detRst, deptRst

		wherepart = " and l.id in (select lotid from lotdepartment where deptid = "

		sqltxt = "select departmentid, sum(quantity*packagedQuantity) as pieces from ticketlineitem "
		sqltxt = sqltxt & "where ticketlinetype in ('IT','AC') and ticketnumber = " & ticketno
		sqltxt = sqltxt & " group by departmentid"

		set detRst = getdisconnectedRecordSet(sqltxt)

		if detRst.recordcount > 0 then
			whereclause = wherepart & CStr(detRst("departmentid"))
			totPieces = clng(detRst("pieces"))
		detRst.MoveNext
		While Not detRst.eof
			whereclause = whereclause & ") " & wherepart & CStr(detRst("departmentid"))
			totPieces = totPieces + clng(detRst("pieces"))
			detRst.MoveNext
		Wend
		whereclause = whereclause & ")"
		pieces = totPieces

		'creating a holder for valid lots
		sqltxt = "select distinct l.id, l.name, lc.hexcolor from lot l, lotcolor lc, lotDepartment ld"
		sqltxt = sqltxt & " where l.status = 'O'"
		sqltxt = sqltxt & " and l.color = lc.name " & whereclause
		sqltxt = sqltxt & " and maxgarments - currentgarments >= " & totPieces

		set lotRst = getDisconnectedRecordSet(sqltxt)

		sqltxt = "select dbo.pivotTicketDepartments(" & ticketno & ",',') as depts"
		set deptRst = getDisconnectedRecordSet(sqltxt)
		dept = deptRst("depts")
		set deptRst = nothing
		end if

	end function



	function updateDatabase()
		dim sqltxt

  		sqltxt = " update ticket set lotid = " & lotid & " where ticketnumber = " & tNo
		qryexecute sqltxt

        sqltxt = "update lot set currentgarments = currentgarments + " & pieces & " where id =" & lotid
        qryexecute sqltxt


	end function


%>
<HTML>
<HEAD>
<TITLE>Choose Lot</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function submitForm() {
		var ticketNo;

		ticketNo = document.lotSelector.txtTicketNo.value;
		document.lotSelector.action = "?submitted=true&userAction=add&txtTicketNo=" + ticketNo
		document.lotSelector.submit();
	}

	function cancelForm() {
		document.lotSelector.action = "customerfunctions.asp";
		document.lotSelector.submit();
	}



</script>
<BODY topmargin=0 leftmargin=0

>
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->
<H1>Choose Lot</H1>
<FORM id="lotSelector" name="lotSelector" action="" method="post" >
	<input type=hidden name="txtTicketNo" value="<%=ticketno%>">

	<TABLE ALIGN=center width=800px BORDER=0 CELLSPACING=0 CELLPADDING=2 >
		<% if len(trim(session("s_errMessage")) ) > 0 then %>
		<tr>
			<td width = 40px></td>
			<td colspan=5><font color = red size =2><b><%= session("s_errMessage")%></b></font></td>
		<td></td>
	</tr>
		<% end if %>



	<% if not (isSubmitted) then
	   for each tNo in tNos %>
	   		<tr height=100 align=left style=font-size:24px>
			<%  getValidLots(tNo)  %>
				<input type=hidden name="pieces" value="<%=pieces%>">
				<td>Lot for Ticket <%=tNo%>&nbsp(<%=dept%>)</td>
				<td><SELECT NAME="lot<%=tNo%>" style="width:250px;font-size:24px">
			<% if lotRst.recordcount > 0 then
					while not lotRst.eof%>
				<OPTION id="<%=lotRst("id")%>|<%=pieces%>" name="LotNo" value="<%=lotRst("id")%>|<%=pieces%>|<%=tNo%>" style="background:<%=lotRst("hexcolor")%>" ><%=lotRst("name")%>

					<% lotRst.moveNext
					wend %>
					</SELECT></td></tr>
			<% end if
		next	%>
	  <%end if %>
	   <tr>
	   <td colspan = 2 align=center>
		<INPUT class=touchNoBorder id=done name=done type=button value="" style="background-image:url(../images/ok.gif);" onClick="submitForm();">
	  </td></tr>
	  <!-- <input class=touch type=button id=newLot name=newLot value="New Lot" style="width:300;height:50;background=white" onclick=createNewLot()>-->
	</TABLE>
</FORM>

</BODY>
</HTML>