<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->

<!--#include file="../external/include.asp" -->
<%
	include getBarcodeEncoderFilename()
	function getBarcodeEncoderFilename()
		on error resume next
		getBarcodeEncoderFilename = "/include/barcode.asp"
		getBarcodeEncoderFilename = getMSVar("BarcodeEncoderFile")
	end function
%>

<%
	dim routeFilter
	dim objresult
	dim cnt
	dim inactiveCnt
	
	routeFilter = ""

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

	
	function AppendCustomerSeqs(current, rs)
	
		AppendCustomerSeqs = current
		
		if rs.recordcount > 0 then
			rs.movefirst
			while not rs.eof
				if AppendCustomerSeqs <> "" then
					AppendCustomerSeqs = AppendCustomerSeqs & ","
				end if
				AppendCustomerSeqs = AppendCustomerSeqs & rs("customersequencenumber")
				rs.movenext
			wend
		end if

	end function
	
	function getCustomerFilter(custIdent)
		getCustomerFilter = ""
		if Session("filterRouteNumber") <> "" then
			getCustomerFilter = " " & custIdent & ".routeNumber = " & Session("filterRouteNumber")
		end if
		if routeFilter <> "" then
			if routeFilter > 0 then
			if getCustomerFilter <> "" then getCustomerFilter = getCustomerFilter & " AND "
			getCustomerFilter = " " & custIdent & ".routeNumber = " & routeFilter
			end if
		end if
		if Session("filterCommercialAccount") <> "" then
			if getCustomerFilter <> "" then getCustomerFilter = getCustomerFilter & " AND "
			getCustomerFilter = getCustomerFilter & "( " & custIdent & ".parentCustomerSeq = " & Session("filterCommercialAccount") & " OR " & custIdent & ".customerSequenceNumber = " & Session("filterCommercialAccount") & ") "
		end if
		if getCustomerFilter <> "" then
			getCustomerFilter = " AND (" & getCustomerFilter & ") "
		end if
	end function
	
	function SmartSearch(smartquery)
		dim selectHead
		dim query, rs
		dim customerseq
		dim phoneSearch
		
		phoneSearch = smartquery
		phoneSearch = replace(phoneSearch, "(", "")
		phoneSearch = replace(phoneSearch, ")", "")
		phoneSearch = replace(phoneSearch, "-", "")
		phoneSearch = replace(phoneSearch, " ", "")

		customerseq = ""

		query = "select c.customersequencenumber from customer c "
		query = query & " inner join ticket t on c.customersequencenumber = t.customersequencenumber "
		query = query & " inner join ticketlineitem tli on t.ticketnumber = tli.ticketnumber "
		query = query & " where tli.invoicenumber = '" & DBStr(trim(smartquery)) & "'"

		query = query &  getCustomerFilter("c")
		
		set rs = getdisconnectedrecordset(query)
		customerseq = AppendCustomerSeqs(customerseq, rs)

		
		query = "select c.customersequencenumber from customer c, ticket t where c.customersequencenumber = t.customersequencenumber and t.invoicenumber = '" & DBStr(trim(smartquery)) & "'"
		query = query &  getCustomerFilter("c")
		
		set rs = getdisconnectedrecordset(query)
		customerseq = AppendCustomerSeqs(customerseq, rs)
		
		query = "select c.customersequencenumber from customer c where c.lastname like '" & DBStr(trim(smartquery)) & "%' or '" & DBStr(trim(phoneSearch)) & "' in (mainphone, mainareacode + mainphone, AltPhone, AltAreaCode + AltPhone, cellphone, right(cellphone, 7))"
		query = query & getCustomerFilter("c")
		
		set rs = getdisconnectedrecordset(query)
		customerseq = AppendCustomerSeqs(customerseq, rs)
		
		query = "select distinct c.customersequencenumber from customer c, ticket t, ticketLineItemTaggedItem tli, taggedPiece tp where c.customersequencenumber = t.customersequencenumber and t.ticketnumber = tli.ticketnumber and tp.taggeditemid = tli.taggeditemid and tp.heatsealid = '" & DBStr(trim(smartquery)) & "'"
		query = query & getCustomerFilter("c")
		
		set rs = getdisconnectedrecordset(query)
		customerseq = AppendCustomerSeqs(customerseq, rs)
		
		if customerseq = "" then
			customerseq = checkForBarcode(smartquery)
		end if
		
		if customerseq <> "" then
			query = "select isactive, dbo.getcustomeropeninvoices(customersequencenumber, -1, null, null) as openInvoiceCount, dbo.getcustomeropeninvoices(customersequencenumber, 1, null, null) as rackedInvoiceCount, customersequencenumber, isnull(lastname, '') as lastname, isnull(firstname, '') as firstname, dbo.formatPhone(mainareacode, mainphone) as phonenumber, r.name as 'routeName', showNotesonEachAccess, isnull(C.shippingAddress1, '') as address, isSuspended from customer C left outer join  Route R  on c.routenumber = r.routenumber where c.customersequencenumber in (" & customerseq & ") "
			query = query & getCustomerFilter("c")
			query = query & " order by lastname, firstname "
			
			set SmartSearch= getdisconnectedrecordset(query)
		else
			set SmartSearch = rs
		end if
	end function
	
	set objresult = SmartSearch(request.form("searchText"))

	
	
	
	function checkForBarcode(smartsearch)
		dim barcode
		dim query, rs

		on error resume next
		
		set barcode = new BarcodeEncoder

		if barcode.LoadBarcode(smartsearch) then
			if barcode.TicketNumber <> "" then
				query = " select customer.customersequencenumber from "
				query = query & " ticket "
				query = query & " inner join customer on ticket.customersequencenumber = customer.customersequencenumber "
				query = query & " where ticket.ticketnumber = " & barcode.TicketNumber
			elseif barcode.InvoiceNumber <> "" then
				query = " select customer.customersequencenumber from "
				query = query & " ticket "
				query = query & " inner join customer on ticket.customersequencenumber = customer.customersequencenumber "
				query = query & " where ticket.invoicenumber = '" & dbstr(barcode.InvoiceNumber) & "'"
			end if
			
			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				checkForBarcode = rs("customersequencenumber")
			end if
			
			set rs = nothing
		end if
	end function
%>


<TABLE class="itable" BORDER=0 CELLSPACING=0 CELLPADDING=0>
	<TR>
		<TH align="left">Last Name</TH>
		<TH align="left">First Name</TH>
		<TH align="left">Phone</TH>
		<TH align="left">Address</TH>
		<TH align="left">Invoices</TH>
		<TH align="left">Route</TH>
	</TR>
	<%
		if objresult.recordcount <=0 then %>
	<TR>
		<TD colspan="4" align="center">Search criteria could not find any matching customers</TD>
	</TR>
	<%	else
	
		cnt = 0
		inactiveCnt = 0
		
		while not objresult.EOF
					
	%>
	<TR id="customer" <%if objresult("isSuspended") then%> style='color:red; text-decoration: line-through;'<%end if%> isactive="<%if objresult("isactive") then%>1<%else%>0<%end if%>" rackedinvoices="<%=objresult("rackedInvoiceCount")%>" openinvoices="<%=objresult("openInvoiceCount")%>" routenumber="<%=objresult("routeName")%>" customerseq="<%=objresult("customersequencenumber")%>" shownotes="<%=lcase(objresult("showNotesOnEachAccess"))%>"  onDblClick="selectRow(this);selectCustomer();" onClick="selectRow(this)" onKeyUp="selectOnEnter()" <%if not objresult("isactive") then%>style="color:#f00;font-weight:bold;display:none"<%end if%>>
		<TD><%=Server.HTMLEncode(objresult("lastname"))%>&nbsp</TD>
		<TD><%=Server.HTMLEncode(objresult("firstname"))%>&nbsp</TD>
		<TD><%=objresult("phonenumber")%>&nbsp</TD>
		<TD><%=Server.HTMLEncode(objresult("address"))%>&nbsp</TD>
		<TD><%=Server.HTMLEncode(objresult("rackedInvoiceCount") & " / " & objresult("openInvoiceCount"))%>&nbsp</TD>
		<TD><%=objresult("routeName")%>&nbsp</TD>
	</TR>
	<%
			cnt = cnt + 1
			
			if cnt mod 10 = 0 then response.flush
			
			if not objresult("isactive") then	inactiveCnt = inactiveCnt + 1
				
			objresult.movenext
		wend
		
		objresult.close
		set objresult = nothing
		end if
	%>
	<% if inactiveCnt > 0 then %>
	<TR onclick="toggleInactives()" style="background:#eee">
		<TD colspan="6" align="center" id="showInactiveButton">
			Click here to show <%=inactiveCnt%> inactive customer(s)
		</TD>
	</TR>	
	<% end if %>
</TABLE>


