<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim transactionID
	dim terminalID
	dim storeID
	dim employeeID
	
	storeID = getReqVar("storeID")
	terminalID = getReqVar("terminalID")
	employeeID = getReqVar("employeeID")
	
	transactionID = getReqVar("transactionID")
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function d_rackTable()
		dim query, rs
		dim invoiceNumbers
		dim invoiceNumber
		dim rackLocations
		
		if transactionID <> "" then
			invoiceNumbers = split(transactionID, ",")
			
			Response.Write "<TABLE style=""width:500px;margin:50px;background:white;border:2px inset"">"
			Response.Write "<TR>"
			Response.Write "<TH style=""height:40px"" align=""center"">Invoice</TH>"
			Response.Write "<TH style=""height:40px"" align=""center"">Rack Location(s)</TH>"
			Response.Write "</TR>"
			for each invoiceNumber in invoiceNumbers
				query = "select dbo.pivotTicketRackLocationBrief(" & invoiceNumber & ", ',') as rackLocations"
				set rs = getdisconnectedrecordset(query)
				
				
				if rs.recordcount > 0 then
					rackLocations = rs("rackLocations")
					query = "select invoicenumber from ticket where ticketnumber = " & invoiceNumber
					set rs = getdisconnectedrecordset(query)
					
					Response.Write "<TR>"
					Response.Write "<TD align=""center""><H2>" & rs("invoicenumber") & "</H2></TD>"
					Response.Write "<TD align=""center""><H2>" & rackLocations & "</H2></TD>"

					Response.Write "</TR>"
				end if
				
			next
		
			Response.Write "</TABLE>"
		end if
	end function
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Process Credit Card</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>
<script language="javascript" type="text/javascript">
	function gotoCreditCardDone() {

		document.ccWaiting.action = "/mainapp/creditCardDone.asp?checksignature=true&guid=<%=request.querystring("guid")%>" +
				"&transactionAmt=<%=request.querystring("transactionAmt")%>" +
				"&transactionID=<%=request.querystring("transactionID")%>" +
				"&cardTypeID=<%=request.querystring("cardTypeID")%>" +
				"&customerSequenceNumber=<%=request.querystring("customerSequenceNumber")%>" +
				"&ticketNumbers=<%=request.querystring("ticketNumbers")%>" +
				"&transactionType=<%=request.querystring("transactionType")%>" +
				"&storeID=<%=storeID%>" +
				"&terminalID=<%=terminalID%>" +
				"&employeeID=<%=employeeID%>" +
				"&target=/mainapp/creditCardSingleRequest.asp";
		document.ccWaiting.submit();
	}

	function showProgress() {
		document.all.progress.style.display = "inline";
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0 	onload="gotoCreditCardDone();setTimeout('showProgress();', 1600);">
<FORM name="ccWaiting" ID="ccWaiting" METHOD=POST  style="margin:0;padding:0">
<!-- #include file="../include/fakebanner.inc" -->

<B class="pageHeading">Response</B>


<BR /><BR /><BR /><BR /><BR />
<CENTER>

<DIV id="progress" style="text-align:center;display:none">

Contacting Processor...<BR />
<IMG  src="/Images/waiting.gif" alt="" />
<BR /><BR /><BR /><BR /><BR />
</DIV>


<%=d_rackTable()%>

</CENTER>
</FORM>
</BODY>
</HTML>

