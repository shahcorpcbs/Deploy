<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim storeId
	dim giftprogramId, effDate, expDate
	dim actionString
	dim begCard, endCard, cardValue
	
	storeId = Session("storeId")
	actionString = Request.QueryString("userAction")
	
	select case actionString
		case "submit"
			addMultiCards()
	end select	
	
	function addMultiCards()
		dim ssql
		dim objRst
		dim i
		
		ssql = "select *, getdate() as effDate, getDate() + validDays as expDate from giftProgram"
		set objRst = getDisconnectedRecordset(ssql)
		if objRst.recordcount = 0 then
			Session("errorMessage") = "Gift Card Program has not been set up.  Please go back and set up gift card program from setup menu."
			Response.Redirect "ErrorMessages.asp"
		else
			effdate = objRst.fields("effDate")
			expdate = objRst.fields("expDate")
			giftProgramId = objRst.fields("giftprogramId")
		end if	
		begCard = Request.Form("firstCardNum")
		endCard = Request.Form("lastCardNum")
		cardValue = Request.Form("curBal")
		ssql = "select * from giftcard where isNumeric(giftcardnumber) = 1 and giftcardnumber between " & begCard & " and " & endCard 
		set objRst = getDisconnectedRecordset(ssql)
		if objRst.recordcount > 0 then
			Session("errorMessage") = "Gift Card range has been used.  Please choose new gift card numbers."
			Response.Redirect "ErrorMessages.asp"
		end if	
		i = clng(begCard)
		do 
			ssql = "INSERT into GIFTCARD(giftprogramid, giftcardnumber, giftValue, effectivedate, expirationdate, lastUsedDate)" _
				& " VALUES(" & giftProgramId & "," & dbcreateqrystring(i) & "," & cardValue _
				& ",'" & formatDate1(effDate) & "','" & formatDate1(expDate) & "','"  & formatDate1(effDate)& "')"
			QryExecute(ssql)
			i = i+1
		loop while (i <= clng(endCard))
		
		Response.Redirect "issueGiftCard.asp"
	end function	
		
			
		
			

%>	
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Assign Value to Multiple Gift Cards</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		if (validateForm()) {
			document.issueMultiGiftForm.action = "?userAction=submit";
			document.issueMultiGiftForm.submit();
		}	
	}
	
	function cancelForm() {
		document.issueMultiGiftForm.action="issueGiftCard.asp";
		document.issueMultiGiftForm.submit()
	}	
	
	function validateForm() {
		var begCard
		var endCard
		var cardValue
		returnValue = true;
		begCard = document.issueMultiGiftForm.firstCardNum.value;
		if (!checkFieldMissing(begCard)) {
			returnValue = false;
			show_focus("Beginning Card Number is required.","CBS Error", document.issueMultiGiftForm.firstCardNum)
			return returnValue;
		}
		if (isNaN(begCard)) {
			returnValue = false;
			show_focus("Beginning Card Number must be a number.","CBS Error", document.issueMultiGiftForm.firstCardNum)
			return returnValue;
		}
		endCard = document.issueMultiGiftForm.lastCardNum.value;
		if (!checkFieldMissing(endCard)) {
			returnValue = false;
			show_focus("Ending Card Number is required.","CBS Error", document.issueMultiGiftForm.lastCardNum)
			return returnValue;
		}
		if (isNaN(endCard)) {
			returnValue = false;
			show_focus("Ending Card Number must be a number.","CBS Error", document.issueMultiGiftForm.lastCardNum)
			return returnValue;
		}
		cardValue = document.issueMultiGiftForm.curBal.value;
		if (!checkFieldMissing(cardValue)) {
			returnValue = false;
			show_focus("Value is required.","CBS Error", document.issueMultiGiftForm.curBal)
			return returnValue;
		}
		if (isNaN(cardValue)) {
			returnValue = false;
			show_focus("Value must be a number.","CBS Error", document.issueMultiGiftForm.curBal)
			return returnValue;
		}
		return returnValue;
	}	
	
	function decimalFormat() {
		var price;
		
		price = document.issueMultiGiftForm.curBal.value;
		price = trim(price);
		if(price.length > 0) {
			price = cleanNumeric(price);
			if(price == "")	{
				show_focus("Enter valid amount.","CBS Error", document.issueMultiGiftForm.curBal);
				return;
			}
		}
		document.issueMultiGiftForm.curBal.value = autoFormatCurrency(document.issueMultiGiftForm.curBal.value);
		//captureKeyUpEvent("curBal"); //added by vivek on 02 Feb 2003
	}
	
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Assign Value to Multiple Gift Cards</B>
<FORM id="issueMultiGiftForm" name="issueMultiGiftForm" action="issueMultiGiftCard.asp" method="Post">
<TABLE ALIGN=center WIDTH=350px BORDER=1 CELLSPACING=1 CELLPADDING=10>
	<TR><TD>
	<TABLE ALIGN=center WIDTH=100% BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR height=40px><TD align=right width=50%>
			<LABEL for=firstCardNum>First Gift Card Number&nbsp</LABEL>
			</TD>
			<TD width=50%>
			<INPUT CLASS=text name=firstCardNum style= width:160px>
		</TD></TR>
		<TR height=40px><TD align=right>
			<LABEL for=lastCardNum>Last Gift Card Number&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=lastCardNum style= width:160px>
		</TD></TR>
		<TR height=40px><TD align=right>
			<LABEL for=curBal>Gift Card Value&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=curBal style= width:80px onKeyup="decimalFormat();">
		</TD></TR>

		<TR height=80px><TD ALIGN=CENTER COLSPAN=2 valign=bottom>
			<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
		</TD></TR>
	</TABLE>
	</TD></TR>
</TABLE>	
</FORM>   

</BODY>
</HTML>