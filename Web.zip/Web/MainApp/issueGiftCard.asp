<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Issue Gift Card</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		document.issueGiftCardForm.submit();
	}
	
	function cancelForm() {
		document.issueGiftCardForm.action="giftCardProgram.asp";
		document.issueGiftCardForm.submit()
	}	
	
	function issueSingleGiftCard(){
		document.issueGiftCardForm.action ="Customersearch.asp?userAction=issueSingleGiftCard"
		document.issueGiftCardForm.submit();
	}
		
	function assignMultiToCustomer(){
		document.issueGiftCardForm.action ="Customersearch.asp?userAction=issueMultiToCust";
		document.issueGiftCardForm.submit();
	}
	
	function assignSingleNoCust(){
		document.issueGiftCardForm.action ="assignSingleNoCust.asp";
		document.issueGiftCardForm.submit();
	}
	
	function purchaseSingleNoCust(){
		document.issueGiftCardForm.action ="purchaseSingleNoCust.asp?userAction=initialize&customerSequenceNumber=1";
		document.issueGiftCardForm.submit();
	}
	function issueMultiGiftCard(){
		document.issueGiftCardForm.action ="issueMultiGiftCard.asp";
		document.issueGiftCardForm.submit();
	}
	

		
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Issue Gift Card</B>
<FORM id="issueGiftCardForm" name="issueGiftCardForm" action="start2.asp" method="Post">'
<TABLE ALIGN=CENTER WIDTH=350px BORDER=1 CELLSPACING=0 CELLPADDING=10>
	<TR><TD>
	<TABLE ALIGN=center WIDTH=100% BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<TR height=60px></TR>	
		<TR height=100px>
			<TD align=center>
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=issueSingleGift onclick="issueSingleGiftCard()">Customer Purchase<br>Single Card</BUTTON>
			</TD>
		</TR>
		<TR height=100px>
			<TD align=center>
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=issueMultiToCust onclick="assignMultiToCustomer()">Assign Card to Customer</BUTTON>
			</TD>
		</TR>
		</TR>	
			<TD align=center>
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=issueMultiGift onclick="issueMultiGiftCard()">Multiple Card Setup</BUTTON>
			</TD>
		</TR>
		<TR height=100px>
			<TD align=center>
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=issueSingleNoCust onclick="assignSingleNoCust()">Single Card Setup<br>(No Customer)</BUTTON>
			</TD>
		</TR>
		<TR height=100px>
			<TD align=center>
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=issueSingleGift2 onclick="purchaseSingleNoCust()">Purchase Gift Card<br>(No Customer)</BUTTON>
			</TD>
		</TR>

		<TR height=60px></TR>	
		<TR >
			<TD colspan = 2 ALIGN=center>
				<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
			</TD>	
		</TR>			
	</TABLE>
	</TD></TR>
</TABLE>	
</FORM>   

</BODY>
</HTML>