<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	'***********************************************************************
	'Name   :Additional Heat Seal Numbers
    'Author : Michele Wiemann
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 07-Sept-2006    MWiemann		Original Version
    '***********************************************************************

	dim invoice
	'invoice details
	dim itemId1
	dim itemName1
	dim pieceCount1
	dim counter
	dim actionString
	dim orgPage
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex
	dim curr_LineNo
	dim selectedDept
	dim couponStartIndex
	dim addOrEdit
	dim deptStartIndex
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim hsStart, hsEnd
	
	hsStart = Request.Form("hsStart")
	hsEnd = Request.Form("hsEnd")

	if isEmpty(hsStart) or hsStart = "" then
		initializeHSValues
	end if

	on error resume next
	set invoice = Session("invoice")
	actionString = Request.QueryString("userAction")
	if actionString = "submit" then
		curr_LineNo = Request.Form("lineNumber")
		selectedDept = Request.Form("selectedDept")
		itemsStartIndex = Request.Form("ItemPageCount")
		upChargeStartIndex = Request.Form("upChargePageCount")
		colorsStartIndex = Request.Form("colorsPageCount")
		patternStartIndex = Request.Form("PatternPageCount")
		addOrEdit = Request.Form("addOrEdit")
		deptStartIndex = Request.Form("DeptPageCount")
		selItemId = Request.Form("selItemId")
		selUpchargeValue = Request.Form("selUpcharge")
		selColorValue = Request.Form("selColor")
		selPatternValue = Request.Form("selPattern")

		updateHeatSealNumbers

	elseif actionString = "clearItem" then
		itemName1 = Request.Form("itemName")
		itemID1 = Request.Form("itemID")
		pieceCount1 = Request.Form("pieceCount")
		curr_LineNo = Request.Form("lineNumber")
		selectedDept = Request.Form("selectedDept")
		itemsStartIndex = Request.Form("ItemPageCount")
		upChargeStartIndex = Request.Form("upChargePageCount")
		colorsStartIndex = Request.Form("colorsPageCount")
		patternStartIndex = Request.Form("PatternPageCount")
		addOrEdit = Request.Form("addOrEdit")
		deptStartIndex = Request.Form("DeptPageCount")
		selItemId = Request.Form("selItemId")
		selUpchargeValue = Request.Form("selUpcharge")
		selColorValue = Request.Form("selColor")
		selPatternValue = Request.Form("selPattern")

		deleteLineItem

	else
	     itemID1 = Request.QueryString("itemID")
	     itemName1 = Request.QueryString("itemName")
	     pieceCount1 = Request.QueryString("pieceCount")
	     curr_LineNo = Request.QueryString("lineNo")
	     selectedDept = Request.QueryString("dept")
	     itemsStartIndex = Request.QueryString("itIndex")
	     upChargeStartIndex = Request.QueryString("upIndex")
	     colorsStartIndex = Request.QueryString("cIndex")
	     patternStartIndex = Request.QueryString("pIndex")
	     addOrEdit = Request.QueryString("addOrEdit")
	     deptStartIndex = Request.QueryString("deptIndex")
	     selItemId = Request.QueryString("selItemId")
	     selUpchargeValue = Request.QueryString("selUp")
	     selColorValue = Request.QueryString("selColor")
	     selPatternValue = Request.QueryString("selPattern")
	end if

	sub initializeHSValues()
		dim query
		dim rs
		query = "Select starths, endhs from miscsetup"
		set rs = getDisconnectedRecordset(query)

		if rs.Recordcount > 0 then
			hsStart = rs("starths")
			hsEnd = rs("endhs")
		end if
	end sub

	sub updateHeatSealNumbers()
		dim intLoop
		dim itemName
		dim hsNumber
		dim itemId
		dim pieceCount
		dim lineNo
		itemName = Request.Form("itemName")
		itemID = Request.Form("itemID")
		pieceCount = Request.Form("pieceCount")
		lineNo = Request.Form("lineNumber")
		for intloop=2 to pieceCount
			hsNumber = Request.Form("txtHeatSealNo")(intloop)
			invoice.addHeatSealInfoForItem lineNo, hsNumber, itemName, itemId
		next
		goBackToDetailedInvoice
	end sub

	sub goBackToDetailedInvoice()
		Response.Redirect "detailedInvoice.asp?userAction=fromAddlHeatSeal" _
								& "&addOrEdit=" & addOrEdit & "&lineNo=" & curr_LineNo _
								& "&dept=" & selectedDept & "&upIndex=" & upChargeStartIndex _
								& "&cIndex=" & colorsStartIndex & "&pIndex=" & patternStartIndex _
								& "&itIndex=" & itemsStartIndex & "&deptIndex=" & deptStartIndex _
								& "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
								& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue
	end sub

	sub deleteLineItem()
		invoice.deleteHeatSeal curr_LineNo
		invoice.deleteItem curr_LineNo
		curr_LineNo = curr_LineNo - 1
		if curr_LineNo = 0 then
			curr_LineNo = 1
		end if

		Response.Redirect "detailedInvoice.asp?userAction=fromAddlHeatSeal" _
								& "&addOrEdit=" & addOrEdit & "&lineNo=" & curr_LineNo _
								& "&dept=" & selectedDept & "&upIndex=" & upChargeStartIndex _
								& "&cIndex=" & colorsStartIndex & "&pIndex=" & patternStartIndex _
								& "&itIndex=" & itemsStartIndex & "&deptIndex=" & deptStartIndex
	end sub





%>
<HTML>
<HEAD>
<TITLE>Additional Heat Seal Numbers</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript">

	function handleEnter (field, event) {
		var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
		if (keyCode == 13) {
	        var i;
	        for (i = 1; i <= field.form.elements.length; i++)
	              if (field == field.form.elements[i])
	                    break;
	        i = (i + 1) % field.form.elements.length;
	        field.form.elements[i].focus();
			return false;
		}
		else
		return true;
	}

	function focusOnField () {
		document.addlHeatSealForm.txtHeatSealNo[1].focus();
	}

	function submitForm() {
		var valid;

		valid = validateHeatSeals();
		if (valid){
			document.addlHeatSealForm.action = "additionalHeatSeal.asp?userAction=submit";
			document.addlHeatSealForm.submit();
		}
	}

	function clearItem() {

		document.addlHeatSealForm.action = "additionalHeatSeal.asp?userAction=clearItem";
		document.addlHeatSealForm.submit();
	}


	function validateHeatSeals(){
		var hsList, hsCount;
		var hsNumber;
		var loop;
		var hs1 = document.heatSealForm.hsStart.value;
		var hs2 = document.heatSealForm.hsEnd.value;
		

        hsList = document.getElementsByName("txtHeatSealNo")
        hsCount = document.getElementsByName("txtHeatSealNo").length


		for (loop=1; loop<hsList.length; loop++) {
			hsNumber = hsList[loop].value;
			if (hsNumber == "") {
				show_focus("Please enter heat seal numbers in all boxes.","Heat Seal Number", hsList[loop]);
				return false;
			}
			else if (isNaN(hsNumber)) {
				show_focus("Please enter numeric heat seal numbers in all boxes.","Heat Seal Number", hsList[loop]);
				return false;
			}
			else if ((e.value > hs1) || (e.value < hs2)) {
				show_focus("Heat Seal number is not within the valid range.  Possible bad scan.","Heat Seal Number", e);
				return false;
			}
		}
		return true;
	}

</script>

<BODY topmargin=0 leftmargin=0 onload="focusOnField()">
<!-- #include file="../include/banner.inc" -->
<H1>Additional Heat Seal Numbers&nbsp;<%=sInvoicenumber%>&nbsp;</H1>
<FORM id="addlHeatSealForm" name="addlHeatSealForm" action="additionalHeatSeal.asp" method="post" >

	<INPUT type="hidden" name="itemName" value="<%= itemName1%>">
	<INPUT type="hidden" name="itemID" value="<%= itemId1%>">
	<INPUT type="hidden" name="pieceCount" value="<%= pieceCount1 %>">
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="couponPageCount" value="<%= couponStartIndex %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="hsStart" value="<%= hsStart %>">
	<INPUT type="hidden" name="hsEnd" value="<%= hsEnd %>">
	<TABLE ALIGN=center WIDTH="800px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr>
			<th>Please enter the other heat seal numbers for <%= itemName1%></th>
			<input type="hidden" name="txtHeatSealNo">
		</tr>
		<%
			for counter=1 to pieceCount1-1 %>
		<tr>
			<td align=center>
			      <INPUT id="txtHeatSealNo" name="txtHeatSealNo" class=text style="width:200px;" onkeypress="return handleEnter(this,event)">
			</td>
        </tr>
        <% next %>
	</table>
	<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=20px><td></td></tr>
		<tr>
			<td align="center" width="200px" >
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick= "submitForm()">
			</td>
		</tr>
	</table>
	<INPUT type="hidden" name="fieldCounter" value="<%= piececount1 -1 %>">

</form>
</BODY>
</HTML>