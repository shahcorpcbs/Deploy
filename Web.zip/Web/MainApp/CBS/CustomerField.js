
CBS = {};
CBS.fields = {};

CBS.fields.Customer = function(config) {
	Ext.apply(this, config);

    this.store = new Ext.data.Store({
		proxy: new Ext.data.HttpProxy({
			url: '/MainApp/CBS/actions.asp?a=getCustomers'
		}),
		
		reader: new Ext.data.JsonReader(
			{
			root: 'rows',
			totalProperty: 'recordcount',
			id: 'customerseq'
			},
			['customerseq', 'customername', 'firstname', 'lastname', 'address', 'phonenumber', 'route']
		)
	});
	
    this.template = new Ext.XTemplate(
        '<tpl for="."><div class="search-item">',
            '<h3><span>{phonenumber}<br />{route}</span>{firstname} {lastname}</h3>',
            '{address}',
        '</div></tpl>'
    );
	
    CBS.fields.Customer.superclass.constructor.call(this, {
        store: this.store,
        displayField: 'customername',
		valueField: 'customerseq',
        typeAhead: false,
        loadingText: 'Searching',
        width: 570,
        pageSize:25,
        hideTrigger:true,
        tpl: this.template,
        itemSelector: 'div.search-item',
		forceSelection: true
	});

}


Ext.extend(CBS.fields.Customer, Ext.form.ComboBox, {


});
