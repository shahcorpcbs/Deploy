<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../../include/QueryDatabase.asp"-->
<!--#include file="../../include/json.asp"-->

<%
	dim query, rs
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if
	
	select case request.querystring("a")
	case "getCustomers"
		response.write getCustomers()
	end select

	function getCustomers()
		dim query, rs
		dim partial
		
		partial = request.form("query")
		
		
		query = " select customer.customersequencenumber as customerseq, "
		query = query & " customer.lastname, "
		query = query & " customer.firstname, "
		query = query & " customer.customername, "
		query = query & " route.name, "
		query = query & " dbo.formatPhone(customer.mainareacode, customer.mainphone) as phonenumber, "
		query = query & " customer.shippingAddress1 as address "
		query = query & " from customer inner join route on customer.routenumber = route.routenumber "
		if partial <> "" then
			query = query & " and customer.lastname like '" & partial & "%'"
		end if

		set rs = getdisconnectedrecordset(query)

		if isnull(limit) then limit = 25
		
		getCustomers = rsToJSON(rs, limit, start)
	
		set rs = nothing
	end function

%>