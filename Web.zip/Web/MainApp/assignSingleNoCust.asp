<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim storeId
	dim giftprogramId, effDate, expDate
	dim actionString
	dim cardNo, cardValue
	
	storeId = Session("storeId")
	actionString = Request.QueryString("userAction")
	
	select case actionString
		case "submit"
			addCard()
	end select	
	
	function addCard()
		dim ssql
		dim objRst
		dim i
		
		ssql = "select *, getdate() as effDate, getDate() + validDays as expDate from giftProgram"
		set objRst = getDisconnectedRecordset(ssql)
		if objRst.recordcount = 0 then
			Session("errorMessage") = "Gift Card Program has not been set up.  Please go back and set up gift card program from setup menu."
			Response.Redirect "ErrorMessages.asp"
		else
			effdate = objRst.fields("effDate")
			expdate = objRst.fields("expDate")
			giftProgramId = objRst.fields("giftprogramId")
		end if	
		cardNo = Request.Form("firstCardNum")
		cardValue = Request.Form("curBal")
		ssql = "select * from giftcard where giftcardnumber =" & dbcreateqrystring(cardNo)
		set objRst = getDisconnectedRecordset(ssql)
		if objRst.recordcount > 0 then
			Session("errorMessage") = "Gift Card is already assigned value.  Please choose another gift card number."
			Response.Redirect "ErrorMessages.asp"
		end if	
		ssql = "INSERT into GIFTCARD(giftprogramid, giftcardnumber, giftValue, effectivedate, expirationdate, lastUsedDate)" _
				& " VALUES(" & giftProgramId & "," & dbcreateqrystring(cardNo) & "," & cardValue _
				& ",'" & formatDate1(effDate) & "','" & formatDate1(expDate) & "','"  & formatDate1(effDate)& "')"
		QryExecute(ssql)
		
		Response.Redirect "issueGiftCard.asp"
	end function	
		
			
		
			

%>	
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Assign Value to Single Gift Card</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		if (validateForm()) {
			document.assignSingleNoCust.action = "?userAction=submit";
			document.assignSingleNoCust.submit();
		}	
	}
	
	function cancelForm() {
		document.assignSingleNoCust.action="issueGiftCard.asp";
		document.assignSingleNoCust.submit()
	}	
	
	function validateForm() {
		var cardNo
		var cardValue
		returnValue = true;
		cardNo = document.assignSingleNoCust.firstCardNum.value;
		if (!checkFieldMissing(cardNo)) {
			returnValue = false;
			show_focus("Card Number is required.", "Card Number", document.assignSingleNoCust.firstCardNum)
			return returnValue;
		}
		cardValue = document.assignSingleNoCust.curBal.value;
		if (!checkFieldMissing(cardValue)) {
			returnValue = false;
			show_focus("Value is required.", "Card Value", document.assignSingleNoCust.curBal)
			return returnValue;
		}
		if (isNaN(cardValue)) {
			returnValue = false;
			show_focus("Value must be a number.", "Card Value", document.assignSingleNoCust.curBal)
			return returnValue;
		}
		return returnValue;
	}	
	
	function decimalFormat() {
		var price;
		
		price = document.assignSingleNoCust.curBal.value;
		price = trim(price);
		if(price.length > 0) {
			price = cleanNumeric(price);
			if(price == "")	{
				show_focus("Enter valid amount.", "Card Value", document.assignSingleNoCust.curBal);
				return;
			}
		}
		document.assignSingleNoCust.curBal.value = autoFormatCurrency(document.assignSingleNoCust.curBal.value);
		//captureKeyUpEvent("curBal"); //added by vivek on 02 Feb 2003
	}
	
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Assign Value to Single Gift Card</B>
<FORM id="assignSingleNoCust" name="assignSingleNoCust" action="assignSingleNoCust.asp" method="Post">
<TABLE ALIGN=center WIDTH=350px BORDER=1 CELLSPACING=1 CELLPADDING=10>
	<TR><TD>
	<TABLE ALIGN=center WIDTH=100% BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR height=40px><TD align=right width=50%>
			<LABEL for=firstCardNum>Gift Card Number&nbsp</LABEL>
			</TD>
			<TD width=50%>
			<INPUT CLASS=text name=firstCardNum style= width:160px>
		</TD></TR>
		<TR height=40px><TD align=right>
			<LABEL for=curBal>Gift Card Value&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=curBal style= width:80px onKeyup="decimalFormat();">
		</TD></TR>

		<TR height=80px><TD ALIGN=CENTER COLSPAN=2 valign=bottom>
			<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
		</TD></TR>
	</TABLE>
	</TD></TR>
</TABLE>	
</FORM>   

</BODY>
</HTML>