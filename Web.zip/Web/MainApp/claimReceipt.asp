<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%

	dim query, rs
  dim customerSequenceNumber
  dim target
	dim printRackSlipOnPickup
	dim notificationIP, smsPickup, emailPickup

	printRackSlipOnPickup = getMSVar("printRackSlipOnPickup")
  customerSequenceNumber = getReqVar("customerSequenceNumber")
  target = getReqVar("target")

  if customerSequenceNumber = "" then customerSequenceNumber = session("customerSequenceNumber")

  getReceiptOptions

  select case lcase(request.querystring("useraction"))
  case "pickuptickets"
    pickupTickets
  end select
  
  

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function


  function pickupTickets()

    dim pickupObj
    
    set pickupObj = Session("pickupObj")
    
    set pickupObj.claimReceipt = Server.CreateObject("ShahCorpComponents.claimReceiptFields")
    
    pickupObj.claimReceipt.name = request.form("name")
    pickupObj.claimReceipt.relationship = request.form("relationship")
    pickupObj.claimReceipt.identificationType = request.form("identificationType")
    pickupObj.claimReceipt.identification = request.form("identification")
    pickupObj.claimReceipt.phoneNumber = request.form("phoneNumber")
    pickupObj.claimReceipt.note = request.form("note")

    if pickupObj.getAmountDue() = 0 then
    	applyPayments
    else
   		Response.Redirect "pickup.asp?targetPage=customerfunctions&target=" & target & "&userAction=" & target
    end if
  end function

  
  	
	function getTicketNumbers()
 		dim pickupObj
		set pickupObj = Session("pickupObj")
		getTicketNumbers = pickupObj.getTicketNosForPrinting()
	end function


	function applyPayments()
		dim custSeqNumber
		dim empId
		dim terminalId
		dim invNumbers
		dim pickupObj
		dim invoiceNumbers
		dim invoiceNumber
		
		empId = Session("employeeID")
		terminalId = Session("terminalID")
		custSeqNumber = Session("customersequencenumber")

		set pickupObj = Session("pickupObj")
		pickupObj.pickupReceipt = 0

		invoiceNumbers = pickupObj.getInvoiceNosForPrinting()
		invoiceNumbers = split(invoiceNumbers, ", ")
		
		for each invoiceNumber in invoiceNumbers
			pickupObj.markInvoicePickedUp invoiceNumber
		next
			
		pickupObj.applyPayments empId, terminalId, pickupObj.constructTicketNosString(), -1

		invNumbers = pickupObj.getTicketNosForPrinting()
		dim totalchangedue
		totalchangedue = abs(pickupObj.getChangeDue())

        if (isMessengerEnabled()) and (smsPickup or emailPickup) then
            Dim data, httpRequest, postResponse

            data = "customerSeq=" & custSeqNumber

            Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
            httpRequest.Open "POST", getMessengerFullPath("main") & "/pickupOccurred", False
            httpRequest.SetRequestHeader "Content-Type", "application/x-www-form-urlencoded"
            httpRequest.Send data
            postResponse = httpRequest.ResponseText
        end if




		if pickupObj.userAction <> "prepay" then
			recordPickupNote
		end if

		Response.Redirect "customerfunctions.asp?userAction=print&addOrEdit=" _
							& addOrEdit & "&ticketNumber=" & invNumbers _
							& "&invoiceType=P&customerseq=" & custSeqNumber _
							& "&totalchangedue="& totalchangedue _
							& "&action=" & pickupObj.userAction
	end function


    function getReceiptOptions()
        dim query, rs

        query = "select triggerType from QueryAlert where id = -12"
        set rs = getdisconnectedrecordset(query)

        if rs("triggerType") <> 0 then
            query = "select sms, email from CustomerMessageSetup where QueryId = -12 and customerId = '"_
                & Session("customerSequenceNumber") & "'"
            set rs = getdisconnectedrecordset(query)
            if rs.recordCount > 0 then
                smsPickup = rs("sms")
                emailPickup = rs("email")
            else
                query = "select sms, email from CustomerMessageSetup where QueryId = -12 and customerId = 0"
                set rs = getdisconnectedrecordset(query)
                if rs.recordCount > 0 then
                    smsReceipt = rs("sms")
                    emailReceipt = rs("email")
                end if
            end if
        end if

    end function

	
	sub recordPickupNote()
		dim query

		
		query = "insert into customernote (customersequencenumber, storeguid, source, note)"
		query = query & " select " & Session("customersequencenumber")
		query = query & ", store.guid"
		query = query & ", '" & session("employeename") & "'"
		query = query & ", 'Picked up invoice " & sInvoicelist & "'"
		query = query & " from store where storeid = " & session("storeid")
		
		qryexecute query
	
	end sub
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript" src="/script/printing.js"></script>
<script language="javascript" type="text/javascript">

  function checkToEnablePickup() {
    var f;
    var enable;
    
    enable = true;
    
    f = document.claimReceipt;
    
    enable = enable && f.name.value != "";
    enable = enable && f.relationship.selectedIndex != 0;
    enable = enable && f.identificationType.selectedIndex != 0;
    enable = enable && ((f.identification.value != "") || (f.phoneNumber.value != "" && f.identificationType.selectedIndex == 3));

     f.pickupButton.disabled = !enable;
  }
  
  function exit() {
    document.claimReceipt.action = "customerfunctions.asp?customerseq=" + document.claimReceipt.customerSequenceNumber.value;
    document.claimReceipt.submit();
  }
  
  function pickupTickets() {
    <% if printRackSlipOnPickup then %>
    PrintRackSlip('<%=getTicketNumbers()%>');
    <% end if %>
    
    document.claimReceipt.action = "?useraction=pickuptickets";
    document.claimReceipt.submit();
  }
    
  function setOption(src, dest) {
	dest.value = src.value;	  
  }
</script>


<STYLE  type="text/css" >
 .optionButton {
	 width: 80px;
	 height: 40px;
 }
</STYLE>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="document.claimReceipt.name.focus()">
<!-- #include file="../include/banner.inc" -->
<H1>Claim Receipt</H1>

<FORM name="claimReceipt" ID="claimReceipt" METHOD=POST  style="margin:0;padding:0"> 
<INPUT type="hidden" name="customerSequenceNumber" value="<%=customerSequenceNumber%>" />
<INPUT type="hidden" name="target" value="<%=target%>" />
<INPUT type="hidden" name="targetPage" value="<%=targetPage%>" />

<BR>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
	    <BUTTON onclick="exit()">Cancel</BUTTON>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON name="pickupButton" onclick="pickupTickets()" disabled>Pickup</BUTTON>
	</SPAN>
</DIV>	
<TABLE class="itable" cellspacing="0" onkeyup="checkToEnablePickup()">

<TR>
  <TH>Attribute</TH>
  <TH>Value</TH>
</TR>

<TR>
  <TD>Name</TD>
  <TD><INPUT name="name" tabindex="1" /></TD>
</TR>

<TR>
  <TD>Relationship</TD>
  <TD>
  	<DIV style="width: 150px; float:left; padding-top: 8px; padding-right: 45px; margin: 0" ><INPUT name="relationship" tabindex="3" /></DIV>
  	<INPUT type="button" class="optionButton" value="Self" onclick="setOption(this, relationship)" />
  	<INPUT type="button" class="optionButton" value="Spouse" onclick="setOption(this, relationship)" />
  	<INPUT type="button" class="optionButton" value="Child" onclick="setOption(this, relationship)" />
  	<INPUT type="button" class="optionButton" value="Parent" onclick="setOption(this, relationship)" />
  	<INPUT type="button" class="optionButton" value="Friend" onclick="setOption(this, relationship)" />
  	<INPUT type="button" class="optionButton" value="Associate" onclick="setOption(this, relationship)" />

  </TD>
</TR>

<TR>
  <TD>Identification type</TD>
  <TD>
  	<DIV style="width: 150px; float:left; padding-top: 8px;  padding-right: 45px; margin: 0" ><INPUT name="identificationType" tabindex="3" /></DIV>
  	<INPUT type="button" style="vertical-align: top" class="optionButton" value="Driver's
 License" onclick="setOption(this, identificationType)" />
  	<INPUT type="button" style="vertical-align: top"  class="optionButton" value="Credit Card" onclick="setOption(this, identificationType)" />
  	<INPUT type="button" style="vertical-align: top"  class="optionButton" value="Phone
 Number" onclick="setOption(this, identificationType)" />
  	<INPUT type="button" style="vertical-align: top"  class="optionButton" value="ID Card" onclick="setOption(this, identificationType)" />
  </TD>
</TR>

<TR>
  <TD>Identification</TD>
  <TD><INPUT name="identification" tabindex="4" /></TD>
</TR>

<TR>
  <TD>Phone number</TD>
  <TD><INPUT name="phoneNumber" tabindex="5" /></TD>
</TR>

<TR>
  <TD>Note</TD>
  <TD><TEXTAREA cols="40" rows="3" style="overflow:auto" name="note"  tabindex="6" ></TEXTAREA></TD>
</TR>

</TABLE>

</FORM>
</BODY>
</HTML>
