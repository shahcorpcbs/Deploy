<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim isSubmitted 
	dim customerseq
	dim routeid 
	dim stopnumber
	Dim multipickup
	dim routenotes
	dim l_storeid
	dim checkForStop
	dim firsttime 
	dim alertmessage
	dim RegularPickup
	
	checkforstop = false
	
	firsttime = true
		
	isSubmitted = Request.QueryString("Submitted")
	
	checkforstop = Request.QueryString("CheckStop")
	
	l_storeid = session("storeid")
	
	customerseq = session("customersequencenumber")

	if checkforstop then
		firsttime = false
		GetStopInfo()
	end if
	
	if isSubmitted then
		UpdateDatabase()
	end if
	
	if firsttime then 
		getCustomerRouteInfo()
	end if
	
	getRoutes()
%>
<HTML>
<HEAD>
<TITLE>Customer Routes</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
var updatestopnumber

	function checkForStopNumber(){
		document.customerRoutesForm.action= "?checkStop=true&updatestopnumber=0";
		document.customerRoutesForm.submit();
	}
	
	function submitForm(){
		document.customerRoutesForm.action= "?Submitted=true" + "&updatestopnumber=" + updatestopnumber ;
		document.customerRoutesForm.submit();
		return true;
	}
	
	function enableButtons(){
		
		if (document.customerRoutesForm.routeList.length < 1 ){
			document.customerRoutesForm.optstopNumber.disabled = true;
			document.customerRoutesForm.okButton.disabled = true;
			
		
		}
		else{
			document.customerRoutesForm.optstopNumber.disabled = false;
			document.customerRoutesForm.okButton.disabled = false;
		}
	}

	function updateOne() {
	    updateSubmit(1);
	}

	function updateNone() {
	    updateSubmit(0);
	}

	function updateSubmit(stopNum) {
        clearConfirmMsg();
		updatestopnumber = stopNum;
		submitForm();
	}
	
	function showAlert(sMessage){
		if (trim(sMessage) != "")
            cbs_confirm(sMessage, updateOne, updateNone);
		else 
		    updatestopnumber = null;
	}
	
	function cancelForm(){
		document.customerRoutesForm.action = "\CustomerEntry.asp?mode=edit";
		document.customerRoutesForm.submit();
	}
	
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0 onload = "enableButtons();showAlert('<%=alertmessage%>')">

<!-- #include file="../include/banner.inc" -->
<H1>Routes</H1>
<FORM id="customerRoutesForm" name="customerRoutesForm" action="" method="Post">
<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
	<tr><td>
			<!-- Routes list-->
			
			<TABLE ALIGN=center>
			<TR>
				<TD width=300px align=right class="label">Route Name</TD>
				<TD>
					<SELECT id="routeList" name=routeList STYLE="FONT-SIZE: 16px" >
<!--						<option value = "0" >None</option> -->
						<%
							if rsRoutelist.recordcount > 0 then
								while not rsRoutelist.eof
						%>		
							<OPTION 
							
								<%if (routeid = trim(rsRouteList("RouteNumber")))then
								%>
									selected
								<%End if
								%>
								VALUE="<%=rsRouteList("RouteNumber")%>" ><%=rsRouteList("Name") %></option>
								<%
							rsRouteList.movenext
							wend
							rsRouteList.close
							set rsRouteList=nothing
							end if
						%>
					</SELECT>
				</TD>
			</tr>
			<tr height=10px></tr>
			<tr>		
			<!-- Stop Numbers-->
				<TD align=right class="label">Stop Number</TD>
				<TD>
					<INPUT style="width:60px;text-align:right" name="optstopNumber" value="<%=Stopnumber%>">

				</TD>
			</TR>
			<tr height=10px></tr>
			<tr>
				<td></td>
				<TD align =left class="label">
					<INPUT type="checkbox" name=chkMultiPickUp id=chkMultiPickUp STYLE="height : 28px; width : 28px;"
					<%if Multipickup then%>
						checked
					<%end if%>>Multi Pickup

					<INPUT type="checkbox" name=chkRegularPickup id=chkRegularPickup STYLE="height : 28px; width : 28px;"
					<%if RegularPickup then%>
						checked
					<%end if%>>Regular Pickup
				</TD>
				
			</tr>
			<tr height=10px></tr>	
			<tr>
				<TD align="right"class="label">Route Notes</TD>
				<TD align =left>
				<TEXTAREA rows="10" cols="30" name="routeNotes" wrap = hard ><%=routenotes%></TEXTAREA>
				</TD>
			</tr>
			</table>
		</td></tr>
		</TABLE>
	
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=20px></tr>
		<tr>
			<TD width=300px></td>
			<TD align=center>
					<INPUT class=touchnoborder id=okButton name=okButton type=button value=""  style="background-image:url(../images/OK.gif)" onClick= "checkForStopNumber()">
			</TD>
			<TD align=center>
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
		   </TD>
		   <TD width=200px></td>
		</tr>
	</TABLE>
		
</FORM>   

</BODY>
</HTML>
<%

	function getCustomerRouteInfo()
	
	dim rsCustomerInfo
	dim sqltxt 
	
		if (customerseq <>  "")  then
		
			sqltxt = "select routenumber, isnull(stopnumber, 0) as stopnumber, routenotes, multiplepickup, regularpickup from customer where customersequencenumber = " & customerseq
			
			set rsCustomerinfo= getDisconnectedRecordset(sqltxt)
			
			if rsCustomerinfo.recordcount > 0 then
		
				routeid = trim(rsCustomerInfo("routenumber"))
				
				stopnumber = trim(rsCustomerInfo("stopnumber"))

				
				if rsCustomerInfo("multiplepickup") then
					multipickup = 1
				else
					multipickup = 0
				end if
			
				if rsCustomerInfo("regularPickup") then
					RegularPickup = 1
				else
					RegularPickup = 0
				end if
			
				routenotes = checkfornull(rsCustomerInfo("routenotes"))
				
				end if
				
				rsCustomerInfo.Close()
				
				set rscustomerinfo= nothing
		end if
	
	end function

	Function GetStopInfo()
	dim sqltxt
	dim rsttemp
		routeid = trim(Request.form("routeList"))
				
		stopnumber= trim(Request.form("optstopNumber"))
		
		routenotes = Request.Form("routeNotes")
				
		multipickup = evalRequestValue(Request.Form("chkMultiPickUp"))
		
		RegularPickup = evalRequestValue(Request.Form("chkRegularPickup"))
		
		if routeid= "0" or trim(routeid) = "" or stopnumber = "0" or trim(stopnumber) = "" then
		
			updatedatabase()
			
		end if
			
						
		sqltxt = "select Count(*) as customercount from customer where customersequencenumber <> " & customerseq _
					& " and stopnumber = " & trim(Request.form("optstopNumber")) _
					& " and Routenumber = " & trim(Request.form("routeList"))_
					& " and storeid = " & l_storeid
		
		set rsttemp = GetDisconnectedRecordset(sqltxt)
		
		if rsttemp.recordcount > 0 then
			if rsttemp("customercount") > 0 then
				alertmessage = "The Stop number is already in use.\nDo you want to update other customers stop numbers on this route?"
			end if
		end if
	
		rsttemp.close
		
		set rsttemp = nothing
		
		if len(trim(alertmessage)) = 0 then 
			updatedatabase()
		end if
		
	end function
	
	function updateDatabase()
	
	dim l_routeidId
	dim l_multipickup
	dim  l_routenotes
	dim l_stopnumber
	dim sqltxt 
	dim supdatestopnumber
	
	l_stopnumber = trim( Request.Form("optstopNumber"))
	
	customerseq = session("Customersequencenumber")
	
	l_routeidId = Request.form("routeList")
	
	supdatestopnumber = Request.QueryString("updatestopnumber")
	
		if l_routeidId = "0" or trim(l_routeidId) = "" then
'			l_routeidId = "NULL"
			l_stopnumber = "0"
		end if
		
		sqltxt = "update customer set " _
            & " routenumber = " & l_routeidId _
            & ", stopnumber = "  & l_stopnumber  _
            & ", multiplepickup= " & evalRequestValue(Request.Form("chkMultiPickUp")) _
            & ", regularPickup = " & evalRequestValue(Request.Form("chkRegularPickup")) _
            & ", routenotes= " &  dbcreateqrystring(Request.Form("routeNotes"))_
            & " where customersequencenumber = " & customerseq
        
        DbStartTrans()
        
		QryExecuteWithTrans(sqltxt)
		
		if supdatestopnumber = "1" and not isnull(l_routeidId)  then
			sqltxt = "update customer set stopnumber = stopnumber + 1 " _
						& " where customersequencenumber <> " & customerseq _
						& " and routenumber = " & l_routeidId _
						& " and stopnumber >= " & trim(Request.Form("optstopNumber"))
			QryExecuteWithTrans(sqltxt)
		end if
		
		DBEndTrans()
		Response.redirect("CustomerEntry.asp?mode=edit")
	
	end function
	
	dim rsRouteList
	Function getRoutes()
	dim sqltxt
		sqltxt = "Select * from Route where storeid = " & l_storeid
		set rsRouteList = getdisconnectedrecordset(sqltxt)
	end function
%>
