<%@ Language=VBScript %>

<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/Email.asp" -->
<!-- #include file="CheckSessionExpiry.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%

    Dim objApp 
    Dim objNs 
    Dim objMail 

	Dim defaultASPTimeout
	
	Dim attachmentFile
	
	Dim emailTo
	
	On Error Resume Next
	
	emailTo = Request.Form("emailTo")
	
	Call CBSSendMail("CBS Reports", "cbsreports@cbs.com", emailTo, emailTo, _
			"", "", "", "", Session("objRP").reportName, _
			"Please find the report in the attached document", Session("objRP").reportStream, "")
			
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & " -Function= CBSSendMail. Could not queue Email for later sending. "
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if
	

%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">

<TITLE>EMail Response</TITLE>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>

<BODY>


<!-- #include file="../include/banner.inc" -->

<B class="pageHeading">EMail Response</B>
<br>
<br>
<table>
		<tr>
		<td>
		The Report - <%= Session("objRP").reportName %> - sent in EMail.
		</td>
		</tr>
		<tr>
		<td>
		&nbsp;
		</td>
		</tr>
		<tr height=35px width=100% >
			<td align=left >
				<INPUT class=touchnoborder id=ok name=ok type=button value="" onClick="history.go(-2);" 
					style="background-image:url(../images/Ok.gif);">
			</td>
		</tr>
</table>


</BODY>
</HTML>
