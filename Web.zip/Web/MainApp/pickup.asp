<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/customerPaymentObj.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/codecs.inc" -->
<!--#include file="../include/notification.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim actionString
	
	actionString = Request.QueryString("userAction")
	
	select case actionString
	case "cfpickup"
		pickupSelectedInvoices "pickup"
	case "cfprepay"
		pickupSelectedInvoices "prepay"
	end select
		
	const maxCouponsCount =12
	
	' begin invoice form
	dim targetPage
	dim addOrEdit
	dim curr_LineNo
	dim selectedDept
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim originatingPage
	' end invoice form
		



	dim storeId
	dim pickupObj
	dim starchPref, finishPref
	dim custSeqNumber, custPriceList, custPhone, customerName

	dim custPaymentObj
	dim custPaymentType
	dim temporaryAccount, permanentAccount
	dim accountBalance
	dim RackRst,rackStr, rackStr1, noOfRows
	dim invoice
	dim ObjMiscSetUp, invoicesTotal
	dim printRackInfo
	dim sInvoicelist
	dim trackCheckNum
	dim promptIfCredit
	dim creditBal
	dim promptIfBalance
	dim allowPUTempAccount
	dim creditLimit
	dim enableXcharge
	dim ccPaymentMade
	dim isPrepay
	dim cc_xcid, cc_maskedCC
	dim cc_expiration
	dim cc_zip
	dim cc_receipt
	dim ccProcessorDomainID
	dim use_clearent
	dim cc_url
	dim cc_key
	dim promptToAddCC
	dim useHeatSeal
	dim useRstHeatSeal

	dim showAmountDueButton
	dim canSms, canEmail
	dim smsReceipt, emailReceipt, notificationIP, smsPickup, emailPickup
	dim clearentServiceLoc, query, rs, transactionID

	dim unfinishedTran : unfinishedTran = "0"
	dim onDemCredit : onDemCredit = 0

	transactionID = Request.QueryString("transactionID")


	dim preCardCreditAmt : preCardCreditAmt = 0
	dim preCardCreditId : preCardCreditId = 0
	dim tipAmt : tipAmt = 0
	if Request.Form("totalTipAmt") <> "" then
	    tipAmt = CDbl(Request.Form("totalTipAmt"))
	end if

	if session("customersequencenumber") = "" then
	    session("customersequencenumber") = Request.QueryString("customerSeq")
	end if
	if session("customersequencenumber") = "" then
	    session("customersequencenumber") = Request.Form("custSeq")
	end if

	GetCustomerInfo session("customersequencenumber")
    canSms = getMSVar("useTwilio")
    canEmail = getMSVar("useEmail")
    useHeatSeal = getMSVar("useHeatSeal")
    useRstHeatSeal = getMSVar("useRstHeatSeal")

    dim userIPAddress, printerIP, printerName
	getCashDrawerFields()


	if isobject(Session("pickupObj")) then
		if not(Session("pickupObj") is nothing) then
			set pickupObj = Session("pickupObj")
			isPrepay = pickupObj.isPrepay()
		end if
	end if

    clearentServiceLoc = getClearentShortPath()

	collectInvoiceDataFromForm

	'Initialize session variables
	sInvoicelist= session("invoicelist")
	printRackInfo = ""

	storeId = Session("storeId")
	customerName = session("customername")
	custPhone = getPhoneNumber()
	custPriceList = Session("priceList")

	showAmountDueButton =  getMSVar("showAmountDueButton")

	'Initialize passed in variables
	actionString = Request.QueryString("userAction")
	if Request.QueryString("targetPage") <> "" then
	    targetPage = Request.QueryString("targetPage")
	end if

	'Initialize other variables
	printRackInfo = ""


	'Initialize form variables

	invoicesTotal = Request.Form("invoicesTotal")

	trackCheckNum = Request.Form("trackCheckNumber")
	promptIfCredit = Request.Form("promptIfCredit")
	promptIfBalance = Request.Form("promptIfBalance")
	allowPUTempAccount = Request.Form("allowPUTempAccount")

  set pickupObj = Session("pickupObj")

  if not checkIfInvoicesOpen(pickupObj.getTicketNosForPrinting()) then
		cancelForm
  end if

  pickupObj.reloadInvoices()

	initialize
	initializeMiscSetUp
	set ObjMiscSetUp = Session("miscSetUp")
	if ObjMiscSetUp.Item("promptToAddCC") then
	    promptToAddCC = "1"
	else
	    promptToAddCC = "0"
	end if
	getReceiptOptions
	determineProcessor

	select case actionString

		case "prepay"
				dim continueCounterSale
				session("pickupCounter") = 1
				set pickupObj = Session("pickupObj")
				isPrepay = true
				getAllRackLocations
				starchPref = ""
				finishPref = ""
				invoicesTotal = pickupObj.getTotal()
				pickupObj.userAction = "prepay"
				pickupObj.DBConnectionString = Session("shahcorpDSN")
				collectInvoiceDataFromQueryString
				if Not IsObject(Session("customerPayment")) then
					initializeCustomerPaymentInfo
				end if

				if Not IsObject(Session("miscSetUp")) then
					initializeMiscSetUp
				end if

				set ObjMiscSetUp = Session("miscSetUp")
				initializeForPickUp
				' if it is a counter sale invoice then do not set the prepay percent
				continueCounterSale = true

				if isobject(Session("invoice")) then
					if not(Session("invoice") is nothing) then
						set invoice = Session("invoice")
						if invoice.counterSaleOnly = true then
							continueCounterSale = false
						end if
					end if
				end if




				if continueCounterSale then
					if ObjMiscSetUp.Count > 0 then
                        if not IsNull(ObjMiscSetUp.Item("CreditCardProcessorDomainID")) then
                            ccProcessorDomainID = ObjMiscSetUp.Item("CreditCardProcessorDomainID")
                        else
                            ccProcessorDomainID = "0"
                        end if


						'End addition by J.Johnston, 4Dec2003
						'Following added by J.Johnston, 5Jan2004
						if ObjMiscSetUp.Item("promptWhenCredit") then
							promptIfCredit = "1"
						else
							promptIfCredit = "0"
						end if
						if ObjMiscSetUp.Item("promptWhenBalance") then
							promptIfBalance = "1"
						else
							promptIfBalance = "0"
						end if
						'End addition by J.Johnston, 5Jan2004
					end if
				end if

				getActivePaymentTypes
				session("totalTax") = ""
		case "addCashPayment"
				if validatePickupCounter then addCashPayment
		case "addCouponPayment"
				if validatePickupCounter then addCouponPayment
		case "giftCardNumber"
				if validatePickupCounter then addGiftCardPayment
		case "cardNumber"
				if validatePickupCounter then addGiftCheckPayment
		case "addTempAccount"
				addTemporaryAccount
		case "OnAccount"
				if validatePickupCounter then addOnAccountPayment ""
		case "addCreditPayment"
				if validatePickupCounter then addCreditPayment
		case "addClearentCreditPayment"
				if validatePickupCounter then addClearentCreditPayment
		case "addFailedClearentCreditPayment"
				addFailedClearentCreditPayment
		case "addPrepay"
				addPrepay
		case "done"
				session("isScan")=false
				applyPayments
		case "pickup"
				session("pickupCounter") = 1
				set pickupObj = Session("pickupObj")
				pickupObj.custSeqNumber = Session("customersequencenumber")
				getAllRackLocations
				starchPref = ""
				finishPref =""
				initializeCustomerPaymentInfo
				invoicesTotal = pickupObj.getTotal()
				initializeForPickUp
				getActivePaymentTypes
				pickupObj.recordPickupAction Session("employeeID")
		case "deletePayment"
				set pickupObj = Session("pickupObj")
				if isPrepay then
					collectInvoiceDataFromForm
				end if
				pickupObj.deletePaymentByName(Request.QueryString("type"))
		case "getCoupon"
				set pickupObj = Session("pickupObj")
				getCoupon
		case "addCoupon"
				set pickupObj = Session("pickupObj")
				addCoupon
				pickupObj.populateLineItemsToDisplay

				initializeCustomerPaymentInfo
				invoicesTotal = pickupObj.getTotal()
				initializeForPickUp
				getActivePaymentTypes
		case "cancel"
				session("isScan")=false
				cancelForm
		case "sendingCCTran"
		    saveCCAttempt
		case "none"
				if isPrepay then
					collectInvoiceDataFromForm
				end if
	end select

	initialize
	getPreCardAuth
	dim path


	if actionString = "pickup" and pickupObj.getAmountDue() = 0 then
		if isSubDividedTicket() then
            path = "pickupChoice.asp?addOrEdit=" & Request.QueryString("addOrEdit") _
                & "&ticketNumber=" & pickupObj.getTicketNosForPrinting() _
                & "&invoiceType=P&customerseq=" & Session("customersequencenumber") _
                & "&totalchangedue=0" _
                & "&action=pickup"
             Response.Redirect path

        end if
	end if

    query = "select orderId from CardAttempt where finished = 0 and customerSequenceNumber = " & session("customersequencenumber")
    set rs = getdisconnectedrecordset(query)
	if rs.recordcount > 0 then
	    unfinishedTran = rs("orderId")
	end if

	'functions start here

	function saveCCAttempt()

		dim query, amount, customerseq, orderId
		amount = Request.QueryString("amount")
		customerseq = Request.QueryString("customerseq")
		orderId = Request.QueryString("orderId")


		query = "insert into CardAttempt (employeeName, customersequencenumber, amount, orderId, apiKey)" _
		    & " values ('" & session("employeename") & "', " & customerseq & ", " & amount & ", '" & orderId _
		    & "', '" & cc_key & "')"

		qryexecute query


	end function

	function determineProcessor()
		dim query, rs

		query = " select  Description, URL, API_Key from CreditCardProcessorDomain where CreditCardProcessorDomainID = " & ccProcessorDomainID

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			if rs("Description") = "Clearent" then
			    use_clearent = "1"
			    cc_key = trim(rs("API_Key"))

                query = " select API_Key from Terminal where terminalId = " & Session("terminalID")
                set rs = getdisconnectedrecordset(query)
                if trim(rs("API_Key")) <> "" then
			        cc_key = trim(rs("API_Key"))
                end if
                cc_url = getClearentShortPath()

			else
                use_clearent = "0"
                if rs("Description") = "XCharge" then
                    enableXcharge = "1"
                else
                    enableXcharge = "0"
                end if
            end if
		end if
	end function

	function getPreCardAuth()
		dim query, rs
		dim customerseq
		dim pickupObj
		dim rcount

		set pickupObj = Session("pickupObj")
		customerseq = Session("customersequencenumber")

		if not(pickupObj is nothing) and customerseq <> "" then
			query = " select amount - isnulL(amountapplied, 0) as available_credits, transactionid from cardpayment "
			query = query & " where customersequencenumber = " & customerseq
			query = query & " and success = 1 and reversed = 0"
			query = query & " and (amountapplied is null or amountapplied < amount) "
			query = query & " order by 1 "


			set rs = getdisconnectedrecordset(query)

			while not(rs.eof or rs.bof)
				pickupObj.payments.filter = "transactionNo='" & preCardCreditId & "'"
				rcount = pickupObj.payments.recordcount
				pickupObj.payments.filter = ""

				if pickupObj.payments.recordcount = 0 then
					preCardCreditAmt = rs("available_credits")
					preCardCreditId = rs("transactionid")

					exit function
				end if

				rs.movenext
			wend

			set rs = nothing
		end if
	end function

	function getPickupOnlyOnAccount(customerSeq)
		dim query, rs

		query = " select pickupOnlyOnAccount from customer where customersequencenumber = " & customerseq

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getPickupOnlyOnAccount = rs("pickupOnlyOnAccount")
		end if

	end function

	function pickupSelectedInvoices(action)
		dim tickets
		dim i
		dim pickupObj
		dim autoPickup
		dim customerseq

		customerseq = session("customersequencenumber")
		autoPickup = getMSVar("autoPickup")

		if action = "pickup" and getPickupOnlyOnAccount(customerSeq) then
			Response.Redirect "accountPickup.asp?useraction=pickup&targetpage=customerfunctions&customerseq=" & customerseq & "&ticketnumber=" & Request.QueryString("Ticketnumber")
		end if

		set pickupObj =Server.CreateObject("ShahCorpComponents.pickup")

		tickets = split(Request.QueryString("Ticketnumber"), ",")

		pickupObj.initPickupObject

		pickupObj.DBConnectionString = Session("shahcorpDSN")
		pickupObj.storeId = Session("storeID")
		pickupObj.initStorePaymentTypeInfo()

		pickupObj.userAction = action

		pickupObj.custSeqNumber = customerseq

		if action = "prepay" then
			for i = lbound(tickets) to ubound(tickets)
				pickupObj.addInvoiceToPrepay tickets(i)
			next
		else
			for i = lbound(tickets) to ubound(tickets)
				pickupObj.addInvoiceToPickup tickets(i)
			next
		end if

		Session("customersequencenumber") = customerseq
		Session("customername") = getCustomerName(customerseq)

		set Session("pickupObj") = pickupObj
		Set Session("pickupInvoices") = Nothing
		Set Session("ticketDepartment") = Nothing
		Set Session("ticketRack") = Nothing
		Set Session("invoice") = Nothing

		Session("invoicelist") = pickupObj.getInvoiceNosForPrinting()

		if action = "pickup" and request.querystring("claimreceipt") then
		  Response.Redirect "claimReceipt.asp?targetPage=customerfunctions&target=" & action
		else
		  if action = "pickup" and autoPickup = 1 and pickupObj.getAmountDue() = 0 then
		  	applyPayments
		  else
		  	Response.Redirect "pickup.asp?targetPage=customerfunctions&target=" & action & "&userAction=" & action
		  end if
		end if


	end function


	function getCustomerName(csn)
		dim query, rs

		query = "select customername from customer where customersequencenumber = " & csn
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getCustomerName = rs("customername")
		end if

		set rs = nothing
	end function

	function validatePickupCounter()
		dim pickupCounter
		dim submitPickupCounter

		validatePickupCounter = true

		if session("pickupCounter") and  request.form("pickupCounter") <> "" then
			pickupCounter = session("pickupCounter")
			submitPickupCounter = request.form("pickupCounter")

			if clng(submitPickupCounter) < clng(pickupCounter) then
				validatePickupCounter = false
			else
				session("pickupCounter") = pickupCounter + 1
			end if
		end if
	end function

	function checkIfInvoicesOpen(ticketNumbers)
	  dim query, rs

	  checkIfInvoicesOpen = true

	  if ticketNumbers <> "" then

  	  query = " select count(*) as cnt from ticket where ticketnumber in (" & ticketNumbers & ")"
  	  query = query & " and ticketstatus in ('fi', 'vo')"

  	  set rs = getdisconnectedrecordset(query)


  	  if rs.recordcount > 0 then
  	    checkIfInvoicesOpen = (rs("cnt") = 0)
  	  end if

  	  set rs = nothing
	  end if

	end function

	sub initializeForPickUp()
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 1-Sep-2003	 Johnston		Added user defined track check number
    ' 5-Sep-2003	 Johnston		Added user defined prompt if account credit
    ' 14-Sep-2003	 Johnston		Added user defined prompt if account balance
	' 16-Sep-2003	 Johnston		Added user defined scan order at pickup
	'*****************************************************************



		if Not IsObject(Session("miscSetUp")) then
			initializeMiscSetUp
		end if
		set ObjMiscSetUp = Session("miscSetUp")
		if ObjMiscSetUp.Count > 0 then

		'Following added by J.Johnston, 1 Sept 2003
			if ObjMiscSetUp.Item("captureCheckNumber") then
				trackCheckNum = "1"
			else
				trackCheckNum = "0"
			end if

			if ObjMiscSetUp.Item("promptWhenCredit") then
				promptIfCredit = "1"
			else
				promptIfCredit = "0"
			end if

			if ObjMiscSetUp.Item("promptWhenBalance") then
				promptIfBalance = "1"
			else
				promptIfBalance = "0"
			end if
			if ObjMiscSetUp.Item("allowTempAccount") then
				allowPUTempAccount = "1"
			else
				allowPUTempAccount = "0"
			end if

            if not IsNull(ObjMiscSetUp.Item("CreditCardProcessorDomainID")) then
                ccProcessorDomainID = ObjMiscSetUp.Item("CreditCardProcessorDomainID")
            else
                ccProcessorDomainID = "0"
            end if
		end if

	end sub

	sub collectInvoiceDataFromQueryString()
		targetPage = Request.QueryString("targetPage")
		addOrEdit = Request.QueryString("addOrEdit")
		curr_LineNo = Request.QueryString("lineNo")
		selectedDept = Request.QueryString("dept")
		itemsStartIndex = Request.QueryString("itIndex")
		upChargeStartIndex = Request.QueryString("upIndex")
		colorsStartIndex = Request.QueryString("cIndex")
		patternStartIndex = Request.QueryString("pIndex")
		deptStartIndex = Request.QueryString("deptIndex")
		selItemId = Request.QueryString("selItemId")
		selUpchargeValue = Request.QueryString("selUp")
		selColorValue = Request.QueryString("selColor")
		selPatternValue = Request.QueryString("selPattern")
		originatingPage = Request.QueryString("originPage")
	end sub

	sub collectInvoiceDataFromForm()
		targetPage = Request.Form("tPage")
		addOrEdit = Request.Form("addOrEdit")
		curr_LineNo = Request.Form("lineNumber")
		selectedDept = Request.Form("selectedDept")
		itemsStartIndex = Request.Form("ItemPageCount")
		upChargeStartIndex = Request.Form("upChargePageCount")
		colorsStartIndex = Request.Form("colorsPageCount")
		patternStartIndex = Request.Form("PatternPageCount")
		deptStartIndex = Request.Form("DeptPageCount")
		selItemId = Request.Form("selItemId")
		selUpchargeValue = Request.Form("selUpcharge")
		selColorValue = Request.Form("selColor")
		selPatternValue = Request.Form("selPattern")
		originatingPage = Request.Form("originPage")
	end sub


	sub cancelForm()
		dim custSeqNumber
		custSeqNumber = Session("customerSequenceNumber")
		Response.Redirect "customerfunctions.asp?useraction=cancel&customerseq=" & custSeqNumber
	end sub

	sub markLinesPickedUp(pickupObj)
		dim lineCSV
		dim invoiceNumber
		dim lineNumber
		dim lineParts

		for each lineCSV in request.form("selectedLineItem")
			lineParts = split(lineCSV, ",")
			lineNumber = lineParts(0)
			invoiceNumber = lineParts(1)

			pickupObj.markLinePickedUp invoiceNumber, lineNumber
		next
	end sub

	sub applyPayments()
		dim custSeqNumber
		dim empId
		dim terminalId
		dim invNumbers
		empId = Session("employeeID")
		terminalId = Session("terminalID")
		custSeqNumber = Session("customersequencenumber")

		set pickupObj = Session("pickupObj")
		pickupObj.pickupReceipt = 0

		markLinesPickedUp pickupObj

		pickupObj.applyPayments empId, terminalId, pickupObj.constructTicketNosString() , -1

		invNumbers = pickupObj.getTicketNosForPrinting()
		dim totalchangedue
		totalchangedue = pickupObj.getChangeDue()

		if pickupObj.userAction <> "prepay" then
			dim i
			dim ticket_numbers

			ticket_numbers = split(invNumbers, ",")

			for i = lbound(ticket_numbers) to ubound(ticket_numbers)
				CBS_TriggerNotification "NPICKUP", empId, custSeqNumber, ticket_numbers(i)
			next


            if isMessengerEnabled() and (smsPickup or emailPickup) then
                on error resume next
                Dim data, httpRequest, postResponse

                data = "customerSeq=" & custSeqNumber

                Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
                httpRequest.Open "POST", getMessengerFullPath("main") & "/pickupOccurred", False
                httpRequest.SetRequestHeader "Content-Type", "application/x-www-form-urlencoded"
                httpRequest.Send data
                postResponse = httpRequest.ResponseText
            end if

			recordPickupNote
		end if

        if tipAmt > 0 then
            on error resume next
            Dim urlPath
            Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
            httpRequest.Open "POST", getAddressPath("main") & getCommonShortPath() & "/checkTip", False
            httpRequest.SetRequestHeader "Content-Type", "application/x-www-form-urlencoded"
            httpRequest.Send ""
            postResponse = httpRequest.ResponseText
        end if

        checkOnDemand()


		if isSubDividedTicket() then
             path = "pickupChoice.asp?userAction=print&addOrEdit=" _
                                & addOrEdit & "&ticketNumber=" & invNumbers _
                                & "&invoiceType=P&customerseq=" & custSeqNumber _
                                & "&totalchangedue="& totalchangedue _
                                & "&action=" & pickupObj.userAction
             Response.Redirect path
        else
            Response.Redirect "customerfunctions.asp?userAction=print&addOrEdit=" _
                                & addOrEdit & "&ticketNumber=" & invNumbers _
                                & "&invoiceType=P&customerseq=" & custSeqNumber _
                                & "&totalchangedue="& totalchangedue _
                                & "&action=" & pickupObj.userAction _
                                & "&onDemCredit=" & onDemCredit
        end if
	end sub

	function checkOnDemand()
        dim query, rs, custSeqNumber, odcAwarded
		custSeqNumber = Session("customersequencenumber")

        query = " select ondemandqualified from customer where customersequencenumber = " & custSeqNumber & " and ondemandqualified = 1 "
        set rs = getdisconnectedrecordset(query)

        if rs.recordcount > 0 then
        	query = "getprobableondemandcoupons " & custSeqNumber
        	Set rs = getDisconnectedRecordset(query)

            if rs.recordcount > 0 then
                rs.MoveFirst
                while not rs.EOF
                    if rs("type") = 2 then
                        dim amt, refId
                        amt = rs("creditAmt")

                        query = "AwardOnDemandCoupon " & custSeqNumber & ", " & rs("id")
                        QryExecute(query)

                        query = "SET NOCOUNT ON; INSERT into MiscCharge (storeid, CustomerSequenceNumber, chargedate, ChargeType, " _
                            & "CreditType, ChargeDescription , chargeamount, effectivedate, createddate, createdEmployeeid, " _
                            & "hardwareid,paymentgroupnumber, internaltransaction, terminalid, ondemandId) " _
                            & " values  (" & session("storeid") & ", " & custSeqNumber & ", getdate(), 'C', " _
                            & "'C', 'On Demand Earned Credit', " & amt & ", getdate(),getdate(), 1, null, null, 1, " _
                            & session("terminalid") & ", " & rs("id") & "); select scope_identity(); set nocount off"
                        dbstartTrans()
                        refId = qryexecutewithtransandselect(query)
                        dbEndTrans()

                        query = "INSERT into GeneralLedger(customerSequenceNumber, refNumber, refType, refDescription, " _
                            & "amountDue, totalAmountDue, totalBalance, termDate, createdDate, createdEmployeeID) " _
                            & " values  (" & custSeqNumber & ", " & refId & ", 'MC', 'On Demand Earned Credit', -1 * "  _
                            & amt & ", -1 * " & amt & ", -1 * " & amt & ", getdate(), getdate(), 1)"
                        qryexecute query

                        onDemCredit = onDemCredit + amt
                    end if
                    rs.MoveNext
                wend
            end if
        end if
	end function

	function getODCTarget(odcid)
		dim query, rs

		if odcid <> "" then
			query = " select cri_target from ondemandcoupon where id = " & odcid
			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				getODCTarget = trim(rs("cri_target"))
			end if

			set rs = nothing
		end if
	end function

	function getCustomerCriField(customerSeq, target)
		dim query, rs

		select case lcase(target)
		case "dollarsspent"
			query = " select dbo.getCustomerSales(" & customerSeq & ", null, null) as val "
		case "visits"
			query = " select dbo.getCustomerVisits(" & customerSeq & ", null, null) as val from customer "
		end select

		if query <> "" then
			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				getCustomerCriField = rs("val")
			end if

			set rs = nothing
		end if

	end function


	function isSubDividedTicket()
	    dim query, rs

	    query = "select id from InvoiceSubDivision where pickedup = 0 and ticketNumber in (" & pickupObj.getTicketNosForPrinting() & ")"
	    set rs = getdisconnectedrecordset(query)

        isSubDividedTicket = rs.recordcount > 0
	end function


	sub recordPickupNote()
		dim query


		query = "insert into customernote (customersequencenumber, storeguid, source, note)"
		query = query & " select " & Session("customersequencenumber")
		query = query & ", store.guid"
		query = query & ", '" & session("employeename") & "'"
		query = query & ", 'Picked up invoice " & sInvoicelist & "'"
		query = query & " from store where storeid = " & session("storeid")

		qryexecute query

	end sub

	sub initialize()

    '=======================================================================
	' Initializes ObjMiscSetup,
	' Initializes CustomerPayment object,
	' Retrieves and sets variables for:
	'  payment type, account type, credit card number and exp date,
	'  accountBalance (=0 UNLESS there is a balance DUE on account),
	'  creditBalance (the calculated account balance),
	'  trackCheckNum flag
	'
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    '
	'*****************************************************************

		'Following added by J.Johnston, 25Sept03
		if Not IsObject(Session("miscSetUp")) then
			initializeMiscSetUp
		end if
		set ObjMiscSetUp = Session("miscSetUp")
		'End addition by J.Johnston, 25Sept03

		if actionString = "prepay" OR actionString = "pickup" then
			initializeCustomerPaymentInfo
		end if
		set custPaymentObj = Session("customerPayment")

		if custPaymentObj.Count > 0 then
			if not IsNull(custPaymentObj.Item("PaymentTypeName")) then
				custPaymentType = custPaymentObj.Item("PaymentTypeName")
			else
				custPaymentType = ""
			end if
			temporaryAccount = custPaymentObj.Item("temporaryAccount")
			if temporaryAccount then
				temporaryAccount ="1"
			else
				temporaryAccount ="0"
			end if
			permanentAccount = custPaymentObj.Item("permanentAccount")
			if permanentAccount then
				permanentAccount ="1"
			else
				permanentAccount ="0"
			end if

			'  accountBalance =0 UNLESS there is a balance DUE on account
			if not IsNull(custPaymentObj.Item("accountBalance")) then
				accountBalance = custPaymentObj.Item("accountBalance")
			else
				accountBalance = 0
			end if

			'Following added by J.Johnston, 5 Sept 2003
			if not IsNull(custPaymentObj.Item("creditBalance")) then
				creditBal = custPaymentObj.Item("creditBalance")
			else
				creditBal = 0
			end if
			'End addition by J.Johnston, 5 Sept 2003

			'Following added by J.Johnston, 25 Sept 2003
			'if ObjMiscSetUp.Item("trackCheckNumber") then	'JJ modified, 6Jan2004
			if ObjMiscSetUp.Item("captureCheckNumber") then
				trackCheckNum = "1"
			else
				trackCheckNum = "0"
			end if
			'End addition by J.Johnston, 25 Sept 2003

			'Following added by J.Johnston, 10 Oct 2003
			if not IsNull(custPaymentObj.Item("CreditLimit")) then
				creditLimit = custPaymentObj.Item("CreditLimit")
			else
				creditLimit = 0
			end if
			'End addition by J.Johnston, 10 Oct 2003

		else
			custPaymentType =""
			temporaryAccount ="0"
			accountBalance = 0
		end if

		if not IsNull(ObjMiscSetUp.Item("CreditCardProcessorDomainID")) then
            ccProcessorDomainID = ObjMiscSetUp.Item("CreditCardProcessorDomainID")
        else
            ccProcessorDomainID = "0"
        end if

	end sub


	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

	sub addTemporaryAccount()
		dim ssql
		dim acctBal
		dim creditLimit
		dim amountPaid
		dim paymentTermsId

		amountPaid = Request.Form("amount")
		'acctBal = Request.Form("txtAccountBalance")
		creditLimit = Request.Form("txtCreditLimit")
		custSeqNumber = Session("customerSequenceNumber")
		paymentTermsId = Request.Form("paymentTerms")
		if IsEmpty(paymentTermsId) then
			ssql ="Update Customer Set CreditLimit=" _
				& creditLimit & ", temporaryAccount=1 Where customerSequenceNumber=" & custSeqNumber
		else
			ssql ="Update Customer Set CreditLimit=" _
				& creditLimit & ", temporaryAccount=1, paymentTermsId=" & paymentTermsId _
				& " Where customerSequenceNumber=" & custSeqNumber
		end if
		QryExecute ssql
		addOnAccountPayment amountPaid
	end sub


	sub addOnAccountPayment(amountpaid)
		if isPrepay then
			collectInvoiceDataFromForm
		end if
		if amountpaid = "" then
			amountpaid = Request.QueryString("amount")
		end if
		if len(trim(amountpaid)) > 0 then
			amountpaid = CDbl(amountpaid)
			set pickupObj = Session("pickupObj")

            'If the customer has set up that another account has billing responsibility, transfer the credit
            'to that account. Otherwise the credit never actually gets used even if the popup asks to use it,
            'it just gets added to the On Account for the customer with billing responsibility. Once the credit
            'has been transferred, it cannot be transferred back
            dim billingResponsibilityId : billingResponsibilityId = hasBillingResponsibility
			if request.querystring("usingCredit") = 1 and billingResponsibilityId <> 0 then
			    dim refId

                query = "SET NOCOUNT ON; INSERT into MiscCharge (storeid, CustomerSequenceNumber, chargedate, ChargeType, " _
                    & "CreditType, ChargeDescription , chargeamount, effectivedate, createddate, createdEmployeeid, " _
                    & "hardwareid,paymentgroupnumber, internaltransaction, terminalid) " _
                    & " values  (" & session("storeid") & ", " & billingResponsibilityId & ", getdate(), 'C', " _
                    & "'C', 'On Demand Earned Credit Transfer', " & amountpaid & ", getdate(),getdate(), 1, null, null, 1, " _
                    & session("terminalid") & "); select scope_identity(); set nocount off"
                dbstartTrans()
                    refId = qryexecutewithtransandselect(query)
                dbEndTrans()

                query = "INSERT into GeneralLedger(customerSequenceNumber, refNumber, refType, refDescription, " _
                    & "amountDue, totalAmountDue, totalBalance, termDate, createdDate, createdEmployeeID) " _
                    & " values  (" & billingResponsibilityId & ", " & refId & ", 'MC', 'On Demand Earned Credit', -1 * "  _
                    & amountpaid & ", -1 * " & amountpaid & ", -1 * " & amountpaid & ", getdate(), getdate(), 1)"
                qryexecute query

                query = "INSERT into GeneralLedger(customerSequenceNumber, refNumber, refType, refDescription, " _
                    & "amountDue, totalAmountDue, totalBalance, termDate, createdDate, createdEmployeeID) " _
                    & " values  (" & session("customersequencenumber") & ", " & refId & ", 'PR', 'Prepay', "  _
                    & amountpaid & ", " & amountpaid & ", " & amountpaid & ", getdate(), getdate(), 1)"
                qryexecute query
			end if
		    pickupObj.addPayment amountPaid, "On Account"
		end if

	end sub

	function hasBillingResponsibility()
	    dim query, rs
	    query = "select billingCustomerSeq from customer where customersequencenumber = " & session("customersequencenumber")
	    set rs = getdisconnectedrecordset(query)

        if rs("billingCustomerSeq") <> "" then
            hasBillingResponsibility = rs("billingCustomerSeq")
        else
            hasBillingResponsibility = 0
        end if
	end function


	sub addClearentCreditPayment()
		dim cardType
		dim cardNumber
		dim cardExp
		dim amountPaid, amountApplied
		dim approvalCode, receiptNumber
		dim transactionID
		dim query
		dim clerk
		dim terminalId
		dim customerSeq
		dim rawAnswer
		dim token, addCCToFile, orderId, tipAmtTran

		amountPaid = Request.QueryString("amount")
		amountApplied = Request.QueryString("amount")
		if Request.QueryString("amountToApply") <> "" then
		    amountApplied = Request.QueryString("amountToApply")
		end if
		approvalCode = Request.QueryString("approvalCode")
		rawAnswer = Request.Form("rawAnswer")
		clerk = session("employeeid")
		terminalId = Session("terminalID")
		customerSeq = Session("customerSequenceNumber")
		orderId = Request.QueryString("orderId")
		tipAmtTran = Request.QueryString("tipAmt")

		if len(trim(amountPaid)) > 0 then
			amountPaid = CDbl(amountPaid)

			cardType = Request.QueryString("cardType")
			cardNumber = Request.QueryString("cardNumber")
			cardExp = Request.QueryString("cardExp")
			transactionID = Request.QueryString("transactionID")

			query = " insert into cardpayment(terminalid, clerk, customersequencenumber, success, transactionid, amount, rawAnswer) "
            query = query & " values ( "
            query = query & terminalid & ", "
            query = query & clerk & ", "
            query = query & customerseq & ", "
            query = query & "1, "
            query = query & "'" & dbstr(transactionid) & "', "
            query = query & "'" & dbstr(amountPaid) & "', "
            query = query & "'" & dbstr(rawAnswer) & "'"
            query = query & " ); SELECT SCOPE_IDENTITY(); SET NOCOUNT OFF;"

		    qryexecute query

            query = "update CardAttempt set Finished = 1 where TransactionId = '" & dbstr(transactionid) & "'"
            qryexecute query
            query = "update CardAttempt set Finished = 1, TransactionId = '" & dbstr(transactionid) & "' where orderId = '" & orderId & "'"
            qryexecute query

			addCCToFile = Request.QueryString("addCCToFile")
			token = Request.QueryString("token")

			if (addCCToFile = "1") then

                query = " update customer set "
                query = query & " creditcardnumber = '" & dbstr(token) & "', "
                query = query & " creditcardmaskednumber = '" & dbstr(cardNumber) & "', "
                query = query & " creditcardexpdate = '" & dbstr(cardExp) & "', "
                query = query & " creditcardtype = '" & dbstr(cardType) & "' "
                query = query & " where customersequencenumber = " & dbstr(customerseq)
		        qryexecute query

		        dim oldToken
		        oldToken = Request.QueryString("oldToken")
		        if oldToken <> "" then
                    query = "insert into Unusedtokens (token, apiKey) values ('" & dbstr(oldToken) & "', '" & cc_key & "')"
                    qryexecute query
		        end if

            elseif token <> "" then
                query = "insert into Unusedtokens (token, apiKey) values ('" & dbstr(token) & "', '" & cc_key & "')"
		        qryexecute query
            end if

            if IsNumeric(tipAmtTran) then
              if tipAmtTran > 0 then
                dim attemptId, paymentId
                query = "select id from cardAttempt where transactionId = '" & dbstr(transactionid) & "'"
                set rs = getdisconnectedrecordset(query)
                attemptId = rs("id")
                query = "select cardpaymentid from cardPayment where transactionId = '" & dbstr(transactionid) & "'"
                set rs = getdisconnectedrecordset(query)
                paymentId = rs("cardpaymentid")

                query = " insert into EmployeeTip(tipamt, cardpaymentid, cardattemptid, ticketNumber) " _
                     & " values ( " _
                     & dbstr(tipAmtTran) & ", " _
                     & paymentId & ", " _
                     & attemptId & ", " _
                     & split(pickupObj.getTicketNosForPrinting(), ",")(0) & " )"
                qryexecute query
                tipAmt = tipAmt + tipAmtTran
              end if
            end if


			set pickupObj = Session("pickupObj")
			pickupObj.addPayment amountApplied, "Credit Card", cardNumber, cardExp, cardType,, transactionID, transactionID
		end if
	end sub


	sub addFailedClearentCreditPayment()
		dim query, rs
		dim rawAnswer, clerk, terminalId, customerSeq
		dim amountAtt, orderId, readingError, cardPaymentId

		amountAtt = Request.QueryString("amount")
		rawAnswer = Request.Form("rawAnswer")
		readingError = Request.QueryString("readingError")
		orderId = Request.QueryString("orderId")
		clerk = session("employeeid")
		terminalId = Session("terminalID")
		customerSeq = Session("customerSequenceNumber")

		if lcase(rawAnswer) <> "timeout" then

			query = " insert into cardpayment(terminalid, clerk, customersequencenumber, success, amount, rawAnswer, amountApplied) "
            query = query & " values ( "
            query = query & terminalid & ", "
            query = query & clerk & ", "
            query = query & customerseq & ", "
            query = query & "0, "
            query = query & "'" & dbstr(amountAtt) & "', "
            query = query & "'" & dbstr(rawAnswer) & "', "
            query = query & "0"
            query = query & " ) "

            openConnection
            dbInsert query
            set rs = dbselect("select SCOPE_IDENTITY() as cardPaymentId")
            cardPaymentId = rs("cardPaymentId")
            set rs = nothing
            closeconnection


            if readingError then
                query = " insert into CardReadError(cardPaymentId, orderId, Tickets, ErrorMsg, apiKey) "
                 query = query & " values ( "
                 query = query & cardPaymentId & ", "
                 query = query & "'" & dbstr(orderId) & "', "
                 query = query & "'" & dbstr(Replace(pickupObj.constructTicketNosString(), "'", "")) & "', "
                 query = query & "'" & dbstr(rawAnswer) & "', "
                 query = query & "'" & dbstr(cc_key) & "'"
                 query = query & " ) "

                qryexecute query

            else
                query = "update CardAttempt set Finished = 1 where orderId = '" & orderId & "'"
                qryexecute query
            end if


		else
		    query = "insert into CardTimeout(OrderId, apiKey) values ('" & dbstr(orderId) & "', '" & dbstr(cc_key) & "')"
            qryexecute query
		end if
	end sub

	sub addCreditPayment()
		dim cardType
		dim cardNumber
		dim cardExp
		dim amountPaid
		dim approvalCode, receiptNumber
		dim transactionID

		amountPaid = Request.QueryString("amount")
		approvalCode = Request.QueryString("approvalCode")
		transactionID = Request.QueryString("transactionID")

		if len(trim(amountPaid)) > 0 then
			amountPaid = CDbl(amountPaid)

			cardType = Request.QueryString("cardType")
			cardNumber = Request.QueryString("cardNumber")
			cardExp = Request.QueryString("cardExp")

			set pickupObj = Session("pickupObj")

			pickupObj.addPayment amountPaid, "Credit Card", cardNumber, cardExp, cardType,, approvalCode, transactionID
		end if

        dim isPrev : isPrev = Request.QueryString("IsPrev")
        if isPrev = "1" then
            query = "select tipAmt from EmployeeTip et, CardPayment cp where et.CardPaymentId = cp.CardPaymentId and '" _
                & transactionID & "' = cp.TransactionID"
            set rs = getdisconnectedrecordset(query)
            if rs.recordcount > 0 then
                tipAmt = rs("tipAmt")
            end if
        end if
	end sub

	sub addPrepay()
		dim amountPaid

		if isPrepay then
			collectInvoiceDataFromForm
		end if

		amountPaid = Request.QueryString("amount")

		if len(trim(amountPaid)) > 0 then
			amountPaid = CDbl(amountPaid)
			if custPaymentObj.Count > 0 then

				set pickupObj = Session("pickupObj")
				pickupObj.addPayment amountPaid, "Prepay"
			end if
		end if
	end sub

	sub addGiftCardPayment()
		dim checkCardNo
		dim amountPaid
		dim paymentType
		dim ssql
		dim giftRst
		dim giftAmt

		if isPrepay then
			collectInvoiceDataFromForm
		end if
		paymentType = Request.Form("paymentType")
		amountPaid = CDbl(Request.Form("amount"))
		checkCardNo = Request.Form("giftCardList")
		ssql = "select giftValue from giftCard where giftCardId =" & checkCardNo
		set giftRst = getDisconnectedRecordset(ssql)
		giftAmt = giftRst("giftValue").value
		if giftAmt < amountPaid then
			amountPaid = giftAmt
		end if
		set pickupObj = Session("pickupObj")


		pickupObj.deletePaymentByName("GiftCard' and checkCardNo = '" & checkCardNo)

		pickupObj.addPayment amountPaid, paymentType, checkCardNo
	end sub

	sub addGiftCheckPayment()
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 3-Sep-2003	 Johnston		Added user defined track check number capability
	'*****************************************************************


		' If track check numbers is ON, at this point you are in the enterCardNumber page.
		' If track check numbers is OFF, at this point you have reloaded Pickup page.

		dim amountPaid
		dim checkCardNo
		dim paymentType
		dim trackCheckNum


		if isPrepay then
			collectInvoiceDataFromForm
		end if

		trackCheckNum = Request.QueryString("trackCheckNum")
		paymentType = Request.Form("paymentType")

		amountPaid = CDbl(Request.Form("amount"))
		if isempty(trackCheckNum) then
			checkCardNo = Request.Form("txtCardNumber")
		else
			paymentType = Request.QueryString("type")
			amountpaid = Request.QueryString("amountPaid")
			checkCardNo = null
		end if
		set pickupObj = Session("pickupObj")

		pickupObj.addPayment amountPaid, paymentType, checkCardNo
	end sub

	sub addCashPayment()
		dim amountPaid
		dim amtToBeApplied

		if isPrepay then
			collectInvoiceDataFromForm
		end if
		amountPaid = Request.QueryString("amount")
		amtToBeApplied = Request.QueryString("AmountApplied")

		set pickupObj = Session("pickupObj")

		if len(trim(amtToBeApplied)) > 0 then
			amtToBeApplied= cdbl(amtToBeApplied)
		else
			amtToBeApplied = 0
		end if

		if len(trim(amountPaid)) > 0 then
			amountPaid = CDbl(amountPaid)
			pickupObj.addPayment amountPaid, "Cash",,,,amtToBeApplied
			if err.number <> 0 then
				set errorList =  Server.CreateObject("Scripting.Dictionary")
				errorList.Add err.number,err.description & " addCashPayment"
				set session("errorList") = errorList
				Response.redirect("../include/error.asp")
			end if

		end if
	end sub

	sub addCouponPayment()
		dim amountPaid
		dim amtToBeApplied
		dim cardNo

		if isPrepay then
			collectInvoiceDataFromForm
		end if
		amountPaid = Request.QueryString("amount")
		amtToBeApplied = Request.QueryString("AmountApplied")
		cardNo = Request.Form("txtCardNumber")

		set pickupObj = Session("pickupObj")

		if len(trim(amtToBeApplied)) > 0 then
			amtToBeApplied= cdbl(amtToBeApplied)
		else
			amtToBeApplied = 0
		end if

		if len(trim(amountPaid)) > 0 then
			amountPaid = CDbl(amountPaid)
			pickupObj.addPayment amountPaid, "Coupon Payment", cardNo,,,amtToBeApplied
			if err.number <> 0 then
				set errorList =  Server.CreateObject("Scripting.Dictionary")
				errorList.Add err.number,err.description & " addCashPayment"
				set session("errorList") = errorList
				Response.redirect("../include/error.asp")
			end if
		end if

	end sub


	sub getAllRackLocations()
		dim ssql
		dim ticketNos
		ticketNos = pickupObj.constructTicketNosStrForInvDetails()
		if ticketNos <> "" then
		ssql ="Select Ticket.ticketNumber as ticketNumber, ticket.invoiceNumber, racklocationstart, racklocationend from  rackAssignment, Ticket " _
				& " where Ticket.ticketNumber IN(" & ticketNos & ") AND ticket.ticketnumber = rackassignment.ticketnumber " _
				& " Order by Ticket.ticketNumber"
		else
		ssql ="Select Ticket.ticketNumber as ticketNumber, ticket.invoiceNumber, racklocationstart, racklocationend from  rackAssignment, Ticket " _
				& " where 1 = 2 "
		end if
		set RackRst = getDisconnectedRecordset(ssql)
		Set Session("ticketRack") = RackRst

	end sub

	sub getActivePaymentTypes()
		dim ssql
		dim objRst
		ssql = "Select paymentTypeName, imageFileName from StorePaymentType where storeId=" & clng(storeId) _
				& " And enabled=1"
		set objRst = getDisconnectedRecordset(ssql)
		Set Session("paymentTypes") = objRst
	end sub

	sub getCoupon()
		dim couponRst
		dim invoiceNumber
		invoiceNumber = request.querystring("invoicenumber")

		if not pickupObj is nothing then
			set couponRst = pickupObj.getInvoiceCouponRst(invoiceNumber)

			Set Session("displayCoupons") = couponRst

			couponRst.PageSize =maxCouponsCount

			Response.Redirect "allCoupons.asp?targetPage=pickup&CorL=C&invoiceNumber=" & invoiceNumber & "&oldTPage=" & targetPage
		end if
	end sub

	function GetCustomerInfo(customerseq)

		dim query, rs


		query = " select customerid, "
		query = query & " isnull(creditcardnumber, '') as creditcardnumber, "
		query = query & " isnull(creditCardMaskedNumber, '') as creditCardMaskedNumber, "
		query = query & " isnull(creditcardexpdate, '') as creditcardexpdate, "
		query = query & " isnull(shippingzipcode, '') as creditcardzip "
		query = query & " from customer where customersequencenumber = " & customerseq

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			cc_xcid = rs("creditcardnumber")
			cc_expiration = rs("creditcardexpdate")
			cc_zip = rs("creditcardzip")
			cc_receipt = trim(rs("customerid"))
			cc_maskedCC = rs("creditCardMaskedNumber")
		end if

		set rs = nothing

	end function

	sub addCoupon()
		dim	ObjMiscSetUp
		dim allowCoupons
		dim oneDiscount
		dim empId
		dim terminalId
		dim empName
		dim storeName
		dim invoiceNumber

		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")
		invoiceNumber = Request.QueryString("invoiceNumber")

		allowCoupons = false
		oneDiscount = true

		set ObjMiscSetUp = Session("miscSetUp")

		if ObjMiscSetUp.Count > 0 then
			allowCoupons = ObjMiscSetUp.Item("allowDropoffCoupons")
			oneDiscount = ObjMiscSetUp.Item("oneDiscountPerInvoice")
		end if

		if allowCoupons then
			pickupObj.addInvoiceCoupon invoiceNumber, Request.QueryString("couponId"), oneDiscount, empId, terminalId, empName, storeName
			pickupObj.reloadInvoices
		end if

	end sub

	function getPhoneNumber()
		dim ssql
		dim rs
		dim mareacode
		dim mphonenum
		dim result

		ssql = "select MainAreaCode, MainPhone from Customer where customerSequenceNumber = '" & Session("customersequencenumber") & "'"
		set rs = getDisconnectedRecordset(ssql)

		result = ""

		if not rs is nothing and rs.RecordCount > 0 then
			mareacode = Trim(rs("MainAreaCode"))
			mphonenum = Trim(rs("MainPhone"))

			if mareacode <> "" then
				result = result & "(" & mareacode & ") "
			end if

			if mphonenum <> "" then
				result = result & Left(mphonenum, 3) & "-" & Right(mphonenum, 4)
			end if

			getPhoneNumber = result
		end if

		rs.Close
		set rs = nothing


	end function


	sub saveSignature()
		dim signature
		dim reason
		dim query, rs

		signature = Request.Form("signature")

		if signature <> "" then
			signature = CompressString(signature, 2)
			reason = Request.Form("signatureReason")

			query = "insert into signature (SigBMP, Reason, TicketNumber) SELECT "
			query = query & " '" & signature & "' as signature "
			query = query & " ,'" & reason & "' as reason "
			query = query & " ,ticketnumber from ticket where ticketnumber in (" & pickupObj.getTicketNosForPrinting() & ")"

			qryexecute query
		end if

	end sub

	function isInvoiceOnPickup(invoiceNumber)
		dim invoiceArr
		dim currInvoiceNumber
		dim i

		invoiceArr = split(sInvoicelist, ",")

		isInvoiceOnPickup = false

		for i = lbound(invoiceArr) to ubound(invoiceArr)
			currInvoiceNumber = trim(invoiceArr(i))
			if trim(invoiceNumber) = currInvoiceNumber then
				isInvoiceOnPickup = true
				exit function
			end if
		next
	end function

    function getReceiptOptions()
        dim query, rs

        query = "select triggerType from QueryAlert where id = -8"
        set rs = getdisconnectedrecordset(query)
        if rs("triggerType") <> 0 then
            query = "select sms, email from CustomerMessageSetup where QueryId = -8 and customerId = '"_
                & Session("customerSequenceNumber") & "'"
            set rs = getdisconnectedrecordset(query)
            if rs.recordCount > 0 then
                smsReceipt = rs("sms")
                emailReceipt = rs("email")
            else
                query = "select sms, email from CustomerMessageSetup where QueryId = -8 and customerId = 0"
                set rs = getdisconnectedrecordset(query)
                if rs.recordCount > 0 then
                    smsReceipt = rs("sms")
                    emailReceipt = rs("email")
                end if
            end if
        end if

        query = "select triggerType from QueryAlert where id = -12"
        set rs = getdisconnectedrecordset(query)

        if rs("triggerType") <> 0 then
            query = "select sms, email from CustomerMessageSetup where QueryId = -12 and customerId = '"_
                & Session("customerSequenceNumber") & "'"
            set rs = getdisconnectedrecordset(query)
            if rs.recordCount > 0 then
                smsPickup = rs("sms")
                emailPickup = rs("email")
            else
                query = "select sms, email from CustomerMessageSetup where QueryId = -12 and customerId = 0"
                set rs = getdisconnectedrecordset(query)
                if rs.recordCount > 0 then
                    smsPickup = rs("sms")
                    emailPickup = rs("email")
                end if
            end if
        end if

       notificationIP = getMessengerShortPath()

    end function


	function getCashDrawerFields()
	    dim query, rs

        printerIP = getPrinterShortPath()

        query = " select storehardware.cashdrawertype, isnull(printer.printername, '') as printername "
        query = query & " from storehardware "
        query = query & " left outer join printer on storehardware.cashdrawerattachedprinterid = printer.printerid "
        query = query & " where storehardware.hardwaretype = 'CD' "
        query = query & " and storehardware.terminalid = " & session("terminalid")

        set rs = getdisconnectedrecordset(query)
        if rs.recordcount > 0 then
            printerName = Replace(rs("printername"), "'", "\'")
        end if


        userIPAddress = getLocalPrinterAddress(session("terminalid"))

	end function
%>
<HTML>
<HEAD>

<TITLE>Pick Up</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../style/pickup.css" rel="stylesheet" type="text/css">
<link href="../style/overlay.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<script language="javascript" type="text/javascript" src="/script/cashdrawer.js"></script>
<script type="text/javascript" src="../External/jquery-3.4.1.js"></script>

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
var lastFocusControl;

function txtAmountEntered_onblur()
{
	lastFocusControl = event.srcElement;

	document.pickupForm.txtCashEntered.value = document.pickupForm.txtAmountEntered.value;
}

function displayUnfinishedTran() {
    clearConfirmMsg();
    var unfinishedOrder = '<%=unfinishedTran %>';
    if (unfinishedOrder == "0")
        return false;

    cbs_confirm("Customer has a previous unfinished credit card transaction, would you like to check it?", doCheckUnfinished, displayCardCreditPrompt);
	return true;
}

function doCheckUnfinished() {
    clearConfirmMsg();
    var unfinishedOrder = '<%=unfinishedTran %>';
    document.getElementById('onFile').style.display = 'block';
    checkUnfinished('<%=clearentServiceLoc%>', '<%=cc_key%>', unfinishedOrder);
}

function gotoCredit() {
    clearConfirmMsg();
	var preCardCreditId = document.pickupForm.preCardCreditId.value;
	var amountToApply = parseFloat(document.pickupForm.preCardCreditAmt.value);
	var invoiceBalance = parseFloat(document.pickupForm.amountDue.value);
	if(amountToApply > invoiceBalance)
	    amountToApply = invoiceBalance;

	document.pickupForm.action = "?userAction=addCreditPayment" +
	    "&transactionid=" + encodeURIComponent(preCardCreditId) +
		"&amount=" + encodeURIComponent(amountToApply);
	document.pickupForm.submit();
}


function displayCardCreditPrompt() {
    clearConfirmMsg();

	var preCardCreditAmt = parseFloat(document.pickupForm.preCardCreditAmt.value);
	var preCardCreditId = document.pickupForm.preCardCreditId.value;
	var amountToApply = 0;
	var invoiceBalance = parseFloat(document.pickupForm.amountDue.value);

	if(preCardCreditAmt > 0) {
		amountToApply = preCardCreditAmt
		if(amountToApply > invoiceBalance)
			amountToApply = invoiceBalance;

		cbs_confirm("Customer has a previous card credit of $" + formatAsMoney(preCardCreditAmt) +
		    ".\nDo you wish to apply $" + formatAsMoney(amountToApply) + " of this credit to the invoice?",
		    doUseCreditPay, displayAccountBalCreditPrompt)
		return true;
	}

	return false;
}

function doUseCreditPay() {
    clearConfirmMsg();
    var amountToApply = 0;
	var preCardCreditAmt = parseFloat(document.pickupForm.preCardCreditAmt.value);
	var preCardCreditId = document.pickupForm.preCardCreditId.value;
	var invoiceBalance = parseFloat(document.pickupForm.amountDue.value);

	if(preCardCreditAmt > 0) {
		amountToApply = preCardCreditAmt
		if(amountToApply > invoiceBalance)
			amountToApply = invoiceBalance;

	}
	document.pickupForm.action = "?userAction=addCreditPayment" +
	    "&transactionid=" + encodeURIComponent(preCardCreditId) +
		"&amount=" + encodeURIComponent(amountToApply) +
		"&IsPrev=1";
	document.pickupForm.submit();
}

function doUseAccountPay() {
        clearConfirmMsg();
		var tempAcctPay = document.pickupForm.accountPaymentAmount.value;
		var AcctBal = document.pickupForm.creditBal.value;
		var adjAcctBal  = eval(AcctBal)+eval(tempAcctPay);
		document.pickupForm.txtAmountEntered.value = -adjAcctBal;
        addOnAccountPayment(true);
        finishDisplayAccountBalCreditPrompt();
}


    function displayAccountBalCreditPrompt()
    {
        clearAlertMsg();
        clearConfirmMsg();
        //Added by J.Johnston, 15Oct03
        // Used to display account status prompts when user clicks on any amount key
		//Account with CREDIT
		var tempAcctPay = document.pickupForm.accountPaymentAmount.value;
		var AcctBal = document.pickupForm.creditBal.value;
		var adjAcctBal = eval(AcctBal)+eval(tempAcctPay);
		var totalDueDisplayed = eval(document.pickupForm.amountDue.value);

		if (document.pickupForm.promptIfCredit.value==1)
		{
			if(adjAcctBal<0 && totalDueDisplayed > 0)
			{
				var strMsg = "Customer has $" + Math.abs(adjAcctBal) + " in their account. Would customer like to pay from their account?";
				cbs_confirm(strMsg,useAccountCredit, finishDisplayAccountBalCreditPrompt)
				return;
			}
		}
        finishDisplayAccountBalCreditPrompt();
	}

	function useAccountCredit() {
	    var acctCredit = parseFloat(document.pickupForm.creditBal.value);
	    var tempAcctPay = document.pickupForm.accountPaymentAmount.value;
	    var adjAcctBal = eval(acctCredit)+eval(tempAcctPay);

		var adjAcctBal = eval(acctCredit)+eval(tempAcctPay);
		document.pickupForm.txtAmountEntered.value = -adjAcctBal;
		if(Math.abs(adjAcctBal)<=document.pickupForm.amountDue.value)
		{
			//if account holds less than amount due, only
			//Apply account total -- no more.
			amountPaid = Math.abs(adjAcctBal);
		}
		else
		{
			//if account holds more than amount due,
			amountPaid = document.pickupForm.amountDue.value;
		}

	    document.pickupForm.action = "?userAction=OnAccount&usingCredit=1&amount=" + amountPaid;
    	document.pickupForm.submit();
	}

	function finishDisplayAccountBalCreditPrompt() {
        clearConfirmMsg();
		if (document.pickupForm.promptIfBalance.value==1)
		{
			if(document.pickupForm.creditBal.value>0)
			{
				cbs_alert("Customer has a BALANCE DUE on ACCOUNT of $" + document.pickupForm.creditBal.value);
			}
		}
	}

//-->
</SCRIPT>
</HEAD>

<script type="text/javascript" src="/script/printing.js"></script>
<script type="text/javascript" src="/script/ccp-expresslink.js"></script>
<script type="text/javascript" src="../Script/clearent.js"></script>
<script type="text/javascript" src="../Script/json2.js"></script>
<script type="text/javascript">

	function getAmountDue()
	{
		return parseFloat($('input[name="amountDue"]').val());
	}
	function populateAmtDue()
	{
		document.pickupForm.txtAmountEntered.value = formatAsMoney(document.pickupForm.amountDue.value);
		document.pickupForm.txtCashEntered.value = formatAsMoney(document.pickupForm.amountDue.value);
	}


	function round(number,X) {
		X = (!X ? 2 : X);
		return Math.round(number*Math.pow(10,X))/Math.pow(10,X);
	}


	function validatePayment(amountPaid, type)
	{
		var amountDue = parseFloat(document.pickupForm.amountDue.value);
		if (amountDue <= 0) {
		    cbs_alert("Amount due is 0, cannot make an additional payment");
		    enableScreen();
		    return false;
		}

		if((type != "Cash" && type != "Coupon") && parseFloat(amountPaid) > parseFloat(amountDue))
		{
			cbs_alert("Cannot make excess payment.");
		    enableScreen();
			return false;
		}

		return true;
	}


	function cashIn(amt) {

		if (document.pickupForm.txtCashEntered.value =="") {
			document.pickupForm.txtCashEntered.value = 0;
		}
		document.pickupForm.txtCashEntered.value = round(eval(document.pickupForm.txtCashEntered.value) + eval(amt),2).toFixed(2);
		document.pickupForm.txtAmountEntered.value = document.pickupForm.txtCashEntered.value;
	}

	// just copied over the cash payment type for coupon
	// to my knowledge both should behave the same
	function addCouponPayment()
	{
		var amountPaid;
		var amountToBeApplied;
		var currentAmtDue;

		amountPaid = document.pickupForm.txtCashEntered.value;
		amountToBeApplied = document.pickupForm.txtAmountEntered.value;
		currentAmtDue =	document.pickupForm.amountDue.value;

		if (amountPaid.length == 0)
		{
			amountPaid = amountToBeApplied
			if (amountPaid > currentAmtDue)
				amountToBeApplied = currentAmtDue
			else
				amountToBeApplied = amountPaid
		}

		if(amountToBeApplied.length == 0)
		{
			show_focus("Enter amount to be applied.", "Amount Applied", document.pickupForm.txtAmountEntered);
			return false;
		}

		if (eval(amountToBeApplied) > eval(amountPaid))
		{
			show_focus("Amount to be applied can not be greater than what is paid.", "CBS Error", document.pickupForm.txtAmountEntered);
			return false;
		}

		if (validateAmount())
		{
			if(validatePayment(amountToBeApplied, "Coupon"))
			{
					if (amountToBeApplied > currentAmtDue)
					{
						amountToBeApplied = currentAmtDue
					}

				if(document.pickupForm.trackCheckNum.value == 1)
					document.pickupForm.action ="enterCardNumber.asp?Opage=pickup&type=Coupon Payment&amountPaid=" + amountPaid + "&amountApplied=" + amountToBeApplied;
				else
					document.pickupForm.action =  "?userAction=addCouponPayment&amount=" +  amountPaid + "&amountApplied=" + amountToBeApplied;

				document.pickupForm.submit();
			}
		}
	}





	function addCashPayment()
	{
		var amountPaid;
		var amountToBeApplied;
		var currentAmtDue;

		amountPaid =document.pickupForm.txtCashEntered.value;
		amountToBeApplied = document.pickupForm.txtAmountEntered.value;
		currentAmtDue =	document.pickupForm.amountDue.value;
		if (amountPaid.length == 0)
		{
			amountPaid = amountToBeApplied
			if (amountPaid > currentAmtDue)
				amountToBeApplied = currentAmtDue
			else
				amountToBeApplied = amountPaid

			if (currentAmtDue <= 0 && amountPaid > 0)
			{
				cbs_alert("Cannot make excess payment")
				return false;
			}
		}
		if(amountToBeApplied.length == 0)
		{
			show_focus("Enter amount to be applied.", "Applied Amount", document.pickupForm.txtAmountEntered);
			return false;
		}
		if (eval(amountToBeApplied) > eval(amountPaid))
		{
			show_focus("Amount to be applied can not be greater than what is paid.", "Applied Amount", document.pickupForm.txtAmountEntered);
			return false;
		}

		if (validateAmount())
		{
			if(validatePayment(amountToBeApplied, "Cash"))
			{
					if (amountToBeApplied > currentAmtDue)
					{
						amountToBeApplied = currentAmtDue
					}
				document.pickupForm.action = "?userAction=addCashPayment&amount=" +  amountPaid
											+ "&amountApplied=" + amountToBeApplied;
					document.pickupForm.submit();
			}
		}
	}



	function validateCashPayment(amountPaid) {
		var currentAmtDue;
		var permAcct;
		permAcct = document.pickupForm.permAccount.value;
		currentAmtDue =	document.pickupForm.amountDue.value;

		if (currentAmtDue <= 0 && amountPaid > 0){
			cbs_alert("Cannot make excess payment.");
			return false;
		}

		return true;
	}


	function addCheckPayment(type) {
		var amountPaid;
		//vivek following line added by vivek on 15 Feb 2003 to supress the return key
		event.keyCode = 0;

		amountPaid = document.pickupForm.txtAmountEntered.value;
		if (validateAmount()) {
			if(validatePayment(amountPaid, "Check")) {
				if(document.pickupForm.trackCheckNum.value == 1) {
					document.pickupForm.action ="enterCardNumber.asp?Opage=pickup&type=Check&amountPaid=" + amountPaid;
					document.pickupForm.submit();
				}else{
					document.pickupForm.action ="pickup.asp?userAction=cardNumber&type=Check&trackCheckNum=0&amountPaid=" + amountPaid;
					document.pickupForm.submit();
				}
			}
		}
	}
	function addTradePayment(type) {
		//vivek following line added by vivek on 15 Feb 2003 to supress the return key
		event.keyCode = 0;

		var amountPaid = document.pickupForm.txtAmountEntered.value;
		if (validateAmount()) {
			if(validatePayment(amountPaid, "Trade")) {
					document.pickupForm.action ="enterCardNumber.asp?Opage=pickup&type=Trade&amountPaid=" + amountPaid;
					document.pickupForm.submit();
			}
		}
	}
	function addGiftCertPayment() {
		var amountPaid = document.pickupForm.txtAmountEntered.value;
		if (validateAmount()) {
			if(validatePayment(amountPaid, "Gift Certificate")) {
				document.pickupForm.action ="enterCardNumber.asp?OPage=pickup&type=Gift Certificate&amountPaid=" + amountPaid;
				document.pickupForm.submit();
			}
		}
	}

	function addGiftCardPayment() {
		var amountPaid = document.pickupForm.txtAmountEntered.value;
		if (validateAmount()) {
			if(validatePayment(amountPaid, "GiftCard")) {
				document.pickupForm.action ="enterGiftCard.asp?type=GiftCard&amountPaid=" + amountPaid;
				document.pickupForm.submit();
			}
		}
	}


	function validateAmount()
	{
		var amountPaid = cleanNumeric(document.pickupForm.txtAmountEntered.value);
		if(amountPaid == "")	{
		    cbs_alert("Enter valid amount.");
			return false;
		}
		return true;
	}

	var savAmt
	var savData
	var savParams

	function credtCardSuccess(amount, data, params) {
        enableScreen();
        savAmt = amount;
        savData = data;
        savParams = params;
	    <% if promptToAddCC then %>
            if (data.xcaccountid && data.account != '<%=cc_maskedCC%>') {
                cbs_confirm("Do you wish to update the credit card information on file with this card?", addTrue, addFalse);
                return;
            }
	    <% end if %>
        gotoAddCreditPay(false);
	}

	function addTrue() {
        enableScreen();
        gotoAddCreditPay(true);
	}
	function addFalse() {
        enableScreen();
        gotoAddCreditPay(false);
	}

	function gotoAddCreditPay(addCardToFile) {
	    handleReceipt(savParams.transaction_id);
		var actionString = "?userAction=addCreditPayment" +
		    "&transactionid=" + encodeURIComponent(savParams.transaction_id) +
		    "&amount=" + encodeURIComponent(savAmt) +
			"&cardType=" + encodeURIComponent(savData.accounttype ? savData.accounttype : '') +
			"&cardNumber=" + encodeURIComponent(savData.account ? savData.account : '') +
			"&cardExp=" + encodeURIComponent(savData.expiration ? savData.expiration : '') +
			"&customerseq=<%=Session("customersequencenumber")%>" +
			"&approvalCode=" + encodeURIComponent(savData.approvalcode);
		if (addCardToFile) {
		    actionString += "&xcaccountid=" + encodeURIComponent(savData.xcaccountid) +
		        "&addCardToFile=1";
		}

		document.pickupForm.action = actionString;
		document.pickupForm.submit();
	}

    var savClerk;
	function beginCreditCardPurchase(amount, clerk) {
	    savClerk = clerk;
	    savAmt = amount;
        if ('<%=cc_xcid%>' === '')
            <% if termLicenseType = 2 then %>
                cbs_alert("No card on file and cannot use card reader on back office terminal. Unable to perform transaction")
            <% else %>
                sendCardRequest(false, amount, clerk);
            <% end if %>
        else {
            <% if termLicenseType = 2 then %>
                cbs_confirm('Back Office Terminals must use card on file', sendStoredCardTrue, '', 'Ok', 'Cancel');
            <% else %>
                var msg = "Would you like to use the card on file:\n\nAccount Number: <%=cc_maskedCC %>\nExp. Date: <%=cc_expiration %>";
                cbs_confirm(msg, sendStoredCardTrue, sendStoredCardFalse);
            <% end if %>
        }
	}

	function sendStoredCardTrue() {
	    clearConfirmMsg();
        enableScreen();
        sendCardRequest(true, savAmt, savClerk);
	}
	function sendStoredCardFalse() {
	    clearConfirmMsg();
        enableScreen();
        sendCardRequest(false, savAmt, savClerk);
	}

    function sendCardRequest(useStoredCard, amount, clerk) {
		var processor;
		var terminalid = <%=Session("terminalID")%>;
		var customerseq = <%=Session("customersequencenumber")%>;
		$(':button').attr('disabled', true);
        $("#home", parent.document)[0].style.pointerEvents = "none";
		processor = new CreditCardProcessor();

		if (useStoredCard) {
            document.getElementById('onFile').style.display = 'block';
            processor.Purchase({
                amount: amount,
                clerk: clerk,
                terminalid: terminalid,
                customerseq: customerseq,
                xc_account_id: '<%=cc_xcid%>',
                zip: '<%=cc_zip%>',
                receipt: '<%=cc_receipt%>',
                success: function(result_obj, params, result) {
                    credtCardSuccess(params.amount, result_obj, params);
                },
                failure: function(result_obj, params, result) {
                    enableScreen();
                    cbs_alert(result_obj.result + (result_obj.description ? "\n" + result_obj.description : ""));
                }
            });
		}
		else {
            document.getElementById('cardReader').style.display = 'block';
            processor.Purchase({
                amount: amount,
                clerk: clerk,
                terminalid: terminalid,
                customerseq: customerseq,
                xc_account_id: '',
                zip: '',
                receipt: '<%=cc_receipt%>',
                success: function(result_obj, params, result) {
                    credtCardSuccess(params.amount, result_obj, params);
                },
                failure: function(result_obj, params, result) {
                    enableScreen();
                    cbs_alert(result_obj.result + (result_obj.description ? "\n" + result_obj.description : ""));
                }
            });
		}
    }

    function forceOnFile() {
        clearAlertMsg();
        handleCardOption(0);
    }

 	function handleCardOption(selectedOpt) {
        clearOptionMsg();
		var customerseq = '<%=Session("customersequencenumber")%>';
        var amount = document.pickupForm.txtAmountEntered.value;
		var orderId = createOrderId('<%=sInvoicelist%>');
		if (orderId.length > 200)
		    orderId = orderId.substring(0, 199);
		var cardOption
		if (selectedOpt === 0)
		       cardOption = "On File"
		else
		    cardOption = "New Card";

        document.getElementById('onFile').style.display = 'block';
        $(':button').attr('disabled', true);
        $("#home", parent.document)[0].style.pointerEvents = "none";

        document.pickupForm.action = "?userAction=sendingCCTran" +
                "&amount=" + encodeURIComponent(amount) +
                "&customerseq=" + encodeURIComponent(customerseq) +
                "&cardOption=" + encodeURIComponent(cardOption) +
                "&orderId=" + encodeURIComponent(orderId);
        document.pickupForm.submit();
 	}

	function addCreditCardPayment(amountPaid)
	{
		var amountDue;

		amountDue = getAmountDue();

		if (amountPaid === '') {
		    cbs_alert("Need to select amount");
		    enableScreen();
		    return false;
		}

		if(parseFloat(amountPaid) > parseFloat(amountDue)) {
			cbs_alert("Can not make a credit card payment for more then the amount due.");
		    enableScreen();
			return false;
		}

		<%if use_clearent then %>
            cardOption = 1;
            var cc_token = '<%=cc_xcid%>';
            var cc_expiration = '<%=cc_expiration%>';
		    <% if termLicenseType = 2 then %>
                if (cc_token !== '' && cc_expiration !== '') {
                    cbs_confirm('Back Office Terminals must use card on file', forceOnFile, '', 'Ok', 'Cancel');
                    return false;
                }
                else {
                cbs_alert("No card on file and cannot use card reader on back office terminal. Unable to perform transaction")
                    return false;
                }
		    <% else %>
                if (cc_token !== '' && cc_expiration !== '')
                    cbs_select('Select Method', 1, 'On File|New Card', "handleCardOption");
                else
                    handleCardOption(cardOption);
            <% end if %>
		<% elseif enableXcharge then %>
			var clerk = <%=session("employeeid")%>;
			beginCreditCardPurchase(amountPaid, clerk);
		<% else %>
			document.pickupForm.action = "?userAction=addCreditPayment&amount=" + amountPaid;
			document.pickupForm.submit();
		<% end if %>
	}




	var amountPaid;
	function addOnAccountPayment(apply)
	{
	/*
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 11-Sep-2003	 Johnston		Changed to allow payment on TEMPORARY account
    ' 29-Sep-2003	 Johnston		Changed to limit amount paid to amount in account
    ' 10-Oct-2003	 Johnston		Changed to consider credit limit on account
	'*****************************************************************
	*/
		var paymentType;
		var temporaryAcct
		var acctBal;
		var permAcct;
		var allowTempAccount;
		var isApply;
		var amountEntered;


		amountEntered = parseFloat(document.pickupForm.txtAmountEntered.value);
		isApply = apply;

		temporaryAcct = document.pickupForm.tempAccount.value;
		paymentType = document.pickupForm.paymentType.value;
		permAcct = document.pickupForm.permAccount.value;
		allowTempAccount = document.pickupForm.allowPUTempAccount.value;

		var strMsg;

		//Following added by J.Johnston, 29 Sept 03
		var acctCredit;
		//How much in account? Positive OR negative.
		//acctCredit is NEGATIVE if $ to spend.
		//acctCredit is POSITIVE if Balance Due on account.
		acctCredit = parseFloat(document.pickupForm.creditBal.value);
		//End addition by J.Johnston, 29 Sept 03

		//Following added by J.Johnston, 30 Sept 03
		var tempAcctPay;	//Used to capture temporary account payment
		//This is a POSITIVE number if account payment has already been applied.
		tempAcctPay = document.pickupForm.accountPaymentAmount.value;

		var adjAcctBal;
		//adjAcctBal is what is in account LESS the amount previously applied.
		//adjAcctBal is NEGATIVE if $ to spend.
		//adjAcctBal is POSITIVE if Balance Due on account.
		adjAcctBal = eval(acctCredit)+eval(tempAcctPay);
		//End addition by J.Johnston, 30 Sept 03

		var creditLimit; //Added by J.Johnston 10 Oct 2003
		//Added by J.Johnston 10 Oct 2003. Customer's credit limit.
		//This is a POSITIVE number if credit is available.
		creditLimit = document.pickupForm.creditLimit.value;

		var creditAvail; //Added by J.Johnston 10 Oct 2003
		//creditAvail is the limit the customer can spend
		//creditAvail is amount in account plus the credit limit
		creditAvail = eval(creditLimit)-eval(adjAcctBal);  //Added by J.Johnston 10 Oct 2003. Store credit limit.

		//FIRST CHECK IF CUSTOMER HAS AN ACCOUNT OF ANY TYPE
		if(permAcct != 1 && amountEntered > -acctCredit) //Does NOT have a permanent account
		{
			if (temporaryAcct == 0)	//and, does NOT have a temporary account
			{

				if (allowTempAccount == 1)	//and, ALLOW CREATION OF TEMP ACCOUNT is checked. JJ Added 14Sep03
				{
				    amountPaid = document.pickupForm.txtAmountEntered.value;
				    cbs_confirm("Do you wish to set the customer as On Account", setUpOnAccount)
					return;
				}
				else	//do NOT ALLOW CREATION OF TEMP ACCOUNT.
				{
					cbs_alert("You cannot set up a temporary account at pickup.");
					return;
				}
			}
			else	//HAS a TEMPORARY account
			{
				acctBal = document.pickupForm.accountBalance.value;
				if (acctBal > 0)
				{
					cbs_alert("Can not have on account payment as it's a temporary account & previous balance is due");
					return;
				}
			}	//End addition by J.Johnston, 11Sep03
		}

		//CUSTOMER HAS SOME SORT OF ACCOUNT.
		if(creditAvail > 0) //Is there credit available?
		{
			//Customer HAS credit available -- money to spend.
			//AcctCredit is a NEGATIVE number if there is an account credit
			//Add temporary account payment (a POSITIVE number or zero)
			strMsg = "creditAvail is POSITIVE.\n";

			if(isApply)
			{
				//Customer wants to apply what is in account.
				if(Math.abs(adjAcctBal)<=document.pickupForm.amountDue.value)
				{
					//if account holds less than amount due, only
					//Apply account total -- no more.
					amountPaid = Math.abs(adjAcctBal);
				}
				else
				{
					//if account holds more than amount due,
					amountPaid = document.pickupForm.amountDue.value;
				}
			}
			else
			{
			//Does account have more or less than amount due?
			//if (Math.abs(adjAcctBal)<=document.pickupForm.txtAmountEntered.value)
				if (creditAvail <= document.pickupForm.txtAmountEntered.value)
				{
					//IF available credit is less than or equal to the amount due,
					//apply available credit, but no more amountPaid = Math.abs(adjAcctBal);
					amountPaid = creditAvail;
					strMsg = "amountPaid = "+amountPaid;
					strMsg = "Available credit is LESS than or EQUAL to amount due.\n"+strMsg;
				}
				else
				{
					//Available credit greater than amount due,
					//amount due is amount entered, i.e. Entire amount applied to account
					amountPaid = document.pickupForm.txtAmountEntered.value;
					strMsg = "amountPaid = "+amountPaid;
					strMsg = "Available credit is MORE than amount due.\n"+strMsg;
				}
			}
		}
		else	//Customer has EXCEEDED available credit
		{
			//Display error msg and exit
			strMsg = "Customer has exceeded available credit.  ";
			strMsg = strMsg + "Please change customer's credit limit or choose another payment type.";
			cbs_alert(strMsg);
			return;
		}

		if (validateAmount())
		{
			if(validatePayment(amountPaid, "On Account"))
			{
				temporaryAcct = document.pickupForm.tempAccount.value;
				paymentType = document.pickupForm.paymentType.value;
				permAcct = document.pickupForm.permAccount.value;
				allowTempAccount = document.pickupForm.allowPUTempAccount.value;

				if(permAcct != "1" && amountEntered > -acctCredit)
				{//Does NOT have a permanent account
					if (temporaryAcct == "0")
					{//and, does NOT have a temporary account
						if (allowTempAccount == "1")
						{//and, ALLOW CREATION OF TEMP ACCOUNT is checked. JJ Added 14Sep03
                            cbs_confirm("Do you wish to set the customer as On Account", setUpOnAccount)
							return;
						}
						else
						{//do NOT ALLOW CREATION OF TEMP ACCOUNT.
							cbs_alert("You cannot set up a temporary account at pickup.");
							return;
						}
					}	//JJ Added 11Sep03 -- IF should close here
					else	//HAS a TEMPORARY account
					{
						acctBal = document.pickupForm.accountBalance.value;
						if (acctBal > 0)
						{
							cbs_alert("Can not have on account payment as it's a temporary account & previous balance is due");
							return;
						}
						else	//JJ Added 11Sep03 -- if POSITIVE account balance, then apply payment
						{
							if(eval(creditAvail)-eval(amountPaid)>=0)
							//IF the available credit >= ticket amount, APPLY TO ACCOUNT
							{
								document.pickupForm.action = "?userAction=OnAccount&amount=" + amountPaid;
								document.pickupForm.submit();
							}
							else
							{
								//Display error msg and exit
								strMsg = "Customer has exceeded available credit.\n";
								strMsg = strMsg + "Credit Limit = $"+creditLimit+"\n";
								if(adjAcctBal<=0)
								{
									strMsg = strMsg + "Account balance = $"+Math.abs(adjAcctBal)+"\n\n";
								}else if(adjAcctBal>0){
									strMsg = strMsg + "Account balance DUE = $"+adjAcctBal+"\n\n";
								}
								//strMsg = strMsg + "Amount available in account = $"+adjAcctBal+"\n\n";
								strMsg = strMsg + "Please change customer's credit limit OR Choose another payment type.";
								cbs_alert(strMsg);
								return;
							}
						}	//End addition by J.Johnston, 11Sep03
					}
				}
				else
				{	//HAS a PERMANENT account
					if(eval(creditAvail)-eval(amountPaid)>=0)
					//IF the available credit >= ticket amount, APPLY TO ACCOUNT
					{
						document.pickupForm.action = "?userAction=OnAccount&amount=" + amountPaid;
						document.pickupForm.submit();
					}
					else
					{
						//Display error msg and exit
						strMsg = "Customer has exceeded available credit.\n";
						strMsg = strMsg + "Credit Limit = $"+creditLimit+"\n";
						if(adjAcctBal<=0)
						{
							strMsg = strMsg + "Account balance = $"+Math.abs(adjAcctBal)+"\n\n";
						}
						else if(adjAcctBal>0)
						{
							strMsg = strMsg + "Account balance DUE = $"+adjAcctBal+"\n\n";
						}
						//strMsg = strMsg + "Amount available in account = $"+adjAcctBal+"\n\n";
						strMsg = strMsg + "Please change customer's credit limit OR Choose another payment type.";
						cbs_alert(strMsg);
						return;
					}
				}
			}
		}
	}

	function setUpOnAccount() {
        clearConfirmMsg();
		document.pickupForm.action = "accountInfo.asp?amountPaid=" + amountPaid;
	}

	function cancelForm() {
		var targetPage;

		targetPage = document.pickupForm.tPage.value;

		<% if isPrepay then %>
			switch (targetPage) {
				case "detail":
						document.pickupForm.action = "detailedInvoice.asp?userAction=fromPickup&submit=cancel";
						break;
				case "counterSale":
						document.pickupForm.action = "counterSale.asp?userAction=fromPickup&submit=cancel";
						break;
				case "giftCard":
						document.pickupForm.action = "giftCards.asp?userAction=fromPickup&paid=false";
						break;
				case "loyalty":
						document.pickupForm.action = "customerFunctions.asp?userAction=fromLoyalty&paid=false&customerseq=<%=session("loyaltycustomerseq")%>";
						break;
				case "customerfunctions":
						document.pickupForm.action = "?userAction=cancel";
						document.pickupForm.submit();
						break;
			}
		<% else %>
			document.pickupForm.action = "?userAction=cancel";
		<% end if %>
		document.pickupForm.submit();
	}




	function submitForm()
	{
		var amountPaid;
		var amountDue;
		var minimumPrepayAmount;
		var targetPage;

		amountDue = document.pickupForm.amountDue.value;
		amountPaid = document.pickupForm.amountPaid.value;
		minimumPrepayAmount = document.pickupForm.minimumPrepayAmount.value;
		targetPage = document.pickupForm.tPage.value;


		<% if isPrepay then %>
			if (targetPage == "detail" && document.pickupForm.canPayLater.value != "True" && amountPaid < minimumPrepayAmount)
			{
				cbs_alert("Invoice must be prepaid at least $" + formatAsMoney(minimumPrepayAmount) + " before continuing.");
				return false;
			}
		<% else %>
			if (amountDue > 0)
			{
				cbs_alert("Invoice must be paid before pickup.");
				return false;
			}
		<% end if %>


		if (document.pickupForm.openCashDrawer.value == "1")
		{
            var url = "http://<%=userIPAddress%><%=printerIP%>/openCashDrawer"
            OpenCashDrawer(url, '<%= printerName %>');
		}

		document.pickupForm.doneButton.disabled = true;
		document.pickupForm.cancelButton.disabled = true;

		<% if isPrepay then %>
			switch (targetPage)
			{
				case "detail":
						document.pickupForm.action = "detailedInvoice.asp?userAction=fromPickup&submit=done";
						document.pickupForm.submit();
						break;
				case "counterSale":
		                if (document.pickupForm.amountDue.value > 0)
		                {
		                	cbs_alert("Counter sale items must be paid in full.");
                              enableMouseButton(1);
                              enableMouseButton(2);
		                	break;
		                }
						document.pickupForm.action = "counterSale.asp?userAction=fromPickup&submit=done&applyPrepayDiscount=0";
						document.pickupForm.submit();
						break;
				case "giftCard":
		                if (document.pickupForm.amountDue.value > 0)
		                {
		                	cbs_alert("Gift cards must be paid in full.");
                              enableMouseButton(1);
                              enableMouseButton(2);
		                	break;
		                }
						document.pickupForm.action = "giftCards.asp?userAction=fromPickup&paid=true";
						document.pickupForm.submit();
						break;
				case "loyalty":
		                if (document.pickupForm.amountDue.value > 0)
		                {
		                	cbs_alert("Loyalty cards must be paid in full.");
                              enableMouseButton(1);
                              enableMouseButton(2);
		                	break;
		                }
						document.pickupForm.action = "customerFunctions.asp?userAction=fromLoyalty&paid=true&customerseq=<%=session("loyaltycustomerseq")%>";
						document.pickupForm.submit();
						break;
				case "customerfunctions":
						document.pickupForm.action = "?userAction=done&pickupReceipt=0" ;
						document.pickupForm.submit();
						break;
				default:
						alert('Please contact Shahcorp if you see this message.');
						document.pickupForm.action = "?userAction=done&pickupReceipt=0" ;
						document.pickupForm.submit();
						break;
			}
		<% else %>
			document.pickupForm.action = "?userAction=done&pickupReceipt=0" ;
			document.pickupForm.submit();
		<% end if %>
	}

	function enableScreen() {
        $(':button').attr('disabled', false);
        $("#home", parent.document)[0].style.pointerEvents = "auto";

        document.getElementById('onFile').style.display = 'none';
        document.getElementById('cardReader').style.display = 'none';
	}

    var savReadError;
    function clearentFailure(rawAnswer, isTimeout, orderId, amount, readingError, screenMsg) {
        enableScreen();
        savAmt = amount;
        savOrderId = orderId;
        savReadError = readingError;
	    var raw = "";
	    if (!isTimeout)
            raw = JSON.stringify(rawAnswer).replace(/-/g, "");
	    else
	        raw = "Timeout";
		document.getElementById("rawAnswer").value =  raw;

		if (screenMsg)
            cbs_alert(screenMsg, finishCFailure);
        else
            finishCFailure();
    }

    function finishCFailure() {
        clearAlertMsg();
        document.pickupForm.action = "?userAction=addFailedClearentCreditPayment" +
                "&amount=" + encodeURIComponent(savAmt) +
                "&orderId=" + encodeURIComponent(savOrderId) +
                "&readingError=" + (savReadError ? "1" : "0");
        document.pickupForm.submit();
    }

   var savId;
   function handleReceipt(id) {
	    var smsReceipt = (String('<%=smsReceipt%>').toLowerCase() === "true");
	    var emailReceipt = (String('<%=emailReceipt%>').toLowerCase() === "true");
	    var savId = id;

	    if (smsReceipt || emailReceipt) {
	        //alert("Sending ele receipt");
            var loc = window.location.href;
            var extraCut = 0;
            if (loc.indexOf(":80") != -1)
                extraCut = 5;
            var endStop = loc.indexOf("/mainapp")
            if (endStop == -1)
                endStop = loc.indexOf("/MainApp")

            endStop = endStop - extraCut;
            var ipAddress = loc.substring(0, endStop);
            var url = ipAddress + "<%=notificationIP%>/sendReceipt?customerSeq=<%=Session("customersequencenumber")%>&ccId="
                + encodeURIComponent(id);

            try {
                $.ajax({
                    type: "POST",
                    url: url,
                    dataType: "text",
                    timeout: "3000",
                    success: function(xhr) {
                        var sentStyle;
                        if (smsReceipt && emailReceipt)
                            sentStyle = "both sms and email";
                        else if (smsReceipt)
                            sentStyle = "sms";
                        else
                            sentStyle = "email";
                        cbs_confirm("Receipt sent to " + sentStyle + ". Do you wish to also print a receipt?", doPrintCCRep);
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        cbs_alert("Unable to connect to CBS Messaging Service to send receipt\nMake sure service is running\nPrinting receipt instead");
                        PrintCreditCardReceipt(id);
                    }
                });
            } catch (exception) {
                cbs_alert("Unable to send - " + e.message);
                PrintCreditCardReceipt(id);
            }

	    }
        else {
	        //alert("Sending phys receipt");
            PrintCreditCardReceipt(id);
        }
    }

    function doPrintCCRep() {
        clearConfirmMsg();
        PrintCreditCardReceipt(savId);
    }


    var savCardType;
    var savCardNum;
    var savExpDate;
    var savAthCode;
    var savOrderId;
    var savToken;
    var savTipAmt;
	function clearentCardSuccess(id, amount, cardType, cardNum, expDate, authCode, rawAnswer, orderId, token, tipAmt) {
        enableScreen()

	    var raw = String(rawAnswer).replace(/-/g, "");
		document.getElementById("rawAnswer").value =  raw;
        var askToAdd = '<%=promptToAddCC%>'
        if (token && askToAdd == 1) {
            var cc_token = '<%=cc_xcid%>';
            var cc_expiration = '<%=cc_expiration%>';

            savId = id;
            savCardNum = cardNum;
            savAmt = amount;
            savExpDate = expDate;
            savAthCode = authCode
            savOrderId = orderId
            savToken = token;
            savTipAmt = tipAmt;
            if (cc_token !== '' && cc_expiration !== '')
            {
                //Old data exists. If different, ask, otherwise don't bother
                if (cc_token !== token || cc_expiration !== expDate)
                    cbs_confirm("Do you wish to update the credit card information on file with this card?", clearAddTrue, clearAddFalse)
               else
                    gotoSaveClear(id, amount, cardType, cardNum, expDate, authCode, orderId, token, "0", tipAmt)
            }
            else {
                cbs_confirm("Do you wish to add the credit card information to be on file?", clearAddTrue, clearAddFalse)
            }
        }
        else
            gotoSaveClear(id, amount, cardType, cardNum, expDate, authCode, orderId, token, "0", tipAmt);
    }

    function clearAddTrue() {
        clearConfirmMsg();
         gotoSaveClear(savId, savAmt, savCardType, savCardNum, savExpDate, savAthCode, savOrderId, savToken, "1", savTipAmt);

    }
    function clearAddFalse() {
        clearConfirmMsg();
        gotoSaveClear(savId, savAmt, savCardType, savCardNum, savExpDate, savAthCode, savOrderId, savToken, "0", savTipAmt);
    }


    function gotoSaveClear(id, amount, cardType, cardNum, expDate, authCode, orderId, token, addCCToFile, tipAmt)
    {
        document.pickupForm.action = "?userAction=addClearentCreditPayment" +
                "&transactionid=" + encodeURIComponent(id) +
                "&amount=" + encodeURIComponent(amount) +
                "&cardType=" + encodeURIComponent(cardType) +
                "&cardNumber=" + encodeURIComponent(cardNum) +
                "&cardExp=" + encodeURIComponent(expDate) +
                "&approvalCode=" + encodeURIComponent(authCode) +
                "&orderId=" + encodeURIComponent(orderId) +
                "&token=" + encodeURIComponent(token) +
                "&tipAmt=" + encodeURIComponent(tipAmt) +
                "&addCCToFile=" + encodeURIComponent(addCCToFile) +
                ('<%=cc_xcid%>' != '' ? "&oldToken=<%=cc_xcid%>" : '');

        document.pickupForm.submit();
	}


	function formatAsMoney(mnt)
	{
		mnt -= 0;
		mnt = (Math.round(mnt*100))/100;
		return (mnt == Math.floor(mnt)) ? mnt + '.00' : ( (mnt*10 == Math.floor(mnt*10)) ? mnt + '0' : mnt);
	}

	function formatStrLeadNTail(fLength, lead, tail)
	{
	     var nBlanks;
             var result;
             var count;

             nBlanks = fLength - lead.length - tail.length;
             result = lead;

             for(count = 0; count < nBlanks; count++)
                 result += " ";

            result +=  tail;

            return result;
	}

	function startupActions(){
		var signature;
		var promptForSignature;
	    var paidAmt;
        var invoiceAmt;

		//Added by SteveG
	    invoiceAmt = document.pickupForm.total.value;
        paidAmt = document.pickupForm.amountPaid.value;

		lastFocusControl = document.pickupForm.txtAmountEntered;

		//Following added by J.Johnston, 15OCT03
		document.pickupForm.txtAmountEntered.focus()
		document.pickupForm.txtAmountEntered.select()
		//End addition by J.Johnston, 15OCT03

		<% if lcase(request.querystring("useraction")) = "addcreditpayment" or lcase(request.querystring("useraction")) = "addclearentcreditpayment"  then %>
            <% if lcase(request.querystring("useraction")) = "addclearentcreditpayment"  then %>
                handleReceipt(<%= request.querystring("transactionid")%>);
            <% end if %>
		if(document.pickupForm.amountDue.value == 0)
		{
			submitForm();
		}
		<% end if %>

        <% if request.querystring("useraction") = "sendingCCTran" then %>
          $(':button').attr('disabled', true);
          $("#home", parent.document)[0].style.pointerEvents = "none";

          var amount = '<%= request.querystring("amount")%>';
          var orderId = '<%= request.querystring("orderId")%>';
          var customerseq = '<%= request.querystring("customerseq")%>';
          if('<%= request.querystring("cardOption")%>' === 'On File') {
              var cc_token = '<%=cc_xcid%>';
              var cc_expiration = '<%=cc_expiration%>';
             document.getElementById('onFile').style.display = 'block';
             chargeOnFileCard(amount, cc_token, cc_expiration, customerseq, '', '<%=cc_url%>', '<%=cc_key%>', '<%=cc_zip%>', orderId);
          }
          else if ('<%= request.querystring("cardOption")%>' === 'New Card') {
              document.getElementById('cardReader').style.display = 'block';
              performSale(amount, '<%=cc_url%>', '<%=cc_key%>', "applyPayment", '<%=cc_zip%>', orderId);
          }

        <% else %>

		<% if request.querystring("useraction") = "pickup" then %>
		<% if ObjMiscSetUp.Item("OnaccountAutoAmtDue") and permanentAccount = 1 then %>
		populateAmtDue();
		addOnAccountPayment();
		<% end if %>
		<% end if %>

        <% if request.querystring("useraction") <> "addClearentCreditPayment" then %>
            if (displayUnfinishedTran())
                return true;
        <% end if %>
		if(displayCardCreditPrompt()) {
			return true;
		}

		<% if not(ObjMiscSetUp.Item("OnaccountAutoAmtDue")) and (request.querystring("useraction") = "pickup" or request.querystring("useraction") = "prepay") then %>
		displayAccountBalCreditPrompt();
		<% end if %>

        <% end if %>
	}

	function printRackLocations() {
		PrintRackSlip('<%=pickupObj.getTicketNosForPrinting()%>');
	}

	function addPayment(element) {
		var paymentTypeName;
		var amountPaid = document.pickupForm.txtAmountEntered.value;

		if(!isStrNumeric(amountPaid))
			return false;


		if(isNaN(parseFloat(amountPaid)) || parseFloat(amountPaid) <= 0) {
			cbs_alert("Payment must be above zero.");
			return false;
		}
		paymentTypeName =  element.id;
		document.pickupForm.doneButton.disabled = true;
		document.pickupForm.cancelButton.disabled = true;

		switch (paymentTypeName) {
			case "Cash":
				addCashPayment();
				break;
			case "Check":
				addCheckPayment();
				break;
			case "Gift Certificate":
				addGiftCertPayment();
				break;
			case "GiftCard":
				addGiftCardPayment();
				break;
			case "Credit Card":
				addCreditCardPayment(amountPaid);
				break;
			case "On Account":
				addOnAccountPayment();
				break;
			case "Coupon Payment":
				addCouponPayment();
				break;
			case "Trade":
				addTradePayment();
				break;
		}
	}

	function deletePayment(element) {
		var paymentTypeName;

		paymentTypeName =  element.id;
		switch (paymentTypeName) {
			case "d_Cash":
				document.pickupForm.action =  "?userAction=deletePayment&type=Cash"
				break;
			case "d_Check":
				document.pickupForm.action =  "?userAction=deletePayment&type=Check"
				break;
			case "d_Gift Certificate":
				document.pickupForm.action =  "?userAction=deletePayment&type=Gift Certificate"
				break;
			case "d_GiftCard":
				document.pickupForm.action =  "?userAction=deletePayment&type=GiftCard"
				break;
			case "d_Credit Card":
				document.pickupForm.action =  "?userAction=deletePayment&type=Credit Card"
				break;
			case "d_On Account":
				document.pickupForm.action =  "?userAction=deletePayment&type=On Account"
				break;
			case "d_Coupon Payment":
				document.pickupForm.action =  "?userAction=deletePayment&type=Coupon Payment"
				break;
			case "d_Trade":
				document.pickupForm.action =  "?userAction=deletePayment&type=Trade"
				break;
			case "d_Total":
				document.pickupForm.action =  "?userAction=deletePayment&type="
				break;

		}

		document.pickupForm.submit();
	}

	function decimalFormat() {
		var price = trim(document.pickupForm.txtAmountEntered.value);
		if(price.length > 0) {
			price = cleanNumeric(price);
			if(price == "")	{
				cbs_alert("Enter valid amount.");
				return;
			}
		}
		document.pickupForm.txtAmountEntered.value = autoFormatCurrency(document.pickupForm.txtAmountEntered.value);
	}

	function getCoupon()
	{
		<% if instr(sinvoicelist, ",") > 0 then %>
		cbs_select("Choose invoice:", 1, "<%=replace(sinvoicelist, ",", "|")%>", "handleInvSelReturn");
		<% else %>
		handleCouponChoice("<%=sinvoicelist%>");
		<% end if %>
	}

   function handleInvSelReturn(returnVal) {
        var inv = "<%=sinvoicelist%>".split(",")[returnVal]
        handleCouponChoice(inv);
   }

	function handleCouponChoice(invoiceNumber) {
		if(invoiceNumber != "") {
			document.pickupForm.action = "?userAction=getCoupon&invoiceNumber=" + invoiceNumber;
			document.pickupForm.submit();
		}
	}

    var missingTranJson
	function handleClearentSearch(missingTran) {
        document.getElementById('onFile').style.display = 'none';
        document.getElementById('cardReader').style.display = 'none';
	    if (missingTran == "") {
	        cbs_alert("Credit Card transaction was not approved", displayAccountBalCreditPrompt);
	        return;
	    }

	    //console.log(missingTran)
	    missingTranJson = JSON.parse(missingTran);
	    var amountToApply = missingTranJson.amount;
	    var invoiceBalance = parseFloat(document.pickupForm.amountDue.value);
        if(amountToApply > invoiceBalance)
            amountToApply = invoiceBalance;

        var msg = "Found Clearent transaction that was approved but not in our database. " +
                  	        "Do you wish to apply $" + formatAsMoney(amountToApply) + " of this payment to this invoice?\nAmount: $" + missingTranJson.amount +
                  	        "\nCard Last Four: " + missingTranJson.card;
        cbs_confirm(msg, applyMissing);
	}

    function applyMissing() {
        clearConfirmMsg();
	    var amountToApply = missingTranJson.amount;
	    var invoiceBalance = parseFloat(document.pickupForm.amountDue.value);
        if(amountToApply > invoiceBalance)
            amountToApply = invoiceBalance;
        document.pickupForm.action = "?userAction=addClearentCreditPayment" +
                "&transactionid=" + encodeURIComponent(missingTranJson.id) +
                "&amount=" + encodeURIComponent(missingTranJson.amount) +
                "&amountToApply=" + encodeURIComponent(amountToApply) +
                "&cardType=" + encodeURIComponent("") +
                "&cardNumber=" + encodeURIComponent(missingTranJson.card) +
                "&cardExp=" + encodeURIComponent(missingTranJson["exp-date"]) +
                "&approvalCode=" + encodeURIComponent(missingTranJson["authorization-code"]) +
                "&rawAnswer=" + encodeURIComponent(missingTranJson) +
                "&token=" + encodeURIComponent("") +
                "&addCCToFile=0";

        document.pickupForm.submit();
    }

    window.addEventListener('beforeunload', (event) => {
      if (document.getElementById('cardReader').style.display == 'block') {
        closeMsg('<%=cc_url%>', '<%= Session("employeeID") %>', '<%= Session("customersequencenumber") %>',
                '<%=sInvoicelist%>', '<%= Session("terminalID") %>', '<%= Request.QueryString("orderId") %>')
      }
    });


        function preventBack() {
            window.history.forward();
        }

        setTimeout("preventBack()", 0);
        window.beforeunload = function() {
            null
        };



</script>

<style type="text/css">

.freeze { pointer-events: none; }

.hidden { display: none; }

</style>

<BODY id="body" topmargin=0 leftmargin=0 onLoad = "startupActions();">

<!-- #include file="../include/banner.inc" -->

<% if isPrepay then %>
<H1>Prepay <%=sInvoicelist%></H1>
<% else %>
<H1>Pickup <%=sInvoicelist%></H1>
<% end if %>


<div id="cardReader" class="overlay hidden">
  <h1 class="overlayHeader" style="text-align: center">Waiting on Card Reader</h1>
</div>

<div id="onFile" class="overlay hidden">
  <h1 class="overlayHeader" style="text-align: center">Transaction in Progress</h1>
</div>


<TABLE ALIGN=center WIDTH="100%" BORDER=0  CELLPADDING=1 >
	<FORM id="pickupForm" name="pickupForm" action="pickup.asp" method="Post" onSubmit="return false">
		<INPUT type="hidden" name="pickupCounter" value="<%=session("pickupCounter")%>" />
		<INPUT type="hidden" name="signature" value= "">
		<INPUT type="hidden" name="signatureReason" value= "">
		<INPUT type="hidden" name="paymentType" value="<%= custPaymentType%>">
		<INPUT type="hidden" name="tempAccount" value="<%= temporaryAccount%>">
		<INPUT type="hidden" name="accountBalance" value="<%= accountBalance%>">
		<INPUT type="hidden" name="permAccount" value="<%= permanentAccount%>">
		<INPUT type="hidden" name="trackCheckNum" value="<%= trackCheckNum%>">
		<INPUT type="hidden" name="promptIfCredit" value="<%= promptIfCredit%>">
		<INPUT type="hidden" name="creditBal" value="<%= formatnumber(creditBal,2,,,0)%>">
		<INPUT type="hidden" name="creditLimit" value="<%= formatnumber(creditLimit,2,,,0)%>">
		<INPUT type="hidden" name="promptIfBalance" value="<%= promptIfBalance%>">
		<INPUT type="hidden" name="allowPUTempAccount" value="<%= allowPUTempAccount%>">
		<INPUT type="hidden" name="ccPaymentMade" value="<%= ccPaymentMade%>">
		<INPUT type="hidden" name="actionString" value="<%= actionstring%>">
		<INPUT type="hidden" name="approvalCode" value="-1">
		<INPUT type="hidden" name="tranReceiptNumber" value="-1">

		<INPUT type="hidden" name="altPaymentAmount" value="<%= formatnumber(pickupObj.getPaymentByType("-Cash"), 2,,,0)%>">
		<INPUT type="hidden" name="cashPaymentAmount" value="<%= formatnumber(pickupObj.getPaymentByType("Cash"), 2,,,0)%>">
		<INPUT type="hidden" name="accountPaymentAmount" value="<%= formatnumber(pickupObj.getPaymentByType("On Account"), 2,,,0)%>">

		<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
		<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
		<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
		<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
		<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
		<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
		<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
		<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
		<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
		<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
		<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
		<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
		<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
		<INPUT type="hidden" name="invoicesTotal" value="<%= invoicesTotal %>">
		<INPUT type="hidden" name="openCashDrawer" value="<%if pickupObj.openCashDrawer then Response.Write "1" else Response.Write "0" end if%>">
		<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
		<INPUT type=hidden name=canPayLater value="<%=sec_FindPermission("/mainapp/pickup.asp", "cancelprepay", Session("employeeid"), false)%>">

		<INPUT type="hidden" name="total" value="<%=pickupObj.getTotal()%>">
		<INPUT type="hidden" name="amountDue" value="<%=pickupObj.getAmountDue()%>">
		<INPUT type="hidden" name="amountPaid" value="<%=pickupObj.getAmountPaid()%>">
		<INPUT type="hidden" name="changeDue" value="<%=pickupObj.getChangeDue()%>">
		<INPUT type="hidden" name="minimumPrepayAmount" value="<%=pickupObj.getMinimumPrepayAmount()%>">
		<INPUT type="hidden" name="isPrePay" value="<%=iif(pickupObj.isPrepay(), "1", "")%>">

		<INPUT type="hidden" name="preCardCreditAmt" value="<%=preCardCreditAmt%>">
		<INPUT type="hidden" name="preCardCreditId" value="<%=preCardCreditId%>">
		<INPUT type="hidden" id="rawAnswer" name="rawAnswer" value="">
		<INPUT type="hidden" id="custSeq" name="custSeq" value="<%= custSeqNumber %>">
		<INPUT type="hidden" id="totalTipAmt" name="totalTipAmt" value="<%= tipAmt %>">
		
		<TR>
			<TD align="center" width="220px">
				<TABLE WIDTH="200px" BORDER=0 CELLSPACING=1>
					<TR>
						<TD align=center>
							<INPUT id=txtAmountEntered name=txtAmountEntered class=text style="font-size: 28; text-align: right; width: 175px; height: 37px" onblur="return txtAmountEntered_onblur();" onKeyup="decimalFormat();return txtAmountEntered_onblur();">
						</TD>
					</TR>

					<TR>
						<TD style="vertical-align:middle;text-align:center;height:100px">
							<!-- #include file="../include/calculator.inc" -->
						</TD>
					</TR>

					<TR>
						<TD>
							<TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=1 >

								<tr>
									<td colspan=2>
										<INPUT type="hidden" id=txtCashEntered name=txtCashEntered class=text>
									</td>
								</tr>

								<% if showAmountDueButton then %>
								<TR>
									<TD colspan=2 align=center style="WIDTH: 100%"><INPUT class=touch id=btnAmountDue name=btnAmountDue type=button value="Amount Due" style="WIDTH: 100%; background-image:url(../images/Dollar Sign.gif);" onClick="populateAmtDue()"></TD>
								</TR>
								<% end if %>

								<TR>
									<TD align=center style="WIDTH: 50%"><INPUT class=touch style="WIDTH: 100%" id=dollar1 name=dollar1 type=button value="1.00" onClick="cashIn('1');"></TD>
									<TD align=center style="WIDTH: 50%"><INPUT class=touch style="WIDTH: 100%" id=dollar5 name=dollar5 type=button value="5.00" onClick="cashIn('5');"></TD>
								</Tr>
								<TR>
									<TD align=center style="WIDTH: 50%"><INPUT class=touch style="WIDTH: 100%" id=dollar10 name=dollar10  type=button value="10.00" onClick="cashIn('10');"></TD>
									<TD align=center style="WIDTH: 50%"><INPUT class=touch style="WIDTH: 100%" id=dollar20 name=dollar20  type=button value="20.00" onClick="cashIn('20');"></TD>
								</Tr>
								<TR>
									<TD align=center style="WIDTH: 50%"><INPUT class=touch style="WIDTH: 100%" id=dollar50 name=dollar50  type=button value="50.00" onClick="cashIn('50');"></TD>
									<TD align=center style="WIDTH: 50%"><INPUT class=touch style="WIDTH: 100%" id=dollar100 name=dollar100  type=button value="100.00" onClick="cashIn('100');"></TD>
								</Tr>

								<tr style="height:10px"><td colspan = 2></td></tr>

								<TR>
									<td colspan=2>
									<table BORDER=0 CELLSPACING=0 CELLPADDING=1 width=100%>
									<tr>
									<TD style="WIDTH: 25%"><INPUT class=touch style="WIDTH: 100%" id=dollarp01 name=dollarp01  type=button value=".01" onClick="cashIn('0.01');"></TD>
									<TD style="WIDTH: 25%"><INPUT class=touch style="WIDTH: 100%" id=dollarp05 name=dollarp05  type=button value=".05" onClick="cashIn('0.05');"></TD>
									<TD style="WIDTH: 25%"><INPUT class=touch style="WIDTH: 100%" id=dollarp10 name=dollarp10  type=button value=".10" onClick="cashIn('0.10');"></TD>
									<TD style="WIDTH: 25%"><INPUT class=touch style="WIDTH: 100%" id=dollarp25 name=dollarp25  type=button value=".25" onClick="cashIn('0.25');"></TD>
									</tr>
									</table>

								</Tr>

								<% if ObjMiscSetUp.Item("allowPickupCoupons") and sInvoicelist <> "" then %>
								<tr style="height:10px"><td colspan = 2></td></tr>
								<tr><td  colspan=2>
									<INPUT class=touch style="WIDTH: 100%" id=getcoupon name=getcoupon  type=button value="Add Coupon" onClick="getCoupon();">
								</td></tr>
								<% end if %>

							</Table>
						</TD>
					</TR>
				</table>
			</TD>
			<td valign=top align="center">
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=1>
					<tr>
						<td style="width:60%"></td>
						<td style="width:20%"></td>
						<td style="width:20%"></td>
					</tr>

					<TR>
						<TD align=left class="label" style="font-size:20pt; font-style:bold; font-weight:bold">Total Due</TD>

						<TD colspan=2 style="color:Red; HEIGHT:100%; WIDTH: 100%; text-align:right; font-size:20pt; font-style:normal; font-weight:normal">
							<%= formatnumber(pickupObj.getAmountDue(),2,,,0)%>
						</TD>
					</TR>
					<tr>
						<TD align=left class="label" style="font-size:18pt; font-style:normal; font-weight:normal">Amount Paid<% if tipAmt > 0 then %> (not inc tip)<%end if%></TD>
						<TD colspan=2 style="HEIGHT:100%; WIDTH: 100%; text-align:right; font-size:18pt; font-style:normal; font-weight:normal"><%= formatnumber(pickupObj.getAmountPaid(), 2,,,0)%></td>
					</tr>

					<% if tipAmt > 0 then %>
					<tr>
						<TD align=left class="label" style="font-size:18pt; font-style:normal; font-weight:normal">Tip</TD>
						<TD colspan=2 style="HEIGHT:100%; WIDTH: 100%; text-align:right; font-size:18pt; font-style:normal; font-weight:normal"><%= formatnumber(tipAmt, 2,,,0)%></td>
					</tr>
					<% end if %>

					<% if targetPage = "detail" or isPrepay then %>
					<tr>
						<TD align=left class="label" style="font-size:18pt; font-style:normal; font-weight:normal">Prepay Discount</TD>
						<TD colspan=2 style="HEIGHT:100%; WIDTH: 100%; text-align:right; font-size:18pt; font-style:normal; font-weight:normal"><%= formatnumber(pickupObj.getPrepayDiscount(), 2,,,0)%></td>
					</tr>
					<% end if %>

					<TR>
						<TD align=left class="label" style="font-size:18pt; font-style:normal; font-weight:normal">Change Due</TD>

						<TD colspan=2 style="color:Red; HEIGHT:100%; WIDTH: 100%; text-align:right; font-size:18pt; font-style:normal; font-weight:normal"><%= formatnumber(pickupObj.getChangeDue(), 2,,,0) %></TD>
					</TR>


					<% if not isPrepay then %>
					<tr>

						<td colspan =2>

							<DIV STYLE="height:87px; OVERFLOW-X: auto; OVERFLOW-Y: auto; WIDTH: 100%" >
							<Table WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=1>

							<tr>
								<TD align= left class="label" style="font-size:16;font-weight:normal"><u>Invoice No.</u></td>
								<td align= left class="label" style="font-size:16;font-weight:normal"><u>Rack Location</u></td>
							</tr>


							<%		dim invoicenumberchange
									noOfRows = 0

										printRackInfo = ""
										invoicenumberchange = ""
										set RackRst = Session("ticketRack")
										noOfRows = RackRst.RecordCount
										if RackRst.RecordCount > 0 then
											RackRst.MoveFirst
											while not RackRst.EOF
								%>
												<%
													rackStr= RackRst.Fields("rackLocationStart").Value
													rackStr1 = RackRst.Fields("rackLocationStart").Value
													if not IsNull(RackRst.Fields("rackLocationEnd").Value) then
														rackStr = rackStr & " - " & RackRst.Fields("rackLocationEnd").Value
														rackStr1 = rackStr1 & " - " & RackRst.Fields("rackLocationEnd").Value
													end if



												%>
											<tr>
											<td align=left style="font-size=14"><%=RackRst.Fields("invoiceNumber").Value%></td>
											<td align=left style="font-size=14"><%=rackStr%></td>
											</tr>

								<%
											if trim(printRackInfo) = "" then
												printRackInfo =    customername & vbcrlf
											end if



											if trim(invoicenumberchange) = "" or invoicenumberchange <> trim(RackRst.Fields("invoicenumber").Value)  then
												invoicenumberchange = RackRst.Fields("invoicenumber").Value
												printRackInfo = printRackInfo & vbcrlf & invoicenumberchange & vbTab & vbTab
											else
												printRackInfo =  printRackInfo & ", "
											end if



												if len(trim(printRackInfo)) = 0 then
													printRackInfo =  printRackInfo &  rackStr
												else
													printRackInfo =  printRackInfo &  rackStr1
												end if


												RackRst.MoveNext

											wend


										end if
								%>
								<!--
							<tr height=100px>
								<TD align= left style="border=0;font-size=10">&nbsp;</td>
								<td align= left  style="border=0;font-size=10">&nbsp;</td>
							</tr>
							-->


							</table>

							</div>
						</td>

						<td>
							<INPUT align=right class=touch id=bttnPrintRackLocations name=bttnPrintRackLocations type=button value="Rack Slip" style="background-image:url(../images/Print-Rack.gif)" onClick = "printRackLocations();" <% if isPrepay or noOfRows <= 0 then %> disabled <% end if%>>
						</td>

					</tr>

					<% else %>

					<tr>

						<td colspan =2 style="height:80px">

						</td>
					</tr>
					<% end if %>





		<!--			<tr>
						<td>
							<INPUT  class=touch id=bttnPrintRackLocations name=bttnPrintRackLocations type=button value="" style="background-image:url(../images/Print-Rack.gif);" onClick = "printRackLocations();" <% if isPrepay or noOfRows <= 0 then %> disabled <% end if%>><br>Print Rack Locations
						</td>
					</tr>
-->


					<%
						dim paymentTypeRst
						dim preferedPaymentType
						dim ssql
						dim sqlresults

						custSeqNumber = Session("customerSequenceNumber")



                        ssql ="select upper(paymentTypeName) as paymentTypeName from Customer where customerSequenceNumber='" & custSeqNumber & "'"

						set sqlresults = getDisconnectedRecordset(ssql)

						if sqlresults is nothing or sqlresults.EOF then
							preferedPaymentType = ""
						else
							sqlresults.MoveFirst
							preferedPaymentType = sqlresults("paymentTypeName")
						end if



						set paymentTypeRst = Session("paymentTypes")
						if paymentTypeRst.RecordCount > 0 then
							paymentTypeRst.MoveFirst
							while not paymentTypeRst.eof

							    if permanentAccount and objmiscsetup.item("OnaccountOnlyOnaccount") and lcase(paymentTypeRst.Fields("paymentTypeName").Value) <> "on account" then

						        else
					%>
							<tr>
								<TD style="align:center; white-space: nowrap">
								    <INPUT class=touch id="<%= paymentTypeRst.Fields("paymentTypeName").Value%>" name="<%= paymentTypeRst.Fields("paymentTypeName").Value%>" type=button value="<%= paymentTypeRst.Fields("paymentTypeName").Value%>" style="<% if ucase(paymentTypeRst.Fields("paymentTypeName").Value) = preferedPaymentType then%>background-color:coral;<%end if%>  width:100%; background-image:url(../images/<%= paymentTypeRst.Fields("imageFileName").Value%>); background-position:10 6" onClick="addPayment(this);">
								</TD>
							    <TD style="HEIGHT:100%; WIDTH: 100%; text-align:right; font-size:18pt; font-style:normal; font-weight:normal"><%= formatnumber(pickupObj.getPaymentByType(paymentTypeRst.Fields("paymentTypeName").Value), 2,,,0)%> </td>
								<TD align=center><INPUT class=touch id="<%= "d_" & paymentTypeRst.Fields("paymentTypeName").Value%>" name="<%= "d_" & paymentTypeRst.Fields("paymentTypeName").Value%>" type=button value="Clear" onClick="deletePayment(this);"></TD>
							  </TD>
							</tr>

					<%
					            end if
							paymentTypeRst.MoveNext
							wend
						end if
					%>


					<tr style="height:10px"><td colspan = 3></td></tr>

					<TR>
						<TD align=left class="label" style="font-size:18pt; font-style:normal; font-weight:normal">Total</TD>
						<TD style="HEIGHT:100%; WIDTH: 100%; text-align:right; font-size:18pt; font-style:normal; font-weight:normal"><%= formatnumber(pickupObj.getPaymentByType(""), 2,,,0)%> </tr>
						<TD align=center><INPUT class=touch id="d_Total" name="d_Total" type=button value="ClearAll" onClick="deletePayment(this);"></TD>
					</TR>

				</TABLE>

			</td>
			<td valign=top>

				<!-- main table -->
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=1>
					<tr>
						<td align=center>

							<!-- Customer name frame -->
							<TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0>


								<tr>
									<td class="label" align=center>&nbsp;<%= Server.HTMLEncode(customerName)%></td>

								</tr>
								<tr>
									<td class="label" align=center>&nbsp;<%= custPhone%></td>

								</tr>


							</table>

						</td>

					</tr>
					<tr>
					<td align=center>
						<DIV STYLE="overflow-y:auto;height:505px; overflow-x:auto;">
						<TABLE style="width:100%;" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=0>
							<tr rowspan =5>
								<td valign="top">
									
										<%
											dim displayRst
											dim cloneRst
											dim parentTicketNo
											dim useInvoice
											dim currentInvoice
											dim invoiceCount
											dim heatseal
											dim itemDepartment
											dim invoiceOnPickup
											
											useInvoice = IsObject(Session("invoice"))
											if useInvoice then
												useInvoice = not( Session("invoice") is nothing )
											end if

											if useInvoice then
												set invoice = Session("invoice")

												set displayRst = invoice.lineItems
												starchPref = invoice.starchPref
												finishPref = invoice.finishPref
												if invoice.invoicesDictionary is nothing then
													invoiceCount = 0
												else
													invoiceCount = invoice.invoicesDictionary.count
												end if
												currentInvoice = 0
											else
												set pickupObj = Session("pickupObj")
												pickupObj.populateLineItemsToDisplay
												set displayRst = pickupObj.displayRst	'Original line
												invoiceCount = 0
												currentInvoice = 0
											end if

											dim lastInvoiceNumber
											lastInvoiceNumber = -1
											
											while currentInvoice <= invoiceCount
												if currentInvoice > 0 then
													dim invoices
													invoices = invoice.invoicesDictionary.Items
													set displayRst = invoices(currentInvoice - 1).lineItems
												end if

												if displayRst.RecordCount > 0 then
													set cloneRst = displayRst.Clone
													displayRst.MoveFirst

													while not displayRst.eof
													
													dim itemDescription
													
													itemDescription = server.htmlencode(displayRst.Fields("itemName"))

									                if useHeatSeal then
                                                        if displayRst.Fields("itemType") = "IT" or displayRst.Fields("itemType") = "AC" then
                                                            if useRstHeatSeal then
                                                            heatseal = displayRst.Fields("heatSeal")
                                                            else
                                                                if useInvoice then
                                                                    heatseal = invoice.getHeatSealId(displayRst.Fields("lineNumber"))
                                                                else
                                                                    heatseal = pickupObj.getHeatSealId(displayRst.Fields("lineNumber"))
                                                                end if
													        end if

                                                            if heatseal <> "" then
                                                                itemDescription = heatseal & " - " & itemDescription
                                                            end if
                                                        end if
													end if
													
													if lastInvoiceNumber <> displayRst.Fields("invoiceNumber") then
														if lastInvoiceNumber <> "-1" then
															response.write "</TABLE>"
														end if
														
														response.write "<TABLE class=""pu-line-items"" BORDER=0 CELLSPACING=0 CELLPADDING=0 >"
														
														response.write "<TR><TH colspan=""6"">Invoice " & displayRst.Fields("invoiceNumber") & "</TH></TR>"

														
														invoiceOnPickup = isInvoiceOnPickup(displayRst.Fields("invoiceNumber"))
														lastInvoiceNumber = displayRst.Fields("invoiceNumber")
													end if
													
													
													itemDepartment = ucase(left(displayRst.Fields("deptName"), 1))
													
													select case displayRst.Fields("itemType")
															case "IT"
																	

																	
																	
																	if isPrepay then
																		cloneRst.Filter ="parentLineNumber=" & displayRst.Fields("lineNumber")
																	else
																		parentTicketNo = displayRst.Fields("ticketNumber").Value
																		cloneRst.Filter ="parentLineNumber=" & displayRst.Fields("lineNumber") & " AND ticketNumber=" & parentTicketNo
																	end if
																	if cloneRst.Recordcount > 0 then
																		cloneRst.MoveFirst
																		while not cloneRst.Eof
																			itemDescription = itemDescription & ", " & cloneRst.Fields("quantity") & " " & server.htmlencode(cloneRst.Fields("itemName"))
																			cloneRst.MoveNext
																		wend
																	end if
																	cloneRst.Filter = adFilterNone
																	
																%>
																<tr name="main" >
																	<% if isPrepay then %>
																		<td width="10px">&nbsp;</td>
																	<% else %>
																		<td width="10px"><input name="selectedLineItem" type="checkbox" onclick="this.checked = !this.checked"
																		<%if displayRst.Fields("pickedUp").Value then%> disabled <%end if%>
																		<%if invoiceOnPickup or displayRst.Fields("pickedUp").Value then%> checked <%end if%>
																		value="<%=displayRst.Fields("lineNumber")%>,<%=displayRst.Fields("invoiceNumber")%>"></td>
																	<% end if %>
																	<td width="20px"><%= displayRst.Fields("quantity")%></td>
																	<td width="15px"><%= itemDepartment %></td>
																	<td><%= itemDescription %></td>
																	<td width="65px" align="right"><%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2)%></td>
																</tr>
																<%
																	case "AC"
																%>
																			<tr name="main" >
																				<% if isPrepay then %>
																					<td width="10px">&nbsp;</td>
																				<% else %>
																					<td width="10px"><input name="selectedLineItem" type="checkbox" onclick="this.checked = !this.checked"
																					<%if displayRst.Fields("pickedUp").Value then%> disabled <%end if%>
																					<%if invoiceOnPickup or displayRst.Fields("pickedUp").Value then%> checked <%end if%>
																					value="<%=displayRst.Fields("lineNumber")%>,<%=displayRst.Fields("invoiceNumber")%>"></td>
																				<% end if %>
																				<td width="20px"><%= displayRst.Fields("quantity")%></td>
																				<td width="15px"><%= itemDepartment %></td>
																				<td><%= itemDescription%></td>
																				<td width="65px" align="right"><%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2)%></td>
																			</tr>
																<%
																case "CU", "SU", "TA", "LY", "SO"
																%>
																	<tr name="main" style="color:#aa0;">
																		<td width="10px">&nbsp;</td>
																		<td width="20px"><%= displayRst.Fields("quantity")%></td>
																		<td width="15px"><%= itemDepartment %></td>
																		<td><%= displayRst.Fields("itemName")%></td>
																		<td width="65px" align="right">
																		<% if displayRst.Fields("itemType") = "CU" then %>-<%end if %>
																		<%= FormatCurrency(displayRst.Fields("lineItemTotal").Value,2)%>
																		</td>
																	</tr>
																<%
																	end select
																	
																	
																	
																	displayRst.MoveNext
																	wend
																end if

																currentInvoice = currentInvoice + 1
															wend
													if lastInvoiceNumber <> "-1" then
															response.write "</TABLE> <!-- et -->"
														end if
															%>
									
								</td>
							</tr>
					</table> <!-- table for border -->
				</div>
				</td>
				</tr>

				<tr>
					<td align=center>
						<TABLE WIDTH="250px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >

							<tr>
								<td align="center">
									<INPUT class=touchnoborder id=doneButton name=doneButton type=button value="" style="background-image:url(../images/ok.gif);" onClick="submitForm();" >
								</td>

								<td align="center">
									<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm();">
								</td>
							</tr>

						</table>
					</td>
				</tr>

			</table>
			</td>
		</tr>
			<INPUT type="hidden" name="rackInfoForPrint" value="<%=Server.HTMLEncode(printRackInfo)%>">
		</FORM>

	</table>

</BODY>
</HTML>