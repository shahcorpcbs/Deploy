<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim ticketNo
	dim creationDate
	dim creationTime
	dim totalAdditions
	dim totalCoupons
	dim storeInfo
	dim totalPayments
	dim totalOverRides
	dim empName
	dim totalDiscounts
	dim logDate
	dim actionString
	dim sInvoicenumber
	DIM OBJPayments
	dim strpayment 
	creationDate =  ""
	creationTime = ""
	totalAdditions = ""
	totalCoupons = ""
	storeInfo =""
	totalPayments =""
	totalOverRides = ""
	totalDiscounts =""
	
	
	ticketNo = Request.QueryString("ticketNo")
	logDate = Request.QueryString("logDate")
	sInvoicenumber = Request.QueryString("invoiceNo")
	actionString = Request.QueryString("userAction")
	select case actionString
		case "getEmpDetails"
				ticketNo = Request.Form("ticketNumber")
		case "cancel"
			cancelForm
	end select
	
	getEditTranHistory
	getPayments	
	
	sub getEditTranHistory()
		dim ssql
		dim objResultSet
		dim recordInfo
				
		if not isObject(Session("TicketEditLog")) then
			ssql = "SELECT logDate, additions, coupons, discounts, storeName, payments, overriddenAmount, " _
				& " employeeName FROM TicketLog Where ticketNumber=" & CLng(ticketNo) _ 
				& " And logType='E' Order by logDate" 
			set objResultSet = getDisconnectedRecordset(ssql)
			set Session("TicketEditLog") =objResultSet
		else
			if Session("TicketEditLog") is nothing then
				ssql = "SELECT logDate, additions, coupons, discounts, storeName, payments, overriddenAmount, " _
				& " employeeName FROM TicketLog Where ticketNumber=" & CLng(ticketNo) _ 
				& " And logType='E' Order by logDate" 
				set objResultSet = getDisconnectedRecordset(ssql)
				set Session("TicketEditLog") =objResultSet
			end if
		end if
	end sub
	
	sub getPayments()
		dim ssql
		dim objResultSet
		
		ssql = "SELECT t.onAccountamount, p.amountpaid, p.paymentTypename " _
				& " FROM TicketLog  t , payment P Where t.ticketNumber=" & CLng(ticketNo) _
				& " And logType='E'and t.paymentgroupnumber *= p.paymentgroupnumber" 
		'Response.Write ssql
		set objPayments =getdisconnectedrecordset(ssql)

		
	end sub
	
	sub cancelForm()
		ticketNo = Request.Form("ticketNumber")
		set Session("TicketEditLog") = Nothing
		Response.Redirect "finishedInvoices.asp?userAction=fromDetail&ticketNumber=" & ticketNo
	end sub
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Edit Transcation History</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		document.editTranHistoryForm.action=document.editTranHistoryForm.action + "?userAction=cancel";
		document.editTranHistoryForm.submit();
	}
	
	function getEditDetails() {
		var logDate;
		var index;
		
		index = document.editTranHistoryForm.empolyeeName.selectedIndex;
		logDate = document.editTranHistoryForm.empolyeeName(index).value;
		document.editTranHistoryForm.action = "?userAction=getEmpDetails&logDate=" + logDate;
		document.editTranHistoryForm.submit();
	}
	
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Edit Invoice Transaction History
<%=sInvoicenumber%></B>
<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >	
<FORM id="editTranHistoryForm" name="editTranHistoryForm" action="editTransactionHistory.asp" method="post">
	<INPUT type="hidden" name="ticketNumber" value="<%= ticketNo %>">
	<%
		dim editTicketLog
		dim found
		dim l_Date
		
		set editTicketLog = Session("TicketEditLog")
		if editTicketLog.Recordcount > 0 then
			editTicketLog.MoveFirst	
			found = true
			if Not IsEmpty(logDate) then
				editTicketLog.MoveFirst	
				found =false
				while not found and not editTicketLog.EOF
					l_Date = CStr(editTicketLog.Fields("logDate").Value)
					if  l_Date = logDate then
						found =true
					end if
					editTicketLog.MoveNext
				wend
				if found = true then
					editTicketLog.MovePrevious
				end if
			end if
			if editTicketLog.Recordcount > 0 and found = true then
				creationDate = FormatDateTime(editTicketLog.Fields("logDate").Value, vbShortDate)
				creationTime = FormatDateTime(editTicketLog.Fields("logDate").Value, vbLongTime)
				totalAdditions = editTicketLog.Fields("additions").Value
				totalCoupons = editTicketLog.Fields("coupons").Value
				totalDiscounts = editTicketLog.Fields("discounts").Value
				storeInfo = editTicketLog.Fields("storeName").Value
				totalPayments = editTicketLog.Fields("payments").Value
				totalOverRides = editTicketLog.Fields("overriddenAmount").Value
				editTicketLog.Filter = adFilterNone
			end if
		end if
	%>
	<tr height=20px></tr>
	<tr>
		<td>
			<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
				<TR>
					<TD align=right class="label">Edit Date</TD>
					<TD>
						<INPUT id=txtCreationDt name=txtCreationDt class=text value="<%= creationDate%>" readonly>
					</TD>
				</TR>
				
				<TR>
					<TD align=right class="label">Edit Time</TD>
					<TD>
						<INPUT id=txtCreationTime name=txtCreationTime class=text value="<%= creationTime%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Additions</TD>
					<TD>
						<INPUT id=txtAdditions name=txtAdditions class=text value="<%= totalAdditions%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Coupons</TD>
					<TD>
						<INPUT id=txtCoupon name=txtCoupon class=text value="<%= totalCoupons%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Discounts</TD>
					<TD>
						<INPUT id=txtDiscount name=txtDiscount class=text value="<%= totalDiscounts%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Store Info</TD>
					<TD>
						<INPUT id=txtStoreInfo name=txtStoreInfo class=text value="<%= storeInfo%>" readonly>
					</TD>
				</TR>
				
				<TR>
					<TD align=right class="label">Payments</TD>
					<TD>
						<INPUT id=txtPayments name=txtPayments class=text value="<%= totalPayments%>" readonly>
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Payment Details</TD>
					<TD>
						<SELECT name=txtPaymentsdetail id=txtPaymentsdetail size=4 style="width:175px;">
						<% if objPayments.recordcount >0 then
							if objPayments("onAccountamount") >0 then
								strpayment  = formatCurrency(objPayments("onAccountamount"), 2 ) & " " & "On Account" %>
								<option><%=strpayment%></option>
							<%end if %>
							
							<%
								while not objPayments.eof
									if objPayments("amountpaid") > 0 then 
										strpayment = formatcurrency(objPayments("amountPaid"), 2)& " " & objPayments("paymentTypeName") %>
										<option><%=strpayment%></option>
									<%end if  %>
							<%objPayments.movenext
							wend %>
						<%END if 
						objPayments.close
						set objPayments = nothing	
						%>
													
						
						</select>
						
					</TD>
				</TR>
				<TR>
					<TD align=right class="label">Over Rides</TD>
					<TD>
						<INPUT id=txtOverRide name=txtOverRide class=text value="<%= totalOverRides%>" readonly>
					</TD>
				</TR>
				
				<TR>
					<TD align=right class="label">Employee Name</TD>
					<TD>
						<select name=empolyeeName style="WIDTH: 175px; font-size:14px" onChange="getEditDetails();">
							<%
								dim tempLogDate
								if editTicketLog.Recordcount > 0 then
									editTicketLog.MoveFirst
									while not editTicketLog.eof
										empName = editTicketLog.Fields("employeeName").Value
										tempLogDate = editTicketLog.Fields("logDate").Value
							%>
										<option value="<%= tempLogDate%>" <% if cstr(logDate) = CStr(tempLogDate) then %> selected <% end if%>><%= empName & " (" & tempLogDate & ")"%>
							<%
										editTicketLog.MoveNext
									wend
								end if
							%>
							
						</select>
					</TD>
				</TR>
			</TABLE>
		</td>
	</tr>
	<tr>
		<td>
			<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<TR>
						<td width=45%></td>
						<TD align=center width=40px>
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick="submitForm();">
						</td>
						<td width=25px>
						<td align=center width=40px>
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onclick="submitForm();">
						</TD>
						<td width=35%></td>
					</TR>     
			</TABLE>
		</td>
	</tr>
</FORM>   
</table>
</BODY>
</HTML>


