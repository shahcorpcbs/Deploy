<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 900 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
    dim query, rs
    dim messageId, note, action, done

    done = 0
    messageId = Request.QueryString("messageId")
    action = Request.QueryString("useraction")

    if action = "setHandled" then
        note = Request.QueryString("note")

        query = "insert into SMSMessageHistory (TwilioResponseMessageId, EmployeeId, DateChanged, Status, Note) values ("
        query = query & messageId & ", " & session("employeeID") & ", CURRENT_TIMESTAMP, 2, '" & dbstr(note) & "' ) "
        qryexecute query

        done = 1
    end if


%>

<HTML>
<HEAD>
<TITLE>Handle SMS Message</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<FORM id="handleSMS" name="handleSMS" action="" method="post">
<script language="javascript" type="text/javascript" src="/Script/webui.js"> </script>
<script type="text/javascript" src="../External/jquery-3.4.1.js"></script>
<script language="javascript" type="text/javascript">
    function submitForm() {
        if (isIECompatibilityMode()) {
         window.showModalDialog("/MainApp/handleSmsMessage.asp?useraction=setHandled&messageId=<%=messageId%>&note=" +
            encodeURIComponent($.trim($("#note").val())), "Handle SMS Message",
            "status:no;Height:0px;Width:0px;center;edge:Sunken;help:No;resizable:no;scroll:no;");
            window.close()
         }
        else
             window.open("/MainApp/handleSmsMessage.asp?useraction=setHandled&messageId=<%=messageId%>&note=" +
                encodeURIComponent($.trim($("#note").val())), "Handle SMS Message",
                "status=no,height=0px,width=0px,center,edge=Sunken,help=No,resizable=no,scroll=no");
    }

    function init() {
        if (1 === <%=done %>) {
            window.close()
        }
    }
</script>

<BODY topmargin=0 leftmargin=0 onload="init()">
Note:<br />
<DIV id="statement_container">
    <textarea id="note" cols="50" rows="10" ></textarea>
    <br /><br />
</DIV>
<table ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR>
			<TD colspan="2" align=center>
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/OK.gif)" onClick= "submitForm()">
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onclick="window.close()">
			</TD>
		</TR>
</table>

</BODY>
</FORM>
</HTML>

