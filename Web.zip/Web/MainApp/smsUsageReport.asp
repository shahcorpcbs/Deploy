<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs, rs2
	dim dateBegin
	dim dateEnd
	dim msgCnt, segCnt, msgSucCnt

	dateBegin = Request.QueryString("dateBegin")
	dateEnd = Request.QueryString("dateEnd")
	if dateBegin = "" then dateBegin = dateadd("m",-1,date())
	if dateEnd = "" then dateEnd =  dateadd("d",1,date())

%>

<html>
<head>
<title>SMS Usage Report</title>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../script/date-picker2.js"></script>
<SCRIPT type="text/javascript" >

	function update() {
	    var dateBegin = $.trim($("#dateBegin").val());
	    var dateEnd = $.trim($("#dateEnd").val());

	    var action = "?useraction=update"
	    action = action + "&dateBegin=" + encodeURIComponent(dateBegin)
	    action = action + "&dateEnd=" + encodeURIComponent(dateEnd)

		document.smsUsageReportForm.action = action;
		document.smsUsageReportForm.submit();
	}

    function exit() {
            document.smsUsageReportForm.action = "\smsMenu.asp";
            document.smsUsageReportForm.submit();
    }

</SCRIPT>
</head>
<body topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>SMS Usage Report</H1>
<form name="smsUsageReportForm" action="" method="post" style="margin:0px">

<table ALIGN=center WIDTH="700px" BORDER=0 CELLSPACING=1 CELLPADDING=5>
    <tr>
        <td>Date range</td>
        <td>
            <INPUT id="dateBegin" name="dateBegin" value="<%=dateBegin%>" readonly onclick="javascript:show_calendar('smsUsageReportForm.dateBegin');">
            to
            <INPUT id="dateEnd" name="dateEnd" value="<%=dateEnd%>" readonly onclick="javascript:show_calendar('smsUsageReportForm.dateEnd');">
        </td>
        <td rowspan="3"><BUTTON class="cmdbar" onclick="update()">Look Up</BUTTON></td>
    </tr>
</table>
<br />


	<TABLE ALIGN=center WIDTH="900px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
    <tr>
        <th style="text-align: left; vertical-align: top">Type</th>
        <th style="text-align: right; vertical-align: top">Attempted<br />Msg Count</th>
        <th style="text-align: right; vertical-align: top">Success/Unique<br />Msg Count</th>
        <th style="text-align: right; vertical-align: top">Segments</th>
    </tr>
		<tr height=50px></tr>
        <tr>
            <td>SMS Messages sent to Customers by Rules</td>
            <%
                query = "select count(*) cnt, COALESCE(sum(segments),0) segments from TwilioSendSmsApiCall where RequestDate >= '" _
                    & dateBegin & "' and RequestDate <'" & dateEnd & "' and employeeId = 0 and customerId != -1"
                set rs = getdisconnectedrecordset(query)
                msgCnt = rs("cnt")
                segCnt = rs("segments")

                query = "select count(*) cnt from TwilioSendSmsApiCall where RequestDate >= '" _
                    & dateBegin & "' and RequestDate <'" & dateEnd & "' and employeeId = 0 and customerId != -1 "_
                    & " and segments > 0"
                set rs2 = getdisconnectedrecordset(query)
                msgSucCnt = rs2("cnt")
            %>
            <td style="text-align: right"><%=rs("cnt") %></td>
            <td style="text-align: right"><%=rs2("cnt") %></td>
            <td style="text-align: right"><%=rs("segments") %></td>
        </tr>
        <tr>
            <td>SMS Messages sent to Customers by Auto Replies</td>
            <%
                query = "select count(*) cnt, COALESCE(sum(segments),0) segments from TwilioSendSmsApiCall where RequestDate >= '" _
                    & dateBegin & "' and RequestDate <'" & dateEnd & "' and employeeId = -1 "
                set rs = getdisconnectedrecordset(query)
                msgCnt = msgCnt + rs("cnt")
                segCnt = segCnt + rs("segments")

                query = "select count(*) cnt from TwilioSendSmsApiCall where RequestDate >= '" _
                    & dateBegin & "' and RequestDate <'" & dateEnd & "' and employeeId = -1 "_
                    & " and segments > 0"
                set rs2 = getdisconnectedrecordset(query)
                msgSucCnt = msgSucCnt + rs2("cnt")
            %>
            <td style="text-align: right"><%=rs("cnt") %></td>
            <td style="text-align: right"><%=rs2("cnt") %></td>
            <td style="text-align: right"><%=rs("segments") %></td>
        </tr>
        <tr>
            <td>SMS Messages sent to Customers by Employees</td>
            <%
                query = "select count(*) cnt, COALESCE(sum(segments),0) segments from TwilioSendSmsApiCall where RequestDate >= '" _
                    & dateBegin & "' and RequestDate <'" & dateEnd & "' and employeeId > 0 and customerId != -1"
                set rs = getdisconnectedrecordset(query)
                msgCnt = msgCnt + rs("cnt")
                segCnt = segCnt + rs("segments")

                query = "select count(*) cnt from TwilioSendSmsApiCall where RequestDate >= '" _
                    & dateBegin & "' and RequestDate <'" & dateEnd & "' and employeeId > 0 and customerId != -1"_
                    & " and segments > 0"
                set rs2 = getdisconnectedrecordset(query)
                msgSucCnt = msgSucCnt + rs2("cnt")
            %>
            <td style="text-align: right"><%=rs("cnt") %></td>
            <td style="text-align: right"><%=rs2("cnt") %></td>
            <td style="text-align: right"><%=rs("segments") %></td>
        </tr>
        <tr>
            <td>SMS Messages received from Customers</td>
            <%
                query = "select count(*) cnt, COALESCE(sum(segments),0) segments from TwilioResponseMessage where dateSent >= '" _
                    & dateBegin & "' and dateSent < '" & dateEnd & "'"
                set rs = getdisconnectedrecordset(query)
                msgCnt = msgCnt + rs("cnt")
                segCnt = segCnt + rs("segments")

                query = "select count(*) cnt, COALESCE(sum(segments),0) segments from TwilioResponseMessage where dateSent >= '" _
                    & dateBegin & "' and dateSent < '" & dateEnd & "'"_
                    & " and segments > 0"
                set rs2 = getdisconnectedrecordset(query)
                msgSucCnt = msgSucCnt + rs2("cnt")
            %>
            <td style="text-align: right"><%=rs("cnt") %></td>
            <td style="text-align: right"><%=rs2("cnt") %></td>
            <td style="text-align: right"><%=rs("segments") %></td>
        </tr>
        <tr>
            <td>SMS Messages sent to Employees</td>
            <%
                query = "select count(*) cnt, COALESCE(sum(segments),0) segments from TwilioSendSmsApiCall where RequestDate >= '" _
                    & dateBegin & "' and RequestDate <'" & dateEnd & "' and customerId = -1"
                set rs = getdisconnectedrecordset(query)
                msgCnt = msgCnt + rs("cnt")
                segCnt = segCnt + rs("segments")

                query = "select count(*) cnt, COALESCE(sum(segments),0) segments from TwilioSendSmsApiCall where RequestDate >= '" _
                    & dateBegin & "' and RequestDate <'" & dateEnd & "' and customerId = -1"_
                    & " and segments > 0"
                set rs2 = getdisconnectedrecordset(query)
                msgSucCnt = msgSucCnt + rs2("cnt")
            %>
            <td style="text-align: right"><%=rs("cnt") %></td>
            <td style="text-align: right"><%=rs2("cnt") %></td>
            <td style="text-align: right"><%=rs("segments") %></td>
        </tr>
		<tr height=30px></tr>
        <tr>
            <th style="text-align: left; border-top: solid black; border-width: 1px 0 0 0">Totals</th>
            <td style="text-align: right; border-top: solid black; border-width: 1px 0 0 0"><%=msgCnt %></td>
            <td style="text-align: right; border-top: solid black; border-width: 1px 0 0 0"><%=msgSucCnt %></td>
            <td style="text-align: right; border-top: solid black; border-width: 1px 0 0 0"><%=segCnt %></td>
        </tr>

		<tr height=30px></tr>
		<tr>
			<td></td>
			<TD>
				<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick= "exit()">
						</td>
					</tr>
				</table>
			</TD>
		</tr>
</table>

</form>

</body>
</html>
