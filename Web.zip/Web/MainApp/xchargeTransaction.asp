<%@ Language=VBScript %>
<%option explicit %>
<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim viewFilter
	dim daysBack
	dim ccprocessor

	set ccprocessor = Server.CreateObject("ShahcorpComponents.creditCardProcessing")
	
	ccprocessor.DBConnectionString = Session("shahcorpDSN")

	ccprocessor.XChargeDirectory = getMSVar("XChargePath")
	if not isnull(getMSVar("XChargePathKeyed")) then
		ccprocessor.XChargeDirectoryKeyed = getMSVar("XChargePathKeyed")
	end if
	ccprocessor.XChargeTimeout = getMSVar("XChargeTimeout")
	
	viewFilter = getReqVar("viewFilter")
	daysBack = getReqVar("daysBack")
	
	if viewFilter = "" then viewFilter = "all"
	if daysBack = "" then daysBack = 0
	
	
	select case lcase(request.querystring("useraction"))
	case "force"
		runTransactions true
	case "rerun"
		runTransactions false
	end select
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getTransactionsRS(viewFilter, daysBack)
		dim query
		
		query = " select xchargetransaction.*, isnull(xchargetransaction.answer, '&nbsp;') as answer, isnull(convert(varchar, xchargetransaction.dateanswered), '&nbsp;') as dateanswered, isnull(xchargetransaction.amount, 0.00) as amount,  employee.employeename "
		query = query & " , isnull(terminal.name, 'Unknown') as terminalName "
		query = query & " from "
		query = query & " xchargetransaction inner join employee on "
		query = query & " xchargetransaction.clerk = employee.employeeid "
		query = query & " left outer join terminal on "
		query = query & " xchargetransaction.terminalid = terminal.terminalid "
		query = query & " where datediff(day, xchargetransaction.datecreated, getdate()) <= " & daysBack
		
		select case viewFilter
		case "all"
		case "noresponse"
			query = query & " and dateanswered is null "
		end select
		
		query = query & " order by datecreated " 
		
		set getTransactionsRS = getdisconnectedrecordset(query)
	end function	
	
	
	function getMSVar(id)
		dim query, rs
		
		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)
		
		set rs = nothing
	end function
	
	
	function getCustomerSeqForTransactionGUID(transactionGUID)
		dim query, rs
		
		query = "select customersequencenumber from xchargetransaction "
		query = query & " where transactionguid = '" & transactionGUID & "'"
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			if not isnull(rs("customersequencenumber")) then
				getCustomerSeqForTransactionGUID = rs("customersequencenumber")
			end if
		end if
		
		set rs = nothing
	end function
	
	function getAmountForTransactionGUID(transactionGUID)
		dim query, rs
		
		query = "select amount from xchargetransaction "
		query = query & " where transactionguid = '" & transactionGUID & "'"
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
				getAmountForTransactionGUID = rs("amount")
		end if
		
		set rs = nothing
	end function
	
	function runTransactions(force)
		dim selectedTransaction
		dim code
		dim customerseq
		dim amount
		
		for each selectedTransaction in request.form("selectedTransaction")

			customerseq = getCustomerSeqForTransactionGUID(request.form("selectedTransaction"))
			amount = getAmountForTransactionGUID(request.form("selectedTransaction"))
			if customerseq <> "" then
				if ccprocessor.ReadSingleAnswer(selectedTransaction, code) then
					insertPayment customerseq, amount, code
				elseif force then
					insertPayment customerseq, amount, code
				end if
			end if
		next
	end function
	
	
	function insertPayment(customerSequenceNumber, amount, code)
		dim query

		query = "execute dbo.InsertPayment " & session("storeid")_
				& " ," & session("terminalid") _
				& " , " & session("employeeid") _
				& " ,"   & customerSequenceNumber _
				& " ,'Credit Card'" _
				& " ,"   & amount _
				& " ,''" _
				& ", " & code _
				& ", ''" _
				& ", ''" _
				& ", ''" _								
				& ", ''"

		qryexecute query
					
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript">

	function forceTransaction() {
	    cbs_confirm("Are you sure you want to FORCE selected transactions?", doForce);
	}

	function doForce() {
        clearConfirmMsg();
	    document.xchargeTransaction.action = "?useraction=force";
        document.xchargeTransaction.submit();
	}

	function rerunTransaction() {
	    cbs_confirm("Are you sure you want to rerun selected transactions?", doRerun)
	}

	function doRerun() {
        clearConfirmMsg();
	    document.xchargeTransaction.action = "?useraction=rerun";
        document.xchargeTransaction.submit();
	}


	function doSearch() {
		document.xchargeTransaction.action = "?useraction=search";
		document.xchargeTransaction.submit();
	}
	function cancelForm() {
		document.xchargeTransaction.action = "accountMgmt.asp";
		document.xchargeTransaction.submit();
	}
	

	function SetRowCheckedStatus(row, check, value) {

		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "selectedTransaction") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "selectedTransaction") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->

<FORM name="xchargeTransaction" ID="xchargeTransaction" METHOD=POST  style="margin:0;padding:0"> 

<TABLE cellpadding="10" align="center">
	<TR>
		<TD>
			<SELECT name="viewFilter">
				<OPTION value="all" <%if viewFilter = "all" then%>selected<%end if%>>All</OPTION>
				<OPTION value="noresponse" <%if viewFilter = "noresponse" then%>selected<%end if%>>No Response</OPTION>
			</SELECT>
		</TD>
		<TD>
			<SELECT name="daysBack">
				<OPTION value="0" <%if daysBack = 0 then%>selected<%end if%>>Today</OPTION>
				<OPTION value="1" <%if daysBack = 1 then%>selected<%end if%>>Yesterday</OPTION>
				<OPTION value="7" <%if daysBack = 7 then%>selected<%end if%>>Last Week</OPTION>
				<OPTION value="32" <%if daysBack = 32 then%>selected<%end if%>>Last Month</OPTION>
				<OPTION value="365" <%if daysBack = 365 then%>selected<%end if%>>Last Year</OPTION>
				<OPTION value="30000" <%if daysBack = 30000 then%>selected<%end if%>>All</OPTION>
			</SELECT>		
		</TD>
		<TD>
			<INPUT type="button" value="Search" onclick="doSearch()" />
		</TD>
	</TR>
</TABLE>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<button onClick="rerunTransaction()">Rerun</button>
		<button onClick="forceTransaction()">Force</button>
		
		
	</SPAN>
	<SPAN style="float:right">
		<button id=cancelButton name=cancelButton onClick="cancelForm()">Cancel</button>
	</SPAN>
</DIV>	

<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR>
		<TH>&nbsp;</TH>
		<TH>&nbsp;</TH>
		<TH>Employee</TH>
		<TH>Terminal</TH>
		<TH>Date Requested</TH>
		<TH>Date Answered</TH>
		<TH>Answer</TH>
		<TH>Amount</TH>
	</TR>
<%
	set rs = getTransactionsRS(viewFilter, daysBack)
	dim answerFound
	
	while not(rs.eof or rs.bof)
		answerFound = rs("dateanswered") <> "&nbsp;"
%>

	<TR onclick="ToggleRowChecked(this)" >
<% if not answerFound and not isnull(rs("customersequencenumber")) then  %>
		<TD><INPUT type="checkbox" name="selectedTransaction" value="<%=rs("transactionguid")%>" onclick="ToggleRowChecked(this.parentNode.parentNode)" /></TD>
<% else %>
		<TD>&nbsp;</TD>
<% end if %>
		<TD style="width:40px" align="center">
<% if not answerFound then %>
		<span style="background:red;color:white;font-size:20;width:25px">!</span>
<% end if %> 
		</TD>
		<TD><%=rs("employeename")%></TD>
		<TD><%=rs("terminalname")%></TD>
		<TD><%=rs("datecreated")%></TD>
<% if answerFound then %>
		<TD><%=rs("dateanswered")%></TD>
		<TD><%=rs("answer")%></TD>
<% else %>
	<% if ccprocessor.IsAnswerReady(rs("transactionguid")) then %>
		<TD colspan="2" align="center"><SPAN style="background:red;color:white">Answer Ready</SPAN></TD>
	<% else %>
		<TD colspan="2" align="center"><SPAN style="background:red;color:white">Answer Missing</SPAN></TD>
	<% end if %>
<% end if %>
		<TD><%=formatcurrency(rs("amount"))%></TD>
	
	</TR>
<%
		rs.movenext
	wend
	
	set rs = nothing
%>
</TABLE>

</FORM>

</BODY>
</HTML>
