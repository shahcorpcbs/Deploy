<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim isSubmitted 
	dim l_storeid
	dim sqltxt 
	dim l_mode
	dim l_firstname
	dim l_MainPhone
	dim l_email
	dim l_dateofbirth
	dim l_address
	dim l_source
	dim l_cellphone
	
	isSubmitted = Request.QueryString("submitted")
	l_storeid = session("StoreID")
	
	' Please remember to remove it once store info is retreieved from cookie
	
	'*************************************************************
	'Update-start database when form is submitted and if required
	if ( isSubmitted ) then 
		if not isnull(l_storeid) and l_storeid <> "" then
			UpdateDatabase()
		end if	
	end if

	' Update-finished 
	'**************************************************************
	dim actionstring
	
	'**************************************************************
	'Redirction start
	actionstring= Request.QueryString("userAction")  
	if ( not isnull(actionstring) and actionstring<>"") then
		Response.Redirect(actionstring)
	end if
	'Redirection end
	'**************************************************************
	
	'**************************************************************
	'Retrieve customersetup record from database
	getCustomerSetupInfo()
	'**************************************************************
	
%>
<HTML>
<HEAD>
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm() {
		document.customerrequiredinfo.action = "?submitted=true&mode=" +document.customerrequiredinfo.mode.value + "&useraction=Customersetup.asp"
		document.customerrequiredinfo.submit();
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Customer Required Fields</H1>
<center>
<FORM id="customersetup" name="customerrequiredinfo" action="" Method = "post">
<input type=hidden name="mode" value="<%=l_mode%>">
<table width=300  CELLSPACING=1 CELLPADDING=0>
<tr><td>
<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=0 ><!-- header row -->
 <tr>
	<td align=center valign=top>
	<TABLE   border="0" cellpadding="10" cellspacing="0" Style = "MARGIN-LEFT: 8px" class="itable">
		<tr>
			<th>Required Fields</th>
		</tr>
		<tr><br>
			<TD><INPUT type=checkbox name="chkfirstName" <%if (l_firstname) then %> checked <%end if %>>&nbsp;&nbsp;First Name</TD>
		</tr>
		<tr> 
			<TD><INPUT type=checkbox name="chkmainphone" <%if (l_mainphone ) then %> checked <%end if %>>&nbsp;&nbsp;Main Phone</TD>
		</tr>
		<tr> 
			<TD><INPUT type=checkbox name="chkEmail" <%if (l_email ) then %> checked <%end if %>>&nbsp;&nbsp;Email</TD>
		</tr>
		<tr> 
			<TD><INPUT type=checkbox name="chkDateofBirth" <%if (l_dateofbirth ) then %> checked <%end if %>>&nbsp;&nbsp;Date Of Birth</TD>
		</tr>
		<tr> 
			<TD><INPUT type=checkbox name="chkAddress" <%if (l_address ) then %> checked <%end if %>>&nbsp;&nbsp;Main Address</TD>
		</tr>
		<tr> 
			<TD><INPUT type=checkbox name="chkCustomerSource" <%if (l_source ) then %> checked <%end if %>>&nbsp;&nbsp;Customer Source</TD>
		</tr>
		<tr> 
			<TD><INPUT type=checkbox name="chkCellPhone" <%if (l_cellphone ) then %> checked <%end if %>>&nbsp;&nbsp;Cell Phone</TD>
		</tr>
	</Table> 
	</td>
</tr>	
<tr height=100px><td align=center>	
	<INPUT class = touchnoborder name=OK type=button value="" style="background-image:url(../images/Ok.gif);background-position=center" onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
	<INPUT class = touchnoborder name=cancel type=button value="" style="background-image:url(../images/Cancel.gif);background-position=center" onClick="history.back(-1)">
</td></tr>
</table>
</td></tr>
</TABLE>
</FORM>
</center>
</BODY>
</HTML>

<%

	Function getCustomerSetupInfo()
	if (not isnull(l_storeid) and not l_storeid = "" ) then
		dim rsCustomeroption
		sqltxt = "select *  from requiredCustomerFields where storeid =" & l_storeid
		set rsCustomeroption= getDisconnectedRecordset(sqltxt)
		if rsCustomeroption.recordcount > 0 then
			l_mode="edit"
		else
			l_mode="add"
		end if
		l_firstname= 0
		l_mainphone= 0
		l_email= 0
		l_dateofbirth= 0
		l_address = 0
		l_source = 0
		l_cellphone = 0
		while Not rscustomeroption.Bof and not rscustomeroption.Eof 
			select Case rsCustomeroption("fieldName")
				case "firstname"
						l_firstname= rsCustomeroption("required")
				case "mainphone"
						l_mainphone = rsCustomeroption("required")
				case "email"
						l_email = rsCustomeroption("required")
				case "dateofbirth"
						l_dateofbirth =rsCustomeroption("required")
				case "mainAddress"
						l_address =rsCustomeroption("required")
				case "customerSource"
						l_source =rsCustomeroption("required")
				case "cellPhone"
				        l_cellphone = rsCustomeroption("required")
			end select
			rscustomeroption.Movenext
		Wend
	end if
	End Function
	
	Function UpdateDatabase()
			dim sqltxt
			
			DbStartTrans()
			
			sqltxt = "delete requiredCustomerFields where storeid = " & l_storeid
			
			QryExecuteWithTrans(sqltxt)
						
			sqltxt = "Insert requiredCustomerFields (storeid,fieldname,Required ) values (" _
						& l_storeid _
						& "," & "'customerSource'" _
						& "," & evalRequestValue(request.form("chkCustomerSource")) _
						& " )"
			
			QryExecuteWithTrans(sqltxt)
			
			sqltxt = "Insert requiredCustomerFields (storeid,fieldname,Required ) values (" _
						& l_storeid _
						& "," & "'firstname'" _
						& "," & evalRequestValue(request.form("chkfirstName")) _
						& " )"
			
			QryExecuteWithTrans(sqltxt)
			
									
			sqltxt = "Insert requiredCustomerFields (storeid,fieldname,Required ) values (" _
						& l_storeid _
						& "," & "'mainphone'"  _
						& "," & evalRequestValue(request.form("chkmainphone")) _
						& " )"
			QryExecuteWithTrans(sqltxt)
			
						
			sqltxt = "Insert requiredCustomerFields (storeid,fieldname,Required ) values (" _
						& l_storeid _
						& "," & "'email'"  _
						& "," & evalRequestValue(request.form("chkemail")) _
						& " )"
			QryExecuteWithTrans(sqltxt)
			
			
			sqltxt = 	"Insert requiredCustomerFields (storeid,fieldname,Required ) values (" _
							& l_storeid _
							& "," & "'dateofbirth'"  _
							& "," & evalRequestValue(request.form("chkDateofBirth")) _
							& " )"
			QryExecuteWithTrans(sqltxt)
			
			sqltxt = 	"Insert requiredCustomerFields (storeid,fieldname,Required ) values (" _
							& l_storeid _
							& "," & "'mainAddress'"  _
							& "," & evalRequestValue(request.form("chkAddress")) _
							& " )"
							
			QryExecuteWithTrans(sqltxt)
			
			sqltxt = 	"Insert requiredCustomerFields (storeid,fieldname,Required ) values (" _
							& l_storeid _
							& "," & "'cellPhone'"  _
							& "," & evalRequestValue(request.form("chkCellPhone")) _
							& " )"
							
			QryExecuteWithTrans(sqltxt)

			DbEndTrans()	

	end function	
	
	
%>
