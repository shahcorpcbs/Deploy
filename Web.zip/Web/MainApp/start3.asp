<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<!--#include file="../include/SystemStartup.asp"-->
<% cbsInit %>

<!--#include file="../include/services.asp" -->
<!--#include file="../include/LicenseCheck.asp" -->
<!--#include file="../include/clientscheck.inc" -->
<!--#include file="../include/security.asp" -->

<!--#include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/form_merge.asp" -->
<!--#include file="../include/schedule.asp" -->
<!--#include file="../include/messages.asp" -->


<%
		dim printOnHomeScreen
		
		startupActions
		
		if request.querystring("bannertext") <> "" then
			session("bannertext") = request.querystring("bannertext")
		end if


		printOnHomeScreen = getMSVar("printOnHomeScreen")
		
		Session("employeeID") = 0
		Session("employeeName") = ""
		Session("ticketPrefix") = getTicketPrefix(session("storeid"))
		Session("loginDate") = ""

		select case lcase(request.querystring("useraction"))
		case "selectroute"
			Session("filterRouteNumber") = request.querystring("routeNumber")
			Session("filterCommercialAccount") = request.querystring("routeDept")
		end select

		sub UpdateCustomerStats()
			dim CustomerChartDays
			
			CustomerChartDays = getMSVar("CustomerChartDays")
		
			if CustomerChartDays > 0 then
				query = "exec UpdateCustomerStats"
				qryexecute query
			end if
		end sub
		
		function getTicketPrefix(storeid)
			dim query, rs

			if storeid <> "" then
				query = " select ticketPrefix from store where storeid = " & storeid
				set rs = getdisconnectedrecordset(query)

				if rs.recordcount > 0 then
					getTicketPrefix = rs("ticketPrefix")
				end if

				set rs = nothing
			end if
		end function

		function getCommercialAccounts(routeNumber)
			dim query, rs

			query = "select distinct parentCustomer.customername, parentCustomer.customersequencenumber "
			query = query & " from customer parentCustomer inner join "
			query = query & " customer childCustomer "
			query = query & " on parentCustomer.customerSequenceNumber = childCustomer.parentCustomerSeq "
			query = query & " where parentCustomer.isactive = 1 and childCustomer.isactive = 1 "
			if routeNumber <> "" then
				query = query & " and parentCustomer.routeNumber = " & routeNumber
			end if

			set getCommercialAccounts = getdisconnectedrecordset(query)

		end function

		function getRouteVersion(storeid)
			dim query, rs

			query = " select routeVersion from miscsetup where storeid = " & storeid

			set rs = getdisconnectedrecordset(query)

			getRouteVersion = rs("routeVersion")

			set rs = nothing
		end function
		

		function getMSVar(id)
			dim query, rs
			
			query = "select " & id & " from miscsetup where storeid = " & session("storeid")
			set rs = getdisconnectedrecordset(query)
	
			getMSVar = rs(id)
			
			set rs = nothing
		end function
		
		function startupActions()
			CBS_preformScheduledActions
			
			if not checkStartupDone() then
				UpdateCustomerStats
				markStartupDone
			end if
		end function
		
		function markStartupDone()
			dim query, rs
			
			query = " insert into systemlog ([type]) VALUES ('STARTUP') "
			
			qryexecute query
		
		end function
		
		function checkStartupDone()
			dim query, rs
			
			query = " select 1 from systemlog where [type] = 'STARTUP' and datediff(day, [date], getdate()) = 0 "
			set rs = getdisconnectedrecordset(query)
			
			checkStartupDone = rs.recordcount > 0
			
			set rs = nothing
		end function
		
%>



<HTML>
<HEAD>


<STYLE  type="text/css" >
	BODY {font-family: "Arial"}
</STYLE>



<link rel="stylesheet" type="text/css" href="/style/banner.css" />

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<script language="javascript" type="text/javascript" src="/Script/printing.js"></script>

<script language="javascript" type="text/javascript" src="/external/jquery.js"></script>

<script language="javascript" type="text/javascript">


	function loadIframe(iframeName, url)
	{
		if(window.frames[iframeName])
		{
			window.frames[iframeName].location = url;
			return false;
		}
		else
			return true;
	}

	function CaptureKey(msg){

		if (event.keyCode == 13){
			SmartSearch(msg);
		}
	}

	function SmartSearch(msg) {
		msg = translateInvoiceNumber(msg);
		Login("/mainapp/customersearch.asp?targetpage=CustomerFunctions&smartsearch=" + encodeURIComponent(msg));
	}
	function GoToCustomer(customerseq) {
		Login("/mainapp/customerfunctions.asp?customerseq=" + customerseq);
    }

	function hideScrollBars(){
		document.body.style.overflow='hidden';
	}

	function printTags() {
		cbs_prompt("Enter Invoice Number", handlePrintTags);
	}

	function handlePrintTags() {
        clearPromptMsg();
	    var invoicenumber = document.getElementById('inputTxtLine').value
		if(invoicenumber != null && invoicenumber != "")
			CbsPrintForm(CbsForm.Tag, CbsKey.InvoiceNumber, invoicenumber);
	}

	function printInvoice() {
		 cbs_prompt("Enter Invoice Number", handlePrintInvoice);
	}

	function handlePrintInvoice() {
        clearPromptMsg();
	    var invoicenumber = document.getElementById('inputTxtLine').value
		if(invoicenumber != null && invoicenumber != "") {
		    CbsPrintForm(CbsForm.Detailed, CbsKey.InvoiceNumber, invoicenumber);
		}
	}

	function exit() {
		//location.href = "/mainapp/exit.asp";
		window.close();
	}


	function licenseWarning() {

<%
		if licenseStyle = 1 then
            dim license_name, license_key, license_expiration, daysToExpire

		    getLicenseDetails license_key, license_name, license_expiration
		    daysToExpire = datediff("d", date(), license_expiration)
		    if daysToExpire <= 20 and daysToExpire > 0 then %>
		        cbs_alert("Your license for CBS will expire in <%=daysToExpire%> days.  Please contact Shahcorp for a new license");
            <%  elseif daysToExpire = 0 then %>
		        cbs_alert("Your license for CBS expires today.  Please contact Shahcorp for a new license");
<%
		    end if
		else
		    if daysLeft <> "" and daysLeft <> "1" then %>
                cbs_alert("Your license for CBS will expire in <%=daysLeft%> days.  Please contact Shahcorp for a new license");
            <% elseif daysLeft = "1" then %>
                cbs_alert("Your license for CBS expires today.  Please contact Shahcorp for a new license");
<%
		    end if
		end if
%>
	}

	function selectRoute(routeNumber, routeDept) {
		location.href = "start2.asp?useraction=selectroute&routeNumber=" + routeNumber + "&routeDept=" + routeDept;
	}

	function setBannerParams() {
		if(window.parent) {
			window.parent.setEmployeeID('');
			window.parent.setTerminalID('<%=session("terminalid")%>');	
		}
	}
	
	
	function onPageLoad() {
		hideScrollBars();
		licenseWarning();
		$("#smartQuery").focus();
		if(window.parent) {
			window.parent.OnLoadStart();
		}
	}
	
	function Login(url, rc) {
		if(rc === undefined)
			rc = 1;
		else
			rc = (rc ? 1 : 0);

		if(window.parent) {
			window.parent.Login(function(employeeid) {
				location.href = url;
			}, rc);
		}
	}

	$(document).ready(function() {
		if(window.parent) {
			setBannerParams()
			window.parent.Logout();
		}
	});

    function setSearchFocus() {
        if (!isOtherMsgActive()) {
            $("#smartQuery").focus()
        }
    }

</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="onPageLoad();">
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->

<% if useNew = 0 then %>
<!-- #include file="startOld.asp" -->
<% else %>
<!-- #include file="startNew.asp" -->
<% end if %>

</BODY>
</HTML>
