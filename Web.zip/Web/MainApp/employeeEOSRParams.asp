<%@ Language=VBScript %>
<% option explicit %>


<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!-- #include file="CheckSessionExpiry.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("reportId")%>
<%	
	dim reportID
	dim rangeStartDate
	dim rangeEndDate
	dim paramStatus
	dim userAction 
	dim sameStartingAmtForCashout
	dim amtForCashout
	dim l_terminalID
	dim ObjMiscSetup	
	l_terminalID = session("terminalID")
	
	set Session("objRP") = Server.CreateObject("CBSReports.clsParams")

	Session("objRP").rangeStartDate = CDate(FormatDateTime(Now(), vbShortDate))
	Session("objRP").rangeEndDate = CDate(FormatDateTime(Now(), vbShortDate))


    dim userIPAddress, printerIP, printerName
	getCashDrawerFields()
	
	if not IsObject(Session("miscSetUp")) then
		initializeMiscSetup
	end if
	set ObjMiscSetup = Session("miscSetUp")	
	if ObjMiscSetup.Count > 0 then
		sameStartingAmtForCashout = ObjMiscSetup.Item("sameStartingAmtForCashout")
		if sameStartingAmtForCashout then
			sameStartingAmtForCashout = 1
			amtForCashout = ObjMiscSetup.Item("amtForCashout")
		else
			sameStartingAmtForCashout = 0
		end if		
	else
		sameStartingAmtForCashout = 0
	end if		
	
	userAction = Request.QueryString("userAction")
	if  userAction = "refresh" then	
		reportID = Session("objRP").reportNumber

		Session("objRP").rangeStartDate = Request.Form("rangeStartDate")
		Session("objRP").rangeEndDate =  Request.Form("rangeEndDate")

		if isNumeric(Request.Form("rangeStartAmount")) then
			Session("objRP").rangeStartAmount = CCur(Request.Form("rangeStartAmount"))
		end if

		if isNumeric(Request.Form("terminalID")) then
			Session("objRP").terminalID = CLng(Request.Form("terminalID"))
		else
			Session("objRP").terminalID = 0
		end if
		
		if isNumeric(Request.Form("hardwareID")) then
			Session("objRP").hardwareID = CLng(Request.Form("hardwareID"))
		else
			Session("objRP").hardwareID = 0
		end if
			
		if isNumeric(Request.Form("nbrOf1Cents")) then
			Session("objRP").nbrOf1Cents = CLng(Request.Form("nbrOf1Cents"))
		else
			Session("objRP").nbrOf1Cents = 0
		end if

		if isNumeric(Request.Form("nbrOf5Cents")) then
			Session("objRP").nbrOf5Cents = CLng(Request.Form("nbrOf5Cents"))
		else
			Session("objRP").nbrOf5Cents = 0
		end if
		if isNumeric(Request.Form("nbrOf10Cents")) then	
			Session("objRP").nbrOf10Cents = CLng(Request.Form("nbrOf10Cents"))
		else
			Session("objRP").nbrOf10Cents = 0
		end if
		if isNumeric(Request.Form("nbrOf25Cents")) then
			Session("objRP").nbrOf25Cents = CLng(Request.Form("nbrOf25Cents"))
		else
			Session("objRP").nbrOf25Cents = 0
		end if
	

		if isNumeric(Request.Form("nbrOf1Dollars")) then
			Session("objRP").nbrOf1Dollars = CLng(Request.Form("nbrOf1Dollars"))
		else
			Session("objRP").nbrOf1Dollars = 0
		end if
		if isNumeric(Request.Form("nbrOf5Dollars")) then
			Session("objRP").nbrOf5Dollars = CLng(Request.Form("nbrOf5Dollars"))
		else
			Session("objRP").nbrOf5Dollars = 0
		end if	
		if isNumeric(Request.Form("nbrOf10Dollars")) then
			Session("objRP").nbrOf10Dollars = CLng(Request.Form("nbrOf10Dollars"))
		else
			Session("objRP").nbrOf10Dollars = 0
		end if	
		if isNumeric(Request.Form("nbrOf20Dollars")) then
			Session("objRP").nbrOf20Dollars = CLng(Request.Form("nbrOf20Dollars"))
		else
			Session("objRP").nbrOf20Dollars = 0
		end if
		if isNumeric(Request.Form("nbrOf50Dollars")) then
			Session("objRP").nbrOf50Dollars = CLng(Request.Form("nbrOf50Dollars"))
		else
			Session("objRP").nbrOf50Dollars = 0
		end if
		if isNumeric(Request.Form("nbrOf100Dollars")) then
			Session("objRP").nbrOf100Dollars = CLng(Request.Form("nbrOf100Dollars"))
		else
			Session("objRP").nbrOf100Dollars = 0
		end if

		if isNumeric(Request.Form("checkAmount")) then
			Session("objRP").checkAmount = CCur(Request.Form("checkAmount"))
		else
			Session("objRP").checkAmount = 0
		end if
		if isNumeric(Request.Form("ccAmount")) then
			Session("objRP").ccAmount = CCur(Request.Form("ccAmount"))
		else
			Session("objRP").ccAmount = 0
		end if
		if isNumeric(Request.Form("tradeAmount")) then
			Session("objRP").tradeAmount = CCur(Request.Form("tradeAmount"))
		else
			Session("objRP").tradeAmount = 0
		end if
'MWiemann -- added coupon payment field		
		if isNumeric(Request.Form("couponAmount")) then
			Session("objRP").couponAmount = CCur(Request.Form("couponAmount"))
		else
			Session("objRP").couponAmount = 0
		end if		
	else
		reportID = IIf(Trim(Request.QueryString("reportID")) = "", 0, Clng(Request.QueryString("reportID")))		
		If GetReportParams(reportID, False, "", 0) = "NEW" Then
			' Initialize All Date Values.

			Session("objRP").requesterName = RPT_Requester_Name_Employee
			Session("objRP").terminalID = l_terminalID

		End If
	end if
	
%>


<%

' Generic Functions
Const TEXT_FOR_ALL_IN_DROPDOWN = "(All)"
Const CODE_FOR_ALL_IN_DROPDOWN = "0"


	function getCashDrawerFields()
	    dim query, rs

	    printerIP = getPrinterShortPath()

        query = " select storehardware.cashdrawertype, isnull(printer.printername, '') as printername "
        query = query & " from storehardware "
        query = query & " left outer join printer on storehardware.cashdrawerattachedprinterid = printer.printerid "
        query = query & " where storehardware.hardwaretype = 'CD' "
        query = query & " and storehardware.terminalid = " & session("terminalid")

        set rs = getdisconnectedrecordset(query)
        if rs.recordcount > 0 then
            printerName = Replace(rs("printername"), "'", "\'")
        end if


        userIPAddress = getLocalPrinterAddress(session("terminalid"))

	end function


function GetEmployeeDropDown( storeID )

	dim strDropDownTag
	dim objRSEmployee
	dim strSQL
	
	strDropDownTag = "<SELECT name=EmployeeID> " & _
						"<OPTION VALUE =" & CODE_FOR_ALL_IN_DROPDOWN & ">" & TEXT_FOR_ALL_IN_DROPDOWN & "</OPTION>"
							
	' As long an option to select all is there, we don't care if there is an error.
	on error resume next

	strSQL = "SELECT employeeID, employeeName, storeID FROM Employee where employeestatus = 'A'" 

	strSQL = strSQL & " ORDER BY employeeName"
	
	set objRSEmployee = getDisconnectedRecordset(strSQL)

	While not objRSEmployee.EOF
		strDropDownTag = strDropDownTag & "<OPTION VALUE= " & objRSEmployee("employeeId") & _
  					     IIf(objRSEmployee("employeeId") = Session("objRP").employeeId, " SELECTED", "") & ">" & _
						 objRSEmployee("employeeName") & "</OPTION>"
		objRSEmployee.MoveNext
	Wend

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetEmployeeDropDown = strDropDownTag
	
end function

function GetTerminalDropDown( storeID )

	dim strDropDownTag
	dim objRSTerminal
	dim strSQL
	
	' strDropDownTag = "<SELECT name=terminalID OnChange=""refreshForm();""> " 
	strDropDownTag = "<SELECT name=terminalID> " & _
						"<OPTION VALUE =" & CODE_FOR_ALL_IN_DROPDOWN & ">" & TEXT_FOR_ALL_IN_DROPDOWN & "</OPTION>"
							
							
	'on error resume next

	if storeID <> "" then
		strSQL = "SELECT terminalID, name, storeID FROM Terminal" & _
				  " WHERE storeID = " & storeID & _
				  " ORDER BY name"
	
		set objRSTerminal = getDisconnectedRecordset(strSQL)

		While not objRSTerminal.EOF
			if Session("objRP").terminalId <= 0 then
				Session("objRP").terminalId = objRSTerminal("terminalId").value
			end if
			strDropDownTag = strDropDownTag & "<OPTION VALUE= " & objRSTerminal("terminalId") & _
  						     IIf(objRSTerminal("terminalId") = Session("objRP").terminalId, " SELECTED", "") & ">" & _
							 objRSTerminal("name") & "</OPTION>"
			objRSTerminal.MoveNext
		Wend
	end if
	
	strDropDownTag = strDropDownTag & "</SELECT>"

	GetTerminalDropDown = strDropDownTag
	
end function

function GetHardwareDropDown( storeID, terminalID, hardwareType, dropDownName )

	dim strDropDownTag
	dim objRSHardware
	dim strSQL
	
	strDropDownTag = "<SELECT name=" & dropDownName & "> " 
							
	' on error resume next

	if terminalID <> "" then
		strSQL = "SELECT hardwareID, hardwareName FROM StoreHardware" & _
				  " WHERE terminalID = " & terminalID & _
				  " AND hardwareType = '" & hardwareType & "'" & _
				  " ORDER BY hardwareName"
	
		set objRSHardware = getDisconnectedRecordset(strSQL)

		While not objRSHardware.EOF
			strDropDownTag = strDropDownTag & "<OPTION VALUE= " & objRSHardware("hardwareId") & _
  						     IIf(objRSHardware("hardwareId") = Session("objRP").hardwareId, " SELECTED", "") & ">" & _
							 objRSHardware("hardwareName") & "</OPTION>"
			objRSHardware.MoveNext
		Wend
	end if
	
	strDropDownTag = strDropDownTag & "</SELECT>"

	GetHardwareDropDown = strDropDownTag
	
end function

%>

<HTML>

<HEAD>

<TITLE>Report Parameter Selection</TITLE>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="/script/cashdrawer.js"></script>


<script type="text/javascript">
    history.forward();
</script>

</HEAD>

<script language="javascript" type="text/javascript">

	function submitForm() {
		if (validateParameters()) {		
			document.reportParmsForm.submit();
		}	
	}
	function closeForm() {
		document.reportParmsForm.action = "employeemenu.asp";
		document.reportParmsForm.submit();
	}

	function validateParameters() {
		// Validate only if the form variable is defined.

		if (reportParmsForm.numberOfHours != null) {
				// Validate only if something is entered.
				if (checkInt(reportParmsForm.numberOfHours.value) == false) {
					cbs_alert("Number of hours must be within 0 to 2,147,483,647. Please enter a numeric value without embedded comma or period.");
					reportParmsForm.numberOfHours.focus();
					return (false);
				}
		}

		if (reportParmsForm.numberOfMonths != null) {
				// Validate only if something is entered.
				if (checkInt(reportParmsForm.numberOfMonths.value) == false) {
					cbs_alert("Number of months must be within 0 to 9,999. Please enter a numeric value without embedded comma or period.");
					reportParmsForm.numberOfMonths.focus();
					return (false);
				}
		}
		return (true);
	}

	function refreshForm() {
		document.reportParmsForm.action = "employeeEOSRParams.asp?userAction=refresh";			
		document.reportParmsForm.submit();		
	}

	function cashDrawerOpen(){
        var url = "http://<%=userIPAddress%><%=printerIP%>/openCashDrawer"
        OpenCashDrawer(url, '<%= printerName %>');
        return false;
	}
	
	
	function calculateValue(element){
		var input1 = String(element.value)
		if (isNaN(input1)) {
			if (input1.indexOf("+") != -1) {
				var strArry = input1.split("+")
				var arraySpot = 0;
				var newVal = 0.0;
				while (arraySpot < strArry.length) {
					newVal = newVal + parseFloat(strArry[arraySpot]);
					arraySpot+=1;
				}
				element.value = parseMoney(newVal);
			}
			else {
			element.value = 0;
			}
		}
		else {
			element.value = parseMoney(input1);	
		}
	}
	
	function handler(NextName){
		var key;
		e = window.event;
		key = e.keyCode;
		if (key == 13) {
		    document.all(NextName).focus();
			return false;
		}
		return true;
	}
			
</SCRIPT>

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="JavaScript" src="../script/validation.js"></script>

<script language="javascript" type="text/javascript">

	function setRangeStartDate() {
		var prevValue;
		var newValue;
		prevValue = document.reportParmsForm.rangeStartDate.value;
		show_calendar("reportParmsForm.rangeStartDate");
		newValue = document.reportParmsForm.rangeStartDate.value;		
	}

	function setRangeEndDate() {
		show_calendar("reportParmsForm.rangeEndDate");
	}
	
	function setRangeStartDateCompareTo() {
		show_calendar("reportParmsForm.rangeStartDateCompareTo");
	}
	
	function setRangeEndDateCompareTo() {
		show_calendar("reportParmsForm.rangeEndDateCompareTo");
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->

<H1>Select Report Parameters </H1>

<FORM id="reportParmsForm" name="reportParmsForm" action="report.asp" method="POST"  onsubmit="return false">

	<input type="hidden" name="reportID" value="<%= Session("objRP").reportNumber%>">
	<input type="hidden" name="storeID" value="<%= Session("objRP").storeID %>">
	<input type="hidden" name="hardwareID" value="0">
	<!-- 
	<TABLE ALIGN=center WIDTH="400px" BORDER=1 CELLSPACING=1 CELLPADDING=5 >
	-->

	<TABLE ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=1 CELLPADDING=0 >
		<tr width=100%><td align=center><b><%= Request.QueryString("reportName") %><b></td></tr> 
	</TABLE>
	
	<TABLE ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=1 CELLPADDING=0 >

	<!-- <tr height=30px><td>&nbsp;</td></tr> -->

		<!-- First display the standard selection criteria -->
		

		<% 		
		'	Allow Terminal Selection for the following reports.
		if _
			  reportID = RPT_NBR_Cash_Out Or _
			  reportID = RPT_NBR_Cash_Out_Z_Report _
		then
		%>
		
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Terminal: </td>
				<td align=left > <%= GetTerminalDropDown(Session("objRP").storeID) %>
				</td>
				<td rowspan=18>
					<INPUT class=touchnoborder id=ok name=ok type=button value="" onClick="submitForm();" 
						style="background-image:url(../images/Ok.gif);"><br><br>
					<INPUT class=touchnoborder id=close name=close type=button value="" onClick="closeForm();" 
						style="background-image:url(../images/Cancel.gif);">
					<br><br>
					<BUTTON <%sec_DWP("opencashdrawer")%> class=std style="width:100px;height=50px;font-size:12px" name=bttnCashDrawer onClick="cashDrawerOpen()">Open Cash<br>Drawer</button>
		
				</td>
			</tr>

			</tr>

		<% end if %>


		<% 		
		'	Allow Employee Selection for the following reports.
		if _
			reportID = RPT_NBR_Cash_Out Or _
			reportID = RPT_NBR_Cash_Out_Z_Report _
		then
		%>
		
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Employee: </td>
				<td align=left > <%= GetEmployeeDropDown("") %>
				</td>
			</tr>

		<% end if %>

		<%
		'	Allow Start Date selection for the following reports.
		if _
			reportID = RPT_NBR_Cash_Out Or _
			reportID = RPT_NBR_Cash_Out_Z_Report _
		then
		%>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Start Date: </td>
				<td align=left >
					<INPUT readonly id=rangeStartDate name=rangeStartDate class=text style="WIDTH: 100px;vertical-align:middle;" value="<%= Session("objRP").rangeStartDate %>">
					<INPUT class=touch id=bttnRangeStartDate name=bttnRangeStartDate type=button value="..." style="width:25px;height:25px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="setRangeStartDate();">
				    <select id="sel_dtRange" onChange="updateDateRange(this, 'rangeStartDate', 'rangeEndDate')">
				        <option value="0"></option>
				        <option value="1">Yesterday</option>
				        <option value="2">Week To Date</option>
				        <option value="3">Last Week</option>
				        <option value="4">Month To Date</option>
				        <option value="5">Last Month</option>
				        <option value="6">Year To Date</option>
				        <option value="7">Last Year</option>
				    </select>
				</td>

			</tr>
		<% end if %>
		

		<%
		'	Allow End Date Selection for the following reports.
		if _
			reportID = RPT_NBR_Cash_Out Or _
			reportID = RPT_NBR_Cash_Out_Z_Report _
		then
		%>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">End Date: </td>
				<td  align=left width = 50%>
					<INPUT readonly id=rangeEndDate name=rangeEndDate class=text style="WIDTH: 100px;vertical-align:middle;" value="<%= Session("objRP").rangeEndDate %>">
					<INPUT class=touch id=bttnRangEndDate name=bttnRangeEndDate type=button value="..." style="width:25px;height:25px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="setRangeEndDate();">
				</td>
			</tr>
		<% end if %>
		
		<%				
			' Cash Denominations
		if _
			reportID = RPT_NBR_Cash_Out Or _
			reportID = RPT_NBR_Cash_Out_Z_Report _
		then
		%>			
			
			<tr height=30px width=100%>
				<td width = 50% class = "label" align=right Style="Font-weight=normal">Starting Amount: </td>
				<td width = 50% >
					<INPUT type=text align=left size=11 Maxlength="9" id=rangeStartAmount name=rangeStartAmount 
					<% if sameStartingAmtForCashout then %>
						value="<%= amtForCashout %>" readonly
					<% else %>
						value="<%= Session("objRP").rangeStartAmount %>" 
					<% end if %>
						onkeyDown="return handler('nbrOf1Cents')" onFocus="(this.select())" >
				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$0.01: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf1Cents name=nbrOf1Cents value="<%= Session("objRP").nbrOf1Cents %>" onkeyDown="return handler('nbrOf5Cents')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$0.05: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf5Cents name=nbrOf5Cents value="<%= Session("objRP").nbrOf5Cents %>" onkeyDown="return handler('nbrOf10Cents')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$0.10: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf10Cents name=nbrOf10Cents value="<%= Session("objRP").nbrOf10Cents %>" onkeyDown="return handler('nbrOf25Cents')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$0.25: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf25Cents name=nbrOf25Cents value="<%= Session("objRP").nbrOf25Cents %>" onkeyDown="return handler('nbrOf1Dollars')" onFocus="(this.select())" >
				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$1: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf1Dollars name=nbrOf1Dollars value="<%= Session("objRP").nbrOf1Dollars %>" onkeyDown="return handler('nbrOf5Dollars')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$5: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf5Dollars name=nbrOf5Dollars value="<%= Session("objRP").nbrOf5Dollars %>" onkeyDown="return handler('nbrOf10Dollars')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$10: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf10Dollars name=nbrOf10Dollars value="<%= Session("objRP").nbrOf10Dollars %>" onkeyDown="return handler('nbrOf20Dollars')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$20: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf20Dollars name=nbrOf20Dollars value="<%= Session("objRP").nbrOf20Dollars %>" onkeyDown="return handler('nbrOf50Dollars')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$50: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf50Dollars name=nbrOf50Dollars value="<%= Session("objRP").nbrOf50Dollars %>" onkeyDown="return handler('nbrOf100Dollars')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$100: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf100Dollars name=nbrOf100Dollars value="<%= Session("objRP").nbrOf100Dollars %>" onkeyDown="return handler('checkAmount')" onFocus="(this.select())" >
				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Check Amount: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="100" id=checkAmount name=checkAmount onchange="calculateValue(this)" value="<%= Session("objRP").checkAmount %>" onkeyDown="return handler('ccAmount')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Credit Card Amount: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="100" id=ccAmount name=ccAmount onchange="calculateValue(this)" value="<%= Session("objRP").ccAmount %>" onkeyDown="return handler('tradeAmount')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Trade Amount: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="100" id=tradeAmount name=tradeAmount onchange="calculateValue(this)" value="<%= Session("objRP").tradeAmount %>" onkeyDown="return handler('couponAmount')" onFocus="(this.select())" >
				</td>
			</tr>
			<!--MWiemann added coupon payment 3.14.04 -->
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Coupon Amount: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="100" id=couponAmount name=couponAmount onchange="calculateValue(this)" value="<%= Session("objRP").couponAmount %>"
				onkeyDown="return handler('ok')" onFocus="(this.select())" >
				</td>
			</tr>
			

		<% end if %>

	</table>
</form>
</BODY>
</HTML>
