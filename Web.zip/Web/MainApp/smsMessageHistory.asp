<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim customerseq, messageId, directSel, searchText, includeErrors, dateBegin, dateEnd

	customerSeq = getReqVar("customerSeq")
	messageId = getReqVar("messageId")
	directSel = getReqVar("directSel")
	searchText = getReqVar("searchText")
	includeErrors = getReqVar("includeErrors")
	dateBegin = getReqVar("dateBegin")
	dateEnd = getReqVar("dateEnd")

	query = " select e.employeeName, smh.employeeId, dateChanged, status, note from SMSMessageHistory smh left join employee e "
	query = query & " on smh.employeeId = e.employeeId where TwilioResponseMessageId = " & messageId
	query = query & " order by dateChanged desc "
	set rs = getdisconnectedrecordset(query)


	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

%>
<HTML>
<HEAD>
<TITLE>SMS History</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript">

	function createActionString() {
	    var searchText = '<%=searchText%>'
	    var action = "";
	    if (searchText.length > 0) {
	        action = action + "&searchText=" + encodeURIComponent(searchText)
	    }

	    action = action + "&directSel=" + encodeURIComponent(<%=directSel%>)
	    action = action + "&dateBegin=<%=dateBegin%>"
	    action = action + "&dateEnd=<%=dateEnd%>"
        action = action + "&includeErrors=<%=includeErrors%>"
	    return action;
	}


	function exit() {
        document.smsMessageHistory.action = "/mainapp/SMSHistory.asp?customerseq=<%=customerSeq%>" + createActionString();
        document.smsMessageHistory.submit();
	}

</script>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>
    SMS Message History
</H1>

<FORM id="smsMessageHistory" name="smsMessageHistory" action="" method="post">
<INPUT type="hidden" name="customerseq" value="<%=customerseq%>" />

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
    <SPAN style="float:right">
        <BUTTON onclick="exit()">Exit</BUTTON>
    </SPAN>
</DIV>

<div style="height: 640px; overflow: scroll">
<table class="itable" width="100%" cellspacing="0">
<tr>
	<th>Employee</th>
	<th>Date Changed</th>
	<th>Status</th>
	<th>Note</th>
</tr>

<%
	while not(rs.eof or rs.bof)
%>
<tr>
    <% if rs("employeeId") = "0" then %>
        <td>Messenger Service</td>
    <% else %>
	    <td><%=rs("employeeName")%></td>
	<% end if %>
	<td><%=rs("dateChanged")%></td>
	<td>
	    <% if rs("status") = 0 then %>
	        Unread
	    <% elseif rs("status") = 1 then %>
	        Read
	    <% elseif rs("status") = 2 then %>
	        Handled
	    <% elseif rs("status") = 3 then %>
	        Auto-Handled
	    <% end if %>
    </td>
	<td><%=rs("note")%></td>
</tr>

<%
		rs.movenext
	wend
	set rs = nothing
%>
</table>
</div>

</FORM>
</BODY>
</HTML>

