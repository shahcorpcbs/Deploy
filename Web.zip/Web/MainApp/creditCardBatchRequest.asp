<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/processor.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim storeNumber
	dim routeNumber
	dim priceListID
	dim balanceAsOf
	dim ccprocessor
	dim totalOfAccounts
	dim includeactive
	dim batchid
	dim use_clearent
	

	
	set ccprocessor = Server.CreateObject("ShahcorpComponents.creditCardProcessing")
	
	ccprocessor.DBConnectionString = Session("shahcorpDSN")
	
	ccprocessor.XChargeDirectory = getMSVar("XChargePath")
	if isobject(getMSVar("XChargePathKeyed")) then
		ccprocessor.XChargeDirectoryKeyed = getMSVar("XChargePathKeyed")
	end if
	ccprocessor.XChargeTimeout = getMSVar("XChargeTimeout")

    determineIfClearent


	
	priceListID = getReqVar("priceListID")
	storeNumber = getReqVar("storeNumber")
	routeNumber = getReqVar("routeNumber")
	balanceAsOf = getReqVar("balanceAsOf")
	includeactive = trim(getReqVar("includeactive")) <> ""
	
	if balanceAsOf = "" then
		balanceAsOf = getCurrentDate()
	end if
	
	function getMSVar(id)
		dim query, rs
		
		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)
		
		set rs = nothing
	end function
	
	sub UpdateGeneralLedger()
		dim query
		
		query = "EXEC UpdateGeneralLedger NULL, " & Session("EmployeeID") & ", " & Session("StoreID")
		
		qryexecute query
	end sub
	
	function getCurrentDate()
		getCurrentDate = Date()
	end function
	
	
	select case lcase(Request.QueryString("useraction"))
	case "processaccounts"
		processAccounts
	
	end select
	
	
	function getCurrentAmountDue(customerseq, includeactive)
		dim query, rs
		
		
		if includeactive then
		  query = "select (dbo.getAccountBalanceForCCBatch(customerSequenceNumber, '" & balanceAsOf & "') - dbo.getCustomerPendingAccountCredit(customerSequenceNumber) + dbo.getAccountBalanceActive(customerSequenceNumber, getdate(), 1)) as accountBalanceToDate from customer where customersequencenumber = " & customerseq	
		else
		  query = "select (dbo.getAccountBalanceForCCBatch(customerSequenceNumber, '" & balanceAsOf & "') - dbo.getCustomerPendingAccountCredit(customerSequenceNumber)) as accountBalanceToDate from customer where customersequencenumber = " & customerseq	
		end if
    
    set rs = getdisconnectedrecordset(query)
		
		getCurrentAmountDue = rs("accountBalanceToDate")
		
		set rs = nothing 
	end function
	
	sub processAccounts()
		dim customerSeqs
		dim customerSeq
		dim fields
		dim amountdue
		dim terminalID
		
		terminalID = session("terminalID")
		
		set customerSeqs = Request.Form("chkaccount")
		
		batchid = ccprocessor.GetNextBatchGroup()

		
		for each customerSeq in customerSeqs
			set fields = createFieldsFromCustomerSeq(customerSeq)
			amountdue = getCurrentAmountDue(customerSeq, includeactive)
			'response.write customerseq & "-" & batchid & "-" & amountdue & "<br>"
			'debugCCFields fields
			if use_clearent then
			        query = "insert into PaymentBatch (BatchID, CustomerSequenceNumber, EmployeeInitiated, CustomerName, AccountNumber, ExpirationDate, TransactionAmount, TransactionGUID) values ("
                    query = query & batchid & ", "
                    query = query & customerseq & ", "
                    query = query & "1, "
                    query = query & DbQryString(Trim(Trim(fields.firstname) & " " & Trim(fields.lastname))) & ", "
                    query = query & DbQryString(Trim(fields.accountnumber)) & ","
                    query = query & DbQryString(fields.expirationyear & fields.expirationmonth) & ", "
                    query = query & amountdue & ", "
                    query = query & "'" & batchId & "_" & customerSeq & "'"
                    query = query & ")"

                    QryExecute query
			else
			    ccprocessor.AddTransactionToBatch terminalID, fields, customerseq, batchid, 1, amountdue
			end if
		next
		'response.end

        if use_clearent then
		    Response.Redirect "/mainapp/creditcardbatchstatus.asp?useraction=clearentBatch&batchid=" & batchid
		else
		    Response.Redirect "/mainapp/creditcardbatchstatus.asp?batchid=" & batchid
		end if
	end sub
	
	function debugCCFields(fields) 
		response.write "fields.accountnumber='" & fields.accountnumber & "'<br>"
		response.write "fields.expirationmonth='" & fields.expirationmonth & "'<br>"
		response.write "fields.expirationyear='" & fields.expirationyear & "'<br>"
		response.write "fields.cvv2='" & fields.cvv2 & "'<br>"
		response.write "fields.firstname='" & fields.firstname & "'<br>"
		response.write "fields.address='" & fields.address & "'<br>"
		response.write "fields.zip='" & fields.zip & "'<br>"
	end function
	
	function getExpirationMonth(expDate)
		dim dpos

		dpos = instr(expDate, "/")

		if dpos > 0 then
			getExpirationMonth = mid(expDate, 1, dpos - 1)
		else
			getExpirationMonth = left(expDate, 2)
		end if
	end function
	
	function getExpirationYear(expDate)
		dim dpos

		dpos = instr(expDate, "/")

		if dpos > 0 then
			getExpirationYear = mid(expDate, dpos + 1)
		else
			getExpirationYear = right(expDate, 2)
		end if
	end function
	
	function createFieldsFromCustomerSeq(customerseq)
		dim query, rs
		dim result
		dim expDate
		
		set result = Server.CreateObject("ShahcorpComponents.creditCardFields")
		
		if customerseq <> "" then
			query = "select "
			query = query & " isnull(creditCardCVC, '') as creditCardCVC"
			query = query & ", isnull(creditCardExpDate, '0000') as creditCardExpDate"
			query = query & ", isnull(creditCardNumber, '') as creditCardNumber"
			query = query & ", customerName as creditCardNameOnCard"
			query = query & ", isnull(billingAddress1, '') as billingAddress1"
			query = query & ", isnull(billingZipCode, '') as billingZipCode"
			query = query & ", customerName as customerName"
			query = query & " from customer where customersequencenumber = " & customerseq

			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				result.accountnumber = rs("creditCardNumber")
				result.expirationmonth = clng(getExpirationMonth(rs("creditCardExpDate")))
				result.expirationyear = clng(getExpirationYear(rs("creditCardExpDate")))
				result.cvv2 = rs("creditCardCVC")
				
				result.firstname = trim(rs("creditCardNameOnCard"))
				result.address = rs("billingAddress1")
				result.zip = rs("billingZipCode")
			end if
		end if
		
		set createFieldsFromCustomerSeq = result
	end function

	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function maskAccountNumber(AccountNumber)
		dim hideCnt
		dim sleft : sleft = 2
		dim sright : sright = 4
		dim i
		
		if len(AccountNumber) < 10 then
			sleft = 0
			sright = 2
		end if
		
		hideCnt = len(AccountNumber) - (sleft + sright)
		if hideCnt < 0 then hideCnt = 0
		
		maskAccountNumber = left(AccountNumber, sleft)
		
		for i = 1 to hideCnt - 2
			maskAccountNumber = maskAccountNumber & "*"
		next

		maskAccountNumber = maskAccountNumber & right(AccountNumber, sright)
	end function
	
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Credit Card Batch Request</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">

</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script type="text/javascript" src="../Script/clearent.js"></script>
<script type="text/javascript" src="../Script/json2.js"></script>
<script language="javascript" type="text/javascript">
    var running = 0;
	function SelectAllAccounts(v) {
		var il = document.creditCardBatchRequest;
		var len = il.elements.length;
		var i, e;
		
		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkaccount") {
				e.checked = v;
		    }
		}
		
		document.creditCardBatchRequest.chkaccountall.checked = v;
	}


	function lookUp() {
		document.creditCardBatchRequest.action = "";
		document.creditCardBatchRequest.submit();
	}
	
	function processAccounts() {
	    if (running == 1)
	        return;
	    running = 1;
		document.creditCardBatchRequest.action = "?useraction=processaccounts";
		document.creditCardBatchRequest.submit();
	}
	function exitForm() {
		document.creditCardBatchRequest.action = "/mainapp/creditCardBatchList.asp";
		document.creditCardBatchRequest.submit();
	}
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "chkaccount") {
				childEl.children[0].checked = !(childEl.children[0].checked);
				break;
			}
			else if (childEl.name == "chkaccount") {
				childEl.checked = !(childEl.checked)
				break;
			}
		}
	}

</SCRIPT>
<BODY topmargin=0 leftmargin=0 onload="SelectAllAccounts(true); ">

<!-- #include file="../include/banner.inc" -->

<B class="pageHeading">Credit Card Batch Request</B>
<FORM id="creditCardBatchRequest" name="creditCardBatchRequest" action="creditCardBatchRequest.asp" method="post">


<TABLE style="">
<TR>
	<TD>Store</TD>
	<TD>Price List</TD>
	<TD>Route</TD>
	<TD>Date Due</TD>
	<TD>Active</TD>
	<TD></TD>
</TR>

<TR>
	<TD>
	<SELECT name="storeNumber" onchange="lookUp()">
		<OPTION value="" <%if trim(routeNumber) = "" then%>selected<%end if%>>(All)</OPTION>
	<%
		query = "select * from store"
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
	%>
		<OPTION value="<%=rs("storeid")%>" <%if trim(storeNumber) = trim(rs("storeid")) then%>selected<%end if%>><%=rs("name")%></OPTION>
	<%
			rs.movenext
		wend
		set rs = nothing
	%>
	</SELECT>
	</TD>
	
	<TD>
	<SELECT name="priceListID" onchange="lookUp()">
		<OPTION value="" <%if trim(routeNumber) = "" then%>selected<%end if%>>(All)</OPTION>
	<%
		query = "select * from pricelist"
		if storeNumber <> "" then
			query = query & " where storeid = " & storeNumber
		end if
		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
	%>
		<OPTION value="<%=rs("pricelistid")%>"  <%if trim(pricelistid) = trim(rs("pricelistid")) then%>selected<%end if%>><%=rs("name")%></OPTION>
	<%
			rs.movenext
		wend
		set rs = nothing
	%>
	</SELECT>
	</TD>
	
	<TD>
	<SELECT name="routeNumber" onchange="lookUp()">
		<OPTION value="" <%if trim(routeNumber) = "" then%>selected<%end if%>>(All)</OPTION>
	<%
		query = "select * from route"
		if storeNumber <> "" then
			query = query & " where storeid = " & storeNumber
		end if
		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
	%>
		<OPTION value="<%=rs("routeNumber")%>"  <%if trim(routeNumber) = trim(rs("routeNumber")) then%>selected<%end if%>><%=rs("name")%></OPTION>
	<%
			rs.movenext
		wend
		set rs = nothing
	%>
	</SELECT>
	</TD>

	<TD>
	<INPUT name="balanceAsOf" onClick="javascript:show_calendar('creditCardBatchRequest.balanceAsOf');" value="<%=balanceAsOf%>"></INPUT>
	</TD>
  <TD>
    <INPUT type="checkbox" style="width:28;height:28" value="1" name="includeactive" <%if includeactive then%>checked<%end if%> />
  </TD>
	<TD>
	<INPUT type="button" value="Look Up" onclick="lookUp()"></INPUT>
	</TD>
</TABLE>



<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
    <BUTTON onclick="processAccounts()">Process</BUTTON>
	</SPAN>
	
	<SPAN style="float:right">
		<BUTTON onclick="exitForm()">Exit</BUTTON>
		
	</SPAN>
</DIV>


<%
	totalOfAccounts = 0
	
	query = "select *"
	query = query & ", isnull('<b>' + creditCardNameOnCard + '</b>', '<i>' + customerName + '</i>') as creditCardNameOnCard"

	if includeactive then
    query = query & ", (dbo.getAccountBalanceForCCBatch(customerSequenceNumber, '" & balanceAsOf & "') - dbo.getCustomerPendingAccountCredit(customerSequenceNumber) + dbo.getAccountBalanceActive(customerSequenceNumber, getdate(), 1)) as accountBalanceToDate"
  else
	  query = query & ", (dbo.getAccountBalanceForCCBatch(customerSequenceNumber, '" & balanceAsOf & "') - dbo.getCustomerPendingAccountCredit(customerSequenceNumber)) as accountBalanceToDate"
	end if
		
	


	query = query & " from customer c where "

	
	if includeactive then
    query = query & " (dbo.getAccountBalanceForCCBatch(customerSequenceNumber, '" & balanceAsOf & "') - dbo.getCustomerPendingAccountCredit(customerSequenceNumber) + dbo.getAccountBalanceActive(customerSequenceNumber, getdate(), 1)) > 0"
  else
    query = query & " (dbo.getAccountBalanceForCCBatch(customerSequenceNumber, '" & balanceAsOf & "') - dbo.getCustomerPendingAccountCredit(customerSequenceNumber)) > 0"
	end if
	
    query = query & " and ltrim(rtrim(creditCardNumber)) <> '' "
    query = query & " and ltrim(rtrim(creditCardExpDate)) <> '' "
    query = query & " and allowCCBatch = 1"
	
	if storeNumber <> "" then
		query = query & " and storeid = " & storeNumber
	end if
	if priceListID <> "" then
		query = query & " and defaultPriceListID = " & priceListID
	end if
	if routeNumber <> "" then
		query = query & " and routeNumber = " & routeNumber
	end if

	query = query & " order by lastname, firstname"
		
	set rs = getdisconnectedrecordset(query)
%>

	<TABLE class="itable" width="100%" border="0" cellspacing="0" cellpadding="0">
		<TR style="text-align:left" >
			<TH><INPUT name="chkaccountall" type="checkbox" onclick="SelectAllAccounts(this.checked)"></TH>
			<TH>Customer Name</TH>
			<TH>Account Number</TH>
			<TH>Expiration Date</TH>
			<TH>Amount</TH>
		</TR>
<%

	while not(rs.eof or rs.bof)
%>
		<TR onclick="ToggleRowChecked(this);">
			<TD><INPUT name="chkaccount" type="checkbox" value="<%=rs("customersequencenumber")%>" onclick="this.checked = !this.checked"></INPUT></TD>
			<TD><%=Server.HTMLEncode(rs("customername"))%></TD>
			<TD><%=maskAccountNumber(rs("creditCardNumber"))%></TD>
			<TD><%=rs("creditCardExpDate")%></TD>
			<TD><%=formatcurrency(rs("accountBalanceToDate"))%></TD>
		</TR>
<%
		totalOfAccounts = totalOfAccounts + rs("accountBalanceToDate")

		rs.movenext
	wend
	set rs = nothing
%>

		<TR>
			<TD></TD>
			<TD colspan="3"><B>Total</B></TD>
			<TD><%=formatcurrency(totalOfAccounts)%></TD>
		</TR>
		
	</TABLE>
</FORM>
</BODY>
</HTML>
