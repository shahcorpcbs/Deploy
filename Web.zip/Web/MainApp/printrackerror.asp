<%@ Language=VBScript %>
<!-- #include file="../include/localprinter.inc" -->
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	
	Dim bNothingToPrint
	
	
	if isobject(session("listRackMessage"))  then
		
		bNothingToPrint = false
	else
		bNothingToPrint = true
	end if
	
	
	
%>
<%
if not bNothingToPrint then
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<SCRIPT language="javascript">
	function PrintAndClose() {
		window.print();
		setTimeout('window.close();', 1000);
		
	}
</SCRIPT>

<STYLE>
	BODY {
		font-family : Arial, Verdana;
		font-size : 12px;
	}
	H2 {
		font-family : Arial, Verdana;
	}
	TD {
		font-family : Arial, Verdana;
		font-size : 12px;
	}
	TD.Heading {
		font-weight : bold;
	}
</STYLE>
</HEAD>
<BODY onLoad="javascript:PrintAndClose();">
<H2 STYLE="text-align:center;">Rack Error Messages </H2>
<TABLE BGCOLOR="#CCCCCC"BORDER=0 CELLSPACING=1 CELLPADDING=3 WIDTH="99%" ALIGN="CENTER">
	
				<TD class="Heading">Invoice Number</TD>
				<TD class="Heading">Rack Start</TD>
				<TD class="Heading">Group Start</TD>
				<TD class="Heading">Rack End</TD>
				<TD class="Heading">Error Message</TD>
			</tr>
			
			
			<%	dim listRack 
					dim sRackItem
					dim element
					dim arrtemp
					dim sInvoice
					dim srackStart
					dim srackGroupstart
					dim srackGroupEnd
					dim sMessage
					dim rackErrorMessage
					dim sValue
					set listRack =  Server.CreateObject("Scripting.Dictionary")
					if isobject(session("listRackMessage"))  then
						if not session("listRackMessage")is nothing then
							set listRack = session("listRackMessage")
							if isobject(listRack) and not listRack is nothing then
								sRackItem = listRack.Keys
								rackErrorMessage = formatdatetime(datetime()) & " " & session("employee") & vbcrlf
								for each element in sRackItem
				 					arrTemp = split(listRack(element), "|||")
				 					'Response.Write listRack(element)
									sInvoice = trim(arrtemp(0))
									srackStart = trim(arrtemp(1))
									srackGroupstart = trim(arrtemp(2))
									srackGroupEnd = trim(arrtemp(3))
									sMessage = trim(arrtemp(4))
									sValue = trim(arrtemp(5))
									rackErrorMessage =  sMessage & vbcrlf
									
					%>				<tr>
									
									<TD BGCOLOR="#FFFFFF"><%=sInvoice%></TD>
									<TD BGCOLOR="#FFFFFF"><%=srackStart%></TD>
									<TD BGCOLOR="#FFFFFF"><%=srackGroupstart%></TD>
									<TD BGCOLOR="#FFFFFF"><%=srackGroupEnd%></TD>
									<TD BGCOLOR="#FFFFFF"><%=sMessage%></TD>
									</tr>
							<% next	
					end if
					end if
						'set Session("listRackMessage") = nothing
					end if
				%>
			
			
	
</TABLE>

</BODY>
</HTML>

<%
else
%>
<!-- This is when Nothing is there to print.. -->
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<SCRIPT language = "JavaScript">
	function FixWindowSize() {
		window.resizeTo(320,180);
	}
</SCRIPT>
<TITLE>Print Rack Error Messages</TITLE>
</HEAD>
<BODY onLoad="javascript:FixWindowSize();">

<TABLE BORDER=0 WIDTH="100%" ALIGN="CENTER" VALIGN="middle">
	<TR><TH style="font-size:13px;">There are no rows to print</TH></TR>
	<TR><TD ALIGN="center">&nbsp;<BR><A STYLE="text-decoration:underline;" href="javascript:window.close();">Close Window</A></TD></TR>
</TABLE>

</BODY>
</HTML>
	
<%
end if

%>