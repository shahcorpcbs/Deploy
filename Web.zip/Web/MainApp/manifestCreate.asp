<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<!--#include file="../include/security.asp" -->

<!--#include file="../include/manifest.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim manifestID


	select case lcase(request.querystring("useraction"))
	case "inventory"
		manifestID = createInventoryManifest

		CBS_setManifestType manifestid, "TLIST"
		redirectToManifestSelect manifestID
	case "close"
		CBS_CloseInventory request.querystring("inventoryid")
	end select

	function CBS_CloseInventory(inventoryid)
		dim query, rs
		
		if inventoryid <> "" then
			query = " update inventory set [open] = 0 where inventoryid = " & inventoryid
			qryexecute query
		end if
	
	end function 
	
	function createInventoryManifest()
		dim invoiceManifestID
		select case lcase(request.querystring("type"))
		case "due"
			invoiceManifestID = createManifestByDueDate(request.querystring("date"))
			CBS_closeManifest invoiceManifestID
		case "create"
			invoiceManifestID = createManifestByCreateDate(request.querystring("date"))
			CBS_closeManifest invoiceManifestID
		end select

		createInventoryManifest = invoiceManifestID
	end function

	sub redirectToManifestSelect(manifestID)
		if manifestID <> "" then
			response.redirect "/mainapp/manifestSelect.asp?manifestid=" & manifestID
		end if
	end sub

	function createManifestByCreateDate(createdDate)
		dim query, rs
		dim manifestID

		manifestID = CBS_createManifest("Store Inventory by CREATED Date " & createdDate, "")

		query = " select invoicenumber, dbo.pivotTicketRackLocationBrief(ticket.ticketnumber, ', ') as racklocation from ticket "
		query = query & " where ticketstatus = 'AC' and invoicetype = 'D' "
		query = query & " and datediff(day, createdDate, '" & createdDate & "') >= 0 " 

		set rs = getdisconnectedrecordset(query)

		while not(rs.eof or rs.bof)
			CBS_addInvoiceLocationToManifest manifestID, rs("invoicenumber"), rs("racklocation"), false
			rs.movenext
		wend

		set rs = nothing

		createManifestByCreateDate = manifestID
	end function

	function createManifestByDueDate(dueDate)
		dim query, rs
		dim manifestID

		manifestID = CBS_createManifest("Store Inventory by DUE Date " & dueDate, "")

		query = " select invoicenumber, dbo.pivotTicketRackLocationBrief(ticket.ticketnumber, ', ') as racklocation from ticket "
		query = query & " where ticketstatus = 'AC' and invoicetype = 'D' "
		query = query & " and datediff(day, duedate, '" & dueDate & "') >= 0 " 

		set rs = getdisconnectedrecordset(query)

		while not(rs.eof or rs.bof)
			CBS_addInvoiceLocationToManifest manifestID, rs("invoicenumber"), rs("racklocation"), false
			rs.movenext
		wend

		set rs = nothing

		createManifestByDueDate = manifestID
	end function

%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">


<script language="JavaScript" src="../script/date-picker2.js"></script>

<script language="javascript" src="../external/jquery-3.4.1.js"></script>

<script language="javascript" type="text/javascript">
	var previousElement = null;
	var selectedInvId = null;
	var selectedInvNew = null;
	var selectedManId = null;

	function exit() {
	    document.manifestCreate.action = "/mainapp/toolsMenu.asp";
        document.manifestCreate.submit();
	}

	function createInventoryManifest() {
			var sel_date = document.getElementById("cdate").value;
			var sel_type = document.getElementById("cdtype");
			sel_type = sel_type.options[sel_type.selectedIndex].value;
			
			document.manifestCreate.action = "?useraction=inventory&type=" + sel_type + "&date=" + sel_date;
			document.manifestCreate.submit();
	}

	function viewClassicInventory() {
	    document.manifestCreate.action = "/mainapp/inventoryList.asp";
	    document.manifestCreate.submit();
	}

	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}
		selectedInvId = element.getAttribute("invId");
		selectedInvNew = element.getAttribute("invNew");
		selectedManId = element.getAttribute("manId");

		previousElement =element;
		
		element.className = "selected";

	}
	
	function closeManifest() {
		if(selectedInvId)
            cbs_confirm("Close selected inventory?", gotoCloseMan)
		else
			cbs_alert("Select a manifest to close.");
	}

	function gotoCloseMan() {
        clearConfirmMsg();
        document.manifestCreate.action = "/mainapp/manifestCreate.asp?useraction=close&inventoryid=" + selectedInvId;
        document.manifestCreate.submit();
	}
	
	function viewManifest() {
		
		if(selectedInvId) {
		    if (selectedInvNew == "True")
			    document.manifestCreate.action = "/mainapp/manifestReview.asp?inventoryid=" + selectedInvId + "&manifestId=" + selectedManId;
			else
			    document.manifestCreate.action = "/mainapp/manifestInventory.asp?inventoryid=" + selectedInvId;
            document.manifestCreate.submit();
		}
		else {
			cbs_alert("Select a manifest to view.");	
		}
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<FORM name="manifestCreate" ID="manifestCreate" METHOD=POST onsubmit="return false" style="margin:0;padding:0">
<H1>Inventory</H1>
<BR><BR>




<DIV style="margin:10px;">
	Create new inventory by
	<SELECT id="cdtype" name="cdtype">
		<OPTION value="DUE">due date</OPTION>
		<OPTION value="CREATE">created date</OPTION>
	</SELECT>
	<INPUT name="cdate" id="cdate" value="<%=Date()%>" style="width:100px;text-align:center" onClick="javascript:show_calendar('manifestCreate.cdate');" readonly />
	<BUTTON onclick="createInventoryManifest()">Begin</BUTTON>
</DIV>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="viewManifest()">View<BR/>Inventory</BUTTON>
		<BUTTON onclick="closeManifest()">Close<BR/>Inventory</BUTTON>
		<BUTTON onclick="viewClassicInventory()">Classic<BR/>Inventory</BUTTON>
		
		
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	





<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH>Inventory#</TH>
		<TH>Description</TH>
	</TR>
	<%
		query = " select inventoryid, manifest.name, manifest.Type type, manifest.manifestId manifestId from inventory "
		query = query & " inner join manifest on inventory.manifestid = manifest.manifestid "
		query = query & " where inventory.[open] = 1 "
		query = query & " order by inventoryid desc"
		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
	%>
	<TR onclick="selectRow(this)" invId="<%=rs("inventoryid")%>" manId='<%=rs("manifestId")%>' invNew='<%=rs("type") = "Inventory"%>'>
		<TD><%=Server.HTMLEncode(rs("inventoryid"))%></TD>
		<TD><%=Server.HTMLEncode(rs("name"))%></TD>
	</TR>
	<%
			rs.movenext
		wend
		set rs = nothing
	%>
</TABLE>


</FORM>
</BODY>
</HTML>
