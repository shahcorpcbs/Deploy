<%@ Language=VBScript %>
<!-- #INCLUDE FILE="../include/AdoConstants.inc" -->
<!--#INCLUDE FILE="../include/loader.asp"-->
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	
	Dim objUpload
	Set objUpload = new Loader
		
	' calling initialize method
	objUpload.Initialize
		
	' File binary data
	Dim FileData
	FileData = " "
	FileData = objUpload.getFileData("Signature")
	
	Dim cn, rs
	set cn = Server.CreateObject("ADODB.Connection.2.6")
	set rs = Server.CreateObject("ADODB.Recordset.2.6")
    
    cn.Open Session("shahcorpDSN")
    rs.CursorLocation = adUseClient
    rs.CursorType = adOpenDynamic
    rs.LockType = adLockBatchOptimistic
    rs.ActiveConnection = cn
    rs.Open "SELECT * from Signature where 1 = 2"
    rs.AddNew
    rs("signatureDate").Value = Now
    rs("signature").AppendChunk filedata
    rs.UpdateBatch
    
    Response.ContentType = "text/html"
    
    dim signatureId
    signatureId = rs.Fields(0).Value
    Response.Write "<HTML><HEAD><TITLE>Signature Saved Successfully</TITLE></HEAD><BODY><FORM>"
    Response.Write "<INPUT TYPE=""hidden"" NAME=""SignatureID"" VALUE=""" & SignatureID & """"& chr(13) & chr(10)
    Response.Write "<INPUT TYPE=""hidden"" NAME=""TotalBytes"" VALUE=""" & Request.TotalBytes & """" & chr(13) & chr(10)
    Response.BinaryWrite FileData
    Response.Write chr(13) & chr(10) & "</FORM><BODY></HTML>"
    Response.Flush
    Response.End
    rs.Close
    cn.Close
    
    Set rs = Nothing
    Set cn = Nothing
%>