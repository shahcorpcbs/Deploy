<%@ Language=VBScript %>
<!-- Added by J.Johnston, 14Feb04 -->
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- End addition, J.Johnston, 14Feb04 -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	'Added by J.Johnston, 14Feb04
	dim strsql
	dim objRs
	dim reportID
	dim ObjMiscSetUp
	dim enableCreditCardProcessing
	
	strsql = "select reportID from ReportDomain where reportName = 'Credit Card Batch Processing'"
	Set objRs = GetDisconnectedRecordset(strSQL)
		
	If objRs.RecordCount > 0 Then
		reportID = objRs("reportID").Value
	end if
	
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & "-Function= Report List. Error while creating the report list."
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if
	
	if Not IsObject(Session("miscSetUp")) then
		initializeMiscSetUp
	end if
	
	set ObjMiscSetUp = Session("miscSetUp")

	If ObjMiscSetUp.Item("creditCardProcessorDescription") <> "None" Then
		enableCreditCardProcessing = "1"
	Else
		enableCreditCardProcessing = "0"
	End If
	'End addition, J.Johnston, 14Feb04
%>

<HTML>
<HEAD>
<TITLE>Account Management</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function applyFinanceCharges(){
		document.accountMgmtForm.action="applyFinanceCharges.asp";
		document.accountMgmtForm.submit();
	}
	function applyPayments(){
		document.accountMgmtForm.action="Customersearch.asp?userAction=applypayments";
		document.accountMgmtForm.submit();
	}
	function runStatements(){
		document.accountMgmtForm.action="runStatements.asp";
		document.accountMgmtForm.submit();
	}
	function issueCreditOrCharge(){
		document.accountMgmtForm.action="Customersearch.asp?userAction=issuecharge";
		document.accountMgmtForm.submit();
	}
	function showVolumeCharge() {
		//document.accountMgmtForm.action="Customersearch.asp?userAction=volumeCharge.asp";
		//document.accountMgmtForm.submit();
	}
	
	function postToQB() {
		document.accountMgmtForm.action="postToQB.asp";
		document.accountMgmtForm.submit();
	}
	
	//Added by J.Johnston, 14Feb04
	function creditCardBatchSubmit()
	{		
		document.accountMgmtForm.action="creditCardBatchList.asp";
		document.accountMgmtForm.submit();	
	}
	
	
	function cancelForm() {
		document.accountMgmtForm.action="managerMenu.asp";
		document.accountMgmtForm.submit();
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Account Management</H1>
<FORM id="accountMgmtForm" name="accountMgmtForm"  method="Post">
	<INPUT TYPE=hidden NAME="reportID" value="<%= reportID%>">

	<TABLE ALIGN=center WIDTH="350px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR height=50px></TR>	
		<TR>
			<TD align=center>
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" id=payments name=payments onClick="applyPayments()">Apply Payments</button>
				<!--<INPUT class=touch id=payments name=payments type=button value="" style="background-image:url(../images/Add-Money-2.gif)" onClick="applyPayments()"><br>Apply Payments-->
			</TD>
			<TD align=center>
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" id=financeCharges name=financeCharges onClick="applyFinanceCharges()">Apply Finance Charges</button>
				<!--<INPUT class=touch id=financeCharges name=financeCharges type=button value="" style="background-image:url(../images/Add-Charge-2.gif)" onClick="applyFinanceCharges()"><br>Apply Finance Charges-->
			</TD>
		</TR>
		<TR height=20px></TR>	
		<TR>
			<TD align=center>
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" id=creditOrCharge name=creditOrCharge onClick="issueCreditOrCharge()">Issue Credit or Charge</button>
				<!--<INPUT class=touch id=creditOrCharge name=creditOrCharge type=button value="" style="background-image:url(../images/CreditCard.gif)"  onClick="issueCreditOrCharge()"><br>Issue Credit or Charge-->
			</TD>
			<TD align=center>
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" id=statements name=statements onClick="runStatements()">Run Statements</button>
				<!--<INPUT class=touch id=statements name=statements type=button value="" style="background-image:url(../images/Report-Money.gif);" onClick="runStatements()"><br>Run Statements-->
			</TD>
		</TR>
		<TR height=20px></TR>	
		<!-- MWiemann 11/4/2003 Added button to post invoices to QB -->
		<TR>
			<!--<TD align=center>
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" id=postQB name=postQB onClick="postToQB()"><img src=""><br>Post Accounts Receivable<br>Invoices to Quickbooks</button>
			</TD> -->
			<!-- Button added by J.Johnston, 14Feb04 -->
			<% If enableCreditCardProcessing = "1" Then %>
			<TD align=center colspan="2">
				<BUTTON class=std style="width:200px;height:100px;font-size:12px" id=ccBatch name=ccBatch onClick="creditCardBatchSubmit()">Credit Card Batch Processing<br></button>
			</TD>
			<%	end if%>
		</TR>
		<TR>
			<TD align=center>
				<!--<INPUT class=touch id=volumeCharge  name=volumeCharge type=button value="" onClick="showVolumeCharge()"><br>Volume Charge-->
			</TD>
		</TR>
		<TR ></TR>
		<tr height=100px>
			<td colspan=2 align="center">
				<INPUT class=touchnoborder id=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" name=cancel onClick="cancelForm()">
			</td>
		</tr>
	</TABLE>
</FORM>   

</BODY>
</HTML>
