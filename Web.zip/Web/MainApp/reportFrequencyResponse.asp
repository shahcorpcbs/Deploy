<%@ Language=VBScript %>

<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="CheckSessionExpiry.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	
	Session("objRP").scheduleName = Trim(Request.Form("scheduleName"))
	Session("objRP").frequencyType = Trim(Request.Form("frequencyType"))

	Session("objRP").frequencyValue1 = -1
	Session("objRP").frequencyValue2 = -1

	Select Case Session("objRP").frequencyType
	Case "BI"
		Session("objRP").frequencyValue1 = clng(Request.Form("biweeklyDayOfWeek1"))
		Session("objRP").frequencyValue2 = clng(Request.Form("biweeklyDayOfWeek2"))
	Case "MO"
		Session("objRP").frequencyValue1 = clng(Request.Form("monthlyFrequencyValue1"))
		Session("objRP").frequencyValue2 = -1
	Case "SM"
		Session("objRP").frequencyValue1 = clng(Request.Form("semiMonthlyFrequencyValue1"))
		Session("objRP").frequencyValue2 = clng(Request.Form("semiMonthlyFrequencyValue2"))
	Case "WE"
		Session("objRP").frequencyValue1 = clng(Request.Form("weeklyFrequencyValue1"))
		Session("objRP").frequencyValue2 = clng(Request.Form("weeklyFrequencyValue1"))
	End Select

	If Request.Form("autoPrint") = "1" Then
		Session("objRP").outputPrintInd = True
	Else
		Session("objRP").outputPrintInd = False
	End if
	
	If Request.Form("autoEmail") = "1" Then
		Session("objRP").outputEmail = Request.Form("emailAddresses")
	Else
		Session("objRP").outputEmail = ""
	End if

	If Request.Form("autoSaveAs") = "1" Then
		Session("objRP").outputDirectory = Request.Form("saveAsDir")
	Else
		Session("objRP").outputDirectory = ""
	End if

	On Error Resume Next
	
    set objSchedule = CreateObject("CBSReports.clsSchedule")
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & "-Function= Report Schedule. Error while creating Schedule Creation Object (CBSReports.clsSchedule). Please make sure that the latest version of the component (CBSReports.dll) is installed."
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if
	
    Call objSchedule.UpdateSchedule (Session("objRP"))
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & "-Function= Report Schedule. Error while calling Schedule method (clsSchedule.UpdateSchedule())."
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if

%>

<HTML>
<HEAD>

<TITLE>Schedule Response</TITLE>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->

<H1>Schedule Response</H1>

<br><br>

<table>
		<tr>
		<td>
		The Report - <%= Session("objRP").reportName %> - scheduled successfully.
		</td>
		</tr>
		<tr>
		<td>
		&nbsp;
		</td>
		</tr>
		<tr height=35px width=100% >
			<td align=left >
<!--				<INPUT class=touch id=ok name=ok type=button value="" onClick="history.go(-2);"  -->
				<INPUT class=touchnoborder id=ok name=ok type=button value="" onClick="location.href='reportSchedule.asp?reportID=<%=Session("objRP").reportNumber%>&reportName=<%= Server.URLEncode (Session("objRP").reportName) %>';" 
					style="background-image:url(../images/Ok.gif);">
			</td>
		</tr>
</table>


</BODY>
</HTML>
