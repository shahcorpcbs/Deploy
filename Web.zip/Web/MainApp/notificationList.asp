<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%

	dim query, rs

%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">
	var previousElement = null;
	var selectedNotification = null;

	function editNotification() {
		if(selectedNotification != null)
		{
		    document.notificationList.action = "notificationSetup.asp?notificationId=" + selectedNotification;
		    document.notificationList.submit();
		}
		else
		{
			cbs_alert("Select a notification from the list.");	
		}
	}
	

	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}
		
		selectedNotification = element.getAttribute("notificationId");

		
		previousElement =element;
		
		element.className = "selected";
	}
	
	function exit() {
		document.notificationList.action = "marketingMenu.asp"
		document.notificationList.submit();
	}

</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<H1>Notification List</H1>

<FORM name="notificationList" ID="notificationList" METHOD=POST  style="margin:0;padding:0"> 
<BR>
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="editNotification()">Edit</BUTTON>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR>
		<TH>Name</TH>
		<TH>Description</TH>
		<TH>Status</TH>
	</TR>
	
	<%
		query = "select notificationid, name, description, active from notification "
		set rs = getdisconnectedrecordset(query)

		while not(rs.eof or rs.bof)
	%>		
	<TR onclick="selectRow(this)" notificationId="<%=rs("notificationid")%>">
		<TD><%=server.htmlencode(rs("name"))%></TD>
		<TD><%=server.htmlencode(rs("description"))%>&nbsp;</TD>
		<TD><%if rs("active") then%><span style="color:#0A0">Active</span><%else%><span style="color:red">Disabled</span><%end if%></TD>
	</TR>
	
	<%
			rs.movenext
		wend
		set rs = nothing
	%>

	

</TABLE>

</FORM>
</BODY>
</HTML>
