<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<% 
	Dim l_customerseq
	dim l_storeid
	dim isSubmitted 
	dim l_employeeId
	dim l_claimid
	dim l_paymentTypename
	
	l_Customerseq = session("Customersequencenumber")
	l_storeid = session("Storeid")
	isSubmitted = Request.QueryString("Submitted")
	l_employeeId = session("EmployeeId")
	l_claimid = session("ClaimID")

    dim userIPAddress, printerIP, printerName
	getCashDrawerFields()
	
	if isSubmitted then
		updatedatabase()
	end if
	
	GetCustomerinfo



	function getCashDrawerFields()
	    dim query, rs

	    printerIP = getPrinterShortPath()

        query = " select storehardware.cashdrawertype, isnull(printer.printername, '') as printername "
        query = query & " from storehardware "
        query = query & " left outer join printer on storehardware.cashdrawerattachedprinterid = printer.printerid "
        query = query & " where storehardware.hardwaretype = 'CD' "
        query = query & " and storehardware.terminalid = " & session("terminalid")

        set rs = getdisconnectedrecordset(query)
        if rs.recordcount > 0 then
            printerName = Replace(rs("printername"), "'", "\'")
        end if


        userIPAddress = getLocalPrinterAddress(session("terminalid"))

	end function
%>
<HTML>
<HEAD>
<TITLE>Close Claim</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="/script/cashdrawer.js"></script>
</HEAD>
<script language="javascript" type="text/javascript">
	function closeClaim() {
		
		if	(trim(document.closeClaimForm.txtAmount.value).length < 1 &&
				! document.closeClaimForm.returnType.display == "none" ) {
				cbs_alert("Enter valid amount.");
				document.closeClaimForm.txtAmount.focus();
				return false;
		}
		
		if (document.closeClaimForm.returnType.value == "R" &&
				! document.closeClaimForm.returnType.display == "none" ){
                var url = "http://<%=userIPAddress%><%=printerIP%>/openCashDrawer"
                OpenCashDrawer(url, '<%= printerName %>');
			}
		else if( document.closeClaimForm.returnType.value == "C" &&
				!document.closeClaimForm.returnType.display == "none" && 
				document.closeClaimForm.hpaymentTypename.value != "ON ACCOUNT" ){
				cbs_alert("Customer is not an account holder. Cannot give credit")
				return false;
			}
				
		document.closeClaimForm.action = "?Submitted=true";
		document.closeClaimForm.submit();
			
	}
	
	function putValueInActionText() {
		var index = document.closeClaimForm.actionMenu.selectedIndex;
		var tindex = document.closeClaimForm.returnType.selectedIndex;
		if(index >-1) {
			document.closeClaimForm.txtAction.value = document.closeClaimForm.actionMenu.options[index].text;
			if (document.closeClaimForm.actionMenu.options[index].value == "4"){

				if(bType.style.display != "block" || document.closeClaimForm.returnType.options[tindex].value != "S")
					bAmount.style.display = "block";
				else
					bAmount.style.display = "none";
				bType.style.display = "block";

			}
			else {
				document.closeClaimForm.txtAmount.value = "";
				bAmount.style.display = "none";
				bType.style.display = "none";
			}
		}
	}
	
	function formatAmount(element){
		var temp = cleanNumeric(element.value);
			element.value= autoFormatCurrency(temp)	
	}
	
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0  onLoad = "putValueInActionText()">
<!-- #include file="../include/banner.inc" -->
<H1>Close Claim</H1>
<FORM id="closeClaimForm" name="closeClaimForm" action="" method="Post">
<input type=hidden name=hpaymentTypename value ="<%=l_paymentTypename%>" >


<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=5 align="center">
	<tr valign="top">
		<td>Action:</td>
		<td>
			<select name=actionMenu style="HEIGHT: 25px;font-size:16px; width:175px;" onChange="putValueInActionText()">
				<!-- options need to be retrieved from database -->
				<option value="1">Customer Found</option>
				<option value="2">Store Found</option>
				<option value="3">Returned to Customer</option>
				<option value="4">Paid Out</option>
			</select>
		
		</td>
	</tr>
	<tr valign="top">
		<td>Description:</td>
		<td>
			<TEXTAREA rows=8 name="txtAction" style="width:390px;border:1px inset;background:white;overflow:auto"></TEXTAREA>
		</td>
	</tr>
	
	
	

	<tr id="bType" valign="top" style="display:none">
		<td>Type:</td>
		<td>
			<select id=returnType name=returnType style="HEIGHT: 25px;font-size:16px;width:150px;" onchange="putValueInActionText()" >

					<option value="C">Credit</option>
					<option value="R">Cash</option>
					<option value="S">Sent Check</option>
				
			</select>
		</td>
	</tr>
	<tr id="bAmount" valign="top" style="display:none">
		<td>Amount:</td>
		<td>
			<INPUT id=txtAmount name=txtAmount class=text style="HEIGHT: 25px; WIDTH: 175px"  onKeyup="formatAmount(this)">
		</td>
	</tr>
	<tr style="height:100px">
		<td colspan="2" align="center">
			<INPUT type="button" style="width:100;height:50px" onclick="closeClaim()" value="Close" />
			<INPUT type="button" style="width:100;height:50px" onclick="history.back(-1);" value="Exit" />
		</td>
	</tr>
</table>



</form>
</BODY>
</HTML>

<%

	function GetCustomerinfo()
	dim rstTemp
	dim sqltxt
		
		'sqltxt = "Execute dbo.GetCustomerAccountBalance " &   session("accountCustomerSequenceNumber")
		sqltxt = "select permanentaccount, Temporaryaccount from customer where customersequencenumber = " & l_customerseq
		'Response.Write sqltxt
		set rstTemp = getdisconnectedrecordset(sqltxt)
	
		if rstTemp.recordcount > 0 then
			if rstTemp("permanentaccount") or  rstTemp("Temporaryaccount")  then
				l_paymentTypename = "ON ACCOUNT"
			end if	
		end if
		rsttemp.close
		set rstTemp = nothing	
		
		end function
	
	function UpdateDatabase()
	dim sqltxt
	
	'sqltxt = "update claim set "_
	'		 & "ClaimStatus = " & "'C'" _
	'		 & ",ClaimAction= " & dbcreateQryString(Request.Form("txtAction")) _
	'		 & ",ClaimAmount = " & dbcreateQryNumeric(Request.Form("txtamount")) _
	'		 & ",ClaimPayoutType=" & dbcreateQryString(Request.Form("returntype"))_
	'		 & ",LastUpdatedDate = " & "getdate()" _
	'		 & ",LastUpdatedEmployeeid =" & L_employeeid _
	'		 & " where claimid = " & l_claimid 
	'Response.Write sqltxt
	
	if request.form("actionMenu") = 4 then
		sqltxt = "exec closeclaim " & l_claimid _
					& " ,"  & dbcreateQryString(Request.Form("txtAction"))_
					& " ," & dbcreateQryNumeric(Request.Form("txtamount")) _
					& "," &  dbcreateQryString(Request.Form("returnType"))_
					& "," &  session("terminalid")_
					& "," &  L_employeeid _
					& "," & session("storeid")
	else
		sqltxt = "exec closeclaim " & l_claimid _
					& " ,"  & dbcreateQryString(Request.Form("txtAction"))_
					& " ,NULL" _
					& ",NULL"_
					& "," &  session("terminalid")_
					& "," &  L_employeeid _
					& "," & session("storeid")
	end if

	
	'Response.Write sqltxt			 
	
	dbstartTrans()
	
	QryExecuteWithTrans(sqltxt)
	
	DbEndTrans()
	Response.Redirect("claimorcomments.asp")
	end function

%>
