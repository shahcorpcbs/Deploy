<%@ Language=VBScript %>
<%option explicit%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/json.asp" -->


<%
	dim customerid
	dim firstname
	dim lastname
	dim fullphone
	dim output
	dim json_writer
	dim valid
	dim message
	dim customerseq
	dim useraction
	
	dim query, rs

	valid = true
	message = "ok"

	useraction = trim(request.form("useraction"))
	customerid = request.form("customerid")
	firstname = request.form("firstname")
	fullphone = replace(replace(replace(request.form("fullphone"), "-", ""), ")", ""), "(", "")
	lastname = request.form("lastname")
	customerseq = request.form("customerseq")


		
	query = " select customerid from customer "
	query = query & " where firstname = '" & dbstr(firstname) & "'"
	query = query & " and lastname = '" & dbstr(lastname) & "'"
	query = query & " and isnull(mainareacode, '') + isnull(mainphone, '') = '" & dbstr(fullphone) & "'"
	if customerid <> "" then
		query = query & " and customerid <> '" & customerid & "'"
	end if
	if customerseq <> "" then
		query = query & " and customersequencenumber <> " & customerseq
	end if
	query = query & " and customer.isactive = 1 "


	set rs = getdisconnectedrecordset(query)

	if rs.recordcount > 0 then
		valid = false
		message = "customer already exists"
	end if

	set rs = nothing

	set json_writer = new JSON

	output = "{"
	output = output & json_writer.toJSON("valid", valid, true, null)
	output = output & ", "
	output = output & json_writer.toJSON("message", message, true, null)
	output = output & ", "
	output = output & json_writer.toJSON("useraction", useraction, true, null)
	output = output & "}"


	response.write output
%>