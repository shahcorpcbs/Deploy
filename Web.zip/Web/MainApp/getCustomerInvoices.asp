<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->
<!--#include file="../include/json.asp"-->

<%
	dim query, rs
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if
	
	

	dim customerSeq
	dim ticketStatus

	customerSeq = request.form("customerSeq")
	if customerSeq = "" then
		customerSeq = session("customersequencenumber")
	end if

	ticketStatus = request.querystring("status")
	if ticketStatus = "finished" then
		ticketStatus = "'FI'"
	else
		ticketStatus = "'AC','OD'"
	end if

	query = " select ticket.ticketnumber, ticket.invoicenumber, ticket.ticketstatus, "
	query = query & " dbo.pivotTicketDepartments(ticket.ticketnumber, ', ') as department, "
	query = query & " route.name as routename, "
	query = query & " dbo.pivotTicketRackLocationBrief(ticket.ticketnumber, ', ') as racklocation, "
	query = query & " ticket.createddate as datecreated, "
	query = query & " ticket.duedate as datedue, "
	query = query & " ticket.invoicetotal as total, "
	query = query & " ticket.amountpaid as amountpaid, "
	query = query & " ticket.invoicetotal - ticket.amountpaid as amountdue "
	query = query & " from ticket "
	query = query & " inner join route on ticket.routenumber = route.routenumber "
	query = query & " where ticket.customersequencenumber = " & customerSeq
	query = query & " and ticket.ticketstatus in (" & ticketStatus & ")"
	
	set rs = getdisconnectedrecordset(query)
	
	response.write rsToJSON(rs, limit, start)

	set rs = nothing
%>