<%@ Language=VBScript %>
<% option explicit %>
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp"-->
<!--#include file="../include/services.asp"-->
<!--#include file="../include/messages.asp" -->
<%
sec_RequestAccessNoLog Request.QueryString("useraction")

%>


<%
	dim query, rs
	dim isSubmitted
	dim customerseq
	dim actionString
	dim l_baddress
	dim l_broute
	dim actionmode
	dim l_firstname
	dim l_lastname
	dim l_email
	dim l_mareacode
	dim l_mphone
	dim l_saddress1
	dim l_saddress2
	dim l_saddress3
	dim l_scity
	dim l_sstate
	dim l_szip
	dim l_pricelistid
	dim l_routeid
	dim l_storeid
	dim l_brfirstname
	dim l_brdob
	dim l_brmainphone
	dim l_multiplePickup
	dim l_countersale
	dim sqltxt
	dim heatSealNos
	dim enforcePrepay
	dim onSuspend
	dim dontPromptForPrepay
	dim historyyear
	dim hasCCOnFile
	dim allowNoRackPickup
	dim promptToPrintAfterPrepay
	dim promptTagsAfterEdit
	dim allEditOnLot

	if historyyear = "" then historyyear = "last365"

	l_storeid= session("Storeid")

	'********************************************
	' for printing invoice
	' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' July 17th		Poonam			Printing Invoice
	'******************************************
	dim ticketNo
	dim addOrEdit
	dim invoiceType
	dim pickUpInvoices
	dim custFullName
	dim totalchangedue
	dim promptAfterTicketCreation
	dim promptAfterTagPrinting
	dim hideRackLocation
	dim promptForClaimReceipt
	dim autoPickup
	dim printRackSlipOnPickup
	dim pagenum
	dim showPrintButtons
	dim promptToScanOrders
	dim promptCreditLimit
	dim existingInvoice
	dim canSms, canEmail
	dim custCellPhone, l_notificationsSetup
	dim smsInvReceipt, emailInvReceipt, notificationIP, smsPickup, emailPickup, sendChangeAlert, changeNote
	dim leaveCustPage, selectInvScanned
	dim healSealPrinter, canPrintHS
	dim onDemCredit : onDemCredit = 0

	if isobject(session("invoice")) then set existingInvoice = session("invoice")
	set session("invoice") = nothing

	showPrintButtons = getMSVar("printOnHomeScreen")
	allowNoRackPickup = getMSVar("allowNoRackPickup")
	hideRackLocation = getMSVar("hideRackLocation")
	promptToPrintAfterPrepay = getMSVar("promptToPrintAfterPrepay")
	promptForClaimReceipt = getMSVar("promptForClaimInvoice")
	autoPickup = getMSVar("autoPickup")
	printRackSlipOnPickup = getMSVar("printRackSlipOnPickup")
	promptToScanOrders = getMSVar("promptScanOrders")
	dontPromptForPrepay = getMSVar("dontPromptForPrepay")
	enforcePrepay = getMSVar("enforcePrepayAtCustFunctions")
	promptTagsAfterEdit = getMSVar("promptTagsEdit")
    canSms = getMSVar("useTwilio")
    canEmail = getMSVar("useEmail")
    notificationIP = getMessengerShortPath()
    leaveCustPage = getMSVar("leaveCustPage")
    selectInvScanned = getMSVar("selectInvScanned")
	allEditOnLot = getMSVar("canEditOnLot")

	actionString = Request.QueryString("userAction")
	ticketNo = Request.QueryString("ticketNumber")
	addOrEdit = Request.QueryString("addOrEdit")
	invoiceType = Request.QueryString("invoiceType")
	pickUpInvoices = Request.QueryString("pickUp")
	heatSealNos = Request.QueryString("heatSeals")
	historyyear = Request.QueryString("historyyear")
	pagenum = Request.QueryString("pagenum")

	if pagenum = "" then pagenum = Request.Form("pagenum")
	if pagenum = "" then pagenum = 1

	if isnumeric(Request.QueryString("totalchangedue")) then
		dim itemp
			itemp= formatNumber(Request.QueryString("totalchangedue"))
			if itemp > 0 then
                if getMSVar("roundToNickel") then
                    totalchangedue = addPennySaverCoupon(itemp)
                else
				    totalchangedue=formatcurrency(Request.QueryString("totalchangedue"),2)
                end if
			end if
	end if

	customerSeq  = Request.QueryString("customerseq")
	if isnull(customerseq) or customerseq="" or customerseq = 0 then
		customerseq = Session("customerSequencenumber")
	else
		session("showInactiveInvoices") = false
	end if
	Session("customerSequencenumber") = customerSeq

	promptCreditLimit = isCustomerOverCreditLimit(customerSeq)
	dim rsCustomerinfo, accbalance
	sqltxt = "Execute dbo.GetCustomerAccountBalance " & customerseq
	set rsCustomerinfo= getdisconnectedrecordset(sqltxt)
	if rsCustomerinfo.recordcount > 0 then
	    accbalance =formatnumber(rsCustomerInfo("AccountBalance"), 2, -1, 0, 0)
	end if


    dim userIPAddress, printerIP, printerName
	getCashDrawerFields()

	dim showCPPopup
	query = "select cellPhonePopup from Terminal where terminalId = " & Session("terminalID")
	set rs = getdisconnectedrecordset(query)
	showCPPopup = rs("cellPhonePopup")

    if showCPPopup then
            query = "select (case when exists  (select 1 from CustomerMessageSetup where customerId = " & customerseq _
                & ") then count(*) else -1 end) cnt from CustomerMessageSetup cms, QueryAlert qa where cms.sms = 1 and customerId = " & customerseq _
                & " and qa.Id = cms.queryId and qa.triggerType != 0 and qa.Id != -10"
            set rs = getdisconnectedrecordset(query)
            if rs("cnt") = -1 then
            query = "select count(*) cnt from CustomerMessageSetup cms, QueryAlert qa where cms.sms = 1 and customerId = 0" _
            & " and qa.Id = cms.queryId and qa.triggerType != 0 and qa.Id != -10"
        set rs = getdisconnectedrecordset(query)
        end if
        l_notificationsSetup = rs("cnt")
	end if
	getReceiptOptions()
	sendInvChgAlert()
	checkHSOption()


	if actionString = "print" AND invoiceType = "D" AND (addOrEdit = "add" OR addOrEdit = "edit") then
		PreformPostInsertTicketActions
	end if

	select case actionString
		case "toggleActiveInvoices"
			session("showInactiveInvoices") = not session("showInactiveInvoices")
			historyyear = "last365"
		case "pickup"
			pickupSelectedInvoices "pickup", autoPickup
		case "prepay"
			pickupSelectedInvoices "prepay", autoPickup
		case "changeroute"
			changeInvoiceRoute Request.QueryString("routeid")
		case "suspend"
			suspendCustomer
		case "unsuspend"
			unsuspendCustomer
		case "scheduledropoff"
			scheduleDropoff
		case "cashout"
			cashOutOverpay
		case "fromLoyalty"
			fromLoyalty
	end select

	GetCustomerInfo()

	function addPennySaverCoupon(itemp)
	    'on error resume next
        dim changedAmt, totalchangedue, ticketNumber, empId, query, rs, paymentNum
        empId = Session("employeeID")
        itemp = itemp * -100    'Classic asp has a Floor function, but not a Ceil, but if we negative it, Floor will round up and then switch it back to pos
        itemp = Floor(itemp / 5 ) * -5
        itemp = itemp / 100
        totalchangedue=formatcurrency(itemp,2)

        changedAmt = itemp - formatNumber(Request.QueryString("totalchangedue"))
        if changedAmt > 0 then
            ticketNumber = split(Request.QueryString("ticketNumber"), ",")(0)

            query = "select max(lineItemNumber) maxLineNum, max(displaySequence) maxDispSeq, departmentId, departmentName " _
                & "from TicketLineItem where ticketNumber = " & ticketNumber & " group by departmentId, departmentName"
            rs = getDisconnectedRecordset(query)

            query = "insert into TicketLineItem (TicketNumber, lineItemNumber, createdByEmployeeId, lastModifiedByEmployeeId, " _
                & "parentLineNumber, displaySequence, departmentId, departmentName, ticketLineType, lineItemId, lineItemName, " _
                & "quantity, lineItemTotal, packagedQuantity, originalUnitPrice, unitprice, totalTaxPercent, totalSurchargePercent, lineItemTaxableAmount) values (" & ticketNumber & ", " & rs("maxLineNum") + 1 & ", " _
                & empId & ", " & empId & ", -1, " & rs("maxDispSeq") + 1 & ", " & rs("departmentId") & ", '" & rs("departmentName") _
                & "', 'CU', -1, 'Penny Saver', 1, " & changedAmt & ", 1, 0, 0, 0, 0, 0)"
            qryexecute query

            query = "insert into ticketLogItem (ticketNumber, logdate, logType, quantity, deptName, itemName, amount) values (" _
                & ticketNumber & ", current_timestamp, 'A', 1, 'Coupon', 'Penny Saver', " & -1 * changedAmt & ")"
            qryexecute query

            query = "update ticket set invoiceTotal = invoiceTotal - " & changedAmt & ", amountPaid = amountPaid - " & changedAmt _
                & ", totalVIPAmount = totalVIPAmount - " & changedAmt & ", totalCouponAmount = totalCouponAmount + " & changedAmt _
                & " where ticketNumber = " & ticketNumber
            qryexecute query

            query = "update ticketevent set invoiceTotal = invoiceTotal - " & changedAmt & ", amountPaid = amountPaid - " & changedAmt _
                & " where ticketNumber = " & ticketNumber & " and type = 'PAYMENT'"
            qryexecute query

            query = "select top 1 paymentNumber from payment where customerSequenceNumber = " & Session("customersequencenumber") _
                & " and paymentTypeName = 'Cash' order by paymentNumber desc"
            rs = getDisconnectedRecordset(query)
            paymentNum = rs ("paymentNumber")

            query = "update payment set amountPaid = amountPaid - " & changedAmt & " where paymentNumber = " & paymentNum
            qryexecute query

            query = "update PaymentTracking set amountApplied = amountApplied - " & changedAmt & " where sourceRefNumber = " & paymentNum
            qryexecute query

        end if

        addPennySaverCoupon = totalchangedue
	end function

    function getReceiptOptions()
        dim result
        result = isMessageEnabledForCustomer(-9, Session("customerSequenceNumber"))
        if result <> "" then
            smsInvReceipt = (Mid(result, 1, 1) = 1)
            emailInvReceipt = (Mid(result, 2, 1) = 1)
        end if

        result = isMessageEnabledForCustomer(-12, Session("customerSequenceNumber"))
        if result <> "" then
            smsPickup = (Mid(result, 1, 1) = 1)
            emailPickup = (Mid(result, 2, 1) = 1)
        end if
    end function

    function sendInvChgAlert()
        dim result, query, rs, smsMessageId
        if session("amountChanged") = 1 and isMessengerEnabled then
            result = isMessageEnabledForCustomer(-17, Session("customerSequenceNumber"))
            if result <> "" then
                if InStr(result, "1") then
                    sendChangeAlert = true
                    query = "select smsMessageId from QueryAlert where Id = -17"
                    set rs = getdisconnectedrecordset(query)
                    smsMessageId = rs("smsMessageId")
                    query = "select message from SmsMessage where Id = " & smsMessageId
                    set rs = getdisconnectedrecordset(query)
                    if InStr(rs("message"), "{employeeNote}") then
                        changeNote = true
                    end if
                end if
            end if
            session("amountChanged") = 0
        end if

    end function


	function addLoyalty()
		dim ssql
		dim objRst
		dim loyEnabled
		dim validDays
		dim expDate
		dim ssql1
		dim loyaltyId
		dim cardno
		dim price
		dim taxCode
		dim priceListID
		dim deptId
		dim taxPercent
		dim taxDesc

		cardno = session("loyaltycardnumber")
		loyaltyId = session("loyaltyid")

		ssql = "select * from loyalty where loyaltyId = " & loyaltyId
		set objRst = getDisconnectedRecordSet(ssql)
		loyEnabled = objRst.fields("enabled")
		if loyEnabled then
			loyEnabled = 1
		else
			loyEnabled = 0
		end if
		validDays = objRst.fields("validDays")
		price = objRst.fields("price")
		taxCode = objRst.fields("taxCode")
		priceListId = objRst.fields("priceListId")
		deptId = objRst.fields("departmentId")

		ssql = "select * from loyaltycustomer where customersequencenumber = " & customerseq & " and loyaltyid = " & loyaltyid
		set objRst = getDisconnectedRecordset(ssql)
		if objRst.recordcount > 0 then
			Session("errorMessage") = "Customer has already purchased this loyalty program.  Please go back and choose another program."
			Response.Redirect "ErrorMessages.asp"
		end if

		ssql = "INSERT into LOYALTYCUSTOMER(customersequencenumber, loyaltyId, loyaltyCardId, enabled, expirationDate)" _
			& " VALUES(" & customerseq & "," & loyaltyId & ",'" & cardNo & "'," & loyEnabled & ", getDate()+" & validDays & ")"
		QryExecute(ssql)
		ssql = "INSERT into LOYALTYCUSTOMEROFFERS select lc.customersequencenumber, d.discountid, d.noofuses " _
			& "FROM DISCOUNT D, LOYALTYDISCOUNT LD, LOYALTYCUSTOMER LC " _
			& "WHERE D.DISCOUNTID = LD.DISCOUNTID AND LC.LOYALTYID = LD.LOYALTYID AND LC.CUSTOMERSEQUENCENUMBER = " _
			& customerseq & " AND LD.LOYALTYID = " & loyaltyId
		QryExecute(ssql)

		if not (isEmpty(taxCode) or isnull(taxCode)) then
			ssql = "select * from tax where taxCode = " & taxCode & " and storeid = " & storeid
			set objRst = getDisconnectedRecordSet(ssql)
			taxPercent = objRst.Fields("taxPercent").value
			taxDesc = objRst.Fields("description").value
		else
			taxPercent = 0
			taxDesc = ""
		end if
	end function

	sub saveInvoiceToDatabase()
		dim empId
		dim terminalId
		dim empName
		dim storeName
		dim invNumber
		dim transactionchangedue
		dim invoice
		dim pickupObj

		set invoice = existingInvoice

		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")

		invoice.saveInvoice "add", empId, terminalId, 0, empName, storeName, true


		set pickupObj = session("pickupObj")
		pickupObj.applyPayments empId, terminalId, "'" & invoice.getTicketNosForPrinting() & "'" , -1
		'transactionchangedue = pickupObj.getChangeDue()
	end sub


	function fromLoyalty()
		dim paid
		dim invoice

		set invoice = existingInvoice

		paid = Request.QueryString("paid")

		if paid = "true" then
			saveInvoiceToDatabase
			addLoyalty
		else
			invoice.cancelDoneOperation
		end if
	end function

	function isCustomerOverCreditLimit(customerSeq)
		dim query, rs

		isCustomerOverCreditLimit = false

		if customerSeq <> "" then
			query = " select isnull(creditLimit, 0) - dbo.getAccountBalance(" & customerSeq & ", null) as remainingCredit "
			query = query & " from customer where customersequencenumber = " & customerSeq

			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				isCustomerOverCreditLimit = cdbl(rs("remainingCredit")) < 0
			end if

			set rs = nothing

		end if

	end function

	function scheduleDropoff()
		response.redirect "scheduleDeliveryDropoff.asp?originPage=customerfunctions&customerSequenceNumber=" & customerseq & "&ticketNumber=" & request.querystring("Ticketnumber")
	end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

	function CustomerSeq2ID(customerseq)
		dim query, rs

		query = "select customerid from customer where customersequencenumber = " & customerseq
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			CustomerSeq2ID = rs("customerid")
		end if

		set rs = nothing

	end function


	function PreformPostInsertTicketActions()
		dim query, rs
		dim ticketNos
		dim ticketNumber

		ticketNos = split(ticketNo, ",")

		for each ticketNumber in ticketNos
			query = "exec dbo.UpdateDailyStats " & ticketNumber & ",'" & addOrEdit & "'"
			qryexecute query

			query = "exec dbo.PreformPostInsertTicketActions " & ticketNumber
			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				promptAfterTicketCreation = promptAfterTicketCreation & rs("PromptAfterTicketInsertion") & ","
				promptAfterTagPrinting = promptAfterTagPrinting & rs("PromptAfterTagsPrint") & ","
			end if
		next
	end function

	function ReleaseFormCount(TicketNumber)
		dim query, rs
		dim tnums
		dim tnum

		ReleaseFormCount = 0

		tnums = split(TicketNumber, ",")
		for each tnum in tnums
			query = "GetReleaseForTicket " & tnum
			set rs = getdisconnectedrecordset(query)
			ReleaseFormCount = ReleaseFormCount + rs.recordcount
			set rs = nothing
		next

	end function

	function isHeatSealDept(TicketNumber)
		dim query, rs
		dim tnums
		dim tnum

		isHeatSealDept = true

		tnums = split(TicketNumber, ",")
		for each tnum in tnums
			query = "isHeatSealDept " & tnum
			set rs = getdisconnectedrecordset(query)
			isHeatSealDept = isHeatSealDept and rs("Result")
			set rs = nothing
		next

     end function


    function checkHSOption()
        dim query, rs, useHeatSeal
        canPrintHS = false
        useHeatSeal = getMSVar("useHeatSeal")
        if useHeatSeal then
            query = "select printerName from Printer where printerType = 'Heat Seal'"
            set rs = getdisconnectedrecordset(query)
            If rs.RecordCount > 0 Then
                canPrintHS = true
                healSealPrinter = rs("printerName")
            end if
        end if
    end function

	function getStoreGUID()
		dim query, rs

		query = "select guid from store where storeid = " & Session("storeid")
		set rs = getdisconnectedrecordset(query)

		getStoreGUID = rs("guid")

		set rs = nothing
	end function


	function GetPickupSchedule(customerseq)
		dim query, rs

		query = "select convert(varchar, scheduledDate, 101) as scheduledDate from deliverywillcall where actionrequired = 'PICKUP' and status = 0 and deliveryid is null and customerSequenceNumber = " & customerSeq
		set rs = getdisconnectedrecordset(query)

		set GetPickupSchedule = rs
	end function

	function getRouteVersion(storeid)
		dim query, rs

		query = " select routeVersion from miscsetup where storeid = " & storeid

		set rs = getdisconnectedrecordset(query)

		getRouteVersion = rs("routeVersion")

		set rs = nothing
	end function

	function getCashDrawerFields()
	    dim query, rs

	    printerIP = getPrinterShortPath()

        query = " select storehardware.cashdrawertype, isnull(printer.printername, '') as printername "
        query = query & " from storehardware "
        query = query & " left outer join printer on storehardware.cashdrawerattachedprinterid = printer.printerid "
        query = query & " where storehardware.hardwaretype = 'CD' "
        query = query & " and storehardware.terminalid = " & session("terminalid")

        set rs = getdisconnectedrecordset(query)
        if rs.recordcount > 0 then
            printerName = Replace(rs("printername"), "'", "\'")
        end if


        userIPAddress = getLocalPrinterAddress(session("terminalid"))

	end function

%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD>
<TITLE>Customer Functions</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
<link href="../style/overlay.css" rel="stylesheet" type="text/css">

<STYLE  type="text/css" >
  .highlightScanned {
    background: #FFCC99;
  }
  .highlightScannedPartial {
    background: silver;
  }
</STYLE>



</HEAD>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript" src="/Script/printing.js"></script>
<script language="javascript" type="text/javascript" src="/script/cashdrawer.js"></script>
<SCRIPT type="text/javascript">
  var keyboardInput = "";
	var lastKeyPressTime = null;

	function printBagTagForCustomer() {
		PrintBagTag(<%=customerseq%>);
	}


	function showEditCustomer() {
		if (validateRequiredFields()) {
			document.customerFunctions.action = "\CustomerEntry.asp?mode=edit";
			document.customerFunctions.submit();
		}
	}
	function showClaimOrComments() {
		if (validateRequiredFields()){
			document.customerFunctions.action = "\claimOrComments.asp";
			document.customerFunctions.submit();
		}
	}
	function showCRM() {
		if (validateRequiredFields()){
			document.customerFunctions.action = "\customerManagement.asp";
			document.customerFunctions.submit();
		}
	}

	function showAccountHistory() {
		if (validateRequiredFields()) {
			document.customerFunctions.action = "\accountHistory.asp?customerseq=<%=customerseq%>";
			document.customerFunctions.submit();
		}
	}
	function showSmsHistory() {
		if (validateRequiredFields()) {
			document.customerFunctions.action = "\smsHistory.asp?customerseq=<%=customerseq%>";
			document.customerFunctions.submit();
		}
	}
	function showEmailHistory() {
		if (validateRequiredFields()) {
			document.customerFunctions.action = "\emailHistory.asp?customerseq=<%=customerseq%>";
			document.customerFunctions.submit();
		}
	}
	function showMiscCharges() {
		if (validateRequiredFields()) {
			document.customerFunctions.action = "\editMiscCharge.asp";
			document.customerFunctions.submit();
		}
	}

	function createDetailedInvoice() {
        clearConfirmMsg();
		if (validateRequiredFields()){
			document.customerFunctions.action  = "detailedInvoice.asp?userAction=create&multiplePickup=" +
			document.customerFunctions.bmultiplepickup.value + "&screenWidth=" + screen.width +
                "&screenHeight=" + screen.height;
			document.customerFunctions.submit();
		}
	}
	function purchaseLoyaltyProgram() {
		if (validateRequiredFields() ) {
			document.customerFunctions.action = "\purchaseLoyalty.asp";
			document.customerFunctions.submit();
		}
	}
	function purchaseGiftCard() {
		if (validateRequiredFields() ) {
			document.customerFunctions.action = "/mainapp/giftCards.asp?customerseq=<%=customerseq%>";
			document.customerFunctions.submit();
		}
	}

	function createQuickInvoice() {
		if 	(validateRequiredFields()){
			document.customerFunctions.action = "\quickInvoice.asp?userAction=create";
			document.customerFunctions.submit();
		}
	}

	function viewInvoiceDetails() {
		var lastInvoice;
		var lineVars;
		var il = document.customerFunctions;
		var len = il.elements.length;
		var i, e;

		invoiceCount = 0;

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkInvoice" && e.checked) {
					lineVars = e.value.split(",");
					lastInvoice = lineVars[0];
					++invoiceCount;
		    }
		}

		if(invoiceCount > 1) {
			cbs_alert("Can only view details on a single invoice (" + invoiceCount + " selected).")
		}
		else if(invoiceCount == 1) {
				document.customerFunctions.action = "invoiceDetails.asp?userAction=edit&Ticketnumber=" +  lastInvoice;
				document.customerFunctions.submit();
		}
		else {
			cbs_alert("Must select an invoice before performing action.");
		}
	}



	function editSelectedInvoice() {
		var lastInvoice;
		var lastMultipickup;
		var invoiceCount;
		var lineVars;
		var lotID;
		var il = document.customerFunctions;
		var len = il.elements.length;
		var i, e;

		invoiceCount = 0;

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkInvoice" && e.checked) {
				lineVars = e.value.split(",");
				lastInvoice = lineVars[0];
				lastMultipickup = lineVars[1];
				lotID = lineVars[7];
				++invoiceCount;
		    }
		}

		if(invoiceCount > 1) {
			cbs_alert("Can only edit a single invoice (" + invoiceCount + " selected).")
		}
		<% if allEditOnLot = 0 then %>
		else if (lotID != null && lotID != 0) {
		    cbs_alert("Cannot edit invoice after it is placed on a lot");
		}
		<% end if %>
		else if(invoiceCount == 1) {
				document.customerFunctions.action = "detailedinvoice.asp?userAction=edit&Ticketnumber=" +  lastInvoice +
				    "&multiplePickup=" + lastMultipickup + "&originPage=customerfunctions&screenWidth=" + screen.width +
				    "&screenHeight=" + screen.height;
				document.customerFunctions.submit();
		}
		else {
			cbs_alert("Must select an invoice before performing action.");
		}
	}

	function schedulePickup() {
			document.customerFunctions.action = "scheduleDeliveryPickup.asp?originPage=customerfunctions&customerSequenceNumber=<%=customerseq%>";
			document.customerFunctions.submit();
	}


		var allScanned;
		var pickupInvoices;
		var pickupInvoiceNumbers;

	function selectedInvoicesPreform(action) {
		var lineVars;
		var il = document.customerFunctions;
		var len = il.elements.length;
		var i, e;
		var count;
    	var claimReceipt;
    	var partialInvoices;
		var invoiceBalance;
		var changeDue = 0;

		pickupInvoiceNumbers = "";
		pickupInvoices = "";
		count = 0;
		allScanned = true;
    	partialInvoices = "";

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkInvoice" && e.checked) {
  		        allScanned = allScanned && (e.getAttribute("scanned") == 1);
				lineVars = e.value.split(",");
				invoiceBalance = parseFloat(e.getAttribute("invoiceBalance"));

				if(action == 'pickup') {
					if(document.customerFunctions.allowNoRackPickup.value == "False") {
						if(lineVars[4] == 0) {
							cbs_alert("Invoice must be racked before pickup.")
							return false;
						}
					}
					else {
						if(lineVars[5] == 1) {
							cbs_alert("Invoices on hold can not be picked up.")
							return false;
						}
						else if(lineVars[6] > 0) {
							cbs_alert("Items exist in the invoice that must be priced before pickup.")
							return false;
						}
					}
				}

				if(action == 'cashout') {
					if(invoiceBalance < 0) {
						changeDue += -invoiceBalance;
					}
				}

                if(lineVars[3] != "q" && (action != 'prepay' || invoiceBalance > 0))
                {
	                if(pickupInvoiceNumbers != "") pickupInvoiceNumbers += ",";
	                pickupInvoiceNumbers += e.getAttribute("invoiceNumber");

				    if(pickupInvoices != "")
				    	pickupInvoices = pickupInvoices + ",";

				    pickupInvoices = pickupInvoices + lineVars[0];

				    if(partialInvoices != "")
				    	partialInvoices = partialInvoices + ",";

				    partialInvoices = partialInvoices + e.getAttribute("partial");


				    ++count;
				}
				else if(lineVars[3] == "q" && (action == 'pickup' || action == 'prepay'))
				{
					cbs_alert("Can not pick up or prepay quick invoices.");
					return false;
				}
		    }
		}

		if(action == 'split' && count > 0) {
			if(count > 1) {
				cbs_alert(count + ' invoices selected.  Please select one invoice to be split.');
				return false;
			}
			document.customerFunctions.action = "splitInvoice.asp?ticketnumber=" + pickupInvoices;
			document.customerFunctions.submit();
			return;
		}
		else if(action == 'cashout' && changeDue > 0) {
             showChangeDue('$' + parseMoney(changeDue))
			document.customerFunctions.action = "?userAction=cashout&ticketnumber=" + pickupInvoices;
			document.customerFunctions.submit();
		}
		else if(action !== 'cashout' && count > 0) {
            var asked = false;
			if(count > 30) {
				cbs_alert(count + ' invoices selected.  Only 30 or fewer invoices can be picked up or prepaid at once.');
				return false;
			}
			if(action == 'pickup') {

				switch (document.customerFunctions.promptForClaimReceipt.value) {
					case "0": case "False":
						claimReceipt = false;
						break;
					case "1": case "True":
					    asked = true;
						cbs_confirm("Does customer have a claim receipt?", finishPromptTrue, finishPromptFalse);
						break;
					case "2":
						claimReceipt = !allScanned;
						break;
					default:
						cbs_alert("Claim receipt case " + document.customerFunctions.promptForClaimReceipt.value + " not handled.")
						break;
				}
				if (!asked)
                    return finishPromptForClaimReceipt(claimReceipt);
			}
			else
				claimReceipt = false;

            if (!asked) {
                document.customerFunctions.action = "?userAction=" + action + "&Ticketnumber=" + pickupInvoices + "&claimreceipt=" + claimReceipt + "&invoicenumbers=" + pickupInvoiceNumbers;
                document.customerFunctions.submit();
			}
		}
		else {
		    cbs_alert("Must select a valid invoice before performing action.");
		}
	}

	function finishPromptTrue() {
	    clearConfirmMsg();
	    finishPromptForClaimReceipt(false);
	}
	function finishPromptFalse() {
	    clearConfirmMsg();
	    finishPromptForClaimReceipt(true);
	}

	function finishPromptForClaimReceipt(claimReceipt) {
        <% if printRackSlipOnPickup then %>
        if(!claimReceipt && !allScanned)
            PrintRackSlip(pickupInvoices);
        <% end if %>

        if(document.customerFunctions.promptToScanOrders.value == 'True' && !allScanned) {
        	cbs_alert('Selected invoices can not be picked up until each is scanned.');
        	return false;
        }
			document.customerFunctions.action = "?userAction=pickup&Ticketnumber=" + pickupInvoices + "&claimreceipt=" + claimReceipt + "&invoicenumbers=" + pickupInvoiceNumbers;
			document.customerFunctions.submit();
	}


	function printSelectedInvoices() {
		var ticketNumbers = getSelectedTicketNumbers();
		if(ticketNumbers == "")
			cbs_alert("Select an invoice before printing.");
		else
		{
		    var options;
		    <% if hideRackLocation then %>
		        options = 'Invoice|Tags|CC Receipt';
		    <% else %>
		        options = 'Invoice|Tags|Rack Slip|CC Receipt';
		    <% end if %>
		    cbs_select('Printing', 1, options, 'handlePrintOption');
		}
	}

    function handleEditSel(selVal) {
        clearOptionMsg();
        if (selVal === 0) {
            document.customerFunctions.action = "\CustomerEntry.asp?mode=edit";
            document.customerFunctions.submit();
        }
    }


	function handlePrintOption(printOption) {
        clearOptionMsg();
            var lineVars;
            var il = document.customerFunctions;
            var len = il.elements.length;
            var i, e;

			switch(printOption) {
			case 0:
				for (i = 0; i < len; i++) {
				    e = il.elements[i];
				    if (e.name == "chkInvoice" && e.checked) {
							CbsPrintForm(CbsForm.Detailed, CbsKey.InvoiceNumber, e.getAttribute("invoiceNumber"));
				    }
				}
				break;
			case 1:
				for (i = 0; i < len; i++) {
				    e = il.elements[i];
				    if (e.name == "chkInvoice" && e.checked) {
						lineVars = e.value.split(",");
						PrintTagsForInvoice(lineVars[0]);
				    }
				}
				break;
			case 2:
				PrintRackSlip(getSelectedTicketNumbers());
				break;
			case 3:
				PrintCCReceipt(getSelectedTicketNumbers());
				break;
			}
	}


	function getSelectedTicketNumbers() {
		var il = document.customerFunctions;
		var len = il.elements.length;
		var i, e;
		var result;

		result = "";

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkInvoice" && e.checked) {
				lineVars = e.value.split(",");
				if(result != "") result += ", ";
				result += lineVars[0];
		    }
		}

		return result;
	}




	function validateRequiredFields(){
		return true;
	}

	function submitForm() {
		cancelForm();
	}

	function cancelForm() {
		document.customerFunctions.action = "customersearch.asp?targetpage=ChangeCustomerFunctions";
		document.customerFunctions.submit();
	}

	function preformOtherAction() {
          cbs_select('Preform Action', 1,'View Details|Cash out excess payment', 'handleOtherOptionChoice');
	}

    function handleOtherOptionChoice(otherAction) {
        clearOptionMsg();
		switch(otherAction) {
		case 0:
			viewInvoiceDetails();
			break;
		case 1:
			selectedInvoicesPreform('cashout');
			break;
		}
    }

	function printInvoice() {
	    clearAnyMsg();
		var custname;
		var actionStr;
		var invType;
		var ticketNumber;
		var addOrEdit;

		custname = document.customerFunctions.customerFullName.value;
		actionStr =document.customerFunctions.actionString.value;
		invType = document.customerFunctions.invoiceType.value;
		ticketNumber = document.customerFunctions.ticketNo.value;
		addOrEdit = document.customerFunctions.addOrEdit.value;

		if (actionStr == "print") {
			switch(invType){
				case "Q" :
				    handlePrintInvoice(ticketNumber, invType);
					break;
				case "D" :
					if(addOrEdit == "add") {
						handlePrintInvoice(ticketNumber, invType);
						PrintReleaseForInvoice(ticketNumber);
						PrintTagsForInvoice(ticketNumber);
						//PrintHeatSealsForInvoice(ticketNumber);
					}
					else {
						PrintEditInvoice(ticketNumber);
						<% if promptTagsAfterEdit then %>
						    cbs_confirm("Print tags?", callPrintTags);
						<% end if %>
					}
					break;
				case "P" :
						PrintPickupInvoice(ticketNumber);
						break;
				case "C" :
						PrintCounterSaleInvoice(ticketNumber);
						break;
			}
		}
	}

	function callPrintTags() {
		clearConfirmMsg();
		var ticketNumber = document.customerFunctions.ticketNo.value;
        PrintTagsForInvoiceNoPrompt(ticketNumber);
	}


	function getHeatSealCount() {
	    clearAnyMsg();
        //PrintHeatSealsForInvoice(document.customerFunctions.ticketNo.value);
		cbs_select('Number of heatseals to print:', 1, '1|2|3|4|5|6|7|8|9|10', 'printHeatSeals');
	}

	function printHeatSeals(count) {
	    clearAnyMsg();
	    count++;    //return is 0 based so need to add 1
		if(count) {
			var name = $('input[name="customerFullName"]').val();

			if(name.length > 18) {
				var first_initial = name.substr(0, 1);
				name = first_initial + ' ' + $('input[name="customerLastName"]').val();
			}

			$.ajax({
				url: 'getHeatSeals.asp',
				data: {n: count},
				dataType: 'json',
				success: function(data) {
					if(data.heat_seals) {
					    var heatSealList = data.heat_seals.join(',');
						var url = "http://<%= getLocalPrinterFullPath(session("terminalid")) %>heatSeals?printerName=" +
						    encodeURIComponent("<%= healSealPrinter %>") + "&custName=" + encodeURIComponent(name.toUpperCase()) +
						    "&heatseals=" + encodeURIComponent(heatSealList);
                        try {
                            $.ajax({
                                type: "POST",
                                url: url,
                                dataType: "text",
                                timeout: "3000",
                                success: function(xhr) {
                                    cbs_alert("Sent heatseal request");
                                },
                                error: function(xhr, ajaxOptions, thrownError) {
                                    cbs_alert("Unable to connect to CBS Printing Service to send heal seal request\nMake sure service is running");
                                }
                            });
                        } catch (exception) {
                            cbs_alert("Unable to send - " + e.message);
                        }
						//parent.LocalPrinter.PrintHeatSeals('Heatseal Printer', name.toUpperCase(), heat_seals);
					}
					else
					    cbs_alert("No valid heat seal ranges set up");
				},
                error: function(xhr, ajaxOptions, thrownError) {
					cbs_alert("Unable to print heat seals\nEnsure valid heat seal ranges are set up");
                    console.log("In error")
                    console.log(xhr);
                    console.log(thrownError);
               }
			});
		}
	}



	function createPDF() {
			var il = document.customerFunctions;
    		var len = il.elements.length;
    		var i, e;
    		var invoices = "";
    		var invoiceCount = 0;

    		for (i = 0; i < len; i++) {
    		    e = il.elements[i];
    		    if (e.name == "chkInvoice" && e.checked) {
    		        if (invoiceCount > 0)
    		            invoices = invoices + ","
    		        invoices = invoices + e.getAttribute("invoiceNumber");
    				++invoiceCount;
    		    }
    		}

    		if (invoiceCount == 0) {
    		    cbs_alert("Must select invoices to download");
    		    return;
    		}
    		PrintPDFInvoice(invoices);
	}

	function sendSMSSelectedInvoices() {
		var il = document.customerFunctions;
		var len = il.elements.length;
		var i, e;
		var invoices = "";
		var invoiceCount = 0;

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkInvoice" && e.checked) {
		        if (invoiceCount > 0)
		            invoices = invoices + ","
		        invoices = invoices + e.getAttribute("invoiceNumber");
				++invoiceCount;
		    }
		}

		if (invoiceCount == 0) {
		    cbs_alert("Must select invoices to send");
		    return;
		}

            var loc = window.location.href;
            var extraCut = 0;
            if (loc.indexOf(":80") != -1)
                extraCut = 5;
            var endStop = loc.indexOf("/mainapp")
            if (endStop == -1)
                endStop = loc.indexOf("/MainApp")

            endStop = endStop - extraCut;
            var ipAddress = loc.substring(0, endStop);
            var url = ipAddress + "<%=notificationIP%>/sendSelectedInvoicesCreatedReceipt?customerSeq=<%=customerSeq%>&invoices=" + invoices;

            //alert(url);
            try {
                $.ajax({
                    type: "POST",
                    url: url,
                    dataType: "text",
                    timeout: "3000",
                    success: function(xhr) {
                        cbs_alert("Invoice(s) Receipt forwarded to Messaging Service");
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        cbs_alert("Unable to connect to CBS Messaging Service to send invoice\nMake sure service is running");
                    }
                });
            } catch (exception) {
                cbs_alert("Unable to send - " + e.message);
            }
	}

	function handlePrintInvoice(ticketNumber, type) {
	    var smsInvReceipt = (String('<%=smsInvReceipt%>').toLowerCase() === "true") && (String('<%=canSms%>').toLowerCase() === "true") && (String('<%=custCellPhone%>').toLowerCase() != "");
	    var emailInvReceipt = (String('<%=emailInvReceipt%>').toLowerCase() === "true") && (String('<%=canEmail%>').toLowerCase() === "true");

	    if (smsInvReceipt || emailInvReceipt) {
	        //alert("Creating ele invoice receipt");
            var loc = window.location.href;
            var extraCut = 0;
            if (loc.indexOf(":80") != -1)
                extraCut = 5;
            var endStop = loc.indexOf("/mainapp")
            if (endStop == -1)
                endStop = loc.indexOf("/MainApp")

            endStop = endStop - extraCut;
            var ipAddress = loc.substring(0, endStop);
            var url = ipAddress + "<%=notificationIP%>/sendInvoicesCreatedReceipt?customerSeq=<%=customerSeq%>";
            //alert(url);
            try {
                $.ajax({
                    type: "POST",
                    url: url,
                    dataType: "text",
                    timeout: "3000",
                    success: function(xhr) {
						cbs_alert("Sent to customer electronically");
						<% if custCellPhone = "" then %>
						    choosePrintType(ticketNumber, type);
						<% else %>
                            choosePrintType(ticketNumber, type, 'electronic');
                        <% end if %>
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        cbs_alert("Unable to connect to CBS Messaging Service to send invoice\nMake sure service is running");
                        choosePrintType(ticketNumber, type);
                    }
                });
            } catch (exception) {
                cbs_alert("Unable to send - " + e.message);
                choosePrintType(ticketNumber, type);
            }
	    }
        else {
	        //alert("Creating physical invoice receipt");
            choosePrintType(ticketNumber, type);
        }
	}

	function choosePrintType(ticketNumber, type, electronic) {
	    if (type === "Q")
	        PrintQuickInvoice(ticketNumber, electronic);
	    else
	        PrintDetailedInvoice(ticketNumber, electronic);
	}


	function PreformPostActions2() {
		var comingFromNewInvoice;
		var addOrEdit;
		var invType;
		var actionStr;
		var dontPromptForPrepay;
		var ticketNumbers;

		ticketNumbers = '<%=ticketNo%>';
		var changedue = document.customerFunctions.changedue.value;
		actionStr =document.customerFunctions.actionString.value;
		addOrEdit = document.customerFunctions.addOrEdit.value;
		invType = document.customerFunctions.invoiceType.value;
		dontPromptForPrepay = document.customerFunctions.dontPromptForPrepay.value;
		comingFromNewInvoice = (actionStr == "print" && invType == "D" && addOrEdit == "add");

		if ( changedue != ""){
			showChangeDue(changedue);
		}

		<% if enforcePrepay = 1 or (enforcePrepay = 2 and hasCCOnFile) then %>
		var ticketNumber;
		if(comingFromNewInvoice) {
		    cbs_confirm("Invoice saved.  Create another?", createDetailedInvoice, nextAction);
		    return false;
		}
		else if(actionStr != "cancel")
		{
			if(CountUnpaidInvoices() > 0) {
				UnCheckAllInvoices();
				CheckAllUnpaidInvoices();
				selectedInvoicesPreform('prepay');
			}
			<% if leaveCustPage = 1 then %>
			else if(ticketNumbers != "" && changedue == "") {
				location.href = 'customersearch.asp';
			}
			<% end if %>
		}

		<% end if %>
		otherFinishPostActions2();
	}

	function nextAction() {
	    clearConfirmMsg();
		var actionStr =document.customerFunctions.actionString.value;
        if(actionStr != "cancel" && CountUnpaidInvoices() > 0) {
            UnCheckAllInvoices();
            CheckAllUnpaidInvoices();
            selectedInvoicesPreform('prepay');
        }
        else
            otherFinishPostActions2();
	}

	function otherFinishPostActions2() {
		<% if leaveCustPage = 1 and InStr(Request.ServerVariables("HTTP_REFERER"), "pickup.asp") <> 0 then %>
		var actionStr = document.customerFunctions.actionString.value;
		var changedue = document.customerFunctions.changedue.value;
		var ticketNumbers = '<%=ticketNo%>';
		if(actionStr != "cancel" && ticketNumbers != "" && changedue == "") {
			location.href = 'customersearch.asp';
		}
		<% end if %>

	    showCustomerAlerts()


		if (document.customerFunctions.pickUpInvoices.value == "1")
		    cbs_confirm("Select all invoices ready to pick up?", checkAndFinish, dontCheck);
		else
            finishPreformPostActions2()
	}

	function dontCheck() {
        clearConfirmMsg();
        finishPreformPostActions2();
	}

	function finishPreformPostActions2() {
		<% if onSuspend then %>
		    disableAllFunctions();
		<% end if %>


		<% if request.querystring("entry") <> "" and selectInvScanned then %>
			selectEntry('<%=replace(replace(request.querystring("entry"), "\", "\\"), "'", "\'")%>', false);
		<% end if %>
	var comingFromNewInvoice = (actionStr == "print" && invType == "D" && addOrEdit == "add");
	var actionStr =document.customerFunctions.actionString.value;
        var dontPromptForPrepay = document.customerFunctions.dontPromptForPrepay.value;

		var custname = document.customerFunctions.customerFullName.value;
		var invType = document.customerFunctions.invoiceType.value;
		var ticketNumber = document.customerFunctions.ticketNo.value;
		var addOrEdit = document.customerFunctions.addOrEdit.value;
		var changedue = document.customerFunctions.changedue.value;
		if(dontPromptForPrepay == "0" && comingFromNewInvoice) {
			selectTicket('<%=request.querystring("ticketnumber")%>', true, '');
            cbs_confirm("Prepay new invoice(s)?", prePayYes, prePayNo);
		}
	}

	function prePayYes() {
        clearConfirmMsg();
		var ticketNumber = document.customerFunctions.ticketNo.value;
		var addOrEdit = document.customerFunctions.addOrEdit.value;
		var changedue = document.customerFunctions.changedue.value;
		var ticketNumbers = '<%=ticketNo%>';
		selectedInvoicesPreform('prepay');
		<% if leaveCustPage = 1 then %>
		if(actionStr != "cancel" && ticketNumbers != "" && changedue == "") {
		    location.href = 'customersearch.asp';
		}
		<% end if %>
	}
    function prePayNo() {
        clearConfirmMsg();
		var ticketNumber = document.customerFunctions.ticketNo.value;
		var addOrEdit = document.customerFunctions.addOrEdit.value;
		var changedue = document.customerFunctions.changedue.value;
		UnCheckAllInvoices();
		<% if leaveCustPage = 1 then %>
		if(actionStr != "cancel" && ticketNumbers != "" && changedue == "") {
		    location.href = 'customersearch.asp';
		}
		<% end if %>
    }


	async function PreformPostActions() {
	<% if sendChangeAlert then %>
	    <% if changeNote then %>
	        cbs_prompt("Do you want to send an alert to the customer that the price of the invoice changed? If so, add note for customer below", sendInvChg, '', true, false, printInvoice)
	    <% else %>
	        cbs_confirm("Do you want to send an alert to the customer that the price of the invoice changed?", sendInvChg, printInvoice)
	    <% end if %>
	<% else %>
		printInvoice();
	<% end if %>

	while (isOtherMsgActive()) {
		await sleep(2000);
	}
	setTimeout("PreformPostActions2()", 700);
	}

	function sendInvChg() {
	    var note = document.getElementById('inputTxtArea').value;
        <% if changeNote then %>
        if (note == "") {
            show_focus("Must include note");
            return;
        }
        <% end if %>
	    clearAnyMsg();
	    var url = "<%= getMessengerFullPath("mainapp") %>/invoiceChanged?customerSeq=<%=customerseq%>&employeeId=<%=Session("EmployeeID")%>" +
	        "&invoiceNum=<%=session("invoicelist")%>&newAmount=" + encodeURIComponent(<%= session("newAmount")%>);
	        <% if changeNote then %>
	        url = url + "&employeeNote=" + encodeURIComponent(note)
	        <% end if %>
            try {
                $.ajax({
                    type: "POST",
                    url: url,
                    dataType: "text",
                    timeout: "3000",
                    success: function(xhr) {
                        cbs_alert("Invoice changed message sent to customer", printInvoice);
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        cbs_alert("Unable to connect to CBS Messaging Service to send message\nMake sure service is running", printInvoice);
                    }
                });
            } catch (exception) {
                cbs_alert("Unable to send - " + e.message, printInvoice);
            }
	}

	function ForcePrepay() {
		var UnpaidInvCnt = CountUnpaidInvoices();

		if(UnpaidInvCnt > 0)
		{
			UnCheckAllInvoices();
			CheckAllUnpaidInvoices();


			<% if dontPromptForPrepay and request.querystring("userAction") <> "cancel" then %>
				selectedInvoicesPreform('prepay');
			<% elseif request.querystring("userAction") = "cancel" or sec_FindPermission("/mainapp/pickup.asp", "cancelprepay", Session("EmployeeID"), false) then %>
                cbs_confirm(UnpaidInvCnt + " invoices are not paid in full.  Do you wish to prepay these?", prepaySelected);
			<% else %>
				selectedInvoicesPreform('prepay');
			<% end if %>

			return true;
		}

		return false;
	}

	function prepaySelected() {
        clearConfirmMsg();
	    selectedInvoicesPreform('prepay');
	}

	function toggleActiveInvoices() {
		document.customerFunctions.action  = "?userAction=toggleActiveInvoices&pagenum=1";
		document.customerFunctions.submit();
	}
	function round(number,X) {
		X = (!X ? 2 : X);
		return Math.round(number*Math.pow(10,X))/Math.pow(10,X);
	}


	function RecalculateNetTotal() {
		var lineVars;
		var il = document.customerFunctions;
		var len = il.elements.length;
		var i, e;
		var netTotal;

		netTotal = 0;

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkInvoice" && e.checked) {
				lineVars = e.value.split(",");
				netTotal += parseFloat(lineVars[2]);
		    }
		}


		document.customerFunctions.netTotal.value = "$" + round(netTotal, 2);

	}

	function SetRowCheckedStatus(row, check, value, scanned) {
		if(!value)
			document.customerFunctions.chkAllInvoices.checked = false

		if(value)
		{
			check.checked = true;
			if(scanned)
			  row.className = "highlightScanned";
			else
			  row.className = "selected";

			check.setAttribute("scanned", (scanned ? 1 : 0));
		}
		else
		{
			ResetPartialScan(row.ticketNumber);
			check.checked = false;
			row.className = "";
			check.scanned = scanned ? 1 : 0;
		}

		RecalculateNetTotal();
	}
	function ResetPartialScan(ticketNumber) {
		$("#partial_" + ticketNumber).val("undefined");
	}


	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "chkInvoice") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked), false);
				break;
			}
			else if (childEl.name == "chkInvoice") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked), false);
				break;
			}
		}
	}

	function SetRowChecked(r, value) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "chkInvoice") {
				SetRowCheckedStatus(r, childEl.children[0], value, false);
				break;
			}
			else if (childEl.name == "chkInvoice") {
				SetRowCheckedStatus(r, childEl, value, false);
				break;
			}
		}
	}

	function CheckAllInvoices() {
		var il = document.customerFunctions;
		var len = il.elements.length;
		var i, e;

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkInvoice") {
				SetRowChecked(e.parentNode.parentNode, true);
		    }
		}
		il.chkAllInvoices.checked = true;
	}

	function checkAndFinish() {
	        clearConfirmMsg();
	        CheckAllRackedInvoices();
	        finishPreformPostActions2();
	}

	function CheckAllRackedInvoices() {
		var il = document.customerFunctions;
		var len = il.elements.length;
		var i, e;

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkIsRacked") {
		    	if(e.value == "1")
						SetRowChecked(e.parentNode.parentNode, true);
					else
						SetRowChecked(e.parentNode.parentNode, false);
		    }


		}
	}

	function CountUnpaidInvoices() {
		var il = document.customerFunctions;
		var len = il.elements.length;
		var i, e;
		var ret;

		ret = 0;

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkIsUnpaid" && e.value == "1") {
				++ret;
		    }
		}
		return ret;
	}

	function CheckAllUnpaidInvoices() {
		var il = document.customerFunctions;
		var len = il.elements.length;
		var i, e;

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkIsUnpaid" && e.value == "1") {
				SetRowChecked(e.parentNode.parentNode, true);
		    }
		}
	}

	function UnCheckAllInvoices() {
		var il = document.customerFunctions;
		var len = il.elements.length;
		var i, e;

		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "chkInvoice") {
				SetRowChecked(e.parentNode.parentNode, false);
		    }
		}
		il.chkAllInvoices.checked = false;
	}

	function ToggleAllInvoices() {
		if(!document.customerFunctions.chkAllInvoices.checked)
			UnCheckAllInvoices();
		else
			CheckAllInvoices();
	}

	function selectInvoiceRoute(routeId) {
		selectedInvoicesPreform('changeroute&routeid=' + routeId);
	}

	function selectHistoryYear(y) {
		document.customerFunctions.action  = "?historyyear=" + y + "&pagenum=1";
		document.customerFunctions.submit();
	}

	function disableAllFunctions() {
		customerFunctions.bttnDetailedInvoice.disabled = true;
		customerFunctions.bttnLoyalty.disabled = true;
		customerFunctions.bttnQuickInvoice.disabled = true;
		customerFunctions.bttnEditCustomer.disabled = true;
		customerFunctions.bttnPrintBagTag.disabled = true;

		customerFunctions.bttnPreformPickup.disabled = true;
		customerFunctions.bttnPreformPrepay.disabled = true;
		customerFunctions.bttnPreformEdit.disabled = true;
		<% if showPrintButtons then %>
		customerFunctions.bttnPreformPrint.disabled = true;
		<% end if %>
		<%if session("showInactiveInvoices") then%>
		customerFunctions.bttnPreformDetails.disabled = true;
		<%end if%>
		customerFunctions.bttnToggleActive.disabled = true;
		<% if getRouteVersion(session("storeid")) = 1 then %>
		customerFunctions.slctInvoiceRoute.disabled = true;
		<% end if %>
	}

	function unsuspendCustomer() {
		document.customerFunctions.action  = "?userAction=unsuspend";
		document.customerFunctions.submit();
	}

	function wndKeyPress() {
		redirectFocus();
	}

	function redirectFocus() {
		var el = document.getElementById("customerFunctions");
		var eventName = "keypress";
		if (el.addEventListener) {
            document.addEventListener("keydown", wndKeyPress, false);
        } else if (el.attachEvent) {
            el.attachEvent("on" + eventName, wndKeyPress);
        } else {
            el["on" + eventName] = wndKeyPress;
        }

        if (document.getElementById('promptBox').style.display != 'block') {
            var el = document.getElementById("keyboardInput");
            el.focus();
		}
	}

	function captureKey(o){
		var scanned;
		var invoiceNumber;
		var currentDate;

		currentDate = new Date();
		if (event.keyCode == 13 && lastKeyPressTime != null) {
			scanned = (currentDate.getTime() - lastKeyPressTime) < (o.toString().length * 30);
			lastKeyPressTime = null;

			selectEntry(o.value, scanned);
			o.value = "";
		}
		else if(lastKeyPressTime == null && o.value.length > 0) {
			lastKeyPressTime = currentDate.getTime();
		}
	}

	function selectEntryResult(result, scanned, number) {
		var missingGarmentsStr = "";

		if(result.LoadBarcode.Success != "0") {
			if(result.LoadBarcode.TicketNumber) {
				selectTicket(result.LoadBarcode.TicketNumber, scanned, missingGarmentsStr);
			}
			else {
				selectInvoice(result.LoadBarcode.InvoiceNumber, scanned);
			}

		}
		else {
			selectInvoice(number, scanned);
		}
	}

	function selectEntry(number, scanned) {
		jQuery.ajaxSetup({cache: false});

		jQuery.ajax({
			type: "GET",
			url: "/script/barcode.json.asp?func=loadbarcode&barcode=" + encodeURIComponent(number),
			async: true,
			dataType: "json",
			success: function(result){
				selectEntryResult(result, scanned, number);
			}
		});
	}


	function selectInvoice(invoiceNumber, scanned) {

		if($("tr[invoiceNumber=" + invoiceNumber + "]").length > 0) {
			$("tr[invoiceNumber=" + invoiceNumber + "]").each(function(i) {
				SetRowCheckedStatus(this, this.children[0].children[0], true, scanned);
			});
		}
		else {
			if(scanned)
				cbs_alert("Invoice " + invoiceNumber + " is not available.");
		}
	}

	function combinePartialStr(existing, addition) {
		var i;
		var result;
		var minLen;
		var nonZero;

		minLen = Math.min(addition.length, existing.length);

		result = "";

		nonZero = false;

		for(i = 0; i < minLen; ++i) {
			if(existing.substr(i, 1) == "1" && addition.substr(i, 1) == "1") {
				nonZero = true;
				result += "1";
			}
			else
				result += "0";
		}

		if(!nonZero)
			result = "";


		return result;
	}

	function selectTicket(ticketNumbers, scanned, partial) {
		//var ticketNumberArr = ticketNumbers.split(',');
		var i;
		var ticketNumber;

		//for(i = 0; i < ticketNumberArr.length; ++i) {
			ticketNumber = ticketNumbers;

			$("tr[ticketNumber=" + ticketNumber + "]").each(function(i) {

				if(this.children[0].children[1].value == "undefined")
					this.children[0].children[1].value = partial;
				else
					this.children[0].children[1].value = combinePartialStr(this.children[0].children[1].value, partial);

				SetRowCheckedStatus(this, this.children[0].children[0], true, scanned);

				if(this.children[0].children[1].value != "")
					this.className = "highlightScannedPartial";
			});
		//}
	}

	function nextPage() {
		document.customerFunctions.action  = "?pagenum=" + (parseInt(document.customerFunctions.pagenum.value) + 1);
		document.customerFunctions.submit();
	}

	function prevPage() {
		document.customerFunctions.action  = "?pagenum=" + (parseInt(document.customerFunctions.pagenum.value) - 1);
		document.customerFunctions.submit();
	}

	function goToPage(pagenumber) {
		document.customerFunctions.action  = "?pagenum=" + pagenumber;
		document.customerFunctions.submit();
	}

	function showCustomerAlerts() {
	<% if promptCreditLimit then %>
		cbs_alert("Customer is over their credit limit.");
	<% end if %>
	<% if Request.QueryString("onDemCredit").Count > 0 and Request.QueryString("onDemCredit") > 0 then %>
	    cbs_alert("Customer received $<%= Request.QueryString("onDemCredit") %> account credit from on demand coupon");
    <% end if %>

	<% if custCellPhone = "" and l_notificationsSetup > 0 then %>
        cbs_select("Customer doesn't have cell phone set but has sms notifications, please add cell phone",
            1, 'Edit Customer|Skip', 'handleEditSel')
	<% end if %>
	}


	function sendSmsMessage() {
            var h = 600;
            var w = 700;
            var y = window.outerHeight / 2 + window.screenY - ( h / 2)
            var x = window.outerWidth / 2 + window.screenX - ( w / 2)
            return window.open(
                "/mainapp/sendSmsMessage.asp?customerseq=<%=customerseq%>",
                webuiResult,
                'status=no,height=' + h + ',width=' + w + ',edge=Sunken,help=No,resizable=No,scroll=no, top=' + y + ', left=' + x);
	}

	function showChangeDue(amt) {
	        var url = "http://<%=userIPAddress%><%=printerIP%>/openCashDrawer"
            OpenCashDrawer(url, '<%= printerName %>');
            document.getElementById("dueMsg").innerHTML = "Change due is " + amt
            document.getElementById('changeDueOL').style.display = 'block';
	}

    function clearChgMsg(elId) {
        if (document.getElementById(elId).style.display != 'none') {
            document.getElementById(elId).style.display = 'none';
            <% if leaveCustPage = 1 then %>
            document.customerFunctions.action = "customersearch.asp";
            document.customerFunctions.submit();
            <% end if %>
        }
    }

</SCRIPT>

<STYLE type="text/css">
#customer-ranking-chart {
	margin-top: 3px;
	margin-right: 100px;
}

#customer-ranking-chart img {
	margin-right: 1px;

}

</STYLE>

<BODY leftmargin=0 topmargin=0 onLoad="PreformPostActions(); redirectFocus();">

<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->

<FORM id="customerFunctions" name=customerFunctions METHOD=POST ACTION="" style="margin:0;padding:0" onsubmit="return false" autocomplete="off">

<input type="hidden" name="functionID" id="functionID" value="">
<input type=hidden name="bbaddress" value="<%=l_baddress%>">
<input type=hidden name="bbroute" value="<%=l_broute%>">
<input type=hidden name="brfirstname" value="<%=l_brfirstname%>">
<input type=hidden name="brdob" value="<%=l_brdob%>">
<input type=hidden name="brmainphone" value="<%=l_brmainphone%>">
<input type=hidden name="brlastphone" value="1">
<input type =hidden name = "bmultiplepickup" value = "<%=l_multiplePickup%>">
<input type=hidden name="customerFullName" value="<%=Server.HTMLEncode(custFullName)%>">
<input type=hidden name="customerLastName" value="<%=Server.HTMLEncode(l_lastname)%>">
<!-- for printing invoice -->
<input type=hidden name="actionString" value="<%= actionString%>">
<input type=hidden name="ticketNo" value="<%= ticketNo%>">
<input type=hidden name="addOrEdit" value="<%= addOrEdit%>">
<input type=hidden name="invoiceType" value="<%= invoiceType%>">
<input type=hidden name="pickUpInvoices" value="<%= pickUpInvoices%>">
<input type=hidden name="heatSeals" value="<%= heatSealNos%>">
<input type=hidden name="changedue" value="<%= totalchangedue%>">
<input type=hidden name="allowNoRackPickup" value="<%= allowNoRackPickup%>">

<input type=hidden name="promptAfterTicketCreation" value="<%= promptAfterTicketCreation%>">
<input type=hidden name="promptAfterTagPrinting" value="<%= promptAfterTagPrinting%>">
<input type=hidden name="promptForClaimReceipt" value="<%= promptForClaimReceipt%>">

<input type=hidden name="promptToScanOrders" value="<%= promptToScanOrders%>">

<input type=hidden name="dontPromptForPrepay" value="<%= dontPromptForPrepay%>">

<div id="changeDueOL" class="overlay" style="display: none; text-align: center">
  <h1 style="color: white" id="dueMsg"></h1>
  <BUTTON id="changeDueOLBtn" style="width: 100px; height: 45px; color: black; vertical-align: top" onclick="clearChgMsg('changeDueOL')">OK</BUTTON>
</div>

<%sec_Log "", "Opened customer functions (" & trim(custFullName) & ")", customerseq%>

<%

	Function Floor(byval n)
		Dim iTmp, bErr

		on error resume next
		n = cdbl(n)
		if err then bErr = true
		on error goto 0

		if bErr then Err.Raise 5000, "Floor Function", _
			"Input must be convertible to a sub-type of double"

		'Round() rounds up
		iTmp = Round(n)

		'test rounded value against the non rounded value
		'if greater, subtract 1
		if iTmp > n then iTmp = iTmp - 1

		Floor = clng(iTmp)
	End Function

	sub CreateCustomerStats()
		dim query, rs
		dim timeperiod
		dim percentile

		query = "select CustomerChartDays from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		timeperiod = rs("CustomerChartDays")

		query = " select dbo.getCustomerVisits(" & customerseq & ", null, null) as visits "

		set rs = getdisconnectedrecordset(query)

		Response.Write "<div style=""background:white;border-bottom:1px solid #DDD;font-size:16;text-align:center;width:100%;height:28px;"">"

		if rs.recordcount > 0 then
			if rs("visits") < 4 then
				Response.Write "<span style=""color:green;float:left;height:22px;margin-top:2px;margin-left:10px;"">New Customer</span>"
			end if
		end if




		percentile = ""

		if timeperiod > 0 then

			query = "exec GetCustomerStats " & customerseq & ", 12"

			set rs = getdisconnectedrecordset(query)



			dim idx
			dim gblock

			gblock = "<img src=""/static/images/customer_rank/no_data.png"" />"

			response.write "<span style=""float: right"" id=""customer-ranking-chart"">"

			for idx = 1 to 12
				if not(rs.eof or rs.bof) then
					if clng(rs("idx")) <= idx then
						percentile = cdbl(rs("percentile"))
						gblock = "<img src=""/static/images/customer_rank/" & floor(percentile * 10) & ".png"" />"
						rs.movenext
					end if
				end if

				response.write gblock
			next

			if percentile <> "" then
				Response.Write "<span style=""height:22px;margin-top:2px;margin-left:10px;"">" & formatnumber(percentile * 100, 1) & "%</span>"

				Response.Write "<span style=""width:100px;text-align:center;"">"

				if percentile > .40 then
					Response.Write "<img src=""/static/icons/16x16/star_yellow.png"">"
					if percentile > .70 then
						Response.Write "<img src=""/static/icons/16x16/star_yellow.png"">"
						if percentile > .80 then
							Response.Write "<img src=""/static/icons/16x16/star_yellow.png"">"
							if percentile > .90 then
								Response.Write "<img src=""/static/icons/16x16/star_yellow.png"">"
								if percentile > .95 then
									Response.Write "<img src=""/static/icons/16x16/star_yellow.png"">"
								end if
							end if
						end if
					end if
				end if

				Response.Write "</span>"
			else
				Response.Write "<span style=""height:22px;margin-top:2px;margin-left:10px;"">No Data</span>"
			end if

			response.write "</span>"
		end if


		Response.Write "</div>"

		set rs = nothing


	end sub

	CreateCustomerStats


%>
	<table width=100% height=688px BORDER=0 CELLSPACING=0 CELLPADDING=0>
		<tr >
			<td>
				<table style="float:left" WIDTH=100% BORDER=0 CELLSPACING=0 CELLPADDING=3  <%if onSuspend then%>style="color:white;background:black"<%end if%>>
					<tr style="font-size:16;">

						<td>
							<div style="font-size:24;text-decoration:<%if onSuspend then%>line-through<%else%>underline<%end if%>"><%=Server.HTMLEncode(l_firstname & " " & l_lastname) %></div>
							<div><%=Server.HTMLEncode(l_email) %></div>
							<div>
								<%if onSuspend then%>
								Customer Suspended
								<%else%>
								Route:<%=l_routeid %>
								<%end if%>
							</div>
						</td>
						<td>
						    <span style="font-size:24">
						    <% if custCellPhone <> "" then %>
						        <img style="height:20px; vertical-align:sub" src="/images/cellphone.png"></img>
						        <% if canSms then %>
						            <a href="#" onclick="sendSmsMessage(); return false;"><% end if %><% end if %><%=Trim(l_mareacode) %>&nbsp;<%=l_mphone %>
						    <% if custCellPhone <> "" and canSms then %>
						        </a>
						    <% end if %>
						    </span><br>
						    <% if custCellPhone <> "" and canSms then %>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<% end if %>
							Price Table:<%=l_pricelistid %>
						</td>

						<td>
							<%=trim(l_saddress1) %><br>
							<%
								Response.write trim(l_scity)
								if len(trim(l_scity)) > 0 then
									Response.Write ", "
								end if
								Response.write trim(l_sstate) & " " & trim(l_szip)
							%>
						</td>
						<%if onSuspend and 	sec_FindPermission("/mainapp/customerfunctions.asp", "suspend", Session("EmployeeID"), false) then %>
						<td width=75px>
						<button style="width:75px;height:50px" onclick="unsuspendCustomer();">Unsuspend</button>
						</td>
						<%end if%>
					</tr>
				</table>
			</td>
		</tr>

		<tr align=center>
			<td>
				<table style="width:100%" border=0>
				<tr align="center">

				<td valign="center" align="center">
				<table border=0>

				<tr align=center>
					<TD>
					<button style="margin-right:25px" class=std name="bttnDetailedInvoice" onClick="createDetailedInvoice()" tabindex=13
					<% if l_countersale then %>
							disabled
					<% end If %>><img src="/static/icons/32x32/invoice.png"><br>Create<br>Detailed Invoice</button>

					<button style="margin-right:25px" class=std name="bttnLoyalty" onClick="purchaseLoyaltyProgram()" tabindex=15><img src="/static/icons/32x32/loyalty.png"><br>Purchase<br>Loyalty Program</button>
					<button style="margin-right:25px; vertical-align: bottom" class=std name="bttnGiftCards" OnClick="purchaseGiftCard()" tabindex=20><img src="/static/icons/32x32/view_text.png"><br>Gift Cards</button>

					<button style="margin-right:25px; vertical-align: bottom" class=std name="bttnAccountHistory"  onClick="showAccountHistory()" tabindex=21
					<% if l_countersale then %>
							disabled
					<% end If %>><img src="/static/icons/32x32/account.png"><br>View Account History</button>
					</TD>
					<TD>
					    <% if canSms then %>
                            <button class=std style="vertical-align: bottom" name="btnSmsHistory"  onClick="showSmsHistory()" tabindex=22>
                            <img src="/static/icons/32x32/account.png"><br>SMS Messages</button>
                        <% end if %>
					</TD>

				</tr>

				<tr align=center>
					<TD>
					<button style="margin-right:25px; vertical-align: top" class=std name="bttnQuickInvoice" onClick="createQuickInvoice()" tabindex=14 <% if l_countersale then %>disabled<% end If %>><img src="/static/icons/32x32/quick_invoice.png"><br>Create Quick Invoice</button>
					<button style="margin-right:25px; vertical-align: top" class=std name="bttnEditCustomer"  onClick="showEditCustomer()" tabindex=19><img src="/static/icons/32x32/customer.png"><br>Edit Customer</button>
					<button style="margin-right:25px; vertical-align: top" <%sec_DWP("printbagtag")%> class=std name="bttnPrintBagTag"  onClick="printBagTagForCustomer()" tabindex=21>
					<img src="/static/icons/32x32/bagtag.png"><br>Print Bag Tag</button>
					<button style="margin-right:25px; vertical-align: top" class=std type="Button" name="bttnCustomerManagement" onClick="showCRM()" tabindex=22
					<% if l_countersale then %>
							disabled
					<% end If %>><img src="/static/icons/32x32/people.png"><br>Customer Management</button>
					</TD>
					<td>
					    <% if canEmail then %>
                            <button class=std onClick="showEmailHistory()" tabindex=22>
                            <img src="/static/icons/32x32/account.png"><br>Email Messages</button>
                        <% end if %>
				    </td>
				</tr>

				</table>
				</td>
				</tr>
				</table>
			</td>
		</tr>




		<tr style="background:#EEE">
			<td>



			</td>
		</tr>

		<tr style="background:#EEE">
			<td>
			  <span style="float:left">
			    <input  id="keyboardInput" style="margin-left: 5px; border: none; background:white; outline:none;" onkeyup="captureKey(this)" />
			  </span>
  		<%if session("showInactiveInvoices") then%>
  				<span style="float:right">
  					<select style="width:100px" onchange="selectHistoryYear(this.value)">
  						<option value="last365" <%if "last365" = trim(historyyear) then%>selected<%end if%>>Year</option>
  						<option value="all" <%if "all" = trim(historyyear) then%>selected<%end if%>>All</option>
  						<%
  							dim yearidx
  							for yearidx = Year(Date()) to Year(Date()) - 10 step -1
  						%>
  						<option value="<%=yearidx%>" <%if trim(yearidx) = trim(historyyear) then%>selected<%end if%>><%=yearidx%></option>
  						<%
  							next
  						%>

  					</select>
  				</span>
      <%elseif getRouteVersion(session("storeid")) = 1 then%>
  				<span style="float:right">
  					<select style="width:150px" onchange="selectInvoiceRoute(this.value)" id="slctInvoiceRoute" name="slctInvoiceRoute">
  					<option value="">Move to route...</option>
  					<%
  						query = "select routeNumber, name from Route where StoreID = " & Session("StoreID")
  						set rs = getdisconnectedrecordset(query)

  						while not (rs.eof or rs.bof)
  					%>
  						<option value="<%=rs("routeNumber")%>"><%=rs("name")%></option>
  					<%
  							rs.movenext
  						wend
  						set rs = nothing
  					%>
  					</select>
  				</span>
  		<%end if%>
			</td>
		</tr>


		<tr style="background:white;height:335px;">
			<td width=100% style="" valign=bottom >
				<div style="height:335px;overflow:auto;margin:0;padding:0;">
				<table  class="itable" BORDER=0 CELLSPACING=0 CELLPADDING=0>

					<%
						dim rstInvoice
						dim pickupSchedule
						dim invStatus
						dim idx

						if session("showInactiveInvoices") then
							invStatus = "'FI', 'VO'"
						else
							invStatus = "'AC', 'OD'"
						end if
						set rstInvoice = GetInvoiceList(customerseq, invStatus)
						set pickupSchedule = GetPickupSchedule(customerseq)





						if rstInvoice.recordcount > 0 then
							if session("showInactiveInvoices") then
								rstInvoice.pagesize = 40
							else
								rstInvoice.pagesize = 10000
							end if

							if clng(pagenum) < 1 then pagenum = 1
							if clng(pagenum) > rstInvoice.pagecount then pagenum = rstInvoice.pagecount
							rstInvoice.absolutepage = pagenum

						end if
					%>


					<tr align=left style="cursor:pointer">
						<th style="width: 3%"><input type=checkbox  id=chkAllInvoices name=chkAllInvoices onclick="ToggleAllInvoices();"></th>
						<th style="text-align:center">&nbsp;</th>
						<th style="">Invoice</th>
					<%if l_multiplePickup = 1 then%>
						<th style="">Pickup Name</th>
						<th style="">Pickup Location</th>
					<%end if%>
						<th style="">Department</th>
						<th style="">Route</th>
					<%if not hideRackLocation then %>
						<th style="">Rack</th>
					<%end if%>
						<th style="">Date Created</th>
					<%if session("showInactiveInvoices") then%>
						<th>Date Out</th>
					<%else%>
						<th>Date Due</th>
					<%end if%>
						<th style="">Total</th>
						<th style="">Due</th>
					</tr>

					<% while not pickupSchedule.eof %>


						<tr style="background:#eee">
							<td></td>
							<td align="left"><img src="/static/icons/24x24/invoice_move.png" /></td>
							<td></td>
						<%if l_multiplePickup = 1 then%>
							<td style="">&nbsp;</td>
							<td style="">&nbsp;</td>
						<%end if%>
						<%if not hideRackLocation then %>
							<td colspan="4">Scheduled Pickup</td>
						<%else%>
							<td colspan="3">Scheduled Pickup</td>
						<%end if%>
							<td><%=pickupSchedule("scheduleddate")%></td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
					<%
							pickupSchedule.movenext
						wend

						set pickupSchedule = nothing

						idx = 0
					%>

					<% while not rstInvoice.eof and idx < rstInvoice.pagesize
							dim invoiceBalance
							invoiceBalance = rstInvoice("nettotal") - rstInvoice("amountpaid")
					%>
						<% if  (rstInvoice("ticketstatus") = "AC" or rstInvoice("ticketstatus") = "OD") and rstInvoice("issplit") and rstInvoice("subLabels") = 0 then
							dim rstSubInvoice
							set rstSubInvoice = GetTicketSplitDetails(rstInvoice("ticketnumber"))



							while not (rstSubInvoice.eof or rstSubInvoice.bof)
							%>
						<tr <%if rstSubInvoice("pickedup") then%>style="color:#f63;"<%end if%> onclick="ToggleRowChecked(this)" id="invoice" ticketNumber="<%=rstInvoice("ticketnumber") %>" invoiceNumber="<%=rstSubInvoice("invoicenumber") %>">
							<td>
								<input  onclick="ToggleRowChecked(this.parentNode.parentNode);" type=checkbox id=chkInvoice name=chkInvoice invoiceBalance="<%=invoiceBalance%>" partial=""  scanned="0" invoiceNumber="<%=rstSubInvoice("invoicenumber") %>" value="<%=rstInvoice("ticketnumber")%>,<%=rstInvoice("ticket_multipickup")%>,<%=round(rstInvoice("nettotal") - rstInvoice("amountpaid"), 2)%>,<%=lcase(rstInvoice("invoicetype"))%>,<%if trim(rstInvoice("racklocation")) = "" then%>0<%else%>1<%end if%>,<%=rstInvoice("onhold")%>,<%=rstInvoice("pricelater")%>,<%=rstInvoice("lotID")%>">
								<input type=hidden id="partial_<%=rstInvoice("ticketnumber")%>" name="partial_<%=rstInvoice("ticketnumber")%>" value="undefined">
								<input type=hidden id=chkIsRacked name=chkIsRacked value="<%if trim(rstInvoice("racklocation")) = "" then%>0<%else%>1<%end if%>">
								<input type=hidden id=chkIsUnpaid name=chkIsUnpaid value="<%if IsInvoiceUnpaid(rstInvoice) then%>1<%else%>0<%end if%>">
							</td>
							<td><%=GetTicketStatusIcons(rstInvoice)%><%=GetPartialInvoiceStatusIcons(rstSubInvoice)%></td>
							<td><%=rstInvoice("invoicenumber") %>:<%=rstSubInvoice("invoicenumber") %> </td>
						<%if l_multiplePickup = 1 then%>
							<td style=""><%=trim(rstInvoice("multiPickupCustomerName")) %></td>
							<td style=""><%=trim(rstInvoice("multiPickupLocation")) %></td>
						<%end if%>
							<td><%=trim(rstInvoice("department")) %> </td>
							<td><%=trim(rstInvoice("routeName")) %> </td>
						<%if not hideRackLocation then %>
							<td><%=trim(rstSubInvoice("racklocation"))%>&nbsp;</td>
						<%end if%>
							<td><%=rstInvoice("datein") %></td>
							<%if session("showInactiveInvoices") then%>
							<td><%=rstInvoice("dateout") %></td>
							<%else%>
							<td><%=rstInvoice("duedate") %></td>
							<%end if%>
							<td>
							<% if not isnull(rstInvoice("nettotal")) then%>
								<%=formatcurrency(rstInvoice("nettotal"), 2)%>
							<%	End if
							%>
							 </td>

							<td><%=formatcurrency(invoiceBalance)%></td>
						</tr>


							<%
								rstSubInvoice.movenext
							wend


						%>


						<% elseif rstInvoice("ticketstatus") <> "OD" then %>

						<tr onclick="ToggleRowChecked(this)" id="invoice" ticketNumber="<%=rstInvoice("ticketnumber") %>" invoiceNumber="<%=rstInvoice("invoicenumber") %>">
							<td>
								<input  onclick="ToggleRowChecked(this.parentNode.parentNode);" type=checkbox id=chkInvoice name=chkInvoice invoiceBalance="<%=invoiceBalance%>" partial=""  scanned="0" invoiceNumber="<%=rstInvoice("invoicenumber") %>" value="<%=rstInvoice("ticketnumber")%>,<%=rstInvoice("ticket_multipickup")%>,<%=round(rstInvoice("nettotal") - rstInvoice("amountpaid"), 2)%>,<%=lcase(rstInvoice("invoicetype"))%>,<%if trim(rstInvoice("racklocation")) = "" then%>0<%else%>1<%end if%>,<%=rstInvoice("onhold")%>,<%=rstInvoice("pricelater")%>,<%=rstInvoice("lotID")%>">
								<input type=hidden id="partial_<%=rstInvoice("ticketnumber")%>" name="partial_<%=rstInvoice("ticketnumber")%>" value="undefined">
								<input type=hidden id=chkIsRacked name=chkIsRacked value="<%if trim(rstInvoice("racklocation")) = "" then%>0<%else%>1<%end if%>">
								<input type=hidden id=chkIsUnpaid name=chkIsUnpaid value="<%if IsInvoiceUnpaid(rstInvoice) then%>1<%else%>0<%end if%>">
							</td>
							<td><%=GetTicketStatusIcons(rstInvoice)%></td>

							<td><%=rstInvoice("invoicenumber") %> </td>
						<%if l_multiplePickup = 1 then%>
							<td style=""><%=trim(rstInvoice("multiPickupCustomerName")) %></td>
							<td style=""><%=trim(rstInvoice("multiPickupLocation")) %></td>
						<%end if%>
							<td><%=trim(rstInvoice("department")) %> </td>
							<td><%=trim(rstInvoice("routeName")) %> </td>
						<%if not hideRackLocation then %>
							<td><%=trim(rstInvoice("racklocation"))%>&nbsp;</td>
						<%end if%>
							<td><%=rstInvoice("datein") %></td>
							<%if session("showInactiveInvoices") then%>
							<td><%=rstInvoice("dateout") %></td>
							<%else%>
							<td><%=rstInvoice("duedate") %></td>
							<%end if%>
							<td>
							<% if not isnull(rstInvoice("nettotal")) then%>
								<%=formatcurrency(rstInvoice("nettotal"), 2)%>
							<%	End if
							%>
							 </td>

							<td><%=formatcurrency(invoiceBalance)%></td>
						</tr>
						<% else %>
						<tr style="background:#eee">
							<td colspan="2" align="center">On Delivery</td>

							<td><%=rstInvoice("invoicenumber") %> </td>
						<%if l_multiplePickup = 1 then%>
							<td style=""><%=trim(rstInvoice("multiPickupCustomerName")) %></td>
							<td style=""><%=trim(rstInvoice("multiPickupLocation")) %></td>
						<%end if%>
							<td><%=trim(rstInvoice("department")) %> </td>
							<td><%=trim(rstInvoice("routeName")) %> </td>
						<%if not hideRackLocation then %>
							<td><%=trim(rstInvoice("racklocation"))%>&nbsp;</td>
						<%end if%>
							<td><%=rstInvoice("datein") %></td>
							<%if session("showInactiveInvoices") then%>
							<td><%=rstInvoice("dateout") %></td>
							<%else%>
							<td><%=rstInvoice("duedate") %></td>
							<%end if%>
							<td>
							<% if not isnull(rstInvoice("nettotal")) then%>
								<%=formatcurrency(rstInvoice("nettotal"), 2)%>
							<% End if %>
							 </td>

							<td><%=formatcurrency(rstInvoice("nettotal") - rstInvoice("amountpaid"))%></td>
						</tr>
						<% end if %>
					<%
							idx = idx + 1
							rstInvoice.movenext
						wend
					%>
				</table>

				</div>
			</td>
		</tr>

		<tr style="background:#EEE">
			<td>
<%
				if rstInvoice.pagecount > 1 then
%>
				<span style="float:left">
				<button style="height:50px;width:80px" onclick="prevPage()">Prev</button>
				<button style="height:50px;width:80px" onclick="nextPage()">Next</button>

				Page
				<select onchange="goToPage(this.value)" >
<%
				for idx = 1 to rstInvoice.pagecount
%>
					<option value="<%=idx%>" <%if trim(idx) = trim(pagenum) then%>selected<%end if%>><%=idx%></option>
<%
				next
%>
				</select>
				of <%=rstInvoice.pagecount%>
				</span>
<%
				end if
%>
				<span style="float:right;text-align:right">
				Total Due:<input readonly style="border:1px solid #CCC;text-align:right;width:100px" id=netTotal name=netTotal value="$0.00">
				<% if accbalance <> 0 then %>
                    <br />
                    Balance Due:<input readonly style="border:1px solid #CCC;text-align:right;width:100px" id=custBal name=custBal value="$<%= accbalance %>">
				<% end if %>
				</span>
			</td>
		</tr>
<%

%>
		<tr class="cmdbar">
			<td>
					<%if not session("showInactiveInvoices") then%>
					<span style="float:left; vertical-align: top" >
						<button onclick="selectedInvoicesPreform('pickup');" id=bttnPreformPickup name=bttnPreformPickup>Pickup</button>
						<button onclick="editSelectedInvoice();" id=bttnPreformEdit name=bttnPreformEdit>Edit</button>
						<button onclick="selectedInvoicesPreform('prepay');" id=bttnPreformPrepay name=bttnPreformPrepay>Prepay</button>
						<button onclick="preformOtherAction();">Other</button>
						<% if showPrintButtons then %><button onclick="printSelectedInvoices();" id=bttnPreformPrint name=bttnPreformPrint>Print</button><% end if %>
                        <% if (smsInvReceipt and canSms and custCellPhone <> "") or (emailInvReceipt and canEmail) then %>
                            <button style="vertical-align: top" onclick="sendSMSSelectedInvoices();">SMS<br />Resend<br />Receipt</button>
                        <% end if %>
						<button style="vertical-align: top" onclick="createPDF();">Invoice<br />PDF</button>
						<% if canPrintHS then %>
						<button style="vertical-align: top" onclick="getHeatSealCount();">Print<br />Heatseals</button>
						<% end if %>
						<button style="vertical-align: top" onclick="CheckAllRackedInvoices();" >Select<br />Racked</button>
					</span>
					<span style="float:left;padding-left:50px">
						<button onclick="schedulePickup();" id=bttnSchedulePickup name=button4>Schedule<br>Pickup</button>
						<button onclick="selectedInvoicesPreform('scheduledropoff');" id=bttnScheduleDropoff name=button4>Schedule<br>Dropoff</button>
					</span>

					<%else%>
					<span style="float:left" >
						<button style="vertical-align: top" onclick="viewInvoiceDetails();" id=bttnPreformDetails name=bttnPreformDetails>View<br>Details</button>
						<% if showPrintButtons then %>
						<button onclick="printSelectedInvoices();" id=bttnPreformPrint name=bttnPreformPrint>Print</button>
					    <% end if %>
						<button style="vertical-align: top" onclick="createPDF();">Invoice<br />PDF</button>
					</span>
					<%end if%>
					<span style="float:right">
						<button onclick="toggleActiveInvoices();"  id=bttnToggleActive name=bttnToggleActive><%if not session("showInactiveInvoices") then%>View<br />Finished<%else%>View<br />Active<%end if%></button>
					</span>
			</td>
		</tr>
		<tr height=50px><td></td></tr>
		</table>

	<input type=hidden name="pagenum" value="<%= pagenum%>">
	</FORM>
</BODY>
</HTML>

<%
	function IsInvoiceUnpaid(rs)
		IsInvoiceUnpaid = lcase(rs("invoicetype")) = "d" and lcase(rs("ticketstatus")) = "ac" and rs("amountpaid") < rs("nettotal")
	end function


	function GetPartialInvoiceStatusIcons(rs)


	end function

	function GetTicketStatusIcons(rs)
		dim result


		if lcase(rs("invoicetype")) = "q" then
			result = "<img src='/static/icons/24x24/invoice_quick.png'>"
		else
			select case lcase(rs("ticketstatus"))
				case "ac"
					if rs("onhold") then
						result = "<img src='/static/icons/24x24/invoice_held.png'>"
					elseif rs("pricelater") > 0 then
						result = "<img src='/static/icons/24x24/invoice_pricelater.png'>"
					else
						result = "<img src='/static/icons/24x24/invoice_open.png'>"
					end if
				case "fi"
					result = "<img src='/static/icons/24x24/invoice_finished.png'>"
			end select

			if rs("ticketstatus") = "VO" then
				result = result & "<img src='/static/icons/24x24/invoice_void.png'>"
			else
				if rs("pricelater") = 0 and round(rs("nettotal") - rs("amountpaid"), 2) <= 0  then
					result = result & "<img src='/static/icons/24x24/invoice_paid.png'>"
				end if

				if trim(rstInvoice("racklocation")) <> "" and trim(rstInvoice("racklocation")) <> "At Plant" then
					result = result & "<img src='/static/icons/24x24/invoice_rack.png'>"
				end if
			end if


		end if

		if dropOffExistsForTicket(rs("ticketnumber")) then
			result = result & "<img src='/static/icons/24x24/invoice_move.png'>"
		end if

		if claimReceiptExistsForTicket(rs("ticketnumber")) then
			result = result & "<img src='/static/icons/24x24/invoice_claimreceipt.png'>"
		end if

		GetTicketStatusIcons = result
	end function


	function GetTicketSplitDetails(ticketNumber)
		dim query, rs

		query = " select ticket.invoicenumber, " _
		    & " case when exists (select location from PlantManifestItem pmi where pmi.invoiceNumber = ticket.invoiceNumber and pmi.status in (2, 3)) then 'At Plant' " _
            & " else dbo.pivotInvoiceRackLocation(ticket.invoicenumber, ', ') end as racklocation, " _
		    & " min(case ticketlineitem.pickedup when 1 then 1 else 0 end) as pickedup " _
		    & " from ticketlineitem " _
		    & " inner join ticket on ticketlineitem.ticketnumber = ticket.ticketnumber " _
		    & " where ticketlineitem.ticketnumber = " & ticketnumber _
		    & " and ticketlineitem.ticketlinetype in ('it', 'ac') " _
		    & " group by ticket.ticketnumber, ticket.invoicenumber "

		set GetTicketSplitDetails = getdisconnectedrecordset(query)

	end function

	function GetInvoiceList(customerseqnumber, status)
		dim query, rs

		query = "select convert(varchar, t.duedate, 101) as duedate, t.invoicetype, t.onhold, t.ticketstatus, t.ticketnumber, convert(varchar, t.dateout, 101) as dateout, t.invoicenumber, convert(varchar, t.createddate, 101) as 'datein' , t.invoicetotal, t.nettotal" _
					& " , t.amountpaid, convert(varchar, t.createddate, 101) as createddate , c.customername , c.multiplepickup, tc.multiplepickup as 'ticket_multipickup', tc.multiPickupCustomerName, tc.multiPickupLocation"_
					& " , dbo.pivotTicketDepartments(t.ticketnumber, ',') as 'department', " _
		            & " case when ticketstatus in ('AC', 'OD') and exists (select location from PlantManifestItem pmi where pmi.invoiceNumber = t.invoiceNumber and pmi.status in (2, 3)) then 'At Plant' " _
					& " else dbo.pivotTicketRackLocationBrief(t.ticketnumber, ',') end as 'racklocation' " _
					& ", I.trackLocation as 'lastScannedlocation'" _
					& ", convert(varchar, t.lastmodifieddate, 101) as lastmodifieddate, r.name as 'routeName'" _
					& ", isnull(t.lotID,0) as lotID " _
					& ", dbo.countPriceLaterLines(t.ticketnumber) as priceLater " _
					& ", dbo.isTicketSplit(t.ticketnumber) as isSplit, " _
                    & " case when exists (select subLabel from InvoiceSubDivision isd where isd.TicketNumber = t.TicketNumber) then 1 else 0 end as 'subLabels' " _
					& " from customer c, ticketcustomer tc, Route r, ticket t LEFT OUTER JOIN TicketLocationtracking I ON t.ticketnumber = I.ticketnumber and I.createddate = (select max(createddate)from  ticketlocationtracking where t.ticketnumber = ticketnumber)  " _
					& " where t.customersequencenumber = " & customerseqnumber  _
					& " and  ticketstatus in ("  & status _
					& ") and t.customersequencenumber = c.customersequencenumber  " _
					& " and t.ticketnumber = tc.ticketnumber " _
					& " and r.routenumber = t.routenumber "

					if historyyear <> "" then
						if historyyear = "all" then
						elseif historyyear = "last365" then
							query = query & " and datediff(d, t.duedate, getdate()) <= 365 "
						else
							query = query & " and datepart(yyyy, t.duedate) = " & historyyear
						end if
					end if

		query = query & " order by convert(datetime, T.DateOut) desc, convert(datetime, T.CreatedDate) asc"
		set GetInvoiceList = getdisconnectedrecordset(query)
	end function

	function dropOffExistsForTicket(ticketnumber)
		dim query, rs
		query = " select count(*) as cnt from deliverywillcall where "
		query = query & " ticketnumber = " & ticketnumber
		query = query & " and status = 0 "
		query = query & " and actionrequired = 'DROPOFF'"
		set rs = getdisconnectedrecordset(query)
		dropOffExistsForTicket = rs("cnt") > 0
		set rs = nothing
	end function
	function claimReceiptExistsForTicket(ticketnumber)
		dim query, rs
		query = " select count(*) as cnt from claimReceipt "
		query = query & " inner join ticketlog on claimReceipt.claimReceiptID = ticketlog.claimReceiptID "
		query = query & " where ticketlog.ticketnumber = " & ticketnumber
		set rs = getdisconnectedrecordset(query)
		claimReceiptExistsForTicket = rs("cnt") > 0
		set rs = nothing
	end function
	function getCustomerInfo()
	dim sqltxt
	dim rsCustomer

		l_multiplePickup = 0

		l_countersale = false

		Sqltxt = "select firstname,lastname ,mainareacode , mainphone , shippingaddress1, shippingaddress2 " _
					& " , shippingaddress3,shippingcity,shippingstate,shippingzipcode  " _
					& " ,  Customerid , customersequencenumber , multiplePickup "_
					& "	, customername ,r.name as 'routename', p.name as 'pricelistname' " _
					& "	, countersaleonly, issuspended, email, cellPhone " _
					& " from customer c LEFT OUTER JOIN pricelist P ON c.defaultpricelistid = p.pricelistid LEFT OUTER JOIN route R ON c.routenumber = r.routenumber where " _
					& " Customersequencenumber = " &  customerseq

		set rsCustomer= getdisconnectedrecordset(sqltxt)

		if rsCustomer.recordcount > 0  then

			if rscustomer("countersaleonly")= true then
				l_countersale = true
			end if

			if rscustomer("multiplePickup")= true then
				l_multiplePickup = 1
			end if

			l_firstname = checkfornull(rscustomer("firstname"))
			l_lastname= checkfornull(rscustomer("lastname"))
			l_email = checkfornull(rscustomer("email"))
			l_mareacode= checkfornull(rscustomer("mainareacode"))
			l_mphone= checkfornull(rscustomer("mainphone"))
			custCellPhone = checkfornull(rscustomer("cellPhone"))

			if len(trim(l_mareacode)) > 0 then
				l_mareacode = "(" & l_mareacode & ")"
			end if

			if len(trim(l_mphone)) >= 7 then
				l_mphone = left(l_mphone, 3) & "-" & right(l_mphone,len(l_mphone) -3)
			end if


			l_saddress1= checkfornull(rscustomer("shippingaddress1"))
			l_saddress2= checkfornull(rscustomer("shippingaddress2"))
			l_saddress3= checkfornull(rscustomer("shippingaddress3"))
			l_scity= checkfornull(rscustomer("shippingcity"))
			l_sstate= checkfornull(rscustomer("shippingstate"))
			l_szip= checkfornull(rscustomer("shippingzipcode"))
			l_pricelistid = rscustomer("pricelistname")
			l_routeid= rscustomer("RouteName")
			'Poonam: added for csutomer name for customer display
			custFullName =  rscustomer("Customername")
			'end change

			hasCCOnFile = false

			Session("customerid") = rscustomer("Customerid")
			session("customername") = rscustomer("Customername")

			onsuspend = rscustomer("issuspended")

		end if
		rscustomer.close

		set rscustomer= nothing
	dim rsSetupOptions

	l_baddress = 0
	l_broute = 0

	Sqltxt = "Select * from customerSetupoptions where storeid =" & l_storeid

	set rsSetupOptions= getdisconnectedrecordset(sqltxt)

	if not rsSetupOptions.BOF and not rsSetupOptions.EOF then

		if rsSetupoptions("allowentrycustaddr") then
			l_baddress = 1
		end if

		if rsSetupoptions("allowentrycustrouteinfo") then
			l_broute = 1
		end if

		rsSetupOptions.close

		set rsSetupOptions = nothing
	end if

	dim rstrequired

	l_brfirstname = 0

	l_brdob = 0

	l_brmainphone = 0

	sqltxt = "select * from requiredcustomerfields where storeid =" & l_storeid

	set rstrequired = getdisconnectedrecordset(sqltxt)

	if not rstrequired.bof and not rstrequired.eof then

		select case lcase(rstrequired("fieldname"))

		case "firstname"
			if rstrequired("required") then
				l_brfirstname= 1
			end if
		case "dateofbirth"
			if rstrequired("required") then
				l_brdob= 1
			end if
	    case "mainphone"
			if rstrequired("required") then
				l_brmainphone= 1
			end if
	    end select
	    rstrequired.close
	    set rstrequired = nothing
	end if

end function




	function getCustomerName(csn)
		dim query, rs

		query = "select customername from customer where customersequencenumber = " & csn
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getCustomerName = rs("customername")
		end if

		set rs = nothing
	end function

	function changeInvoiceRoute(routeId)
		dim tickets
		dim i
		dim ticketStr
		dim query, rs

		ticketStr = "'" & Request.QueryString("Ticketnumber") & "'"
		ticketStr = Replace(ticketStr, ",", "','")

		query = "update ticket set routenumber = " & routeId & " where ticketnumber in (" & ticketStr & ")"

		qryexecute query
	end function

	function getPickupOnlyOnAccount(customerSeq)
		dim query, rs

		query = " select pickupOnlyOnAccount from customer where customersequencenumber = " & customerseq

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getPickupOnlyOnAccount = rs("pickupOnlyOnAccount")
		end if

	end function


	function cashOutOverpayTickets(ticketnumbers)
		dim query, rs

		query = " select ticketnumber, nettotal, amountpaid from ticket where amountpaid > nettotal and ticketnumber in (" & ticketnumbers & ")"
		set rs = getdisconnectedrecordset(query)

		cashOutOverpayTickets = 0

		while not(rs.eof or rs.bof)
			cashOutOverpayTickets = cashOutOverpayTickets + rs("amountpaid") - rs("nettotal")
			query = " update ticket set amountpaid = nettotal where ticketnumber = " & rs("ticketnumber")
			qryexecute query
			rs.movenext
		wend

		set rs = nothing
	end function


	function cashOutOverpay()
		dim query, rs

		dim tickets
		dim amount

		tickets = Request.QueryString("Ticketnumber")
		amount = cashOutOverpayTickets(tickets)

		query = "INSERT into MiscCharge (storeid, CustomerSequenceNUmber, chargedate, ChargeType, CreditType, ChargeDescription , chargeamount, effectivedate, createddate, createdEmployeeid, hardwareid,paymentgroupnumber, internaltransaction, terminalid) "
		query = query & " values  (" & session("storeid") & ", " & customerSeq & ", getdate(), 'C', 'R', 'Credit due to excess payment', " & amount & ", getdate(),getdate(), " & session("employeeid") & ", null, null, 1, " & session("terminalid") & ")"

		qryexecute query
	end function

	function pickupSelectedInvoices(action, autoPickup)
		dim tickets
		dim i
		dim pickupObj
		dim pickupInvoiceNumbers

		if action = "pickup" and getPickupOnlyOnAccount(customerSeq) then
			Response.Redirect "accountPickup.asp?useraction=pickup&targetpage=customerfunctions&customerseq=" & customerseq & "&ticketnumber=" & Request.QueryString("Ticketnumber")
		end if

		set pickupObj =Server.CreateObject("ShahCorpComponents.pickup")

		tickets = split(Request.QueryString("Ticketnumber"), ",")
		pickupInvoiceNumbers = request.querystring("invoicenumbers")

		pickupObj.initPickupObject

		pickupObj.DBConnectionString = Session("shahcorpDSN")
		pickupObj.storeId = Session("storeID")
		pickupObj.initStorePaymentTypeInfo()

		pickupObj.userAction = action

		pickupObj.custSeqNumber = customerseq

		if action = "prepay" then
			for i = lbound(tickets) to ubound(tickets)
				pickupObj.addInvoiceToPrepay tickets(i)
			next
		else
			for i = lbound(tickets) to ubound(tickets)
				pickupObj.addInvoiceToPickup tickets(i)
			next
		end if



		Session("customersequencenumber") = customerseq
		Session("customername") = getCustomerName(customerseq)

		set Session("pickupObj") = pickupObj
		Set Session("pickupInvoices") = Nothing
		Set Session("ticketDepartment") = Nothing
		Set Session("ticketRack") = Nothing
		Set Session("invoice") = Nothing

		Session("invoicelist") = pickupInvoiceNumbers

		if action = "pickup" and request.querystring("claimreceipt") then
		  Response.Redirect "claimReceipt.asp?targetPage=customerfunctions&invoicenumbers=" & pickupInvoiceNumbers & "&target=" & action
		else
		  if action = "pickup" and autoPickup = 1 and pickupObj.getAmountDue() = 0 then
		  	applyPayments
		  else
		  	Response.Redirect "pickup.asp?targetPage=customerfunctions&customerSeq=" & customerSeq _
		  	    & "&invoicenumbers=" & pickupInvoiceNumbers & "&target=" & action & "&userAction=" & action
		  end if
		end if


	end function

	function applyPayments()
		dim custSeqNumber
		dim empId
		dim terminalId
		dim invNumbers
		dim pickupObj
		dim invoiceNumbers
		dim invoiceNumber

		empId = Session("employeeID")
		terminalId = Session("terminalID")
		custSeqNumber = Session("customersequencenumber")

		set pickupObj = Session("pickupObj")
		pickupObj.pickupReceipt = 0

		invoiceNumbers = split(request.querystring("invoicenumbers"), ",")

		for each invoiceNumber in invoiceNumbers
			pickupObj.markInvoicePickedUp invoiceNumber
		next

		pickupObj.applyPayments empId, terminalId, pickupObj.constructTicketNosString(), -1

		invNumbers = pickupObj.getTicketNosForPrinting()
		dim totalchangedue
		totalchangedue = abs(pickupObj.getChangeDue())

        if (isMessengerEnabled and (smsPickup or emailPickup)) then
            Dim data, httpRequest, postResponse

            data = "customerSeq=" & custSeqNumber

            Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
            httpRequest.Open "POST", getMessengerFullPath("main") & "/pickupOccurred", False
            httpRequest.SetRequestHeader "Content-Type", "application/x-www-form-urlencoded"
            httpRequest.Send data
            postResponse = httpRequest.ResponseText
        end if



		if pickupObj.userAction <> "prepay" then
			recordPickupNote
		end if
		checkOnDemand()

		Response.Redirect "customerfunctions.asp?userAction=print&addOrEdit=" _
							& addOrEdit & "&ticketNumber=" & invNumbers _
							& "&invoiceType=P&customerseq=" & custSeqNumber _
							& "&totalchangedue="& totalchangedue _
							& "&action=" & pickupObj.userAction _
                            & "&onDemCredit=" & onDemCredit
	end function


	function checkOnDemand()
        dim query, rs, custSeqNumber, odcAwarded, runAgain
		custSeqNumber = Session("customersequencenumber")
		runAgain = 1

        query = " select ondemandqualified from customer where customersequencenumber = " & custSeqNumber & " and ondemandqualified = 1 "
        set rs = getdisconnectedrecordset(query)

        if rs.recordcount > 0 then
        	query = "getprobableondemandcoupons " & custSeqNumber
        	Set rs = getDisconnectedRecordset(query)
            while rs.recordcount > 0 and runAgain = 1
                runAgain = 0
                rs.MoveFirst
                while not rs.EOF
                    if rs("type") = 2 then
                        runAgain = 1
                        dim amt, refId
                        amt = rs("creditAmt")

                        query = "AwardOnDemandCoupon " & custSeqNumber & ", " & rs("id")
                        QryExecute(query)

                        query = "SET NOCOUNT ON; INSERT into MiscCharge (storeid, CustomerSequenceNumber, chargedate, ChargeType, " _
                            & "CreditType, ChargeDescription , chargeamount, effectivedate, createddate, createdEmployeeid, " _
                            & "hardwareid,paymentgroupnumber, internaltransaction, terminalid, ondemandId) " _
                            & " values  (" & session("storeid") & ", " & custSeqNumber & ", getdate(), 'C', " _
                            & "'C', 'On Demand Earned Credit', " & amt & ", getdate(),getdate(), 1, null, null, 1, " _
                            & session("terminalid") & ", " & rs("id") & "); select scope_identity(); set nocount off"
                        dbstartTrans()
                        refId = qryexecutewithtransandselect(query)
                        dbEndTrans()

                        query = "INSERT into GeneralLedger(customerSequenceNumber, refNumber, refType, refDescription, " _
                            & "amountDue, totalAmountDue, totalBalance, termDate, createdDate, createdEmployeeID) " _
                            & " values  (" & custSeqNumber & ", " & refId & ", 'MC', 'On Demand Earned Credit', -1 * "  _
                            & amt & ", -1 * " & amt & ", -1 * " & amt & ", getdate(), getdate(), 1)"
                        qryexecute query

                        onDemCredit = onDemCredit + amt
                    end if
                    rs.MoveNext
                wend
                query = "getprobableondemandcoupons " & custSeqNumber
                Set rs = getDisconnectedRecordset(query)
            wend
        end if
	end function

	sub recordPickupNote()
		dim query


		query = "insert into customernote (customersequencenumber, storeguid, source, note)"
		query = query & " select " & customerSeq
		query = query & ", store.guid"
		query = query & ", '" & session("employeename") & "'"
		query = query & ", 'Picked up invoice " & Session("invoicelist") & "'"
		query = query & " from store where storeid = " & session("storeid")

		qryexecute query

	end sub
	function suspendCustomer()
		dim query
		query = "update customer set issuspended = 1 where customersequencenumber = " & customerseq
		qryexecute query
	end function

	function unsuspendCustomer()
		dim query
		query = "update customer set issuspended = 0 where customersequencenumber = " & customerseq
		qryexecute query
	end function

%>