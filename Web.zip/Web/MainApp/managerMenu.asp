<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/processor.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
    dim use_clearent
    determineIfClearent

	function getDatabaseNames()
		dim dboptions
		dim dbtool
		dim i
		dim result
		
		set dbtool = server.createobject("ShahCorpComponents.DbTool")
		dboptions = dbtool.GetDbOptions()
		
		for i = lbound(dboptions) to ubound(dboptions)
			if result <> "" then result = result & "|"
			result = result & dboptions(i).DbName
		next
		
		getDatabaseNames = result
	end function
%>
<HTML>
<HEAD>
<TITLE>Manager Menu</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT type="text/javascript">
	function submitForm(){
		document.managerMenuForm.submit();
	}
	
	function cancelForm(){
		document.managerMenuForm.action="start2.asp";
		document.managerMenuForm.submit();
	}	
	
	function showAccountManagement(){
		document.managerMenuForm.action ="accountMgmt.asp";
		document.managerMenuForm.submit();
	}
	
	function showEmpManagement(){
		document.managerMenuForm.action ="employeeManagement.asp";
		document.managerMenuForm.submit();
	}
	
	function showreportList(){
		document.managerMenuForm.action ="reportGroup.asp";
		document.managerMenuForm.submit();
	}
	function showPurchasing() {
		document.managerMenuForm.action="purchasing.asp";
		document.managerMenuForm.submit();
	}
	
	function showLicenseManager() {
		document.managerMenuForm.action="/MainApp/LicenseManager.asp?Reason=checking";
		document.managerMenuForm.submit();
	}
	
	function giftCardProgram() {
		document.managerMenuForm.action="/MainApp/giftCards.asp";
		document.managerMenuForm.submit();
	}
	
	function inactiveCustomerSearch() {
		document.managerMenuForm.action="/MainApp/activeInactiveCustomerSearch.asp";
		document.managerMenuForm.submit();
	}

	function inactivateTicketSearch() {
		document.managerMenuForm.action="/MainApp/InactivateTicketSearch.asp";
		document.managerMenuForm.submit();
	}

	function overRideCashOutZ() {
		document.managerMenuForm.action="/MainApp/OverRideCashOutZ.asp";
		document.managerMenuForm.submit();
	}

	function showMarketingTool() {
		document.managerMenuForm.action="/MainApp/marketingMenu.asp";
		document.managerMenuForm.submit();
	}
	
	function showMainSetup() {
		document.managerMenuForm.action="/setup/mainsetup.asp";
		document.managerMenuForm.submit();
	}
	function SwitchToTrainingMode() {
		document.managerMenuForm.action="/mainapp/start2.asp?mode=T";
		document.managerMenuForm.submit();
	}

	function SwitchToProductionMode() {
		document.managerMenuForm.action = "/mainapp/start2.asp?mode=P";
		document.managerMenuForm.submit();
	}
	
	function mergeCustomers() {
		document.managerMenuForm.action="/MainApp/mergeCustomers.asp";
		document.managerMenuForm.submit();
	}
	
	function viewProduction() {
		document.managerMenuForm.action="/MainApp/productionTracking.asp";
		document.managerMenuForm.submit();
	}	
	
	function selectDatabase() {
		cbs_select("Select Database", 1, "<%=getDatabaseNames()%>", "handleDBSelect");
	}

    function handleDBSelect(returnVal) {
        clearOptionMsg();
        var db = "<%=getDatabaseNames()%>".split("|")[returnVal];
        if(db && window.parent)
            window.parent.SelectDatabase(db);
    }

	function voidTransaction() {
		document.managerMenuForm.action="/mainapp/cardpaymentvoidList.asp";
		document.managerMenuForm.submit();
	}

	function showCardPaymentLog() {
		document.managerMenuForm.action="/mainapp/cardpaymentlog.asp";
		document.managerMenuForm.submit();
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Manager Menu</H1>
<FORM id="managerMenuForm" name="managerMenuForm" action="start2.asp" method="Post" onsubmit="return false">
<CENTER>

	<TABLE ALIGN=center BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=accountMgmt onclick="showAccountManagement()">Account Management</BUTTON>
			</TD>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=empMgmt onclick="showEmpManagement()">Employee Management</BUTTON>
			</TD>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=reportList onclick="showreportList()">Reporting</BUTTON>
			</TD>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=purchasing onclick="showPurchasing()">Purchasing</BUTTON>
			</TD>
		</TR>
		<TR>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=giftCard onclick="giftCardProgram()">Gift Card Program</BUTTON>
			</TD>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=LicenseMgmt onclick="showLicenseManager()">Update CBS License</BUTTON>
			</TD>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=inactiveCust onclick="inactiveCustomerSearch()"><!--<img src="">-->Change Customer Status</button>
			</TD>	
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=inactiveTicket onclick="inactivateTicketSearch()"><!--<img src="">-->Change Invoice Status<br>(Void or Reverse Pickup)</button>
			</TD>	
		</TR>
		<TR>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=overRideCOZ onclick="overRideCashOutZ()"><!--<img src="">-->Override Cash Out Z</button>
			</TD>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=marketingTool onclick="showMarketingTool()">Specialized Reports</button>
			</TD>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=mainsetup onclick="showMainSetup()"><!--<img src="">-->Setup</button>
			</TD>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px"  onclick="selectDatabase()"><!--<img src="">-->Select Database</button>
			</TD>
		</TR>
		<TR>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=cardPaymentLog onclick="showCardPaymentLog()">Credit Card Log</button>
			</TD>
			<%if use_clearent then %>
                <TD>
                    <BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=voidTransaction" onclick="voidTransaction()">Void Transactions<br>(Today Only)</button>
                </TD>
			<% end if %>
                <TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=mergeCustomer onclick="mergeCustomers()">Merge Customers</button>
                </TD>
			<TD>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" name=productionTracking onclick="viewProduction()">View Production</button>
			</TD>
			<TD>
			</TD>
		</TR>
		
	</TABLE>
	<br><br>
	<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">

</CENTER>
</FORM>   

</BODY>
</HTML>
