<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim dateBegin, dateEnd, clearentIP
	
	dateBegin = getReqVar("dateBegin")
	dateEnd = getReqVar("dateEnd")
	if dateBegin = "" then dateBegin = date()


    clearentIP = getClearentShortPath()

	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../script/date-picker2.js"></script>
<script type="text/javascript" src="/script/printing.js"></script>

<script type="text/javascript">
	var previousElement = null;
	var selectedTransactionId = null;
	var voidedTransaction = null;


	function printReceipt() {
		if(selectedTransactionId) {
			if (voidedTransaction == 0)
			    PrintCreditCardReceipt(selectedTransactionId);
			else
				PrintCreditCardVoidReceipt(selectedTransactionId);
		}
	}

	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}
		
		selectedTransactionId = element.getAttribute("transactionId");
		voidedTransaction = element.getAttribute("voided");

		previousElement =element;
		
		element.className = "selected";
	}

	function retryPayment(cardpaymentid, tickets) {
            var loc = window.location.href;
            var extraCut = 0;
            if (loc.indexOf(":80") != -1)
                extraCut = 5;
            var endStop = loc.indexOf("/mainapp")
            if (endStop == -1)
                endStop = loc.indexOf("/MainApp")

            endStop = endStop - extraCut;
            var ipAddress = loc.substring(0, endStop);
                var url = ipAddress + "<%=clearentIP%>/checkReadErrorTrans?cardPaymentId=" + cardpaymentid;
                cbs_alert("The credit card transaction will be verified and if approved will be applied to the ticket(s) " +
                    tickets + ". Please give up to 1 minute before re-checking.");
                try {
                    $.ajax({
                        type: "POST",
                        url: url,
                        dataType: "text",
                        timeout: "1500"
                    });
                } catch (exception) {
                    cbs_alert("Unable to connect to clearent service to attempt")
                }

	}
	
	function update() {
		document.accountHistory.action = "?useraction=update";
		document.accountHistory.submit();
	}
	
	function exit() {
		document.accountHistory.action = "/mainapp/managermenu.asp";
		document.accountHistory.submit();
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<H1>Card Payment Log</H1>


<FORM id="accountHistory" name="accountHistory" action="" method="post" onsubmit="return false">
<INPUT type="hidden" name="customerseq" value="<%=customerseq%>" />


Date range
<INPUT name="dateBegin" value="<%=dateBegin%>" readonly onclick="javascript:show_calendar('accountHistory.dateBegin');">
to
<INPUT name="dateEnd" value="<%=dateEnd%>" readonly onclick="javascript:show_calendar('accountHistory.dateEnd');">
<BUTTON onclick="update()">Look Up</BUTTON>

</FORM>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="printReceipt()">Print<br>Receipt</BUTTON>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH>Terminal</TH>
		<TH>Employee</TH>
		<TH>Customer</TH>
		<TH>Date</TH>
		<TH>Success</TH>
		<TH>Amount</TH>
		<TH>Applied</TH>
		<TH></TH>
	</TR>
	<%

		query = " select cardpaymentid, isnull(rawanswer, '') as rawanswer, daterequested, isnull(amount, 0) as amount, isnull(amountapplied, 0) as amountapplied, isnull(success, -1) as success, "
		query = query & " isnull(terminal.name, '') as terminalname, "
		query = query & " isnull(employee.employeename, '') as employeename, "
		query = query & " isnull(customer.customername, '') as customername, "
		query = query & " transactionid , 0 as void"
		query = query & " from cardpayment "
		query = query & " left outer join terminal on cardpayment.terminalid = terminal.terminalid "
		query = query & " left outer join employee on cardpayment.clerk = employee.employeeid "
		query = query & " left outer join customer on cardpayment.customersequencenumber = customer.customersequencenumber "
		

		query = query & " where 1 = 1 "
		
		
		if dateBegin <> "" then
			query = query & " and datediff(day, cardpayment.daterequested, '" & dateBegin & "') <= 0 "
		end if
		
		
		if dateEnd <> "" then
			query = query & " and datediff(day, cardpayment.daterequested, '" & dateEnd & "') >= 0 "
		end if
	

		query = query & " union all ("
        query = query & " select cardpaymentid, isnull(rawanswer, '') as rawanswer, daterequested, "
        query = query & "isnull(amount, 0) * -1 as amount, isnull(amount, 0) * -1 as amountapplied, isnull(success, -1) as success, "
        query = query & "isnull(terminal.name, '') as terminalname, isnull(employee.employeename, '') as employeename, "
        query = query & "isnull(customer.customername, '') as customername, cast(cardpaymentid as varchar) as transactionid, 1 as void from cardvoid "
        query = query & "left outer join terminal on cardvoid.terminalid = terminal.terminalid "
        query = query & "left outer join employee on cardvoid.clerk = employee.employeeid "
        query = query & "left outer join customer on cardvoid.customersequencenumber = customer.customersequencenumber "
        query = query & "where 1 = 1 "

		if dateBegin <> "" then
			query = query & " and datediff(day, cardvoid.daterequested, '" & dateBegin & "') <= 0 "
		end if

		if dateEnd <> "" then
			query = query & " and datediff(day, cardvoid.daterequested, '" & dateEnd & "') >= 0 "
		end if


		query = query & ") order by cardpaymentid, daterequested "
%>

	<!--tr><td colspan="7"><%=query%></td></tr-->
<%


		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
	%>
	<TR onclick="selectRow(this)" transactionId="<%=rs("transactionid")%>" voided="<%=rs("void")%>">
		<TD><%=server.htmlencode(rs("terminalname"))%></TD>
		<TD><%=server.htmlencode(rs("employeename"))%></TD>
		<TD><%=server.htmlencode(rs("customername"))%></TD>
		<TD><%=server.htmlencode(rs("daterequested"))%></TD>
		<TD><%
			select case rs("success")
			case 1
				response.write "YES"
			case 0
				response.write "NO"
			end select
		
		%></TD>
		<% if rs("void") = 0 then %>
		<TD><%=formatcurrency(rs("amount"))%></TD>
		<TD><%=formatcurrency(rs("amountapplied"))%></TD>
		<% else %>
			<TD style="color:red"><%=formatcurrency(rs("amount"))%></TD>
			<TD style="color:red"><%=formatcurrency(rs("amountapplied"))%></TD>
		<% end if%>
		<td>
		    <% dim query2, rs2
		        query2 = "select tickets from CardReadError where handled = 0 and cardPaymentId = " & rs("cardpaymentid")
		        set rs2 = getdisconnectedrecordset(query2)
                if rs2.recordcount > 0 then
		     %>
                <BUTTON onclick="this.disabled = true; retryPayment('<%=rs("cardpaymentid")%>', '<%=rs2("tickets")%>'); ">Recheck<br />Payment</BUTTON>
            <% end if %>
		</td>
	</TR>
	<%
			rs.movenext
		wend
		set rs = nothing
	%>
</TABLE>

</FORM>
</BODY>
</HTML>
