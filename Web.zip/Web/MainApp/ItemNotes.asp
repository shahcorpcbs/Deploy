<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("targetPage")%>
<%
	dim targetPage
	dim lineNumber
	dim invoice
	dim itemNotes
	dim userAction
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim colorSet, upchargeSet, patternSet
	dim dueDateSet
	dim dueDate
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim originatingPage
	
	targetPage = Request.QueryString("targetPage")
	
	select case targetPage
		case "quick"
				'userAction = Request.QueryString("userAction")
				dueDateSet = Request.QueryString("isDueDateSet")
				lineNumber = Request.QueryString("lineNumber")
				deptStartIndex = Request.Form("DeptPageCount")
				addOrEdit = Request.Form("addOrEdit")
				selectedDept = Request.Form("selDeptId")
				set invoice = Session("invoice")
				itemNotes = invoice.getItemNotes(lineNumber)
		case "detail", "counterSale"
				lineNumber = Request.QueryString("lineNumber")	
				dueDateSet = Request.Form("isDueDateSet")
				dueDate = Request.Form("txtDueDate")
				curr_LineNo = Request.Form("lineNumber")
				selectedDept = Request.Form("selectedDept")
				itemsStartIndex = Request.Form("ItemPageCount")
				upChargeStartIndex = Request.Form("upChargePageCount")
				colorsStartIndex = Request.Form("colorsPageCount")
				patternStartIndex = Request.Form("PatternPageCount")
				deptStartIndex = Request.Form("DeptPageCount")
				addOrEdit = Request.Form("addOrEdit")
				upchargeSet = Request.Form("upchargeSet")
				colorSet = Request.Form("colorSet")
				patternSet = Request.Form("patternSet")
				selItemId = Request.Form("selItemId")
				selUpchargeValue = Request.Form("selUpcharge")
				selColorValue = Request.Form("selColor")
				selPatternValue = Request.Form("selPattern")
				originatingPage = Request.Form("originPage")
				set invoice = Session("invoice")
				itemNotes = invoice.getItemNotes(lineNumber)
	
end select
	
		
%>
<HTML>
<HEAD>
<TITLE>Item Notes</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function submitForm() {
		var line
		var page
		var dueDate
		line = document.ItemNotesForm.selLineNo.value;
		page = document.ItemNotesForm.tPage.value;
		dueDate = document.ItemNotesForm.isDueDateSet.value;
		switch(page){
			case "quick":
				document.ItemNotesForm.action ="quickinvoice.asp?userAction=returnFromNotes"
				break;
			case "detail":
				document.ItemNotesForm.action ="detailedInvoice.asp?userAction=returnFromNotes"
				break;
			case "counterSale":
				document.ItemNotesForm.action ="counterSale.asp?userAction=returnFromNotes"
				break;
		}
		document.ItemNotesForm.submit();
			
	}

	function cancelForm() {
		var page;

		page = document.ItemNotesForm.tPage.value;

		switch(page){
			case "quick":
				document.ItemNotesForm.action ="quickinvoice.asp"
				break;
			case "detail":
				document.ItemNotesForm.action ="detailedInvoice.asp"
				break;
			case "counterSale":
				document.ItemNotesForm.action ="counterSale.asp"
				break;
		}
		document.ItemNotesForm.submit();
			
	}
</script>
<BODY topmargin=0 leftmargin=0 onLoad="document.ItemNotesForm.itemNotes.focus()">

<!-- #include file="../include/banner.inc" -->
<H1>Item Notes</H1>
<FORM id="ItemNotesForm" name="ItemNotesForm" action="itemNotes.asp" method="post">
	<INPUT type="hidden" name="isDueDateSet" value="<%= dueDateSet %>">
	<INPUT type="hidden" name="selLineNo" value="<%= lineNumber %>">
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="upchargeSet" value="<%= upchargeSet %>">
	<INPUT type="hidden" name="colorSet" value="<%= colorSet %>">
	<INPUT type="hidden" name="patternSet" value="<%= patternSet %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<INPUT type="hidden" name="txtDueDate" value="<%= dueDate %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
			<tr height=50px><td></td></tr>
			<TR>
				<TD align="center">
					<TEXTAREA rows="10" cols="40" name="itemNotes" tabindex=1><%= itemNotes%></TEXTAREA>
				</TD>
			</TR>
			<TR>
				<TD align="center">
					<TABLE ALIGN=center WIDTH="400px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
						<!--<td align="center">
							<INPUT class=touch id=editButton name=editButton type=button value=""><br>Edit
						</td>-->
						<td align="center">
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick="submitForm();">
						&nbsp&nbsp&nbsp
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm();">
						</td>
					</table>
			   </TD>
			</TR>     
	</TABLE>
</FORM>   

</BODY>
</HTML>