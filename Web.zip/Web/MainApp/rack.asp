<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/ApplicationFunctions.inc" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/EmployeeSecurity.asp" -->
<!-- #include file="../include/email.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim isSubmitted
	dim s_Invoicestatus
	dim straction
	dim l_error
	dim is_rack
	dim s_errmessage
	dim ticketnumber
	dim alertmessage
	dim addtolist,	rackinvoice,racklocation1,racklocation2,racklocation3,rackchkgroup

	dim ssql
	dim UseSameRackLocation
	dim HideRackErrors
	dim sqlrs
	
	rackinvoice=""
	racklocation1 = ""
	racklocation2=""
	racklocation3=""
	
	
	alertmessage = ""
	addtolist = 0
	ticketnumber = 0
	rackchkGroup = 0

	
	s_Invoicestatus = ""
	ticketnumber = request("txtTicketNumber")
	s_Invoicestatus = request("txtTicketStatus")
	isSubmitted = Request.QueryString("submitted")
		
	l_error = false
	
	if isobject(session("rackList")) then
		set session("rackList") = nothing
	end if

			
	if isSubmitted   then
		UseSameRackLocation = Request.Form("chkKeepRackNumber")
		HideRackErrors = Request.Form("chkHideError")
		

		ssql = "Update MiscSetup Set UseSameRackLocation = '" & UseSameRackLocation & "'"
		ssql = ssql & ", HideRackErrors = '" & HideRackErrors & "' where storeid = '" & Session("Storeid") & "'"
		

		
		QryExecute ssql

		saveData()
		straction = Request.QueryString("userAction")
		isNumeric(request("rackinvoice")) 		
		
		if straction="validate" then
			validateRackAssignment()
			rackinvoice = request("rackinvoice")
			racklocation1 = request("racklocation1")
			racklocation2 = request("racklocation2")
			racklocation3 = request("racklocation3")
			rackchkgroup = request("rackchkgroup")
			
		elseif  straction="getStatus" then
			getTicketStatus()
			
		elseif straction="done" then
			if  IsNumeric(request("txtTicketNumber")) then
				if trim(Request.Form("chkHideError")) = "" then
					updateDatabaseHideErrorUnChecked()
				else
					updateDatabase()
				end if
		
				if l_error = true  then
					Response.Redirect("RackError.asp")& "?hideError=" & Request.Form("chkHideError") & "&pickup=" & bpickup
				else 
					Response.Redirect("Start.asp")
				end if
			end if	
		end if
	else
		session("s_errmessage") = ""

		ssql = "select UseSameRackLocation, HideRackErrors from MiscSetup where storeID = '" & Session("StoreID") & "'"
		set sqlrs = getdisconnectedrecordset(ssql)
		if not sqlrs.eof then
			if sqlrs("UseSameRackLocation") then
				UseSameRackLocation = 1
			else
				UseSameRackLocation = 0
			end if
			
			if sqlrs("HideRackErrors") then
				HideRackErrors = 1
			else
				HideRackErrors = 0
			end if
		end if
		sqlrs.close
		set sqlrs = nothing

	end if
	
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Rack</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript">
		
	function submitForm(element){
		var i
		i = 0;
		
		if (document.rackForm.lstRackedItems.length > 0 ){
			while (i < document.rackForm.lstRackedItems.length ) {
				document.rackForm.lstRackedItems[i].selected = true;
				i++;
			}
		}
		i=0;
		
		if (document.rackForm.deletedRackedItems.length > 0 ){
			while (i < document.rackForm.deletedRackedItems.length ) {
				document.rackForm.deletedRackedItems[i].selected = true;
				i++;
			}
		}

		if (element == "validate" ){
			document.rackForm.action = document.rackForm.action + "?Submitted=true&userAction=validate";
			document.rackForm.submit();
		}
		
		if (element == "getstatus" ){
			document.rackForm.action = document.rackForm.action + "?Submitted=true&userAction=getStatus";
			document.rackForm.submit();
		}
		else if (element== "done"){
				document.rackForm.action = document.rackForm.action + "?Submitted=true&userAction=done";
				document.rackForm.submit();
		}
	}
	
//	function ProcessRackScanData(sData) {
//		var lst, ar, pair, rack, tag, i;
//		lst = document.getElementById("lstRackedItems");
//		if(sData && sData.length > 0) {
//			//alert(sData);
//			ar = sData.split("\r\n");
//			if(ar) {
//				for(i = 0; i < ar.length; i++) {
//					pair = ar[i];
//					rack = pair.split(",")[0];
//					tag = pair.split(",")[1];
//					if(lst) {
//						var opt = new Option()
//						
//						opt.value =tag + "|||" + rack + "|||" + rack + "|||" + rack
//						
//						opt.text = tag  + "|||" + rack + "|||" + rack + "|||" + rack
//						
//						lst.options[lst.options.length] = opt;
//					}
//				}
//			}
//		}
//	}
	
	function captureKeyDownEvent(element){

		if (event.keyCode == 9)
		{
			if (!checkforduplicateracks())
				return false;									
			if (element.name == "txtTicketNumber" && trim(element.value).length != 0 && !(document.rackForm.chkHideError.checked) )
			{	
				if ((document.rackForm.txtTicketNumber.value) == (document.rackForm.previousinvoicenumber.value))
				{
					//if invoice number is same
				}
				else
				{
					//if invoice number is not same
					submitForm("getstatus");
				}
			}

			if (element.name == "txtRackLocation" && trim(element.value).length != 0 && (document.rackForm.chkHideError.checked) && !(document.rackForm.chkGroupedLocation.checked) )
				addItemToRackList(trim(document.rackForm.txtTicketNumber.value) , trim(document.rackForm.txtRackLocation.value), "", "")
				
			else if (element.name == "txtRackLocation" && trim(element.value).length != 0 && !(document.rackForm.chkHideError.checked) && !(document.rackForm.chkGroupedLocation.checked))
				{
					storeItemsonForm(trim(document.rackForm.txtTicketNumber.value), trim(document.rackForm.txtRackLocation.value), "", "");
					submitForm("validate");
				}
				
			else if (element.name == "txtToLocation" && trim(element.value).length != 0 && document.rackForm.chkGroupedLocation.checked)
			{
				if (trim(document.rackForm.txtGroupedLocation.value).length != 0) 
				{	
					if (document.rackForm.chkHideError.checked) 
					{					
						addItemToRackList(trim(document.rackForm.txtTicketNumber.value ), "" ,  trim(document.rackForm.txtGroupedLocation.value),  trim(document.rackForm.txtToLocation.value));
						setFocusOnControl("ticketnumber");
						event.keyCode = 0;
					}
					else
					{
						storeItemsonForm(trim(document.rackForm.txtTicketNumber.value ), "" ,  trim(document.rackForm.txtGroupedLocation.value),  trim(document.rackForm.txtToLocation.value));
						submitForm("validate");
					}
				}
			}		
		}				
	}
	

	function captureKeyUpEvent(element){
		
		if (event.keyCode == 13){
			event.returnValue = true;	
					
			if (!checkforduplicateracks())
				return false;
	
			if (element.name == "txtTicketNumber" && trim(element.value).length != 0 )
			{
				if(document.rackForm.chkKeepRackNumber.checked && document.rackForm.txtRackLocation.value != "")
				{
					element = document.rackForm.txtRackLocation;
				}
				else
				{
					setFocusOnControl("racknumber")
				}
			}
			
			if (element.name == "txtRackLocation" && trim(element.value).length == 0  )		
				setFocusOnControl("chkGroupedLocation")	
			
			else if (element.name == "txtRackLocation" && trim(element.value).length != 0 && document.rackForm.chkHideError.checked)
				{
					addItemToRackList(trim(document.rackForm.txtTicketNumber.value) , trim(document.rackForm.txtRackLocation.value), "", "");
					setFocusOnControl("ticketnumber");
					document.rackForm.action = "?";
					document.rackForm.submit();
				}
			
			else if ((element.name == "txtRackLocation") && (trim(element.value).length != 0)  && !(document.rackForm.chkHideError.checked) )
				{
				storeItemsonForm(trim(document.rackForm.txtTicketNumber.value) , trim(document.rackForm.txtRackLocation.value), "", "");
				if(!document.rackForm.chkKeepRackNumber.checked)		
					document.rackForm.txtRackLocation.value = "";
				//setFocusOnControl("txtRackLocation");
				// by rahul to validate rack assignment
				submitForm("validate");
				// end of rack assignment validation
//				setFocusOnControl("ticketnumber");
				}
								
			else if (element.name == "txtGroupedLocation")		
				setFocusOnControl(element.name)					
				
			else if (element.name == "txtToLocation" && trim(element.value).length != 0 && document.rackForm.chkGroupedLocation.checked)
			{
				if (trim(document.rackForm.txtGroupedLocation.value).length != 0) 
				{	
					if (document.rackForm.chkHideError.checked) 
					{					
						addItemToRackList(trim(document.rackForm.txtTicketNumber.value ), "" ,  trim(document.rackForm.txtGroupedLocation.value),  trim(document.rackForm.txtToLocation.value));
						setFocusOnControl("ticketnumber");
						event.keyCode = 0;
					}
					else
					{
						storeItemsonForm(trim(document.rackForm.txtTicketNumber.value ), "" ,  trim(document.rackForm.txtGroupedLocation.value),  trim(document.rackForm.txtToLocation.value));
						submitForm("validate");
					}
				}
			}
		}		
	} 
	
	function gotfocus(element)
	{
		if (((document.rackForm.txtTicketNumber.value) != (document.rackForm.previousinvoicenumber.value)) && !(document.rackForm.chkHideError.checked))
			submitForm("getstatus");
	}
	
	
	function onRackClick(){
	
		if (!checkforduplicateracks())
				return false;
	
		if ( (! document.rackForm.chkGroupedLocation.checked) && (trim(document.rackForm.txtRackLocation.value).length > 0)  && !(document.rackForm.chkHideError.checked)  ) 
		{
			storeItemsonForm(document.rackForm.txtTicketNumber.value , document.rackForm.txtRackLocation.value, "", "");
			submitForm("validate");
		}
			
		else if ( document.rackForm.chkGroupedLocation.checked &&
				trim(document.rackForm.txtGroupedLocation.value).length > 0  &&
				trim(document.rackForm.txtToLocation.value).length > 0 && !(document.rackForm.chkHideError.checked)  )
		{
			storeItemsonForm(document.rackForm.txtTicketNumber.value , "" ,  document.rackForm.txtGroupedLocation.value,  document.rackForm.txtToLocation.value);
			submitForm("validate");			
		}
		
		if ( (! document.rackForm.chkGroupedLocation.checked) && (trim(document.rackForm.txtRackLocation.value).length > 0)  && (document.rackForm.chkHideError.checked)  ) 
		{
			addItemToRackList(document.rackForm.txtTicketNumber.value , document.rackForm.txtRackLocation.value, "", "");
		}
			
		else if ( document.rackForm.chkGroupedLocation.checked &&
				trim(document.rackForm.txtGroupedLocation.value).length > 0  &&
				trim(document.rackForm.txtToLocation.value).length > 0 && (document.rackForm.chkHideError.checked)  )
		{	
			addItemToRackList(document.rackForm.txtTicketNumber.value , "" ,  document.rackForm.txtGroupedLocation.value,  document.rackForm.txtToLocation.value);
		}
		
		document.rackForm.action = "?";
		document.rackForm.submit();
	}
	
	
	function setFocusOnControl(element){
	
		if (element == "ticketnumber"){ 
			document.rackForm.txtTicketNumber.focus();
			document.rackForm.txtTicketNumber.select();
		}
		
		else if (element == "txtRackLocation" || element == "racknumber") 
		{
				document.rackForm.txtRackLocation.focus();
		}
			
		else if (element == "chkGroupedLocation") {
			document.rackForm.txtGroupedLocation.value = "";
			document.rackForm.txtToLocation.value = "";	
			if (document.rackForm.chkGroupedLocation.checked)
				document.rackForm.txtGroupedLocation.focus()
			else
				document.rackForm.txtRackLocation.focus()
		}
		else if (element == "txtToLocation") 
			document.rackForm.txtRackLocation.focus()
			
		else if (element == "txtGroupedLocation") 
			document.rackForm.txtToLocation.focus()		
	}
			
	function storeItemsonForm(sInvoice, sRackloc, sRackstart, sRackend)
	{
		if (sInvoice == "")
			return false;
		document.rackForm.rackInvoice.value = sInvoice;

		if (sRackloc != "")
			document.rackForm.racklocation1.value = sRackloc;
			
		if (sRackstart != "")
			document.rackForm.racklocation2.value = sRackstart;

		if (sRackend != "")
			document.rackForm.racklocation3.value = sRackend;
						
		if (document.rackForm.chkGroupedLocation.checked)
			document.rackForm.rackchkGroup.value = 1;
	
		return true;
	}
	
	function addItemToRackList(sInvoice, sRackloc, sRackstart, sRackend){
		var newOption
		var i;
		
		if (sInvoice == "")
			return false;

		newOption = new Option();
		newOption.value =sInvoice + "|||" + sRackloc + "|||" + sRackstart + "|||" + sRackend
		newOption.text = sInvoice + "|||" + sRackloc + "|||" + sRackstart + "|||" + sRackend 
		
		document.rackForm.lstRackedItems.options.add(newOption, 0);
		
		if(!document.rackForm.chkKeepRackNumber.checked)		
			document.rackForm.txtRackLocation.value = "";
		document.rackForm.txtGroupedLocation.value = ""  ;
		document.rackForm.txtToLocation.value = "";
		document.rackForm.chkGroupedLocation.checked=false;
//		document.rackForm.txtticketnumber.focus();	
	}
			
	function cancelForm(){
		document.rackForm.action = "start.asp"
		document.rackForm.submit()
	}
	
	function deleteItems(){
		var i,j;
		var newOption;
		i = 0;
		j=document.rackForm.deletedRackedItems.length;
		
		if (document.rackForm.lstRackedItems.length > 0 ){
			while (i < document.rackForm.lstRackedItems.length ) {
				if (document.rackForm.lstRackedItems[i].selected )
					{
					newOption = new Option();
					newOption.value =document.rackForm.lstRackedItems.options[i].value;
					newOption.text = document.rackForm.lstRackedItems.options[i].text;
					document.rackForm.deletedRackedItems.options[j] = newOption;
					j++;		
					document.rackForm.lstRackedItems.options[i]=null;
					}
				else
				i++;
			}
		}	
	}
	
function removeInvoiceNumberFromRacks(invoicenumber) {
	var i;
	var dataitem;
	
	for(i = document.rackForm.lstRackedItems.length - 1;
		i >= 0;
		i--)
		{
			dataitem = 	document.rackForm.lstRackedItems.options[i].text.split("|||");

			if(dataitem[i] == invoicenumber)
				document.rackForm.lstRackedItems.options.remove(i);
		}
}


function checkforduplicateracks(){

	var i,j;
	var arr,dataitem;
	var invoicenumber1;
	var racklocationStart="";
	var racklocationFrom="";
	var racklocationTo="";
	var prevracklovation="";
	invoicenumber1 = document.rackForm.txtTicketNumber.value;
	racklocationFrom = document.rackForm.txtRackLocation.value;
	if (document.rackForm.chkGroupedLocation.checked){
		racklocationFrom = trim(document.rackForm.txtGroupedLocation.value);
		racklocationTo =  trim(document.rackForm.txtToLocation.value);
	}

	j = document.rackForm.lstRackedItems.length;

	for (i=0;i<j;i++){
		arr = document.rackForm.lstRackedItems.options[i].text;		
		dataitem = arr.split("|||");
		if (dataitem[0] == invoicenumber1) {											
			if (dataitem[1] == ""){
				if ((dataitem[2] == racklocationFrom) || (dataitem[3] ==racklocationFrom) || (dataitem[2] == racklocationTo) || (dataitem[3] ==racklocationTo) ){
					document.rackForm.txtTicketNumber.focus();
					document.rackForm.txtTicketNumber.select();
					return false;
				}
			}
			else{
				if (dataitem[2] == ""){
					if ((racklocationFrom == dataitem[1]) || (racklocationTo == dataitem[1])){
						document.rackForm.txtTicketNumber.focus();
						document.rackForm.txtTicketNumber.select();
						return false;
					}
				}
				else{
					if ((racklocationFrom == dataitem[1]) || (racklocationTo == dataitem[1]) || (racklocationFrom == dataitem[2]) || (racklocationTo == dataitem[2])){
						document.rackForm.txtTicketNumber.focus();
						document.rackForm.txtTicketNumber.select();
						return false;
					}				
				}			
			}				
		}	
	}
	return true;
}


</SCRIPT>
<BODY topmargin=0 leftmargin=0 
<%if (is_rack ) then %>
		onLoad = "setFocusOnControl('racknumber')"

<%else %>
		onLoad = "setFocusOnControl('ticketnumber')"
<%end if %>


>
<!-- #include file="../include/rackscanner.inc" -->
<!-- #include file="../include/banner.inc" -->

<FORM id="rackForm" name="rackForm" action="rack.asp" method=post>

<input type=hidden name="previousinvoicenumber" value=<%=ticketnumber%>>
<input type=hidden name="addtolist" value=<%=addtolist%>>
<input type=hidden name="rackInvoice" value="<%=rackInvoice%>">
<input type=hidden name="rackchkGroup" value=<%=rackchkGroup%>>
<input type=hidden name="racklocation1" value="<%=racklocation1%>">
<input type=hidden name="racklocation2" value="<%=racklocation2%>">
<input type=hidden name="racklocation3" value="<%=racklocation3%>">

	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
	<% if is_rack=false and len(trim(session("s_errMessage")) ) > 0 then %>
		<tr>
		<td width = 40px></td>
		<td width=40%><font color = red size =2 ><b><%= session("s_errMessage")%></b></font></td>
		
		<td></td>
		
	</tr>
	<% End if %>
	<tr>
		<td width = 40px></td>
		<!-- changed this to start as checked -- and then update accordingly as user entered-->
		<td ><input type=checkbox name=chkHideError id = chkHideError value = "1" STYLE="height=28px;width=28px;"
			<%if HideRackErrors = 1 then%>
				checked
			<% end if  %> 		 	 ><b>Hide Errors</b></td>
		<td>
		<input type=checkbox name=chkKeepRackNumber id = chkKeepRackNumber value="1" STYLE="height=28px;width=28px;"
			<%if UseSameRackLocation = 1 then%>
				checked
			<% end if  %>
		>
		<b>Use Same Rack Location</b>
		</td>
	</tr>
		<TR>
			<td></td>
			<TD class="label">Invoice Number</TD>
			<TD class="label">Invoice Status</TD>
		</TR>
		<TR>
			<td ></td>
			<TD><INPUT id=txtTicketNumber name="txtTicketNumber" class=text onKeydown="captureKeyDownEvent(this)" onKeyup="captureKeyUpEvent(this)"  value ="<%=Request.Form("txtTicketNumber")%>" ></TD>
			<!-- <onBlur = "focusOnBlur(this)" > -->
			<TD><INPUT id=txtTicketStatus name=txtTicketStatus class=text readonly value = "<%=s_invoicestatus%>"></TD>
		</TR>
		<TR>
			<td></td>
			<TD class="label">Rack Location</TD>
			<TD rowspan =6 >
			<select name="deletedRackedItems" id="deletedRackedItems" size="0" multiple style="width=0;font-size=16px">
			</select>
				<select name="lstRackedItems" id="lstRackedItems" size="10" multiple style="width=300;font-size=16px" >
				<%	dim listRack 
					dim sRackItem
					dim element
					dim arrtempelement
					set listRack =  Server.CreateObject("Scripting.Dictionary")
					
					if isobject(session("rackList"))  then
						if not session("rackList")is nothing then
							set listRack = session("rackList")
							if isobject(listRack) and not listRack is nothing then
								sRackItem = listRack.Keys
								for each element in sRackItem
								'arrtempelement= split(listRack(element),"|||")
						 %>	
									<option value = "<%=listRack(element)%>"><%=listRack(element)%></option>
								<% next	
							end if
						end if						
					end if
			%>
				</select>
			</TD>
		</TR>
		<TR>
			<td ></td>
			<TD>
				<INPUT type=text id=txtRackLocation name="txtRackLocation" class=text onfocus="gotfocus(this)" onKeydown="captureKeyDownEvent(this)" onKeyup="captureKeyUpEvent(this)"
				value="<%=Request.Form("txtRackLocation")%>"
				>
			</TD>
		</TR>
		<TR>
			<td ></td>
			<TD><Input type=checkbox name=chkGroupedLocation value="group" STYLE="height=28px;width=28px;" onClick="setFocusOnControl(this.name)"
			<% if lcase(Request.Form("chkGroupedLocation")) = lcase("group") then %>
				checked
			<%end if%>
			><b>Group Location</b></TD>
		</TR>
		<TR>
			<td ></td>
			<TD>
				<INPUT id=txtGroupedLocation name=txtGroupedLocation class=text onfocus="gotfocus(this)" onkeyDown="captureKeyDownEvent(this)" onkeyup="captureKeyUpEvent(this)" > 
			</TD>
		</TR>
		<TR>
			<td></td>
			<TD>
				<TABLE WIDTH="100%" BORDER=0>
					<TR>
						<TD align=center width =50% class="label">To</P></TD>
						<TD></TD>
					</TR>
				</TABLE>
			</TD>
		</TR>
		<TR>
			<td ></td>
			<TD>
				<INPUT id=txtToLocation name=txtToLocation class=text onfocus="gotfocus(this)" onKeydown="captureKeyDownEvent(this)" onkeyup="captureKeyUpEvent(this)">
			</TD>
		</TR>
		<TR>
			<td ></td>
			<td colspan=2>
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5>
					<tr>
						<td align=center>
							<!--<INPUT class=touch id=rack name=rack type=button value="" style="background-image=url(../images/hanger-2.gif)" onClick= "onRackClick()">
							<INPUT class=touch id=delete name=delete type=button value="" style="background-image=url(../images/Cancel-2.gif)" onClick="deleteItems()">-->
							<BUTTON class=std id=rack name=rack onClick= "onRackClick()"><img src="../images/hanger-2.gif"><br>Rack</BUTTON>
							<BUTTON class=std id=delete name=delete onClick="deleteItems()"><img src="../images/Cancel-2.gif"><br>Delete</button>
						</td>
					</tr><tr>	
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)" onfocus="gotfocus(this)" onClick="submitForm('done')">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()" value="">
						</td>
						<td width=150px></td>
					</tr>
				</table>
			</td>
		</TR>
	</TABLE>
</FORM>   

<script language="Javascript">
if (document.rackForm.addtolist.value == 1){
	if (trim(document.rackForm.racklocation1.value) ==""){
		addItemToRackList(document.rackForm.rackInvoice.value , "" ,  document.rackForm.racklocation2.value,  document.rackForm.racklocation3.value);
	}
	else{
		addItemToRackList(document.rackForm.rackInvoice.value , document.rackForm.racklocation1.value, "", "");
	}	
		document.rackForm.racklocation1.value = "";	
		document.rackForm.rackInvoice.value	= "";	
		document.rackForm.racklocation2.value = "";	
		document.rackForm.racklocation3.value = "";		
		document.rackForm.addtolist.value =0;	
}


</script>

<script language="javascript">
		var checkvalue;
		var alertMessage;
		<%
			if Len(alertMessage) > 0 then
				Response.Write "alertMessage='"
				Response.Write alertMessage
				Response.Write "'" 
			end if
		%>
//		var xx="" ;
//	
//		for (i in document.forms[0])
//		   xx += i + "\t" ;
//		  
		if (alertMessage != null){			
			checkvalue=confirm(alertMessage);			
			if (checkvalue ){
				if (trim(document.rackForm.racklocation1.value) == ""){	
					addItemToRackList(trim(document.rackForm.rackInvoice.value ), "" ,  trim(document.rackForm.racklocation2.value),  trim(document.rackForm.racklocation3.value) );
				}
				else{
					addItemToRackList(trim(document.rackForm.rackInvoice.value ), trim(document.rackForm.racklocation1.value),  "","" );
				}
			}
			document.rackForm.racklocation1.value = "";	
			document.rackForm.rackInvoice.value	= "";	
			document.rackForm.racklocation2.value = "";	
			document.rackForm.racklocation3.value = "";		
			document.rackForm.addtolist.value =0;
			alertMessage = null;			
		}
		
</script>
</BODY>

<%
	dim bPickup
	
	function validateRackAssignment()
		
		dim sqltxt
		dim rackcount
		dim i
		dim listRackMessage
		dim sInvoice
		dim srackStart
		dim srackEnd
		dim arrTemp
		dim rsTemp
		dim rsDelete
		dim sTicketnumber
		dim rsPickup
		dim usercount,str
		dim showerror,s_errmessage1
		
		s_errmessage1 = ""
		alertMessage = ""
		usercount = 0
		is_rack= false
		showerror = false
		l_error = false
		'set listRackMessage =  Server.CreateObject("Scripting.Dictionary")
		dbStartTrans()
	
		sInvoice = trim(request("rackinvoice"))
		srackStart = trim(request("racklocation1"))
			
		if srackstart = "" then
			srackStart = trim(request("racklocation2"))
			srackEnd = trim(request("racklocation3"))
		end if
			
		' Validate rack information
		sqltxt = "Exec dbo.ValidateRackAssignment " &  dbcreateQrystring(sInvoice) & " , " & dbcreateQrystring(srackStart)& " , " & dbcreateQrystring(srackEnd)& " , " &  session("employeeid") & " ," & session("storeid")
		
		set rstemp = getDisconnectedRecordsetwithTrans(sqltxt)
		
		if rsTemp.recordcount > 0 then
			if len(rsTemp("errorMessage")) > 0 then
				s_errmessage1 =  s_errmessage1 &  rstemp("errorMessage")  & _
								" Click OK button otherwise Click Cancel."
		'		listRackMessage.Add  Request.Form("lstRackedItems")(i)& i , Request.Form("lstRackedItems")(i) & "|||" & rstemp("errorMessage") & "|||" & rstemp("Disabled")
				l_error = true
			end if
		
			if rstemp("Disabled") = 0 then
				showerror = true
			else
'				s_errmessage1 = 	rstemp("errorMessage")
'				Response.Write  s_errmessage1
'				Response.End
				showerror = false
			end if
			
		end if
			
		rsTemp.close
		set rstemp = nothing
			
		if l_error and showerror then
			alertMessage = 	s_errmessage1		
		end if	
		
'		if l_error and not showerror then
'			session("s_errmessage") = 	s_errmessage1		
'		end if	

		if not l_error then		
			addtolist = 1
'			updateDatabaseHideErrorUnchcked()		
		end if
		s_errmessage1 = ""
	end function			
	
	Function getTicketStatus()
		dim sqltxt
		dim rsTemp
		session("s_errmessage") = ""
		is_rack= false
		s_invoicestatus = ""
		sqltxt = "select ticketStatus , onhold , invoicetype from ticket where  invoicenumber = " & dbcreateQryString(request.form("txtticketnumber"))
					
		set rsTemp = getdisconnectedRecordset(sqltxt)
		
		if rsTemp.recordcount > 0 then
			if rsTemp("onhold")  then
				session("s_errMessage") = "Invoice " & request.form("txtticketnumber")& " on Hold. It can not be Racked"
				session("rackList") = empty
			elseif rsTemp("invoicetype") <> "D" then
				session("s_errMessage") = "Invoice " & request.form("txtticketnumber")& " is not a detailed invoice."
				session("rackList") = empty
			elseif rsTemp("ticketStatus") = "FI" then
				session("s_errMessage") = "Invoice " & request.form("txtticketnumber")& " is Finished. It cannot be Racked further. "
				session("rackList") = empty
			elseif rsTemp("ticketStatus") = "AC" then
				s_invoicestatus = "Active"
				is_rack=  true
				session("s_errmessage") = ""
				
				' Display existing racks information 
				' modified by rahul 12/16/2002
	
				set listRack =  Server.CreateObject("Scripting.Dictionary")
					
				' modified by rahul on 17th feb 2003 to told previous rack values in the list
				dim usercount
				usercount  = 0 
				if not session("rackList")is nothing then					
					set listRack =  session("rackList")
					usercount = cint(ubound(listRack.keys)) + 1				
				end if					
				' end rahul
								
				dim str
				dim rsRack,i
				dim getinvoicelist,rackcount,arrTemp,sInvoice				
				
				' modified by rahul on 17th feb 2003 to preserve items in list box if hide error check box is unchecked
				' checking for existing invoice number
				getinvoicelist = true
				rackcount = cint(Request.Form("lstRackedItems").count)
				
				for i = 1 to rackcount	
					arrTemp = split( Request.Form("lstRackedItems")(i), "|||")
					sInvoice = trim(arrtemp(0))
					if trim(request.form("txtticketnumber")) = sInvoice then
							getinvoicelist = false
					end if
				next
				'end rahul
	
				if getinvoicelist then
					sqltxt = "exec dbo.GetRackAssignment " _
					& dbcreateqrystring(request.form("txtticketnumber"))		
		
					set rsRack = getdisconnectedRecordset(sqltxt)
				
					if rsRack.RecordCount > 0   then			
						while not rsRack.eof
							usercount  = usercount  + 1
							str = request.form("txtticketnumber") & "|||" &  rsRack("rackLocationStart").value & "|||" &  rsRack("rackLocationEnd").value & "|||"
							listRack.add usercount  , str
							rsRack.moveNext
						wend	
						set session("rackList") = listRack		
					end if
					rsRack.close
					set rsRack = nothing ' end of rack information display
				end if
			end if				
		else
			session("s_errmessage") =  "Invoice with Number "& request.form("txtticketnumber")&  " not found"
			' to prevent rack list for prevoius invoice ' rahul 06/03/2003 
			'session("rackList") = empty
		end if
							
		rsTemp.close
		set rstemp = nothing
	
	end function


	function saveData()
		dim i 
		dim	arrlist	
		set arrList =  Server.CreateObject("Scripting.Dictionary")
		for i =  1 to Request.Form("lstRackedItems").count
			arrList.Add i, Request.Form("lstRackedItems")(i)
		next
		
		set session("rackList")= nothing
		set session("rackList")= arrlist
	end function
	
' update database when hide error check box is Unchecked.		
	function updateDatabase()
		dim sqltxt
		dim rackcount
		dim i
		dim listRackMessage
		dim sInvoice
		dim srackStart
		dim srackEnd
		dim arrTemp
		dim rsTemp
		dim rsDelete
		dim sTicketnumber
		dim rsPickup
	
		' get pickup notification to send emails
		sqltxt = "select notifypickup from miscsetup where storeid = " & session("storeid")
	
		set rsPickup = getdisconnectedrecordset(sqltxt)
		if rspickup.recordcount > 0 then
			if rspickup("notifypickup") then
				bpickup= 1
			end if
		end if
		rsPickup.close
			
		set rspickup = nothing
		
		set listRackMessage =  Server.CreateObject("Scripting.Dictionary")
'		rackcount = Request.Form("lstRackedItems").count
		rackcount = Request.Form("deletedRackedItems").count	
'
		if rackcount <> 0 then
			for i = 1 to rackcount			
				if request("chkHideError") <> 1 then
					arrTemp = split( Request.Form("deletedRackedItems")(i), "|||")
					sInvoice = trim(arrtemp(0))
					'response.write "sInvoice : " & sInvoice
					sqltxt = "Exec dbo.DeleteRackAssignment " &  dbcreateQrystring(sInvoice)
					set rsDelete = getdisconnectedrecordset(sqltxt)
				end if		
			next
		end if
		
		set listRackMessage =  Server.CreateObject("Scripting.Dictionary")
		rackcount = Request.Form("lstRackedItems").count
		
		' Delete racks for exising invoice
		' Modified by rahul bhargava on 16/12/2002
		
		if rackcount <> 0 then
			for i = 1 to rackcount			
				if request("chkHideError") <> 1 then
					arrTemp = split( Request.Form("lstRackedItems")(i), "|||")
					sInvoice = trim(arrtemp(0))
					sqltxt = "Exec dbo.DeleteRackAssignment " &  dbcreateQrystring(sInvoice)
					set rsDelete = getdisconnectedrecordset(sqltxt)
				end if
			next
		else
			if request("chkHideError") <> 1 then
					sqltxt = "Exec dbo.DeleteRackAssignment " &  dbcreateQrystring(request("txtticketnumber"))
					set rsDelete = getdisconnectedrecordset(sqltxt)			
			end if
		end if
				
	' delete rack  end
	
		dim lstEmailInvoice 
	
		set lstEmailInvoice = Server.CreateObject("Scripting.Dictionary")
	
		dbStartTrans()
	
		for i = 1 to rackcount
	
			arrTemp = split( Request.Form("lstRackedItems")(i), "|||")
			sInvoice = trim(arrtemp(0))
			srackStart = trim(arrtemp(1))
			srackEnd = trim(arrtemp(2))
			if srackstart = "" then
				srackStart = trim(arrtemp(2))
				srackEnd = trim(arrtemp(3))
			end if
			
			' insert rack information
			sqltxt = "Exec dbo.InsertRackAssignment " &  dbcreateQrystring(sInvoice) & " , " & dbcreateQrystring(srackStart)& " , " & dbcreateQrystring(srackEnd)& " , " &  session("employeeid") & " ," & session("storeid")
			
			set rstemp = getDisconnectedRecordsetwithTrans(sqltxt)
			if rsTemp.recordcount > 0 then
				if len(rsTemp("errorMessage")) > 0 then
					listRackMessage.Add  Request.Form("lstRackedItems")(i)& i , Request.Form("lstRackedItems")(i) & "|||" & rstemp("errorMessage") & "|||" & rstemp("Disabled")
					l_error = true
				else 
					lstEmailInvoice.Add sInvoice & i , sInvoice 
					' send email code if picup notification is set to 1
				end if
			end if
			
			rsTemp.close
			set rstemp = nothing			
		next 
	
		dbendtrans()	
		set session("listRackMessage")= nothing
		set session("listRackMessage")= listRackMessage

		if bpickup =  1 then
			sendOrderEmail  lstEmailInvoice
		end if
	end function
	
' update database when hide error check box is UNchecked.	
	
		function updateDatabaseHideErrorUnChecked()
		dim sqltxt
		dim rackcount
		dim i
		dim listRackMessage
		dim sInvoice
		dim srackStart
		dim srackEnd
		dim arrTemp
		dim rsTemp
		dim rsDelete
		dim sTicketnumber
		dim rsPickup
	
		' get pickup notification to send emails
		sqltxt = "select notifypickup from miscsetup where storeid = " & session("storeid")
	
		set rsPickup = getdisconnectedrecordset(sqltxt)
		if rspickup.recordcount > 0 then
			if rspickup("notifypickup") then
				bpickup= 1
			end if
		end if
		rsPickup.close
	
		set rspickup = nothing
		
		set listRackMessage =  Server.CreateObject("Scripting.Dictionary")
'		rackcount = Request.Form("lstRackedItems").count
		rackcount = Request.Form("deletedRackedItems").count	
'
		if rackcount <> 0 then
			for i = 1 to rackcount			
				if request("chkHideError") <> 1 then
					arrTemp = split( Request.Form("deletedRackedItems")(i), "|||")
					sInvoice = trim(arrtemp(0))
					'response.write "sInvoice : " & sInvoice
					sqltxt = "Exec dbo.DeleteRackAssignment " &  dbcreateQrystring(sInvoice)
					set rsDelete = getdisconnectedrecordset(sqltxt)
				end if
			next
		end if		

		set listRackMessage =  Server.CreateObject("Scripting.Dictionary")
		rackcount = Request.Form("lstRackedItems").count

		
		' Delete racks for exising invoice
		' Modified by rahul bhargava on 16/12/2002
		
		if rackcount <> 0 then
			for i = 1 to rackcount			
				if request("chkHideError") <> 1 then
					arrTemp = split( Request.Form("lstRackedItems")(i), "|||")
					sInvoice = trim(arrtemp(0))
					sqltxt = "Exec dbo.DeleteRackAssignment " &  dbcreateQrystring(sInvoice)
					set rsDelete = getdisconnectedrecordset(sqltxt)
				end if		
			next
		else
			if request("chkHideError") <> 1 then
					sqltxt = "Exec dbo.DeleteRackAssignment " &  dbcreateQrystring(request("txtticketnumber"))
					set rsDelete = getdisconnectedrecordset(sqltxt)			
			end if
		end if
		
	' delete rack  end
		dim lstEmailInvoice 
		set lstEmailInvoice = Server.CreateObject("Scripting.Dictionary")
		if rackcount <> 0 then
			dbStartTrans()
		for i = 1 to rackcount
			arrTemp = split( Request.Form("lstRackedItems")(i), "|||")
			sInvoice = trim(arrtemp(0))
			srackStart = trim(arrtemp(1))
			srackEnd = trim(arrtemp(2))
			if srackstart = "" then
				srackStart = trim(arrtemp(2))
				srackEnd = trim(arrtemp(3))
			end if
			
			' insert rack information
			sqltxt = "INSERT INTO RackAssignment ([ticketNumber], [rackLocationStart], [rackLocationEnd], [rackedEmployeeID], [rackedDate],[storeID]) select  ticketnumber " _
						& "," & dbcreateqrystring(srackstart)_
						& "," & dbcreateqrystring(srackend)_
						& "," & session("employeeid")_
						& ", getdate()"_
						& " ," & session("storeid")_
						& " from ticket where invoicenumber = " & dbcreateqrystring(sInvoice)

			qryexecutewithtrans(sqltxt)
			lstEmailInvoice.Add sInvoice & i , sInvoice 
		next 
		dbendtrans()			
		end if

		if bpickup =  1 then
			sendOrderEmail  lstEmailInvoice
		end if
	end function
	
	function sendOrderEmail(lstEmailInvoice )
	
	dim sqltxt 
	dim rsEmail
	dim sEmailToAddress
	dim sEmailToName
	dim sEmailMessage
	dim sEmailSubject
	dim sEmailFrom
	dim sEmailFromAddress
	dim sInvoice
	dim listKeys
	dim element
	dim sCCName
	dim sCCAddress
	dim sBccName
	dim sBccAddress
	dim sAttachment1
	dim sAttachment2
	
	sAttachment2= ""
	sAttachment1 = ""
	sBccAddress = ""
	sBccName = ""
	sCCName = ""
	sccAddress = ""
	sEmailFrom = "Shahcorp"
	sEmailFromAddress = "Shahcorp"
	sEmailSubject = "Order Pickup Notification"
	
	listKeys = lstEmailInvoice.keys
	
	for each element in listKeys
	
		sinvoice = lstEmailInvoice(element)
		sqltxt = "select c.email, p.emailtext, c.Customername, t.invoicenumber from  " _
					& "ticket t , pricelist  p , customer c  where t.invoicenumber = " & dbcreateqrystring(trim(sInvoice)) _
					 & " and t.pricelistid = p.pricelistid and t.customersequencenumber = c.customersequencenumber " _
					 & " and  p.emailtext is not null and c.email is not null"
	
		set rsEmail = getDisconnectedRecordset(sqltxt)
		if rsEmail.recordcount > 0 then
			sEmailToAddress = rsEmail("email")	
			sEmailToName = rsEmail("Customername")
			sEmailMessage = rsEmail("emailtext")	
			sEmailSubject = sEmailSubject & " for Invoice Number: " & rsEmail("invoicenumber")
			CBSSendMail sEmailFrom, sEmailFromAddress, sEmailToName, sEmailToAddress, sCCName, sccAddress, sBccName, sBccAddress, sEmailSubject, sEmailMessage, sAttachment1, sAttachment2
		end if
		rsEmail.close
		set rsEmail = nothing
		next 
	end function	
%>


</HTML>