<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/validatefunction.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("action")%>
<%
	dim query, rs
	dim isSubmitted
	dim lotid
	dim action
	dim dayrange
	dim show
	dim showclosed
	dim datebegin
	dim dateend
	
	datebegin = Request.Form("datebegin")
	dateend = Request.Form("dateend")
	
	if datebegin = "" then datebegin = Date()
	if dateend = "" then dateend = Date()

	isSubmitted = Request.QueryString("Submitted")
	if isSubmitted then
		lotid = Request.QueryString("lotNumber")
		action = Request.QueryString("action")
		updateDatabase()
	end if

	function updateDatabase()
		dim sqltxt
		dim useLotsForAssy
		dim conveyorType
		dim rs

		if (action = "close") then
			sqltxt = "update Lot set status = 'C', dateclosed = getdate() where currentgarments >= mingarments and id = "+lotid
			QryExecute(sqltxt)

			sqltxt = "select useLotsForAssembly, conveyorType from miscsetup"
			set rs = getdisconnectedrecordset(sqltxt)
			if rs.recordcount > 0 then
				useLotsForAssy = rs("useLotsForAssembly")
				conveyorType = rs("conveyorType")
			end if

			set rs=nothing
			if useLotsForAssy then
				if conveyorType = "MP" then
					sqltxt = "exec sendLotToMP " + lotid
					QryExecute(sqltxt)
				elseif conveyorType = "IT" then
					sqltxt = "exec sendLotToItacs " + lotid
					QryExecute(sqltxt)
				end if
			end if
		end if
	end function

	function floor(x)
		dim temp

		temp = Round(x)

		if temp > x then temp = temp - 1
	
		floor = temp
	End Function

	function formatAge(minutes)
		dim hours
		dim days

		days = floor(minutes / 1440)
		hours = floor((minutes mod 1440) / 60)
		minutes = floor(minutes mod 60)
		
		if days > 0 then formatAge = formatAge & " " & days & " days"
		if hours > 0 then formatAge = formatAge & " " & hours & " hours"
		if minutes > 0 then formatAge = formatAge & " " & minutes & " minutes"
		if formatAge = "" then formatAge = "brand new"
	end function
	

%>
<HTML>
<HEAD>
<TITLE>Lot Manager</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">
  var selectedLot = null;
  var previousElement = null;
  var currentGarments = null;
  var minGarments = null;
  

	
	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}
		selectedLot = element.getAttribute("lotID");
		currentGarments = element.getAttribute("currentGarments");
		minGarments = element.getAttribute("minGarments");
		
		previousElement = element;
		
		element.className = "selected";

	}


	function submitForm(element) {
		if (element == "cancel") {
			document.lotManager.action="toolsMenu.asp";
			document.lotManager.submit();
		}
		else if (element == "OpenLot") {
	        document.lotManager.action="../setup/lots.asp";
			document.lotManager.submit();
		}
		else {


	           if (selectedLot == null) {
	                 alert("Please choose one lot before pressing action button.")
	           }
	           else {

	                 switch (element){
	                       case "BurstLot":
	                             break;
	                       case "OpenLot":
	                             document.lotManager.action="../setup/lots.asp";
	                             document.lotManager.submit();
	                             break;
	                       case "CloseLot":
	                       			if(parseInt(currentGarments) < parseInt(minGarments)) {
		                       			cbs_alert('Lot needs at least ' + minGarments + ' garments before it may be closed.');
		                       			return false;
	                       			}
	                       			cbs_confirm("Close lot?", closeLot);
	                             break;
	                       case "EditLot":
	                             document.lotManager.action="../setup/lots.asp?lotID=" + selectedLot;
	                             document.lotManager.submit();
	                             break;
	                       case "cancel":
	                             document.lotManager.action="toolsMenu.asp";
	                             document.lotManager.submit();
	                             break;
	                 }
	           }

	           
	      }
	}

	function closeLot() {
        clearConfirmMsg();
        document.lotManager.action="?Submitted=true&lotNumber=" + selectedLot + "&action=close";
        document.lotManager.submit();
	}

	function viewLot(lotID) {
  	    document.lotManager.action = "/mainapp/lotdetails.asp?lotID=" + lotID;
		document.lotManager.submit();
	}
	
	function submit_filter() {
		document.lotManager.action = "";
		document.lotManager.submit();
	}
	

</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Lot Manager</H1>
<FORM id="lotManager" name="lotManager" action="LotManager.asp" onsubmit="return false" Method = "post">
	<INPUT type=hidden name=isSubmitted value=<%=isSubmitted%>>

	

<div name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<span style="float:left">
	  <button name="OpenLot" onClick="submitForm(this.name)" >New</button>
	  <button name="EditLot" onClick="submitForm(this.name)" >Edit</button>
	  <button name="ViewLot" onClick="viewLot(selectedLot)" >View</button>
	  
		<button name="CloseLot" onClick="submitForm(this.name)" >Close</button>
		
	</span>
	<span style="float:right">
      <button name="cancel" onClick="submitForm(this.name)">Exit</button>
	</span>
</div>	

<div style="height:200px; overflow: auto">

<table class="itable" BORDER=0 CELLSPACING=0 CELLPADDING=0 style="font-size:16">
	<tr align=center>
	  <th width=100px align=center>Status</th>
		<th width=100px align=center>Name</th>
		<th width=75px align=center>Number</th>
		<th width=100px align=center>Color</th>
		<th width=100px align=center>Size</th>
		<th width=100px align=center>Current</th>
		<th width=100px align=center>Open</th>
		<th width=100px align=center>Pieces<br>Not Racked</th>
		<th width=100px align=center>Invoices<br>Not Racked</th>
		<th width=250px align=center>Date Opened</th>
		<th width=100px align=center>Age</th>
	</tr>


	<%

		query = "select distinct lot.*,"
		query = query & " dbo.getLotHexColor(lot.color, lot.lotdefaultid) as colorcode, "
		query = query & " dbo.getCountNotDoneLots(lot.id,'PCS') as pieces, dbo.getCountNotDoneLots(lot.id,'INV') as invoices, dbo.pivotLotDepts(lot.id,',') as depts "
		query = query & " , datediff(minute, dateopened, isnull(dateclosed, getdate())) as age "
		query = query & " from lot "
		query = query & "	where status = 'O' or status is null order by lot.id"
		
		set rs = getdisconnectedrecordset(query)

		while not(rs.eof or rs.bof)
	%>
	<tr align=left onclick="selectRow(this);" height=25px lotID="<%=rs("id")%>" currentGarments="<%=rs("CurrentGarments")%>" minGarments="<%=rs("MinGarments")%>" >
	  <td align=center width=100px>Open</td>
		<td align=center width=100px><%=rs("Name")%></td>
		<td align=center width=75px><%=rs("Number")%> </td>
		<td align=center width=100px bgcolor="<%=rs("colorcode")%>"><b><%=rs("Color")%></b></td>
		<td align=center width=100px><%=rs("MaxGarments")%> </td>
		<td align=center width=100px><%=rs("CurrentGarments")%> </td>
		<td align=center width=100px><%=rs("MaxGarments")-rs("CurrentGarments")%> </td>
		<td align=center width=100px><%=rs("pieces")%></td>
		<td align=center width=100px><%=rs("invoices")%></td>
		<td align=center width=250px><%=rs("DateOpened")%> </td>
		<td align=center width=100px><%=formatAge(rs("age"))%></td>
		<INPUT type=hidden name=status id=status value="<%=rs("status")%>">

	</tr>
	<%
		rs.movenext
		wend

		set rs = nothing
	%>
</table>
</div>



<input name="datebegin" value="<%=datebegin%>" style="width: 80px; text-align: center" onclick="javascript:show_calendar('lotManager.datebegin');" readonly>
<input name="dateend" value="<%=dateend%>" style="width: 80px; text-align: center" onclick="javascript:show_calendar('lotManager.dateend');" readonly>
<input type="button" value="Search" onclick="submit_filter()">

<br>

<div style="height:300px; overflow: auto">
<table class="itable" BORDER=0 CELLSPACING=0 CELLPADDING=0 style="font-size:16">
	<tr align=center>
	  <th width=100px align=center>Status</th>
		<th width=100px align=center>Name</th>
		<th width=75px align=center>Number</th>
		<th width=100px align=center>Color</th>
		<th width=100px align=center>Size</th>
		<th width=100px align=center>Current</th>
		<th width=100px align=center>Open</th>
		<th width=100px align=center>Pieces<br>Not Racked</th>
		<th width=100px align=center>Invoices<br>Not Racked</th>
		<th width=250px align=center>Date Opened</th>
		<th width=100px align=center>Age</th>
	</tr>
	
	<%

		query = "select lot.*, dbo.getTotalLotPieces(lot.id) as maxGarments, "
		query = query & " dbo.getLotHexColor(lot.color, lot.lotdefaultid) as colorcode, "
		query = query & " dbo.getCountNotDoneLots(lot.id,'PCS') as pieces, dbo.getCountNotDoneLots(lot.id,'INV') as invoices, dbo.pivotLotDepts(lot.id,',') as depts "
		query = query & " , datediff(minute, dateopened, isnull(dateclosed, getdate())) as age "
		query = query & " from lot "
		query = query & " where (status = 'C' or status is null)"
		
		
		if datebegin <> "" then
			query = query & " and datediff(day, dateclosed, '" & datebegin & "') <= 0"
		end if
		
		if dateend <> "" then
			query = query & " and datediff(day, dateclosed, '" & dateend & "') >= 0"
		end if
		
		query = query & " order by dateclosed desc, lot.id"

		set rs = getdisconnectedrecordset(query)

  
		while not(rs.eof or rs.bof)
	%>
	<tr align=center style="background: f3f3f3">
	  <td align=center width=100px>Closed</td>
		<td align=center><button style="height:40px;width:120px" value="" onclick="viewLot(<%=rs("id")%>)"><%=rs("Name")%></button></A></td>
		<td align=center><%=rs("Number")%> </td>
		<td width=100px align=center bgcolor=<%=rs("colorcode")%> ><b><%=rs("color")%></b></td>
		<td align=center><%=rs("maxGarments")%> </td>
		<td align=center>-</td>
		<td align=center>-</td>
		<td align=center><%=rs("pieces")%></td>
		<td align=center width=100px><%=rs("invoices")%></td>
		<td align=center><%=rs("DateClosed")%> </td>
		<td align=center width=100px><%=formatAge(rs("age"))%></td>
		<INPUT type=hidden name=status id=status value="<%=rs("status")%>">

	</tr>
	<%
		rs.movenext
		wend

		set rs = nothing
	%>
</table>
</div>

</FORM>
</BODY>
</HTML>