<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	'******************************************************************************
	'Name   : SearchResults.asp
    '==============================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------------
    ' 09-Sep-2003	 Johnston		Increased font size in select table
    '******************************************************************************

	dim actionString
	dim dosearch
	dim objresult  
	dim l_routeid
	dim l_lastname 
	dim l_phonenumber
	dim routeFilter
	
	session("showInactiveInvoices") = false
	actionString = trim(Request.QueryString("targetPage"))
	L_routeid =  trim(Request.QueryString("Routeid"))
	routeFilter = trim(Request.QueryString("routeFilter"))
	getSearchResult()
%>

<HTML>
<HEAD>
<TITLE>Customer Search</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">

	<SCRIPT LANGUAGE=javascript>
	var lastFocusControl;
	var previousElement=null;
	var x;
	var vshowNotes;
	<!--
				
		function selectRow(element) {
			var childEl;
			if (previousElement !=null){
				previousElement.className="";
			}
			childEl = element.children[0];
			var rowChildNodes = childEl.children
			for(i=0; i<rowChildNodes.length; i++){
				childEl = rowChildNodes[i];
				if (childEl.name == "selectid") {
					x = childEl.value;
				}
				if (childEl.name == "showNotes") {
					vshowNotes = childEl.value;
				}
			 
				/*	if(childEl.tagName == "INPUT") {
					childEl.checked=true;
					break;
				}  */
			}
			previousElement =element;
			element.className = "selected";
			document.searchResults.selectButton.disabled= false;
		}
		
		
	//-->
	
/*	function addNewCustomer(){
		document.searchResults.action ="customerEntry.asp";
		document.searchResults.submit();
	}
	
	function searchCustomer(){
		document.searchResults.action ="searchresults.asp?userAction=" + document.searchResults.targetPage.value;
		document.searchResults.submit();
	} */
	
	function addNewCustomer(){
		if(document.searchResults.lastName.value != "")
			document.searchResults.action =document.searchResults.action + "customerentry.asp" + "?mode="+ "add" + "&lastname=" + escape(document.searchResults.lastName.value) ;
		else if(document.searchResults.phoneNumber.value != "")
			document.searchResults.action =document.searchResults.action + "customerentry.asp" + "?mode="+ "add" + "&phone=" + escape(document.searchResults.phoneNumber.value) ;
		else if(document.searchResults.smartsearch.value != "")
			document.searchResults.action =document.searchResults.action + "customerentry.asp" + "?mode="+ "add" + "&lastname=" + escape(document.searchResults.smartsearch.value) ;
		else
			document.searchResults.action =document.searchResults.action + "customerentry.asp" + "?mode="+ "add";
		
		document.searchResults.submit();
	}
	
	function selectCustomer(){
		var strtarget
		
		strtarget = document.searchResults.targetPage.value		
		
		straction = "?targetpage=" + strtarget +  "&customerseq=" + x + "&routeid=" +document.searchResults.routeid.value ;
		if (vshowNotes == "True" && document.searchResults.targetPage.value != "commonbilling") {
				document.searchResults.action = "CustomerNotes.asp" + straction
				document.searchResults.submit();
		}
		else{
			if (document.searchResults.targetPage.value=="CustomerFunctions") {
				document.searchResults.action = "CustomerFunctions.asp?customerseq=" + x;
				document.searchResults.submit();
			}
			else if (document.searchResults.targetPage.value=="route") {
				document.searchResults.action = "/setup/RouteAddEdit.asp?mode=edit&customerseq=" + x + "&routeid=" +document.searchResults.routeid.value ;
				document.searchResults.submit();	
			}
			else  if (document.searchResults.targetPage.value =="applypayments") {
				document.searchResults.action = "/mainapp/ApplyPayments.asp?customerseq=" + x;
				document.searchResults.submit();
			}
			else  if (document.searchResults.targetPage.value =="issuecharge") {
				document.searchResults.action = "/mainapp/issueCreditOrCharge.asp?customerseq=" + x;
				document.searchResults.submit();
			}
			else  if (document.searchResults.targetPage.value =="runstatements") {
				document.searchResults.action = "/mainapp/runStatements.asp?customerseq=" + x;
				document.searchResults.submit();
			}
			else  if (document.searchResults.targetPage.value =="scheduledelivery") {
				document.searchResults.action = "/mainapp/scheduleDelivery.asp?customerseq=" + x;
				document.searchResults.submit();
			}
	
			// Start: Added by Vinny on 05-Nov-2002
			else  if (document.searchResults.targetPage.value =="reportParams") {
				document.searchResults.action = "/mainapp/reportParams.asp?customerSequenceNumber=" + x;
				document.searchResults.submit();
			}
			// End : Added by Vinny on 05-Nov-2002
			
			else if (document.searchResults.targetPage.value == "issueSingleGiftCard") {
				document.searchResults.action = "/mainapp/issueSingleGiftCard.asp?userAction=initialize&customerSequenceNumber=" + x;
				document.searchResults.submit();
			}
			
			else if (document.searchResults.targetPage.value == "issueMultiToCust") {
				document.searchResults.action = "/mainapp/issueMultiToCust.asp?userAction=initialize&customerSequenceNumber=" + x;
				document.searchResults.submit();
			}	
			else if (document.searchResults.targetPage.value == "customerdiscount") {
				document.searchResults.action =  "/mainapp/customerdiscount.asp?targetpage=customerentry&customerseq=<%=session("prevcustomersequencenumber")%>&referredby=" + x;
				document.searchResults.submit();
			}	
			else if (document.searchResults.targetPage.value == "commonbilling") {
				document.searchResults.action =  "/mainapp/customerpayment.asp?targetpage=customerentry&customerseq=<%=session("prevcustomersequencenumber")%>&billingcustomerseq=" + x;
				document.searchResults.submit();
			}	
			else if (document.searchResults.targetPage.value == "parentcustomer") {
				document.searchResults.action =  "/mainapp/customerpayment.asp?targetpage=customerentry&customerseq=<%=session("prevcustomersequencenumber")%>&parentcustomerseq=" + x;
				document.searchResults.submit();
			}	
			else if (document.searchResults.targetPage.value == "routesetup") {
				document.searchResults.action =  "/setup/routeSetup.asp?userAction=adddelivery&customerseq=" + x;
				document.searchResults.submit();
			}	
			else if (document.searchResults.targetPage.value == "customermanagement") {
				document.searchResults.action =  "/mainapp/customermanagement.asp?customerseq=" + x;
				document.searchResults.submit();
			}	
		}
	}
	
	function cancelForm(){
		if (document.searchResults.targetPage.value=="CustomerFunctions") {
				document.searchResults.action = "CustomerSearch.asp";
				document.searchResults.submit();
			}
			else if (document.searchResults.targetPage.value=="route") {
				document.searchResults.action = "/setup/Routes.asp";
				document.searchResults.submit();	
			}
			else  if (document.searchResults.targetPage.value =="applypayments") {
				document.searchResults.action = "/mainapp/accountMgmt.asp";
				document.searchResults.submit();
			}
			else  if (document.searchResults.targetPage.value =="issuecharge") {
				document.searchResults.action = "/mainapp/accountMgmt.asp";
				document.searchResults.submit();
			}
			else  if (document.searchResults.targetPage.value =="runstatements") {
				document.searchResults.action = "/mainapp/accountMgmt.asp";
				document.searchResults.submit();
			}
			else  if (document.searchResults.targetPage.value =="scheduledelivery") {
				document.searchResults.action = "/mainapp/routesMenu.asp";
				document.searchResults.submit();
			}
			else if (document.searchResults.targetPage.value=="routesetup") {
					document.searchResults.action = "/setup/routeSetup.asp";
					document.searchResults.submit();
			}
			// Start: Added by Vinny on 05-Nov-2002
			else  if (document.searchResults.targetPage.value =="reportParams") {
				document.searchResults.action = "Customersearch.asp?userAction=reportParams";
				document.searchResults.submit();
			}
			else if (document.searchResults.targetPage.value=="customermanagement") {
					document.searchResults.action = "/mainapp/customermanagement.asp?customerseq=<%=session("prevcustomersequencenumber")%>";
					document.searchResults.submit();
			}
			// End: Added by Vinny on 05-Nov-2002
			else if (document.searchResults.targetPage.value=="customerdiscount") {
					document.searchResults.action = "/mainapp/customerdiscount.asp?targetpage=customerentry&customerseq=<%=session("prevcustomersequencenumber")%>";
					document.searchResults.submit();
			}
			else if (document.searchResults.targetPage.value=="commonbilling") {
					document.searchResults.action = "/mainapp/customerpayment.asp?targetpage=customerentry&customerseq=<%=session("prevcustomersequencenumber")%>";
					document.searchResults.submit();
			}
			else if (document.searchResults.targetPage.value=="parentcustomer") {
					document.searchResults.action = "/mainapp/customerpayment.asp?targetpage=customerentry&customerseq=<%=session("prevcustomersequencenumber")%>";
					document.searchResults.submit();
			}
			else {
				document.searchResults.action = "customersearch.asp";
				document.searchResults.submit();
			}
		
	
	}
	
	
	function goToSearch(){
		document.searchResults.action ="customersearch.asp";
		document.searchResults.submit();
	}
	
	function captureKeyUpEvent(element){
		
	  	if (event.keyCode == 13){
	  		event.returnValue = true;	
			selectCustomer();
		}
	}
	
</SCRIPT>
</HEAD>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Customer Search Results</H1>
<br><br>

<TABLE width="100%"  align=center cellspacing="0" cellpadding="0" border="0">
 <FORM id="searchResults" name="searchResults" action="" method="Post">
		<input type=hidden name="lastName" value="<%=Server.HTMLEncode(l_lastname)%>">
		<input type=hidden name="phoneNumber" value="<%=l_phonenumber%>">
		<INPUT type="hidden" name="targetPage" value="<%= actionString %>">
		<INPUT type="hidden" name="routeid" value="<%=l_routeid %>">
		<INPUT type="hidden" name="smartsearch" value="<%=trim(Server.HTMLEncode(Request.QueryString("smartsearch")))%>">
<tr  class="cmdbar">
	<td>
		<div>
			<span style="float:right">
				<button id=cancelButton name=cancelButton onClick="cancelForm()">Cancel</button>
			</span>
		</div>
	<td>
</tr>
<TR style="background:white;">
   <TD>
		<TABLE class="itable" align=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0>
			<TR>
				<TH style="width: 25%">Customer Name</TH>
				<TH style="width: 15%">Phone</TH>
				<TH style="width: 25%">Address</TH>
				<TH style="width: 15%">City</TH>
				<TH style="width: 20%">Route</TH>
			</TR>
			<%
				'Response.Write " going to reterived results "
				
				if objresult.recordcount <=0 then %>
			<TR>
				<TD colspan="5" align="center">Search criteria could not find any matching customers</TD>
			</TR>
			<%	else
			
				while not objresult.EOF
							
			%>
			<!-- Following lines modified by J.Johnston, 9Sep03-->
			<!-- Added FONT-SIZE: 18px;-->
			<TR onDblClick="selectRow(this);selectCustomer();" onClick="selectRow(this)" onKeyPress="captureKeyUpEvent(this)" >
				<TD valign="center" style="padding-left:10px;text-align:left;FONT-SIZE: 18px;"><input type="hidden" name="selectid" id="selectid" style="Height=25px;Width=25px" value="<%=objresult("customersequencenumber")%>">
					<input type="hidden" name="showNotes" id="showNotes" style="Height=25px;Width=25px" value="<%=objresult("showNotesOnEachAccess")%>">
				
				
				<%=Server.HTMLEncode(objresult("customername"))%>&nbsp</TD>
				<TD style="padding-left:10px;text-align:center;FONT-SIZE: 18px;"><%=formatareacode(objresult("mainareacode")) & formatphone(objresult("mainphone"))%>&nbsp</TD>
				<TD style="padding-left:10px;text-align:center;FONT-SIZE: 18px;"><%=objresult("shippingaddress1")%>&nbsp</TD>
				<TD style="padding-left:10px;text-align:center;FONT-SIZE: 18px;"><%=objresult("shippingCity")%>&nbsp</TD>
				<TD style="padding-left:10px;text-align:center;FONT-SIZE: 18px;"><%=objresult("routeName")%>&nbsp</TD>
				
			</TR>
			<!-- End modification by J.Johnston, 9Sep03-->
			<%
				objresult.movenext
				wend
				objresult.close
				set objresult = nothing
				end if
			%>
									
		</TABLE>
		<!-- </div> -->
		
		<BR>
	</TD>
</TR>
<tr  class="cmdbar">
	<td>
		<div>
			<span style="float:left">
				<button id=selectButton name=selectButton disabled onClick="selectCustomer()">Select</button>
			</span>
			
			<span style="float:right">
				<button id=newCustomerButton name=newCustomerButton   onClick= "addNewCustomer()" >New<br>Customer</button>
			</span>
		</div>
	<td>
</tr>
</FORM>   
</TABLE>

</BODY>
</HTML>
<% 


	function AppendCustomerSeqs(current, rs)
	
		AppendCustomerSeqs = current
		
		if rs.recordcount > 0 then
			rs.movefirst
			while not rs.eof
				if AppendCustomerSeqs <> "" then
					AppendCustomerSeqs = AppendCustomerSeqs & ","
				end if
				AppendCustomerSeqs = AppendCustomerSeqs & rs("customersequencenumber")
				rs.movenext
			wend
		end if

	end function
	
	function getCustomerFilter(custIdent)
		getCustomerFilter = ""
		if Session("filterRouteNumber") <> "" then
			getCustomerFilter = " " & custIdent & ".routeNumber = " & Session("filterRouteNumber")
		end if
		if routeFilter <> "" then
			if routeFilter > 0 then
			if getCustomerFilter <> "" then getCustomerFilter = getCustomerFilter & " AND "
			getCustomerFilter = " " & custIdent & ".routeNumber = " & routeFilter
			end if
		end if
		if Session("filterCommercialAccount") <> "" then
			if getCustomerFilter <> "" then getCustomerFilter = getCustomerFilter & " AND "
			getCustomerFilter = getCustomerFilter & "( " & custIdent & ".parentCustomerSeq = " & Session("filterCommercialAccount") & " OR " & custIdent & ".customerSequenceNumber = " & Session("filterCommercialAccount") & ") "
		end if
		if getCustomerFilter <> "" then
			getCustomerFilter = " AND (" & getCustomerFilter & ") "
		end if
	end function
	
	function SmartSearch(smartquery)
		dim selectHead
		dim query, rs
		dim customerseq
		
		customerseq = ""

		query = "select c.customersequencenumber from customer c, ticket t where c.customersequencenumber = t.customersequencenumber and t.invoicenumber = '" & DBStr(trim(smartquery)) & "'"
		query = query &  getCustomerFilter("c")
		
		set rs = getdisconnectedrecordset(query)
		customerseq = AppendCustomerSeqs(customerseq, rs)
		
		query = "select c.customersequencenumber from customer c where c.lastname like '" & DBStr(trim(smartquery)) & "%' or mainphone = '" & DBStr(trim(smartquery)) & "' or mainareacode + mainphone = '" & DBStr(trim(smartquery)) & "'"
		query = query & " or c.cellphone = '" & DBStr(trim(smartquery)) & "'"

		query = query & getCustomerFilter("c")
		
		set rs = getdisconnectedrecordset(query)
		customerseq = AppendCustomerSeqs(customerseq, rs)
		
		query = "select distinct c.customersequencenumber from customer c, ticket t, ticketLineItemTaggedItem tli, taggedPiece tp where c.customersequencenumber = t.customersequencenumber and t.ticketnumber = tli.ticketnumber and tp.taggeditemid = tli.taggeditemid and tp.heatsealid = '" & DBStr(trim(smartquery)) & "'"
		query = query & getCustomerFilter("c")
		
		set rs = getdisconnectedrecordset(query)
		customerseq = AppendCustomerSeqs(customerseq, rs)

		if customerseq <> "" then
			query = "select customersequencenumber, lastname + ' ' + isnull(firstname, '') + ' ' + isnull(middleinitial, '') as customername, shippingaddress1, shippingcity,  mainareacode, mainphone, r.name as 'routeName', showNotesonEachAccess from customer C left outer join  Route R  on c.routenumber = r.routenumber where c.isactive = 1 and c.customersequencenumber in (" & customerseq & ") "
			query = query & getCustomerFilter("c")
			query = query & " order by lastname, firstname "
			
			set SmartSearch= getdisconnectedrecordset(query)
		else
			set SmartSearch = rs
		end if
	end function
	
	
	function getSearchResult()
		dim name
		dim customerid
		dim sqltxt
		dim smartquery
	
		smartquery = trim(Request.QueryString("smartsearch"))

		if smartquery = "" then
			name = replace(Request.QueryString("name"), "|||", "&")
			name = replace(name, ") ", "")
			name = replace(name, ")", "")
			name = replace(name, "(", "")
			name = replace(name, "-", "")
			customerid=replace(Request.QueryString("customerid"), "|||", "&")
			sqltxt = CreateQryString(name, customerid)
			sqltxt   = sqltxt & ", isnull(firstname, '')"
			
			set objresult = getdisconnectedrecordset(sqltxt)
			
			if customerid <> "" and objresult.recordcount = 1 then
				if actionString = "CustomerFunctions" then
          if objresult("showNotesonEachAccess") then
  					Response.Redirect "/mainapp/CustomerNotes.asp?targetpage=CustomerFunctions&customerseq=" & objresult("customersequencenumber")
  				else
  					Response.Redirect "/mainapp/customerfunctions.asp?customerseq=" & objresult("customersequencenumber")
  				end if
				elseif actionString = "issuecharge" then
				  Response.Redirect "/mainapp/issueCreditOrCharge.asp?customerseq=" & objresult("customersequencenumber")
				elseif actionString = "applypayments" then
				  Response.Redirect "/mainapp/ApplyPayments.asp?customerseq=" & objresult("customersequencenumber")
				end if
			end if
		else

			smartquery = replace(smartquery, ") ", "")
			smartquery = replace(smartquery, ")", "")
			smartquery = replace(smartquery, "(", "")
			smartquery = replace(smartquery, "-", "")
			set objresult = smartsearch(smartquery)

			if actionString = "CustomerFunctions" and isnumeric(smartquery) then
				if objresult.recordcount = 1 then
					if objresult("showNotesonEachAccess") then
						Response.Redirect "/mainapp/customernotes.asp?targetpage=CustomerFunctions&customerseq=" & objresult("customersequencenumber")
					else
						Response.Redirect "/mainapp/customerfunctions.asp?customerseq=" & objresult("customersequencenumber")
					end if
				end if

			
				if len(smartquery) >= 7 then
					l_phonenumber = smartquery
				end if
			else
				l_lastname = smartquery

			end if
		end if	
	end function
	
	function formatareacode(sareacode) 
		formatareacode= ""
		if not isnull(sareacode) then
			formatareacode= "(" & sareacode & ")"
		end	if
	end function
	
	function formatphone(sPhone) 
		formatphone= ""
		if not isnull(sPhone) and  len(trim(sPhone)) = 7 then
			formatphone=   left(sPhone, 3) & "-" & right(sPhone, 4)
		else
			formatphone = sPhone
		end	if
	end function
	
	function formatname(slname, sfname)
		formatname= ""
		if not isnull(slname) then
			formatname= checkfornull(slname) + ", "  + checkfornull(sfname)
		end if
	
	end function

	function getPageSpecificFilter()
	
		select case lcase(Request.QueryString("targetpage"))
		case "applypayments"
			getPageSpecificFilter = " and (permanentaccount = 1 or temporaryaccount = 1)"
		end select
	
	end function
	
	
	function CreateQryString(name, customerid)
	dim strqry
	dim sqryPhone
	
	if isNumeric(name) and len(trim(name))  = 10  then
	
		sqryphone = "or ( (mainareacode+mainphone) like " & "'"&  name & "%' and c.isActive=1)"
		sqryphone = sqryphone & " or (cellphone) = " & "'" & name & "'" & "' and c.isactive =1)"
		
	elseif isNumeric(name) and len(trim(name)) = 7 then
	
		sqryphone = "or ( mainphone  like " & "'"&  name & "%' and c.isActive=1)"
	
	end if	
	
	if trim(name) <>"" then
		strqry = "select customersequencenumber, lastname + ' ' + isnull(firstname, '') + ' ' + isnull(middleinitial, '') as customername, shippingaddress1, shippingcity,  mainareacode, mainphone, r.name as 'routeName', showNotesonEachAccess from customer C left outer join  Route R  on c.routenumber = r.routenumber where  (lastname like" & "'" & DBStr(name) & "%') and c.isActive=1 " & getPageSpecificFilter() & getCustomerFilter("C")
		strqry = strqry & sqryphone & " order by customername"
	elseif trim(customerid) <> "" then
		strqry = "select customersequencenumber, lastname + ' ' + isnull(firstname, '') + ' ' + isnull(middleinitial, '') as customername , shippingaddress1, shippingcity,  mainareacode, mainphone, r.name as 'routeName'  , showNotesonEachAccess from customer C left outer join  Route R  on c.routenumber = r.routenumber where  customerid = " & "'" & DBStr(customerid) & "' and c.isActive=1 " & getPageSpecificFilter() &  getCustomerFilter("C") & " order by customername"
	else
		strqry = " Select customersequencenumber, lastname + ' ' + isnull(firstname, '') + ' ' + isnull(middleinitial, '') as customername, shippingaddress1, shippingcity,  mainareacode, mainphone, r.name as 'routeName' , showNotesonEachAccess from customer C left outer join  Route R  on c.routenumber = r.routenumber  where c.isActive=1 " & getPageSpecificFilter() &  getCustomerFilter("C") & " order by customername" 
	end if
	
	if not isNumeric(name) then
	else
			l_phonenumber = name
	end if
		
	createQryString = strqry
	end function
%>
