<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim routeNumber
	dim customerSeq
	dim targetPage
	
	routeNumber = getReqVar("routeNumber")
	customerSeq = getReqVar("customerSeq")
	targetPage = getReqVar("targetPage")
	
	if routeNumber = "" then
		routeNumber = getFirstRouteNumber(session("storeid"))
	end if
	
	if customerSeq = "" then
		customerSeq = session("customerSequenceNumber")
	end if
	
	select case lcase(request.querystring("useraction"))
	case "submit"
		saveForm
		gotoTargetPage targetPage
	case "cancel"
		gotoTargetPage targetPage
	end select

	function gotoTargetPage(targetPage)
		select case(lcase(targetPage))
		case "routesetup"
			response.redirect "/setup/routeSetup.asp?routeNumber=" & routeNumber
		case else
			response.redirect "customerdeliverylist.asp?customerseq=" & customerSeq
		end select
	end function
		
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function


	function getFirstRouteNumber(storeID)
		dim query, rs
		query = "select min(routeNumber) as firstRoute from route where routeNumber > 0 and storeid = " & storeid
		set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
			getFirstRouteNumber = rs("firstRoute")
		else
			getFirstRouteNumber = 0
		end if
	end function

  function packRouteStops(routeNumber)
    dim query
    
    query = "exec dbo.packRouteStops " & routeNumber


    qryexecute query
  end function

	
	function getRouteStopRange(routenumber)
		dim query, rs
		
		query = " select MAX(stopOrder) - MIN(stopOrder) as range from "
		query = query & " customerdelivery where active = 1 and routeid = " & routenumber
		
		set rs = getdisconnectedrecordset(query)
		
		getRouteStopRange = rs("range")
		
		set rs = nothing
		
	end function
	
	sub moveDeliveryToPosition(deliveryid, stopOrder)
    dim query, rs
    dim routeNumber
    dim range
    
    query = "select routeid as routenumber, stoporder from customerdelivery where id = " & deliveryid

    set rs = getdisconnectedrecordset(query)
    
    if rs.recordcount > 0 then
      routeNumber = rs("routeNumber")
      range = getRouteStopRange(routeNumber)
      
      if clng(stopOrder) < clng(rs("stopOrder")) then
        query = " update customerdelivery set stoporder = stoporder + 1 where active = 1 and routeid = " & routeNumber & " and stoporder >= " & stopOrder
      else
        query = " update customerdelivery set stoporder = stoporder - 1 where active = 1 and routeid = " & routeNumber & " and stoporder <= " & stopOrder
      end if

      if clng(stopOrder) <> clng(rs("stopOrder")) then
        qryexecute query
  
        query = " update customerdelivery set stoporder = " & stopOrder & " where id = " & deliveryid

        qryexecute query
  
  		  packRouteStops routeNumber
		  end if
    end if
	
	end sub
	
	function saveForm()
		createDelivery customerSeq, routeNumber, request.form("stopOrder"), request.form("regularStop") <> "", request.form("ccBeforeDelivery") <> ""
		setCustomerAccount customerSeq, request.form("accountLimit"), request.form("accountTerms")
	end function
	
	
	function setCustomerAccount(customerSeq, accountLimit, accountTerms)
		dim query, rs
		if accountLimit <> "" then
			if accountLimit > 0 then
			
				query = " update customer set "
				query = query & " permanentaccount = 1 "
				query = query & ", creditlimit = " & accountLimit
				
				if accountTerms <> "" then
					query = query & ", paymenttermsid = " & accountTerms
				else
					query = query & ", paymenttermsid = null "
				end if
				
				query = query & " where customersequencenumber = " & customerSeq
				
				qryexecute query
			end if
		end if
		
	end function
	
	function inactivateOldDeliveries(customerSeq, routeNumber)
		dim query, rs
		
		query = " update customerdelivery set active = 0, enddate = getdate() "
		query = query & " where customersequencenumber = " & customerSeq
		query = query & " and routeid = " & routeNumber
		query = query & " and active = 1 "
		
		qryexecute query
	
	end function
	
	function createDelivery(customerSeq, routeNumber, stopOrder, regularPickup, ccBeforeDelivery)
		dim query, rs
		dim deliveryID

		inactivateOldDeliveries  customerSeq, routeNumber
		
		openConnection
		
		query = "insert into customerdelivery(customersequencenumber, routeid, stopOrder, deliverynotes) "
		query = query & " select " & customerSeq & ", " & routeNumber & ", isnull(max(stopOrder) + 1, 0), '" & replace(request.form("notes"), "'", "''") & "'"
		
		query = query & " from customerdelivery where routeID = " & routeNumber

		dbInsert query
		
		set rs = dbSelect("select @@IDENTITY as deliveryId")
		
		deliveryID = rs("deliveryId")
		
		closeConnection
		
		moveDeliveryToPosition deliveryid, stopOrder
		setDeliveryCustomerDefaults deliveryid, customerSeq, ccBeforeDelivery
		setDefaultDeliveryDays deliveryid, regularPickup
		moveCustomerToRoute customerSeq, routeNumber
		
		createDelivery = deliveryID
	end function
	
	function moveCustomerToRoute(customerSeq, routeNumber)
		dim query, rs
		
		query = "update customer set routeNumber = " & routeNumber & " where customerSequenceNumber = " & customerSeq
		qryexecute query
	end function
	
  function fullCustomerAddress(rs, t)
		dim p1, p2
		
		t = lcase(trim(t))
		
		if t = "shipping" or t = "billing" then
			p1 = ""
			p2 = ""
			
			if rs(t & "Address1") <> "" then  p1 = p1 & trim(rs(t & "Address1")) & vbcrlf end if
			if rs(t & "Address2") <> "" then  p1 = p1 & trim(rs(t & "Address2")) & vbcrlf end if
			if rs(t & "Address3") <> "" then  p1 = p1 & trim(rs(t & "Address3")) & vbcrlf end if
			
			p2 = trim(trim(rs(t & "City")) & " " & trim(rs(t & "State")))
			
			if p2 <> "" and rs(t & "Zipcode") <> "" then
			  p2 = p2 & ", " & trim(rs(t & "Zipcode"))
			else
			  p2 = p2 & trim(rs(t & "Zipcode"))
			end if
			
			fullCustomerAddress = p1 & p2
		end if
  end function
  
	function setDeliveryCustomerDefaults(deliveryid, customerSeq, ccBeforeDelivery)
		dim query, rs
		dim address
		dim paymentType
		dim phoneNumber
		
		query = "select *, dbo.formatPhone(mainareacode, mainphone) as phonenumber from customer where customersequencenumber = " & customerSeq
		set rs = getdisconnectedrecordset(query)
		
		address = fullCustomerAddress(rs, "shipping")
		paymentType = rs("paymenttypename")
		phoneNumber = rs("phoneNumber")
		
		set rs = nothing

		if ccBeforeDelivery then
			paymentType = "Credit Card"
		elseif trim(paymentType) = "CREDIT CARD" then
			paymentType = "On Account"
		end if

		query = "update customerdelivery set deliveryaddress = '" & address & "'"
		query = query & ", paymentType = '" & paymentType & "'"
		query = query & ", deliveryPhone = '" & phoneNumber & "'"
		query = query & " where id = " & deliveryid

		
		qryexecute query
	end function
	
	function setDefaultDeliveryDays(deliveryid, regularPickup)
		dim query, rs
		dim deliveryValue
		
		if regularPickup then
			deliveryValue = 3
		else
			deliveryValue = 1
		end if
		
		
		query = " update customerdelivery set "
		query = query & " customerdelivery.deliverMon = route.deliveryMon * " & deliveryValue
		query = query & ", customerdelivery.deliverTue = route.deliveryTue * " & deliveryValue
		query = query & ", customerdelivery.deliverWed = route.deliveryWed * " & deliveryValue
		query = query & ", customerdelivery.deliverThu = route.deliveryThu * " & deliveryValue
		query = query & ", customerdelivery.deliverFri = route.deliveryFri * " & deliveryValue
		query = query & ", customerdelivery.deliverSat = route.deliverySat * " & deliveryValue
		query = query & ", customerdelivery.deliverSun = route.deliverySun * " & deliveryValue
		query = query & " from customerdelivery inner join route on customerdelivery.routeID = route.routeNumber "
		query = query & " where customerdelivery.id = " & deliveryid

		
		qryexecute query
	end function
	
	function getCustomersOnRoute(routeNumber)
		dim query, rs
		if routeNumber <> "" then
			query = "select dbo.countCustomersOnRoute(" & routeNumber & ") as cnt "
			set rs = getdisconnectedrecordset(query)
			getCustomersOnRoute = rs("cnt")
			set rs = nothing
		else
			getCustomersOnRoute = 0
		end if
	end function
	
	function isCustomerAccountHolder(customerSeq)
		dim query, rs
		
		query = " select customersequencenumber from customer "
		query = query & " where customersequencenumber = " & customerSeq
		query = query & " and permanentAccount = 1 "
		query = query & " and creditLimit > 0 "
		
		set rs = getdisconnectedrecordset(query)
		
		isCustomerAccountHolder = rs.recordcount > 0
		
		set rs = nothing
	end function

	function isCustomerCreditBatch(customerSeq)
		dim query, rs
		
		query = " select customersequencenumber from customer "
		query = query & " where customersequencenumber = " & customerSeq
		query = query & " and allowccbatch = 1 "

		set rs = getdisconnectedrecordset(query)
		
		isCustomerCreditBatch = rs.recordcount > 0
		
		set rs = nothing
	end function
%>
<HTML>
<HEAD>
<TITLE>Customer Routes</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript">

	function selectRoute(routeNumber) {
		document.quickCustomerDeliveryForm.action = "?routenumber=" + routeNumber;
		document.quickCustomerDeliveryForm.submit();
	}
	
	function submitForm() {
		document.quickCustomerDeliveryForm.action = "?useraction=submit";
		document.quickCustomerDeliveryForm.submit();
	}
	
	function cancelForm() {
		document.quickCustomerDeliveryForm.action = "?useraction=cancel";
		document.quickCustomerDeliveryForm.submit();
	}
	
	function fixDecimal(o, places) {
		var temp;
		
		temp = o.value.replace(/[^0123456789]/g, "");

		o.value = temp.substr(0,temp.length - places) + "." + temp.substr(temp.length - places);
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0 onload="">

<!-- #include file="../include/banner.inc" -->
<H1>Route Membership</H1>
<FORM id="quickCustomerDeliveryForm" name="quickCustomerDeliveryForm" action="" method="Post">

<INPUT type="hidden" name="customerSeq" value="<%=customerSeq%>" />
<INPUT type="hidden" name="targetPage" value="<%=targetPage%>" />


<TABLE cellspacing="4" align="center">

	<TR>
		<TD>
			Route<BR />
			<SELECT name="routeNumber" onchange="selectRoute(this.value)" > 
			<%
				query = "select routeNumber, name from route where routenumber > 0 and storeid = " & session("storeid")
				set rs = getdisconnectedrecordset(query)
				
				while not(rs.eof or rs.bof)
			%>
				<OPTION value="<%=rs("routeNumber")%>" <%if trim(routeNumber) = trim(rs("routeNumber")) then%>selected<%end if%>><%=rs("name")%></OPTION>
			<%
					rs.movenext
				wend
				set rs = nothing
			%>
			</SELECT>
		</TD>
		<TD>
			Stop Order<BR />
			<SELECT name="stopOrder"> 
			  <OPTION value="-1">First</OPTION>
			  <OPTION value="65000">Last</OPTION>
			<%
			dim i
			dim customerCnt
			customerCnt = getCustomersOnRoute(routeNumber)
			for i = 1 to customerCnt
			%>
			  <OPTION><%=i%></OPTION>
			<%
			next
			%>
			  
			</SELECT>
		</TD>
	</TR>
	<TR>
		<TD>
			Regular Stop
		</TD>
		<TD>
			<INPUT name="regularStop" type="checkbox" style="width:27px;height:27px" value="1" />
		</TD>
	</TR>
	<TR>
		<TD colspan="2">
			Note<BR />
			<TEXTAREA rows="6" cols="40" name="notes"></TEXTAREA>
		</TD>
	</TR>
	
	<% if isCustomerCreditBatch(customerSeq) then %>
	<TR>
		<TD>
			Debit Credit Card Before Delivery
		</TD>
		<TD>
			<INPUT name="ccBeforeDelivery" type="checkbox" style="width:27px;height:27px" value="1" />
		</TD>
	</TR>
	<% end if %>
		
	<% if not isCustomerAccountHolder(customerSeq) then %>
	<TR>
		<TD>
			Payment Terms
		</TD>
		<TD>
			<SELECT name="accountTerms">
				<OPTION selected value="">None</OPTION>
			<%
				query = " select * from paymenttermsdomain where storeid = " & session("storeid")
				set rs = getdisconnectedrecordset(query)
				
				while not (rs.eof or rs.bof)
			%>
				<OPTION value="<%=rs("paymenttermsid")%>"><%=rs("paymentname")%></OPTION>
			<%
					rs.movenext
				wend
				set rs = nothing
			%>
			</SELECT>
		</TD>
	</TR>
	
	<TR>
		<TD>
			Account Limit
		</TD>
		<TD>
			<INPUT name="accountLimit" style="width:100px;text-align:right" value="" onkeyup="fixDecimal(this, 2)" />
		</TD>
	</TR>
	<% end if %>

	<TR>
		<TD colspan="2" align="center">
			<INPUT type="button" style="width:100px;height:50px" value="Ok" onclick="submitForm()" />
			<INPUT type="button" style="width:100px;height:50px" value="Cancel" onclick="cancelForm()" />
		</TD>
	</TR>
</TABLE>

</FORM>   

</BODY>
</HTML>
