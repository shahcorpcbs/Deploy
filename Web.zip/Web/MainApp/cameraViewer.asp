<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim imgID
	
	imgID = Trim(Request.QueryString("imgID"))
	if imgID = "" then
		imgID = Request.Form("txImgID")
	end if

%>

<HTML>
<HEAD>
<TITLE>Capture Image</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<SCRIPT LANGUAGE="javascript" >

	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<FORM id="cameraViewer" action = "" name="cameraViewer" method ="POST">
		<font face="Verdana, Helvetica" size=2 color="#000000">

		
			<%
				dim imageList
				dim ssql
				dim fileName
				
				ssql = "SELECT ImageFile, Comments from CapturedImages WHERE ID='" & imgID & "'"
				
				set imageList = getDisconnectedRecordset(ssql)
			
				while not imageList.EOF
					fileName = "/ImageCapture/" &  Trim(imageList("ImageFile"))
					
			%>

					<IMG width=320 height=240 src=<%=fileName%>>
					<%=imageList("Comments")%>
					
			<%		
					imageList.MoveNext
				wend
				
				imageList.Close
				set imageList = nothing
			%>

		</font>
		
		<INPUT type="hidden" name="txImgID" class=text value=<%=imgID%>>
</FORM>
</BODY>
</HTML>

