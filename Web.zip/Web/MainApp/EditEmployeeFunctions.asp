<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query
	dim rs
	dim useraction
	
	useraction = trim(Request.QueryString("useraction"))
	
	select case useraction
		case "remove"
			removeFunction
		case "add"
			addNewFunction
		case "save"
			saveToDatabase
	end select
	
	sub removeFunction()
		query = "delete from EmployeeFunction where ID = '" & trim(Request.QueryString("id")) & "'"
		qryexecute(query)
	end sub
	
	sub addNewFunction()
		query = "insert into EmployeeFunction (Location, Action, Name, Description) values ('" & _
				trim(Request.QueryString("Location")) & "','" & _
				trim(Request.QueryString("Action")) & "','" & _
				trim(Request.QueryString("Name")) & "','" & _
				trim(Request.QueryString("Description")) & "')"

		qryexecute(query)
	end sub
	
	sub saveToDatabase()
		dim functionCount
		dim i
		functionCount = Request.Form("ef_id").Count
		
		for i = 1 to functionCount
			dim id, name, description, location, action
			
			id = trim(Request.Form("ef_id")(i))
			name = trim(Request.Form("ef_name")(i))
			description = trim(Request.Form("ef_description")(i))
			location = trim(Request.Form("ef_location")(i))
			action = trim(Request.Form("ef_action")(i))
			
			query = "update EmployeeFunction set" _
				& " name = '" & name & "'" _
				& ", description = '" & description & "'" _
				& ", location = '" & location & "'" _
				& ", action = '" & action & "'" _
				& " where id = '" & id & "'"

			
			qryexecute(query)
		next
		
	end sub
	
%>
<HTML>
<HEAD>
<TITLE>Employee Function Setup</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function addNewFunction() {
		document.efs.action = "?useraction=add" +
		"&name=" + document.efs.ef_new_name.value +
		"&description=" + document.efs.ef_new_description.value +
		"&location=" + document.efs.ef_new_location.value +
		"&action=" + document.efs.ef_new_action.value;
		document.efs.submit();
	}
	function saveToDatabase() {
		document.efs.action = "?useraction=save";
		document.efs.submit();
	}
	function removeFunction(ID) {
		document.efs.action = "?useraction=remove" +
		"&id=" + ID;
		document.efs.submit();
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Employee Function Setup</H1>
<FORM id="efs" name="efs"  Method = "post">

<div style="margin-left:50px; margin-right:50px;">

<%
	dim counter
	query = "select * from EmployeeFunction"
	set rs = getDisconnectedRecordset(query)
	
	counter = 0
	
	while not (rs.EOF or rs.BOF)
%>

	<input type=hidden name="ef_id" value="<%=trim(rs("id"))%>">
	<div style="color:black; margin-bottom:13px;">
		<input style="float:left;height:50px; width:50px" type="button" value="Delete" onClick="removeFunction(<%=rs("ID")%>)">
		<div >
			<span style="width:70px; text-align:right;">Name:</span>
				<input style="width:200px" name=ef_name value="<%=trim(rs("Name"))%>"> 
			<span style="width:70px; text-align:right;">Description:</span>
				<input style="width:400px" name=ef_description value="<%=trim(rs("Description"))%>">
		</div>
		<div >
			<span style="width:70px; text-align:right;">Location:</span>
				<input style="width:400px" name=ef_location value="<%=trim(rs("Location"))%>"> 
			<span style="width:70px; text-align:right;">Action:</span>
				<input style="width:200px" name=ef_action value="<%=trim(rs("Action"))%>">
		</div>
	</div>
	

<%	
		counter = (counter + 1) mod 2
		rs.MoveNext
	wend
	
	set rs = nothing
%>


	<div style="color:black; margin-bottom:13px;">
		<input style="float:left;height:50px; width:50px" type="button" value="Add" onClick="addNewFunction()">
		<div >
			<span style="width:70px; text-align:right;">Name:</span>
				<input style="width:200px" name=ef_new_name value=""> 
			<span style="width:70px; text-align:right;">Description:</span>
				<input style="width:400px" name=ef_new_description value="">
		</div>
		<div >
			<span style="width:70px; text-align:right;">Location:</span>
				<input style="width:400px" name=ef_new_location value=""> 
			<span style="width:70px; text-align:right;">Action:</span>
				<input style="width:200px" name=ef_new_action value="">
		</div>
	</div>
	
	<div>
		<input style="height:50px; width:100px" type="button" value="Cancel">
		<input style="height:50px; width:100px" type="button" value="Okay" onClick="saveToDatabase()">
	</div>
	
</div>
</FORM>
</BODY>
</HTML>
