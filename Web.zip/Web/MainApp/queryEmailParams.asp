<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 360 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim queryName
	dim queryTransformed
	dim query, rs
	dim userQueryID
	dim formID
	dim formTemplate
	
	userQueryID = getReqVar("userQueryID")
	queryTransformed = getReqVar("query")
	queryName = getReqVar("queryName")
	formID = getReqVar("formID")
	
	queryName = getQueryName(userQueryID)
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getQueryName(userQueryID)
		dim query, rs
		
		if userQueryID <> "" then
			query = "select name from userquery where userqueryid = " & userqueryid
			
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then getQueryName = rs("name")
		end if
	
	end function


	function getStoreName()
		dim query, rs

		query = "select name from store where storeid = " & Session("storeid")
		set rs = getdisconnectedrecordset(query)

		getStoreName = rs("name")

		set rs = nothing
	end function

	function getStoreEmail()
		dim query, rs

		query = "select isnull(email, '') as email from store where storeid = " & Session("storeid")
		set rs = getdisconnectedrecordset(query)

		getStoreEmail = rs("email")

		set rs = nothing
	end function
%>

<HTML>
<HEAD>
<TITLE>Email</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT LANGUAGE="javascript" >


	function goBack() {
		document.queryEmailParams.action = "querydb.asp";
		document.queryEmailParams.submit();
	}

	function sendEmail() {
		document.queryEmailParams.action = "queryMergeEmail.asp?useraction=sendemail";
		document.queryEmailParams.submit();
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->

<FORM name="queryEmailParams" ID="queryEmailParams" METHOD=POST  style="margin:0;padding:0"> 
<INPUT type="hidden" name="queryName" value="<%=Server.URLEncode(queryName)%>" />
<INPUT type="hidden" name="query" value="<%=queryTransformed%>" />
<INPUT type="hidden" name="userQueryID" value="<%=userQueryID%>" />
<INPUT type="hidden" name="formID" value="<%=formID%>" />

<H1>Merge Email</H1><BR />
<BR />

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">

	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="goBack()" value="" >Back</BUTTON>
		<BUTTON onclick="sendEmail()" value="" >Send</BUTTON>
	</SPAN>
</DIV>

<TABLE class="itable" style="width:100%" cellpadding="0" cellspacing="0">
	<TR align="left">
		<TH>Attribute</TH>
		<TH>Value</TH>
	</TR>
	<TR>
		<TD>From Email</TD>
		<TD><INPUT name="fromEmail" style="width:200px" value="<%=getStoreEmail()%>"></TD>
	</TR>
	<TR>
		<TD>From Name</TD>
		<TD><INPUT name="fromName" style="width:200px" value="<%=getStoreName()%>"></TD>
	</TR>
	<TR>
		<TD>Subject</TD>
		<TD><INPUT name="subject" style="width:200px" value="<%=queryName%>"></TD>
	</TR>
	<TR>
		<TD>Email Field</TD>
		<TD>
			<SELECT name="emailField">
<%
		dim idx
		
		query = queryTransformed
		set rs = getdisconnectedrecordset(query)

		for idx = 0 to rs.Fields.Count - 1
%>
				<OPTION <%if lcase(rs.Fields(idx).Name) = "email" then%>selected<%end if%>><%=Server.HTMLEncode(rs.Fields(idx).Name)%></OPTION>
<%
		next
%>
			</SELECT>
		</TD>
	</TR>
</TABLE>

</FORM>
</BODY>
</HTML>

