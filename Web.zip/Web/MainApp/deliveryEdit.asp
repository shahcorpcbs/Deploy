<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<%
	dim deliveryID
	dim deliveryDate
	dim allow_editDeliveryDate
	dim query, rs
	dim routeNumber
	dim deliveryList
	dim allow_generateDirections
	dim routeDept
	
	set deliveryList = nothing
	deliveryID = getReqVar("deliveryID")
	routeNumber = getReqVar("routeNumber")
	deliveryDate = getReqVar("deliveryDate")
	routeDept = getReqVar("routeDept")
	allow_generateDirections = getMapPointEnabled()
	
	if routeNumber = "" then
		routeNumber = getFirstRouteNumber()
	end if
	
	if trim(deliveryDate) = "" then
		deliveryDate = getDeliveryDateDB(deliveryID)
		if trim(deliveryDate) = "" then
			deliveryDate = getTodaysDate()
		end if
	end if
	
	select case(request.querystring("useraction"))
	case "addorremoveinvoice"
		addOrRemoveInvoice
		updateDeliveryDateDB deliveryid, request.form("deliveryDate")
	case "removestopfromdelivery"
		removeStop deliveryid, request.querystring("customersequencenumber")
	case "addroute"
		addRoute deliveryID, routeNumber, routeDept, true, true
		updateDeliveryDateDB deliveryid, request.form("deliveryDate")
	case "adddropoffs"
		addRoute deliveryID, routeNumber, routeDept, false, true
		updateDeliveryDateDB deliveryid, request.form("deliveryDate")
	case "addpickups"
		addRoute deliveryID, routeNumber, routeDept, true, false
		updateDeliveryDateDB deliveryid, request.form("deliveryDate")
	case "removeroute"
		removeRoute deliveryID, routeNumber
	case "addstoptodelivery"
		addStopToDelivery deliveryID, request.querystring("customersequencenumber")
		updateDeliveryDateDB deliveryid, request.form("deliveryDate")
	end select
	
	updateDeliveryStatus deliveryid
	setAllowActions deliveryID
	
	function getFirstRouteNumber()
		dim query, rs
		
		query = "select min(routeNumber) as routeNumber from route where routeNumber > 0 and storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getFirstRouteNumber = 1
		
		if rs.recordcount > 0 then
			getFirstRouteNumber = rs("routeNumber")
		end if
		
		set rs = nothing
	end function
	
	function updateDeliveryDateDB(deliveryID, deliveryDate)
		dim query, rs
		
		if deliveryid <> "" and deliveryDate <> "" then
			query = " update delivery set deliverydate = '" & deliverydate & "'"
			query = query & " where deliveryid = " & deliveryid
			
			qryexecute query
		end if
	end function
	function getMapPointEnabled()
		dim query, rs
		
		query = " select enableMapPoint from miscsetup where enableMapPoint = 1 and storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
	
		getMapPointEnabled = rs.recordcount > 0
		
		set rs = nothing
	end function
	function getDeliveryDateDB(deliveryID)
		dim query, rs
		
		if deliveryID <> "" then
			query = " select convert(varchar, deliverydate, 101) as deliverydate from delivery where deliveryid = " & deliveryid
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getDeliveryDateDB = rs("deliverydate")
			end if
		end if
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function


	function setAllowActions(deliveryID)
		select case getDeliveryStatus(deliveryID)
		case ""
			allow_editDeliveryDate = true
		case 0
			allow_editDeliveryDate = true
	
		end select
	end function
	
	function updateDeliveryStatus(deliveryid)
		dim status
		dim deliveryitemcount

		if deliveryid <> "" then
			status = getDeliveryStatus(deliveryid)
			deliveryitemcount = getDeliveryStopCount(deliveryid)

			if status = 0 then
				if deliveryitemcount > 0 then
					setDeliveryStatus deliveryid, 1
				end if
			elseif status = 1 then
				if deliveryitemcount = 0 then
					setDeliveryStatus deliveryid, 0
				end if
			end if
		end if
	end function
	function getDeliveryStopCount(deliveryid)
		dim query, rs
		getDeliveryStopCount = 0
		if deliveryid <> "" then
			query = " select count(*) as stopcount from deliverystop "
			query = query & " where deliverystop.deliveryid = " & deliveryid
			
			set rs = getdisconnectedrecordset(query)
			
			getDeliveryStopCount = rs("stopcount")
		end if
	end function
	function getDeliveryItemCount(deliveryid)
		dim query, rs
		getDeliveryItemCount = 0
		if deliveryid <> "" then
			query = " select count(*) as deliveryitemcount from deliveryitem inner join deliverystop on "
			query = query & " deliveryitem.deliverystopid = deliverystop.deliverystopid "
			query = query & " where deliverystop.deliveryid = " & deliveryid
			
			set rs = getdisconnectedrecordset(query)
			
			getDeliveryItemCount = rs("deliveryitemcount")
		end if
	end function
	function getDeliveryStatus(deliveryid)
		dim query, rs
		
		getDeliveryStatus = ""
		
		if deliveryid <> "" then
			query = " select status from delivery where deliveryid = " & deliveryid
			set rs = getdisconnectedrecordset(query)
			
			getDeliveryStatus = rs("status")
		end if
	end function
	
	function setDeliveryStatus(deliveryid, status)
		dim query
		
		if deliveryid <> "" then
			query = " update delivery set status = " & status
			query = query & " where deliveryid = " & deliveryid
			
			qryexecute query
		end if
	end function
	
	function addOrRemoveInvoice()
		select case lcase(request.querystring("addorremove"))
		case "add"
			addInvoiceToDelivery deliveryID, request.querystring("invoicenumber")
		case "remove"
			removeInvoiceFromDelivery deliveryID, request.querystring("invoicenumber")
		end select
	end function

	function getRoutes()
		dim query, rs
		
		query = " select routeNumber, name from route where routenumber > 0 and storeid = " & session("storeid")

		set rs = getdisconnectedrecordset(query)
		
		set getRoutes = rs
	end function
	
	
	function getCustomerDeliveryQuery(deliveryDate, customerSeq, routeNumber)
		dim query, rs
		dim routeFilter
		dim dayOfWeek
		dim dayOfWeekColumnName
		dim dayOfWeekColumnNames

		
		dayOfWeekColumnNames = Array("DeliverSun", "DeliverMon", "DeliverTue", "DeliverWed", "DeliverThu", "DeliverFri", "DeliverSat")

		
		dayOfWeek = DATEDIFF("d", DATEADD("ww", DATEDIFF("ww",0,deliveryDate) - 1, 0), deliveryDate) - 1
		
		dayOfWeekColumnName = dayOfWeekColumnNames(dayOfWeek)
		
		routeFilter = getRouteFilter(deliveryid)
		
		query = " select customerdelivery.*, customer.customername, customer.parentCustomerSeq as parentCustomerSequenceNumber, customer.billingCustomerSeq as billingCustomerSequenceNumber "
		query = query & " from customerdelivery inner join customer on "
		query = query & " customerdelivery.customersequencenumber = customer.customersequencenumber " 
		query = query & " where datediff(day, customerdelivery.begindate, '" & deliveryDate & "') >= 0 "
		query = query & " and customerdelivery.active = 1 "
		query = query & " and (customerdelivery.enddate is null or "
		query = query & " datediff(day, '" & DBStr(deliveryDate) & "', customerdelivery.enddate) >= 0) "
		query = query & " and " & dayOfWeekColumnName & " in (1,2,3) "
		
		if customerSeq <> "" then
			query = query & " and customerdelivery.customersequencenumber = " & customerSeq
		end if
		
		if routeNumber <> "" then
			query = query & " and routeid = " & routeNumber
		end if
		
		getCustomerDeliveryQuery = query
	end function
	
	function getDeliveryListRS(deliveryDate)
		dim query
		dim routeFilter
		dim dayOfWeek
		dim dayOfWeekColumnName
		dim dayOfWeekColumnNames

		
		dayOfWeekColumnNames = Array("DeliverSun", "DeliverMon", "DeliverTue", "DeliverWed", "DeliverThu", "DeliverFri", "DeliverSat")
		
		dayOfWeek = DATEDIFF("d", DATEADD("ww", DATEDIFF("ww",0,deliveryDate) - 1, 0), deliveryDate) - 1
		
		dayOfWeekColumnName = dayOfWeekColumnNames(dayOfWeek)

		query = " select * from deliverylist "
		query = query & " where datediff(day, begindate, '" & DBStr(deliveryDate) & "') >= 0 "
		query = query & " and (enddate is null or "
		query = query & " datediff(day, '" & DBStr(deliveryDate) & "', enddate) >= 0) "
		query = query & " and (duedate is null or datediff(day, duedate, '" & deliveryDate & "') >= 0 ) "
		query = query & " and " & dayOfWeekColumnName & " in (1,2,3) "
		query = query & " order by stopOrder, " & dayOfWeekColumnName & ", customersequencenumber, routenumber, invoicenumber "


		set getDeliveryListRS = getdisconnectedrecordset(query)
	end function
	
	function formatRackLocation(racklocation)
		racklocation = trim(racklocation)
		if racklocation <> "" then
			formatRackLocation = "-(" & racklocation & ")"
		end if
	
	end function
	
	
	function isRouteDisplayed(routeNumber)
		dim displayedRoute
		
		isRouteDisplayed = false
		
		for each displayedRoute in request.form("routeFilter")
			if trim(routeNumber) = trim(displayedRoute) then
				isRouteDisplayed = true
				exit function
			end if
		next
	end function
	
	function isRouteInDelivery(deliveryID, routeNumber)
		dim query, rs
		
		if deliveryID <> "" then
			query = " select * from deliverystop where "
			query = query & " routeid = " & routenumber
			query = query & " and deliveryid = " & deliveryid
			
			set rs = getdisconnectedrecordset(query)
			
			isRouteInDelivery = rs.recordcount > 0
			
			set rs = nothing
		else
			isRouteInDelivery = false
		end if
	end function
	
	
	function getRoutesInDeliveryFilter(deliveryid)
		dim query, rs
		dim result
		result = ""
		
		if deliveryid <> "" then
			query = " select routeid from deliverystop where deliveryid = " & deliveryid
			
			set rs = getdisconnectedrecordset(query)
			
			
			while not(rs.eof or rs.bof)
				if result <> "" then result = result & ","
				result = result & rs("routeid")
				rs.movenext
			wend
			set rs = nothing
		end if
		
		getRoutesInDeliveryFilter = result
	end function
	
	
	function getRouteFilter(deliveryid)
		dim result
		dim displayedRoute
		dim deliveryRoutes
		

		result = "0, " & request.form("routeNumber")

		
		deliveryRoutes = getRoutesInDeliveryFilter(deliveryid)
		
		if deliveryRoutes <> "" then result = result & "," & deliveryRoutes

		
		getRouteFilter = result
	end function

	function isTicketInDelivery(deliveryid, ticketnumber) 
		dim query, rs

		if not isnull(ticketnumber) then
		
			query = "select count(*) as cnt from deliveryitem inner join deliverystop on "
			query = query & " deliveryitem.deliverystopid = deliverystop.deliverystopid "
			query = query & " where deliveryitem.ticketnumber = " & ticketnumber
			query = query & " and deliveryitem.status = 0 "
		
			if deliveryid <> "" then
				query = query & " and deliverystop.deliveryid = " & deliveryid
			end if
			
			
			
			set rs = getdisconnectedrecordset(query)
		
			isTicketInDelivery = (rs("cnt") > 0)
			
			set rs = nothing
		else
			isTicketInDelivery = false
		end if
		
	end function


	function isStopInDelivery(deliveryid, customerdeliveryid, deliverydate) 
		dim query, rs
		

		
		if deliveryid <> "" then
			query = "select count(*) as cnt from deliverystop where "
			query = query & " customerdeliveryid = " & customerdeliveryid
			query = query & " and deliveryid = " & deliveryid
		else
			query = "select count(*) as cnt from delivery inner join deliverystop on "
			query = query & " delivery.deliveryid = deliverystop.deliveryid "
			query = query & " where deliverystop.customerdeliveryid = " & customerdeliveryid
			query = query & " and datediff(day, deliverydate, '" & deliverydate & "') = 0 "

		end if

		
		set rs = getdisconnectedrecordset(query)

		isStopInDelivery = (rs("cnt") > 0)

		set rs = nothing
	end function
	
	function removeInvoiceFromDelivery(deliveryid, invoicenumber)
		dim query, rs
		
		query = " delete deliveryitem from deliveryitem inner join ticket on "
		query = query & " deliveryitem.ticketnumber = ticket.ticketnumber "
		query = query & " inner join deliverystop on "
		query = query & " deliveryitem.deliverystopid = deliverystop.deliverystopid "
		query = query & " where ticket.invoicenumber = " & invoicenumber
		query = query & " and deliverystop.deliveryid = " & deliveryid
		
		qryexecute query
		
		query = " update ticket set routeNumber = customer.routenumber, "
		query = query & " ticket.ticketstatus = 'AC' "
		query = query & " from ticket inner join customer on "
		query = query & " ticket.customersequencenumber = customer.customersequencenumber "
		query = query & " where invoiceNumber = " & invoiceNumber

		qryexecute query
	end function
	
	function addInvoiceToDelivery(deliveryid, invoicenumber)
		dim query, rs
		dim ticketNumber
		dim deliverystopid
		
		query = " select * "
		query = query & " from ticket "
		query = query & " where invoicenumber = '" & invoicenumber & "'"
		query = query & " and ticketStatus='AC' "
		query = query & " and invoiceType='D' "
		
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			deliverystopid = addStopToDelivery(deliveryid, rs("customersequencenumber"))
						
			addTicketToStop deliveryStopID, rs("ticketnumber")
		end if
	end function
	
	function addTicketToStop(deliveryStopID, ticketNumber)
		dim query, rs
		dim routeid
		
		if deliveryStopID <> "" and ticketNumber <> "" then
			query = " select routeid from deliverystop where deliverystopid = " & deliverystopid
			set rs = getdisconnectedrecordset(query)
			
			routeid = rs("routeid")
			
			query = " update ticket set routeNumber = " & routeid & ", ticketStatus = 'OD' where ticketNumber = " & ticketNumber
			qryexecute query
		
			query = " insert into deliveryitem (deliverystopid, ticketnumber, status) "
			query = query & " values (" & deliveryStopID & "," & ticketNumber & ", 0) "
	
			qryexecute query
		end if
	end function

	
	function getStopInDelivery(deliveryid, customerseq)
		dim query, rs
		
		query = " select deliverystopid "
		query = query & " from deliverystop where "
		query = query & " customersequencenumber = " & customerseq
		query = query & " and deliveryid = " & deliveryid

		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getStopInDelivery = rs("deliverystopid")
		else
			getStopInDelivery = ""
		end if
		
		set rs = nothing
	end function

	
	

	
	function createNewDelivery(employeeid, status)
		dim query, rs
		
		openConnection
		
		query= " INSERT INTO Delivery (EmployeeID, Status) "
		query = query & " VALUES ("
		query = query & employeeid
		query = query & ", " & status
		query = query & ")"
		
		dbInsert query

		set rs = dbSelect("select @@IDENTITY as NewID")
		createNewDelivery = rs("NewID")

		set rs = nothing
		
		closeConnection
	end function
	
	
	function getRouteStopOrder(routeNumber, stopOrder)
		dim query, rs

		query = " select routestoporder from route where routenumber = " & routeNumber

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getRouteStopOrder = stopOrder + clng(rs("routestoporder")) * 10000
		else
			getRouteStopOrder = stopOrder
		end if
	
	end function
	
	function addStopToDelivery(pdeliveryid, customerseq)
		dim query, rs
		dim deliverystopid
		dim paymenttype
		dim routeid
		dim customerdeliveryid
		dim deliveryaddress
		dim deliverynotes
		dim stopOrder
		dim addressValidated
		dim deliveryphone
		dim mapAddress
		dim parentCustomerSequenceNumber
		dim billingCustomerSequenceNumber
		dim routeStopOrder
		
		deliverystopid = ""

		if pdeliveryid = "" then
			pdeliveryid = createNewDelivery(Session("EmployeeID"), 1)
			deliveryid = pdeliveryid
		end if

		
		deliverystopid = getStopInDelivery(pdeliveryid, customerseq)

		
		
		if deliverystopid = "" then
			query = getCustomerDeliveryQuery(deliveryDate, customerseq, routeNumber)

			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				deliveryaddress = rs("deliveryaddress")
				deliverynotes = rs("deliverynotes")
				routeid = rs("routeid")
				customerdeliveryid = rs("id")
				stopOrder = rs("stopOrder")
				addressValidated = rs("addressValidated")
				mapAddress = rs("mapAddress")
				deliveryphone = rs("deliveryPhone")
				parentCustomerSequenceNumber = rs("parentCustomerSequenceNumber")
				billingCustomerSequenceNumber = rs("billingCustomerSequenceNumber")
				routeStopOrder = getRouteStopOrder(routeid, stopOrder)
				
				set rs = nothing
				
				openConnection
				
				query = " insert into deliverystop (customersequencenumber, deliveryaddress, deliveryphone, deliverynotes, routeid, customerdeliveryid, deliveryid, stoporder, addressValidated, mapAddress, parentCustomerSequenceNumber, billingCustomerSequenceNumber) "
				query = query & " values( "
				query = query & " " & customerseq
				query = query & ", '" & DBStr(deliveryaddress) & "'"
				query = query & ", '" & DBStr(deliveryphone) & "'"
				query = query & ", '" & DBStr(deliverynotes) & "'"
				query = query & ", " & DbCreateQryString(routeid)
				query = query & ", " & customerdeliveryid 
				query = query & ", " & pdeliveryid
				query = query & ", " & routeStopOrder
				
				if addressValidated then
					query = query & ", 1"
				else
					query = query & ", 0"
				end if
				
				if mapAddress then
					query = query & ", 1"
				else
					query = query & ", 0"
				end if
				
				if isnull(parentCustomerSequenceNumber) then
					query = query & ", null"
				else
					query = query & ", " & parentCustomerSequenceNumber
				end if
				
				if isnull(billingCustomerSequenceNumber) then
					query = query & ", null"
				else
					query = query & ", " & billingCustomerSequenceNumber
				end if
				
				query = query & ")"

				
				dbSelect query
				set rs = dbSelect("select @@IDENTITY as NewID")
				deliverystopid = rs("NewID")
				set rs = nothing
				closeConnection
				
				if not isnull(parentCustomerSequenceNumber) then
					addStopToDelivery pdeliveryid, parentCustomerSequenceNumber
				end if
			end if
		end if

		
		addStopToDelivery = deliverystopid
	end function
	

	function addRoute(deliveryID, routeNumber, routeDept, pickups, dropoffs)
		dim query, rs
		dim dayOfWeek
		dim dayOfWeekColumnName
		dim dayOfWeekColumnNames

		
		dayOfWeekColumnNames = Array("DeliverSun", "DeliverMon", "DeliverTue", "DeliverWed", "DeliverThu", "DeliverFri", "DeliverSat")
		
		dayOfWeek = DATEDIFF("d", DATEADD("ww", DATEDIFF("ww",0,deliveryDate) - 1, 0), deliveryDate) - 1
		
		dayOfWeekColumnName = dayOfWeekColumnNames(dayOfWeek)
		
		set rs = getDeliveryListRS(deliveryDate)
		
		if routeNumber <> "" then
			if routeDept <> "" then
				rs.filter = "(routeID = " & routeNumber & " and parentCustomerSeq = " & routeDept & ") or (routeID = " & routeNumber & " and customersequencenumber = " & routeDept & ")"
			else
				rs.filter = "routeID = " & routeNumber
			end if
		end if
		
		
		
		while not(rs.eof or rs.bof)
			if (rs(dayOfWeekColumnName) = 1 or rs(dayOfWeekColumnName) = 3) and not isnull(rs("invoicenumber")) then
				if dropoffs and not isTicketInDelivery("", rs("ticketnumber")) then
					addInvoiceToDelivery deliveryID, rs("invoicenumber")
				end if
				
				if rs(dayOfWeekColumnName) = 3 and pickups and not isStopInDelivery("", rs("id"), deliveryDate) then
					addStopToDelivery deliveryID, rs("customersequencenumber")
				end if
			elseif rs(dayOfWeekColumnName) = 2 or rs(dayOfWeekColumnName) = 3 then
				if pickups and not isStopInDelivery("", rs("id"), deliveryDate) then
					addStopToDelivery deliveryID, rs("customersequencenumber")
				end if
			end if
			
			rs.movenext
		wend

		set rs = nothing
	end function
	
	function removeStop(deliveryID, customersequencenumber)
		dim query
		
		query = " update ticket set ticketstatus = 'AC' where "
		query = query & " ticketnumber in ("
		query = query & " select ticketnumber from deliveryitem inner join deliverystop on "
		query = query & " deliveryitem.deliverystopid = deliverystop.deliverystopid "
		query = query & " where deliverystop.deliveryid = " & deliveryID
		query = query & " and deliverystop.customersequencenumber = " & customersequencenumber
		query = query & " )"
		
		qryexecute query
		
		query = " delete from deliveryitem where "
		query = query & " deliverystopid in "
		query = query & " (select deliverystopid from deliverystop "
		query = query & "  where deliveryid = " & deliveryID
		query = query & "  and customersequencenumber = " & customersequencenumber
		query = query & " )"
		
		qryexecute query
		
		query = " delete from deliverystop "
		query = query & "  where deliveryid = " & deliveryID
		query = query & "  and customersequencenumber = " & customersequencenumber
		
		qryexecute query
		
	end function
	
	function removeRoute(deliveryID, routeNumber)
	
		query = " update ticket set ticketstatus = 'AC' where "
		query = query & " ticketnumber in ("
		query = query & " select ticketnumber from deliveryitem inner join deliverystop on "
		query = query & " deliveryitem.deliverystopid = deliverystop.deliverystopid "
		query = query & " where deliverystop.deliveryid = " & deliveryID
		
		if routeNumber <> "" then
			query = query & " and deliverystop.routeid = " & routeNumber
		end if
		
		query = query & " )"
		
		qryexecute query
		
		dim query
		
		query = " delete from deliveryitem where "
		query = query & " deliverystopid in "
		query = query & " (select deliverystopid from deliverystop "
		query = query & "  where deliveryid = " & deliveryID
		
		if routeNumber <> "" then
			query = query & "  and routeid = " & routeNumber
		end if
		
		query = query & " )"
		
		qryexecute query
		
		query = " delete from deliverystop "
		query = query & "  where deliveryid = " & deliveryID
		
		if routeNumber <> "" then
			query = query & "  and routeid = " & routeNumber
		end if
		
		qryexecute query
		
	end function
	
	function getTodaysDate()
		getTodaysDate = FormatDateTime(Now(), vbShortDate)
	end function



	function getDeliveryDayHTML(daystatus)
		select case daystatus
		case 0
			getDeliveryDayHTML = "No Delivery"
		case 1
			getDeliveryDayHTML = "Dropoff"
		case 2
			getDeliveryDayHTML = "Pickup"
		case 3
			getDeliveryDayHTML = "Pickup and Dropoff"

		end select
	end function
	
	function getCommercialAccounts(routeNumber)
		dim query, rs
		
		query = "select distinct parentCustomer.customername, parentCustomer.customersequencenumber "
		query = query & " from customer parentCustomer inner join "
		query = query & " customer childCustomer "
		query = query & " on parentCustomer.customerSequenceNumber = childCustomer.parentCustomerSeq "
		query = query & " where parentCustomer.isactive = 1 and childCustomer.isactive = 1 "
		if routeNumber <> "" then
			query = query & " and parentCustomer.routeNumber = " & routeNumber
		end if
		
		set getCommercialAccounts = getdisconnectedrecordset(query)
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript">

	function removeStopFromDelivery(customersequencenumber) {
		document.deliveryEdit.action = "?useraction=removestopfromdelivery&customersequencenumber=" + customersequencenumber;
		document.deliveryEdit.submit();
	}
	
	function addStopToDelivery(customersequencenumber) {
		document.deliveryEdit.action = "?useraction=addstoptodelivery&customersequencenumber=" + customersequencenumber;
		document.deliveryEdit.submit();
	}
	
	function addOrRemoveInvoice() {
		var addOrRemove;
		var o;
		
		o = document.deliveryEdit.addorremove;
		addOrRemove = o.options[o.selectedIndex].value;
		
		document.deliveryEdit.action = "?useraction=addorremoveinvoice&addorremove=" + addOrRemove + "&invoicenumber=" + document.deliveryEdit.invoiceToAdd.value;
		document.deliveryEdit.submit();
	}
	
	function addInvoice(invoiceNumber) {
		document.deliveryEdit.action = "?useraction=addorremoveinvoice&addorremove=add&invoicenumber=" + invoiceNumber;
		document.deliveryEdit.submit();
	}
	function removeInvoice(invoiceNumber) {
		document.deliveryEdit.action = "?useraction=addorremoveinvoice&addorremove=remove&invoicenumber=" + invoiceNumber;
		document.deliveryEdit.submit();
	}
	
	function updateList() {
		document.deliveryEdit.action = "?useraction=update";
		document.deliveryEdit.submit();
	}
	
	function exitForm() {
		document.deliveryEdit.action = "/mainapp/delivery.asp?deliveryid=<%=deliveryid%>";
		document.deliveryEdit.submit();
	}
	
	function addRoute() {
		document.deliveryEdit.action = "?useraction=addroute";
		document.deliveryEdit.submit();
	}
	function addPickups() {
		document.deliveryEdit.action = "?useraction=addpickups";
		document.deliveryEdit.submit();
	}
	function addDropoffs() {
		document.deliveryEdit.action = "?useraction=adddropoffs";
		document.deliveryEdit.submit();
	}
	
	function removeRoute() {
		document.deliveryEdit.action = "?useraction=removeroute";
		document.deliveryEdit.submit();
	}
	
	function selectDate(element) {
		show_calendar("deliveryEdit." + element.name);
	}
	function captureKey(){
	
		if (event.keyCode == 13){
			addOrRemoveInvoice();
		}
	}
</script>

</HEAD>

<BODY STYLE="margin:0;padding:0" onload="document.getElementById('invoiceToAdd').focus();">
<!-- #include file="../include/banner.inc" -->
<FORM name="deliveryEdit" ID="deliveryEdit" METHOD=POST  style="margin:0;padding:0"> 

<INPUT type="hidden" name="deliveryID" value="<%=deliveryID%>">
<BR />
<TABLE style="width:100%">
	<TR>
		<TD valign="bottom" style="width:300px">
			<select name="addorremove">
				<option value="add">Add</option>
				<option style="color:#f00" value="remove"
				<% if request.querystring("addorremove") = "remove" then %>
				selected <% end if %> >Remove</option>
			</select>

			<input name="invoiceToAdd" onkeyup="captureKey();" />
			<input onclick="addOrRemoveInvoice();"  type="button" value="Go" style="width:50px" />
		</TD>
		<TD align="center" >

			<SELECT name="routeNumber" onchange="updateList()">
				<!-- <OPTION value="" <%if trim(routeNumber) = "" then%>selected<%end if%>>(All)</OPTION> -->
			<%
			dim routeRS

			set routeRS = getRoutes()

			while not(routeRS.eof or routeRS.bof)
			%>
				<OPTION value="<%=routeRS("routeNumber")%>"
				<%if trim(routeRS("routeNumber")) = trim(routeNumber) then%>selected<%end if%>>
					<%=routeRS("name")%><% if isRouteInDelivery(deliveryid, routeRS("routeNumber")) then %> (Delivery Present)<% end if %>
				</OPTION>
			<%
				routeRS.movenext
			wend
			set routeRS = nothing
			%>
			</SELECT>

			<SELECT id="routeDept" name="routeDept" onchange="updateList()">
				<OPTION value="">All</OPTION>
	<%
			set rs = getCommercialAccounts(routeNumber)
			while not(rs.eof or rs.bof)
	%>
				<OPTION value="<%=rs("customerSequenceNumber")%>" <%if trim(rs("customerSequenceNumber")) = trim(routeDept) then %>selected<% end if %> ><%=rs("customername")%></OPTION>
	<%
				rs.movenext
			wend
			set rs = nothing
	%>
			</SELECT>

			<INPUT <% if not allow_editDeliveryDate then %>readonly<%else%>onclick="selectDate(this);"<%end if%> style="width:80px;text-align:center"  name="deliveryDate" class="txtDate" value="<%=deliveryDate%>" />
			<INPUT type="button" value="Update" onclick="updateList()" />
		</TD>

	</TR>
</TABLE>

<BR />

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">

	<SPAN style="float:left">
        <BUTTON onclick="addRoute()">Add All</BUTTON>
        <BUTTON onclick="addPickups()">Add<BR />Pickups</BUTTON>
        <BUTTON onclick="addDropoffs()">Add<BR />Dropoffs</BUTTON>
        <BUTTON onclick="removeRoute()">Remove<BR />All</BUTTON>
	</SPAN>
 
	<SPAN style="float:right">
        <BUTTON onclick="exitForm()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" cellspacing="0">
	<TR>
		<TH style="width:100px">Pickup</TH>
		<TH>Stop</TH>
		<TH>Customer</TH>
		<TH>Address</TH>
		<TH>Route</TH>
		<TH>Action</TH>
		<TH>Invoices</TH>
	</TR>
<%
	dim deliveryListRS
	dim dayOfWeek
	dim dayOfWeekColumnName
	dim dayOfWeekColumnNames
	dim previousCustomerMark
	dim thisCustomerMark
	dim done
	dim totalItems
	dim totalItemsOnDelivery
	dim totalStops
	dim totalStopsOnDelivery
	
	totalItems = 0
	totalItemsOnDelivery = 0
	totalStops = 0
	totalStopsOnDelivery = 0
	
	dayOfWeekColumnNames = Array("DeliverSun", "DeliverMon", "DeliverTue", "DeliverWed", "DeliverThu", "DeliverFri", "DeliverSat")
	
	dayOfWeek = DATEDIFF("d", DATEADD("ww", DATEDIFF("ww",0,deliveryDate) - 1, 0), deliveryDate) - 1
	
	dayOfWeekColumnName = dayOfWeekColumnNames(dayOfWeek)

	set deliveryListRS = getDeliveryListRS(deliveryDate)


	if routeNumber <> "" then
		if routeDept <> "" then
			deliveryListRS.filter = "(routeID = " & routeNumber & " and parentCustomerSeq = " & routeDept & ") or (routeID = " & routeNumber & " and customersequencenumber = " & routeDept & ")"
		else
			deliveryListRS.filter = "routeID = " & routeNumber
		end if
	end if
	

	
	done = deliveryListRS.eof or deliveryListRS.bof

	
	if not done then
		thisCustomerMark = deliveryListRS("customersequencenumber") & deliveryListRS(dayOfWeekColumnName)
	end if

	while not done
	
		previousCustomerMark = thisCustomerMark
		
		if isnull(deliveryListRS("ticketnumber")) and deliveryListRS(dayOfWeekColumnName) = 1 then
			previousCustomerMark = thisCustomerMark
			deliveryListRS.movenext
			done = deliveryListRS.eof or deliveryListRS.bof
			if not done then
				thisCustomerMark = deliveryListRS("customersequencenumber") & deliveryListRS(dayOfWeekColumnName)
			end if
		else
%>
	<TR>
		<TD align="center" style="width:100px">
		<%if true then%>
			<% if trim(deliveryid) <> "" and isStopInDelivery(deliveryid, deliveryListRS("id"), deliverydate) then %>
			<INPUT style="height:40px;width:80px;background:#0f0" type="button" onclick="removeStopFromDelivery(<%=deliveryListRS("customersequencenumber")%>)" value="Remove" />			
			
			<%
				totalStopsOnDelivery = totalStopsOnDelivery + 1
				totalStops = totalStops + 1
				elseif deliveryListRS(dayOfWeekColumnName) = 1 or isStopInDelivery("", deliveryListRS("id"), deliverydate) then
			%>	
			<INPUT style="height:40px;width:80px" type="button" disabled value="" />
			<% else %>
			<INPUT style="height:40px;width:80px" type="button" onclick="addStopToDelivery(<%=deliveryListRS("customersequencenumber")%>)" value="Pickup" />
			<%
				totalStops = totalStops + 1
				end if%>
			
			
		<%
			
			end if%>

		</TD>
		
		<TD align="center"><%=deliveryListRS("stopOrder")%></TD>
		<TD align="center"><%=deliveryListRS("customername")%></TD>
		<TD align="center" <% if allow_generateDirections and not deliveryListRS("addressValidated") then%>style="border: 3px double red;"<%end if%> ><%=replace(deliveryListRS("deliveryaddress"), vbcrlf, "<br />")%></TD>
		<TD align="center"><%=deliveryListRS("routename")%></TD>
		<TD align="center"><%=getDeliveryDayHTML(deliveryListRS(dayOfWeekColumnName))%></TD>
		<TD align="center">

<%
		while not done and thisCustomerMark = previousCustomerMark

			if not isnull(deliveryListRS("ticketnumber")) and (deliveryListRS(dayOfWeekColumnName) = 1 or deliveryListRS(dayOfWeekColumnName) = 3) then
				
				if trim(deliveryid) <> "" and isTicketInDelivery(deliveryid, deliveryListRS("ticketnumber")) then
%>
		<INPUT type="button" value="<%=deliveryListRS("invoicenumber")%>" style="background:#0f0" onclick="removeInvoice(<%=deliveryListRS("invoicenumber")%>)" />
<%
					totalItemsOnDelivery = totalItemsOnDelivery + 1
					totalItems = totalItems + 1
				elseif isTicketInDelivery("", deliveryListRS("ticketnumber")) then
%>
		<INPUT type="button" value="<%=deliveryListRS("invoicenumber")%>" disabled />
<%
				else		
%>
		<INPUT type="button" value="<%=deliveryListRS("invoicenumber")%>" onclick="addInvoice(<%=deliveryListRS("invoicenumber")%>)" />
<%
					totalItems = totalItems + 1
				end if
			end if
			
			previousCustomerMark = thisCustomerMark
			deliveryListRS.movenext
			done = deliveryListRS.eof or deliveryListRS.bof
			if not done then
				thisCustomerMark = deliveryListRS("customersequencenumber") & deliveryListRS(dayOfWeekColumnName)
			end if
		wend
%>
		</TD>
	</TR>
	
<%
		end if
	wend
	
	set deliveryListRS = nothing
%>
<TR>
	<TD colspan="7" align="center" style="padding:10px;border-top:1px solid #ddd;background:#fcfcfc">
		Items: <%=totalItemsOnDelivery%>/<%=totalItems%>&nbsp;&nbsp;&nbsp;
		Stops: <%=totalStopsOnDelivery%>/<%=totalStops%>
	</TD>
</TR>
</TABLE>


</FORM>
</BODY>
</HTML>
