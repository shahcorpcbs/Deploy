<%
	class CardTransactionCredentials
		public Version
		public ID
		public TerminalType
		public Token
		public Industry
		public TerminalID
	end class
	

	class CardTransactionResults
		public CardTransactionID
		public CardProcessorType
		public CardTransactionType
		public TerminalID
		public EmployeeID
		public CustomerSequenceNumber
		public TimeRequested
		public TimeComplete
		public Success
		public ProcessorResponse
		public ProcessorBatchID
		public ProcessorBatchAmount
		public ProcessorApprovalCode
		public OrderAmount
		public OrderTax
		public OrderID
		public CardMasked
		public CardExpiration
		public CardType
		public CardAlias
		public PaymentNumber
		public BankApprovalCode
		public CardHolderName
		public ProcessorReferenceID
		public AuthorizedAmount
		public CardOnFileAction
		public TransactionIndustry
		public ISOCode
		public AccountSource
		public TransactionConditionCode
		public CustomerZIP

	end class

%>