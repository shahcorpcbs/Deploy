
<%@ Language=VBScript %>

<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->

<%
	on error resume next

	Response.AddHeader "Content-Type", "type=""text/html"""
	Response.AddHeader "Content-Disposition", "attachment;filename=""report.html"""
%>


<% if Session("objRP").reportFormat =  RPT_Report_Format_HTML then %>

<HTML>

<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0" >
<TITLE>Report</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<BODY topmargin=0 leftmargin=0>

<% else %>

<HTML>

<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0" >
<TITLE>Report</TITLE>
</HEAD>

<BODY topmargin=0 leftmargin=0>

<PRE>
<% end if %>

<!--
<FORM id="reportDisplayForm" name="reportDisplayForm" action="" method="post">
	<INPUT type="hidden" name="reportAction" value= "<%=reportAction%>">
-->

<%


	on error resume next

    dim objReport
    dim strStream
    dim reportFormat
	dim reportAction

	dim previousTimeoutValue
	dim reportTimeoutValue

	previousTimeoutValue = Server.ScriptTimeout
	reportTimeoutValue = 360000

	' If not supplied, assume that the report format is HTML
    reportFormat = IIf(Request.QueryString("reportFormat") = "", "HTML", Request.QueryString("reportFormat"))

    reportAction = Request.Form("reportAction")

    set objReport = CreateObject("CBSReports.clsReport")

	session("reportStream") = ""

	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & "-Function= Report Display. Error while creating Report Object (CBSReports.clsReport). Please make sure that the latest version of the component (CBSReports.dll) is installed."
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if

	Session("objRP").reportAction = reportAction

	Server.ScriptTimeout = reportTimeoutValue

	if _
	Session("objRP").reportNumber = RPT_NBR_AR_Statement Or  _
	Session("objRP").reportNumber = RPT_NBR_AR_MultiPickup_Statement _
  then
		if Session("objRP").requesterName = RPT_Requester_Name_Statement_History then
			' This is not generating the report, but just getting the blob stored
			' in the database for previous report generation.
		    objReport.GetPreviousARStatement(Session("objRP"))
		    Response.Write Session("objRP").reportStream
			Session("reportStream") = Session("objRP").reportStream
		else
			if Session("objRP").customerSequenceNumber = 0 then
				' If one customer is selected, just run the report
				' Get list of customers for the selection criteria and execute the
				' report for each one, and disply with page breaks.
				Dim strSQL
				Dim strWHERE
				strWHERE = ""
				strSQL = "SELECT customerSequenceNumber FROM Customer "

				strWHERE = " WHERE (permanentAccount = 1 OR (dbo.getAccountBalance(customersequencenumber, null) > 0.005)) and (ExcludeFromAR = 0)"

				If Session("objRP").reportNumber = RPT_NBR_AR_MultiPickup_Statement Then
					strWHERE = strWHERE & " AND multiplePickup = 1 "
				Else
					strWHERE = strWHERE & " AND multiplePickup = 0 "
				End if

				If Session("objRP").storeID > 0 then
					strWHERE = strWHERE & _
					           IIf(strWHERE = "",  " WHERE ", " AND ") & _
							   " storeID = " + CStr(Session("objRP").storeID)
				end if

				If Session("objRP").priceListID > 0 then
					strWHERE = strWHERE & _
					           IIf(strWHERE = "",  " WHERE ", " AND ") & _
							   " defaultPriceListID = " + CStr(Session("objRP").priceListID)
				end if

				If Session("objRP").routeNumber >= 0 then
					strWHERE = strWHERE & _
					           IIf(strWHERE = "",  " WHERE ", " AND ") & _
							   " routeNumber = " + CStr(Session("objRP").routeNumber)
				'Change for all choice for routes
				Else
					strWHERE = strWHERE
				end if

				' Response.Write strSQL & " " & strWHERE

				strWHERE = strWHERE & " ORDER BY LastName, FirstName"

				Dim objRS
				Dim firstOne
				'added 11/18/2003 MWiemann anyData determines if there is data to display.
				'                          if there is no data, an error message is returned
				Dim anyData

				firstOne = true
				anyData = false
				Set objRS = getDisconnectedRecordset(strSQL & " " & strWHERE)
				if not objRS is nothing then
					while (not objRS.EOF)
						Session("objRP").customerSequenceNumber = objRS("customerSequenceNumber").value
						objReport.CreateStandardReport(Session("objRP"))
						if not Session("objRP").noDataFound and Session("objRP").reportStream <> "" then
							if firstOne = false then
								Response.Write "<H6 STYLE=""page-break-after:always;"">&nbsp;</H6>"
								Session("reportStream") = Session("reportStream") & "<H6 STYLE=""page-break-after:always;"">&nbsp;</H6>"
							end if
							Response.Write Session("objRP").reportStream
							Session("reportStream") = Session("reportStream") & Session("objRP").reportStream
							firstOne = false
							anyData = true
						end if
						objRS.MoveNext
					wend
					if anyData = false then
						Response.Write "<TABLE ALIGN=CENTER><TR><TD align=center STYLE=FONT-SIZE=18><BR><BR><BR><B> " & _
						               "There is no data to satisfy the selection criteria.<BR>Please change criteria " & _
						               "and run report again, if you wish.</B></TD></TR></TABLE>"
					end if
				end if

			else
				' Response.Write "Customer sequence number greater than 0"
				objReport.CreateStandardReport(Session("objRP"))
				if not Session("objRP").noDataFound then
					Response.Write Session("objRP").reportStream
					Session("reportStream") = Session("objRP").reportStream
				else
					Response.Write "<TABLE ALIGN=CENTER><TR><TD align=center STYLE=FONT-SIZE=18><BR><BR><BR><B> " & _
  					                  "There is no data to satisfy the selection criteria.<BR>Please change criteria " & _
					 	               "and run report again, if you wish.</B></TD></TR></TABLE>"
				end if
			end if
		end if
  else
		objReport.CreateStandardReport(Session("objRP"))

		'if _
		'	Session("objRP").reportNumber = RPT_NBR_Mailing_Label _
		'then
		'	WriteReportStream
		'else
			Response.Write Session("objRP").reportStream
		'end if
	end if

	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")

		errorList.Add err.number, err.Source & err.description

		set session("errorList") = errorList

		Response.redirect("../include/error.asp")
	else
		' Response.Write Session("objRP").reportStream
	end if

	Server.ScriptTimeout = 	previousTimeoutValue
%>

<%

sub WriteReportStream()

	Dim objFS
	Dim objFile

	'Response.Write "Creating File System object"
    Set objFS = CreateObject("Scripting.FileSystemObject")
	'Response.Write "Created File System object"

	'Response.Write "Creating File object"
    Set objFile = objFS.OpenTextFile(Session("objRP").currentReportFile & Session("objRP").currentReportExtension, 1, False, 0)

	'Response.Write "Getting in to loop"
	Do While objFile.AtEndOfStream <> True
		'Response.Write "Reading line"
		Response.Write objFile.ReadLine
	Loop

	objFile.Close

	Set objFile = nothing
	Set objFS = nothing

end sub

%>

<% if Session("objRP").reportFormat =  RPT_Report_Format_HTML then %>

</FORM>
</BODY>
</HTML>

<% else %>

</PRE>

<% end if %>

