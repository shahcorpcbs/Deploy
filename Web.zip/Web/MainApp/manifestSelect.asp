<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp" -->

<!-- #include file="../include/manifest.asp" -->

<!-- #include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim daysOfHistory
	dim orderBy
	dim manifestid
	dim inventoryid
	
	
	manifestid = getReqVar("manifestid")
	
	daysOfHistory = getReqVar("daysOfHistory")
	if daysOfHistory = "" then daysOfHistory = 0
	orderBy = getReqVar("orderBy")
	
	select case lcase(request.querystring("useraction"))
	case "begininventory"
		inventoryid = beginInventory()
		response.redirect "/mainapp/manifestInventory.asp?inventoryid=" & inventoryid
	end select


	function beginInventory()
		dim query, rs
		dim inventoryid
		dim selManifestID
		
		
		query = " insert into inventory (manifestid) "
		query = query & " values(" & manifestid & ")"
		
		inventoryid = dbInsertWithIdentity(query)
	
		for each selManifestID in request.form("chkManifest")
			query = " insert into inventorymanifest(inventoryid, manifestid) "
			query = query & " values ("
			query = query & inventoryid
			query = query & ", " & selManifestID
			query = query & ")"
			
			qryexecute query
		next
		
		beginInventory = inventoryid
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	

%>


<HTML>
<HEAD>


<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" src="../external/jquery-3.4.1.js"></script>
<script language="javascript" type="text/javascript">

	function exit() {
		document.manifestList.action = "/mainapp/manifestCreate.asp";
		document.manifestList.submit();
	}
	
	function selectManifests() {
		var il = document.manifestList;
		var len = il.elements.length;
		var manifestID = 0;
		var invoiceCount = 0;
		
		for (var i = 0; i < len; i++) {
		    var e = il.elements[i];
		    if (e.name == "chkManifest" && e.checked) {
				manifestID = e.value;
				++invoiceCount;
		    }
		}

		if(invoiceCount > 0) {
			document.manifestList.action = "?useraction=begininventory";
			document.manifestList.submit();
		}
		else {
			cbs_alert("Must select an manifest before performing action.");
		}
	}

	function updateFilter() {
	      document.manifestList.action = "?useraction=updatefilter";
	      document.manifestList.submit();
	}
	
	function SetRowCheckedStatus(row, check, value) {
				
		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "chkManifest") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked), false);
				break;
			}
			else if (childEl.name == "chkManifest") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked), false);
				break;
			}
		}
	}
</script>

<style type="text/css">

</style>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="" onsubmit="return false;">
<!-- #include file="../include/banner.inc" -->
<FORM name="manifestList" ID="manifestList" METHOD=POST  style="margin:0;padding:0"> 
<INPUT type="hidden" name="manifestid" value="<%=manifestid%>" />


<h1>Select Scanned Manifests</h1>



<DIV style="text-align: center; font-size: 18; padding: 8px" >
Show since
<SELECT name="daysOfHistory" onchange="updateFilter()">
	<OPTION value="0" <%if daysOfHistory = 0 then%>selected<%end if%>>Today</OPTION>
	<OPTION value="1" <%if daysOfHistory = 1 then%>selected<%end if%>>Yesterday</OPTION>
	<OPTION value="7" <%if daysOfHistory = 7 then%>selected<%end if%>>Last Week</OPTION>
	<OPTION value="30" <%if daysOfHistory = 30 then%>selected<%end if%>>Last Month</OPTION>
	<OPTION value="90" <%if daysOfHistory = 90 then%>selected<%end if%>>Last Quarter</OPTION>
	<OPTION value="365" <%if daysOfHistory = 365 then%>selected<%end if%>>Last Year</OPTION>
	<OPTION value="32000" <%if daysOfHistory = 32000 then%>selected<%end if%>>All</OPTION>
</SELECT>

order
<SELECT name="orderby" onchange="updateFilter()">
	<OPTION value="asc" <%if orderBy = "asc" then%>selected<%end if%>>Ascending</OPTION>
	<OPTION value="desc" <%if orderBy = "desc" then%>selected<%end if%>>Descending</OPTION>
</SELECT>
</DIV>


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
		<BUTTON onclick="selectManifests()">Select</BUTTON>
	</SPAN>
</DIV>	

<DIV style="overflow:scroll; height: 570px">
<TABLE class="itable" cellspacing="0">

	<TR>
		<TH>&nbsp;</TH>
		<TH style="width:100px">Manifest #</TH>
		<TH>Name</TH>
		<TH>Date Created</TH>
		<TH>Note</TH>
		<TH>Invoice Count</TH>
	<TR>

<%
	query = " select isnull(convert(varchar, m1.dateracked, 101), '') as dateracked, m1.name, m1.manifestid, m1.parentmanifestid, m1.datecreated, isnull(m2.name, '') as parentname, dbo.getItemCountOnManifest(m1.manifestID) as itemCount from "
	query = query & " manifest m1 "
	query = query & " left outer join manifest m2 on m1.parentmanifestid = m2.manifestid "
	query = query & " where m1.active = 1 "
	query = query & " and m1.type <> 'TLIST' "
	query = query & " and datediff(day, m1.datecreated, getdate()) <= " & daysOfHistory
	
	if orderBy = "desc" then
		query = query & " order by isnull(m1.parentmanifestid, m1.manifestid) desc, m1.parentmanifestid desc  "
	else
		query = query & " order by isnull(m1.parentmanifestid, m1.manifestid), m1.parentmanifestid  "
	end if

	set rs = getdisconnectedrecordset(query)


	while not(rs.eof or rs.bof)
%>
	<% if isnull(rs("parentmanifestid")) then %>
		<TR manifestID="<%=rs("manifestid")%>" onclick="ToggleRowChecked(this)" class="manifest_head">
			<TD align="center"><INPUT type="checkbox" onclick="ToggleRowChecked(this.parentNode.parentNode);" value="<%=rs("manifestid")%>" name="chkManifest"></TD>
			<TD align="center"><IMG src="/static/icons/16x16/copy.png"> <%=rs("manifestid")%></TD>
			<TD><%=Server.HTMLEncode(rs("name"))%></TD>
			<TD><%=rs("datecreated")%></TD>
			<TD><%
				if rs("dateracked") <> "" then
					response.write "Racked " & rs("dateracked")
				else
					response.write "&nbsp;"
				end if
			%></TD>
			<TD><%=rs("itemCount")%></TD>
		</TR>
	<% else %>
		<TR manifestID="<%=rs("manifestid")%>" onclick="ToggleRowChecked(this)" class="manifest_item">
			<TD align="center"><INPUT type="checkbox" onclick="ToggleRowChecked(this.parentNode.parentNode);" value="<%=rs("manifestid")%>" name="chkManifest"></TD>
			<TD align="center"><IMG src="/static/icons/16x16/new.png"> <%=rs("manifestid")%></TD>
			<TD><%=Server.HTMLEncode(rs("name"))%></TD>
			<TD><%=rs("datecreated")%></TD>
			<TD><%
				if rs("dateracked") <> "" then
					response.write "Racked " & rs("dateracked")
				else
					response.write "&nbsp;"
				end if
			%></TD>
			<TD><%=rs("itemCount")%></TD>
		</TR>
	<% end if %>
<%
		rs.movenext
	wend

	set rs = nothing
%>

</TABLE>
</DIV>

</FORM>
</BODY>
</HTML>
