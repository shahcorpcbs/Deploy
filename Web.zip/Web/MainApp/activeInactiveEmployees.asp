<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim l_storeid
	dim isSubmitted 
	'dim actionstring
	dim l_status
	
	l_storeid = Session("storeid")
	isSubmitted = Request.QueryString("submitted")
	
	if isSubmitted then
		UpdateDatabase()
	end if
	
	''actionstring= Request.QueryString("useraction")
	
	getEmployeesList()
%>
<HTML>
<HEAD>
<TITLE>Activate Inactivate Employees</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(element) {
	
		switch (element){
			case "ok":
				document.activateInactivateEmp.action="employeeManagement.asp";
				break;
			case "cancel":
				document.activateInactivateEmp.action="employeeManagement.asp";
				break;
			case "makeActive":
				document.activateInactivateEmp.action="?Submitted=true&status=active";
				break;
			case "makeInActive":
				document.activateInactivateEmp.action="?Submitted=true&status=inactive";
				break;
			
		}
		
		document.activateInactivateEmp.submit();
	}
	
	function selectAll(){
	var i;
	var x;
	i = 0
		if ( document.activateInactivateEmp.select != null){
			if (document.activateInactivateEmp.select.length >0 ) {
			    var items = document.getElementsByName("select")
				while (i < items.length) {
					if (! items[i].disabled) {
						items[i].checked=!items[i].checked;
					}
					i++;
				}
			}
		}
	}
	
</script>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Make Employee Active or Inactive</H1>
<FORM id="activateInactivateEmp" name="activateInactivateEmp" action="" method="post" onsubmit="return false">
	<TABLE ALIGN=center WIDTH="700px" BORDER=0 CELLSPACING=0 CELLPADDING=2 >
		<tr height=40px></tr>
		<!-- header row -->
		<tr>
			
			<td align=right>
				<TABLE WIDTH="350px" BORDER=0 CELLSPACING=1 CELLPADDING=5>
					<!-- heading -->
					<tr>
						<th width=30px></th>
						<th width =230px align=left class="label">Employee Name</th>
						<th  align=left class="label">Status</th>				
					</tr>
				</table>
			</td>
		</tr>
		<!-- list -->
		<tr>
			<td align=right rowspan=3>
				<DIV STYLE="overflow-y:auto;height:200px; overflow-x:auto; width:350px">
						<TABLE WIDTH="100%" style="border-color:#2F4F4F;border-style:solid;background-color:white;" BORDER=1 CELLSPACING=0>
							<tr rowspan =5>
								<td>
									<TABLE WIDTH="100%" align=center style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=3>
									<!-- to be removed while coding -->	
										<tr><td>
											<%GetEmployeesList()
												if rstList.recordcount > 0 then
													while not rstlist.eof 
											%>
													<tr>
													<td width=30px><input type="checkbox" name="select" id="select" STYLE="height=28px;width=28px;" value ="<%=rstList("Employeeid")%>"
													<% if rstList("Employeeid")= "1" then %>
														Disabled
													<% end if %>
													></td>
													<td width = 250px  STYLE="FONT-SIZE: 16px;"><%=rstList("firstname")& " " & rstList("LastName")%></td>
													<td width = 25px  STYLE="FONT-SIZE: 16px;"><%=rstList("EmployeeStatus")%></td>
													</tr>
											<%		rstlist.movenext
													wend
													end if
													rstList.close
												set rstlist = nothing
											%>
											
										</tr>
										
									</table>
								</td>
							</tr>
					</table> <!-- table for border -->
				</div>
			</td>
			<td align="center">
				<BUTTON class=std id=makeActive name=makeActive onClick="submitForm(this.name)"
					<%if totalcount = 0 then %>
						disabled
					<%end if%>>Make Active</button>
				<!--<INPUT class=touch id=makeActive name=makeActive type=button value=""  style="background-image:url(../images/Select.gif)" onClick="submitForm(this.name)"-->
			</td>
			<td width=50px></td>
		</tr>
		<tr>
			<td align="center">
				<!--<INPUT class=touch id=makeInActive name=makeInActive type=button value=""  style="background-image:url(../images/Un-Select-All-2.gif)" onClick="submitForm(this.name)"-->
				<BUTTON class=std id=makeInActive name=makeInActive onClick="submitForm(this.name)"
					<%if totalcount = 0 then %>
						disabled
					<%end if%>
				>Make Inactive</button>
			</td>
			<td width=50px></td>
		</tr>
		<tr>
			<td align="center">
				<!--<INPUT class=touch id=showAllEmp name=showAllEmp type=button  style="background-image:url(../images/Employee-Management.gif)" value="" onClick="selectAll()"><br>Show all Employees(Toggle)-->
				<BUTTON class=std id=showAllEmp name=showAllEmp onClick="selectAll()">Toggle All Employees</button>
			</td>
			<td width=50px></td>
		</tr>
		<tr height=20px></tr>
		<tr height=100px>
			<td align="center" colspan=2>
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=2>
					<tr>
						<td align="center">
							<INPUT class=touchnoborder id=ok name=ok type=button  style="background-image:url(../images/Ok.gif)" value="" onClick="submitForm(this.name)">&nbsp&nbsp&nbsp&nbsp&nbsp
							<INPUT class=touchnoborder id=cancel name=cancel type=button  style="background-image:url(../images/Cancel.gif)" value="" onClick="submitForm(this.name)">
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</form>
</BODY>
</HTML>
<%
	dim rstList
	dim totalcount
	totalcount = 0
	
	function getEmployeesList()
	dim sqltxt
		sqltxt = "select * from employee where storeid = " & l_storeid
		sqltxt = sqltxt & " order by lastname, firstname "
		set rstList = GetDisconnectedRecordset(sqltxt)
		if rstlist.recordcount > 0 then 
			totalcount = rstlist.recordcount
		end if
	end function
	
	function UpdateDatabase()
	dim sqltxt
	dim totalcount
	Dim i	
		totalcount = Request.Form("select").count
		if totalcount <=0 then
			exit function
		end if 
		l_status = Request.queryString("status")
		
			if l_status = "active" then
			
				dbstartTrans()	
				for i =  1 to totalcount 
					sqltxt  = "Update employee set employeestatus = 'A' where employeeid = " & Request.Form("select")(i)
					QryExecuteWithTrans(sqltxt)
				next
				DbEndTrans()
			
		elseif l_status = "inactive" then
		
				dbstartTrans()	
				for i =  1 to totalcount 
					sqltxt  = "Update employee set employeestatus = 'I' where employeeid = " & Request.Form("select")(i)
					QryExecuteWithTrans(sqltxt)
				next
				DbEndTrans()
		end if
	end function
%>

