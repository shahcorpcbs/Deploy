<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim targetPage
	'dim dueDateSet
	dim addOrEdit
	dim onHold
	dim actionString
	dim submitAction
	dim validate 
	dim invNumber
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	
	actionString = Request.QueryString("userAction")
	if IsEmpty(actionString) then
		targetPage = Request.QueryString("targetPage")
		'dueDateSet = Request.QueryString("isDueDateSet")
		addOrEdit = Request.QueryString("addOrEdit")
		onHold = Request.QueryString("onHold")
		curr_LineNo = Request.QueryString("lineNo")
		selectedDept = Request.QueryString("dept")
		itemsStartIndex = Request.QueryString("itIndex")
		upChargeStartIndex = Request.QueryString("upIndex")
		colorsStartIndex = Request.QueryString("cIndex")
		patternStartIndex = Request.QueryString("pIndex")
		deptStartIndex = Request.QueryString("deptIndex")
		selItemId = Request.QueryString("selItemId")
		selUpchargeValue = Request.QueryString("selUp")
		selColorValue = Request.QueryString("selColor")
		selPatternValue = Request.QueryString("selPattern")
	else
		
		targetPage = Request.Form("tPage")
		'dueDateSet = Request.Form("isDueDateSet")
		addOrEdit = Request.Form("addOrEdit")
		onHold = Request.Form("onHold")
		curr_LineNo = Request.Form("lineNumber")
		selectedDept = Request.Form("selectedDept")
		itemsStartIndex = Request.Form("ItemPageCount")
		upChargeStartIndex = Request.Form("upChargePageCount")
		colorsStartIndex = Request.Form("colorsPageCount")
		patternStartIndex = Request.Form("PatternPageCount")
		deptStartIndex = Request.Form("DeptPageCount")
		selItemId = Request.Form("selItemId")
		selUpchargeValue = Request.Form("selUpcharge")
		selColorValue = Request.Form("selColor")
		selPatternValue = Request.Form("selPattern")
		invNumber =""
		if actionString = "submit" then
			submitAction = Request.QueryString("submit")
			if submitAction ="ok" then
				invNumber = Request.Form("txtPrice")
				validate = validateInvNumber()
				if Not validate then
					Session("errorMessage") = "Duplicate invoice number. Go back and enter new number"
					Response.Redirect "invoiceErrorMessages.asp"
				end if
			end if
			select case targetPage
				case "quick"
					Response.Redirect "quickinvoice.asp?userAction=newInvoiceNo&submit=" & submitAction _
										& "&invNo=" & invNumber & "&addOrEdit=" & addOrEdit _
										& "&onHold=" & onHold & "&dept=" & selectedDept _
										& "&deptIndex=" & deptStartIndex		
				case "detail"
					Response.Redirect "detailedInvoice.asp?userAction=newInvoiceNo&submit=" & submitAction _
										& "&invNo=" & invNumber & "&addOrEdit=" & addOrEdit _
										& "&onHold=" & onHold &  "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
										& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
										& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
										& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
										& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue
				case "counterSale"
					Response.Redirect "counterSale.asp?userAction=newInvoiceNo&submit=" & submitAction _
										& "&invNo=" & invNumber & "&addOrEdit=" & addOrEdit _
										& "&onHold=" & onHold &  "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
										& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
										& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
										& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
										& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue	
			end select
		end if	
	end if
	
	function validateInvNumber()
		dim ssql
		dim storeId
		dim objResultSet
		
		storeId = Session("storeID")
		ssql = "Select count(*) as NoOfRows from Ticket where storeId=" & storeId _
				& " And invoiceNumber='" & invNumber & "'"
		set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Fields("NoOfRows").Value > 0 then
			validateInvNumber = false
		else
			validateInvNumber =true
		end if
	end function
%>
<HTML>
<HEAD>
<TITLE>Invoice Number</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
	var lastFocusControl;
function txtPrice_onblur() {
	lastFocusControl = event.srcElement;
}
	
//-->
</SCRIPT>
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(userAction) {
		/*if(page == "quick") {
				document.invoiceNo.action = "quickinvoice.asp?userAction=invoiceNo&submit=" + userAction;
			}else {
				if(page == "detail") {
					document.invoiceNo.action = "detailedInvoice.asp?userAction=newInvoiceNo&submit=" + userAction;
				}
			}*/
		var invNo
		invNo = document.invoiceNo.txtPrice.value;
		if (userAction =="ok") {
			if (invNo.length > 0) {
				document.invoiceNo.action = "?userAction=submit&submit=" + userAction;
				document.invoiceNo.submit();
			}
			else {
				cbs_alert("Must enter an invoice Number");
			}
		}else{
			document.invoiceNo.action = "?userAction=submit&submit=" + userAction;
			document.invoiceNo.submit();
		}
	}
	function checkEnter(event){ 	
		var code = 0;
		
		code = event.keyCode;
		if (code==13)
			submitForm("ok");
	}

</script>

<BODY topmargin=0 leftmargin=0 onLoad="document.invoiceNo.txtPrice.focus();">

<!-- #include file="../include/banner.inc" -->
<H1>Enter Invoice Number</H1>
<FORM id="invoiceNo" name="invoiceNo" action="newInvoiceNumber.asp" method="post">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="onHold" value="<%= onHold %>">
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px><td></td></tr>
		<TR>
			<td width=50px></td>
			<TD class="label" align="right">New Invoice Number</TD>
			<TD align=left width=100px>
				<INPUT id=txtPrice name=txtPrice maxLength=20 class=text style="width:300px;" onblur="txtPrice_onblur()" onKeyPress="checkEnter(event);">
			</TD>
			<td align="center" width="60px">
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick= "submitForm('ok')">
			</td>
			<td align="center" width="60px">
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="submitForm('cancel');">
			</td>
		</TR>
		<TR height=20px></TR>
		<tr>
			<td colspan=5>
				<!-- #include file="../include/keyboard.inc" -->
			</td>
		</tr>
				
	</table>
</form>
</BODY>
</HTML>
	