<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/customerPaymentObj.asp" -->
<!-- #include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs

	select case lcase(request.querystring("useraction"))
		case "hs"
			doHeatsealDetailsRequest
		case "reset"
			doHeatsealReset
	end select
	
	function doHeatsealReset()
		dim query, rs
		dim heat_seals: heat_seals = request.querystring("heat_seals")
		dim heat_seal
		dim result
	
		for each heat_seal in split(heat_seals, ",")
			query = " delete from taggedpiece where heatsealid = '" & heat_seal & "'"
			qryexecute query
		next
		
		result = "{"
		result = result & """success"":1,"
		result = result & """message"":""" & jsencode("") & """"
		result = result & "}"
		
		response.write result
		response.end
	end function
	
	function doHeatsealDetailsRequest()
		dim query, rs
		dim heat_seal: heat_seal = request.querystring("heat_seal")
		dim result
		
		query = "select " 
		query = query & " taggedpiece.HeatSealID as heat_seal, " 
		query = query & " customer.customerName as customer_name, " 
		query = query & " isnull(pricelistitem.itemName + ' (' + dbo.pivotTaggedItemDescriptions(taggedpiece.TaggedItemID) + ')', '') as item_description " 
		query = query & " from taggedpiece " 
		query = query & " inner join taggeditem on TaggedPiece.TaggedItemID = TaggedItem.TaggedItemID " 
		query = query & " inner join PriceListItem on taggeditem.PriceListItemID = PriceListItem.priceListItemID " 
		query = query & " left outer join ticketlineitem on taggedpiece.heatsealid = ticketlineitem.heatseal " 
		query = query & " left outer join ticket on ticketlineitem.ticketnumber = ticket.ticketnumber " 
		query = query & " left outer join customer on ticket.customersequencenumber = customer.customersequencenumber " 
		query = query & " where taggedpiece.heatsealid = '" & heat_seal & "' " 

		set rs = getdisconnectedrecordset(query)
	
		if rs.recordcount > 0 then
			result = "{"
			result = result & """success"":1,"
			result = result & """heat_seal"":""" & jsencode(rs("heat_seal")) & ""","
			result = result & """customer_name"":""" & jsencode(rs("customer_name")) & ""","
			result = result & """item_description"":""" & jsencode(rs("item_description")) & ""","
			result = result & """invoices"":""" & jsencode("") & """"
			result = result & "}"
		else
			result = "{"
			result = result & """success"":0,"
			result = result & """message"":""" & jsencode("Could not find heat seal.") & """"
			result = result & "}"
		end if
		
		
		response.write result
		response.end
	end function
	
	function jsencode(s)
		if not isnull(s) then
			JSEncode = s
			JSEncode = Replace(JSEncode, "\", "\\") 
			JSEncode = Replace(JSEncode, """", "\""")
			JSEncode = Replace(JSEncode, vbCr, "\r")
			JSEncode = Replace(JSEncode, vbLf, "\n")
		end if
	end function 
%>

<HTML>
<HEAD>
<TITLE>Finished Invoices</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner-di.inc" -->
<H1>Heat Seal Manager</H1>

Scan heat seals:
<INPUT id="heatSealEntry" />


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="resetHeatSeals()">Reset<BR>Heat Seals</BUTTON>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" cellspacing="0" id="ths">
<TR>
	<TH>Heat Seal</TH>
	<TH>Customer</TH>
	<TH>Description</TH>
</TR>

</TABLE>

</BODY>


<script type="text/javascript" src="/external/doT.min.js"></script>

<SCRIPT language="javascript" type="text/javascript">
	var hs_row_t = doT.template('<tr class="selected" heat_seal="{{=it.heat_seal}}"><td>{{=it.heat_seal}}</td><td>{{=it.customer_name}}</td><td>{{=it.item_description}}</td></tr>');
	
	$(document).ready(function() {
		$.ajaxSetup({cache: false});
		$('#heatSealEntry').focus();
		$('#heatSealEntry').keyup(function(e) {
			if(e.keyCode == 13) {
				var heat_seal = $('#heatSealEntry').val();
				
				$.ajax({url: 'heatSealManager.asp', dataType: 'json', data: {useraction: 'hs', heat_seal: heat_seal}}).always(function(data) {
					if(data.message) {
						cbs_alert(data.message);
						$('#heatSealEntry').val('');
					}
					if(data.success) {
						$('#ths').append(hs_row_t(data));
						$('#heatSealEntry').val('');
					}
				});
			}
		});
		
		$('#ths tr').live('click', function() {
			$(this).toggleClass('selected');
		});
	});
	
	function resetHeatSeals() {
		cbs_confirm('Reset selected heat seals?', doReset);
	}

	function doReset() {
		var hs_list = '';
		$('tr.selected').each(function() {
			if(hs_list != '') hs_list += ',';
			hs_list += $(this).attr('heat_seal');
		});

		$.ajax({url: 'heatSealManager.asp?useraction=reset', dataType: 'json', data: {heat_seals: hs_list}}).always(function(data) {
			if(data.message) {
				cbs_alert(data.message);
			}
			$('#ths .selected').remove();
		});
	}
	
	function exit() {
		location.href = 'toolsmenu.asp';
	}
</SCRIPT>

</HTML>
