<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->
<!--#include file="../include/messages.asp" -->

<%

	const DELIVERY_STATUS_FINISH = 5
	const DELIVERY_STATUS_ADDING = 11
	const DELIVERY_STATUS_VERIFYING = 12
	const DELIVERY_STATUS_PAYMENTS1 = 13
	const DELIVERY_STATUS_MANIFEST = 14
	const DELIVERY_STATUS_UNDELIVERABLE = 15
	const DELIVERY_STATUS_PAYMENTS2 = 16

	const DELIVERY_ITEM_INVOICE_ERROR = -10
	const DELIVERY_ITEM_REMOVED = -1
	const DELIVERY_ITEM_READY = 0
	const DELIVERY_ITEM_ADDED = 1
	const DELIVERY_ITEM_STOP_WARNING = 10

	dim query, rs	
	dim weekAdj
	dim deliveryID
	dim deliveryDate, invToInc
	
	deliveryID = getReqVar("deliveryID")
	deliveryDate = getCurrentDeliveryDate(deliveryid)
	weekAdj = getReqVar("weekAdj")
	if weekAdj = "" then weekAdj = 0

	if Request.Form("invoiceToInclude") <> "" then
	    invToInc = Request.Form("invoiceToInclude")
	else
        query = "select deliveryChoiceInv from MiscSetup where storeid = " & session("storeid")
        set rs = getdisconnectedrecordset(query)
        invToInc = rs("deliveryChoiceInv")
	end if
	
	select case request.querystring("useraction")
	case "viewpreviousweek"
		weekAdj = weekAdj - 1
	case "viewnextweek"
		weekAdj = weekAdj + 1
	case "addroute"
		if deliveryID = "" then deliveryID = createNewDelivery(session("employeeid"), 11, request.querystring("deliveryDate"))
		addRouteToDelivery deliveryID, request.querystring("routeNumber"), request.querystring("deliveryDate")
		deliveryDate = getCurrentDeliveryDate(deliveryid)
		updateDeliveryDate deliveryID, deliveryDate
		setDeliveryStopsDirty deliveryID, true
	case "removeroute"
		removeRouteFromDelivery deliveryID, request.querystring("routeNumber"), request.querystring("deliveryDate")
		deliveryDate = getCurrentDeliveryDate(deliveryid)
		updateDeliveryDate deliveryID, deliveryDate
		setDeliveryStopsDirty deliveryID, true
	case "continuedeliverynoroute"
		continueDeliveryNoRoute
	end select
	
	
	function setDeliveryStopsDirty(deliveryID, dirty)
		dim query, rs
		
		if deliveryID <> "" then
			query = " update delivery set "
			if dirty then
				query = query & " stopsdirty = 1 "
			else
				query = query & " stopsdirty = 0 "
			end if
			query = query & " where deliveryid = " & deliveryid
			
			qryexecute query
		end if
	
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	
	function removeRouteFromDelivery(deliveryID, routeNumber, deliveryDate)
		dim query, rs
		
		query = " select deliveryrouteassignedid from deliveryrouteassigned where deliveryid = " & deliveryid
		query = query & " and routenumber = " & routenumber
		query = query & " and deliverydate = '" & deliverydate & "'"
		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
		
			query = " update ticket set ticket.ticketstatus = 'AC' "
			query = query & " from deliveryitem inner join ticket on "
			query = query & " deliveryitem.invoicenumber = ticket.invoicenumber "
			query = query & " where deliveryitem.deliveryid = " & deliveryid
			query = query & " and deliveryitem.deliveryrouteassignedid = " & rs("deliveryrouteassignedid")

			qryexecute query
			
			query = " delete deliveryitem where deliveryid = " & deliveryid
			query = query & " and deliveryitem.deliveryrouteassignedid = " & rs("deliveryrouteassignedid")
	
			qryexecute query

			query = " delete deliveryrouteassigned where deliveryrouteassignedid = " & rs("deliveryrouteassignedid")

			qryexecute query
			
			rs.movenext
		wend
	end function
	
	function getCurrentDeliveryDate(deliveryid)
		dim query, rs

		getCurrentDeliveryDate = Date()
		
		if deliveryid <> "" then

			query = " select min(deliverydate) as routedeliverydate from deliveryrouteassigned where deliveryid = " & deliveryid

			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				if not isnull(rs("routedeliverydate")) then
					getCurrentDeliveryDate = rs("routedeliverydate")
				end if
			end if
		end if
	end function
	
	function updateDeliveryDate(deliveryID, deliveryDate)
		dim query, rs
		
		query = " update delivery set deliverydate = '" & deliveryDate & "'"
		query = query & " where deliveryid = " & deliveryid
		
		qryexecute query
	end function
	
	function createNewDelivery(employeeid, status, deliveryDate)
		dim query, rs
		
		openConnection
		
		query= " INSERT INTO Delivery (EmployeeID, Status, deliveryDate) "
		query = query & " VALUES ("
		query = query & employeeid
		query = query & ", " & status
		query = query & ", '" & deliveryDate & "'"
		query = query & ")"
		
		dbInsert query

		set rs = dbSelect("select @@IDENTITY as NewID")
		createNewDelivery = rs("NewID")

		set rs = nothing
		
		closeConnection
	end function

	function continueDeliveryNoRoute()
		deliveryID = createNewDelivery(session("employeeid"), DELIVERY_STATUS_ADDING, deliveryDate)
		response.redirect "deliveryFunction.asp?useraction=addcustomerstops&deliveryid=" & deliveryid & "&destination=" & Server.URLEncode("deliveryWillCall.asp?deliveryID=" & deliveryid)
	end function
	
	
	function addInvoiceToDelivery(deliveryID, deliveryRouteAssignedID, invoiceNumber, customerDeliveryID)
		dim query, rs

		if invoiceNumber <> "" then
			query = " delete from deliveryitem where invoiceNumber = '" & invoiceNumber & "'"
			query = query & " and deliveryid = " & deliveryID
			
			qryexecute query
	
			query = " insert into deliveryitem (invoiceNumber, status, deliveryid, customerDeliveryID, deliveryRouteAssignedID) "
			query = query & " values ('" & invoiceNumber & "', 1, " & deliveryID & "," & customerDeliveryID & "," & deliveryRouteAssignedID & ")"
	
			qryexecute query
			
			query = " update ticket set ticketstatus = 'OD' "
			query = query & " where ticketstatus = 'AC' and invoicenumber = '" & invoicenumber & "'"
	
			qryexecute query
		end if
		
	end function

	function addRouteAssigned(deliveryid, routeNumber, deliveryDate)
		dim query
		
		query = " insert into deliveryrouteassigned (deliveryid, routeNumber, deliverydate) "
		query = query & " values (" & deliveryID & ", " & routeNumber & ", '" & deliveryDate & "')"
		
		openConnection
		
		dbInsert query
		
		set rs = dbSelect("select @@IDENTITY as NewID")
		
		addRouteAssigned = rs("NewID")

		set rs = nothing
		
		closeConnection
	end function
	
	
	function addRouteToDelivery(deliveryID, routeNumber, deliveryDate)
		dim query, rs
		dim routeFilter
		dim dayOfWeek
		dim dayOfWeekColumnName
		dim dayOfWeekColumnNames
		dim deliveryRouteAssignedID, deliveryChoiceInv
		
		deliveryRouteAssignedID = addRouteAssigned(deliveryid, routeNumber, deliveryDate)
		
		dayOfWeekColumnNames = Array("DeliverSun", "DeliverMon", "DeliverTue", "DeliverWed", "DeliverThu", "DeliverFri", "DeliverSat")
		
		dayOfWeek = DATEDIFF("d", DATEADD("ww", DATEDIFF("ww",0,deliveryDate) - 1, 0), deliveryDate) - 1
		
		dayOfWeekColumnName = dayOfWeekColumnNames(dayOfWeek)


		query = " select invoiceNumber, id as customerdeliveryid from deliverylist "
		query = query & " where datediff(day, begindate, '" & DBStr(deliveryDate) & "') >= 0 "
		query = query & " and (enddate is null or "
		query = query & " datediff(day, '" & DBStr(deliveryDate) & "', enddate) >= 0) "
		if Request.Form("invoiceToInclude") <> 2 then
		    query = query & " and (duedate is null or datediff(day, duedate, '" & deliveryDate & "') >= 0 ) "
		end if
		query = query & " and " & dayOfWeekColumnName & " in (1,2,3) "
		query = query & " and routeID = " & routeNumber
		query = query & " and dbo.countPriceLaterLines(ticketnumber) = 0 "


		if Request.Form("invoiceToInclude") = 1 or Request.Form("invoiceToInclude") = 2 then
			query = query & " and ticketnumber in (select ticketnumber from rackassignment where rackassignment.ticketnumber = deliverylist.ticketnumber) "
		end if
		query = query & " order by stopOrder, " & dayOfWeekColumnName & ", customersequencenumber, routenumber, invoicenumber "

		set getDeliveryListRS = getdisconnectedrecordset(query)
		
		while not(getDeliveryListRS.eof or getDeliveryListRS.bof)
			addInvoiceToDelivery deliveryID, deliveryRouteAssignedID, getDeliveryListRS("invoiceNumber"), getDeliveryListRS("customerdeliveryid")
			getDeliveryListRS.movenext
		wend

		
		set getDeliveryListRS = nothing
	end function
	
	
%>


<HTML>
<HEAD>


<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../external/ext/resources/css/ext-all.css" />

<style type="text/css">
    .x-window-dlg .ext-mb-download {
        background:transparent url(images/download.gif) no-repeat top left;
        height:46px;
    }
</style>
    
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>



<script language="javascript" type="text/javascript">

	function selectRoute(routeNumber, deliveryDate) {
		document.deliveryselectroutes.action = "?useraction=addroute&routenumber=" + routeNumber + "&deliveryDate=" + deliveryDate;
		document.deliveryselectroutes.submit();
	}

    var routeNumToRemove;
    var delDateToRemove;
	function removeSelectRoute(routeNumber, deliveryDate) {
	    routeNumToRemove = routeNumber;
	    delDateToRemove = deliveryDate;
        cbs_confirm("Remove selected route from delivery?", gotoRemoveRoute);
	}

	function gotoRemoveRoute() {
        clearConfirmMsg();
	    document.deliveryselectroutes.action = "?useraction=removeroute&routenumber=" + routeNumToRemove + "&deliveryDate=" + delDateToRemove;
        document.deliveryselectroutes.submit();
	}
	
	function viewPreviousWeek() {
		document.deliveryselectroutes.action = "?useraction=viewpreviousweek";
		document.deliveryselectroutes.submit();
	}
	
	function viewNextWeek() {
		document.deliveryselectroutes.action = "?useraction=viewnextweek";
		document.deliveryselectroutes.submit();
	}
	
	function continueDelivery() {
		document.deliveryselectroutes.action = "deliveryFunction.asp?useraction=addcustomerstops&deliveryid=<%=deliveryID%>&destination=" + escape("deliveryWillCall.asp?useraction=checkwillcall&deliveryID=<%=deliveryID%>");
		document.deliveryselectroutes.submit();
	}
	
	function exit() {
		document.deliveryselectroutes.action = "deliveryManager.asp"
		document.deliveryselectroutes.submit();
	}
	
	function continueDeliveryNoRoute() {
		document.deliveryselectroutes.action = "?useraction=continuedeliverynoroute";
		document.deliveryselectroutes.submit();
	}
	

</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->


<H1>Delivery - Select Routes to Deliver (1/5)</H1>

<FORM name="deliveryselectroutes" id="deliveryselectroutes" method=POST  onsubmit="" > 
<INPUT type="hidden" name="weekAdj" value="<%=weekAdj%>" />
<INPUT type="hidden" name="deliveryID" value="<%=deliveryID%>" />


<TABLE>
	<TR>
		<TD>Invoices to Include</TD>
		<TD>
            <SELECT id="invoiceToInclude" name="invoiceToInclude">
                <OPTION <% if invToInc = 0 then %> selected <%end if%> value="0">All Due on Delivery Date</OPTION>
                <OPTION <% if invToInc = 1 then %> selected <%end if%> value="1">Racked Due on Delivery Date</OPTION>
                <OPTION <% if invToInc = 2 then %> selected <%end if%> value="2">Racked ignoring Delivery Date</OPTION>
           </select>
		</TD>
	</TR>
</TABLE>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="viewPreviousWeek()">Previous<BR>Week</BUTTON>
		<BUTTON onclick="viewNextWeek()">Next<BR>Week</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
    <BUTTON  <%if deliveryid = "" then%>onclick="continueDeliveryNoRoute()"<%else%>onclick="continueDelivery()"<%end if%>>Next</BUTTON>
	</SPAN>
</DIV>	

<% 
	function routeButtons(deliveryID, rs, routeDate, deliveryDayRS)
		dim result
		dim onDelivery
		dim onThisDelivery
		
		if rs.recordcount > 0 then
			rs.movefirst
			
			while not rs.eof
				if not (deliveryDayRS is nothing) then
					deliveryDayRS.filter = "routeNumber = " & rs("routeNumber") & " and deliverydate = '" & routeDate & "'"
					onDelivery = deliveryDayRS.recordcount > 0
					if onDelivery and deliveryid <> "" then
						deliveryDayRS.filter = "routeNumber = " & rs("routeNumber") & " and deliverydate = '" & routeDate & "' and deliveryid = " & deliveryid
						onThisDelivery = deliveryDayRS.recordcount > 0
					end if
				else
					onDelivery = false
				end if
				
				result = result & " <input type=""button"" style=""width:120px;height:40px; "
				if onDelivery then
					
					if onThisDelivery then
						result = result & "background:#0f0"" "
						result = result & " onclick=""removeSelectRoute(" & rs("routeNumber") & ", '" & routeDate & "')"""
					else
						result = result & "background:#ff0;"" "
						result = result & " onclick=""if (confirm('Delivery already out, are you sure?')) selectRoute(" & rs("routeNumber") & ", '" & routeDate & "')"""
					end if
				else
					result = result & """ onclick=""selectRoute(" & rs("routeNumber") & ", '" & routeDate & "')"""
				end if

				result = result & " value=""" & Server.HTMLEncode(rs("name")) & """"
				result = result & " /> <BR>"
				
				rs.movenext
			wend
		end if
		routeButtons = result
	end function
	

	dim routeRS
	dim weekStart
	dim weekDay
	dim deliveryDayRS
	dim dayOfWeek
	
	weekStart = DateAdd("ww", DatePart("ww", Date) - 1 + weekAdj, DatePart("yyyy", Date) & "-1-1")
	dayOfWeek = DatePart("w", weekStart)

	query = " select * from route where activeroute = 1 and storeid = " & session("storeid")
	set routeRS = getdisconnectedrecordset(query)

	query = " select distinct deliveryid, routeNumber, deliverydate from deliveryrouteassigned "
	set deliveryDayRS = getdisconnectedrecordset(query)


%>

<table style="width:100%" class="itable" cellspacing="0" cellpadding="10">

	<tr>
		<th style="text-align: center"><% =DateAdd("d", 1 - dayOfWeek, weekStart) %><br>Sunday</th>
		<th style="text-align: center"><% =DateAdd("d", 2 - dayOfWeek, weekStart) %><br>Monday</th>
		<th style="text-align: center"><% =DateAdd("d", 3 - dayOfWeek, weekStart) %><br>Tuesday</th>
		<th style="text-align: center"><% =DateAdd("d", 4 - dayOfWeek, weekStart) %><br>Wednesday</th>
		<th style="text-align: center"><% =DateAdd("d", 5 - dayOfWeek, weekStart) %><br>Thursday</th>
		<th style="text-align: center"><% =DateAdd("d", 6 - dayOfWeek, weekStart) %><br>Friday</th>
		<th style="text-align: center"><% =DateAdd("d", 7 - dayOfWeek, weekStart) %><br>Saturday</th>
	</tr>
	<tr valign="top" align="center">
		<% weekDay = DateAdd("d", 1 - dayOfWeek, weekStart) %>
		<td <%if datediff("d", weekDay, deliveryDate) = 0 then%>style="background:#ee0"<%end if%>><%
				routeRS.filter="deliverysun=1"
				response.write routeButtons(deliveryID, routeRS, weekDay, deliveryDayRS) %>
		</td>
		<% weekDay = DateAdd("d", 2 - dayOfWeek, weekStart) %>
		<td <%if datediff("d", weekDay, deliveryDate) = 0 then%>style="background:#ee0"<%end if%>><%
				routeRS.filter="deliverymon=1"
				response.write routeButtons(deliveryID, routeRS, weekDay, deliveryDayRS) %>
		</td>
		<% weekDay = DateAdd("d", 3 - dayOfWeek, weekStart) %>
		<td <%if datediff("d", weekDay, deliveryDate) = 0 then%>style="background:#ee0"<%end if%>><%
				routeRS.filter="deliverytue=1"
				response.write routeButtons(deliveryID, routeRS,weekDay, deliveryDayRS) %>
		</td>
		<% weekDay = DateAdd("d", 4 - dayOfWeek, weekStart) %>
		<td <%if datediff("d", weekDay, deliveryDate) = 0 then%>style="background:#ee0"<%end if%>><%
				routeRS.filter="deliverywed=1"
				response.write routeButtons(deliveryID, routeRS, weekDay, deliveryDayRS) %>
		</td>
		<% weekDay = DateAdd("d", 5 - dayOfWeek, weekStart) %>
		<td <%if datediff("d", weekDay, deliveryDate) = 0 then%>style="background:#ee0"<%end if%>><%
				routeRS.filter="deliverythu=1"
				response.write routeButtons(deliveryID, routeRS, weekDay, deliveryDayRS) %>
		</td>
		<% weekDay = DateAdd("d", 6 - dayOfWeek, weekStart) %>
		<td <%if datediff("d", weekDay, deliveryDate) = 0 then%>style="background:#ee0"<%end if%>><%
				routeRS.filter="deliveryfri=1"
				response.write routeButtons(deliveryID, routeRS, weekDay, deliveryDayRS) %>
		</td>
		<% weekDay = DateAdd("d", 7 - dayOfWeek, weekStart) %>
		<td <%if datediff("d", weekDay, deliveryDate) = 0 then%>style="background:#ee0"<%end if%>><%
				routeRS.filter="deliverysat=1"
				response.write routeButtons(deliveryID, routeRS, weekDay, deliveryDayRS) %>
		</td>
	</tr>
</table>


</FORM>

</BODY>
</HTML>
