<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<%
	dim query, rs
	dim deliveryID
	dim deliveryDate
	dim routeNumber
	
	deliveryID = getReqVar("deliveryID")
	deliveryDate = getReqVar("deliveryDate")
	routeNumber = getReqVar("routeNumber")
	routeDept = getReqVar("routeDept")
	
	if deliveryID <> "" and deliveryDate <> "" then
		updateDeliveryDate deliveryID, deliveryDate
	end if
	
	if deliveryDate = "" then deliveryDate = Date()
	
	select case lcase(request.querystring("useraction"))
	case "collectdeliverydata"
		if deliveryID = "" then deliveryID = createNewDelivery(session("employeeid"), 11)
		collectDeliveryData deliveryID, request.form("deliveryData")
	case "addroute"
		if deliveryID = "" then deliveryID = createNewDelivery(session("employeeid"), 11)
		addRouteToDelivery deliveryID, request.form("routeNumber"), deliveryDate
	case "updateroutenumber"
		routeNumber = request.form("routeNumber")
		routeDept = ""
	case "removeselecteditems"
		removeFromDelivery deliveryID, request.form("deliveryitemid")
	end select

	function removeFromDelivery(deliveryID, deliveryItemIDs)
		dim query, rs


		query = " update ticket set ticket.ticketstatus = 'AC' "
		query = query & " from deliveryitem inner join ticket on "
		query = query & " deliveryitem.invoicenumber = ticket.invoicenumber "
		query = query & " where deliveryitem.deliveryItemID in ("  & deliveryItemIDs & ")"
		query = query & " and ticket.ticketstatus = 'OD' "
		
		qryexecute query

		query = " delete from deliveryitem where deliveryid = " & deliveryID
		query = query & " and deliveryItemID in ("  & deliveryItemIDs & ")"
		
		qryexecute query

	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function createNewDelivery(employeeid, status)
		dim query, rs
		
		openConnection
		
		query= " INSERT INTO Delivery (EmployeeID, Status) "
		query = query & " VALUES ("
		query = query & employeeid
		query = query & ", " & status
		query = query & ")"
		
		dbInsert query

		set rs = dbSelect("select @@IDENTITY as NewID")
		createNewDelivery = rs("NewID")

		set rs = nothing
		
		closeConnection
	end function
	
	sub collectDeliveryData(deliveryID, deliveryData)
		dim invoicenumbers
		dim invoicenumber

		invoicenumbers = split(deliveryData, "|")

		for each invoicenumber in invoicenumbers
			addInvoiceToDelivery deliveryID, invoiceNumber
		next
	end sub
	
	function getTicketData(invoiceNumber, ticketNumber, ticketStatus)
		dim query, rs
		
		query = " select ticketnumber, ticketstatus from ticket where "
		query = query & " invoiceNumber = '" & invoiceNumber & "'"

		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			ticketNumber = rs("ticketNumber")
			ticketStatus = rs("ticketStatus")
		end if
		
		set rs = nothing
	end function
	
	function addInvoiceToDelivery(deliveryID, invoiceNumber)
		dim query, rs

		query = " delete from deliveryitem where invoiceNumber = '" & invoiceNumber & "'"
		query = query & " and deliveryid = " & deliveryID
		
		qryexecute query

		query = " insert into deliveryitem (invoiceNumber, status, deliveryid) "
		query = query & " values ('" & invoiceNumber & "', 1, " & deliveryID & ")"

		qryexecute query

		query = " update ticket set ticketstatus = 'OD' "
		query = query & " where ticketstatus = 'AC' and invoicenumber = '" & invoicenumber & "'"
		
		response.write query
		response.end
		
		qryexecute query
		
	end function
	
	function addRouteToDelivery(deliveryID, routeNumber)
		dim query, rs

	end function


	function getCommercialAccounts(routeNumber)
		dim query, rs
		
		query = "select distinct parentCustomer.customername, parentCustomer.customersequencenumber "
		query = query & " from customer parentCustomer inner join "
		query = query & " customer childCustomer "
		query = query & " on parentCustomer.customerSequenceNumber = childCustomer.parentCustomerSeq "
		query = query & " where parentCustomer.isactive = 1 and childCustomer.isactive = 1 "
		if routeNumber <> "" then
			query = query & " and parentCustomer.routeNumber = " & routeNumber
		end if
		
		set getCommercialAccounts = getdisconnectedrecordset(query)
	end function
	
	
	function addRouteToDelivery(deliveryID, routeNumber, deliveryDate)
		dim query
		dim routeFilter
		dim dayOfWeek
		dim dayOfWeekColumnName
		dim dayOfWeekColumnNames

		
		dayOfWeekColumnNames = Array("DeliverSun", "DeliverMon", "DeliverTue", "DeliverWed", "DeliverThu", "DeliverFri", "DeliverSat")
		
		dayOfWeek = DATEDIFF("d", DATEADD("ww", DATEDIFF("ww",0,deliveryDate) - 1, 0), deliveryDate) - 1
		
		dayOfWeekColumnName = dayOfWeekColumnNames(dayOfWeek)

		query = " select invoiceNumber from deliverylist "
		query = query & " where datediff(day, begindate, '" & DBStr(deliveryDate) & "') >= 0 "
		query = query & " and (enddate is null or "
		query = query & " datediff(day, '" & DBStr(deliveryDate) & "', enddate) >= 0) "
		query = query & " and (duedate is null or datediff(day, duedate, '" & deliveryDate & "') >= 0 ) "
		query = query & " and " & dayOfWeekColumnName & " in (1,2,3) "
		query = query & " and routeID = " & routeNumber
		query = query & " order by stopOrder, " & dayOfWeekColumnName & ", customersequencenumber, routenumber, invoicenumber "

		set getDeliveryListRS = getdisconnectedrecordset(query)
		
		while not(getDeliveryListRS.eof or getDeliveryListRS.bof)
			addInvoiceToDelivery deliveryID, getDeliveryListRS("invoiceNumber")
			getDeliveryListRS.movenext
		wend
		
		set getDeliveryListRS = nothing
	end function
	
	function updateDeliveryDate(deliveryID, deliveryDate)
		dim query, rs
		
		if deliveryid <> "" and deliveryDate <> "" then
			query = " update delivery set deliverydate = '" & deliverydate & "'"
			query = query & " where deliveryid = " & deliveryid
			
			qryexecute query
		end if
	end function
%>

<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT language="javascript" type="text/javascript">

	var timer = null;
	
	function resetTimeout() {
		if(timer != null) {
			clearTimeout(timer);
			timer = setTimeout("submitDeliveryData();", 1000);
		}
	}
	
	function submitDeliveryData() {
		document.deliveryAddInvoice.action = "?useraction=collectdeliverydata";
		document.deliveryAddInvoice.submit();
	}

	
	function newDeliveryItem() {
		var InvoiceNumber;
		var tInvoiceNumber;
		
		InvoiceNumber = document.deliveryAddInvoice.InvoiceNumber.value;
		
		  
		tInvoiceNumber = translateInvoiceNumber(InvoiceNumber);
		
		if(tInvoiceNumber != -1) {
		InvoiceNumber = tInvoiceNumber;
		}
		
	
	  if(document.deliveryAddInvoice.deliveryData.value != "")
	  	document.deliveryAddInvoice.deliveryData.value += "|";
	  
	  document.deliveryAddInvoice.deliveryData.value += InvoiceNumber;
	  
	  if(timer != null)
	  	clearTimeout(timer);
	  
	  timer = setTimeout("submitDeliveryData();", 1000);
	  
	  resetForm();
	}

	function resetForm() {
		document.deliveryAddInvoice.InvoiceNumber.value = "";
		document.deliveryAddInvoice.InvoiceNumber.focus();
	}
	function removeSelectedItems() {
		document.deliveryAddInvoice.action = "?useraction=removeselecteditems";
		document.deliveryAddInvoice.submit();
	}
	
	
	function verifyAndContinue() {
		document.deliveryAddInvoice.action = "?useraction=verifyandcontinue";
		document.deliveryAddInvoice.submit();
	}
	
	function captureKeyUpEvent(element) {
		if (event.keyCode == 13) {
			event.returnValue = true;
			
			switch(element.name) {
		        case "InvoiceNumber":
		            newDeliveryItem();
			}
		}
		return true;
	}

	function exitForm() {
		document.deliveryAddInvoice.action = "/MainApp/deliveryManager.asp"
		document.deliveryAddInvoice.submit();
	}
	
	function addRoute(routeNumber) {
		document.deliveryAddInvoice.action = "?useraction=addroute&routenumber=" + routeNumber;
		document.deliveryAddInvoice.submit();
	}
	function updateRouteNumber(routeNumber) {
		document.deliveryAddInvoice.action = "?useraction=updateroutenumber&routenumber=" + routeNumber;
		document.deliveryAddInvoice.submit();
	}
	function selectDate(element) {
		show_calendar("deliveryAddInvoice." + element.name);
	}
</SCRIPT>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="deliveryAddInvoice.InvoiceNumber.focus()">
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->


<H1>Delivery - Add Invoice (1/6)</H1>

<FORM id="deliveryAddInvoice" name="deliveryAddInvoice" method="post" onsubmit="return false">


<INPUT type="hidden" name="deliveryData" value="">
<INPUT type="hidden" name="deliveryID" value="<%=deliveryID%>">

<TABLE>
	<TR>
		<TD>
			Delivery Date:<BR />
			<INPUT name="deliveryDate" id="deliveryDate" value="<%=deliveryDate%>" onclick="selectDate(this)" />
		</TD>
	</TR>
</TABLE>

<TABLE>
	<TR>
		<TD>
			Invoice Number:<BR />
			<INPUT name="InvoiceNumber" onKeyup="return captureKeyUpEvent(this)">
		</TD>
		<TD> Or </TD>
		<TD>
			Route:<BR />
			<SELECT name="routeNumber" id="routeNumber" onchange="updateRouteNumber(this.value)" >
			<%
				query = " select routenumber, name from route where storeid = " & session("storeid")
				set rs = getdisconnectedrecordset(query)
				while not(rs.eof or rs.bof)
			%>
				<OPTION value="<%=rs("routenumber")%>" <%if trim(routeNumber) = trim(rs("routenumber")) then%>selected<%end if%>><%=rs("name")%></OPTION>
			<%
					rs.movenext
				wend
				set rs = nothing
			%>
			</SELECT>
			<SELECT id="routeDept" name="routeDept" >
				<OPTION value="">All</OPTION>
	<%
			set rs = getCommercialAccounts(routeNumber)
			while not(rs.eof or rs.bof)
	%>
				<OPTION value="<%=rs("customerSequenceNumber")%>" <%if trim(rs("customerSequenceNumber")) = trim(routeDept) then %>selected<% end if %> ><%=rs("customername")%></OPTION>
	<%
				rs.movenext
			wend
			set rs = nothing
	%>
			</SELECT>
			<INPUT type="button" value="Add" onclick="addRoute(routeNumber.value)" />
		</TD>
	</TR>
</TABLE>
			
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="removeSelectedItems()">Remove</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exitForm()">Exit</BUTTON>
		<BUTTON onclick="verifyAndContinue()">Continue</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" width="100%" cellspacing="0" cellpadding="0">
<TR>
	<TH>&nbsp;</TH>
	<TH>Invoice Number</TH>
	<TH>Customer Name</TH>
</TR>

<%
	if deliveryID <> "" then
		query = " select deliveryitem.deliveryitemid, deliveryitem.invoicenumber, "
		query = query & " isnull(customer.customername, '') as customername "
		query = query & " from deliveryitem "
		query = query & " left outer join ticket on "
		query = query & " deliveryitem.invoicenumber = ticket.invoicenumber "
		query = query & " left outer join customer on "
		query = query & " ticket.customersequencenumber = customer.customersequencenumber "
		query = query & " where deliveryid = " & deliveryID
		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
%>

<TR>
	<TD><INPUT type="checkbox" name="deliveryitemid" value="<%=rs("deliveryitemid")%>" /></TD>
	<TD><%=rs("invoiceNumber")%></TD>
	<TD><%=rs("customername")%></TD>
</TR>

<%
			rs.movenext
		wend
		set rs = nothing
	end if
%>
</TABLE>

</FORM>
</BODY>
</HTML>
