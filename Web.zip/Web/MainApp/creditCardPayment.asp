<%@ Language=VBScript %>
<%option explicit%>

<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/customerPaymentObj.asp"-->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>

<%
	'*******************************************************************
	'Name   : creditCardPayment.asp
    'Author : James Johnston
    'Created: 13-Jan-2004
    'Modification History
    '===================================================================
    ' Date           Changed By    Change Log
    ' ------------------------------------------------------------------
    ' 13-Jan-2004    Johnston		Original version
	'*******************************************************************

'COMMON variables
dim originatingPage	'JJ, 13Jan04
dim ObjMiscSetUp
dim ccTotal
dim custSeqNumber
dim customername
dim storeId
dim empID
dim terminalId
dim sessionName
dim onFile
dim fileStatus
dim approvalCode
dim creditFormName
dim custPaymentObj
dim custCreditCardTypeID
dim custCreditCardNo
dim custCreditCardExpDate
dim custCreditCardExpMonth
dim custCreditCardExpYear
dim firstDigits, cardTypeArray
dim xChargePath

'PICKUP variables
dim pickupObj
dim InvoiceList
dim invoicesTotal
dim totalInv
dim ticketNums
dim RackRst,rackStr, rackStr1, noOfRows, rackString
dim printRackInfo
dim invoicenumberchange
dim isPrePay
dim itemsStartIndex
dim upChargeStartIndex
dim colorsStartIndex
dim patternStartIndex
dim deptStartIndex
dim addOrEdit
dim targetPage

'APPLY PAYMENT variables

'Set COMMON variables
originatingPage = Request.QueryString("OPage")	'Added by JJ, 13Jan04
targetPage = Request.QueryString("tPage")
if targetPage = "" then
	targetPage = Request.Form("tPage")
end if
set ObjMiscSetUp = Session("miscSetUp")
ccTotal = Request.QueryString("ccAmount")
custSeqNumber = Session("customerSequenceNumber")
if isNull(custSeqNumber) then
	custSeqNumber = session("accountCustomerSequenceNumber")
end if
Session("customerSequenceNumber")=custSeqNumber
customerName = session("customername")
storeId = Session("storeID")
empID = Session("employeeID")
terminalId = Session("terminalID")
sessionName = Session.SessionID
onFile = Request.QueryString("onFile")
fileStatus = 0
creditFormName = ""
xChargePath = ObjMiscSetUp.Item("XChargePath")
'xChargePath = replace(xChargePath,"\","\\")

'Set PICKUP ONLY variables
if originatingPage = "Pickup" then
	InvoiceList= session("invoicelist")
	set pickupObj = Session("pickupObj")
	ticketNums = pickupObj.getTicketNosForPrinting()
	invoicesTotal = pickupObj.invoicesTotal
	totalInv = totalDue()
	printRackInfo = ""
	noOfRows = 0
	rackString = ""
		'Following added by J.Johnston, 5Dec03, for prepay (from PICKUP)
	isPrePay = Request.Form("isPrePay")	
	itemsStartIndex = Request.Form("ItemPageCount")
	upChargeStartIndex = Request.Form("upChargePageCount")
	colorsStartIndex = Request.Form("colorsPageCount")
	patternStartIndex = Request.Form("PatternPageCount")
	deptStartIndex = Request.Form("DeptPageCount")
	addOrEdit = Request.Form("addOrEdit")
		'End addition, 5Dec03
	invoicenumberchange = ""
end if

getCustomerCreditCardInfo

checkForForm

'Rack info for display and printing, for PICKUP/PREPAY only
if originatingPage = "Pickup" then
	'SteveG added condition where ticketRack does not exist during prepay
	if isobject(Session("ticketRack")) then
	    if not (Session("ticketRack") is nothing) then
			set RackRst = Session("ticketRack")
			noOfRows = RackRst.RecordCount
			if RackRst.RecordCount > 0 then
				RackRst.MoveFirst
				while not RackRst.EOF
					rackStr= RackRst.Fields("rackLocationStart").Value
					rackStr1 = RackRst.Fields("rackLocationStart").Value
					if not IsNull(RackRst.Fields("rackLocationEnd").Value) then
						rackStr = rackStr & " - " & RackRst.Fields("rackLocationEnd").Value
						rackStr1 = rackStr1 & " - " & RackRst.Fields("rackLocationEnd").Value
					end if
					if trim(printRackInfo) = "" then
						printRackInfo =    customername & vbcrlf 
					end if						
					if trim(invoicenumberchange) = "" or invoicenumberchange <> trim(RackRst.Fields("invoicenumber").Value)  then
						invoicenumberchange = RackRst.Fields("invoicenumber").Value
						printRackInfo = printRackInfo & vbcrlf & invoicenumberchange & vbTab & vbTab
					else
						printRackInfo =  printRackInfo & ", "
					end if							
					if len(trim(printRackInfo)) = 0 then
						printRackInfo =  printRackInfo &  rackStr
					else
						printRackInfo =  printRackInfo &  rackStr1
					end if		
					
					if len(trim(rackString))=0 then
						if len(trim(rackStr))<> 0 then
							rackString = rackStr
						else
							rackString = rackStr1
						end if
					else
						if len(trim(rackStr))<> 0 then
							rackString = rackString + ", " + rackStr
						else
							rackString = rackString + ", " + rackStr1
						end if
					end if					
					RackRst.MoveNext
															
				wend								
			end if
		end if
	end if
end if


Function getCreditCardsTypes()
'This function retrieves all credit card types setup for store.
' Returns an array of valid c.c. names (cardTypeArray)
' and an array of valid first digits for those c.c. types (firstDigits)
'Used for all C.C. payments

	dim sqltxt
	dim rsCreditTypes
	dim typeArray(),cardArray(15)
	dim i,x
	
	i=0
	x=0
	
	sqltxt = "select creditcardTypeId, name from creditcardtypedomain where storeid = " & storeId
	set rsCreditTypes = getdisconnectedRecordset(sqltxt)
	
	if rsCreditTypes.recordcount > 0 then
		'Set array of valid first digits
		redim typeArray(rsCreditTypes.recordcount-1)
		while not rsCreditTypes.EOF
			if ucase(left(rsCreditTypes.fields("name").value,2))="VI" then
				typeArray(i)=4
				cardArray(i)=x
			elseif ucase(left(rsCreditTypes.fields("name").value,2))="MA" then
				typeArray(i)=5
				cardArray(i)=x
			elseif ucase(left(rsCreditTypes.fields("name").value,2))="AM" then
				typeArray(i)=34
				cardArray(i)=x
				redim preserve typeArray(ubound(typeArray)+1)
				i=i+1
				typeArray(i)=37
				cardArray(i)=x
			elseif ucase(left(rsCreditTypes.fields("name").value,3))="DIS" then
				typeArray(i)=6
				cardArray(i)=x
			elseif ucase(left(rsCreditTypes.fields("name").value,3))="DIN" then
				typeArray(i)=30	
				cardArray(i)=x	
			elseif ucase(left(rsCreditTypes.fields("name").value,4))="CART" then
				typeArray(i)=36
				cardArray(i)=x
				redim preserve typeArray(ubound(typeArray)+1)
				i=i+1
				typeArray(i)=38
				cardArray(i)=x	
			elseif ucase(left(rsCreditTypes.fields("name").value,3))="ENR" then
				typeArray(i)=201
				cardArray(i)=x
				redim preserve typeArray(ubound(typeArray)+1)
				i=i+1
				typeArray(i)=214
				cardArray(i)=x		
			elseif ucase(left(rsCreditTypes.fields("name").value,3))="JCB" then
				typeArray(i)=213
				cardArray(i)=x
				redim preserve typeArray(ubound(typeArray)+1)
				i=i+1
				typeArray(i)=180
				cardArray(i)=x											
			end if
			i=i+1
			x=x+1
			rsCreditTypes.movenext
		wend
	
		firstDigits = join(typeArray,",")
		cardTypeArray = join(cardArray,",")
		rsCreditTypes.movefirst
	end if
	
	set getCreditCardsTypes = rsCreditTypes
	
End Function


sub getCustomerCreditCardInfo()
'This proc retrieves stored customer C.C. info
' Sets C.C. type, number, exp. date 
'Used for all C.C. payments


	initializeCustomerPaymentInfo

	set custPaymentObj = Session("customerPayment")
	
	if custPaymentObj.Count > 0 then
		custCreditCardTypeID = custPaymentObj.Item("creditCardTypeId")
		custCreditCardNo = custPaymentObj.Item("creditCardNumber")
		if not isnull(custCreditCardNo) then
			onFile = 1
		else
			onFile = 0
		end if
		custCreditCardExpDate = custPaymentObj.Item("creditCardExpDate")
		if not isnull(custCreditCardExpDate) then
			custCreditCardExpMonth = left(custCreditCardExpDate,2)
			custCreditCardExpYear = right(custCreditCardExpDate,2)
		end if
	end if
	
end sub


function totalDue()
'This function gets total amount due on invoice.
' Returns totalDue
'Used for PICKUP payments

	dim tempTotalDue
	if (formatnumber(pickupObj.getTotalAmountDue, 2)-formatnumber(pickupObj.totalAmtPaid, 2))>0 then							  
		tempTotalDue = formatnumber(pickupObj.getTotalAmountDue, 2)-formatnumber(pickupObj.getPaymentByType(""), 2)
	else
		tempTotalDue = 0.00
	end if
	totalDue = tempTotalDue
	
end function


function checkForForm()
'This function retrieves the proper printer form for Credit Card receipts.
' Returns creditFormName
'Used for all C.C. printing

	dim prnsql
	dim prnrs
	
	prnsql = "SELECT printerID, printerType, formName, numCopies, printerName, brand, model, port, baudRate, hardwareName, routeNumber "
	prnsql = prnsql & " FROM Printer, StoreHardware "
	prnsql = prnsql & " WHERE StoreHardware.hardwareID IN "
	prnsql = prnsql & " (  SELECT hardwareID "
	prnsql = prnsql & "    FROM StoreHardware "
	prnsql = prnsql & "    WHERE hardwareType = 'PR' "
	prnsql = prnsql & "    AND routeNumber is NULL "
	prnsql = prnsql & "    AND terminalID = " & Session("terminalID") & "  ) "
	prnsql = prnsql & "    AND Printer.hardwareID = StoreHardware.hardwareID "
	prnsql = prnsql & "    AND printerType = 'CREDIT CARD RECEIPT' "
	set prnrs = getDisconnectedRecordset(prnsql)
	
	IF prnrs.eof or prnrs.bof then
		creditFormName = null
	else
		creditFormName = prnrs("formName")
	end if 
	
	if isnull(creditFormName) then
		creditFormName = ""
	end if
	
end function

function OnlyFirstInvoice(InvoiceList)
	dim invoices
	invoices = split(InvoiceList & ",", ",")
	OnlyFirstInvoice = replace(invoices(0), " ", "")
end function

%>

<HTML>

<HEAD>

<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">

<TITLE>Process Credit Card</TITLE>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>

<script language="javascript" type="text/javascript">

	var lastFocusControl;
	var lastControl;
	var cardType;
	var accountNumber;
	var expirationDate;
	var expirationMonth;
	var expirationYear;
	var ccCustName;
	var fileName;
	var approvalCode;
	var timedOut;
	var swipeData;
	var onFile;
	var magCardPollTimer = null;
	
	lastControl = "txtCCNumber";
	timedOut = false;
	
     function pause(numberMillis) {
		var scr;
		
        var dialogScript = 
           'window.setTimeout(' +
           ' function () { window.close(); }, ' + numberMillis + ');';
        var result = 
// For IE5.

		scr = 'javascript:document.writeln('
		scr += '"<scr'
		scr += 'ipt>'
		scr += dialogScript
		scr += '<'
		scr += '/script >")'
		
		
         window.showModalDialog(scr);

     }
     
	function beginMagCardPoll() {
		magCardPollTimer = setTimeout("pollMagCard();", 600);
	}
	function resetMagCardPoll() {
		clearTimeout(magCardPollTimer);
		magCardPollTimer = setTimeout("pollMagCard();", 600);
	}
	
	function pollMagCard() {
		var response;
		
		if(SigPad_IsResponseReady())
		{
			response = SigPad_GetResponse(1000);
			
			if(response.length > 0)
			{
				//alert(response);
				document.creditCardInfo.txtCCData.value = response;
				onNumberBlur();

			}
			else
				resetMagCardPoll();
			//document.creditCardInfo.txtCCData.value
		}
		else
		{
			resetMagCardPoll();
		}
	}
	
	
	function checkEnter(event)
	{ 	
		var code = 0;
		
		code = event.keyCode;
		if (code==13)
			submitForm("ok");
	}
	
	
	function validateEnterKey() 
	{
		return false;
	}
	
	
	//set the default focus after loading the page.
	function setFocusOnFirstControl()
	{										
		document.creditCardInfo.txtCCData.focus();	
	}
	
	
	//Set the focus on PROCESS button.
	function setFocusOnControl()
	{				
		document.creditCardInfo.processButton.focus();
	}	
	

	//Set the focus on PROCESS button when enter key pressed.
	function captureKeyUpEvent()
	{
		if (event.keyCode == 13)
		{			
			event.returnValue = true;
			setFocusOnControl();
			event.keyCode = 0;
		}
	}
	
	
	function onNumberBlur() 
	{
	//This function fills the c.c. type, account#, exp.date, and name on card fields
	// when card is swiped.
	// If manually entering data, displays extra data entry fields.
	// Warns user of unsupported c.c. types
	//Used for all C.C. payments	
	
		document.creditCardInfo.style.cursor="default";
		swipeData = document.creditCardInfo.txtCCData.value;
		
		if(swipeData!="")	//This is a swiped card
		{
			var firstSwipeChar;
			firstSwipeChar = swipeData.substr(0,1);
		
			if(firstSwipeChar==";" || firstSwipeChar=="%") //This is a swiped CREDIT card
			{
					
				var splitSwipedData;
				splitSwipedData = swipeData.split(";");	//split into 2 lines
				
				var firstLine;
				firstLine = splitSwipedData[0];	//capture 1st line
	
				var splitFirstLine;
				splitFirstLine = firstLine.split("^");	//split 1st line
		
				ccCustName = splitFirstLine[1];
				if(ccCustName=="" || ccCustName == null)
				{
					ccCustName=""
				}
		
				var secondLine;
				secondLine=splitSwipedData[1];	//capture 2nd line
		
				var splitSecondLine;
				splitSecondLine = secondLine.split("=");	//split 2nd line
		
				accountNumber = splitSecondLine[0];
				if(isNaN(accountNumber.substr(0,1)))
				{
					accountNumber="";
				}
				
				if(splitSecondLine[1]!=null)
				{
					expirationDate = splitSecondLine[1];
					expirationDate = expirationDate.substr(0,4);
					expirationDate = expirationDate.substr(2,2)+expirationDate.substr(0,2);
				}
				else
				{
					expirationDate="";
				}
		
				document.creditCardInfo.txtCCNumber.value = accountNumber;
				document.creditCardInfo.txtCCExpDate.value = expirationDate;
				document.creditCardInfo.txtCCCustName.value = ccCustName;
		
				validCreditCard()
	
			}
			else	//This is NOT a CREDIT card
			{

			}
			
			document.creditCardInfo.txtCCData.value="";
			document.creditCardInfo.selCreditType.focus();
			return;
		}
		else	//This is NOT a swiped card
		{
			//Display additional fields
			document.creditCardInfo.txtCCcvctag.style.visibility="visible";
			document.creditCardInfo.txtCCAddresstag.style.visibility="visible";
			document.creditCardInfo.txtCCZiptag.style.visibility="visible";
			document.creditCardInfo.txtCCZip.style.visibility="visible";
			document.creditCardInfo.txtCCAddress.style.visibility="visible";
			document.creditCardInfo.txtCCcvc.style.visibility="visible";
			document.creditCardInfo.txtCCCity.style.visibility="visible";
			document.creditCardInfo.txtCCCitytag.style.visibility="visible";
			document.creditCardInfo.txtCCState.style.visibility="visible";
			document.creditCardInfo.txtCCStatetag.style.visibility="visible";
			
			accountNumber = document.creditCardInfo.txtCCNumber.value;
			if (accountNumber.length != "")
			{
				validCreditCard()
			}

		}
		
		document.creditCardInfo.txtCCData.value="";
		lastFocusControl = document.getElementById(lastControl);
		
	}
	
	
	function validCreditCard()
	{
	//This function warns user of unsupported c.c. types
	//Called from onNumberBlur().  Used for all C.C. payments
	
		var firstDigits = document.creditCardInfo.firstDigits.value;
		var splitFirstDigits = firstDigits.split(",");
		var cardTypeArray = document.creditCardInfo.cardTypeArray.value;
		var splitcardTypeArray = cardTypeArray.split(",");				
		var validtype;
		validtype = false;
							
		for (i=0;i<splitFirstDigits.length;i++)
		{
			if(accountNumber.substr(0,1) == splitFirstDigits[i]
					|| accountNumber.substr(0,2) == splitFirstDigits[i]
					|| accountNumber.substr(0,3) == splitFirstDigits[i])
			{
				validtype = true;
				document.creditCardInfo.selCreditType.selectedIndex=splitcardTypeArray[i];
			}
		}
							
		if (validtype!=true)
		{
			cbs_alert("This is not an accepted credit card type.");
			document.creditCardInfo.selCreditType.selectedIndex=splitFirstDigits.length;
			document.creditCardInfo.txtCCNumber.value = "";
		}				
	}
	
	
	function setLastControl()
	{
		lastControl = document.activeElement.id;
	}
	
	
	function cancelForm() 
	{
		var custSeqNumber;
		custSeqNumber = document.creditCardInfo.custSeqNumber.value;
		document.creditCardInfo.action = "";
		document.creditCardInfo.submit();		
	}	
	
	function clearAll()
	{
		document.creditCardInfo.style.cursor="default";
		document.creditCardInfo.selCreditType.value = 0;
		document.creditCardInfo.txtCCNumber.value = "";
		document.creditCardInfo.txtCCExpDate.value = "";
		document.creditCardInfo.txtCCCustName.value = "";
		document.creditCardInfo.txtCCData.value = "";
		document.creditCardInfo.txtProcessing.style.visibility="hidden";
		document.creditCardInfo.txtCCZip.style.visibility="hidden";
		document.creditCardInfo.txtCCZip.value="";
		document.creditCardInfo.txtCCZiptag.style.visibility="hidden";		
		document.creditCardInfo.txtCCAddress.style.visibility="hidden";
		document.creditCardInfo.txtCCAddress.value="";
		document.creditCardInfo.txtCCAddresstag.style.visibility="hidden";		
		document.creditCardInfo.txtCCcvc.style.visibility="hidden";
		document.creditCardInfo.txtCCcvc.value="";
		document.creditCardInfo.txtCCcvctag.style.visibility="hidden";
		document.creditCardInfo.txtCCCity.style.visibility="hidden";
		document.creditCardInfo.txtCCCity.value="";
		document.creditCardInfo.txtCCCitytag.style.visibility="hidden";
		document.creditCardInfo.txtCCState.style.visibility="hidden";
		document.creditCardInfo.txtCCState.value="";
		document.creditCardInfo.txtCCStatetag.style.visibility="hidden";
		document.creditCardInfo.fileStatus.value = 0;		
		accountNumber = null;
		expirationDate = null;
		ccCustName = null;
		document.creditCardInfo.processButton.disabled = false;
		removeOldFiles(fileName);	//Added by JJ, 7Jan04
		setFocusOnFirstControl();
		
		SigPad_PromptForMagCard("\\n\\n\\n\\n\\nInsert Card");
		resetMagCardPoll();
	}
	
	
	function clearExtraFields()
	{
		document.creditCardInfo.style.cursor="default";
		document.creditCardInfo.selCreditType.value = 0;
		document.creditCardInfo.txtProcessing.style.visibility="hidden";
		
		if(document.creditCardInfo.txtCCZip.value=="")
		{
			document.creditCardInfo.txtCCZip.style.visibility="hidden";
			document.creditCardInfo.txtCCZiptag.style.visibility="hidden";	
		}
		
		if(document.creditCardInfo.txtCCAddress.value=="")
		{	
			document.creditCardInfo.txtCCAddress.style.visibility="hidden";
			document.creditCardInfo.txtCCAddresstag.style.visibility="hidden";		
			document.creditCardInfo.txtCCCity.style.visibility="hidden";
			document.creditCardInfo.txtCCCity.value="";
			document.creditCardInfo.txtCCCitytag.style.visibility="hidden";
			document.creditCardInfo.txtCCState.style.visibility="hidden";
			document.creditCardInfo.txtCCState.value="";
			document.creditCardInfo.txtCCStatetag.style.visibility="hidden";		
		}
		
		if(document.creditCardInfo.txtCCcvc.value=="")
		{
			document.creditCardInfo.txtCCcvc.style.visibility="hidden";
			document.creditCardInfo.txtCCcvc.value="";
			document.creditCardInfo.txtCCcvctag.style.visibility="hidden";			
		}
				
		document.creditCardInfo.processButton.disabled = false;	
	}
		
		
	function processCC()
	{
	//Main function. 
	// Checks data validity.
	// Builds and names xCharge file, retrieves answer file, cleans up files, and
	// returns to appropriate page.
	//Used for all C.C. payments	
	
		var CCString;
		var ccTotal;	
		var signature;

		SigPad_Prompt("\\n\\n\\nAccept Charges?\\n$" + document.creditCardInfo.ccTotal.value);

		if(SigPad_GetResponse(50000) != SigPad_Accept)
		{
			cbs_alert("Customer did not accept charges");
			document.creditCardInfo.style.cursor="default";
			document.creditCardInfo.txtProcessing.style.visibility="hidden";
			return;
		
		}
		
		SigPad_DisplayText("\\n\\n\\n\\n\\nVerifying...");
		
		
		CCString = "";
		
		ccTotal = document.creditCardInfo.ccTotal.value;
		onFile = document.creditCardInfo.onFile.value;

		document.creditCardInfo.processButton.disabled = true;
		
		ccTotal = document.creditCardInfo.ccTotal.value;
		onFile = document.creditCardInfo.onFile.value;
		
		//Check for valid and needed data
		if(validateCCData()==false)
		{
			return;
		}
		
		document.creditCardInfo.txtProcessing.value = "BUILDING REQUEST STRING"
		
		//Everything checks out. Build string.
		CCString = buildString(CCString,ccTotal);
		
		document.creditCardInfo.txtProcessing.value = "WRITTING REQUEST FILE"
		
		//Create file
		createTempFile(CCString);
		
		document.creditCardInfo.txtProcessing.value = "RENAMING REQUEST FILE"
		
		//Check for .tmp file. If exists, rename as .req
		if(!renameFile(fileName))		//Rename file
		{
			return;				
		}		
		
		document.creditCardInfo.txtProcessing.value = "LOOKING FOR ANSWER"
		
		//Pickup answer file
		getAnswerFile(fileName);
		
		if(timedOut == true)
		{
			document.creditCardInfo.style.cursor="default";
			document.creditCardInfo.txtProcessing.style.visibility="hidden";
			clearAll();	//Added 5Jan04, JJ
			return;
		}
		
		//Delete file
		deleteFile(fileName);
		
		document.creditCardInfo.style.cursor="default";
		
		fileStatus = document.creditCardInfo.fileStatus.value;
		//cbsAlert("fileStatus = "+fileStatus,cbsOKOnly,"JJ");
		
		var isPrePay;
		isPrePay = document.creditCardInfo.isPrePay.value;
		//cbsAlert("isPrePay = "+isPrePay,cbsOKOnly,"JJ");
		
		if(fileStatus != -1)//transaction was APPROVED (-1 indicates DENIED)
		{
			if(document.creditCardInfo.originPage.value=="ApplyPayments")
			{
				document.creditCardInfo.action="ApplyPayments.asp?customerSeq="+document.creditCardInfo.custSeqNumber.value+"&amountpaid="+document.creditCardInfo.ccTotal.value+"&type=CreditCard&change="+fileStatus;
				document.creditCardInfo.submit();
			}
			else
			{
				SigPad_PromptForSignature("\\n\\n\\n" + document.creditCardInfo.txtCCCustName.value + "\\nTotal:" + ccTotal);
				signature = SigPad_GetResponse(500000);
		
		
				if(signature == "" || signature == SigPad_Decline)
				{
					cbs_alert("Signature missing. Please remove transaction from X-Charge if not finished.");
					clearAll();
					signature = ""
					return;
				}

				
				SigPad_DisplayText("\\n\\n\\n\\n\\nThank You");
				
				document.creditCardInfo.signature.value = SigPad_Var2Bmp(signature);
				document.creditCardInfo.signatureReason.value = "Credit card payment";
				
				document.creditCardInfo.action="pickup.asp?userAction=creditCardOnFile&change=" + fileStatus+"&ccpayment=1&isPrePay="+isPrePay;
				document.creditCardInfo.submit();
			}
		}
		
	}


	function saveAndContinue()
	{
	
	}
		
	
	function validateCCData()
	{
	//Checks for valid and needed data
	
		//Type of card
		if (document.creditCardInfo.selCreditType.value==0)
		{
			cbs_alert("Please select the TYPE of card.");
			
			clearExtraFields();
			
			document.creditCardInfo.selCreditType.focus();
			return false;
		}
		
		//Account number or Expiration date missing
		if (document.creditCardInfo.txtCCNumber.value=="" ||
				document.creditCardInfo.txtCCExpDate.value=="")
		{
			if (document.creditCardInfo.txtCCNumber.value=="")
			{
				cbs_alert("Please enter ACCOUNT NUMBER.");				
				clearExtraFields();
				document.creditCardInfo.txtCCNumber.focus();
			}
			else
			{
				cbs_alert("Please enter EXPIRATION DATE.");				
				clearExtraFields();
				document.creditCardInfo.txtCCExpDate.focus();
			}
			return false;
		}
		
		//Account number alphanumeric
		accountNumber=document.creditCardInfo.txtCCNumber.value;
		if(isNaN(accountNumber))
		{
			cbs_alert("ACCOUNT NUMBER is not a number.");
			clearExtraFields();
			document.creditCardInfo.txtCCNumber.focus();
			return false;
		}
		
		//Expiration date invalid
		expirationDate = document.creditCardInfo.txtCCExpDate.value;
		var result
		result = expDateCheck(expirationDate);
		if(result==false)
		{
			return false;
		}			
	
	}
	
	
	function expDateCheck(expirationDate)
	{
	//Checks if c.c. expiration date is valid		
		var d;
		var m, y;
		
		d = new Date();
		m = d.getMonth()+1;
		m = parseInt(m);
		y = d.getFullYear();
		y = parseInt(y);
				
		expirationYear = 20+expirationDate.substr(2,2);
		expirationYear = parseInt(expirationYear);
		expirationMonth = expirationDate.substr(0,2);
		expirationMonth = parseFloat(expirationMonth);	//for some reason parseInt will not properly convert all months
				
		if(expirationYear <= y)
		{
			if(expirationMonth < m)
			{
				cbs_alert("This card has EXPIRED.");
				return false;
			}
		}
		
		if(expirationMonth > 12)
		{
			cbs_alert("Invalid month.");
			return false;
		}
		
		return true;
	}
	
	
	function buildString(CCString,ccTotal)
	{
		var strQCQ = '","';
		var strQ = '"';	
		var tranType;
		var empID;
		var sInvoiceList;
		var ccZip;
		var ccAddress;
		var ccCity;
		var ccState;
		var ccCVC;
		
		tranType = "C1";	//Code used by xCharge
		empID = document.creditCardInfo.empID.value;
		sInvoiceList = "";
		ccTotal = document.creditCardInfo.ccTotal.value;
		
		CCString = strQ+tranType+strQCQ;
		CCString = CCString + empID + strQCQ;
		CCString = CCString + sInvoiceList + strQCQ;
		CCString = CCString + accountNumber + strQCQ;
		if(swipeData!="")//swiped card
		{
			//If swiped, must include entire data string from card (swipedata)
			expirationDate = expirationDate.substr(2,2)+expirationDate.substr(0,2)+swipeData;
		}
		else
		{
			//If not swiped, only send expiration date
			expirationDate = expirationDate.substr(2,2)+expirationDate.substr(0,2);
		}
		CCString = CCString + expirationDate + strQCQ;
		if(swipeData!="")//swiped card
		{
			CCString = CCString + ccTotal + strQ;
		}
		else//NOT a swiped card
		{
			//Collect info from manual enter fields
			ccZip = document.creditCardInfo.txtCCZip.value;
			ccAddress = document.creditCardInfo.txtCCAddress.value;
			ccCity = document.creditCardInfo.txtCCCity.value;
			ccState = document.creditCardInfo.txtCCState.value;
			ccCVC = document.creditCardInfo.txtCCcvc.value;
			
			//Add to string
			if(ccZip!="")
			{
				CCString = CCString + ccTotal + strQCQ;
				CCString = CCString + ccZip + strQ;
			}
			else
			{
				CCString = CCString + ccTotal + strQCQ;
				//if zip is empty, send default
				CCString = CCString + "99999" + strQ;
			}

			if(ccAddress!="" && ccCity!="" && ccState!="")
			{
				ccAddress = ccAddress + " " + ccCity + " " + ccState;
				ccAddress = ccAddress.toUpperCase();
				CCString = CCString + ',"' + ccAddress + strQ;
			}
			if(ccAddress=="")
			{
				CCString = CCString + ',""'
			}
			
			if(ccCVC!="")
			{
				CCString = CCString + ',"' + ccCVC + strQ
			}
			else
			{
				CCString = CCString + ',""'
			}
		}
		
		return CCString;	
	}


	function changeMouse()
	{
		document.creditCardInfo.style.cursor="wait";
	}
	
	
	function createTempFile(CCString)
	{
		var sessionName
		sessionName = document.creditCardInfo.sessionName.value;
		
		var termName
		termName = document.creditCardInfo.terminalId.value;
		
		var pathName
		pathName = document.creditCardInfo.xChargePath.value;
		
		var fsoTempFile = new ActiveXObject("Scripting.FileSystemObject");
		
		if(fsoTempFile.FolderExists(pathName))
		{
			fileName = pathName+"\\"+termName+sessionName;
			document.creditCardInfo.fileName.value = fileName;
		}
		else
		{
			cbs_alert("X-Charge Transaction folder does not exist.\nCheck path in Miscellaneous Setup.");
			return;
		}
		
		
		removeOldFiles(fileName);

		var a = fsoTempFile.CreateTextFile(fileName+".tmp", true);
		a.WriteLine(CCString);
		a.Close();
		
		void fsoTempFile;
	}
	
	
	function removeOldFiles(fileName)
	{
	  var fsoRemove, newName;
	  newName = fileName + ".tmp";
	  fsoRemove = new ActiveXObject("Scripting.FileSystemObject");
	  
	  //.tmp file
	  if(fsoRemove.FileExists(newName))
	  {
		fsoRemove.DeleteFile(newName);
	  }
	  //.req file 
	  newName = fileName + ".req";
	  if(fsoRemove.FileExists(newName))
	  {
		fsoRemove.DeleteFile(newName);
	  }	  
	  //.hld file 
	  newName = fileName + ".hld";
	  if(fsoRemove.FileExists(newName))
	  {
		fsoRemove.DeleteFile(newName);
	  }	
	  //.ans file 
	  newName = fileName + ".ans";
	  if(fsoRemove.FileExists(newName))
	  {
		fsoRemove.DeleteFile(newName);
	  }
	  
	  void fsoRemove;		  	  
	}
		
		
	function renameFile(fileName)
	{
		var fsoRename;
		var f;
		var newName;
		var attemptCounter;
		attemptCounter = 0;
		
		fsoRename = new ActiveXObject("Scripting.FileSystemObject");
		
		while(attemptCounter<=10)
		{
			if (fsoRename.FileExists(fileName + ".tmp"))
			{
				f = fsoRename.GetFile(fileName+".tmp");
				newName = fsoRename.getfilename(fileName)+".req";
				f.Name=newName;
	
				void fsoRename;
				
				return true;
			}
			
			attemptCounter = attemptCounter + 1;	
		}
		
		if(!fsoRename.FileExists(fileName + ".req"))
		{
			cbs_alert("Unable to process transaction.\nPlease try again.");
			void fsoRename;
			return false;
		}				
	}
	
	
	function deleteFile(fileName)
	{
	  var fso, newName;
	  newName = fileName + ".ans";
	  //cbsAlert("newName = "+newName,cbsOKOnly,"JJdeleteFile");
	  fso = new ActiveXObject("Scripting.FileSystemObject");
	  if(fso.FileExists(newName))
	  {
		fso.DeleteFile(newName);
	  }
	}




	function getAnswerFile(fileName)
	{
		var fsoAnswer;
		var newName;
		var approvalMsg;
		var retVal;
		var msg;


		var timeoutSeconds = 120;
		
		fsoAnswer = new ActiveXObject("Scripting.FileSystemObject");
		newName = fileName + ".ans";
		approvalMsg = "";
		timedOut = false;	
		
		//Loop until answer is found, or time-out reached

	
		document.creditCardInfo.txtProcessing.value = "PROCESSING..... LOOKING FOR RESPONSE";
		
		//For next 30 seconds...
		do
		{
			document.creditCardInfo.txtProcessing.value = "PROCESSING..... " + timeoutSeconds;
			
			if(fsoAnswer.FileExists(newName))
				break;
			
			-- timeoutSeconds;
			pause(1000);
		}
		while(timeoutSeconds > 0);
		
		//If the answer is found...
		if(fsoAnswer.FileExists(newName))
		{
			//Open request file
			var f;
			var ts;
			document.creditCardInfo.txtProcessing.value = "RESPONSE FOUND";
			f = fsoAnswer.GetFile(newName);
			ts = f.OpenAsTextStream(1, 0);
			approvalMsg = ts.ReadLine();
			ts.Close( );
		}
		else
		{
			document.creditCardInfo.txtProcessing.value = "REPONSE NOT FOUND";
			cbs_alert("TRANSACTION TIMED OUT.\n\n MAKE SURE X-CHARGE and MODEM ARE WORKING PROPERLY.");
			timedOut = true;
			void fsoAnswer;
			return;
		}
		
		//Hide msg
		document.creditCardInfo.txtProcessing.style.visibility="hidden";
		
		//Handle dis/approval
		if(approvalMsg!="")
		{
			var approvalMsgLength;
			approvalMsgLength = approvalMsg.length;
			var approvalText;
			approvalText = approvalMsg.substr(2,approvalMsgLength-3);
			if(approvalMsg.substr(1,1)=="Y")
			{
				approvalCode = approvalText;
				document.creditCardInfo.approvalCode.value = approvalCode;
				
				if(document.creditCardInfo.creditFormName.value != "")
				{
					PrintReceipt();
				}
				else
				{
					SigPad_DisplayText("\\n\\n\\n\\nPurchase APPROVED\\n" + approvalText);
					cbs_alert("There is no credit receipt form set in Miscellaneous Setup.");
					cbs_alert("Purchase APPROVED\n\nApproval Code:  "+approvalText);					
				}
				
				//if c.c. info already on file AND c.c. number on screen differs...
				if((onFile == 1 || document.creditCardInfo.promptToAddCC.value == 1) && accountNumber != document.creditCardInfo.custCreditCardNo.value)
				{
					msg = "Do you wish to change the credit card information on file?";
					
					retVal = confirm(msg);
							
					if (retVal) 
					{
						//fileStatus = 1 means UPDATE info
						document.creditCardInfo.fileStatus.value = 1;
					}
					else
					{
						//fileStatus = 0 means RETAIN info
						document.creditCardInfo.fileStatus.value = 0;
					}
				}
				void fsoAnswer;
			}
			else
			{
				SigPad_DisplayText("\\n\\n\\n\\nPurchase DENIED\\n" + approvalText);
				cbs_alert("Purchase DENIED\n\nReason:  "+approvalText);
				
				clearAll();	//Added 5Jan04, JJ
				document.creditCardInfo.fileStatus.value = -1;
				void fsoAnswer;
				return;
			}
		}
	}
	
	
	function PrintReceipt()
	{
		var ccAuthCode;
		var ccExpDate;
		var ccType;
		var ccAcctNum;
		var ccCardHolder;
		var ccTotal;
		var ticketNums;
		
		ticketNums = document.creditCardInfo.ticketNums.value;
		ccAuthCode = document.creditCardInfo.approvalCode.value;
		ccExpDate = document.creditCardInfo.txtCCExpDate.value;
		ccType = document.creditCardInfo.selCreditType.value;
		ccAcctNum = document.creditCardInfo.txtCCNumber.value;
		ccAcctNum = "XXXX XXXX XXXX "+ccAcctNum.substr(12,4);	//Blank out first 12 chars.
		ccCardHolder = document.creditCardInfo.txtCCCustName.value;
		ccTotal = document.creditCardInfo.ccTotal.value;
		
		PrintCreditReceipt(ticketNums,ccAuthCode,ccExpDate,ccType,ccAcctNum,ccCardHolder,ccTotal);//passing TICKET #, not inv #
	}
	
	
	//Used for PICKUP payments only
	function printRackLocations() 
	{
		var rackStrForPrint;
		rackStrForPrint = document.creditCardInfo.rackInfoForPrint.value;
		PrintRackLocations(rackStrForPrint);		
	}	
	
	
	function displayProcessing()
	{
		document.creditCardInfo.txtProcessing.style.visibility="visible";
		//cbsAlert("",cbsOKOnly,"");
		document.creditCardInfo.style.cursor="wait";
		changeMouse();
	}
	
	
	function WaitTimer(InTime)
	{
		//JJ, 7Jan04
		//This function allows user to set a wait period.
		//Incoming parameter is the number of seconds to wait.
		//Displays the text message "PROCESSING" in the credit card form.
		//If used in another form, comment out or change the 2 lines beginning
		// with "document..."
		
		//Set timer
		var d, timer;
		var MinMilli;
		MinMilli = 1000 * InTime;
		d = new Date();
		timer = d.getTime();
	
		//For "time" number of seconds...
		do
		{
			d = new Date();
			document.creditCardInfo.txtProcessing.style.visibility="visible";
		}
		while(d.getTime() < (timer+MinMilli));
		
		document.creditCardInfo.txtProcessing.style.visibility="hidden";
	}
	
	
</script>

<BODY topmargin=0 leftmargin=0 onload="setFocusOnFirstControl();beginMagCardPoll();">

<center>

<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/signaturepad.inc" -->
<!-- #include file="../include/cashdrawer.inc" -->
<!-- #include file="../include/localprinter.inc" -->

<%
if originatingPage = "Pickup" then
	'Following adds an "S" to Invoice List and Rack labels if needed
	dim tempString
	dim searchString
	searchString = ","
	dim myPos
	tempString = CStr(InvoiceList)
	myPos = InStr(tempString,searchString)
	if myPos>0 then 
		tempString = "s" 
	else
		tempString = ""
	end if
end if
%>
<B class="pageHeading">&nbsp;Please swipe or enter Credit Card information</B>
</center>

<FORM id="creditCardInfo" name="creditCardInfo" action="creditCardPickup.asp" method="post" onSubmit ="return validateEnterKey();" >

	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>"><!-- JJ added, 13Jan04	-->
	<INPUT type="hidden" name="InvoiceList" value="<%= OnlyFirstInvoice(InvoiceList)%>">
	<INPUT type="hidden" name="ticketNums" value="<%= ticketNums%>">
	<INPUT type="hidden" name="custSeqNumber" value="<%= custSeqNumber%>">
	<INPUT type="hidden" name="empID" value="<%= empID%>">
	<INPUT type="hidden" name="totalInv" value="<%= totalInv%>">
	<INPUT type="hidden" name="terminalId" value="<%= terminalId%>">
	<INPUT type="hidden" name="sessionName" value="<%= sessionName%>">
	<INPUT type="hidden" name="custCreditCardTypeID" value="<%= custCreditCardTypeID%>">
	<INPUT type="hidden" name="custCreditCardNo" value="<%= custCreditCardNo%>">
	<%custCreditCardExpDate = custCreditCardExpMonth&custCreditCardExpYear%>
	<INPUT type="hidden" name="custCreditCardExpDate" value="<%= custCreditCardExpDate%>">
	<INPUT type="hidden" name="ccTotal" value="<%= ccTotal%>">
	<INPUT type="hidden" name="onFile" value="<%= onFile%>">
	<INPUT type="hidden" name="fileStatus" value="<%= fileStatus%>">
	<INPUT type="hidden" name="approvalCode" value="<%= approvalCode%>">
	<INPUT type="hidden" name="creditFormName" value="<%= creditFormName%>">	
	<INPUT type="hidden" name="rackInfoForPrint" value="<%= printRackInfo%>">	
	<INPUT type="hidden" name="xChargePath" value="<%= xChargePath%>">
	<INPUT type="hidden" name="isPrePay" value="<%= isPrePay%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit%>"><!-- Added by J.Johnston, 5Dec03-->
	<INPUT type="hidden" name="fileName" value=""><!-- Added by J.Johnston, 17Feb04-->
	<INPUT type="hidden" name="promptToAddCC" value="<%if ObjMiscSetUp.Item("promptToAddCC") then Response.Write "1" else Response.Write "0" end if%>">
	<INPUT type="hidden" name="tPage" value="<%=targetPage%>">
	<INPUT id=txtCCData name=txtCCData maxLength=200 class=text style=" HEIGHT:1px; WIDTH:1px" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()" onClick="setLastControl()" onKeyPress="changeMouse()" size=5 tabindex=-1>
	<input type = hidden name=signature value= "">
	<input type = hidden name=signatureReason value= "">
	
	<!-- Invoice Number, Total Due, Buttons -->
	<TABLE ALIGN=center WIDTH=90% BORDER=0 CELLSPACING=2 CELLPADDING=0 style="font-size=12pt">
		
		<!-- Invoice and Rack Numbers PICKUP ONLY-->
		<%if originatingPage = "Pickup" then %>
		<TR valign=top>
			<TD class="label" align="right" style=" WIDTH: 30%">Invoice Number<%=tempString%>&nbsp;</TD>
			<TD align=left style=" text-align:left; font-size:12pt; font-style:normal; font-weight:bold">
				<%= InvoiceList%></TD>
				
			<TD class="label" align="right" style=" WIDTH: 15%">Rack<%=tempString%>&nbsp;</TD>
			<TD align=left style="HEIGHT:100%; WIDTH: 25%; text-align:left; font-size:12pt; font-style:normal; font-weight:bold">
				<%= rackString%></TD>				
		</TR>
		<%end if%>
				
		<!-- Total Due -->
		<TR>
			<TD align=right class="label" style="font-style:bold; font-weight:bold; WIDTH:30%">Total&nbsp;</TD>					
			<TD style="color:Red; text-align:left; font-size:12pt; font-style:normal; font-weight:bold">
				$<%= formatnumber(ccTotal,2,true)%>
			</TD>
			<TD><INPUT id=txtCCAddresstag name=txtCCAddresstag class="text" align="right" style="border-style:none; color:red;  background-color:#F7FBFC; text-align:right; VISIBILITY:hidden" value="Address * " readonly tabindex=-1></TD>
			<TD><INPUT id=txtCCAddress name=txtCCAddress maxLength=50 class=text  align=left style="HEIGHT: 25px; font-size=12pt; VISIBILITY:hidden" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()" onClick="setLastControl()" size=5 tabindex=5 value="<%=trim(custPaymentObj.Item("billingAddress1"))%>"></TD>
		</TR>
		
		<!-- Card Type -->
		<TR>
			<TD class="label" align="right">Credit Card Type<font color=red> * </font>&nbsp;</TD>
			
			<TD><SELECT id=selCreditType name=selCreditType style="font-size=12pt" tabindex=1>
				<!-- <Option value = "0" ></option> -->
					<%
						dim creditCardTypes
						Set creditCardTypes = getCreditCardsTypes()
						if creditCardTypes.recordcount <> 0 then
							while not creditCardTypes.EOF
						%>
							<OPTION VALUE= "<%= creditCardTypes.Fields("creditcardTypeId").Value %>" <%if creditCardTypes.Fields("creditcardTypeId").Value = custCreditCardTypeID then %>selected<%end if%>> <%= creditCardTypes.Fields("name").Value %></OPTION>
						<%
								creditCardTypes.MoveNext
							wend
						else
						%>
							<OPTION VALUE= "1">No Credit Cards setup in Setup | Customer Setup</OPTION>
						<%
						end if
					%>	
			<Option value = "0" ></option>
			</SELECT></TD>
			<TD><input id=txtCCCitytag name=txtCCCitytag class="text" align="right" style="width=100%; border-style:none; color:red; background-color:#F7FBFC; text-align:right; VISIBILITY:hidden" value="City * " tabindex=-1 readonly></TD>
			<TD><INPUT id=txtCCCity name=txtCCCity maxLength=15 class=text align=left style="WIDTH: 100%; HEIGHT: 25px; font-size=12pt; VISIBILITY:hidden" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" size=5 tabindex=6 value="<%=trim(custPaymentObj.Item("billingCity"))%>"></TD>
			<INPUT type="hidden" name="firstDigits" value="<%= firstDigits%>" tabindex=-1>
			<INPUT type="hidden" name="cardTypeArray" value="<%= cardTypeArray%>" tabindex=-1>	
		</TR>
		
		<!-- Card Number -->
		<TR>
			<TD class="label" align="right">Account Number<font color=red> * </font>&nbsp;</TD>
			<TD><INPUT id=txtCCNumber tabindex=2 name=txtCCNumber maxLength=200 class=text style=" HEIGHT: 25px; font-size=12pt" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()" onClick="setLastControl()" size=5 value=<%= custCreditCardNo%> ></TD>		
			<TD><input id=txtCCStatetag name=txtCCStatetag class="text" align="right" style="width=100%; border-style:none; color:red; background-color:#F7FBFC; text-align:right; VISIBILITY:hidden" value="State * " tabindex=-1 readonly></TD>
			<TD><INPUT id=txtCCState name=txtCCState maxLength=2 class=text align=left style="WIDTH: 20%; HEIGHT: 25px; font-size=12pt; VISIBILITY:hidden" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" size=5 tabindex=7 value="<%=trim(custPaymentObj.Item("billingState"))%>"></TD>						
		</TR>
		
		<!-- Expiration Date -->
		<TR>
			<TD class="label" align="right">Expiration Date ("mmyy")<font color=red> * </font>&nbsp;</TD>
			<TD><INPUT id=txtCCExpDate tabindex=3 name=txtCCExpDate maxLength=4 class=text style="WIDTH: 50px; HEIGHT: 25px; font-size=12pt" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" size=5 value=<%= custCreditCardExpDate%>></TD>
			<TD><input id=txtCCZiptag name=txtCCZiptag class="text" align="right" style="width=100%; border-style:none; color:red; background-color:#F7FBFC; text-align:right; VISIBILITY:hidden" value="Zip * " readonly tabindex=-1></TD>
			<TD><INPUT id=txtCCZip name=txtCCZip maxLength=5 class=text align=left style="WIDTH: 55px; HEIGHT: 25px; font-size=12pt; VISIBILITY:hidden" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" size=5 tabindex=8 value="<%=trim(custPaymentObj.Item("billingZipCode"))%>"></TD>
		</TR>
		
		<!-- Customer Name on INVOICE -->
		<TR>
			<TD class="label" align="right">Customer Name <%if originatingPage = "Pickup" then %>(on Invoice)<%end if%>&nbsp;</TD>
			<TD align=left style=" text-align:left; font-size:12pt; font-style:normal; font-weight:normal">
				<%= customerName%></TD>
			<TD> <INPUT id=txtCCcvctag name=txtCCcvctag class=text align=right style="width=100%; border-style:none; color:red;  background-color:#F7FBFC; text-align:right; visibility=hidden" value="CVC * " readonly tabindex=-1></TD>
			<TD> <INPUT id=txtCCcvc name=txtCCcvc maxLength=5 class=text  align=left style="WIDTH: 50px; HEIGHT: 25px; font-size=12pt; VISIBILITY:hidden" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" size=5 tabindex=9 value="<%=trim(custPaymentObj.Item("creditCardCVC"))%>"></TD>				
		</TR>
		
		<!-- Customer Name on CARD -->
		<TR>
			<TD class="label" align="right" >Customer Name (on Credit Card)&nbsp;</TD>
			<TD><INPUT id=txtCCCustName name=txtCCCustName maxLength=20 class=text style="WIDTH: 250px; HEIGHT: 25px; font-size=12pt" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" size=5 tabindex=4 value="<%=trim(custPaymentObj.Item("creditCardNameOnCard"))%>"></TD>
			<TD colspan = "2"><INPUT id=txtProcessing name=txtProcessing class=text style="WIDTH: 160px; HEIGHT: 25px; VISIBILITY:hidden; border-style:none;  background-color:#F7FBFC; color:red"  
					 size=5 value="PROCESSING....." readonly>&nbsp;&nbsp;&nbsp;&nbsp;</TD>					
		</TR>
		
		<tr height=10><td></td><td><font color=red>Items marked with * are required.</td></tr>
		
		<!-- Buttons -->
		<tr>	
			<td align="middle" colspan=4>
				<%if originatingPage = "Pickup" then %>
				<INPUT align=right class=touch id=bttnPrintRackLocations name=bttnPrintRackLocations type=button value="" style="background-image:url(../images/Print-Rack.gif)" onClick = "printRackLocations();" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<%end if%>
				<INPUT class=touchnoborder id=processButton name=processButton type=button style="BORDER-RIGHT: deepskyblue thick outset; BORDER-TOP: silver thick ridge; FONT-WEIGHT: bold; FONT-SIZE: 12pt; BORDER-LEFT: silver thick ridge; BORDER-BOTTOM: deepskyblue thick outset; BACKGROUND-REPEAT: no-repeat; FONT-STYLE: italic; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: deepskyblue" onmousedown="displayProcessing()" onClick="processCC()" value="Process">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<INPUT class=touchnoborder id=clearButton name=clearButton type=button style="BORDER-RIGHT: thick outset; BORDER-TOP: snow thick ridge; FONT-WEIGHT: bold; FONT-SIZE: 12pt; BORDER-LEFT: snow thick ridge; BORDER-BOTTOM: thick outset; FONT-STYLE: italic; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: gainsboro; FONT-VARIANT: small-caps" onClick="clearAll()" value="Clear All">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;			
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button style="BACKGROUND-IMAGE: url(../images/Cancel.gif)" onClick="history.back()" >
				<!-- <INPUT class=touchnoborder id=testButton name=testButton type=button value="TEST" style="" onClick="testFunction()">-->				
			</td>
		</tr>
		
	</TABLE>
	
	<!-- Keyboard -->
	<table ALIGN=center width="100%">
		<tr height=20><td></td></tr>
		<TR height=20 colspan="5"></TR>
		<tr>
			<td><!-- #include file="../include/keyboard.inc" --></td>
		</tr>
				
	</table>
	
</FORM>
</BODY>
</HTML>
