<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim invoice
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim onHold, addOrEdit
	dim actionString
	dim submitAction
	dim validate 
	dim noOfInv, counter
	dim alertMessage
	dim targetPage, originatingPage
	
	alertMessage =""
	actionString = Request.QueryString("userAction")	
	set invoice = Session("invoice")
	noOfInv = invoice.getNoOfInvoices()
	if IsEmpty(actionString) then
		targetPage = Request.QueryString("targetPage")
		select case targetPage
			case "detail", "counterSale"
					collectInputDataFromQueryString
			case "prompt"
					collectInputDataFromForm
		end select
	else
		collectInputDataFromForm
		targetPage = Request.Form("tPage")
		if actionString ="submitted" then
			submitAction = Request.QueryString("submitAction")
			if submitAction ="ok" then
				validate =  validateInvNumber()
				if validate then
					saveInvoice
				end if
			else
				select case targetPage
					case "detail"
							Response.Redirect "detailedInvoice.asp?userAction=newInvoiceNo&submit=cancel" _
									& "&addOrEdit=" & addOrEdit _
									& "&onHold=" & onHold &  "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
									& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
									& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
									& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
									& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue _
									& "&originPage=" & originatingPage
					case "counterSale"
							Response.Redirect "counterSale.asp?userAction=newInvoiceNo&submit=cancel" _
									& "&addOrEdit=" & addOrEdit _
									& "&onHold=" & onHold &  "&lineNo=" & curr_LineNo & "&dept=" & selectedDept _
									& "&upIndex=" & upChargeStartIndex & "&cIndex=" & colorsStartIndex _
									& "&pIndex=" & patternStartIndex & "&itIndex=" & itemsStartIndex _
									& "&deptIndex=" & deptStartIndex & "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
									& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue
				end select
			end if
		end if
	end if
	
	sub collectInputDataFromForm()
		dim goToPage
		
		originatingPage = Request.Form("originPage")
		addOrEdit = Request.Form("addOrEdit")
		onHold = Request.Form("onHold")
		curr_LineNo = Request.Form("lineNumber")
		selectedDept = Request.Form("selectedDept")
		itemsStartIndex = Request.Form("ItemPageCount")
		upChargeStartIndex = Request.Form("upChargePageCount")
		colorsStartIndex = Request.Form("colorsPageCount")
		patternStartIndex = Request.Form("PatternPageCount")
		deptStartIndex = Request.Form("DeptPageCount")
		selItemId = Request.Form("selItemId")
		selUpchargeValue = Request.Form("selUpcharge")
		selColorValue = Request.Form("selColor")
		selPatternValue = Request.Form("selPattern")
		goToPage = Request.QueryString("goToPage")
		targetPage = goToPage
	end sub
	
	sub collectInputDataFromQueryString()
		addOrEdit = Request.QueryString("addOrEdit")
		onHold = Request.QueryString("onHold")
		curr_LineNo = Request.QueryString("lineNo")
		selectedDept = Request.QueryString("dept")
		itemsStartIndex = Request.QueryString("itIndex")
		upChargeStartIndex = Request.QueryString("upIndex")
		colorsStartIndex = Request.QueryString("cIndex")
		patternStartIndex = Request.QueryString("pIndex")
		deptStartIndex = Request.QueryString("deptIndex")
		selItemId = Request.QueryString("selItemId")
		selUpchargeValue = Request.QueryString("selUp")
		selColorValue = Request.QueryString("selColor")
		selPatternValue = Request.QueryString("selPattern")
		originatingPage = Request.QueryString("originPage")
	end sub
	
	sub saveInvoice()
		dim intLoop
		dim aInvoiceNo
		dim invoicesDictionary
		dim invoicesArray
		dim aInvoice
		dim ObjMiscSetUp
		dim tagsSameAsInvNos
		dim printTagsForHeatSeal
			
		if Not IsObject(Session("miscSetUp")) then
			initializeMiscSetUp
		end if
				
		set ObjMiscSetUp = Session("miscSetUp")
		if ObjMiscSetUp.Count > 0 then
			tagsSameAsInvNos = ObjMiscSetUp.Item("sameTagInvNumber")
			printTagsForHeatSeal =  ObjMiscSetUp.Item("printTagsForHeatSealItems")
		else
			tagsSameAsInvNos = true
			printTagsForHeatSeal = false
		end if
		'set invoice = Session("invoice")
		'if not IsObject(Session("taxCodes")) then
		'	getTaxCodes 
		'end if
		'set taxCodes = Session("taxCodes")	
		'invoice.invoiceDone oneDiscount, taxCodes
		'if err.number <> 0 then
		'	set errorList =  Server.CreateObject("Scripting.Dictionary")
		'	errorList.Add err.number,err.description & "-Function= Multiple Invoice Numbers -saveInvoice"
		'	set session("errorList") = errorList
		'	Response.redirect("../include/error.asp")
		'end if
		'
		'
		'set invoicesDictionary = invoice.splitInvoice(addOrEdit)
		set invoicesDictionary = invoice.invoicesDictionary
		invoicesArray = invoicesDictionary.Items
		select case addOrEdit
			case "add"
					invoice.invoiceNo = Request.Form("txtInvNo")(1)
					for intLoop=2 to Request.Form("txtInvNo").Count
						aInvoiceNo = Request.Form("txtInvNo")(intLoop)
						set aInvoice = invoicesArray(intLoop-2)
						aInvoice.invoiceNo = aInvoiceNo
					next
			case "edit"
					for intLoop=1 to Request.Form("txtInvNo").Count
						aInvoiceNo = Request.Form("txtInvNo")(intLoop)
						set aInvoice = invoicesArray(intLoop-1)
						aInvoice.invoiceNo = aInvoiceNo
					next
		end select
		if targetPage = "counterSale"  then
			invoice.tagsSameAsInvNos = true
			saveInvoiceToDatabase false, false
		else
			invoice.tagsSameAsInvNos = tagsSameAsInvNos
			if tagsSameAsInvNos then
				saveInvoiceToDatabase true, printTagsForHeatSeal
			else
				Response.Redirect "addTagNumber.asp?addOrEdit=" & addOrEdit & "&originPage=" & originatingPage
			end if
		end if
	end sub
	
	sub saveInvoiceToDatabase(tagsSameAsInvNo, printTagsForHeatSeal)
		dim empName
		dim storeName
		dim empId
		dim terminalId
		dim custSeqNumber
		dim invNumber
		dim transactionchangedue
		on error resume next
		custSeqNumber = Session("customersequencenumber")
		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")
		invoice.saveInvoice addOrEdit, empId, terminalId, 0, empName, storeName, true
		transactionchangedue = invoice.transactionchangedue
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Multiple Invoice Numbers  saveInvoiceToDatabase- saveInvoice"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		if tagsSameAsInvNo then
			invoice.insertTagsForTicket printTagsForHeatSeal
			if err.number <> 0 then
				set errorList =  Server.CreateObject("Scripting.Dictionary")
				errorList.Add err.number,err.description & "-Function= Multiple Invoice Numbers insertTagsForTicket"
				set session("errorList") = errorList
				Response.redirect("../include/error.asp")
			end if
		end if
		invNumber = invoice.getTicketNosForPrinting()
		Response.Redirect "customerfunctions.asp?userAction=print&addOrEdit=" _
							& addOrEdit & "&ticketNumber=" & invNumber _
							& "&invoiceType=D&customerseq=" & custSeqNumber _
							& "&totalchangedue=" & transactionchangedue
	end sub
	
	sub getTaxCodes()
		dim objResultSet
		dim ssql
		dim storeId
		
		on error resume next
		storeId = Session("storeID")
		ssql = "Select taxCode, description, taxPercent FROM Tax Where storeID=" & clng(storeId)
		set objResultSet = getDisconnectedRecordset(ssql)
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Multiple Invoice Numbers- getTaxCodes"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		set Session("taxCodes") = objResultSet
	end sub
			
	function validateInvNumber()
		dim ssql
		dim storeId
		dim objResultSet
		dim invNos, aInvoiceNo
		dim intLoop
		dim retval
		dim tempInvNosList()
		dim occurence
		dim counter
		dim noOfElements
		
		retval =true
		storeId = Session("storeID")
		invNos = ""
		Redim tempInvNosList(Request.Form("txtInvNo").Count)
		noOfElements = Request.Form("txtInvNo").Count
		for intLoop=1 to Request.Form("txtInvNo").Count
			aInvoiceNo = Request.Form("txtInvNo")(intLoop)
			tempInvNosList(intLoop-1) = UCase(aInvoiceNo)
			if aInvoiceNo = "" then
				retval = false
				Session("errorMessage") = "Must enter all invoice numbers. Go back and enter all number(s)."
				Response.Redirect "invoiceErrorMessages.asp"
				exit for
			else
				invNos =  invNos &  "'" & aInvoiceNo & "',"
			end if
		next
		invNos = Left(invNos, Len(invNos) - 1)
		intLoop = 1
		while intLoop <= noOfElements and retval
			aInvoiceNo = Request.Form("txtInvNo")(intLoop)
			occurence = 0
			for counter = 0 to noOfElements -1
				if tempInvNosList(counter) = UCase(aInvoiceNo) then
					occurence = occurence + 1
					if occurence > 1 then
						retval = false
						Session("errorMessage") = aInvoiceNo &  " is repeated multiple times. Go back and enter new number(s)."
						Response.Redirect "invoiceErrorMessages.asp"
						exit for
					end if
				end if
			next
			intLoop = intLoop +1
		wend
		
		if retval then
			ssql = "Select invoiceNumber from Ticket where storeId=" & storeId _
					& " And invoiceNumber IN (" & invNos & ")"
			set objResultSet = getDisconnectedRecordset(ssql)
			if objResultSet.Recordcount > 0 then
				retval =false
				invNos = ""
				objResultSet.MoveFirst
				while not objResultSet.eof
					invNos =  invNos & " " & objResultSet.Fields("invoiceNumber").Value
					objResultSet.MoveNext
				wend
				Session("errorMessage") = invNos &  " are duplicate invoice number(s). Go back and enter new number(s)."
				Response.Redirect "invoiceErrorMessages.asp"
			end if
		end if
		validateInvNumber = retval
	end function
	
	
%>
<HTML>
<HEAD>
<TITLE>Multiple Invoice Numbers</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
	var lastFocusControl;
function txtInvNo_onblur() {
	lastFocusControl = event.srcElement;
}
	
//-->
</SCRIPT>
</HEAD>
<script language="javascript" type="text/javascript">
	var alertMessage = null;
	function submitForm(userAction) {
		document.multiInvNo.action = "?userAction=submitted&submitAction=" + userAction;
		document.multiInvNo.submit();
	}
	function checkForAlertMessages() {
		<%
			if Len(alertMessage) > 0 then
			Response.Write "alertMessage='"
			Response.Write alertMessage
			Response.Write "'" 
			end if
		%>
		if (alertMessage != null){
			cbs_alert (alertMessage);
		}
	}
	
	function showfocusonInvNumber() {
		var noOfInvs;
		noOfInvs = eval(document.multiInvNo.noOfInvoices.value);
		if (noOfInvs > 1){
			document.multiInvNo.txtInvNo(0).focus();
		}else{
			document.multiInvNo.txtInvNo.focus();
		}
	}
	
	function checkEnter(element){ 	
		var code = 0;
		var noOfInvs;
		var nextNo;
		
		noOfInvs = eval(document.multiInvNo.noOfInvoices.value);
		code = event.keyCode;
		if (code==13){
			if (noOfInvs > 1){
				if (element.id == noOfInvs) {
					submitForm("ok");
				}else{
					nextNo = eval(element.id);
					document.multiInvNo.txtInvNo(nextNo).focus();
				}
			}else{
				submitForm("ok");
			}
		}
	}
	
</script>
<BODY leftMargin=0 topMargin=0 onLoad="checkForAlertMessages();showfocusonInvNumber();">
<!-- #include file="../include/banner.inc" -->
<H1>Enter Invoice Numbers</H1>
<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
	<FORM id="multiInvNo" name="multiInvNo" action="multipleInvoiceNos.asp" method="post" onSubmit="return false;">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="onHold" value="<%= onHold %>">
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	<INPUT type="hidden" name="noOfInvoices" value="<%= noOfInv %>">
	<%
		counter = 1
		while counter <= noOfInv
	%>
		<tr>
			<td width=50px></td>
			<td class="label">Enter Invoice Number</td>
			<td>
				<INPUT id="<%= counter%>" name="txtInvNo" class=text onblur="txtInvNo_onblur()" style="width:250px;" onKeyPress="checkEnter(this);">
			</td>
		</tr>
	<%	
		counter = counter + 1 			
		wend
	%>
		<tr>
			<td width=50px></td>
			<td></td>
			<td align=center>
				<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align="center" width="60px">
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick= "submitForm('ok')">
						</td>
						<td align="center" width="60px">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="submitForm('cancel');">
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<TR height=20px></TR>
		<tr>
			<td colspan=3>
				<!-- #include file="../include/keyboard.inc" -->
			</td>
		</tr>
	</form>
</table>
</BODY>
</HTML>

