<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 360 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->

<!--#include file="../include/form_merge.asp" -->
<!--#include file="../include/schedule.asp" -->

<!--#include file="../include/security.asp" -->

<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim queryName
	dim queryTransformed
	dim query, rs
	dim userQueryID
	dim formTemplate
	dim merge
	dim employeeEmailAddr
	
	userQueryID = getReqVar("userQueryID")
	queryTransformed = getReqVar("query")
	queryName = getReqVar("queryName")
	merge = getReqVar("merge")
	
	queryName = getQueryName(userQueryID)
	
	select case lcase(request.querystring("useraction"))
	case "save"

		saveScheduledQuery
		CBS_preformScheduledActions
		response.redirect "querydb.asp?userQueryID=" & Server.URLEncode(userQueryID) & "&query=" & Server.URLEncode(queryTransformed)
	
	end select


	function saveScheduledQuery()
		dim query, rs

		query = " insert into ScheduledQuery (name, query, scheduledDate, interval, intervalunit, formid, destination, destinationtype) "
		query = query & " values ("
		query = query & DbCreateQryString(request.form("name"))
		query = query & ", " & DbCreateQryString(queryTransformed)
		query = query & ", " & DbCreateQryString(request.form("scheduleddate"))
		if request.form("repeat") = 1 then
			query = query & ", " & DbCreateQryNumeric(request.form("interval"))
			query = query & ", " & DbCreateQryString(request.form("intervalunit"))
		else
			query = query & ", null"
			query = query & ", null"
		end if
		query = query & ", " & DbCreateQryNumeric(request.form("formid"))
		query = query & ", " & DbCreateQryString(request.form("email"))
		query = query & ", " & DbCreateQryString(request.form("destinationtype"))
		query = query & ")"

		qryexecute query
	end function
	
	function getEmployeeEmailAddr(employeeID)
		dim query, rs
		
		if employeeID <> "" then
			query = " select isnull(email, '') as email from employee where employeeid = " & employeeid
			
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getEmployeeEmailAddr = rs("email")
			end if
			
			set rs = nothing
		end if
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getQueryName(userQueryID)
		dim query, rs
		
		if userQueryID <> "" then
			query = "select name from userquery where userqueryid = " & userqueryid
			
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then getQueryName = rs("name")
		end if
	
	end function


	function getStoreName()
		dim query, rs

		query = "select name from store where storeid = " & Session("storeid")
		set rs = getdisconnectedrecordset(query)

		getStoreName = rs("name")

		set rs = nothing
	end function

	function getStoreEmail()
		dim query, rs

		query = "select isnull(email, '') as email from store where storeid = " & Session("storeid")
		set rs = getdisconnectedrecordset(query)

		getStoreEmail = rs("email")

		set rs = nothing
	end function
%>

<HTML>
<HEAD>
<TITLE>Schedule Query</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<SCRIPT LANGUAGE="javascript" >


	function exit() {
		document.queryschedule.action = "querydb.asp";
		document.queryschedule.submit();
	}

	function save() {
		document.queryschedule.action = "?useraction=save";
		document.queryschedule.submit();
	}
	
	function showInterval(val) {
		if(val)
			$('#interval_el').show();
		else
			$('#interval_el').hide();
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->

<FORM name="queryschedule" ID="queryschedule" METHOD=POST  style="margin:0;padding:0"> 
<INPUT type="hidden" name="queryName" value="<%=Server.URLEncode(queryName)%>" />
<INPUT type="hidden" name="query" value="<%=queryTransformed%>" />
<INPUT type="hidden" name="userQueryID" value="<%=userQueryID%>" />

<H1>Schedule Query</H1><BR />
<BR />

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">

	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="exit()" value="" >Cancel</BUTTON>
		<BUTTON onclick="save()" value="" >Save</BUTTON>
	</SPAN>
</DIV>

<TABLE class="itable" style="width:100%" cellpadding="0" cellspacing="0">
	<TR align="left">
		<TH>Attribute</TH>
		<TH>Value</TH>
	</TR>
	<TR>
		<TD>Schedule Name</TD>
		<TD><INPUT name="name" style="width:200px" value="<%=queryName%>"></TD>
	</TR>
	<TR>
		<TD>Scheduled Date</TD>
		<TD>
			<SELECT name="repeat" onchange="showInterval(this.value != '0')">
				<OPTION value="0">Run Once</OPTION>
				<OPTION value="1">Repeat</OPTION>
			</SELECT>

			<INPUT readonly name="scheduleddate" style="width:80px;text-align:center" value="<%=Date()%>" onClick="javascript:show_calendar('queryschedule.scheduleddate');">
			after
			<SELECT>
				<OPTION value="0">12:00 AM</OPTION>
				<OPTION value="1">1:00 AM</OPTION>
				<OPTION value="2">2:00 AM</OPTION>
				<OPTION value="3">3:00 AM</OPTION>
				<OPTION value="4">4:00 AM</OPTION>
				<OPTION value="5">5:00 AM</OPTION>
				<OPTION value="6">6:00 AM</OPTION>
				<OPTION value="7">7:00 AM</OPTION>
				<OPTION value="8">8:00 AM</OPTION>
				<OPTION value="9">9:00 AM</OPTION>
				<OPTION value="10">10:00 AM</OPTION>
				<OPTION value="11">11:00 AM</OPTION>
				<OPTION value="12">12:00 PM</OPTION>
				<OPTION value="13">1:00 PM</OPTION>
				<OPTION value="14">2:00 PM</OPTION>
				<OPTION value="15">3:00 PM</OPTION>
				<OPTION value="16">4:00 PM</OPTION>
				<OPTION value="17">5:00 PM</OPTION>
				<OPTION value="18">6:00 PM</OPTION>
				<OPTION value="19">7:00 PM</OPTION>
				<OPTION value="20">8:00 PM</OPTION>
				<OPTION value="21">9:00 PM</OPTION>
				<OPTION value="22">10:00 PM</OPTION>
				<OPTION value="23">11:00 PM</OPTION>
			</SELECT>
		</TD>
	</TR>
	<TR id="interval_el" style="display: none">
		<TD>Interval</TD>
		<TD>
			every
			<SELECT name="interval">
				<OPTION>1</OPTION>
				<OPTION>2</OPTION>
				<OPTION>3</OPTION>
				<OPTION>4</OPTION>
				<OPTION>5</OPTION>
				<OPTION>6</OPTION>
				<OPTION>7</OPTION>
				<OPTION>8</OPTION>
				<OPTION>9</OPTION>
				<OPTION>10</OPTION>
				<OPTION>11</OPTION>
				<OPTION>12</OPTION>
				<OPTION>13</OPTION>
				<OPTION>14</OPTION>
				<OPTION>15</OPTION>
				<OPTION>16</OPTION>
				<OPTION>17</OPTION>
				<OPTION>18</OPTION>
				<OPTION>19</OPTION>
				<OPTION>20</OPTION>
				<OPTION>21</OPTION>
				<OPTION>22</OPTION>
				<OPTION>23</OPTION>
				<OPTION>24</OPTION>
				<OPTION>25</OPTION>
				<OPTION>26</OPTION>
				<OPTION>27</OPTION>
				<OPTION>28</OPTION>
				<OPTION>29</OPTION>
				<OPTION>30</OPTION>
			</SELECT>


			<SELECT name="intervalunit">
				<OPTION value="yyyy">Year</OPTION>
				<OPTION value="q">Quarter</OPTION>
				<OPTION value="m">Month</OPTION>
				<OPTION value="d" selected>Day</OPTION>
				<OPTION value="ww">Week</OPTION>
				<OPTION value="h">Hour</OPTION>
				<OPTION value="n">Minute</OPTION>
				<OPTION value="s">Second</OPTION>
			</SELECT>


		</TD>
	</TR>
	
	<TR>
		<TD>Merge and send</TD>
		<TD>
			<INPUT name="destinationtype" type="hidden" value="emailmerge">
			
			form
			<SELECT name="formid">
			
			<%
				query = " select formid, name from htmlform "
				set rs = getdisconnectedrecordset(query)
				
				while not(rs.eof or rs.bof)
			%>
				
				<OPTION value="<%=rs("formid")%>"><%=server.htmlencode(rs("name"))%></OPTION>
			<%
					rs.movenext
				wend
				set rs = nothing
			%>
			</SELECT>
			to email field
			<SELECT name="email">
			
<%
		dim idx
		
		query = queryTransformed
		set rs = getdisconnectedrecordset(query)

		for idx = 0 to rs.Fields.Count - 1
%>
				<OPTION <%if lcase(rs.Fields(idx).Name) = "email" then%>selected<%end if%>><%=Server.HTMLEncode(rs.Fields(idx).Name)%></OPTION>
<%
		next
%>
			</SELECT>
		</TD>
	</TR>

</TABLE>

</FORM>
</BODY>
</HTML>

