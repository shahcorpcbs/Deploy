<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim ObjMiscSetUp
	dim autoInvNos
	dim deptStartIndex
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim targetPage
	
	if IsObject(Session("miscSetUp")) then
		set ObjMiscSetUp = Session("miscSetUp")
	else
		set ObjMiscSetUp = Server.CreateObject("Scripting.Dictionary")	
	end if
	if ObjMiscSetUp.Count > 0 then
		autoInvNos = ObjMiscSetUp.Item("useAutomaticInvoiceNumbers")
		if autoInvNos then
			autoInvNos ="1"
		else
			autoInvNos ="0"
		end if
	else
		autoInvNos = "0"
	end if	
	selectedDept = Request.QueryString("dept")
	addOrEdit = Request.QueryString("addOrEdit")
	deptStartIndex = Request.QueryString("deptIndex")
	
%>
<HTML>
<HEAD>
<TITLE>Prompt To Split</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(userAction) {
		var autoInvNos
		var addOrEdit
		
		addOrEdit = document.splitPrompt.addOrEdit.value;
		autoInvNos = document.splitPrompt.autoInvNos.value;
		//targetPage = document.splitPrompt.tPage.value;
		if (userAction == "yes") {
			if (autoInvNos == "1"){
				document.splitPrompt.action = "quickInvoice.asp?userAction=split";
			}
			else{
				document.splitPrompt.action ="multipleInvoiceNosForQuickInv.asp?targetPage=prompt";
			}
			
		}else{
			if (autoInvNos == "1") {
				document.splitPrompt.action = "quickInvoice.asp?userAction=nosplit";
									
			}else{
				if (addOrEdit == "add"){
					document.splitPrompt.action = "newInvoiceNumber.asp?userAction=nosplit";
				}
				else {
					document.splitPrompt.action = "quickInvoice.asp?userAction=nosplit";
				}
			}
		}
		document.splitPrompt.submit();
	}
</script>
<BODY topmargin=0 leftmargin=0>
	<!-- #include file="../include/banner.inc" -->
<TABLE ALIGN=center WIDTH="250px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
	<FORM id="splitPrompt" name="splitPrompt" action="promptToSplit.asp" method="post">
		<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
		<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
		<INPUT type="hidden" name="onHold" value="0">
		<INPUT type="hidden" name="tPage" value="quick">
		<INPUT type="hidden" name="autoInvNos" value="<%= autoInvNos%>">
		<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
		<tr height=100px><td></td></tr>
		<tr>
			<td class=label colspan=2> Do you want to split the invoices?
			</td>
		</tr>
		<tr height=10px><td></td></tr>
		<tr>
			<td align="center" width="80px">
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick= "submitForm('yes')">
			</td>
			<td align="center" width="80px">
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="submitForm('no')">
			</td>
		</tr>
		
	</form>
</table>
</BODY>
</HTML>
