<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs, connectionId
	connectionId = Request.QueryString("connectionId")

	query = "select pmi.Id, TicketNumber, InvoiceNumber, CustomerName, Departments, NumOfPieces, DueDate, ScannedDate, Location, Status " _
	    & " from PlantManifestItem pmi, ConnectionItemsLink cil where cil.ItemId = pmi.Id and cil.ConnectionId = " & connectionId
	set rs = getdisconnectedrecordset(query)
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" src="../external/jquery.js"></script>
<script language="javascript" type="text/javascript">

    function print() {
        var divToPrint = document.getElementById("items");
        var html = divToPrint.outerHTML.replace('cellspacing="0"', 'cellspacing="10"')
        newWin = window.open("");
        newWin.document.write(html);
        newWin.print();
        newWin.close();
    }

	function exit() {
		document.plantManifest.action = "/mainapp/plantManifests.asp";
		document.plantManifest.submit();
	}
	
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->
<FORM name="plantManifest" ID="plantManifest" METHOD=POST  style="margin:0;padding:0" onSubmit="return false">


<H1>Manifest</H1>
<BR><BR>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="clear: both;margin-bottom:0">
	<SPAN style="float:right">
		<BUTTON onclick="print()">Print</BUTTON>
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" cellspacing="0" id="items">
<TR id="thead">
	<TH>Invoice</TH>
	<TH>Location</TH>
	<TH>Current Status</TH>
	<TH>Last Scanned Date</TH>
	<TH>Due Date</TH>
	<TH>Customer</TH>
	<TH>Pieces</TH>
</TR>
<%
	while not(rs.eof or rs.bof)
%>
<tr>
    <td><%= rs("invoiceNumber")%></td>
    <td><%= rs("Location")%></td>
    <td>
    <% if rs("Status") = 1 then %>
        Manifest Created
    <% elseif rs("Status") = 2 then %>
        Received At Plant
    <% elseif rs("Status") = 3 then %>
        Cleaned
    <% elseif rs("Status") = 4 then %>
        Returned
    <% end if %>
    </td>
    <td><%= rs("ScannedDate")%></td>
    <td><%= rs("DueDate")%></td>
    <td><%= rs("CustomerName")%></td>
    <td><%= rs("NumOfPieces")%></td>
</tr>
<%
	rs.movenext
	wend
%>

</TABLE>

</FORM>
</BODY>
</HTML>
