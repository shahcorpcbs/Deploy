<%@ Language=VBScript %>

<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim transactionAmt
	dim customerSequenceNumber
	
	transactionAmt = 1
	
	
	function addLeadingZeros(value, leadingZeros)
		value = CStr(value)
		
		while len(value) < leadingZeros
			value = "0" & value
		wend
		
		addLeadingZeros = value
	end function

	
	sub d_optionRange(minValue, maxValue, selValue, leadingZeros)
		dim index
		
		for index = minValue to maxValue
			Response.Write "<OPTION value=""" & index & """"
			if index = selValue then
				Response.Write " selected"
			end if
			Response.Write ">"
			Response.Write addLeadingZeros(index, leadingZeros)
			Response.Write "</OPTION>"
		next
	end sub
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Process Credit Card</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">



<STYLE  type="text/css" >
	.progressBar {
		border: 1px solid #ddd;
		width: 220px;
		padding: 0;
		background: white;
		height: 20px;
		overflow: hidden;
		text-align: center;
		background: url(/Images/ajax_loader_bar.gif);
		display: none;

	}
	.progressBar.progressIndicator {
		padding: 0px;
		margin: 0px;
		background: #d8a;
		position: absolute;
		top: 0;
		left: 0;
		width: 50%;
		height: 100%;
		background: url(/Images/ajax_loader_bar_full.gif);
	}
	.progressMessage {
	}
	
</STYLE>

</HEAD>

<script language="javascript" src="../external/jquery-3.4.1.js"></script>
<script language="javascript" src="../external/jquery.form.js"></script>

<script language="javascript" type="text/javascript">

var transactionID = "";
var timerID = null;

$(document).ready(
	function()
	{
		readyAjaxForm();
	}
);

function readyAjaxForm() {
	$('#creditCardTransaction').submit(function() { 
	    submitRequest();
	    return false; 
	});
}

function validateForm() {
	
}

function processResult(response, statusText) {

	$("#progressMessage").html(response.answer);

	transactionID = response.transactionID;
	
	$("#progressIndicator").css("width", response.progress);

	if(response.success == "")
		startTimer();
	else
		processAnswer(response);
	
}

function returnAnswer() {
	
	
}

function processAnswer(response) {
	stopTimer();
	
	if(response.success == "Y") {
		
	}
	else {
		alert(response.answer);
	}
}

function showError(request, message, exception) {
	alert(message + ":" + exception);
}

function submitRequest() {

	
  var options = { 
    	url: "/data/ccprocessing_transaction.asp?transactionID=" + transactionID,
			timeout: 3000,
      error: showError,
      dataType: 'json',
      beforeSubmit: validateForm,
      success: processResult
  }; 
    
	$("#creditCardTransaction").ajaxSubmit(options); 
}

function startTimer() {
	if(timerID) {
		stopTimer();
	}
	timerID = setTimeout("submitRequest()", 1000);
	$("#progressBar").show();
}

function stopTimer() {
	clearTimeout(timerID);
	$("#progressBar").hide();
}

function cancelTransaction() {
	if(timerID) {
		stopTimer();
		// TODO: send request to cancel
		transactionID = ""
	}
	else {
		// go back
	}
}



</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="">

<B class="pageHeading">Process Credit Card Transaction</B>

<FORM id="creditCardTransaction" name="creditCardTransaction" action="/data/ccprocessing_transaction.asp" method="post">

	<INPUT type="hidden" name="customerSequenceNumber" value="<%=customerSequenceNumber%>" />
	<INPUT type="hidden" name="transactionType" value="C1" />
	<INPUT type="hidden" name="clerk" value="<%=employeeID%>" />
	<INPUT type="hidden" name="comment" value="" />

	
	<TABLE style="" cellspacing=0 cellpadding=2>

	
		<TR>
			<TD style="width:150px">Amount:</TD>
			<TD><INPUT style="font-size:16" name="amount" readonly value="<%=transactionAmt%>" /></TD>
		</TR>
		
		<TR>
			<TD style="width:150px">Credit Card Number:</TD>
			<TD><INPUT style="font-size:16" name="accountNumber" value="" /></TD>
		</TR>
	
		<TR>
			<TD>Expiration Date:</TD>
			<TD>
				<SELECT style="font-size:16" name="expirationMonth">
					<%d_optionRange 1, 12, "",  2%>
				</SELECT>
				
				
				<SELECT style="font-size:16" name="expirationYear">
					<%d_optionRange Year(Date()), Year(Date()) + 20, "", 4%>
				</SELECT>	
			</TD>
		</TR>
	
		<TR>
			<TD>CVV2 Code:</TD>
			<TD><INPUT style="font-size:16" name="cvv2" style="width:35px" value=""><BR>
			</TD>
		</TR>
	
		<TR>
			<TD></TD>
			<TD colspan=2>The CVV2 codes normally appear on the back of the card in the signature area.</TD>
		</TR>
	
	
		<TR>
			<TD>Billing Address:</TD>
			<TD><INPUT style="font-size:16" name="address" value="" ></TD>
		</TR>
	
		<TR>
			<TD>Billing Zip Code:</TD>
			<TD><INPUT style="font-size:16" name="zipCode" value=""></TD>
		</TR>
	
		<TR style="height:70px">
			<TD></TD>
			<TD colspan="2" valign="bottom">
				<INPUT style="width:100px;height:50px;" type=submit name="processButton" value="Process" />
				<INPUT style="width:100px;height:50px;" type=button name="clearButton" value="Clear" />
				<INPUT style="width:100px;height:50px;" type=button name="cancelButton" onclick="cancelTransaction()" value="Cancel"/>
			</TD>
		</TR>
	</TABLE>
</FORM>

<BUTTON onclick="submitRequest()">Test</BUTTON>


<DIV class="progressBar" id="progressBar">
	<DIV class="progressIndicator" id="progressIndicator">&nbsp;</DIV>
	<DIV class="progressMessage" id="progressMessage">Hello World!</DIV>
</DIV>



</BODY>
</HTML>
