<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim employeeID
	dim query, rs
	dim employeeTimeID
	dim dateRangeStart
	dim dateRangeEnd
	dim message
	dim loggedInEmployeeID


	employeeTimeID = getReqVar("employeetimeid")
	employeeID = session("setupEmployeeid")
	loggedInEmployeeID = session("employeeid")
	
	dateRangeStart = getReqVar("dateRangeStart")
	dateRangeEnd = getReqVar("dateRangeEnd")
	
	if dateRangeStart = "" then
		dateRangeStart = dateadd("yyyy", -1, date())
	end if
	
	if dateRangeEnd = "" then
		dateRangeEnd = date()
	end if
	
	select case lcase(request.querystring("useraction"))
		case "updatecycle"
			updateCycle
		case "addcycle"
			addCycle
		case "deletecycle"
			deleteCycle employeeTimeID
		case "newcycle"
			employeeTimeID = ""
	end select
	
	function updateCycle()
		dim clockInDateTime
		dim clockOutDateTime

		clockInDateTime = getClockInDateTime()
		clockOutDateTime = getClockOutDateTime()
	
		if datediff("s", clockInDateTime, clockOutDateTime) < 0 then
			message = "Clock in after clock out"
		elseif verifyCycleUpdate(employeeID, employeeTimeID, clockInDateTime, clockOutDateTime) then
			updateCycle2 employeeTimeID, getClockInDateTime(), getClockOutDateTime(), request.form("wage"), request.querystring("note"), loggedInEmployeeID
		else
			message = "Times overlap."
		end if
	end function
	function addCycle()
		dim clockInDateTime
		dim clockOutDateTime

		clockInDateTime = getClockInDateTime()
		clockOutDateTime = getClockOutDateTime()
	
		if datediff("s", clockInDateTime, clockOutDateTime) < 0 then
			message = "Clock in after clock out"
		elseif verifyCycleUpdate(employeeID, employeeTimeID, clockInDateTime, clockOutDateTime) then
			addCycle2 employeeID, getClockInDateTime(), getClockOutDateTime(), request.form("wage"), loggedInEmployeeID, request.querystring("note")
		else
			message = "Times overlap."
		end if
	end function

	function getEmployeeHourlyWage(employeeid)
		dim query, rs
		
		query = "select isnull(hourlywage, 0) as hourlywage from employee where employeeid = " & employeeid
		set rs = getdisconnectedrecordset(query)
		
		getEmployeeHourlyWage = null
		
		if rs.recordcount > 0 then
			getEmployeeHourlyWage = rs("hourlywage")
		end if
		
		set rs = nothing
	end function
	
	function verifyCycleUpdate(employeeID, employeeTimeID, clockIn, clockOut)
		dim query, rs
		
		query = " select * from employeetime where "
		query = query & " employeeid = " & employeeid
		if employeeTimeID <> "" then
			query = query & " and employeetimeid <> " & employeeTimeID
		end if
		query = query & " and datediff(mi, '" & clockIn & "', clockout) > 0 " 
		query = query & " and not (clockout is null) "
		query = query & " and datediff(mi, clockin, '" & clockOut & "') > 0 "
		
		set rs = getdisconnectedrecordset(query)
		
		verifyCycleUpdate = (rs.recordcount = 0)
		
		set rs = nothing
	end function
	
	function deleteCycle(employeeTimeID)
    dim query, rs

    if employeeTimeID then
      query = " delete from employeetime where employeetimeid = " & employeeTimeID

      qryexecute query
    end if
	end function
	
	function updateCycle2(employeeTimeID, clockIn, clockOut, wage, note, employeeID)
		dim query, rs
		
		if employeeTimeID <> "" and clockIn <> "" then
			query = " update employeetime set clockin = " & DbCreateQryString(clockin)
			query = query & ", clockout = " & DbCreateQryString(clockOut)
			query = query & ", hourlyWage = " &  wage
			query = query & " where employeetimeid = " & employeeTimeID
			
			qryexecute query
			
			query = " insert into employeetimelog (logtype, employeetimeid, clockin, clockout, note, employeeID) "
			query = query & " values ('UP', " & employeeTimeID
			query = query & ", " & DbCreateQryString(clockin)
			query = query & ", " & DbCreateQryString(clockOut)
			query = query & ", " & DbCreateQryString(note)
			query = query & ", " & employeeID & ")"
			
			qryexecute query
			
		end if
	end function
	
	function getClockInDateTime()
		getClockInDateTime = request.form("clockInDate")
		getClockInDateTime = getClockInDateTime & " " & request.form("clockInHour")
		getClockInDateTime = getClockInDateTime & ":" & request.form("clockInMinute")
		getClockInDateTime = getClockInDateTime & " " & request.form("clockInHour12")
	end function
	
	function getClockOutDateTime()
		getClockOutDateTime = request.form("clockOutDate")
		getClockOutDateTime = getClockOutDateTime & " " & request.form("clockOutHour")
		getClockOutDateTime = getClockOutDateTime & ":" & request.form("clockOutMinute")
		getClockOutDateTime = getClockOutDateTime & " " & request.form("clockOutHour12")
	end function
	
	
	function addCycle2(employeeId, clockIn, clockOut, hourlyWage, loggedInEmployeeID, note)
	    dim query, rs
	
	    if clockIn <> "" then
			dbstartTrans()
			query = " insert into employeetime (employeeid, clockin, clockout, hourlyWage) "
			query = query & " values (" & employeeId
			query = query & ", " & DbCreateQryString(clockin)
			query = query & ", " & DbCreateQryString(clockOut)
			query = query & ", " & DbCreateQryNumeric(hourlyWage) & " )"
			
			qryexecutewithtrans query
			
			query = " insert into employeetimelog (logtype, employeetimeid, clockin, clockout, note, employeeid) "
			query = query & " values ('AD', @@identity "
			query = query & ", " & DbCreateQryString(clockin)
			query = query & ", " & DbCreateQryString(clockOut)
			query = query & ", " & DbCreateQryString(note)
			query = query & ", " & employeeID & ")"
			
			qryexecutewithtrans query
			dbendtrans()
	    end if
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	
	function addLeadingZeros(value, leadingZeros)
		value = CStr(value)
		
		while len(value) < leadingZeros
			value = "0" & value
		wend
		
		addLeadingZeros = value
	end function
	
	sub d_optionRange(minValue, maxValue, selValue, leadingZeros)
		dim index
		
		for index = minValue to maxValue
			Response.Write "<OPTION value=""" & index & """"
			if index = selValue then
				Response.Write " selected"
			end if
			Response.Write ">"
			Response.Write addLeadingZeros(index, leadingZeros)
			Response.Write "</OPTION>"
		next
	end sub
	
	function addLeadingZeros(value, leadingZeros)
		value = CStr(value)
		
		while len(value) < leadingZeros
			value = "0" & value
		wend
		
		addLeadingZeros = value
	end function

	sub d_optionRange(minValue, maxValue, selValue, leadingZeros)
		dim index
		
		for index = minValue to maxValue
			Response.Write "<OPTION value=""" & index & """"
			if index = selValue then
				Response.Write " selected"
			end if
			Response.Write ">"
			Response.Write addLeadingZeros(index, leadingZeros)
			Response.Write "</OPTION>"
		next
	end sub
	
	function getEmployeeName(employeeid)
		dim query, rs

		if employeeid <> "" then
			query = "select employeename from employee where employeeid = " & employeeid
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getEmployeeName = rs("employeename")
			end if
			
			set rs = nothing
		end if
	end function
%>
<HTML>
<HEAD>
<TITLE>Edit Employee Hours</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>


<script language="JavaScript" src="../script/webui.js"></script>
<script language="JavaScript" src="../script/date-picker2.js"></script>

<script language="javascript" type="text/javascript">
  function selectCycle(employeetimeid) {
    document.editEmpHours.action = "?useraction=selectcycle&employeetimeid=" + employeetimeid;
    document.editEmpHours.submit();
  }
	function selectDate(element) {
		show_calendar("editEmpHours." + element.name);
	}
	
	function newCycle() {
        document.editEmpHours.action = "?useraction=newcycle";
        document.editEmpHours.submit();
	}
	function updateCycle() {
		cbs_prompt("Enter reason for updating selected cycle:", handleUpdateCycle);
	}

	function handleUpdateCycle() {
        clearPromptMsg();
	    var note  = document.getElementById('inputTxtLine').value;
        if(note) {
          document.editEmpHours.action = "?useraction=updatecycle&note=" + encodeURIComponent(note);
          document.editEmpHours.submit();
        }
	}


	function addCycle() {
		cbs_prompt("Enter reason for adding cycle:", handleAddCycle);
	}

	function handleAddCycle() {
        clearPromptMsg();
	    var note  = document.getElementById('inputTxtLine').value;
	    if(note) {
		    document.editEmpHours.action = "?useraction=addcycle&note=" + encodeURIComponent(note);
		    document.editEmpHours.submit();
		}
	}

	function deleteCycle() {
        if(confirm("Delete selected cycle?")) {
          document.editEmpHours.action = "?useraction=deletecycle&employeetimeid=<%=employeeTimeID%>";
          document.editEmpHours.submit();
        }
	}

	function updateDateRange() {
    document.editEmpHours.action = "?useraction=update";
    document.editEmpHours.submit();
	}
	function exitForm() {
        document.editEmpHours.action = "employeeList.asp?userAction=editHours";
        document.editEmpHours.submit();
	}

	function displayMessage() {
	<% if message <> "" then %>
    cbs_alert("<%=message%>");
  <% end if %>
	}
	
	
	function formatAmount(element)
	{
		var temp = cleanNumeric(element.value)
		element.value = autoFormatCurrency(temp)
	}
</script>

<BODY topmargin=0 leftmargin=0 onLoad="displayMessage()">

<!-- #include file="../include/banner.inc" -->
<H1>Edit Hours For <%=Server.HTMLEncode(getEmployeeName(employeeID))%></H1>
<FORM id="editEmpHours" name="editEmpHours" action="" method="post" onsubmit="return false">

<INPUT type="hidden" value="<%=employeeTimeID%>" name="employeeTimeID" />
<INPUT type="hidden" value="<%=employeeID%>" name="employeeID" />

<TABLE>
  <TR>
    <TD>
      Date Start<BR />
      <INPUT style="width:80px;text-align:center" name="dateRangeStart" value="<%=dateRangeStart%>" onclick="selectDate(this);" />
    </TD>
    <TD>
      Date End<BR />
      <INPUT style="width:80px;text-align:center" name="dateRangeEnd" value="<%=dateRangeEnd%>" onclick="selectDate(this);" />
    </TD>
    <TD>
      <BR />
      <INPUT type="button" value="Update" onclick="updateDateRange()" />
    </TD>
  </TR>
</TABLE>

<TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
<TR valign="top" style="background:white" cellspacing="0" cellpadding="0" border="0">
<TD>
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin:0">
	<SPAN style="float:left">
    <BUTTON onclick="newCycle()" >New</BUTTON>
	</SPAN>
	
	<SPAN style="float:right;">

	</SPAN>
</DIV>
<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
<TR>
	<TH>Clocked In</TH>
	<TH>Clocked Out</TH>
</TR>
<%
	query = " select * from employeetime where employeeid = '" & employeeID & "'"

	if dateRangeStart <> "" then
		query = query & " and  datediff(d, clockin, '" & dateRangeStart & "') <= 0 "
	end if
	if dateRangeEnd <> "" then
		query = query & " and datediff(d, clockin, '" & dateRangeEnd & "') >= 0  "
	end if
	
	query = query & " order by clockin desc "
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
%>
<TR
<% if trim(rs("employeetimeid")) = trim(employeeTimeID) then %>
class="selected"
<% end if %>
onclick="selectCycle(<%=rs("employeetimeid")%>)">
	<TD align="center"><%=FormatDateTime(rs("clockin"))%></TD>
	<TD align="center">
<% if isnull(rs("clockout")) then %>
  Didn't Clock Out
<% else %>
  <%=FormatDateTime(rs("clockout"))%>
<% end if %>
  </TD>
</TR>

<%
		rs.movenext
	wend
	set rs = nothing
%>
</TABLE>
</TD>
<TD width="1%" style="border-left:1px solid #aaa">
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin:0">
	<SPAN style="float:left">
	
	<% if employeeTimeID <> "" then %>
    <BUTTON onclick="updateCycle()" >Update</BUTTON>
  <% else %>
    <BUTTON onclick="addCycle()" >Add</BUTTON>
  <% end if %>
  
    <BUTTON onclick="deleteCycle()" >Delete</BUTTON>
    
	</SPAN>
	
	<SPAN style="float:right;">
    <BUTTON onclick="exitForm()" >Exit</BUTTON>
	</SPAN>
</DIV>
<%
  dim cycleStartDate
  dim cycleEndDate
  dim cycleWage
  
	cycleStartDate = now()
	cycleEndDate = now()
	
  if employeeTimeID <> "" then
    query = " select *, isnull(clockout, clockin) as clockout, isnull(hourlywage, 0) as wage from employeetime where employeetimeid = " & employeeTimeID
    
    set rs = getdisconnectedrecordset(query)
    
    if rs.recordcount > 0 then
      cycleStartDate = rs("clockin")
      cycleEndDate = rs("clockout")
      cycleWage = rs("wage")
    end if
  else
  	cycleWage = getEmployeeHourlyWage(employeeID)
  
  end if
%>


<TABLE style="background:#ccc" border="0" cellpadding="5" width="250px">
  <TR>
    <TD colspan="2">
      <INPUT style="width:100%" value="Time Range" style="text-align:center" readonly />
    </TD>
  </TR>
  <TR>
    <TD>In</TD>
    <TD align="right">
      <INPUT name="clockInDate" value="<%=FormatDateTime(cycleStartDate, vbShortDate)%>" style="text-align:center" onclick="selectDate(this);" />
      
      <DIV>
        <SELECT name="clockInHour">
          <%d_optionRange 1, 12, (Hour(cycleStartDate) - 1) Mod 12 + 1, 2%>
        </SELECT>
        
        <SELECT name="clockInMinute">
          <%d_optionRange 0, 60, Minute(cycleStartDate), 2%>
        </SELECT>
        
        <SELECT name="clockInHour12">
          <OPTION value="AM" <%if Hour(cycleStartDate) < 12 then%>selected<%end if%>>AM</OPTION>
          <OPTION value="PM" <%if Hour(cycleStartDate) >= 12 then%>selected<%end if%>>PM</OPTION>
        </SELECT>
      </DIV>
    </TD>
  </TR>
  <TR>
    <TD>Out</TD>
    <TD align="right">
      <INPUT name="clockOutDate" value="<% =FormatDateTime(cycleEndDate, vbShortDate)%>" style="text-align:center" onclick="selectDate(this);" />
    
      <DIV>
        <SELECT name="clockOutHour">
          <%d_optionRange 1, 12, (Hour(cycleEndDate) - 1) Mod 12 + 1, 2%>
        </SELECT>
        
        <SELECT name="clockOutMinute">
          <%d_optionRange 0, 60, Minute(cycleEndDate), 2%>
        </SELECT>
        
        <SELECT name="clockOutHour12">
          <OPTION value="AM" <%if Hour(cycleEndDate) < 12 then%>selected<%end if%>>AM</OPTION>
          <OPTION value="PM" <%if Hour(cycleEndDate) >= 12 then%>selected<%end if%>>PM</OPTION>
        </SELECT>
      </DIV>
    </TD>
  </TR>
  <TR>
    <TD>Wage</TD>

    <TD align="right"><INPUT style="width: 60px; text-align: right" name="wage" value="<%=formatnumber(cycleWage, 2)%>" onkeyup="formatAmount(this)" /></TD>
  <TR>

  </TR>
</TABLE>
</TD>
</TR>
  <tr height=50px></tr>
  </table>
</FORM>
</BODY>
</HTML>
