<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/sha1.asp"-->
<%
	dim query, rs
	dim ticketnumber
	dim daystoinspect
	dim ticketcreateddate
	dim customersequencenumber

	const LOC_CUSTOMERFUNCTIONS = "/mainapp/customerfunctions.asp"
	const LOC_SEARCHRESULTS = "/mainapp/searchresults.asp"
	
	
	ticketnumber = getReqVar("ticketnumber")
	daystoinspect = getReqVar("daystoinspect")
	invoicenumber = getReqVar("invoicenumber")
	
	if ticketnumber = "" and invoicenumber <> "" then
		ticketnumber = convertInvoiceToTicketNumber(invoicenumber)
	end if
	
	if daystoinspect = "" then
		daystoinspect = "30"
	end if

	initializeWithTicketNumber ticketnumber

	function convertInvoiceToTicketNumber(invoicenumber)
		dim query, rs
		
		query = "select ticketnumber from ticket where invoicenumber = " & invoicenumber
		set rs = getdisconnectedrecordset(query)
		
		if not(rs.eof or rs.bof) then
			convertInvoiceToTicketNumber = rs("ticketnumber")
		end if
		
		set rs = nothing
	
	end function
	sub initializeWithTicketNumber(ticketnumber)
		dim query, rs
		
		if not isnull(ticketnumber) and ticketnumber <> "" then
			query = "select createddate, customersequencenumber from ticket where ticketnumber = " & ticketnumber
	
			set rs = getdisconnectedrecordset(query)
			
			ticketcreateddate = rs("createddate")
			customersequencenumber = rs("customersequencenumber")
		end if
	end sub
	
	function getBrightness(col)
		dim r, g, b
		
		r = clng("&H" & left(col, 2))
		g = clng("&H" & mid(col, 3, 2))
		b = clng("&H" & right(col, 2))

		getBrightness = 0.3 * r + 0.59 * g + 0.11 * b
	end function
	
	function fontContrastColor(col)
		if getBrightness(col) > 128 then
			fontContrastColor = "000000"
		else
			fontContrastColor = "ffffff"
		end if
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	
	function stringToHTMLColor(str)
		stringToHTMLColor = left(sha1(str), 6)
	end function

	function readTicketAction(ta)
		select case lcase(ta)
			case "c"
				readTicketAction = "Create"
			case "e"
				readTicketAction = "Edit"
			case "p"
				readTicketAction = "Pickup"
		end select
	end function
	
	function readAppLocation(al)
		readAppLocation = al
		
		select case lcase(al)
			case "/mainapp/searchresults.asp"
				readAppLocation = "Customer Search"
			
		end select
	end function

%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">

</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->

<INPUT type="hidden" name="ticketNumber" value="<%=ticketnumber%>">
<INPUT type="hidden" name="daystoinspect" value="<%=daystoinspect%>">

<%
	if customersequencenumber <> "" then
		query = "select customer.* from customer where customersequencenumber = " & customersequencenumber
		set rs = getdisconnectedrecordset(query)
%>

<div style="margin:5px;font-size:16;text-align:center">Customer Activity for <%=rs("customername")%> from <%=ticketcreateddate%> to <%=dateadd("d", daystoinspect, ticketcreateddate)%></div>
<%
		set rs = nothing
	end if
%>

<TABLE class="itable" cellpadding="0" cellspacing="0">


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		
	</SPAN>
	
	<SPAN style="float:right;">
		<BUTTON onclick="location.href='inventoryItem.asp'">Ok</BUTTON>
	</SPAN>
</DIV>

<TR>
	<TH>Employee</TH>
	<TH>Date</TH>	
	<TH align="left">Action</TH>
</TR>
<%

	if not isnull(ticketnumber) and ticketnumber <> "" then


	dim rsSecurityLog
	dim rsTicketLog
	dim color
	dim invcolor

	
	query = "select *, convert(varchar, date, 109) as longdate from securitylog where lower(location) = '" & LOC_CUSTOMERFUNCTIONS & "'"
	query = query & " and datediff(day, convert(datetime, '" & ticketcreateddate & "'), date) between 0 and " & daystoinspect
	query = query & " and customersequencenumber = " & customersequencenumber & " order by date asc"
	set rsSecurityLog = getdisconnectedrecordset(query)

	query = "select ticketlog.* from ticketlog inner join ticket on ticketlog.ticketnumber = ticket.ticketnumber "
	query = query & " where ticket.customersequencenumber = " & customersequencenumber
	query = query & " and datediff(day, convert(datetime, '" & ticketcreateddate & "'), ticketlog.logDate) between 0 and " & daystoinspect
	query = query & " order by ticketlog.logDate asc"
	set rsTicketLog = getdisconnectedrecordset(query)
	
	
	while not (rsSecurityLog.eof or rsSecurityLog.bof) or not (rsTicketLog.eof or rsTicketLog.bof)
	





		if not (rsSecurityLog.eof or rsSecurityLog.bof) then
		
		query = "select top 1 employee.employeename, securitylog.* from securitylog inner join employee on securitylog.employeeid = employee.employeeid "
		query = query & " where securitylog.date < convert(datetime, '" & rsSecurityLog("longdate") & "') "
		query = query & " and securitylog.employeeid = " & rsSecurityLog("employeeid")
		query = query & " order by securitylog.date desc"

		set rs = getdisconnectedrecordset(query)
		
		if lcase(rs("location")) = LOC_SEARCHRESULTS then
			color = stringToHTMLColor(rs("employeeid"))
			invcolor = fontContrastColor(color)

%>

	<TR>
		<TD style="background:#<%=color%>;color:<%=invcolor%>" align="center"><%=rs("employeename")%></TD>
		<TD align="center"><%=rsSecurityLog("date")%></TD>
		<TD><%="From " & readAppLocation(rs("location"))%></TD>
	</TR>
<%




		end if
			rsSecurityLog.movenext
		end if
		
		
		if not (rsTicketLog.eof or rsTicketLog.bof) then
			dim goahead
			
			goahead = (rsSecurityLog.eof or rsSecurityLog.bof)

			if not goahead then	goahead = datediff("s", rsTicketLog("logDate"), rsSecurityLog("date")) > 0
			
			while goahead
		
%>
	<TR>
		<TD></TD>
		<TD align="center"><%=rsTicketLog("logdate")%></TD>
		<TD><%=readTicketAction(rsTicketLog("logtype")) & " Invoice"%></TD>
	</TR>

<%


			
				rsTicketLog.movenext
				
				goahead = not(rsTicketLog.eof or rsTicketLog.bof)
				if goahead then
					goahead = (rsSecurityLog.eof or rsSecurityLog.bof)
					if not goahead then	goahead = datediff("s", rsTicketLog("logDate"), rsSecurityLog("date")) > 0
				end if

			wend
		end if
		
		
	wend
	
	
	set rsSecurityLog = nothing
	set rsTicketLog = nothing

	
%>
</TABLE>
<%
	end if
%>
</BODY>
</HTML>
