<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<%
	dim query, rs
	dim customerseq
	dim employeeid
	
	
	function getMessageServerURL()
		dim query, rs
		
		query = "select isnull(messageServerURL, '') as messageServerURL from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getMessageServerURL = trim(rs("messageServerURL"))
		
		set rs = nothing
	end function
	
	function getStoreGUID()
		dim query, rs
		
		query = "select guid from store where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getStoreGUID = rs("guid")
		
		set rs = nothing
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">
	function createNewTask() {
		var w = window.open("<%=getMessageServerURL()%>/MainApp/createtask.asp?storeguid=<%=getStoreGUID()%>&customerseq=<%=customerseq%>&employeeid=<%=employeeid%>", "Task", "status=no,fullscreen=no,scrollbars=no,width=500,height=500");
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="createNewTask()">New</BUTTON>
	</SPAN>
	
	<SPAN style="float:right">
	</SPAN>
</DIV>


<TABLE class="itable" cellspacing="0" cellpadding="0">

<TR>
	<TH>Date</TH>
	<TH>Status</TH>
	<TH>Description</TH>
</TR>
<%
	query = "select * from task where datediff(d, datecreated, getdate()) <= 30 or status = 0"
	set rs = getdisconnectedrecordset(query)

	while not(rs.eof or rs.bof)
%>
	<TR>
		<TD><%=rs("datecreated")%></TD>
		<TD><%=rs("status")%></TD>
		<TD><%=rs("description")%></TD>
	</TR>	

<%
		rs.movenext
	wend
	
	set rs = nothing
%>
</TABLE>

</BODY>
</HTML>
