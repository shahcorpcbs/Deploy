<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/EmployeeSecurity.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim isSubmitted 
	dim customerseq
	dim CreditID
	dim accnum
	Dim Creditexpr
	dim creditexpmonth
	dim creditexpyear

	dim l_storeid	
	isSubmitted = Request.QueryString("submitted")
	l_storeid = Session("storeid")
	customerseq = session("customersequencenumber")
	
	if (isSubmitted ) then
		UpdateDatabase()
	end if
		
	
	GetCustomerCreditInfo()
	
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Credit Card On File</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		if (validateForm() == true) {
			document.creditCardOnFileForm.action=document.creditCardOnFileForm.action + "?submitted=true"
			document.creditCardOnFileForm.submit();
			}
		}
	
	
	function checkRequiredFields() {
		
		if (document.creditCardOnFileForm.cardTypes.selectedIndex >  0 && 
			(trim(document.creditCardOnFileForm.txtAccountNumber.value).length == 0 ||
			trim(document.creditCardOnFileForm.txtExpMonth.value).length == 0 ||
			trim(document.creditCardOnFileForm.txtExpYear.value).length == 0))
		{
			cbs_alert("Please enter all the Required information");
			return false;
		}
		return true;	
	}
	
	
	function  validateForm(){
		var retval 
		retval = checkRequiredFields()
		
		if (retval == true){
			if (!checkInt(document.creditCardOnFileForm.txtAccountNumber.value)) {
				show_focus("Must enter all numbers.", "Credit Card Number", document.creditCardOnFileForm.txtAccountNumber);
				return false;
			}
			if (!checkMonth(document.creditCardOnFileForm.txtExpMonth.value)){
				show_focus("Enter valid month.", "Expiration Date", document.creditCardOnFileForm.txtExpMonth);
				return false;
			}
			if (!checkInt(document.creditCardOnFileForm.txtExpYear.value)){
				show_focus("Enter valid Year.", "Expiration Date", document.creditCardOnFileForm.txtExpYear);
				return false;
			}
		}
		return retval;
	}
	
	
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Credit Card on File</B>
<FORM id="creditCardOnFileForm" name="creditCardOnFileForm" action="" method="post">
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
			<tr height=50px></tr>
			<!-- types -->
			<TR>
				<TD class="label" align=right>Type</TD>
				<TD align=left>
					<SELECT name=cardTypes STYLE="font-size:14px;">
					<Option value = "0" >None</option>
					<%
						dim rsCreditTypes
						dim sqltxt 
						sqltxt = "select * from creditcardtypedomain where storeid = " & l_storeid
						set rsCreditTypes = getdisconnectedRecordset(sqltxt)
						while not rscreditTypes.eof
					%>	
					<OPTION 
					<% if (creditid = rsCreditTypes("creditcardTypeId"))then %>
						selected 
					<%End if %>
					VALUE= "<%= rsCreditTypes("creditcardTypeId") %>"><%=rsCreditTypes("Name") %>
					<%
						rsCreditTypes.movenext
						wend
						rsCreditTypes.close
						set rsCreditTypes = nothing
					%>
					</SELECT>
				</TD>
			</TR>
			<!-- account number -->
			<TR>
				<TD class="label" align=right>Account Number&nbsp;<b><font color=red>*</font></TD>
				<TD>
					<INPUT id=txtAccountNumber name=txtAccountNumber maxlength= 64 class=text style="HEIGHT: 25px; WIDTH: 250px"  value="<%=accnum%>">
				</TD>	
			</TR>
					
			<!-- Expiration month -->
			<TR>
				<TD class="label" align=right>Expiration Month&nbsp;<b><font color=red>*</font></TD>
				<TD	align=left>
					<INPUT id=txtexpMonth name=txtExpMonth maxlength = 2 class=text style="HEIGHT: 25px; WIDTH: 150px"  value="<%=creditexpmonth%>">
				</TD>
			</TR>	
		
			<!-- Expiration year -->
			<TR>
				<TD class="label" align=right>Expiration Year&nbsp;<b><font color=red>*</font></TD>
				<TD	align=left>
					<INPUT id=txtexpYear name=txtExpYear class=text	maxlength = 2 style="HEIGHT: 25px; WIDTH:	150px"  value="<%=creditexpyear%>">
				</TD>
			</TR>
			<!-- empty rows -->
			<TR height=20px></TR>
			<!-- buttons -->
			<TR>
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5>
					<tr>
						<td width=225px></td>
						<td align=center width=80px>
							<INPUT class=touchnoborder id=ok name=ok type=button value="" style="background-image:url(../images/OK.gif)" onClick="submitForm()">
						</td>
						<td>
							<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="history.go(-1);">
						</td>
					</tr>
				</table>
			</TR>     
	</TABLE>
</FORM>   

</BODY>
</HTML>
<%

	function getCustomerCreditInfo()
	dim rsCustomerInfo
	dim sqltxt
	
		sqltxt = "select CreditCardtypeid, CreditCardNumber,creditcardexpdate from customer where customersequencenumber = " & customerseq
			
			set rsCustomerinfo= GetDisconnectedRecordset(sqltxt)
			
			if rsCustomerinfo.recordcount > 0 then
				CreditID = rsCustomerInfo("CreditCardtypeid")
				accnum = checkfornull(rsCustomerInfo("CreditCardNumber"))
				Creditexpr = checkfornull(rsCustomerInfo("creditcardexpdate"))
				creditexpmonth= left(creditexpr,2)
				creditexpyear= right(creditexpr,2)
			end if
			
			rsCustomerInfo.Close()
			
			set rscustomerinfo= nothing
		
	end function

	function updateDatabase()
	dim l_creditId
	dim l_accNumber
	dim l_accLimit
	dim  l_expmonth
	dim  l_expyear
	dim l_expdate
	dim sqltxt
		
		customerseq = session("Customersequencenumber")
		l_creditId = Request.form("cardTypes")
		l_accnumber= Request.form("txtAccountNumber")
		l_expmonth = Request.form("txtexpMonth")
		l_expyear = Request.form("txtexpYear")	
		if l_creditId < 1 then
			l_creditId = ""
			l_expdate = ""
			l_accnumber = ""
		else
			if len(trim(l_expmonth)) < 2 then
				l_expmonth = "0" & l_expmonth
			end if 
			
			if len(trim(l_expyear)) < 2 then
				l_expyear = "0" & l_expyear
			end if 
			l_expdate = l_expmonth & l_expyear
		end if
		
		sqltxt = "update customer set " _
            & "creditcardtypeid = " & dbcreateQrynumeric(l_creditId) _
            & ",creditcardnumber = "  & dbcreateQrystring(l_accnumber)  _
            & ",creditcardexpdate= " & dbcreateQrystring(l_expdate) _
            & " where customersequencenumber = " & customerseq
        ' Response.Write sqltxt
        dbstartTrans()
		QryExecutewithtrans(sqltxt)
		dbEndTrans()
		Response.redirect("CustomerEntry.asp?mode=edit")
	
	end function

%>