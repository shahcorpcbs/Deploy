<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 900 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
    dim query, rs
    dim customerSeq, phoneNumber, contactPref
    dim notificationIP
    dim blacklisted, twilioNum

    customerSeq = getReqVar("customerSeq")
    phoneNumber = getReqVar("phoneNumber")

    notificationIP = getMessengerShortPath()


    if customerSeq <> "" then
        query = "select contactPref, twilioBlackList from customer where customerSequenceNumber = " & customerSeq
        set rs = getdisconnectedrecordset(query)
        contactPref = rs("contactPref")
        blacklisted = rs("twilioBlackList")

        if blacklisted then
            twilioNum = getMSVar("twilioFromNumber")
        end if
    end if


    query = "select id, message, description, smsOnly from SmsMessage where message is not null and description != 'Reserved'"
    set rs = getdisconnectedrecordset(query)


	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function
%>

<HTML>
<HEAD>
<TITLE>Send SMS Message</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<FORM id="sendSMS" name="sendSMS" action="" method="post">
<script language="javascript" type="text/javascript" src="/Script/webui.js"> </script>
<script type="text/javascript" src="../external/jquery-3.4.1.js"></script>
<script language="javascript" type="text/javascript">

	function init() {
	     $("#twilioNum").text(formatPhoneNumber(<%=twilioNum%>));
	}

    function formatPhoneNumber(phoneNumberString) {
      var cleaned = ('' + phoneNumberString).replace(/\D/g, '');
      var match = cleaned.match(/^(1|)?(\d{3})(\d{3})(\d{4})$/);
      if (match) {
        var intlCode = (match[1] ? '+1 ' : '');
        return ['(', match[2], ') ', match[3], '-', match[4]].join('');
      }
      return null;
    }

    function disableNew() {
        document.sendSMS.newMessage.disabled = true;
        document.sendSMS.storedId.disabled = false;
        document.sendSMS.savedMessage.disabled = false;
    }
    function disableStored() {
        document.sendSMS.newMessage.disabled = false;
        document.sendSMS.storedId.disabled = true;
        document.sendSMS.savedMessage.disabled = true;
    }
    function loadMessage(message) {
        document.getElementById('savedMessage').value = unescape(message);
    }
    function submitForm() {
            var loc = window.location.href;
            var extraCut = 0;
            if (loc.indexOf(":80") != -1)
                extraCut = 5;
            var endStop = loc.indexOf("/mainapp")
            if (endStop == -1)
                endStop = loc.indexOf("/MainApp")

            endStop = endStop - extraCut;
            var ipAddress = loc.substring(0, endStop);

        var url = ipAddress + "<%=notificationIP%>/sendIndividualMessage?customerSeq=<%=customerseq%>&phone=<%=phoneNumber%>&";
        if($('input[name=messageType]:checked').val() === "New") {
            var newMessage = $.trim(document.getElementById('newMessage').value);
            if (newMessage === "") {
                cbs_alert("Cannot send blank message");
                return;
            }
            url += "message=" + encodeURIComponent(newMessage);
        }
        else {
            if (document.getElementById('storedId').value === "0") {
                cbs_alert("Must select a message to send");
                return;
            }
            url += "messageId=" + document.getElementById('storedId').value;
        }
        url += "&employeeId=" + encodeURIComponent(<%=session("employeeID")%>);
        //alert(url);

        try {
            $.ajax({
                type: "POST",
                url: url,
                dataType: "text",
                timeout: "3000",
                success: function(xhr) {
                    cbs_alert("Text Message Sent");
                    window.close();
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    cbs_alert("Unable to connect to CBS Messaging Service\nMake sure service is running");
                    //console.log(xhr);
                    //console.log(ajaxOptions);
                    //console.log(thrownError);
                    window.close();
                }
            });
        } catch (exception) {
            cbs_alert("Unable to send - " + exception.message);
        }
    }
</script>

<BODY topmargin=0 leftmargin=0 onload="init()">
<INPUT type="hidden" name="customerseq" value="<%=customerseq%>" />
<DIV id="statement_container">
<% if contactPref = 2 then %>
    <h6>Note: This customer prefers to get messages via email</h6>
<% end if %>
<% if blacklisted then %>
    <h6>Note: This customer is unsubscribed. Sms will be attempted but likely will be blocked.
    <br />If customer wishes to start receiving sms messages again, have them text 'start'<br />to <span id="twilioNum"></span></h6>
<% end if %>
<br />
<Input type=radio name=messageType value="New" onclick="disableStored()" checked>New Message
<br />
<textarea id="newMessage" cols="50" rows="10" ></textarea>
<br /><br />
<Input type=radio name=messageType value="Stored" onclick="disableNew()">Canned Messages
<br />
<select id="storedId" disabled onchange="if(this.options[this.selectedIndex].onclick != null){this.options[this.selectedIndex].onclick(this);}">
<option value="0"></option>
<% while not rs.eof %>
    <% if isnull(rs("smsOnly")) then %>
        <option value="<%=rs("id") %>" onclick="loadMessage('<%=escape(rs("message"))%>')" ><%=rs("description")%></option>
    <% else %>
        <option value="<%=rs("id") %>" onclick="loadMessage('<%=escape(rs("message"))%> <%=escape(rs("smsOnly"))%>')" ><%=rs("description")%>" </option>
    <% end if %>
<%
	rs.movenext
	wend
	set rs = nothing
%>
</select>
<br />
<textarea id="savedMessage" name="savedMessage" readonly disabled cols="50" rows="10"></textarea>

</DIV>
<table ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR>
			<TD colspan="2" align=center>
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/OK.gif)" onClick= "submitForm()">
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onclick="window.close()">
			</TD>
		</TR>
</table>

<div style="border: 1px solid;   position: absolute;
                                                top: 8px;
                                                right: 60px;">
  <span style="font-size: 14px;"><b>Keyword Variables</b></span><br /><br />
  {storename}<br />{customername}<br />{firstname}<br />{lastname}
  <br /><br />
  <span style="font-size: 10px">Message text with these variables<br />will be replaced with the logical<br />values when sending message</span>
</div>

</BODY>
</FORM>
</HTML>

