<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/processor.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim batchid
	dim ccprocessor
	dim errorMsg
	dim hasrefreshed
	dim totalOfAccounts
	dim targetpage
	dim deliveryid
	dim use_clearent, notificationIP


	targetpage = getReqVar("targetpage")
	deliveryid = getReqVar("deliveryid")

	errorMsg = ""

	set ccprocessor = Server.CreateObject("ShahcorpComponents.creditCardProcessing")

	ccprocessor.DBConnectionString = Session("shahcorpDSN")
	ccprocessor.XChargeDirectory = getMSVar("XChargePath")
	if isobject(getMSVar("XChargePathKeyed")) then
		ccprocessor.XChargeDirectoryKeyed = getMSVar("XChargePathKeyed")
	end if
	ccprocessor.XChargeTimeout = 120

    determineIfClearent

	batchid = getReqVar("batchid")
	hasrefreshed = getReqVar("hasrefreshed")
	if trim(batchid) = "" then batchid = getLastBatchID()
	if trim(hasrefreshed) = "" then hasrefreshed = false

    if use_clearent then
        notificationIP = getClearentShortPath()
    else
	    ccprocessor.UpdateBatchGroup batchid
	end if


	select case lcase(Request.QueryString("useraction"))
	case "closebatch"
		closeBatch
	case "refresh"
		hasrefreshed = "1"
	end select

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	function getLastBatchID()
		dim query, rs

		query = "select isnull(max(batchid), 0) as maxbatchid from paymentbatch"
		set rs = getdisconnectedrecordset(query)

		getLastBatchID = rs("maxbatchid")

		set rs = nothing
	end function

	sub closeBatch()
	    dim query, rs, date

		if Request.Form("stg_waiting") > 0 then
			errorMsg = "Error: Can not close batch while some accounts are still in the <span style=""background:yellow"">Waiting</span> stage."

			exit sub
		end if

		if Request.Form("stg_missing") > 0 then
			errorMsg = "Warning: Some accounts may be in the <span style=""background:orange"">Request Missing</span> stage."
			errorMsg = errorMsg & "  These accounts have been <span style=""background:gray;color:white"">Cancelled</span> from this batch and will have to be billed by creating a new batch."
		end if

		ccprocessor.closeBatchGroup batchid, Session("storeid"), Session("terminalid"), Session("employeeid")

		promoteDeliveryStatus batchid
		setEffectiveDate batchid

	end sub

	function setEffectiveDate(batchid)
	    dim query, processDate
	    processDate = getReqVar("processDate")

		if batchid <> "" then

			query = "update generalLedger set createdDate = '" & processDate & "' where refNumber in (select pnum from ( "
            query = query & " select max(paymentNumber) as pnum, p.customerSequenceNumber from payment p, paymentBatch pb where pb.BatchID = " & batchid
            query = query & " and pb.CustomerSequenceNumber = p.customerSequenceNumber and pb.TransactionAmount = (p.amountPaid) "
            query = query & " and pb.Stage = 0 group by p.customerSequenceNumber) t)"

			qryexecute query
		end if

	end function

	function promoteDeliveryStatus(batchid)
		dim query, rs

		if batchid <> "" then
			query = "select max(deliveryid) as deliveryid from delivery where paymentbatchid = " & batchid
			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				setDeliveryStatus rs("deliveryid"), 4
			end if

			query = " update deliverypayment set deliverypayment.status = case paymentbatch.stage when 0 then 10 else paymentbatch.stage + (10 * sign(paymentbatch.stage)) end "
			query = query & " from deliverypayment inner join deliverystop on "
			query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
			query = query & " inner join paymentbatch on "
			query = query & " deliverypayment.batchid = paymentbatch.batchid and deliverystop.customersequencenumber = paymentbatch.customersequencenumber "
			query = query & " where deliverypayment.batchid = " &  batchid
			qryexecute query

		end if


	end function

	function setDeliveryStatus(deliveryid, status)
		dim query

		if deliveryid <> "" then
			query = " update delivery set status = " & status
			query = query & " where deliveryid = " & deliveryid

			qryexecute query
		end if
	end function


	sub w_statusIcon(stage)
		select case stage
			case -3
				Response.Write "<div style=""padding-top:7px;height=28px;text-align:center;width:100%;background:gray;color:white"">Cancelled</div>"
			case -2
				Response.Write "<div style=""padding-top:7px;height=28px;text-align:center;width:100%;background:red;color:white"">Error Processing</div>"
			case -1
				Response.Write "<div style=""padding-top:7px;height=28px;text-align:center;width:100%;background:red;color:white"">No Answer</div>"
			case 0
				Response.Write "<div style=""padding-top:7px;height=28px;text-align:center;width:100%;background:green;color:white"">Account Updated</div>"
			case 1
				Response.Write "<div style=""padding-top:7px;height=28px;text-align:center;width:100%;background:yellow"">Waiting</div>"
			case 2
				Response.Write "<div style=""padding-top:7px;height=28px;text-align:center;width:100%;background:orange"">Request Missing</div>"
			case 3
				Response.Write "<div style=""padding-top:7px;height=28px;text-align:center;width:100%;background:lightgreen"">Card Billed</div>"
			case default
				Response.Write "<div style=""padding-top:7px;height=28px;text-align:center;width:100%;background:gray"">Other</div>"
		end select
	end sub

	function getAccountsAtStage(stg)
		dim query, rs

		query = "select count(*) as cnt from paymentbatch where batchid = " & batchid & " and stage = " & stg
		set rs = getdisconnectedrecordset(query)

		getAccountsAtStage = rs("cnt")

		set rs = nothing
	end function

	function getAccountsValueAtStage(stg)
		dim query, rs

		query = "select isnull(sum(transactionamount), 0) as cnt from paymentbatch where batchid = " & batchid & " and stage = " & stg
		set rs = getdisconnectedrecordset(query)

		getAccountsValueAtStage = rs("cnt")

		set rs = nothing
	end function

	function getDateRan()
		dim query, rs

		query = "select min(DateInitiated) as dateinitiated from paymentbatch where batchid = " & batchid
		set rs = getdisconnectedrecordset(query)

		getDateRan = rs("dateinitiated")

		set rs = nothing
	end function

	function isFiltered(stg)
		dim allowedstages
		dim allowedstage

		isFiltered = true

		if hasrefreshed = "1" then
			set allowedstages = Request.Form("allowed_stg")

			for each allowedstage in allowedstages

				if trim(stg) = trim(allowedstage) then
					isFiltered = false
					exit function
				end if
			next

		else
			isFiltered = false
			exit function
		end if

	end function

	function getAllowedStagesCVS()
		dim allowedstages
		dim allowedstage

		set allowedstages = Request.Form("allowed_stg")

		getAllowedStagesCVS = ""

		for each allowedstage in allowedstages
			if getAllowedStagesCVS <> "" then
				getAllowedStagesCVS = getAllowedStagesCVS & ","
			end if

			getAllowedStagesCVS = getAllowedStagesCVS & allowedstage
		next
	end function

	function isDeliveryBatchOpen(batchid, deliveryid)
		dim query, rs

		query = " select deliverypaymentid from deliverypayment "
		query = query & " inner join deliverystop on deliverypayment.deliverystopid = deliverystop.deliverystopid "
		query = query & " inner join delivery on deliverystop.deliveryid = delivery.deliveryid "
		query = query & " where delivery.deliveryid = " & deliveryid
		query = query & " and deliverypayment.batchid = " & batchid
		query = query & " and deliverypayment.status in (1, 2, 11, 12, 13) " ' what a mess

		set rs = getdisconnectedrecordset(query)

		isDeliveryBatchOpen = rs.recordcount > 0
	end function

	function isBatchOpen(batchid)
		dim query, rs

		if deliveryid <> "" then
			if isDeliveryBatchOpen(batchid, deliveryid) then
				isBatchOpen = true
				exit function
			end if
		end if

		query = " select max(stage) as maxstage from paymentbatch where batchid = " & batchid
		set rs = getdisconnectedrecordset(query)

		isBatchOpen = false
		if rs.recordcount > 0 then
			isBatchOpen = rs("maxstage") > 0
		end if

		set rs = nothing
	end function
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Credit Card Batch Status</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script type="text/javascript" src="../Script/clearent.js"></script>
<script type="text/javascript" src="../Script/json2.js"></script>
<script language="javascript" type="text/javascript">


	function CCTransaction(ticketNumbers,ccAuthCode,ccExpDate,ccType,ccAcctNum,ccCardHolder,ccTotal) {
		this.ticketNumbers = ticketNumbers;
		this.ccAuthCode = ccAuthCode;
		this.ccExpDate = ccExpDate;
		this.ccType = ccType;
		this.ccAcctNum = ccAcctNum;
		this.ccCardHolder = ccCardHolder;
		this.ccTotal = ccTotal;
	}

	function printCCTransactions() {
		var transactions;
		var idx;

		transactions = getCompletedCCTransactions();

		for(idx = 0; idx < transactions.length; idx++) {
		/*	alert(transactions[idx].ticketNumbers + "," +
			transactions[idx].ccAuthCode + "," +
			transactions[idx].ccExpDate + "," +
			transactions[idx].ccType + "," +
			transactions[idx].ccAcctNum + "," +
			transactions[idx].ccCardHolder + "," +
			transactions[idx].ccTotal + "," +
			transactions[idx].ticketNumbers

			);
			*/
			PrintCreditReceipt(
			transactions[idx].ticketNumbers,
			transactions[idx].ccAuthCode,
			transactions[idx].ccExpDate,
			transactions[idx].ccType,
			transactions[idx].ccAcctNum,
			transactions[idx].ccCardHolder,
			transactions[idx].ccTotal);
		}
	}

	function getCompletedCCTransactions() {
		var result;
		var counter;

		counter = 0;
<%

	query = "select * from paymentbatch where stage in (3, 0) and batchid = " & batchid
	query = query & " order by stage, customername"

	set rs = getdisconnectedrecordset(query)
%>
		result = new Array(<%=rs.recordcount%>);
<%
	while not(rs.eof or rs.bof)
%>
		result[counter++] = new CCTransaction('<%=rs("customersequencenumber")%>', '<%=rs("answer")%>', '<%=rs("expirationdate")%>', '0', '<%=rs("accountnumber")%>', '<%=replace(rs("customername"), "'", """")%>', '<%=rs("transactionamount")%>');
<%
		rs.movenext
	wend
	set rs = nothing
%>
		return result;
	}

	function closeBatch() {
	    var processDate = document.getElementById("ProcessDateBox").value;
		document.creditCardBatchStatus.action = "?useraction=closebatch&processDate=" + encodeURIComponent(processDate);
		document.creditCardBatchStatus.submit();
	}

	function exitForm() {
<%
	if deliveryid <> "" then
%>
		document.creditCardBatchStatus.action = "/mainapp/deliveryCCBatch.asp?deliveryid=<%=deliveryid%>";
		document.creditCardBatchStatus.submit();
<%
	else
%>
		document.creditCardBatchStatus.action = "/mainapp/creditCardBatchList.asp";
		document.creditCardBatchStatus.submit();
<%
	end if
%>
	}

	function refreshForm() {
	    clearAlertMsg();
		document.creditCardBatchStatus.action = "?userAction=refresh";
		document.creditCardBatchStatus.submit();
	}

    function process() {
        <% if (lcase(Request.QueryString("useraction")) = "clearentbatch") then %>
            batchProcessing(<%=batchId%>, "<%=notificationIP%>");
    	<% end if %>

        setProcessDates();
    }

	function setProcessDates() {
	    var today = new Date();
	    var options = [
          {
            "text"  : formatDate(new Date()),
            "value" : formatDate(new Date()),
            selected: true
          },
          {
            "text"     : formatDate(new Date(today.setDate(today.getDate() - 1))),
            "value"    : formatDate(today)
          },
          {
            "text"     : formatDate(new Date(today.setDate(today.getDate() - 1))),
            "value"    : formatDate(today)
          },
          {
            "text"     : formatDate(new Date(today.setDate(today.getDate() - 1))),
            "value"    : formatDate(today)
          },
          {
            "text"     : formatDate(new Date(today.setDate(today.getDate() - 1))),
            "value"    : formatDate(today)
          },
          {
            "text"     : formatDate(new Date(today.setDate(today.getDate() - 1))),
            "value"    : formatDate(today)
          },
          {
            "text"     : formatDate(new Date(today.setDate(today.getDate() - 1))),
            "value"    : formatDate(today)
          },
          {
            "text"     : formatDate(new Date(today.setDate(today.getDate() - 1))),
            "value"    : formatDate(today)
          }
        ];

	    var selectBox = document.getElementById('ProcessDateBox');
	    for(var i = 0, l = options.length; i < l; i++){
          var option = options[i];
          selectBox.options.add( new Option(option.text, option.value, option.selected) );
        }
	}

    function formatDate(date) {
        var year = date.getFullYear().toString();
        var month = (date.getMonth() + 101).toString().substring(1);
        var day = (date.getDate() + 100).toString().substring(1);
        return  month + "/" + day + "/" + year;
    }

    function showSpinner() {
        document.getElementById("progress").style.display = "inline";
    }

    function hideSpinner() {
        document.getElementById("progress").style.display = "none";
    }

</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="process();">

<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/localprinter.inc" -->
<DIV id="progress" style="text-align:center;display:none;position:absolute; left: 25%; top: 50%; font-size: 35px; ">

Running batch. You may close or leave this page - process will continue<BR />
<IMG  src="/Images/waiting.gif" alt="" style="height: 75px"/>
<BR /><BR /><BR /><BR /><BR />
</DIV>


<table width="100%">
<tr>
<td align="left">Credit Card Batch</td>
<td align="right">Date Initiated: <%=getDateRan()%></td>
</tr>
</table>

<FORM id="creditCardBatchStatus" name="creditCardBatchStatus" action="creditCardBatchStatus.asp" method="post">



<INPUT name="batchid" type="hidden" value="<%=batchid%>">
<INPUT name="hasrefreshed" type="hidden" value="<%=hasrefreshed%>">
<INPUT name="targetpage" type="hidden" value="<%=targetpage%>">
<INPUT name="deliveryid" type="hidden" value="<%=deliveryid%>">






<table align="center" cellspacing=1 cellpadding=0 style="margin-bottom:12px;" >
<tr>
	<td style="background:yellow"><input name="allowed_stg" type="checkbox" value="1" <%if not isFiltered(1) then%>checked<%end if%>><span style="text-align:center;width:100px;background:yellow">Waiting</span></td>
	<td style="background:orange"><input name="allowed_stg" type="checkbox" value="2" <%if not isFiltered(2) then%>checked<%end if%>><span style="text-align:center;width:100px;background:orange">Request Missing</span></td>
	<td style="background:lightgreen"><input name="allowed_stg" type="checkbox" value="3" <%if not isFiltered(3) then%>checked<%end if%>><span style="text-align:center;width:100px;background:lightgreen">Card Billed</span></td>
	<td style="background:green;color:white"><input name="allowed_stg" type="checkbox" value="0" <%if not isFiltered(0) then%>checked<%end if%>><span style="text-align:center;width:100px;background:green;color:white">Account Updated</span></td>
	<td width="10px"></td>
	<td style="background:gray;color:white"><input name="allowed_stg" type="checkbox" value="-3" <%if not isFiltered(-3) then%>checked<%end if%>><span style="text-align:center;width:100px;background:gray;color:white">Cancelled</span></td>
	<td style="background:red;color:white"><input name="allowed_stg" type="checkbox" value="-2" <%if not isFiltered(-2) then%>checked<%end if%>><span style="text-align:center;width:100px;background:red;color:white">Error Processing</span></td>
	<td style="background:red;color:white"><input name="allowed_stg" type="checkbox" value="-1" <%if not isFiltered(-1) then%>checked<%end if%>><span style="text-align:center;width:100px;background:red;color:white">No Answer</span></td>

</tr>

<tr>
	<td><input name="stg_waiting" readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=getAccountsAtStage(1)%>"></input></td>
	<td><input name="stg_missing" readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=getAccountsAtStage(2)%>"></input></td>
	<td><input name="stg_billed" readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=getAccountsAtStage(3)%>"></input></td>
	<td><input name="stg_credited" readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=getAccountsAtStage(0)%>"></input></td>
	<td width="10px"></td>
	<td><input name="stg_cancelled" readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=getAccountsAtStage(-3)%>"></input></td>
	<td><input name="stg_error" readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=getAccountsAtStage(-2)%>"></input></td>
	<td><input name="stg_noanswer" readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=getAccountsAtStage(-1)%>"></input></td>
</tr>

<tr>
	<td><input readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=formatcurrency(getAccountsValueAtStage(1))%>"></input></td>
	<td><input readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=formatcurrency(getAccountsValueAtStage(2))%>"></input></td>
	<td><input readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=formatcurrency(getAccountsValueAtStage(3))%>"></input></td>
	<td><input readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=formatcurrency(getAccountsValueAtStage(0))%>"></input></td>
	<td width="10px"></td>
	<td><input readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=formatcurrency(getAccountsValueAtStage(-3))%>"></input></td>
	<td><input readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=formatcurrency(getAccountsValueAtStage(-2))%>"></input></td>
	<td><input readonly style="border:none;width:100%;text-align:center;font-weight:bold;" value="<%=formatcurrency(getAccountsValueAtStage(-1))%>"></input></td>
</tr>

</table>

<% if errorMsg <> "" then %>
<div style="border:3px dashed red;padding:5px;margin:5px;text-align:center;font-size:16;font-weight:bold">
<%=errorMsg%>
</div>
<% end if %>

<table>
<tr>
<td align="left">Process Date</td>
<td align="left"><select id="ProcessDateBox"></select></td>
</tr>
</table>
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
    <BUTTON onclick="refreshForm()">Refresh</BUTTON>
    <BUTTON style="vertical-align: top" onclick="printCCTransactions()">Print<BR />Forms</BUTTON>
    <BUTTON style="vertical-align: top" onclick="closeBatch()" <%if not isBatchOpen(batchid) then%>disabled<%end if%>>Close<BR />Batch</BUTTON>

	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="exitForm()">Exit</BUTTON>
	</SPAN>
</DIV>


<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="text-align:left" >
		<TH>&nbsp;</TH>
		<TH align="center">Status</TH>
		<TH>&nbsp;</TH>
		<TH>Customer Name</TH>
		<TH>Message</TH>
		<TH>Amount</TH>
	</TR>
<%

	totalOfAccounts = 0


	if hasrefreshed then
		if getAllowedStagesCVS() <> "" then
			query = "select paymentbatch.*, customer.customername as fullname from paymentbatch "
			query = query & " inner join customer on paymentbatch.customersequencenumber = customer.customersequencenumber "
			query = query & " where paymentbatch.batchid = " & batchid & " and paymentbatch.stage in (" & getAllowedStagesCVS() & ") order by paymentbatch.stage, customer.customername"
		else
			query = "select *, '' as fullname from paymentbatch where batchid = -1"
		end if
	else
			query = "select paymentbatch.*, customer.customername as fullname from paymentbatch "
			query = query & " inner join customer on paymentbatch.customersequencenumber = customer.customersequencenumber "
			query = query & " where paymentbatch.batchid = " & batchid
	end if


	set rs = getdisconnectedrecordset(query)


	while not(rs.eof or rs.bof)
%>
	<TR style="height:30px;">
		<TD style="width:10px">&nbsp;</TD>
		<TD style="width:150px"><%w_statusIcon rs("stage")%></TD>
		<TD style="width:20px">&nbsp;</TD>
		<TD><A HREF="/mainapp/customerfunctions.asp?customerseq=<%=rs("customersequencenumber")%>"><%=rs("fullname")%></A></TD>
		<TD><%=rs("answer")%></TD>
		<TD><%=formatcurrency(rs("transactionamount"))%></TD>
	</TR>
<%

		totalOfAccounts = totalOfAccounts + rs("transactionamount")

		rs.movenext
	wend

	set rs = nothing
%>

	<TR style="height:30px;">

	<TD colspan=5><B>Total</B></TD>
	<TD><%=formatcurrency(totalOfAccounts)%></TD>
	</TR>

</TABLE>


</FORM>
</BODY>
</HTML>
