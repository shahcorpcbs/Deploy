<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	'***********************************************************************
	'Name   :Add Tag Numbers
    'Author : Poonam Gupta
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 01-Jul-2002    Poonam			Original Version
    ' 11-Nov-2003	 MWiemann	    Modified tag color buttons to appear in
    '                               color rather than have an image of a color.
    '                               Also added department and piece info,
	'								due date, finish & starch pref
    '                               from detailed invoice
    '***********************************************************************
	
	dim addOrEdit
	dim invoiceCounter
	dim invoice
	dim invoiceNumber
	dim actionString
	dim messageToShow
	dim originatingPage
	dim duedate
	dim duedateDay
	dim finishpref
	dim starchpref
	dim enableLotTags
	dim query
	dim rs
	
	enableLotTags = isLotTagsEnabled()
	
	actionString = Request.QueryString("userAction")
	addOrEdit = Request.QueryString("addOrEdit")
	originatingPage = Request.QueryString("originPage")
	invoiceCounter = Request.Form("invoiceCounter")
	set invoice = Session("invoice")
	duedate = invoice.getDeptDueDate("")
	duedateDay = WeekdayName(Weekday(duedate))
	finishpref = invoice.finishpref
	starchpref = invoice.starchpref
	if IsEmpty(invoiceCounter) then
		invoiceCounter = 0
		invoiceNumber = invoice.invoiceNo
	end if 
	select case actionString 
			case "submit"
					addTagNumbers
	end select
	
	function getCurrentInvoice()

		if invoiceCounter = 0 and invoice.isInvoiceEmpty() and Not invoice.invoicesDictionary is nothing then
			invoiceCounter = 1
		end if

		if invoiceCounter = 0 then
			set getCurrentInvoice = invoice
		else
			set getCurrentInvoice = invoice.invoicesDictionary.Item(invoiceCounter)
		end if
	end function
	
	function isLotTagsEnabled()
		dim query, rs
		
		query = " select enablelottags from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			isLotTagsEnabled = rs("enablelottags")
		end if
		
		set rs = nothing
	end function
	
	sub addTagNumbers()
		dim ticketTags
		dim counter
		dim tagNumber
		dim tagInfo
		dim tagColor
		dim tagArray
		dim ticketTag
		dim aInvoice
		dim addMoreTags
		dim lotNumber
		
		invoiceCounter = clng(invoiceCounter)
		addMoreTags =false
		addOrEdit = Request.Form("addOrEdit")
		originatingPage = Request.Form("originPage")
		Set ticketTags = Server.CreateObject("Scripting.Dictionary")
		for counter =1 to Request.Form("tagNumbersList").Count
			tagInfo = Request.Form("tagNumbersList")(counter)
			tagArray = Split(tagInfo,"|||")
			tagNumber = tagArray(0)
			tagColor = tagArray(1)
			lotNumber = tagArray(2)
			
			Set ticketTag = Server.CreateObject("ShahCorpComponents.TicketTag")
			
			ticketTag.TagNumber = tagNumber
			ticketTag.TagColor = tagColor
			ticketTag.LotNumber = lotNumber
			
			ticketTags.Add tagNumber, ticketTag
		next

		if invoiceCounter = 0 and invoice.isInvoiceEmpty() and Not invoice.invoicesDictionary is nothing then
			invoiceCounter = 1
		end if

		if invoiceCounter = 0 then
			set invoice.ticketTags = ticketTags
		else
			set aInvoice = invoice.invoicesDictionary.Item(invoiceCounter)
			set aInvoice.ticketTags = ticketTags
		end if
		if Not invoice.invoicesDictionary is nothing then
			invoiceCounter = invoiceCounter +1
			if invoiceCounter <= invoice.invoicesDictionary.Count then
				addMoreTags =true
				set aInvoice = invoice.invoicesDictionary.Item(invoiceCounter)
				invoiceNumber = aInvoice.invoiceNo
			end if
		end if
		if not addMoreTags then
			Response.Redirect "detailedInvoice.asp?userAction=fromTagAllocation&button=ok&addOrEdit="	& addOrEdit	& "&originPage=" & originatingPage	
		end if
		
	end sub
			
	function getExistingTagsForTicket()
		dim ticketNo
		dim ssql
			
		ticketNo = invoice.ticketNo
		ssql = "SELECT tagNumber, tagColor, lotNumber FROM TicketTag Where ticketNumber=" & CLng(ticketNo)
		set getExistingTagsForTicket = getDisconnectedRecordset(ssql)
	end function
	
%>
<HTML>
<HEAD>
<TITLE>Detailed Invoice</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	
	function addTagNoToList(tagColor){

		
	<% if enableLotTags then %>
	
		document.addTagNumber.txtTagNumber.focus();
		document.addTagNumber.txtTagNumber.select();
		
		var lotNo = parseInt(document.addTagNumber.txtLotNumber.value);
		var tagNo = parseInt(document.addTagNumber.txtTagNumber.value);
		var tagNoEnd = parseInt(document.addTagNumber.txtTagNumberEnd.value);
		var idx;

		
		if(tagNoEnd < tagNo) {
			cbs_alert("Tag range not valid " + tagNoEnd + "<" + tagNo);
			return false;
		}
		
		if (tagExists(lotNo, tagNo) == true){
			for(idx = tagNo; idx <= tagNoEnd; ++idx) {
				var oOption = document.createElement("OPTION");
				oOption.text= lotNo + "-" + idx + " (" + tagColor + ")";
				oOption.value= idx + "|||" + tagColor + "|||" + lotNo;
				document.all.item("tagNumbersList").add(oOption);
			}
			document.addTagNumber.txtTagNumber.value="";
			document.addTagNumber.txtTagNumberEnd.value="";
			
			document.addTagNumber.txtTagNumber.focus();
		}
		
		
	<% else %>

		var tagNo = document.addTagNumber.txtTagNumber.value;
		tagNo = trim(tagNo);
		if (tagExists(0, tagNo) == true){
			if(tagNo.length >0){
				var oOption = document.createElement("OPTION");
				oOption.text=tagNo + " (" + tagColor + ")";
				oOption.value=tagNo + "|||" + tagColor + "|||" + 0;
				document.all.item("tagNumbersList").add(oOption);
			}
			document.addTagNumber.txtTagNumber.value="";
			document.addTagNumber.txtTagNumber.focus();
		}
	<% end if %>
	}
	
	function tagExists(lotNumber, tagNumber) {
		var counter;
		var tempTag;
		var tempTagNo;
		var tagInfo;
		var returnValue;
		var tempLotNo;
		
		returnValue =true;
		tagNumber = new String(tagNumber);
		tagNumber = tagNumber.toUpperCase();
		counter = document.addTagNumber.tagNumbersList.length
		for (var i=0; i< counter; i++){
			tempTag = new String(document.addTagNumber.tagNumbersList.options[i].value);
			tempTag = tempTag.toUpperCase();
			tagInfo = tempTag.split("|||");
			tempTagNo = tagInfo[0];
			tempLotNo = tagInfo[2];
			if(tempTagNo == tagNumber && tempLotNo == lotNumber) {
				returnValue =false;
				cbs_alert("Duplicate Tag Number - " +  tagNumber);
				break;
			}
		}
		return returnValue;
	}
	
	function deleteSelectedTagNo(){
		var idx;
		
		for(idx = 0; idx < document.addTagNumber.tagNumbersList.length; ++idx) {
			if(document.addTagNumber.tagNumbersList.options[idx].selected) {
				document.addTagNumber.tagNumbersList.options[idx] = null;
				--idx;
			}
		}

	}
	
	function submitForm() {
		var counter;
		
		counter = document.addTagNumber.tagNumbersList.length;

		for(var i=0; i<counter; i++) {
				document.addTagNumber.tagNumbersList.options[i].selected =true;
		}

		document.addTagNumber.action = "?userAction=submit";
		document.addTagNumber.submit();
	}
	
	function cancelForm() {
		var addOrEditVal;
		addOrEditVal = document.addTagNumber.addOrEdit.value;
		document.addTagNumber.action = "detailedInvoice.asp?userAction=fromTagAllocation&button=cancel&addOrEdit=" + addOrEditVal;
		document.addTagNumber.submit();
	}
	
	function focusOnLoad() {
	<% if enableLotTags then %>
		document.addTagNumber.txtLotNumber.focus();
	<% else %>
		document.addTagNumber.txtTagNumber.focus();
	<% end if %>
	}
	
	function moveFocus(obj) {
	<% if enableLotTags then %>
		if (event.keyCode == 13){
			if(obj.name == "txtLotNumber") {
				document.addTagNumber.txtTagNumber.focus();
				document.addTagNumber.txtTagNumber.select();
			}
			else if(obj.name == "txtTagNumber") {
				document.addTagNumber.txtTagNumberEnd.focus();
				document.addTagNumber.txtTagNumberEnd.select();
			}
		}
	<% end if %>
	}
	
</script>
<BODY topmargin=0 leftmargin=0 onLoad="focusOnLoad();">

<!-- #include file="../include/banner.inc" -->
<H1>Enter Tag Number</H1>
<FORM id="addTagNumber" name="addTagNumber" action="addTagNumber.asp" method="Post">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="invoiceCounter" value="<%= invoiceCounter %>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	<TABLE ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px>
			<td></td>
			<td colspan=1 align=center class="label" style=font-size=14><% if invoiceCounter > 0 then %>Enter Tags for Next Invoice <% end if%>
			</td>
		</tr>
		<tr valign=top>
<%

				dim detRst
				dim dept
				dim deptDueDate
				dim pkgqty
				dim currentInvoice

				set currentInvoice = getCurrentInvoice()

				if currentInvoice.isInvoiceEmpty() then
				
				else
%>
			<td rowspan = 8>
				<table name="invoiceDetails" id=invoiceDetails width=300px>
				<tr>
					<td colspan=2 style=font-size=16><u>Invoice Details</u></td>
				</tr>
<%
				dim customerPreference
				dim customerPreferences
				dim customerPreferencesRS

				set customerPreferences = invoice.preferences

				query = " select * from customerpreferencetype order by displayorder "
        set customerPreferencesRS = getdisconnectedrecordset(query)

        while not (customerPreferencesRS.eof or customerPreferencesRS.bof)
        	if customerPreferences.exists(clng(customerPreferencesRS("customerPreferenceTypeID"))) then
        		response.write "<tr><td colspan=2 style=font-size=16>"
        		response.write customerPreferencesRS("name") & ": " & customerPreferences(clng(customerPreferencesRS("customerPreferenceTypeID")))
        		response.write "</td></tr>"
        	end if

        	customerPreferencesRS.movenext
        wend
%>

				<tr>	
					<td colspan=2 style=font-size=16>&nbsp;</td>
				</tr>
				
				<tr>
					<td style=font-size=16><u>Department</u></td>
					<td style=font-size=16><u>Pieces</u></td>
				</tr>	
				<%

				
				set detRst = currentInvoice.lineitems
				detRst.Sort = "deptName ASC"
		
				if detRst.Recordcount > 0 then
					detRst.MoveFirst
					dept=detRst.Fields("deptName").Value
					pkgqty = 0
					
					While Not detRst.eof
						deptDueDate = currentInvoice.getDeptDueDate(dept)
						If detRst.Fields("deptName").Value = dept then
							if not isnull(detRst.Fields("pkgquantity").value) then
								pkgqty = pkgqty + (clng(detRst.Fields("quantity").value) * clng(detRst.Fields("pkgquantity").value))
							end if	
						else

			
				%>

				<tr>
					<td style=font-size=16 colspan="2"><%=WeekdayName(Weekday(deptDueDate))%>, <%=deptDueDate%></td>
				</tr>		
				<tr>
					<td style=font-size=16><%=dept%></td>
					<td style=font-size=16><%=pkgqty%></td>
				</tr>		
				<%		
							dept=detRst.Fields("deptName").Value
							
							if not isnull(detRst.Fields("pkgquantity").value) then
								pkgqty = clng(detRst.Fields("quantity").value) * clng(detRst.Fields("pkgquantity").value)
							else
								pkgqty = 0
							end if	
							
						end if
						detRst.moveNext
				%>				
				<%
					wend
				end if	
				%>

				<tr>
					<td style=font-size=16 colspan="2"><%=WeekdayName(Weekday(deptDueDate))%>, <%=deptDueDate%></td>
				</tr>			
				<tr>
					<td style=font-size=16><%=dept%></td>
					<td style=font-size=16><%=pkgqty%></td>
				</tr>		
				<%
				end if
				%>
				</table>
			</td>		
		</tr>
		<tr>
			<td colspan=2 class="label" align="center" style=font-size=16>Invoice</td>
		</tr>
		<tr>	
			<td colspan=2 align=center>
				<INPUT id=txtInvNumber name=txtInvNumber class=text style="WIDTH: 190px;" value="<%= invoiceNumber%>" readonly>
			</td>
			<td rowspan=8 valign=top>
				<Table ALIGN=center width=300px BORDER=0 CELLSPACING=1 CELLPADDING=0 >
					<tr>
						<td align="center" colspan=2> 		
							<select id=tagNumbersList name=tagNumbersList size=10 style="width:250px;font-size:16" multiple>
								<%
									dim existingTags
									if addOrEdit = "edit" then
										set existingTags = getExistingTagsForTicket()
										if existingTags.Recordcount > 0 then
											existingTags.MoveFirst
											while not existingTags.eof
								%>
												<option value="<%= existingTags.Fields("tagNumber").Value & "|||" & existingTags.Fields("tagColor").Value & "|||" & existingTags.Fields("lotNumber").Value%>">
												<% if existingTags.Fields("lotNumber").Value > 0 then %>
												<%= existingTags.Fields("lotNumber").Value & "-" & existingTags.Fields("tagNumber").Value & " (" & existingTags.Fields("tagColor").Value & ")"%>
												<% else %>
												<%= existingTags.Fields("tagNumber").Value & " (" & existingTags.Fields("tagColor").Value & ")"%>
												<% end if %>
												</option>
								<%				
												existingTags.MoveNext
											wend
										end if
									end if
								%>
							</select>
						<td>
					</tr>
					<tr height=20px> <td></td></tr>
					<tr>
						<td align=center colspan=2>
							<INPUT class=touch id=delete name=delete type=button value="" style="background-image:url(../images/Cancel-2.gif);background-position=center;" onclick="deleteSelectedTagNo()"><br>Delete<br>
						</td>
						
					</tr>
					<tr height=20px><td></td></tr>
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=ok name=ok type=button value="" style="background-image:url(../images/ok.gif);" onClick="submitForm();">
							&nbsp&nbsp&nbsp
							<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm();">
						</td>
					</tr>
					
				</table>
			</td>
		<% if enableLotTags then %>
		<tr>
			<td colspan=1 class="label" align="center" style=font-size=16 width="55px">Lot</td>
			<td colspan=1 class="label" align="center" style=font-size=16>Tag Range</td>
		</tr>
		<tr>
			<td colspan=1 align=center width="55px">
				<INPUT id=txtLotNumber name=txtLotNumber class=text style="WIDTH: 50px;" onkeyup="moveFocus(this)">
			</td>
			<td colspan=1 align=center>
				<INPUT id=txtTagNumber name=txtTagNumber class=text style="WIDTH: 60px;" onkeyup="moveFocus(this)">
				<INPUT id=txtTagNumberEnd name=txtTagNumberEnd class=text style="WIDTH: 60px;" onkeyup="moveFocus(this)">
			</td>
		</tr>
		<% else %>
		<tr>
			<td colspan=2 class="label" align="center" style=font-size=16 >Tag</td>
		</tr>
		<tr>
			<td colspan=2 align=center>
				<INPUT id=txtTagNumber name=txtTagNumber class=text style="WIDTH: 190px;">
			</td>
		</tr>
		<% end if %>
		<tr>
			<td align=center colspan=2>
				<Table ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=0 >
		<%
		  dim counter
		  
		  query = " select * from lotcolor "
		  set rs = getdisconnectedrecordset(query)
		
		  while not(rs.eof or rs.bof)
		%>
		<tr>
			<TD align=right width=150><INPUT class=touch id=<%=rs("name")%> name=<%=rs("name")%> type=button value="<%=rs("name")%>" style=background-color:<%=rs("hexcolor")%> onClick="addTagNoToList(this.name);">&nbsp</TD>
		<%
		  rs.movenext
		  if not(rs.eof or rs.bof) then
		%>
			<Td align=left width=150><INPUT class=touch id=<%=rs("name")%> name=<%=rs("name")%> type=button value="<%=rs("name")%>" style=background-color:<%=rs("hexcolor")%> onClick="addTagNoToList(this.name);"><br></TD>
		<%
		  else
		%>
		  <Td align=left width=150></TD>
		<%
		  end if
		%>
			
		</tr>
		
		<%  if not(rs.eof or rs.bof) then
		        rs.movenext
		    end if
		  wend
		%>
				</table>
			</td>	
		</tr>
	</TABLE>
</FORM>   

</BODY>
</HTML>
