<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim isSubmitted 
	dim l_storeid
	dim l_employeeid
	dim l_action
	dim rsTicketbydate 
	dim l_error 
        dim errorRS

	rsTicketbydate = null

	l_storeid = session("storeid")
	l_employeeid = session("employeeid")
	isSubmitted = Request.QueryString("Submitted")
	if isSubmitted then
		UpdateDatabase()
		if Session("viewTableSource") is nothing then
			Response.Redirect "routesMenu.asp"
                else
                      Response.Redirect("viewTable.asp?title=Checkout Errors&table=viewTableSource")
                      set errorRS = Session("viewTableSource")
                      errorRS.Close
                      set errorRS = nothing
                      set Session("viewTableSource") = nothing
		end if
	end if
	
	l_action = Request.QueryString("userAction")
	
	if l_action = "byDate" then
		getTicketbydate()
	end if
	
	getRoutes()
%>
<HTML>
<HEAD>
<TITLE>Check Out</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<SCRIPT LANGUAGE="javascript" >

	function captureKeyUpEvent(element){
	
	  	if (event.keyCode == 13){
			event.returnValue = true;	
			addInvoiceNoToList();
		}
	}
	  	
	function cancelForm() {
		document.checkOutForm.action="routesMenu.asp";
		document.checkOutForm.submit();
	}
	
	function addInvoiceNoToList(){
		var ticketNo = document.checkOutForm.txtTicketNo.value;
		ticketNo = trim(ticketNo);
		if(ticketNo.length >0){
			var oOption = document.createElement("OPTION");
			oOption.text=ticketNo;
			oOption.value=ticketNo;
			document.all.item("invoiceNumbersList").add(oOption);
		}
		document.checkOutForm.txtTicketNo.value="";
	}
	function deleteSelectedInvNo(){
		if(document.checkOutForm.invoiceNumbersList.length >0){
			var index = document.checkOutForm.invoiceNumbersList.selectedIndex;
			if(index >=0) {
				document.checkOutForm.invoiceNumbersList.options[index]=null;
				if ( document.checkOutForm.invoiceNumbersList.length > 0 )
					document.checkOutForm.invoiceNumbersList[0].selected = true;								
			}
		}
			
	}
	
	function enableInvoiceSel() {
	
		if(document.checkOutForm.selectCriteria[0].checked) {
			document.checkOutForm.txtTicketNo.disabled=false;
			document.checkOutForm.addToList.disabled=false;
			document.checkOutForm.txtDate1.disabled=true;
			document.checkOutForm.txtDate2.disabled=true;
			document.checkOutForm.addToList1.disabled=true;
		}
		else	
			if(document.checkOutForm.selectCriteria[1].checked){
				document.checkOutForm.txtTicketNo.disabled=true;
				document.checkOutForm.addToList.disabled=true;
				document.checkOutForm.txtDate1.disabled=false;
				document.checkOutForm.txtDate2.disabled=false;
				document.checkOutForm.addToList1.disabled=false;
				
				if (document.checkOutForm.txtFromDate.value == "")
					document.checkOutForm.txtFromDate.value = getTodaysDate();
					
				if (document.checkOutForm.txtToDate.value == "")
					document.checkOutForm.txtToDate.value = getTodaysDate();
			} 
				
	}	
	
		function getTodaysDate(){
			var now ;
			var x
			now = new Date();
			x = formatString(now.getMonth()+ 1) + "/" + formatString(now.getDate()) + "/" + now.getFullYear()
			return x;
		}
		
		
		function formatString(element){
		var x
		x = String(element)
		if (x.length < 2) 
			x = "0" + x; 
		return (x);
	
	
	}
	
		function getInvoiceforDate(){
			if (document.checkOutForm.routeList.selectedIndex > -1 ) { 
				if (document.checkOutForm.txtFromDate.value == "" ||
					document.checkOutForm.txtToDate.value == "")
					cbs_alert("Please enter start and end date");
				else{
					 
					document.checkOutForm.action = "?useraction=byDate"
					document.checkOutForm.submit()
				}
			}
	  	}	
	  	
	  	function clearInvoiceList() {
	  		if (oldrouteindex != document.checkOutForm.routeList.selectedIndex) {
	  			document.checkOutForm.invoiceNumbersList.length   = 0;
	  			
	  		}
	  		oldrouteindex = document.checkOutForm.routeList.selectedIndex 
	  	}	
	  	
	  	var oldRouteindex;
	  	
	  	function saveRouteIndex(){
	  	
	  		oldrouteindex = document.checkOutForm.routeList.selectedIndex 
	  		enableInvoiceSel();
	  	}
	  	
	  	function submitForm(){
	  	var i
	  	i = 0;
	  	if (document.checkOutForm.invoiceNumbersList.length > 0 ){
	  			while (i < document.checkOutForm.invoiceNumbersList.length) {
	  				document.checkOutForm.invoiceNumbersList[i].selected = true;
	  				i++;
	  			}
	  			document.checkOutForm.action = "?submitted=true";
	  			document.checkOutForm.submit();
	  		}
	  		else
	  			cancelForm();
	  	
	  	}
	  	
	  
	  	
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload = saveRouteIndex();>

<!-- #include file="../include/banner.inc" -->
<H1>Check Out</H1>
<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >	
	<FORM id="checkOutForm" name="checkOutForm" action="" method=post>
		<tr height=20px><td></td></tr>

		<tr>
			<td align=left class="label">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Route Name</td>
			<td>
				<SELECT name=routeList STYLE="FONT-SIZE: 16px; width:175px" onChange="clearInvoiceList();">
				<%
					if rsRoutelist.Recordcount > 0 then
						while not rsRoutelist.eof
				%>	
				<OPTION 
				<%if trim(Request.Form("routeList")) = trim(rsRoutelist("routenumber") ) then %>
					selected
				<% end if %>
				VALUE= "<%=trim(rsRoutelist("routenumber"))%>"><%=trim(rsRoutelist("name")) %> </option>
				<%
					rsRoutelist.movenext
					wend
						rsRoutelist.close
						set rsRoutelist = nothing
					end if 
				
				%>
				
				</SELECT>
			</td>
		</tr>
		<tr height=20px><td></td></tr>
		<tr>
			<td  align=left class="label" valign=top>
				<input type="radio" name=selectCriteria value="ticketNo" style="height=28px;width=28px;"
				<%if trim(Request.Form("selectCriteria")) = "ticketNo" then %>
					checked
				<% end if %>
				onClick="enableInvoiceSel()" checked>Invoice Numbers
			</td>
			<td valign=top>
				<INPUT id=txtTicketNo name=txtTicketNo class=text onKeyUp="captureKeyUpEvent(this)">
			</td>	
			<td  valign=top width=30px >
				<INPUT class=touch id=addToList name=addToList type=button value="" style="background-image:url(../images/select-All-2.gif);width:30px;height:30px;" onClick="addInvoiceNoToList()">
			</td>
			<td  valign=top rowspan=4>
				<Select multiple name=invoiceNumbersList size=15 style="width:200px;font-size=16px">
				<%
					if not isnull(rsTicketbydate)  then
						if rsTicketbydate.Recordcount > 0 then
							while not rsTicketbydate.eof
				%>				
								<OPTION VALUE= "<%=trim(rsTicketbydate("invoicenumber"))%>"><%=trim(rsTicketbydate("invoicenumber")) %></OPTION>
				<%
								rsTicketbydate.movenext
							wend
							rsTicketbydate.close
						set rsTicketbydate = nothing
						end if 
					end if
				
				%>
				</Select>
			</td>
			<td valign=top width=100px>
				<INPUT class=touch id=delete name=delete type=button value="" style="background-image:url(../images/Cancel-2.gif);background-position=center" onClick="deleteSelectedInvNo()"><br>Delete
			</td>
		</tr>
		<tr>
			<td align=left class="label" valign=top>
				<input type="radio" name=selectCriteria value="ticketsInDateRange" style="height=28px;width=28px;"
				<%if trim(Request.Form("selectCriteria")) = "ticketsInDateRange" then %>
					checked
				<% end if %>
				onClick="enableInvoiceSel()">Select all Invoices<br>&nbsp;&nbsp;&nbsp;Due Between</td>
			<td valign=top>
				<INPUT id=txtFromDate name=txtFromDate class=text style="width:100px;" readonly value = "<%=Request.Form("txtFromDate") %>">
				<INPUT class=touch id=txtDate1  name=txtDate1  type=button  value="" style="background-image:url(../images/Calender.gif); width=25px; height=25px;" disabled onClick="javascript:show_calendar('checkOutForm.txtFromDate');">
				
			</td>
			<td  valign=top width=30px >
				<INPUT class=touch id=addToList1 name=addToList1 type=button value="" style="background-image:url(../images/select-All-2.gif); width:30px; height:30px;" disabled onClick="getInvoiceforDate()">
			</td>	
		</tr>
		<tr>
			<td valign=top></td>
			<td valign=top ><b align=center class="label">To</b><br>
				<INPUT id=txtToDate name=txtToDate class=text style="width:100px;" readonly value = "<%=Request.Form("txtToDate") %>">
				<INPUT class=touch id=txtDate2  name=txtDate2  type=button value="" style="background-image:url(../images/Calender.gif); width=25px; height=25px;" disabled onClick="javascript:show_calendar('checkOutForm.txtToDate');">
			</td>	
		</tr>
		<tr>
			<td></td>
			<td>
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=2>
					<tr>
						<td align=center><BR><BR><BR><BR>
							<INPUT class=touch id=checkOut name=checkOut type=button value="" style="background-image:url(../images/Check-out.gif);background-position=center" onClick="submitForm()"><br>Check Out
						</td>
						<td align=center><BR><BR><BR><BR>
							<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
						</td>
						
					</tr>
				</table>
			</td>
		</tr>
	</form>
</table>
</BODY>
</HTML>
<%
	dim rsRouteList
	
	
	Function getRoutes()
	dim sqltxt
		'Modified by MWiemann on 6-13-2003 -- to exclude non valid routenumber 0 (none)
		sqltxt = "Select * from Route where storeid = " & l_storeid & " and routeNumber > 0"
		set rsRouteList = getdisconnectedrecordset(sqltxt)
	end function
	
	function getTicketbydate()
	dim sqltxt
	dim s_startdate
	dim s_enddate
	dim s_startrange
	dim s_endRange
	dim s_route
		
		s_route = Request.Form("routelist")
		s_startdate = trim(Request.Form("txtFromdate"))
		s_enddate = trim(Request.Form("txtToDate"))
			
		s_startrange = s_startdate  
		
		s_endRange = s_enddate  
	
	sqltxt = "select ticketnumber, invoicenumber from ticket where routenumber = " & s_route _
				& " and onHold = 0 " _
				& " and ticketstatus = 'AC' " _
				& " and invoicetype = 'D' " _
				& " and  convert(varchar, duedate, 112)  between convert(varchar, cast(  " & dbcreateqrystring(s_startrange) _
				& "  as datetime), 112) and  convert(varchar, cast(  " & dbcreateqrystring(s_endrange)_
				& "  as datetime), 112)  " 
				
	'Response.Write sqltxt
	
	set rsTicketBydate = getDisconnectedrecordset(sqltxt)
		
	end function
	
	function UpdateDatabase()
	dim sqltxt
	dim i
	dim invoicelist
	dim rstErrorlist
	dim runStart, runRemaining
	dim runCount
        dim errorRS

	runStart = 1
	runRemaining = Request.Form("invoiceNumbersList").count
	runCount = 20

        set errorRS = nothing



	'below changed by SteveG to run checkout_delivery in batches of 20
        'this was to fix the error cause by the second argument to checkout_delivery
	'becoming to large and not fitting the definition in the sp
	'removed the start/end transaction and retrieved the recordset without trans

	'dbstarttrans()

	while runRemaining > 0

		if runRemaining < runCount then
			runCount = runRemaining
		end if


		'invoicelist = "'" & dbcreateqrystring(Request.Item("invoiceNumbersList").Item(1))& "'"
		'Modified the above line by Haribabu on Jan 09, 2003 to avoid SQL Error
		invoicelist = dbcreateqrystring(Request.Item("invoiceNumbersList").Item(runStart))

	    for i = runStart + 1 to runStart + runCount - 1
			'invoicelist = invoicelist & ", '" & dbcreateqrystring(Request.Form("invoiceNumbersList").Item(i)) & "'"
			'Modified the above line by Haribabu on Jan 09, 2003 to avoid SQL Error
			invoicelist = invoicelist & ", " & dbcreateqrystring(Request.Form("invoiceNumbersList").Item(i))
            next

		sqltxt = "exec checkout_delivery " & dbcreateqrystring(Request.form("routelist")) _
				& "," & dbcreateqrystring(invoicelist) _
				& ",null, null " _
				& ", " & session("employeeid")_
				& "," & session("storeid")

	   set rstErrorlist = getDisconnectedRecordset(sqltxt)

	'	set rstErrorlist = getDisconnectedRecordsetwithTrans(sqltxt)

		if rstErrorlist.recordcount > 0 then

                        if errorRS is nothing then
                           set errorRS = Server.CreateObject("ADODB.Recordset")
                           errorRS.Fields.Append "Ticket", adVarChar, 20
                           errorRS.Fields.Append "Description", adVarChar, 255
                           errorRS.Open
                        end if

			while not rstErrorlist.eof


				errorRS.AddNew

                                for i = 0 to rstErrorlist.Fields.Count - 1
				    errorRS.Fields(i).Value = rstErrorlist.Fields(i).Value

				next

                                errorRS.Update

				rstErrorlist.movenext
			wend

			rstErrorlist.close


			set rstErrorlist = nothing

		end if

		runStart = runStart + runCount
		runRemaining = runRemaining - runCount
	wend

        set Session("viewTableSource") = errorRS

	'dbendtrans()

	end function

%>
