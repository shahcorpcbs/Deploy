<%@ Language=VBScript %>
<%option explicit %>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	
%>
<HTML>
<HEAD>
<TITLE>Manager Menu</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function showFormEmpAccess() {
		document.employeeMgmtForm.action = "EditEmployeeRoles.asp?originPage=employeemanagement";
		document.employeeMgmtForm.submit();
	}	
	
	function showEmployeeRole(){
		document.employeeMgmtForm.action ="EditRole.asp?originPage=employeemanagement";
		document.employeeMgmtForm.submit();
	}
	
	function showAddEmployee(){
		document.employeeMgmtForm.action ="addNewEmployee.asp?userAction=add";
		document.employeeMgmtForm.submit();
	}
	function showEditEmployee(){
		document.employeeMgmtForm.action ="employeeList.asp?userAction=editEmployee";
		document.employeeMgmtForm.submit();
	}
	function changeEmployeeStatus(){
		document.employeeMgmtForm.action ="activeInactiveEmployees.asp";
		document.employeeMgmtForm.submit();
	}
	function editEmployeeHours(){
		document.employeeMgmtForm.action ="employeeList.asp?userAction=editHours";
		document.employeeMgmtForm.submit();
	}
	function showEmployeeNotifications(){
		document.employeeMgmtForm.action ="../setup/employeeAlerts.asp";
		document.employeeMgmtForm.submit();
	}
	function showEmployeeReports(){
		document.employeeMgmtForm.action ="../setup/employeeReports.asp";
		document.employeeMgmtForm.submit();
	}
	function editEmployeeOtherHours(){
	    document.employeeMgmtForm.action ="employeeList.asp?userAction=editOtherHours";
	    document.employeeMgmtForm.submit();
	}
	function cancelForm(){
		document.employeeMgmtForm.action ="managerMenu.asp";
		document.employeeMgmtForm.submit();
	}

	function viewSecurityLog(){
		document.employeeMgmtForm.action ="viewSecurityLog.asp";
		document.employeeMgmtForm.submit();
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Employee Management Menu</H1>
<FORM id="employeeMgmtForm" name="employeeMgmtForm" action="" method="post">
	<TABLE ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR></TR>
		<TR>
			<TD align=middle>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" id=addEmployee name=addEmployee onClick="showAddEmployee()">Add Employee</BUTTON>
			</TD>
			<TD align=middle>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" id=editEmployee name=editEmployee onClick="showEditEmployee()">Edit Employee</BUTTON>
			</TD>
			<td align = middle>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" id=accessEmployee name=accessEmployee onClick="showFormEmpAccess()">Employee Access</BUTTON>
			</td>
			<td align = middle>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" onClick="showEmployeeNotifications()">Employee Notifications</BUTTON>
			</td>
		</TR>
		<TR height:40px></TR>
		<TR>
			<TD align=middle>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" id=changeEmpStatus name=changeEmpStatus onClick="changeEmployeeStatus()">Change Employee Status</BUTTON>
			</TD>
			<TD align=middle>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" id=editEmpHours name=editEmpHours onClick="editEmployeeHours()">Edit Employee Hours</BUTTON>
			</TD>
			<TD align=middle>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" onClick="viewSecurityLog()">Security Log</BUTTON>
			</TD>
			<td align = middle>
				<BUTTON class="std" style="width:200px;height:100px;font-size:12px" onClick="showEmployeeReports()">Employee Reports</BUTTON>
			</td>
		</TR>
		<tr>
			<TD align=middle>
				<BUTTON class=std style="width:200px;height=100px;font-size:12px" id=editEmpOtherHours name=editEmpOtherHours onClick="editEmployeeOtherHours()">Add/Edit Employee<br>Other Hours<br>(Vac, Sick, Hol)</BUTTON>
			</TD>
	    </tr>

		<TR style="height: 50px" ></tr>
		<TR height:100px>
			<td colspan=4 align="center">
				<INPUT class=touchnoborder id=cancel type=button value="" name=cancel style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
			</td>
		</tr>
	</TABLE>
</FORM>   

</BODY>
</HTML>
