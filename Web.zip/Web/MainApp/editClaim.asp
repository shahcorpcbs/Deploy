<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<% 
	Dim l_customerseq
	dim l_storeid
	dim isSubmitted 
	dim l_employeeId
	dim l_claimid
	
	l_Customerseq = session("Customersequencenumber")
	l_storeid = session("Storeid")
	isSubmitted = Request.QueryString("Submitted")
	l_employeeId = session("EmployeeId")
	l_claimid = Request.QueryString("claimId")
	
	if len(trim(l_claimid)) = 0 then
	
		l_claimid = session("Claimid")
		
	else
		session("ClaimID") = l_claimid	
		
	end if

	select case lcase(request.querystring("useraction"))
	case "addnote"
		addNote l_claimid, l_employeeId, request.querystring("note")

	end select


	function addNote(claimid, employeeid, note)
		dim query, rs


		query = "Insert into claimcomment(claimid, createddate, createdemployeeId,description) values ( " _
					& claimid _
					& "," & "getdate()" _
					& "," & employeeid _
					& "," & DbcreateQryString(note)_
					& " )"
		qryexecute(query)

	end function	
%>
<HTML>
<HEAD>
<TITLE>Edit Claim</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
		
	function addNewInfoToClaim() {
		cbs_prompt('Enter claim note', handleNote, '', true)
	}

	function handleNote() {
        clearPromptMsg();
	    var note  = document.getElementById('inputTxtArea').value;
		if(note != null && note != "") {
			document.editClaim.action = "editClaim.asp?useraction=addnote&note=" + encodeURIComponent(note);
			document.editClaim.submit();
		}
	}
	
	function closeSelectedClaim() {
		document.editClaim.action = "closeClaim.asp";// + "?claimid=" + document.editClaim.h_claimid.value;
		document.editClaim.submit();
	}
	
	function submitForm() {
		document.editClaim.action ="claimOrComments.asp";
		document.editClaim.submit();
	}			
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Claim</H1>
<FORM id="editClaim" name="editClaim" action="" method="Post" onSubmit="return false">
<!--<input name =h_claimid type=hidden value="<%=l_claimid%>">-->

<%
	dim claimRS
	
	set claimRS = getClaimRS(l_claimid)
%>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="addNewInfoToClaim()">Add Note</BUTTON>
	<%if claimRS("claimstatus") = "Open" then%><BUTTON onclick="closeSelectedClaim()">Close</BUTTON><%end if%>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="submitForm()">Exit</BUTTON>
	</SPAN>
</DIV>



<TABLE class="itable">

<TR>
<TD>
<TABLE style="background:#F8F8F8;margin-top:5px;margin-bottom:5px;width:100%">
	<tr valign="top">
		<td style="width:100px">Date Created:</td>
		<td valign = top >
			<%=claimRS("createddate")%>
		</td>
	</tr>
	<tr valign="top">
		<td>Employee:</td>
		<td>
			<%=claimRS("employeename")%>
		</td>
	</tr>
	
	
	<tr valign="top">
		<td>Status:</td>
		<td>
			<%=claimRS("claimstatus")%>
		</td>
	</tr>

	<tr valign="top">
		<td>Action Taken:</td>
		<td>
			<%
			Response.write claimRS("ClaimAction")
			if trim(claimRS("claimAmount")) <> "" then
				Response.Write " " & formatcurrency(claimRS("claimAmount")) 
			end if
		%>
		</td>
	</tr>
</TABLE>
</TD>
</TR>
<%
	dim claimCommentRS
	dim spacerExists
	
	spacerExists = false
	
	set claimCommentRS = getClaimCommentRS(l_claimid)

	while not(claimCommentRS.eof or claimCommentRS.bof)
%>
<% if not spacerExists and not isnull(claimRS("lastUpdatedDate")) then
			if datediff("s", claimRS("lastUpdatedDate"), claimCommentRS("createddate")) > 0 then
				spacerExists = true
%>
	<tr style="background:#F8F8F8">
		<td style="border-bottom:3px inset #aaa" align="center" <%if claimRS("claimstatus") = "Open" then%>style="background:lightgreen"<%else%>style="background:red;color:white"<%end if%>>
		<%=claimRS("claimstatus") & " " & claimRS("lastUpdatedDate") & " " & claimRS("ClaimAction")%>
		</td>
	</tr>
<%
			end if
		end if
%>
<TR>
<TD>


<TABLE style="background:#F8F8F8;margin-top:5px;margin-bottom:5px;width:100%">

	<tr valign="top">
		<td style="width:100px">Date:</td>
		<td valign = top >
			<%=claimCommentRS("createddate")%>
		</td>
	</tr>
	<tr valign="top">
		<td>Employee:</td>
		<td>
			<%=claimCommentRS("employeename")%>
		</td>
	</tr>
	<tr valign="top">
		<td>Description:</td>
		<td>
			
			
			<TEXTAREA readonly rows=6 name="claimInfo" style="width:390px;border:1px inset;background:white;overflow:auto"><%=claimCommentRS("description")%></TEXTAREA>
		</td>
	</tr>
	

</TABLE>
</TD>
</TR>


<%
		claimCommentRS.movenext
	wend
%>

<% if not spacerExists then
%>
	<tr style="background:#F8F8F8">
		<td style="border-bottom:3px inset #aaa" align="center" <%if claimRS("claimstatus") = "Open" then%>style="background:lightgreen"<%else%>style="background:red;color:white"<%end if%>>
		<%=claimRS("claimstatus") & " " & claimRS("lastUpdatedDate") & " " & claimRS("ClaimAction")%>
		</td>
	</tr>
<%
		end if
%>

<tr style="height:100px"></tr>

</TABLE>


</form>
</BODY>
</HTML>
<%

	function getClaimRS(claimid)
		dim query, rs
		
		query = "select claim.*, employee.employeename, "
		query = query & " case claim.claimstatus when 'O' then 'Open' else 'Closed' end as claimstatus, "
		query = query & " isnull(claimaction, '') as claimaction from "
		query = query & " claim inner join employee on "
		query = query & " claim.createdemployeeid = employee.employeeid "
		query = query & " where claimid = " & claimid
		
		set getClaimRS = getdisconnectedrecordset(query)
	end function
	
	function getClaimCommentRS(claimid)
		dim query, rs
		
		query = " select claimcomment.*, employee.employeename "
		query = query & " from claimcomment inner join employee on "
		query = query & " claimcomment.createdemployeeid = employee.employeeid "
		query = query & " where claimcomment.claimid = " & claimid 
		query = query & " order by claimcomment.createddate "
		
		set getClaimCommentRS = getdisconnectedrecordset(query)
	end function
	

%>
