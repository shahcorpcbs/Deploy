<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp" -->

<!-- #include file="../include/manifest.asp" -->

<!-- #include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim inventoryid
	dim manifestid
	
	inventoryid = getReqVar("inventoryid")
	manifestid = getManifestId(inventoryid)
	rmanifestids = getRManifestIds(inventoryid)
	
	select case lcase(request.querystring("useraction"))
	case "activate"
		activateInvoices
	end select
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	
	function activateInvoice(invoiceNumber, rackLocation)
		dim query, rs

		query = "execute ReactivateTicket @invoiceNumber='" & dbstr(invoiceNumber) & "',@rackLocation='" & dbstr(rackLocation) & "',@employeeid=" & session("employeeid") & _
				",@employeename='" & session("employeename")  & "',@storeid=" & session("storeid") & ",@terminalid=" & session("terminalid")

		qryexecute query
	
	end function
	
	function activateInvoices()
		dim query, rs
		dim invoiceNumber, rackLocation
		dim manifestItemId
		
		for each manifestItemId in request.form("ico_check")
			query = " select invoicenumber, isnull(location, '') as location from manifestitem where manifestitemid = " & manifestItemId
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				invoiceNumber = rs("invoicenumber")
				rackLocation = rs("location")
				
				activateInvoice invoiceNumber, rackLocation
			end if
			
			set rs = nothing
		next
	end function
	
	function getRManifestIds(inventoryid)
		dim query, rs
		
		query = " select manifestid from inventorymanifest where inventoryid = " & inventoryid
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
			if getRManifestIds <> "" then getRManifestIds = getRManifestIds & ","
			getRManifestIds = getRManifestIds & rs(0)
			rs.movenext
		wend
		
		set rs = nothing
	
	end function
	
	function getManifestId(inventoryid)
		dim query, rs
		
		query = " select manifestid from inventory where inventoryid = " & inventoryid
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getManifestId = rs(0)
		end if
		
		set rs = nothing
	
	end function
	
	
	function getStoreName(inventoryid)
		dim query, rs
		
		query = " select name from store where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getStoreName = rs(0)
		end if
		
		set rs = nothing
	
	end function
	
	function getInventoryDescription(inventoryid)
		dim query, rs
		
		if inventoryid = "" then exit function
		
		query = " select manifest.name "
		query = query & " from inventory inner join manifest on inventory.manifestid = manifest.manifestid "
		query = query & " where inventory.inventoryid = " & inventoryid
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getInventoryDescription = rs(0)
		end if
		
		set rs = nothing
		
	
	end function

%>


<HTML>
<HEAD>


<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<LINK href="../style/manifest.css" rel="stylesheet" type="text/css">

<script language="javascript" src="../external/jquery.js"></script>

<script language="javascript" type="text/javascript">
	function showMatchedItems() {
		var matchedItems = document.getElementById('t_matched');
		var showButton = document.getElementById('a_show_matched');
		var hideButton = document.getElementById('a_hide_matched');
		
		matchedItems.style.display = 'block';
		showButton.style.display = 'none';
		hideButton.style.display = 'block';
		
	}
	function hideMatchedItems() {
		var matchedItems = document.getElementById('t_matched');
		var showButton = document.getElementById('a_show_matched');
		var hideButton = document.getElementById('a_hide_matched');
		
		matchedItems.style.display = 'none';
		showButton.style.display = 'block';
		hideButton.style.display = 'none';
	}
	
	function exit() {
	    document.ico_form.action = "/mainapp/manifestCreate.asp";
	    document.ico_form.submit();
	}

    var options = "Cancel|Matched Inventory|Missing Inventory|Incorrectly Checked Out|Invalid|Changed Rack Location|All";
	function printResults() {
	    cbs_select("Print what section:", 1, options, "handlePrintChoice");
	}

	function handlePrintChoice(returnVal) {
        clearOptionMsg();
	    var invType = options.split("|")[returnVal]
		var content = "";

		if(invType && invType != "Cancel") {
			switch(invType) {
				case "All":
					var inventoryEl = document.getElementById("inventory_content");
					content += inventoryEl.outerHTML;
					
					break;
				case "Matched Inventory":
					var inventoryEl = document.getElementById("store_content");
					content += inventoryEl.outerHTML;
					
					var inventoryEl = document.getElementById("matched_content");
					content += inventoryEl.outerHTML;
					
					break;
				case "Missing Inventory":
					var inventoryEl = document.getElementById("store_content");
					content += inventoryEl.outerHTML;
					
					var inventoryEl = document.getElementById("missing_content");
					content += inventoryEl.outerHTML;
					
					break;
				case "Incorrectly Checked Out":
					var inventoryEl = document.getElementById("store_content");
					content += inventoryEl.outerHTML;
					
					var inventoryEl = document.getElementById("ico_content");
					content += inventoryEl.outerHTML;
					
					break;
				case "Invalid":
					var inventoryEl = document.getElementById("store_content");
					content += inventoryEl.outerHTML;
					
					var inventoryEl = document.getElementById("invalid_content");
					content += inventoryEl.outerHTML;
					
					break;
				case "Changed Rack Location":
					var inventoryEl = document.getElementById("store_content");
					content += inventoryEl.outerHTML;
					
					var inventoryEl = document.getElementById("cr_content");
					content += inventoryEl.outerHTML;
					
					break;
			}

			var print_window = window.open('','','width=600,height=600');
			print_window.document.open("text/html");
			print_window.document.write('<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">');
			print_window.document.write('<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">');
			print_window.document.write('<LINK href="../style/manifest.print.css" rel="stylesheet" type="text/css">');
			print_window.document.write(content);
			print_window.document.close();
			print_window.onafterprint = function() {
			    print_window.close();
            }
			print_window.print();

		}
	}
	
	function submit_ico() {
        cbs_confirm("Are you sure you want to activate and rack these invoices?", gotoActivate);
	}

	function gotoActivate() {
        clearConfirmMsg();
        document.ico_form.action = "?useraction=activate#inv_sec";
        document.ico_form.submit();
	}
	
	function SetRowCheckedStatus(row, check, value) {
				
		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function select_ico(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "ico_check") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked), false);
				break;
			}
			else if (childEl.name == "ico_check") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked), false);
				break;
			}
		}
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="printResults()">Print</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<div id="inventory_content">
<h1>Inventory #<%=inventoryid%></h1>





<div id="store_content">
	<div><b>Store:</b> <%=getStoreName(inventoryid)%></div>
	<div><b>Date:</b> <%=Date() & " " & Time()%></div>
	<div><b>Description:</b> <%=getInventoryDescription(inventoryid)%> </div>
	<div><b>Manifests:</b> Computer: <%=manifestid%>, Scanned: <%=rmanifestids%></div>
</div>

<div class="inv_sec" id="matched_content">
<%
	query = " select manifestitem.invoicenumber, isnull(manifestitem.location, '') as location, isnull(customer.customername, '') as customername from manifestitem "
	query = query & " left outer join ticket on manifestitem.invoicenumber = ticket.invoicenumber "
	query = query & " left outer join customer on ticket.customersequencenumber = customer.customersequencenumber "
	query = query & " where manifestitem.manifestid = " & manifestid
	query = query & " and manifestitem.invoicenumber in (select invoicenumber from manifestitem where manifestid in (" & rmanifestids & "))"
	query = query & " order by case dbo.isint(manifestitem.location) when 1 then cast(manifestitem.location as int) else 10000000 end "

		
	set rs = getdisconnectedrecordset(query)
%>
	<h2>Matched Inventory (<%=rs.recordcount%> items)</h2>
	


	<table id="t_matched" style="display:none" class="itable" cellspacing="0">
		<tr>
			<th>Invoice Number</th>
			<th>Location</th>
			<th>Customer</th>
		</tr>

<%	
	while not (rs.eof or rs.bof)
%>
		<tr>
			<td><%=Server.HTMLEncode(rs("invoicenumber"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("location"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("customername"))%>&nbsp;</td>
		</tr>
<%
		rs.movenext
	wend
	set rs = nothing
%>
	</table>

	<div><a id="a_show_matched" href="javascript:showMatchedItems()">Show matched items</a></div>
	<div><a id="a_hide_matched" style="display:none" href="javascript:hideMatchedItems()">Hide matched items</a></div>
	
	
</div>

<div class="inv_sec" id="missing_content">
<%
	query = " select manifestitem.invoicenumber, isnull(manifestitem.location, '') as location, isnull(customer.customername, '') as customername, "
	query = query & " isnull(ticket.invoicetotal, 0) - isnull(ticket.amountpaid, 0) as invoicebalance, "
	query = query & " isnull((select top 1 payment.paymenttypename from payment where paymentgroupnumber = isnull(ticket.lastpickupgroupnumber, isnull(ticket.lastprepaygroupnumber, -1)) order by amountpaid desc), '') as paymentmethod "
	query = query & " from manifestitem "
	query = query & " left outer join ticket on manifestitem.invoicenumber = ticket.invoicenumber "
	query = query & " left outer join customer on ticket.customersequencenumber = customer.customersequencenumber "
	query = query & " where manifestitem.manifestid = " & manifestid
	query = query & " and manifestitem.invoicenumber not in (select invoicenumber from manifestitem where manifestid in (" & rmanifestids & "))"
	query = query & " order by case dbo.isint(manifestitem.location) when 1 then cast(manifestitem.location as int) else 10000000 end "

		
	set rs = getdisconnectedrecordset(query)
%>
	<h2>Missing Inventory (<%=rs.recordcount%> items)</h2>
	
	<table class="itable" cellspacing="0">
		<tr>
			<th>Invoice Number</th>
			<th>Location</th>
			<th>Balance</th>
			<th>Payment Method</th>
			<th>Customer</th>
		</tr>

<%	
	while not (rs.eof or rs.bof)
%>
		<tr>
			<td><%=Server.HTMLEncode(rs("invoicenumber"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("location"))%>&nbsp;</td>
			<td><%=formatcurrency(rs("invoicebalance"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("paymentmethod"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("customername"))%>&nbsp;</td>
		</tr>
<%
		rs.movenext
	wend
	set rs = nothing
%>
	</table>
</div>

<a name="inv_sec" /> 

<FORM name="ico_form" ID="ico_form" METHOD=POST  style="margin:0;padding:0"> 
<input type="hidden" name="inventoryid" value="<%=inventoryid%>" />

<div class="inv_sec" id="ico_content">
<%
	query = " select manifestitem.manifestitemid, manifestitem.invoicenumber, isnull(manifestitem.location, '') as location, isnull(customer.customername, '') as customername, isnull(ticket.dateout, '') as dateout, isnull(ticketstatusdomain.ticketstatusname, '') as ticketstatusname from manifestitem "
	query = query & " inner join manifest on  manifestitem.manifestid = manifest.manifestid "
	query = query & " inner join ticket on manifestitem.invoicenumber = ticket.invoicenumber "
	query = query & " inner join customer on ticket.customersequencenumber = customer.customersequencenumber "
	query = query & " left outer join ticketstatusdomain on ticket.ticketstatus = ticketstatusdomain.ticketstatus "
	query = query & " where manifestitem.manifestid in (" & rmanifestids & ")"
	query = query & " and manifestitem.invoicestatus = 'finished' "
	query = query & " and manifestitem.invoicenumber not in (select invoicenumber from manifestitem where manifestid = " & manifestid & ")"
	query = query & " and convert(varchar, manifest.datecreated, 101) <> convert(varchar, ticket.dateout, 101) "
	query = query & " order by case dbo.isint(manifestitem.location) when 1 then cast(manifestitem.location as int) else 10000000 end "

		
	set rs = getdisconnectedrecordset(query)
%>
	<h2>Incorrectly Checked Out (<%=rs.recordcount%> items)</h2>
	
<div id="centeredmenu">
   <ul>
      <li><a href="javascript:submit_ico()">Activate/Rack Invoice</a></li>
   </ul>
</div>
	
	<table class="itable" cellspacing="0">
		<tr>
			<th>Invoice Number</th>
			<th>Location</th>
			<th>Current Invoice Status</th>
			<th>Date Out</th>
			<th>Customer</th>
		</tr>

<%	
	while not (rs.eof or rs.bof)
%>
		<tr <%if rs("ticketstatusname") = "Finished" then%>onclick="select_ico(this)"<%end if%>>
			<td><input type="checkbox" name="ico_check" value="<%=rs("manifestitemid")%>" style="display:none"/>
				<%=Server.HTMLEncode(rs("invoicenumber"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("location"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("ticketstatusname"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("dateout"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("customername"))%>&nbsp;</td>
		</tr>
<%
		rs.movenext
	wend
	set rs = nothing
%>
	</table>
</div>
</form>

<div class="inv_sec" id="invalid_content">
<%
	query = " select manifestitem.invoicenumber, isnull(manifestitem.location, '') as location, isnull(ticketstatusdomain.ticketstatusname, '') as ticketstatusname from manifestitem "
	query = query & " left outer join ticket on manifestitem.invoicenumber = ticket.invoicenumber "
	query = query & " left outer join customer on ticket.customersequencenumber = customer.customersequencenumber "
	query = query & " left outer join ticketstatusdomain on ticket.ticketstatus = ticketstatusdomain.ticketstatus "
	query = query & " where manifestitem.manifestid in (" & rmanifestids & ")"
	query = query & " and manifestitem.invoicestatus not in ('finished', 'open') "
	query = query & " and manifestitem.invoicenumber not in (select invoicenumber from manifestitem where manifestid = " & manifestid & ")"
	query = query & " order by case dbo.isint(manifestitem.location) when 1 then cast(manifestitem.location as int) else 10000000 end "

		
	set rs = getdisconnectedrecordset(query)
%>
	<h2>Invalid (<%=rs.recordcount%> items)</h2>
	
	<table class="itable" cellspacing="0">
		<tr>
			<th>Invoice Number</th>
			<th>Location</th>
			<th>Current Invoice Status</th>
		</tr>

<%	
	while not (rs.eof or rs.bof)
%>
		<tr>
			<td><%=Server.HTMLEncode(rs("invoicenumber"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("location"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("ticketstatusname"))%>&nbsp;</td>
		</tr>
<%
		rs.movenext
	wend
	set rs = nothing
%>
	</table>
</div>


<div class="inv_sec" id="cr_content">
<%
	query = " select manifestitem.invoicenumber, isnull(manifestitem.location, '') as location, manifestitem.previouslocation, isnull(customer.customername, '') as customername from manifestitem "
	query = query & " inner join ticket on manifestitem.invoicenumber = ticket.invoicenumber "
	query = query & " inner join customer on ticket.customersequencenumber = customer.customersequencenumber "
	query = query & " where manifestitem.manifestid in (" & rmanifestids & ")"
	query = query & " and manifestitem.invoicestatus = 'open' "
	query = query & " and manifestitem.location <> manifestitem.previouslocation "
	query = query & " order by case dbo.isint(manifestitem.location) when 1 then cast(manifestitem.location as int) else 10000000 end "

	
	set rs = getdisconnectedrecordset(query)
%>
	<h2>Changed Rack Location (<%=rs.recordcount%> items)</h2>
	
	<table class="itable" cellspacing="0">
		<tr>
			<th>Invoice Number</th>
			<th>Old Location</th>
			<th>New Location</th>
			<th>Customer</th>
		</tr>

<%	
	while not (rs.eof or rs.bof)
%>
		<tr>
			<td><%=Server.HTMLEncode(rs("invoicenumber"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("previouslocation"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("location"))%>&nbsp;</td>
			<td><%=Server.HTMLEncode(rs("customername"))%>&nbsp;</td>
		</tr>
<%
		rs.movenext
	wend
	set rs = nothing
%>
	</table>
</div>

</div>


</BODY>
</HTML>
