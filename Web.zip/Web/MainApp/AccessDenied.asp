<%@ Language=VBScript %>
<HTML>
<HEAD>
<link href="/script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY topmargin=0 leftmargin=0>
<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/banner.inc"-->
<p>&nbsp;</p>
<table style="background-color:#ff0000;" align=center cellspacing="1" cellpadding="0" border="0">
<tr>
<td align="center" valign="middle" nowrap style="background-color: #F00; color: #FFF; font-size: 30">
Access Denied
</td>
</tr>
<tr>
    <td align="center" style="color:#2F4F4F; background-color:#ffffff; padding: 20px 20px 30px 20px;">
		You do not have sufficient privileges to access this function.<br> 
		Contact your Store Manager to setup access.
		<%if Request.QueryString("msg") <> "" then%>
		<br><br><%=Request.QueryString("msg")%>
		<%end if%>
		
		<%if sec_DeterminingRole <> "" then%>
		<br><br>(<%=sec_DeterminingRole%>)
		<%end if%>
	</td>
</tr>

<tr>
	<td align=center>
		<input type=button style="margin:3px;background:white;height:50px;width:80px;" value="Back" onclick="history.go(-1);">
		<input type=button style="margin:3px;background:white;height:50px;width:80px;" value="Start Over" onclick="location.href='/mainapp/start2.asp'">
	</td>
</tr>
</table>


</BODY>
</HTML>
