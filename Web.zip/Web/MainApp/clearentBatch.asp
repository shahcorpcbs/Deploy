<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
    dim batchId
    batchId = lcase(Request.QueryString("batchid"))
%>
<HTML>
<script type="text/javascript" src="../Script/clearent.js"></script>
<script type="text/javascript" src="../Script/json2.js"></script>
<script type="text/javascript" src="/external/jquery-1.7.1.min.js"></script>
<script language="javascript" type="text/javascript">

    function process() {
        batchProcessing(<%=batchId%>);
        document.clearentBatch.action = "/mainapp/creditcardbatchstatus.asp?batchid=<%=batchid%>";
        document.clearentBatch.submit();
    }
</SCRIPT>

<body topmargin=0 leftmargin=0 onload="process()" />
<FORM id="clearentBatch" name="clearentBatch" action="clearentBatch.asp" method="post" />

</HTML>
