<%@ Language=VBScript %>
<% Option Explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<% dim  isSubmitted
	dim l_ticketnumber
	dim s_useraction
	dim query, rs

	l_ticketnumber = ""
	s_useraction = ""


    dim terminalid, userIPAddress
	terminalId = Session("terminalID")
    userIPAddress = getLocalPrinterAddress(terminalId)


	isSubmitted = Request.querystring("submitted")

	if (isSubmitted) then
		s_useraction = Request.QueryString("useraction")
		if len(trim(Request.QueryString("invoicenumber") )) > 0 then
			getticketnumber()
		end if
	end if

	dim storeType
    query = "select storeType from store"
    set rs = getdisconnectedrecordset(query)
    storeType = cInt(rs("storeType"))

	dim useSms, useEmail
    useSms = getMSVar("useTwilio")
    useEmail = getMSVar("useEmail")

    dim notificationIP, printerIP, printerName

    notificationIP = getMessengerShortPath()
    printerIP = getPrinterShortPath()


	query = " select storehardware.cashdrawertype, isnull(printer.printername, '') as printername "
	query = query & " from storehardware "
	query = query & " left outer join printer on storehardware.cashdrawerattachedprinterid = printer.printerid "
	query = query & " where storehardware.hardwaretype = 'CD' "
	query = query & " and storehardware.terminalid = " & terminalid

	set rs = getdisconnectedrecordset(query)
    if rs.recordcount > 0 then
        printerName = Replace(rs("printername"), "'", "\'")
    end if


    	function getMSVar(id)
    		query = "select " & id & " from miscsetup"
    		set rs = getdisconnectedrecordset(query)

    		getMSVar = rs(id)

    		set rs = nothing
    	end function
    	
    	
	sub getticketnumber()
	    dim sqltxt
	    dim rsTemp
		sqltxt = "select ticketnumber from ticket where invoicenumber = " & dbcreateqrystring(Request.QueryString("invoicenumber"))
		'Response.Write sqltxt
		set rstemp = getdisconnectedrecordset(sqltxt)
		if rsTemp.recordcount > 0 then
			l_ticketnumber = rsTemp("ticketnumber")
		end if
		rsTemp.close
		set rsTemp = nothing
	end sub

%>

<HTML>
<HEAD>
<TITLE>Tools Menu</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="/script/cashdrawer.js"></script>
</HEAD>


<script language="javascript" type="text/javascript" src="/script/printing.js"></script>


<script language="javascript" type="text/javascript">

	function showCreateManifest() {
		document.toolsMenuForm.action="manifestCreate.asp"
		document.toolsMenuForm.submit();
	}

	function unHoldInvoice() {
		document.toolsMenuForm.action="unHoldInvoice.asp"
		document.toolsMenuForm.submit();
	}

	function searchGarment() {
		document.toolsMenuForm.action="garmentSearch1.asp"
		document.toolsMenuForm.submit();
	}
	function enterTagNumber() {
		document.toolsMenuForm.action="toolsTagNumber.asp";
		document.toolsMenuForm.submit();
	}
	function showItemOrderTracking() {
		document.toolsMenuForm.action="itemorderTracking.asp";
		document.toolsMenuForm.submit();
	}
	function showTagSearch() {
		document.toolsMenuForm.action="tagSearch.asp";
		document.toolsMenuForm.submit();
	}
	function listQuickInvoices() {
		document.toolsMenuForm.action="quickInvoices.asp";
		document.toolsMenuForm.submit();
	}
	function showLotManager() {
		document.toolsMenuForm.action="lotManager.asp";
		document.toolsMenuForm.submit();
	}
	function assignLot() {
		document.toolsMenuForm.action="lotTicket.asp";
		document.toolsMenuForm.submit();
	}	
	function showConveyorMenu() {
		document.toolsMenuForm.action="conveyorMenu.asp";
		document.toolsMenuForm.submit();
	}
	function showManifestList() {
		document.toolsMenuForm.action="manifestList.asp";
		document.toolsMenuForm.submit();
	}
	function cashDrawerOpen(){
	    <% if termLicenseType = 2 then %>
	        cbs_alert("Back Office Terminals cannot have a cash drawer");
	    <% else %>
		var request = "/mainapp/requestActionSecurity.asp?employeeid=<%=Session("EmployeeID")%>&action=opencashdrawer&location=<%=trim(Request.ServerVariables("SCRIPT_NAME"))%>";

		jQuery.getJSON(request,
			function(data) {
				if(data.success != "0") {
					cashDrawerOpenAction();
				}
				else {
					cbs_alert("Access denied.");
				}
			}
		);
		<% end if %>
	}

	function printTags(){
		var request = "/mainapp/requestActionSecurity.asp?employeeid=<%=Session("EmployeeID")%>&action=printTags&location=<%=trim(Request.ServerVariables("SCRIPT_NAME"))%>";

		jQuery.getJSON(request,
			function(data) {
				if(data.success != "0") {
					printTagsAction();
				}
				else {
					cbs_alert("Access denied.");
				}
			}
		);
	}

	function printInvoice(){
		var request = "/mainapp/requestActionSecurity.asp?employeeid=<%=Session("EmployeeID")%>&action=printInvoice&location=<%=trim(Request.ServerVariables("SCRIPT_NAME"))%>";

		jQuery.getJSON(request,
			function(data) {
				if(data.success != "0") {
					printInvoiceAction();
				}
				else {
					cbs_alert("Access denied.");
				}
			}
		);
	}

	function cashDrawerOpenAction(){
	    var url = "http://<%=userIPAddress%><%=printerIP%>/openCashDrawer"
        OpenCashDrawer(url, '<%= printerName %>');

        <% if useSms or useEmail then %>
            var loc = window.location.href;
            var extraCut = 0;
            if (loc.indexOf(":80") != -1)
                extraCut = 5;
            var endStop = loc.indexOf("/mainapp")
            if (endStop == -1)
                endStop = loc.indexOf("/MainApp")

            endStop = endStop - extraCut;
            var ipAddress = loc.substring(0, endStop);

            url = ipAddress + "<%=notificationIP%>/cashdrawerOpen?employeeId=<%=Session("employeeId")%>";
            try {
                $.ajax({
                    type: "POST",
                    url: url,
                    dataType: "text",
                    timeout: "3000",
                    success: function(xhr) {
                    },
                    failure: function(xhr, ajaxOptions, thrownError) {
                        cbs_alert("Unable to connect to CBS Messaging Service to send alert\nMake sure service is running");
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        cbs_alert("Unable to connect to CBS Messaging Service to send alert\nMake sure service is running");
                    }
                });
            } catch (exception) {
                cbs_alert("Unable to send - " + e.message);
            }
        <% end if %>
	}
	function printTagsAction() {
		cbs_prompt("Enter Invoice Number", handlePrintTagAfterPrompt);
	}

	function printInvoiceAction() {
		cbs_prompt("Enter Invoice Number", handlePrintInvoiceAfterPrompt);
	}

	function handlePrintTagAfterPrompt() {
        clearPromptMsg();
	    var invoicenumber = document.getElementById('inputTxtLine').value;
	    CbsPrintForm(CbsForm.Tag, CbsKey.InvoiceNumber, invoicenumber);
	}

	function handlePrintInvoiceAfterPrompt() {
        clearPromptMsg();
	    var invoicenumber = document.getElementById('inputTxtLine').value;
	    CbsPrintForm(CbsForm.Detailed, CbsKey.InvoiceNumber, invoicenumber);
	}
	
	function printPriceList() {
		document.toolsMenuForm.action="pricelist.asp";
		document.toolsMenuForm.submit();
	}

	function messageHistory() {
		document.toolsMenuForm.action = "/MainApp/smsHistory.asp";
		document.toolsMenuForm.submit();
	}

	function emailHistory() {
		document.toolsMenuForm.action = "/MainApp/emailHistory.asp";
		document.toolsMenuForm.submit();
	}

	function plantManifests() {
		document.toolsMenuForm.action = "/MainApp/plantManifests.asp";
		document.toolsMenuForm.submit();
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="">

<!-- #include file="../include/banner.inc" -->

<H1>Tools</H1>
	<FORM id="toolsMenuForm" name="toolsMenuForm" action="" onsubmit="return false" method="post">
<TABLE ALIGN=center BORDER=0 CELLSPACING=0 CELLPADDING=0 >

		<tr>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnTagInfo onClick="enterTagNumber()"><img src="/static/icons/32x32/entry.png"><br><br>Enter Tag Info</button></td>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnInventory onClick="showCreateManifest()"><img src="/static/icons/32x32/manifest_add.png"><br><br>Inventory</button></td>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnlistQuickInvoice onClick="listQuickInvoices()"><img src="/static/icons/32x32/quick_invoice.png"><br><br>Quick Invoices</button></td>
		</tr>
		<tr>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnGarmentSearch onClick="searchGarment()"><img src="/static/icons/32x32/search.png"><br><br>Garment Search</button></td>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnUnholdInvoice onClick="unHoldInvoice()"><img src="/static/icons/32x32/resume.png"><br><br>Un Hold Invoice</button></td>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnTagSearch onClick= "showTagSearch()"><img src="/static/icons/32x32/search.png"><br><br>Tag Search</button></td>
		</tr>
		<tr>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnItemOrder onClick="showItemOrderTracking()"><img src="/static/icons/32x32/tracking.png"><br><br>Item Order Tracking</button></td>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnCashDrawer onClick="cashDrawerOpen()"><img src="/static/icons/32x32/money.png"><br><br>Open Cash Drawer</button></td>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnLotMgr onClick="showLotManager()"><img src="/static/icons/32x32/lot.png"><br><br>Lot Manager</button></td>
		</tr>
		<tr>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnAssignLot onClick="assignLot()"><img src="/static/icons/32x32/lot_add.png"><br><br>Lot Assignment</button></td>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnConveyor onClick="showConveyorMenu()"><img src="/static/icons/32x32/conveyor.png"><br><br>Conveyor</button></td>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnManifests onClick="showManifestList()"><img src="/static/icons/32x32/manifest.png"><br><br>Manifests</button></td>
		</tr>
		<tr>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnPrintInvoice onClick="printInvoice()"><img src="/static/icons/32x32/invoice.png"><br><br>Print Invoice</button></td>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnPrintTags onClick="printTags()"><img src="/static/icons/32x32/tag.png"><br><br>Print Tags</button></td>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=bttnPrintPriceList onClick="printPriceList()">Print Price List</button></td>
		</tr>
		<tr>
		<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" onclick="messageHistory()">SMS Message History</BUTTON></td>
        <td><BUTTON class=std style="width:200px;height:100px;font-size:12px" onclick="emailHistory()">Email Message History</BUTTON></td>
        <% if storeType <> 0 then %>
        <td><BUTTON class=std style="width:200px;height:100px;font-size:12px" onclick="plantManifests()">Plant/Drop Store Manifests</BUTTON></td>
        <% end if %>
        </tr>

	</form>
</table>
</BODY>
</HTML>