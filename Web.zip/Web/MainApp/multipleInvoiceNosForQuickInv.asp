<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim invoice
	dim deptStartIndex
	dim selectedDept
	dim onHold, addOrEdit
	dim actionString
	dim submitAction
	dim validate 
	dim noOfInv, counter
	dim alertMessage
	dim targetPage
		
	alertMessage =""
	actionString = Request.QueryString("userAction")	
	if IsEmpty(actionString) then
		set invoice = Session("invoice")
		noOfInv = invoice.getNoOfInvoices()
		targetPage = Request.QueryString("targetPage")
		select case targetPage
			case "quick"
					collectInputDataFromQueryString
			case "prompt"
					collectInputDataFromForm
		end select
	else
		collectInputDataFromForm
		if actionString ="submit" then
			submitAction = Request.QueryString("submit")
			if submitAction ="ok" then
				validate =  validateInvNumber()
				if validate then
					saveInvoice
				end if
			else
				Response.Redirect "quickInvoice.asp?userAction=newInvoiceNo&submit=cancel" _
									& "&addOrEdit=" & addOrEdit _
									& "&dept=" & selectedDept & "&deptIndex=" & deptStartIndex 
			end if
		end if
	end if
	
	sub collectInputDataFromForm()
		dim goToPage
		
		addOrEdit = Request.Form("addOrEdit")
		selectedDept = Request.Form("selectedDept")
		deptStartIndex = Request.Form("DeptPageCount")
	end sub
	
	sub collectInputDataFromQueryString()
		addOrEdit = Request.QueryString("addOrEdit")
		selectedDept = Request.QueryString("dept")
		deptStartIndex = Request.QueryString("deptIndex")
	end sub
	
	sub saveInvoice()
		dim intLoop
		dim aInvoiceNo
		dim invoicesDictionary
		dim invoicesArray
		dim aInvoice
		dim ObjMiscSetUp
		dim oneDiscount
		dim taxCodes
		dim tagsSameAsInvNos
			
		set invoice = Session("invoice")
		set invoicesDictionary = invoice.splitInvoice()
		invoicesArray = invoicesDictionary.Items
		select case addOrEdit
			case "add"
					invoice.invoiceNo = Request.Form("txtInvNo")(1)
					for intLoop=2 to Request.Form("txtInvNo").Count
						aInvoiceNo = Request.Form("txtInvNo")(intLoop)
						set aInvoice = invoicesArray(intLoop-2)
						aInvoice.invoiceNo = aInvoiceNo
					next
			case "edit"
					for intLoop=1 to Request.Form("txtInvNo").Count
						aInvoiceNo = Request.Form("txtInvNo")(intLoop)
						set aInvoice = invoicesArray(intLoop-1)
						aInvoice.invoiceNo = aInvoiceNo
					next
		end select
		saveInvoiceToDatabase
	end sub
	
	sub saveInvoiceToDatabase()
		dim empId
		dim terminalId
		dim custSeqNumber
		dim invNumber
		dim empName, storeName
		on error resume next
		custSeqNumber = Session("customersequencenumber")
		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")
		invoice.saveInvoice addOrEdit, empId, terminalId, 0, empName, storeName, true
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Multiple Invoice Numbers For Quick Invoice saveInvoiceToDatabase- saveInvoice"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		invNumber = invoice.getTicketNosForPrinting()
		Response.Redirect "customerfunctions.asp?userAction=print&addOrEdit=" _
							& addOrEdit & "&ticketNumber=" & invNumber _
							& "&invoiceType=Q&customerseq=" & custSeqNumber
	end sub
	
	
			
	function validateInvNumber()
		dim ssql
		dim storeId
		dim objResultSet
		dim invNos, aInvoiceNo
		dim intLoop
		dim retval
		dim tempInvNosList()
		dim occurence
		dim counter
		dim noOfElements
		
		retval =true
		storeId = Session("storeID")
		invNos = ""
		Redim tempInvNosList(Request.Form("txtInvNo").Count)
		noOfElements = Request.Form("txtInvNo").Count
		for intLoop=1 to Request.Form("txtInvNo").Count
			aInvoiceNo = Request.Form("txtInvNo")(intLoop)
			tempInvNosList(intLoop-1) = UCase(aInvoiceNo)
			if aInvoiceNo = "" then
				set invoice = Session("invoice")
				noOfInv = invoice.getNoOfInvoices()
				retval = false
				Session("errorMessage") = "Must enter all invoice numbers. Go back and enter all number(s)."
				Response.Redirect "invoiceErrorMessages.asp"
				exit for
			else
				invNos =  invNos &  "'" & aInvoiceNo & "',"
			end if
		next
		
		invNos = Left(invNos, Len(invNos) - 1)
		intLoop = 1
		while intLoop <= noOfElements and retval
			aInvoiceNo = Request.Form("txtInvNo")(intLoop)
			occurence = 0
			for counter = 0 to noOfElements -1
				if tempInvNosList(counter) = UCase(aInvoiceNo) then
					occurence = occurence + 1
					if occurence > 1 then
						retval = false
						Session("errorMessage") = aInvoiceNo &  " is repeated multiple times. Go back and enter new number(s)."
						Response.Redirect "invoiceErrorMessages.asp"
						exit for
					end if
				end if
			next
			intLoop = intLoop +1
		wend
		
		if retval then
			ssql = "Select invoiceNumber from Ticket where storeId=" & storeId _
					& " And invoiceNumber IN (" & invNos & ")"
			set objResultSet = getDisconnectedRecordset(ssql)
			if objResultSet.Recordcount > 0 then
				retval =false
				invNos = ""
				objResultSet.MoveFirst
				while not objResultSet.eof
					invNos =  invNos & " " & objResultSet.Fields("invoiceNumber").Value
					objResultSet.MoveNext
				wend
				Session("errorMessage") = invNos &  " are duplicate invoice number(s). Go back and enter new number(s)."
				Response.Redirect "invoiceErrorMessages.asp"
			end if
		end if
		validateInvNumber = retval
	end function
	
	
%>
<HTML>
<HEAD>
<TITLE>Multiple Invoice Numbers</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
	var lastFocusControl;
function txtInvNo_onblur() {
	lastFocusControl = event.srcElement;
}
	
//-->
</SCRIPT>
</HEAD>
<script language="javascript" type="text/javascript">
	var alertMessage = null;
	function submitForm(userAction) {
		document.multiInvNo.action = "?userAction=submit&submit=" + userAction;
		document.multiInvNo.submit();
	}
	function checkForAlertMessages() {
		<%
			if Len(alertMessage) > 0 then
			Response.Write "alertMessage='"
			Response.Write alertMessage
			Response.Write "'" 
			end if
		%>
		if (alertMessage != null){
			cbs_alert (alertMessage);
		}
	}
</script>
<BODY leftMargin=0 topMargin=0 onLoad="checkForAlertMessages();">
<!-- #include file="../include/banner.inc" -->
<H1>Enter Invoice Numbers</H1>
<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
	<FORM id="multiInvNo" name="multiInvNo" action="multipleInvoiceNosForQuickInv.asp" method="post">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<%
		counter = 1
		while counter <= noOfInv
	%>
		<tr>
			<td width=50px></td>
			<td class="label">Enter Invoice Number</td>
			<td>
				<INPUT id="<%= counter%>" name="txtInvNo" class=text onblur="txtInvNo_onblur()" style="width:250px;">
			</td>
		</tr>
	<%	
		counter = counter + 1 			
		wend
	%>
		<tr>
			<td width=50px></td>
			<td></td>
			<td align=center>
				<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align="center" width="60px">
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick= "submitForm('ok')">
						</td>
						<td align="center" width="60px">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="submitForm('cancel');">
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<TR height=20px></TR>
		<tr>
			<td colspan=3>
				<!-- #include file="../include/keyboard.inc" -->
			</td>
		</tr>
	</form>
</table>
</BODY>
</HTML>

