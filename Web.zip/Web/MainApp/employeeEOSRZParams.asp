<%@ Language=VBScript %>
<% option explicit %>

<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!-- #include file="CheckSessionExpiry.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("reportId")%>
<%	
	dim l_reportID
	dim l_StartDate
	dim l_EndDate
	dim paramStatus
	dim userAction 
	dim l_storeID
	dim l_terminalID
	dim l_terminalName
	dim l_employeeID
	dim l_employeeName
	dim l_startingAmt
	dim cashOutRst, cashRst
	dim endingAmtForCashout
	dim ObjMiscSetup
	dim sqlTxt2
	
	set Session("objRP") = Server.CreateObject("CBSReports.clsParams")

	l_storeID = session("storeID")
	l_terminalID = session("terminalID")
	l_employeeID = session("employeeID")
	l_reportID = IIf(Trim(Request.QueryString("reportID")) = "", 0, Clng(Request.QueryString("reportID")))	


    dim userIPAddress, printerIP, printerName
	getCashDrawerFields()
	
	if not IsObject(Session("miscSetUp")) then
		initializeMiscSetup
	end if
	set ObjMiscSetup = Session("miscSetUp")	
	if ObjMiscSetup.Count > 0 then
		endingAmtForCashout = ObjMiscSetup.Item("endingAmtForCashout")
		if endingAmtForCashout then
			endingAmtForCashout = 1
			sqltxt2 = "select top 1 endingAmount as CashAmt" _
				& " from cashout where storeid =" & l_storeid & " and terminalid = " & l_terminalid  _
				& " order by enddate desc "
			set cashRst = getDisconnectedRecordset(sqltxt2)
			if not cashRst.bof and not cashRst.eof then
				l_startingAmt = cashRst("cashAmt")
			end if	
		else
			endingAmtForCashout = 0
		end if		
	else
		endingAmtForCashout = 0
	end if		
	
	
	
	initializeForm()
	
	If GetReportParams(l_reportID, True, "", 0)= "NEW" Then
		Session("objRP").rangeStartDate = l_startDate
		Session("objRP").rangeEndDate = l_endDate
		Session("objRP").terminalID = l_terminalID
		Session("objRP").employeeID = l_employeeID
	End if	
	
	function initializeForm()
		dim sqltxt
		dim cashRst
		sqltxt = "select dateadd(minute,1,max(c.enddate)) as startDate, getdate() as enddate, e.employeeName, t.name as terminalName " _
			 & " from cashOut c, employee e, terminal t where " _
			 & " c.storeid =" & l_storeid & " and c.terminalid = " & l_terminalid & " and e.employeeid = " & l_employeeid _
			 & " and c.terminalid = t.terminalid group by e.employeeName, t.name"
		set cashOutRst = getDisconnectedRecordset(sqltxt)
		if not cashOutRst.bof and not cashOutRst.eof then
			l_startDate = cashOutRst("startDate")
			l_endDate = cashOutRst("endDate")
			l_employeeName = cashOutRst("employeeName")
			l_terminalName = cashOutRst("terminalName")

		end if
		cashOutRst.close
		set cashOutRst = nothing	
	end function	

	function getCashDrawerFields()
	    dim query, rs


	    printerIP = getPrinterShortPath()

        query = " select storehardware.cashdrawertype, isnull(printer.printername, '') as printername "
        query = query & " from storehardware "
        query = query & " left outer join printer on storehardware.cashdrawerattachedprinterid = printer.printerid "
        query = query & " where storehardware.hardwaretype = 'CD' "
        query = query & " and storehardware.terminalid = " & session("terminalid")

        set rs = getdisconnectedrecordset(query)
        if rs.recordcount > 0 then
            printerName = Replace(rs("printername"), "'", "\'")
        end if


        userIPAddress = getLocalPrinterAddress(session("terminalid"))

	end function
%>

<HTML>

<HEAD>

<TITLE>Report Parameter Selection</TITLE>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="/script/cashdrawer.js"></script>


<script type="text/javascript">
    history.forward();
</script>

</HEAD>

<script language="javascript" type="text/javascript">

	function submitForm() {
		document.cashOutForm.submit();
	}
	
	function closeForm() {
		document.cashOutForm.action = "employeemenu.asp";
		document.cashOutForm.submit();
	}
	function cashDrawerOpen(){
		var url = "http://<%=userIPAddress%><%=printerIP%>/openCashDrawer"
        OpenCashDrawer(url, '<%= printerName %>');
        return false;
	}
	
	function calculateValue(element){
		var input1 = String(element.value)
		if (isNaN(input1)) {
			if (input1.indexOf("+") != -1) {
				var strArry = input1.split("+")
				var arraySpot = 0;
				var newVal = 0.0;
				while (arraySpot < strArry.length) {
					newVal = newVal + parseFloat(strArry[arraySpot]);
					arraySpot+=1;
				}
				element.value = parseMoney(newVal);
			}
			else {
			element.value = 0;
			}
		}
		else {
			element.value = parseMoney(input1);	
		}		
	}
	
	function handler(NextName){
		var key;
		e = window.event;
		key = e.keyCode;
		if (key == 13) {
			document.all(NextName).focus();
			return false;
		}
		return true;
	}	
	
</SCRIPT>

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="JavaScript" src="../script/validation.js"></script>



<!-- #include file="../include/banner.inc" -->

<BODY topmargin=0 leftmargin=0>

<H1>Select Report Parameters </H1>

<FORM id="cashOutForm" name="cashOutForm" action="report.asp" method="POST" onsubmit="return false">

	<input type="hidden" name="reportID" value="<%= l_reportID %>">
	<input type="hidden" name="storeID" value="<%= l_storeID %>">
	<input type="hidden" name="terminalID" value="<%= l_terminalID %>">
	<input type="hidden" name="rangeStartDate" value="<% = l_startDate %>">
	<input type="hidden" name="rangeEndDate" value="<% = l_endDate %>">
	<!-- 
	<TABLE ALIGN=center WIDTH="400px" BORDER=1 CELLSPACING=1 CELLPADDING=5 >
	-->

	<TABLE ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=1 CELLPADDING=0 >
		<tr width=100%><td align=center><b><%= Request.QueryString("reportName") %><b></td></tr> 
	</TABLE>
	
	<TABLE ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=1 CELLPADDING=0 >

	<!-- <tr height=30px><td>&nbsp;</td></tr> -->

		<!-- First display the standard selection criteria -->
			
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Terminal: </td>
				<td align=left ><B> &nbsp;<%= l_terminalName %> </b>
				</td>
				<td rowspan=18>
					<INPUT class=touchnoborder id=ok name=ok type=button value="" onClick="submitForm();" 
						style="background-image:url(../images/Ok.gif);"><br><br>
					<INPUT class=touchnoborder id=close name=close type=button value="" onClick="closeForm();" 
						style="background-image:url(../images/Cancel.gif);">
					<br><br>
					<BUTTON <%sec_DWP("opencashdrawer")%> class=std style="width:100px;height=50px;font-size:12px" name=bttnCashDrawer onClick="cashDrawerOpen()">Open Cash<br>Drawer</button>				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Employee: </td>
				<td align=left > <b>&nbsp;<%= l_employeeName %></b>
				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Start Date: </td>
				<td align=left > <b> &nbsp;<%= l_startDate %> </b>
				</td>

			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">End Date: </td>
				<td  align=left width = 50%> <b> &nbsp;<%= l_endDate %></b>
				</td>
			</tr>

			<tr height=30px width=100%>
				<td width = 50% class = "label" align=right Style="Font-weight=normal">Starting Amount: </td>
				<td width = 50% >
					<INPUT type=text align=left size=11 Maxlength="9" id=rangeStartAmount name=rangeStartAmount 
					<%if endingAmtForCashout then%>
						value="<%=l_startingAmt%>" readonly
					<% else %>	
						value="<%=Session("objRP").rangeStartAmount%>" 
					<%end if%>
					onkeyDown="return handler('nbrOf1Cents')" onFocus="(this.select())" >
				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$0.01: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf1Cents name=nbrOf1Cents value="<%=Session("objRP").nbrOf1Cents%>" onkeyDown="return handler('nbrOf5Cents')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$0.05: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf5Cents name=nbrOf5Cents value="<%=Session("objRP").nbrOf5Cents%>" onkeyDown="return handler('nbrOf10Cents')" onFocus="(this.select())">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$0.10: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf10Cents name=nbrOf10Cents value="<%=Session("objRP").nbrOf10Cents%>" onkeyDown="return handler('nbrOf25Cents')" onFocus="(this.select())">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$0.25: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf25Cents name=nbrOf25Cents value="<%=Session("objRP").nbrOf25Cents%>" onkeyDown="return handler('nbrOf1Dollars')" onFocus="(this.select())" >
				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$1: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf1Dollars name=nbrOf1Dollars value="<%=Session("objRP").nbrOf1Dollars%>" onkeyDown="return handler('nbrOf5Dollars')" onFocus="(this.select())">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$5: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf5Dollars name=nbrOf5Dollars value="<%=Session("objRP").nbrOf5Dollars%>" onkeyDown="return handler('nbrOf10Dollars')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$10: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf10Dollars name=nbrOf10Dollars value="<%=Session("objRP").nbrOf10Dollars%>" onkeyDown="return handler('nbrOf20Dollars')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$20: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf20Dollars name=nbrOf20Dollars value="<%=Session("objRP").nbrOf20Dollars%>" onkeyDown="return handler('nbrOf50Dollars')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$50: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf50Dollars name=nbrOf50Dollars value="<%=Session("objRP").nbrOf50Dollars%>" onkeyDown="return handler('nbrOf100Dollars')" onFocus="(this.select())" >
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$100: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf100Dollars name=nbrOf100Dollars value="<%=Session("objRP").nbrOf100Dollars%>" onkeyDown="return handler('checkAmount')" onFocus="(this.select())">
				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Check Amount: </td>
				<td width = 50%  align=left><INPUT type=text size=9  id=checkAmount name=checkAmount onchange="calculateValue(this)" value="<%=Session("objRP").checkAmount%>" onkeyDown="return handler('ccAmount')" onFocus="(this.select())">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Credit Card Amount: </td>
				<td width = 50%  align=left><INPUT type=text size=9  id=ccAmount name=ccAmount onchange="calculateValue(this)" value="<%=Session("objRP").ccAmount%>" onkeyDown="return handler('tradeAmount')" onFocus="(this.select())">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Trade Amount: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=tradeAmount name=tradeAmount onchange="calculateValue(this)" value="<%=Session("objRP").tradeAmount%>" onkeyDown="return handler('couponAmount')" onFocus="(this.select())">
				</td>
			</tr>
			<!--MWiemann added coupon payment 3.14.04 -->
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Coupon Amount: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=couponAmount name=couponAmount onchange="calculateValue(this)" value="<%=Session("objRP").couponAmount%>" 
					<% if endingAmtForCashout then %> 
						onKeyDown="return handler('endingAmount')"
					<% else %>	
						onkeyDown="return handler('ok')"
					<% end if %>	 onFocus="(this.select())">
				</td>
			</tr>
			<!--MWiemann added ending amount for Bennies 11.18.04 -->
			<%if endingAmtForCashout then %>
			<tr height=30px>			
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Ending cash in drawer: </td>
				<td width = 50%  align=left> <INPUT type=text size=9 Maxlength="9" id=endingAmount name=endingAmount 
				value="<%=Session("objRP").endingAmount%>" onkeyDown="return handler('ok')" onFocus="(this.select())"></td>	
			</tr>
			<% end if %>
	</table>
</form>
</BODY>
</HTML>
