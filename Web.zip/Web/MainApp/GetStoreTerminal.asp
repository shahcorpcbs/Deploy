<%@ Language=VBScript %>

<%option explicit%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>

<% 
	dim refresh
	
	If Request.Form("PageAction") = "SetStoreTerminal" then
		Response.Cookies("storeID") = Request.Form("Store")
		Response.Cookies("terminalID") = Request.Form("Terminal")
		Response.Cookies("storeGUID") = Request.Form("storeGUID")

		Response.Cookies("storeID").Expires = dateadd("yyyy", 10, now())
		Response.Cookies("terminalID").Expires = dateadd("yyyy", 10, now())
		Response.Cookies("storeGUID").Expires = dateadd("yyyy", 10, now())

	    refresh = true

	end if
%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>Home</title>
	<link href="/script/stylesheet.css" rel="stylesheet" type="text/css">
	<script LANGUAGE="javascript">
	<!--
		function onChangeStore() {
			if(document.getElementById("Store").value == "") {
				return;
			}
			var pa;
			var frm;
			frm = document.getElementById("GetStoreTerminalForm");
			pa = document.getElementById("PageAction");
			pa.value = "GetTerminal";
			frm.submit();
		}
		
		function onSubmitButtonClick() {
			var pa;
			var frm;
			var st;
			var term;
			st = document.getElementById("Store");
			term = document.getElementById("Terminal");
			if(st.value == "") {
				alert("Select a store","CBS Error");
				st.focus();
				return;
			}
			if(term.value == "") {
				alert("Select a terminal","CBS Error");
				term.focus();
				return;
			}
			frm = document.getElementById("GetStoreTerminalForm");
			pa = document.getElementById("PageAction");
			pa.value = "SetStoreTerminal";
			frm.submit();
		}
		
		function refresh() {
            document.GetStoreTerminalForm.action = "/mainapp/start.asp";
            document.GetStoreTerminalForm.submit();
		}
		
	//-->
</script>

	
</head>

<body leftmargin="0" topmargin="0" <%if refresh then%>onload="refresh();"<%end if%>>

<%
	dim remoteaddr:  remoteaddr = Request.ServerVariables("REMOTE_ADDR")
%>

<div style="margin:100px;text-align:center">
<h1>
Your IP address is: <%=remoteaddr%>
</h1>

<form name="GetStoreTerminalForm" id="GetStoreTerminalForm" method="POST">
	<input type="hidden" name="PageAction" id="PageAction" value="">

	<%
		'Get all stores and terminals details..
		dim storeSQL
		dim storeRs
		storeSQL = "SELECT storeID, storeNumber, name, guid FROM Store"
				
		Set storeRs = GetDisconnectedRecordset(storeSQL)
		If storeRs Is Nothing Or storeRs.EOF then
			'Give an error message
			dim errorMessage
			errorMessage = "Failed to get list of stores"
			dim el
			set el = Server.CreateObject("Scripting.Dictionary")
			set Session("errorList") = el
			el.Add "Error1" , errorMessage
			Response.Redirect "/include/error.asp"
			set el = nothing
		else
			storeRs.MoveFirst
		End If		
	%>

	<% if trim(storeRs("storeID")) = trim(Request.Form("Store")) then %>
	<input type="hidden" name="storeGUID" id="storeGUID" value="<%=storeRs("guid")%>">
	<% end if %>

	<table align=center cellspacing=0 cellpadding=10 border=0>
	<tr>
	<td>Select a store</td>
	<td>
	<select name="Store" id="Store" onChange="onChangeStore();">
		<% if Request.Form("Store") = "" then %>
			<option selected value="">Select a Store
		<% Else  %>
			<option value="">Select a Store
		<% end if %>
		
		<%
			while not storeRs.EOF
		%>
		<% 
			dim reqvar, rsVar
			reqvar = CStr(Request.Form("Store"))
			rsVar = cstr(storeRs("storeID"))
			If reqVar = rsVar then %>
			<option selected VALUE="<%= storeRs("storeID") %>"><%= storeRs("name") %> 
		<% Else  %>
			<option VALUE="<%= storeRs("storeID") %>"><%= storeRs("name") %>
		<% End If %>
		
		<%
			storeRs.MoveNext
			wend
			storeRs.close
			set storeRs = nothing
			
		%>
	</select>
	</td>
	</tr>
	
	<%
		'Get all stores and terminals details..
		dim terminalSQL
		dim terminalRs
				
		if Request.Form("Store") <> "" and Request.Form("PageAction") = "GetTerminal" then
			terminalSQL = "SELECT isnull(clientterminal.RemoteAddr, '') as RemoteAddr, terminal.terminalID, name + isnull(' - ' + clientterminal.RemoteAddr, '') as name FROM Terminal "
			terminalSQL = terminalSQL & " left outer join clientterminal on terminal.terminalid = clientterminal.terminalid "
			terminalSQL = terminalSQL & " WHERE storeID = " & Request.Form("Store")
			
			'Get the terminials for Selected Store
			Set terminalRs = GetDisconnectedRecordset(terminalSQL)
			If terminalRs Is Nothing Or terminalRs.EOF then
				'Give an error message
				errorMessage = "Failed to get list of terminals"
				set el = Server.CreateObject("Scripting.Dictionary")
				set Session("errorList") = el
				el.Add "Error1" , errorMessage
				Response.Redirect "/include/error.asp"
				set el = nothing
			else
				terminalRs.MoveFirst
			End If		
	%>
		<tr>
		<td>Select a terminal</td>
		<td>
		<select name="Terminal" id="Terminal">
			<option selected value="">Select a Terminal
			<%
				while not terminalRs.EOF
			%>
					<option VALUE="<%= terminalRs("terminalID") %>" <%if remoteaddr = terminalRs("RemoteAddr") then%>selected<%end if%>><%= terminalRs("name") %></option>
			<%
					terminalRs.MoveNext
				wend
			%>
		</select>
		</td>
		</tr>
		
		<tr><td align=center valign=middle colspan=2>
		<input type="button" name="SubmitButton" id="SubmitButton" value="Submit" style="height:50px;width=100px" onClick="onSubmitButtonClick();">
		</td></tr>
	<% End If %>
	

	</table>
</form>

</div>

</body>

</html>