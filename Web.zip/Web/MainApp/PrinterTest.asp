<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	Session("storeID") = 1
	Session("terminalID") = 2
	Session("employeeID") = 2
	Session("customerSequenceNumber") = 2
%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->

<HTML>
<HEAD>
	<STYLE>
		BODY {
			color:#111111;
			background-color:#FFFFFF;
			font-family:Tahoma;
			font-size:11px;
		}
		TABLE {
			color:#CDCAB6;
			background-color:#111111;
			font-family:Tahoma,Arial;
			font-size:11 px;
		}
		TD {
			color:#111111;
			background-color:#CDCAB6;
			font-family:Tahoma,Arial;
			font-size:11px;
		}
		input {
			color:#111111;
			font-family:Tahoma,Arial;
			font-size:11px;
		}
	</STYLE>

</HEAD>
<BODY onLoad="PopulateLocalPrinters(document.getElementById('select1'), 'Fax');">
<!-- #include file="../include/localprinter.inc" -->

<SCRIPT LANGUAGE=javascript>
	<!--
		function DPrint() {
			PrintDetailedInvoice(document.getElementById("txtDTicketNo").value);
		}
		function CPrint() {
			PrintCounterSaleInvoice(document.getElementById("txtCTicketNo").value);
		}
		function QPrint() {
			PrintQuickInvoice(document.getElementById("txtQTicketNo").value);
		}
		function TagPrint() {
			PrintTagsForInvoice(document.getElementById("txtTagTicketNo").value);
		}
		function PickupPrint() {
			PrintPickupInvoice(document.getElementById("txtPickupTicketNos").value);
		}
		function Populate() {
			var lst;
			lst = document.getElementById("select1");
			cbs_alert("calling");
			PopulateLocalPrinters(lst, "a");
		}
		 function PrintCounterSaleInvoice(tn) {
			if(LocalPrinter) {
				LocalPrinter.PrintCounterSaleInvoice(tn);
			}
		 }
	//-->
	</SCRIPT>
	
<h2>Printer Test Page</h2>
<FORM action="" method=get id=form1 name=form1>
<SELECT id=select1 name=select1>
	<OPTION value="">Please Select</OPTION>

</SELECT><br><br>
<INPUT type="button" value="Button" id=button1 name=button1 onClick="Populate();">
<BR><br>
<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=6>
	<TR>
		<TD>Ticket Number</TD>
		<TD><INPUT id=txtDTicketNo name=txtDTicketNo value=140 ></TD>
		<TD><INPUT type="button" value="Print Detailed Invoice" id=submit1 
				   name=submit1 onClick="DPrint();"></TD>
	</TR>
	<TR>
		<TD>Ticket Number</TD>
		<TD><INPUT id=txtCTicketNo name=txtCTicketNo value=140 ></TD>
		<TD><INPUT type="button" value="Print Counter Sale Invoice" id=submit5 
				   name=submit5 onClick="CPrint();"></TD>
	</TR>
	<TR>
		<TD>Ticket Number</TD>
		<TD><INPUT id=txtQTicketNo name=txtQTicketNo value=106></TD>
		<TD><INPUT type="button" value="Print Quick Invoice" id=submit2 
		            name=submit2 onClick="QPrint;"></TD>
	</TR>
	<TR>
		<TD>Ticket Number</TD>
		<TD><INPUT id=txtTagTicketNo name=txtTagTicketNo value=140></TD>
		<TD><INPUT type="button" value="Print Tags For Invoice" id=submit3 name=submit3 
		              onClick="TagPrint();"></TD>
	</TR>
	<TR>
		<TD>Ticket Number</TD>
		<TD><INPUT id=txtPickupTicketNos name=txtPickupTicketNos value="169,170,171"></TD>
		<TD><INPUT type="button" value="Print Pickup Invoice" id=submit4 name=submit4 
		              onClick="PickupPrint();"></TD>
	</TR>
</TABLE>

	
</FORM>

</BODY>
</HTML>
