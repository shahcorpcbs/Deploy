<%@ Language=VBScript %>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim actionString
	dim destFile
	dim sourceFile
	dim device
	dim ssql
	dim cameraList
	dim sourceExt
	dim wwwTools, regTools
	dim imgID
	dim splitChunks
	

	dim targetPage
	dim lineNumber
	dim userAction
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim colorSet, upchargeSet, patternSet
	dim dueDateSet
	dim dueDate
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim originatingPage
	
	
	targetPage = Request.QueryString("targetPage")
	if targetPage = "" then
		targetPage = Request.Form("tPage")
	end if
	

	select case targetPage
		case "quick"
				'userAction = Request.QueryString("userAction")
				dueDateSet = Request.QueryString("isDueDateSet")
				lineNumber = Request.QueryString("lineNumber")
				deptStartIndex = Request.Form("DeptPageCount")
				addOrEdit = Request.Form("addOrEdit")
				selectedDept = Request.Form("selDeptId")
		case "detail", "counterSale"
				lineNumber = Request.QueryString("lineNumber")	
				dueDateSet = Request.Form("isDueDateSet")
				dueDate = Request.Form("txtDueDate")
				curr_LineNo = Request.Form("lineNumber")
				selectedDept = Request.Form("selectedDept")
				itemsStartIndex = Request.Form("ItemPageCount")
				upChargeStartIndex = Request.Form("upChargePageCount")
				colorsStartIndex = Request.Form("colorsPageCount")
				patternStartIndex = Request.Form("PatternPageCount")
				deptStartIndex = Request.Form("DeptPageCount")
				addOrEdit = Request.Form("addOrEdit")
				upchargeSet = Request.Form("upchargeSet")
				colorSet = Request.Form("colorSet")
				patternSet = Request.Form("patternSet")
				selItemId = Request.Form("selItemId")
				selUpchargeValue = Request.Form("selUpcharge")
				selColorValue = Request.Form("selColor")
				selPatternValue = Request.Form("selPattern")
				originatingPage = Request.Form("originPage")
	end select


	if lineNumber = "" then
		lineNumber = Request.Form("lineNumber")
	end if
	

	
	actionString = Request.QueryString("action")
	device = Trim(Request.QueryString("device"))
	if device = "" then
		device = Request.Form("txDevice")
	end if
	
	
	imgID = Trim(Request.Form("imgID"))
	if imgID = "" then
		ssql = "SELECT * from CapturedImages"
		set cameraList = getDisconnectedRecordset(ssql)
		imgID = cameraList.RecordCount + 1
		cameraList.Close
		set cameraList = nothing
	end if
	
	
	


	if device = "" then
		ssql = "SELECT brand, hardwareID from StoreHardware where hardwareType = 'IC' and model = 'default' and terminalid = '" & session("terminalid") & "'"
	else
		ssql = "SELECT brand, hardwareID from StoreHardware where hardwareType = 'IC' and hardwareID = '" & device & "'"
	end if

	set cameraList = getDisconnectedRecordset(ssql)
	
	if cameraList.EOF then
		cameraList.Close
		set cameraList = nothing
			
		ssql = "SELECT brand, hardwareID from StoreHardware where hardwareType = 'IC' and model = 'default'"
				
		set cameraList = getDisconnectedRecordset(ssql)
	end if

	if cameraList.EOF then
		cameraList.Close
		set cameraList = nothing
			
		ssql = "SELECT brand, hardwareID from StoreHardware where hardwareType = 'IC'"
				
		set cameraList = getDisconnectedRecordset(ssql)
	end if
			
	if cameraList.EOF then
		sourceFile = ""
	else
		sourceFile = cameraList("brand")
		device = cameraList("hardwareID")
	end if

	sourceExt = "jpg"
	destFile = "capture-" & imgID & "." & sourceExt

	cameraList.Close
	set cameraList = nothing
			



	if actionString <> "submit" then
		'set wwwTools = CreateObject("CBSLoTools.WWW")
		'set regTools = CreateObject("CBSLoTools.Registry")
		
		'wwwTools.CopyURLToFile sourceFile, CStr(regTools.GetWWWRootDir()) & "\\ImageCapture\\" & destFile

		download sourceFile, Request.ServerVariables("APPL_PHYSICAL_PATH") & "\\ImageCapture\\" & destFile
	else
	
			dim sqltxt
			dim nComments
			dim employeeID
			nComments = Request.Form("txComments")
			employeeID = Session("employeeID")
			
			sqltxt = "INSERT INTO CapturedImages (ID, EmployeeID, Origin, ImageFile, Comments) VALUES ('" & imgID & "', '" & employeeID & "', 'invoice', '" & destFile & "', " & DbCreateQryString(nComments) & ")"

			QryExecute(sqltxt)
	end if


	
	function download(url, filename)
	    on error resume next
	' from http://blog.netnerds.net/2007/01/vbscript-download-and-save-a-binary-file/
	' Set your settings
	    strFileURL = url
	    strHDLocation = filename


	' Fetch the file
	    Set objXMLHTTP = CreateObject("MSXML2.XMLHTTP")
	 
	    objXMLHTTP.open "GET", strFileURL, false
	    objXMLHTTP.send()
	 
	    If objXMLHTTP.Status = 200 Then
	      Set objADOStream = CreateObject("ADODB.Stream")
	      objADOStream.Open
	      objADOStream.Type = 1 'adTypeBinary
	 
	      objADOStream.Write objXMLHTTP.ResponseBody
	      objADOStream.Position = 0    'Set the stream position to the start
	 
	      Set objFSO = Createobject("Scripting.FileSystemObject")
	        If objFSO.Fileexists(strHDLocation) Then objFSO.DeleteFile strHDLocation
	      Set objFSO = Nothing
	 
	      objADOStream.SaveToFile strHDLocation
	      objADOStream.Close
	      Set objADOStream = Nothing
	    End if
	 
	    Set objXMLHTTP = Nothing
	end function
		
%>

<HTML>
<HEAD>
<TITLE>Capture Image</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<SCRIPT LANGUAGE="javascript" >

	function captureImage(){
		document.cameraCapture.submit();
	}
	
	function selectCamera(){
		document.cameraCapture.action= "?action=capture&device=" + cameraCapture.cameralist.options[cameraCapture.cameralist.selectedIndex].value;
		document.cameraCapture.submit();
	}

	function submitImage(){
		document.cameraCapture.action= "?action=submit&device=" + cameraCapture.cameralist.options[cameraCapture.cameralist.selectedIndex].value;
		document.cameraCapture.submit();
	}
	
	function goBack(userAction)
	{
		var line
		var page
		var dueDate
			
		page = document.cameraCapture.tPage.value;
			
		switch(page){
			case "quick":
				document.cameraCapture.action ="quickinvoice.asp?userAction=" + userAction
				break;
			case "detail":
				document.cameraCapture.action ="detailedInvoice.asp?userAction=" + userAction
				break;
			case "counterSale":
				document.cameraCapture.action ="counterSale.asp?userAction=" + userAction
				break;
		}
			
		document.cameraCapture.submit();
	}
	
	function setFocus(){
		<%if actionString = "submit" then%>
			goBack("returnFromCapture");
		<%end if%>
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0  onLoad="setFocus()">
<!-- #include file="../include/banner.inc" -->
<H1>Capture Image</H1>
<FORM id="cameraCapture" action = "" name="cameraCapture" method ="POST">

		<font face="Verdana, Helvetica" size=2 color="#000000">
		
		<TABLE width = 90% border="0" cellpadding="10" cellspacing="0" Style = "MARGIN-LEFT: 10px">
		
		<tr align=center><td>
		
		Select Source:
		<BR>
		<SELECT name=cameralist onchange ="selectCamera()">

		<%
			ssql = "SELECT sh.hardwareID, sh.hardwareName, t.name as TerminalName from StoreHardware sh, Terminal t where sh.hardwareType = 'IC' and sh.terminalID = t.terminalID"
			set cameraList = getDisconnectedRecordset(ssql)
			
			while not cameraList.EOF
		%>
			<option <%if device = cameraList("hardwareID") then%>selected<%end if%> value=<%=cameraList("hardwareID")%>><%=cameraList("hardwareName") & " on " & cameraList("TerminalName")%></option>
		<%
			cameraList.MoveNext
			wend
			
			cameraList.Close
			set cameraList = nothing
		%>	
			
		</SELECT>
		</td></tr>
		
		<tr align=center><td>
		
		<IMG src=<%="/ImageCapture/" & destFile%>>
		<BR>
		<INPUT name="editcamera" type=button style="Height:50px" value="Capture New Image" onClick="captureImage()"/>
		
		</td></tr>
		
		<tr align=center><td>
		
		Add Comments:
		<BR>
		<textarea name=txComments rows="3" cols="40"></textarea>
		</td></tr>
		
		<tr align=center><td>

	<INPUT class=touchnoBorder type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitImage()" >&nbsp&nbsp&nbsp&nbsp&nbsp
	<INPUT class=touchnoBorder type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="goBack();">
			</td></tr>
		</font>
		
		
	<INPUT type="hidden" name="isDueDateSet" value="<%= dueDateSet %>">
	<INPUT type="hidden" name="selLineNo" value="<%= lineNumber %>">
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="upchargeSet" value="<%= upchargeSet %>">
	<INPUT type="hidden" name="colorSet" value="<%= colorSet %>">
	<INPUT type="hidden" name="patternSet" value="<%= patternSet %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<INPUT type="hidden" name="txtDueDate" value="<%= dueDate %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	
	
	
		
	
	
	
		<INPUT type="hidden" name="txDevice" class=text value="<%=device%>">
		<INPUT type="hidden" name="imgID" class=text value="<%=imgID%>">

</FORM>
</BODY>
</HTML>

