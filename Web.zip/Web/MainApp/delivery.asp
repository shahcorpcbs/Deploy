﻿<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->
<!--#include file="../include/messages.asp" -->

<%

	const DELIVERY_STATUS_FINISH = 5
	const DELIVERY_STATUS_ADDING = 11
	const DELIVERY_STATUS_VERIFYING = 12
	const DELIVERY_STATUS_PAYMENTS1 = 13
	const DELIVERY_STATUS_MANIFEST = 14
	const DELIVERY_STATUS_UNDELIVERABLE = 15
	const DELIVERY_STATUS_PAYMENTS2 = 16

	const DELIVERY_ITEM_INVOICE_ERROR = -10
	const DELIVERY_ITEM_REMOVED = -1
	const DELIVERY_ITEM_READY = 0
	const DELIVERY_ITEM_ADDED = 1
	const DELIVERY_ITEM_STOP_WARNING = 10
	
	dim deliveryID
	dim deliveryStatus
	dim deliveryDate

	dim useTookan
	dim tookanUsername
	dim tookanPassword

	deliveryID = getReqVar("deliveryID")
	deliveryStatus = getDeliveryStatus(deliveryID)
	deliveryDate = getDeliveryDate(deliveryID)

	useTookan = getMSVar("useTookan")
	tookanUsername = getMSVar("tookanUsername")
	tookanPassword = getMSVar("tookanPassword")

	select case(request.querystring("useraction"))

	case "savepayments"
		savePayments
	case "applypayments"
		adjustCreditCardBatchTotals deliveryID
		applyPayments deliveryID
		createCreditCardBatch deliveryID
	case "removepayments"
		removePayments
		
	case "removeselection"
		removeSelection
	end select

	function getDeliveryStatus(deliveryID)
		dim query, rs
		
		query = " select status from delivery where deliveryid = " & deliveryid
		set rs = getdisconnectedrecordset(query)
		
		getDeliveryStatus = -1
			
		if rs.recordcount > 0 then
			getDeliveryStatus = rs("status")
		end if
		
		set rs = nothing
	end function

	function getDeliveryDate(deliveryID)
		dim query, rs
		
		query = " select deliverydate from delivery where deliverydate is not null and deliveryid = " & deliveryid
		set rs = getdisconnectedrecordset(query)
		
		getDeliveryDate = ""
			
		if rs.recordcount > 0 then
			getDeliveryDate = rs("deliverydate")
		end if
		
		set rs = nothing
	end function
	
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getPendingPaymentsCount(deliveryid)
		dim query, rs
		
		getPendingPaymentsCount = 0
		
		if deliveryid <> "" then
			query = " select count(*) paymentcount from deliverypayment inner join deliverystop on "
			query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
			query = query & " where deliverystop.deliveryid = " & deliveryid
			query = query & " and (deliverypayment.status > 0 and deliverypayment.status <> 10) "
			
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getPendingPaymentsCount = rs("paymentcount")
			end if
		end if
		
	end function

	function getPendingCCPaymentsCount(deliveryid)
		dim query, rs
		
		getPendingCCPaymentsCount = 0
		
		if deliveryid <> "" then
			query = " select count(*) paymentcount from deliverypayment inner join deliverystop on "
			query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
			query = query & " where deliverystop.deliveryid = " & deliveryid
			query = query & " and (deliverypayment.status > 0 and deliverypayment.status <> 10) "
			query = query & " and deliverypayment.paymentmethod = 'Credit Card' "
			
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getPendingCCPaymentsCount = rs("paymentcount")
			end if
		end if
		
	end function
	
	function savePayments() 
		dim query, rs
		dim paymentamount
		dim paymentmethod
		dim paymentnumber
		dim deliverystopid
		
		query = "select * from deliverystop"
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
			deliverystopid = rs("deliverystopid")
			
			paymentamount = request.form("paymentamount_" & deliverystopid)
			paymentmethod = request.form("paymentmethod_" & deliverystopid)
			paymentnumber = request.form("paymentnumber_" & deliverystopid)
			
			query = " update deliverystop set AmountToBeApplied = " & paymentamount
			query = query & ", PaymentMethod = '" & paymentmethod & "'"
			query = query & ", PaymentNumber = '" & paymentnumber & "'"
			query = query & " where deliverystopid = " & deliverystopid

			QryExecute query
			
			rs.movenext
		wend
	end function
	
	function getRouteNamesForDeliveryID(deliveryID)
		dim query, rs
		
		if deliveryID <> "" then
			query = " select distinct route.name as routename from "
			query = query & " route inner join deliverystop "
			query = query & " on route.routenumber = deliverystop.routeid "
			query = query & " where deliveryid = " & deliveryID
			
			set rs = getdisconnectedrecordset(query)
			
			while not(rs.eof or rs.bof)
				if getRouteNamesForDeliveryID <> "" then getRouteNamesForDeliveryID = getRouteNamesForDeliveryID & ", "
				getRouteNamesForDeliveryID = getRouteNamesForDeliveryID & rs("routename")
				
				rs.movenext
			wend
			
			set rs = nothing
		end if
	end function
	
	function applyPayments(deliveryID)
		dim query, rs
		dim terminalID
		dim employeeID
		
		employeeID = Session("employeeID")
		terminalID = Session("terminalID")
		
		query = "execute dbo.PayDeliveryItems " & terminalID & "," & employeeID & "," & deliveryID

		qryexecute query
	end function

	function getMSVar(id)
		dim query, rs
		
		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)
		
		set rs = nothing
	end function

	function getDeliveryItemStatusHTML(status)
		dim result
		
		select case status
			case DELIVERY_ITEM_INVOICE_ERROR
				result = "<span style=""background:#f00;color:#fff;padding:2px"">"
				result = result & "ERROR"
				result = result & "</span>"
			case DELIVERY_ITEM_REMOVED
				result = "<span style=""background:#f00;color:#fff;padding:2px"">"
				result = result & "REMOVED"
				result = result & "</span>"
			case DELIVERY_ITEM_READY
				result = "<span style=""background:#fff;color:#000;padding:2px"">"
				result = result & "READY"
				result = result & "</span>"
			case DELIVERY_ITEM_ADDED
				result = "<span style=""background:#0f0;color:#000;padding:2px"">"
				result = result & "ADDED"
				result = result & "</span>"
			case DELIVERY_ITEM_STOP_WARNING
				result = "<span style=""background:#ff0;color:#000;padding:2px"">"
				result = result & "STOP WARNING"
				result = result & "</span>"
		end select
	
		getDeliveryItemStatusHTML = result
	end function

	function getPaymentStatusHTML(status)
		dim result
		
		select case status
			case 1
				result = "<span style=""background:#f0f;color:#fff;padding:2px"">"
				result = result & "Pending"
				result = result & "</span>"
			case 2
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Pending Batch"
				result = result & "</span>"
			case 10
				result = "<span style=""background:#af0;color:#000;padding:2px"">"
				result = result & "Paid"
				result = result & "</span>"
			case 11
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Request Made"
				result = result & "</span>"
			case 12
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Waiting"
				result = result & "</span>"
			case 13
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Transaction Made"
				result = result & "</span>"
			case -11
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Missing Request"
				result = result & "</span>"
			case -12
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Process Error"
				result = result & "</span>"
			case -13
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Cancelled"
				result = result & "</span>"

		end select
	
		getPaymentStatusHTML = result
	end function


	function getPaymentsForStop(deliverystopid)
		dim query, rs
		
		query = " select isnull(sum(amounttobeapplied), 0) as amount from "
		query = query & " deliverypayment where deliverystopid = " & deliverystopid

		set rs = getdisconnectedrecordset(query)

		getPaymentsForStop = rs("amount")
		
		set rs = nothing
	
	end function
	
	function canMakePaymentOnRoute(routeNumber)
		dim query, rs
		
		canMakePaymentOnRoute = true
		
		query = " select count(*) as cnt from routedepartment where routenumber = " & routenumber
		set rs = getdisconnectedrecordset(query)
		
		if rs("cnt") > 0 then
			canMakePaymentOnRoute = false
		end if
		
		if canMakePaymentOnRoute then
			set rs = nothing
			
			query = " select count(*) as cnt from route where not ((billingResponsibility is null) or not (discountPercent is null)) and routenumber = " & routenumber
			set rs = getdisconnectedrecordset(query)
			
			if rs("cnt") > 0 then
				canMakePaymentOnRoute = false
			end if
		end if
		
		set rs = nothing
	end function
	
	
	function removeSelection()
		dim query, rs
		dim deliveryStopID
		dim deliveryItemID
		
		
		for each deliveryItemID in request.form("selectedDeliveryItem")
			query = " update deliverywillcall set deliverywillcall.deliveryid = null "
			query = query & " from deliverywillcall inner join deliveryitem on "
			query = query & " deliverywillcall.ticketnumber = deliveryitem.ticketnumber "
			query = query & " where deliveryitem.deliveryitemid = " & deliveryItemID
			qryexecute query
			
			query = " update ticket set ticketstatus = 'AC' "
			query = query & " from ticket inner join deliveryitem "
			query = query & " on ticket.ticketnumber = deliveryitem.ticketnumber "
			query = query & " where ticket.ticketstatus = 'OD' "
			query = query & " and deliveryitem.deliveryitemid = " & deliveryItemID
			qryexecute query

			query = " delete deliveryitem where deliveryitemid = " & deliveryItemID
			qryexecute query
			
			
		next
	
		for each deliveryStopID in request.form("selectedDeliveryStop")
			query = " update deliverywillcall set deliverywillcall.deliveryid = null "
			query = query & " from deliverywillcall inner join deliveryitem on "
			query = query & " deliverywillcall.ticketnumber = deliveryitem.ticketnumber "
			query = query & " where deliveryitem.deliverystopid = " & deliveryStopID
			qryexecute query

			query = " update ticket set ticketstatus = 'AC' "
			query = query & " from ticket inner join deliveryitem "
			query = query & " on ticket.ticketnumber = deliveryitem.ticketnumber "
			query = query & " where ticket.ticketstatus = 'OD' "
			query = query & " and deliveryitem.deliverystopid = " & deliveryStopID
			qryexecute query

			query = " delete deliveryitem where deliverystopid = " & deliveryStopID
			qryexecute query
			
			query = " delete deliverystop where deliverystopid = " & deliveryStopID
			qryexecute query
		next
	
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">


<style type="text/css">

.customer_row th {
	background:#DDD;
	border-bottom:1px solid #888;
	height:30px;
}

.customer_row tr {

}

.customer_row td {

	border:3px solid #F6F6F6;
	background:#fff;
}

.directions_row th {
	background:#AAA;

}

.directions_row tr {
	background:#DDD;
}

.directions_row td {

	border:none;
	background:#fff;
}

.customer_invoices th {
	height:20px;
}

.customer_invoices tr {
	background:#DDD;
}

.customer_invoices td {
	border:none;
}

</style>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<script language="javascript" type="text/javascript">


	function savePayments() {
		document.delivery.action = "?useraction=savepayments";
		document.delivery.submit();
	}
	function applyPayments() {
		document.delivery.action = "?useraction=applypayments";
		document.delivery.submit();
	}

	function continueDelivery() {
		if(document.delivery.pendingCCPaymentsCount.value > 0) {
			cbs_alert("Pending credit card payments must be closed before continuing.");
			document.delivery.action = "deliveryCCBatch.asp?deliveryID=<%=deliveryID%>";
			document.delivery.submit();
		}
		else {
			document.delivery.action = "deliveryUndeliverable.asp?deliveryID=<%=deliveryID%>";
			document.delivery.submit();
		}
	}
	

	function removePayments() {
		document.delivery.action = "?useraction=removepayments";
		document.delivery.submit();
	}
	
	function removeSelection() {
		var selectedItems;
		var selectedStops;
		var confirmString;
		
		selectedItems = $("input[name='selectedDeliveryItem']:checked").length;
		selectedStops = $("input[name='selectedDeliveryStop']:checked").length;

		if(selectedItems > 0 || selectedStops > 0) {
			confirmString = "Remove"
			if(selectedItems > 0)
				confirmString += "\n " + selectedItems + " Item(s)";
			if(selectedStops > 0)
				confirmString += "\n " + selectedStops + " Stop(s)";

            cbs_confirm(confirmString, gotoRemoveSel)
		}
		else {
			cbs_alert("Nothing to remove.");
		}
	}

	function gotoRemoveSel() {
        clearConfirmMsg();
        document.delivery.action = "?useraction=removeselection";
        document.delivery.submit();
	}

	
	function addPayment(deliverystopid, amountdue, defaultpaymentmethod, customersequencenumber) {
			var w = window.open("/mainapp/deliverypayment.asp?" +
			"deliverystopid=" +	deliverystopid +
			"&amounttobeapplied=" + amountdue +
			"&paymentMethod=" + defaultpaymentmethod +
			"&customerseq=" + customersequencenumber,
			"DeliveryPayment",
			"status=no,fullscreen=no,scrollbars=no,width=270,height=250");
	}
	
	
	function exit() {
		document.delivery.action = "deliveryManager.asp"
		document.delivery.submit();
	}
	
	function printDepartmentManifest() {
		var doc;
		
		doc = "";
		
		$(".commercialDepartment").each( function(index, element) {
			if(index > 0)
				doc += '<H6 STYLE="page-break-after:always;">&nbsp;</H6>'	
				
			doc += '<table cellspacing="0" border="0" cellpadding="2" style="width:100%">' + $(element).html() + '</table>'
			
			
		});
		
		var manifest_window = window.open('','','width=300,height=300');
		manifest_window.document.open("text/html");
		manifest_window.document.write(doc);
		manifest_window.document.close();
		manifest_window.print();
		manifest_window.close();
	}
	
	function printManifest() {
		var manifest_window = window.open('','','width=300,height=300');
		manifest_window.document.open("text/html");
		manifest_window.document.write(document.getElementById('manifest').innerHTML);
		manifest_window.document.close();
		manifest_window.print();
		manifest_window.close();
	}
	
	function editDelivery() {
		document.delivery.action = "deliverySelectRoutes.asp?deliveryID=" + document.delivery.deliveryID.value;
		document.delivery.submit();
	}
	

	function SetRowCheckedStatus(row, check, value) {

		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleItemChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "selectedDeliveryItem") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "selectedDeliveryItem") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}
	function ToggleStopChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "selectedDeliveryStop") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "selectedDeliveryStop") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->

<H1>Delivery - Manifest (3/5) <%=getRouteNamesForDeliveryID(deliveryID)%></H1>

<FORM name="delivery" ID="delivery" METHOD=POST onsubmit="return false">

<input type="hidden" name="deliveryID" value="<%=deliveryID%>">
<input type="hidden" name="pendingCCPaymentsCount" value="<%=getPendingCCPaymentsCount(deliveryid)%>" />


<DIV class="cmdbar" style="margin-bottom:1" id="commandButtons">
		<SPAN style="float:left">
<!--
			<BUTTON onclick="removePayments()" >Remove<BR />Payment</BUTTON>
			<BUTTON onclick="applyPayments()" >Apply<BR />Payments</BUTTON>
-->
			<% if deliveryStatus = DELIVERY_STATUS_ADDING then %>
			<BUTTON style="vertical-align: top" onclick="editDelivery()" >Edit<BR />Delivery</BUTTON>
			<BUTTON onclick="removeSelection()" >Remove</BUTTON>
			<% end if %>
		</SPAN>
		<SPAN style="float:left;padding-left:50px;">
			<BUTTON onclick="printManifest()" >Print<BR>All</BUTTON>
			<BUTTON onclick="printDepartmentManifest()" >Print<BR>C. Stops</BUTTON>
		</SPAN>
		<SPAN style="float:right">
			<BUTTON onclick="exit()">Exit</BUTTON>
			<% if deliveryStatus > 0 and deliveryStatus <> DELIVERY_STATUS_FINISH then %>
	    <BUTTON onclick="continueDelivery()">Next</BUTTON>
	    <% end if %>
		</SPAN>
</DIV>	



<DIV id="manifest" name="manifest" style="width:100%;height:625px;font-size:10px;">

<TABLE style="width: 100%">
<TR>
<TD align="left"><H3>Delivery: #<%=deliveryid%></H3></TD>
<TD align="right"><H3>Delivery Date: <%=deliveryDate%></H3></TD>
</TR>
</TABLE>
<TABLE id="manifest_table" style="width:100%" cellspacing="0" border="0" cellpadding="2" style="background:white;">

	<TR align="left">
		<TH style="border-top:2px groove;background:#efefef;border-bottom:1px outset;">&nbsp;</TH>
		<TH style="border-top:2px groove;background:#efefef;border-bottom:1px outset">Stop</TH>
		<TH style="border-top:2px groove;background:#efefef;border-bottom:1px outset" colspan="2">Name/Address</TH>
		<TH style="border-top:2px groove;background:#efefef;border-bottom:1px outset" colspan="4">Notes</TH>
	</TR>
	<TR align="right">
		<TH>&nbsp;</TH>
		<TH align="left">Department</TH>
		<TH align="left">Invoice</TH>
		<TH align="left">Location</TH>
		<TH>Pieces</TH>
		<TH>Price</TH>
		<TH>Discount</TH>
		<TH>Net</TH>
	</TR>

	
	<TR>
		<TD style="background:#eaeaea" valign="center" align="left">&nbsp;</TD>
		<TD style="background:#eaeaea" valign="center" align="left"><span></span></TD>
		<TD style="background:#eaeaea" valign="center" align="left" colspan="2"><span>Store (Start)</span></TD>
		<TD style="background:#eaeaea" valign="center" align="center" colspan="4">&nbsp;</TD>
	</TR>

<%

	if deliveryid <> "" then
	
	dim stopNumber
	
	stopNumber = 0

	query = " select "
	query = query & " deliverystop.*, isnull(customerdelivery.begindate, getdate()) as begindate, customerdelivery.accountType, "
	query = query & " case deliverystop.deliveryphone when '' then dbo.formatPhone(customer.mainareacode, customer.mainphone) else deliverystop.deliveryphone end as deliveryphone, "
	query = query & " customer.customername, "
	query = query & " isnull(customerdelivery.paymenttype, customer.paymenttypename) as defaultpaymentmethod, "
	query = query & " dbo.getAccountBalance(customer.customersequencenumber, getdate()) as customerBalance, "
	query = query & " isnull(convert(varchar(10), customerdelivery.stoporder), '--') as cdorder "
	query = query & " from deliverystop "
	query = query & " inner join customer on deliverystop.customersequencenumber = customer.customersequencenumber "
	query = query & " inner join customerfields on deliverystop.customersequencenumber = customerfields.customersequencenumber "
	query = query & " left outer join customerdelivery on deliverystop.customerdeliveryid = customerdelivery.id "
	query = query & " where "
	query = query & " deliverystop.deliveryid = " & deliveryid
	query = query & " and parentCustomerSequenceNumber is null "
	query = query & " and skipMessageId is null "
	query = query & " order by "
	query = query & " deliverystop.stoporder, "
	query = query & " deliverystop.deliverystopid  "

	set rs = getdisconnectedrecordset(query)
	
	dim invoiceCount
	dim invoiceTotal
	
	invoiceCount = 0
	invoiceTotal = 0

	while not(rs.eof or rs.bof)
		stopNumber = stopNumber + 1

		dim customerInvoiceRS
		dim customerPaymentRS
		dim deliveryAmountDue
		dim deliveryPieceCount
		dim customerAmountDue
		dim customerPieceCount
		dim lastCustomerName
		dim customerAmountDiscounted
		dim deliveryDiscounted
		dim subCustomerCount
		

		subCustomerCount = 0
		deliveryAmountDue = 0
		deliveryPieceCount = 0
		deliveryDiscounted = 0
		
		customerAmountDue = 0
		customerPieceCount = 0
		customerAmountDiscounted = 0
		
		query = " select ticket.*, customer.customerName, invoicetotal - amountpaid as amountdue, ticketcustomer.multipickupcustomername, ticketcustomer.multipickuplocation, dbo.getTotalPieces(ticket.ticketnumber, null) as pieceCount, "
		query = query & " deliveryitem.deliveryitemid, isnull(deliveryitem.amountposted, 0) as amountposted, "
		query = query & " deliveryitem.status, deliveryitem.scanned, dbo.calcTicketAccountDiscount(ticket.ticketnumber) as amountDiscounted, "
		query = query & " dbo.pivotTicketDepartments(ticket.ticketnumber, ', ') as ticketDepartments "
		query = query & " from deliveryitem inner join ticket on "
		query = query & " deliveryitem.ticketnumber = ticket.ticketnumber "
		query = query & " inner join customer on "
		query = query & " ticket.customerSequenceNumber = customer.customerSequenceNumber "
		query = query & " left outer join ticketcustomer on "
		query = query & " ticket.ticketnumber = ticketcustomer.ticketnumber "
		query = query & " where deliverystopid in "

		query = query & " (select " & rs("deliverystopid") & " union select childStop.deliverystopid from deliverystop parentStop "
		query = query & " inner join deliverystop childStop "
		query = query & " on childStop.parentCustomerSequenceNumber = parentStop.customerSequenceNumber and childStop.deliveryID = parentStop.deliveryID "
		query = query & " where parentStop.deliveryStopID = " & rs("deliverystopid") 
		query = query & " and childStop.deliveryID = " & deliveryid & " )"

		query = query & " order by deliverystopid, ticket.ticketnumber "
		
		set customerInvoiceRS = getdisconnectedrecordset(query)


%>
	
	
	<TR  onclick="ToggleStopChecked(this)">

		<TD valign="center" align="left" colspan="4" style="border-top:3px groove;border-bottom:1px outset" >

			<INPUT type="checkbox" name="selectedDeliveryStop" value="<%=rs("deliverystopid")%>" style="position: absolute; left: -100;"  />
			
			<TABLE>
			<TR>
			<TD align="center" valign="center" style="width: 60px;">
			<%=stopNumber%>
			</TD>
			<%if datediff("d", rs("begindate"), date()) <= 14 or rs("pickupRequested") then %>
			<TD>
			<IMG style="float:left" src="/static/icons/48x48/alert.gif" >
			</TD>
			<% end if %>
			
			<TD>
			<div style="font-weight: bold;font-size:.8em">


				<%= trim(rs("customername")) & " [" & rs("cdorder") & "]" %>
				<% if rs("deliveryPhone") <> "" then %>
				&nbsp;&nbsp;<%=rs("deliveryPhone")%>
				<% end if %>
				<% if rs("deliveryaddress") <> "" then %>
				<br><%=replace(rs("deliveryaddress"), vbcrlf, "<br>")%>
				<% end if %>
			<div>
			</TD>
			</TR>
			</table>
		</TD>

		
		
		<TD valign="center" colspan="4" style="border-top:2px groove;border-bottom:1px outset">
			<% if rs("deliverynotes") = "" then %>
			<center>No Notes</center>
			<% else %>
			<%=replace(rs("deliverynotes"), vbcrlf, "<br>")%>
			<% end if %>
		</TD>
	</TR>
	<SPAN <%if rs("accountType") = 1 then%>class="commercialDepartment"<%end if%>>
	
	

		
<%
		if customerInvoiceRS.recordcount > 0 then
		
		query = " select * from deliverypayment "
		query = query & " where deliverystopid = " & rs("deliverystopid")
		query = query & " order by deliverypaymentid "
		
		set customerPaymentRS = getdisconnectedrecordset(query)
		
		
%>
	<TR align="right" >
		<!--<TD style="background: #f8f8f8; text-decoration:underline; font-weight: bold" align="left" colspan="8"><strong><%=customerInvoiceRS("customername")%></strong></TD>-->
	</TR>


<%
		if customerInvoiceRS.recordcount > 0 then
			customerInvoiceRS.movefirst
			lastCustomerName = customerInvoiceRS("customername")
		end if

		while not(customerInvoiceRS.eof or customerInvoiceRS.bof)

			if lastCustomerName <> customerInvoiceRS("customername") then
				subCustomerCount = subCustomerCount + 1
%>
		<TR align="right" >
			<TD style="border-top:1px solid #ddd;padding-left:25px" align="left" colspan="4"><strong>Subtotal</strong></TD>
			<TD style="border-top:1px solid #ddd"><%=customerPieceCount%></TD>
			<TD style="border-top:1px solid #ddd"><%=formatcurrency(customerAmountDue)%></TD>
			<TD style="border-top:1px solid #ddd"><%=formatcurrency(customerAmountDiscounted)%></TD>
			<TD style="border-top:1px solid #ddd"><%=formatcurrency(customerAmountDue - customerAmountDiscounted)%></TD>
		</TR>
		<TR><TD colspan="8" align="center">&nbsp;</TD></TR>
		</SPAN>
		<SPAN <%if rs("accountType") = 1 then%>class="commercialDepartment"<%end if%>>
		<TR align="right" >
			<TD style="background: #f8f8f8; text-decoration:underline;" align="left" colspan="8"><strong><%=customerInvoiceRS("customername")%></strong></TD>
		</TR>
		
<%
				customerAmountDue = 0
				customerPieceCount = 0
				customerAmountDiscounted = 0
			end if
%>
		<TR align="right" valign="top" onclick="ToggleItemChecked(this)">
			<TD align="left">
				<INPUT type="checkbox" name="selectedDeliveryItem" value="<%=customerInvoiceRS("deliveryitemid")%>" />
			</TD>
			<TD align="left">
					<%
						if customerInvoiceRS("multipickupcustomername") <> "" then
							response.write customerInvoiceRS("multipickupcustomername")
						else
							response.write customerInvoiceRS("customername")
						end if
					%>
			</TD>
			<TD align="left">

			<%
				if DateDiff("d", deliveryDate, customerInvoiceRS("duedate")) > 0 then
			%>
				<span style="background-color: #000; color: #fff; padding: 1px 3px;"><%=customerInvoiceRS("invoicenumber")%>&nbsp;<%=server.htmlencode(customerInvoiceRS("duedate"))%></span>&nbsp;<%=customerInvoiceRS("ticketDepartments")%>
			<%
				else
			%>
				<%=customerInvoiceRS("invoicenumber")%>&nbsp;<%=customerInvoiceRS("ticketDepartments")%>
			<%
				end if
			%>

			
			
			
			
			
			</TD>
			<TD align="center"  style="width:100px">
			<%=customerInvoiceRS("multipickuplocation")%>&nbsp;
			</TD>
			<TD><%=customerInvoiceRS("pieceCount")%></TD>

			<TD>
				<%=formatcurrency(customerInvoiceRS("amountdue") + customerInvoiceRS("amountposted"))%>
			</TD>
			<TD><%=formatcurrency(customerInvoiceRS("amountdiscounted"))%></TD>
			<TD><%=formatcurrency(customerInvoiceRS("amountdue") + customerInvoiceRS("amountposted") - customerInvoiceRS("amountdiscounted"))%></TD>
		</TR>
<%
			if customerInvoiceRS("status") = 0 then
			
				deliveryAmountDue = round(deliveryAmountDue + customerInvoiceRS("amountdue") + customerInvoiceRS("amountposted"), 2)
				deliveryPieceCount = deliveryPieceCount + customerInvoiceRS("pieceCount")
				deliveryDiscounted = deliveryDiscounted + customerInvoiceRS("amountdiscounted")
				
				customerAmountDue = round(customerAmountDue + customerInvoiceRS("amountdue") + customerInvoiceRS("amountposted"), 2)
				customerPieceCount = customerPieceCount + customerInvoiceRS("pieceCount")
				customerAmountDiscounted = customerAmountDiscounted + customerInvoiceRS("amountdiscounted")
	
				invoiceCount = invoiceCount + 1
				invoiceTotal = invoiceTotal + customerInvoiceRS("amountdue") + customerInvoiceRS("amountposted")

			end if
			

		
			lastCustomerName = customerInvoiceRS("customername")
			customerInvoiceRS.movenext
		wend

%>

		<% if subCustomerCount > 0 then %>
		<TR align="right" >
			<TD style="border-top:1px solid #ddd;padding-left:25px" align="left" colspan="4"><strong>Subtotal</strong></TD>
			<TD style="border-top:1px solid #ddd"><%=customerPieceCount%></TD>
			<TD style="border-top:1px solid #ddd"><%=formatcurrency(customerAmountDue)%></TD>
			<TD style="border-top:1px solid #ddd"><%=formatcurrency(customerAmountDiscounted)%></TD>
			<TD style="border-top:1px solid #ddd"><%=formatcurrency(customerAmountDue - customerAmountDiscounted)%></TD>
		</TR>
		<% end if %>
		<TR><TD colspan="8" align="center">&nbsp;</TD></TR>
		</SPAN>
<%
		
		while not(customerPaymentRS.eof or customerPaymentRS.bof)
%>

				<TR>
					<TD align="center">
					<% if customerPaymentRS("status") <= 1 and customerPaymentRS("status") >= 0 then %>
					<INPUT type="checkbox" name="selectedPayment" value="<%=customerPaymentRS("deliverypaymentid")%>"  />
					<% else %>
					&nbsp;
					<% end if %>
					</TD>
					<TD><B><%=customerPaymentRS("paymentmethod")%></B></TD>
					<TD align="center"><B><%=getPaymentStatusHTML(customerPaymentRS("status"))%></B></TD>
					<TD>&nbsp;</TD>
					<TD align="right" 
					<% if customerPaymentRS("status") < 1 then %>
					style="text-decoration: line-through;color:#aaa"
					<% end if %> ><B><%=formatcurrency(-customerPaymentRS("amounttobeapplied"))%></B></TD>
					<TD colspan="2">&nbsp;</TD>
				</TR>
<%
			if customerPaymentRS("status") > 0  then
				if customerPaymentRS("status") <> 10 then
					deliveryAmountDue = round(deliveryAmountDue - customerPaymentRS("amounttobeapplied"), 2)
				end if
			end if
			customerPaymentRS.movenext
		wend
%>

<%		if rs("customerBalance") < 0 then %>
				<TR>
					<TD align="center">&nbsp;</TD>
					<TD><B>Account Credit</B></TD>
					<TD align="center"><B>&nbsp;</B></TD>
					<TD>&nbsp;</TD>
					<TD align="right"><B><%=formatcurrency(-rs("customerBalance"))%></B></TD>
					<TD colspan="2">&nbsp;</TD>
				</TR>
<%
			deliveryAmountDue = deliveryAmountDue + rs("customerBalance")
			if deliveryAmountDue < 0 then
				deliveryAmountDue = 0
			end if
		end if %>

				<TR align="right" style="background:#f6f6f6">
					<TD style="border-top:1px solid #ddd;padding-left:25px" align="left" colspan="4"><strong>Total</strong></TD>
					<TD style="border-top:1px solid #ddd"><%=deliveryPieceCount%>::::: <%=rs("deliverystopid")%></TD>
					<TD style="border-top:1px solid #ddd"><%=formatcurrency(deliveryAmountDue)%></TD>
					<TD style="border-top:1px solid #ddd"><%=formatcurrency(deliveryDiscounted)%></TD>
					<TD style="border-top:1px solid #ddd"><%=formatcurrency(deliveryAmountDue - deliveryDiscounted)%></TD>
				</TR>

		</SPAN>
<%


		set customerInvoiceRS = nothing
		set customerPaymentRS = nothing

		else
%>
	</span>
<%
		end if

		if stopnumber mod 20 = 0 then response.flush
		
		rs.movenext
	wend

	set rs = nothing
	
	end if
%>

	<TR>
		<TD style="background:#eaeaea" valign="center" align="center">&nbsp;</TD>
		<TD style="background:#eaeaea" valign="center" align="left"><span></span></TD>
		<TD style="background:#eaeaea" valign="center" align="left" colspan="6"><span>Store (End)</span></TD>
	</TR>
	<TR>
		<TD style="background:#eaeaea"  colspan="8" valign="center" align="right"><span>Total Invoices:<%=invoiceCount%></span></TD>
	</TR>
	
</TABLE>
</DIV>
</FORM>
</BODY>
</HTML>
