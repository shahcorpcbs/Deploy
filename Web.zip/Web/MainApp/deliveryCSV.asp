<%@ Language=VBScript %>
<%option explicit%>
<%
	dim dbname
	
	dbname = request.querystring("dbname")
	if dbname = "" then dbname = "default"
%>

<!--#include file="../include/SystemStartup.asp"-->
<% selectDatabase dbname %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<%
	dim query, rs
	dim cellValue
	dim counter
	dim lineout
	dim deliveryID
	dim routeNumber
	dim i
	
	deliveryID = request.querystring("deliveryID")
	routeNumber = request.querystring("routeNumber")
	
	
	if routeNumber <> "" then
		response.AddHeader "Content-Type", "type=""text"""
		response.AddHeader "Content-Disposition:", "attachment;filename=""route.csv"""
	
		query = ""
		
		query = query & " select 0 as stoporder, store.name as [name], "
		query = query & " store.streetaddress1 as [address1], store.streetaddress2 as [address2], "
		query = query & " store.city as [city], store.state as [state], store.zipcode as [zipcode], "
		query = query & " dbo.formatPhone(store.areacode, store.phonenumber) as [phone] from store where storeid = (select min(storeid) from store)"
		query = query & " union all "
		query = query & " select customerdelivery.stoporder, customerName as [name], "
		query = query & " shippingaddress1 as [address1], shippingaddress2 as [address2], "
		query = query & " shippingcity as [city], shippingstate as [state], shippingzipcode as [zipcode], "
		query = query & " dbo.formatPhone(mainareacode, mainphone) as [phone] "
		query = query & " from customer inner join customerdelivery on customer.customersequencenumber = customerdelivery.customersequencenumber "
		query = query & " where customerdelivery.routeid = " & routeNumber
		query = query & " and customer.isactive = 1 and customerdelivery.active = 1 "
		query = query & " union all "
		query = query & " select 99999 as stoporder, store.name as [name], "
		query = query & " store.streetaddress1 as [address1], store.streetaddress2 as [address2], "
		query = query & " store.city as [city], store.state as [state], store.zipcode as [zipcode], "
		query = query & " dbo.formatPhone(store.areacode, store.phonenumber) as [phone] from store where storeid = (select min(storeid) from store)"
		query = query & " order by 1, 2 "

	else
		response.ContentType = "application/octet-stream"
    	response.AddHeader "Content-Disposition", "attachment; filename=Delivery" & deliveryID & ".csv"
		
		query = ""
		
		query = query & " select 0 as stoporder, store.name as [name], "
		query = query & " store.streetaddress1 as [address1], store.streetaddress2 as [address2], "
		query = query & " store.city as [city], store.state as [state], store.zipcode as [zipcode], "
		query = query & " dbo.formatPhone(store.areacode, store.phonenumber) as [phone] from store where storeid = (select min(storeid) from store)"
		query = query & " union all "
		query = query & " select deliverystop.stoporder, customerName as [name], "
		query = query & " shippingaddress1 as [address1], shippingaddress2 as [address2], "
		query = query & " shippingcity as [city], shippingstate as [state], shippingzipcode as [zipcode], "
		query = query & " dbo.formatPhone(mainareacode, mainphone) as [phone] "
		query = query & " from customer inner join DeliveryStop on customer.customerSequenceNumber = deliverystop.CustomerSequenceNumber "
		query = query & " where deliverystop.DeliveryID = " & deliveryID
		query = query & " union all "
		query = query & " select 99999 as stoporder, store.name as [name], "
		query = query & " store.streetaddress1 as [address1], store.streetaddress2 as [address2], "
		query = query & " store.city as [city], store.state as [state], store.zipcode as [zipcode], "
		query = query & " dbo.formatPhone(store.areacode, store.phonenumber) as [phone] from store where storeid = (select min(storeid) from store)"
		query = query & " order by 1, 2 "
		
	end if
	
	



	
	set rs = getdisconnectedrecordset(query)

	if rs.recordcount > 0 then
		rs.MoveFirst
		
		lineout = ""
		
	  for i = 0 to rs.Fields.Count - 1
	  	if rs.Fields(i).Name <> "customerSequenceNumber" then
	  		if lineout <> "" then lineout = lineout & ","
		    lineout = lineout & """" & replace(rs.Fields(i).Name, """", """""") & """"
	    end if
	  next
		  
		response.write lineout & vbcrlf
		
		
		counter = 1
		
		while not (rs.eof or rs.bof)

			lineout = ""
			
		  for i = 0 to rs.Fields.Count - 1
		  	if isnull(rs.Fields(i).Value) then
		  		cellValue = ""
		  	else
		  		cellValue = rs.Fields(i).Value
		  	end if
		  	
		  	if rs.Fields(i).Name <> "customerSequenceNumber" then
		  		if lineout <> "" then lineout = lineout & ","
			    lineout = lineout & """" & replace(cellValue, """", """""") & """"
		    end if
		  next

		  rs.MoveNext
		  
		  if not rs.bof then response.write lineout & vbcrlf
		  
			if counter mod 50 = 0 then response.flush
			counter = counter + 1
		wend
	end if
%>
