<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<% 
	Dim l_customerseq
	dim l_storeid
	dim isSubmitted 
	dim claimtype
	dim l_employeeId
	dim l_error
	dim query, rs
	
	l_Customerseq = session("Customersequencenumber")
	l_storeid = session("Storeid")
	isSubmitted = Request.QueryString("Submitted")
	l_employeeId = session("EmployeeId")
	
	if isSubmitted then
		if trim(Request.form("txtInvoiceNumber")) <> "" then
			if verifyInvoiceNumber(Request.form("txtInvoiceNumber")) then
				updateDatabase()
				response.redirect "claimorComments.asp"
			end if
		else
			updateDatabase()
			response.redirect "claimorComments.asp"
		end if
		
		
		
	end if
	
	if Trim(Request.QueryString("claimType")) <> "" then
	    claimtype = Trim(Request.QueryString("claimType"))
	else
	    claimtype = Trim(Request.form("h_claimType"))
	end if

%>
<HTML>
<HEAD>
<TITLE>New Claim</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="JavaScript" src="../script/validation.js"></script>
<script language="javascript" type="text/javascript">
	function submitForm() {
		if (document.newClaim.claimInfo.value =="") {
			cbs_alert ("Please enter a description for claim/comment");
		}
		else {
		    document.newClaim.action =  "?claimtype=<%=claimtype%>&Submitted=true";
		    document.newClaim.submit();
		}
	}	
	
	function cancelForm(){
		document.newClaim.action = "claimorComments.asp"
		document.newClaim.submit();
	
	}
	
	function validateInvoiceNumber(invoiceNumber) {

		if(invoiceNumber != "" && !isStrNumeric(invoiceNumber)) {
			show_focus("Invoice not valid", "CBS Error", document.newClaim.txtInvoiceNumber);
		}
	}
	
</SCRIPT>


<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Claim Or Comments</H1>

<FORM id="newClaim" name="newClaim" action="" method="Post">

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="submitForm()">Create</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="cancelForm()">Cancel</BUTTON>
	</SPAN>
</DIV>

<H1>
<%if trim(claimtype) = "claim" then %>
New Claim
<%else %>
New Comment 
<% end if %></H1>




<input type=hidden name = h_claimType value = "<%=claimType%>">





<font color=red><b><%=l_error%></b></font>

<TABLE style="background:#F8F8F8;margin:20px">
	<tr valign="top">
		<td>Date:</td>
		<td valign = top >
			<INPUT id=txtDateOccurred name=txtDateOccurred readonly style="width:390px;border:1px inset;background:white" value = "<%=Request.Form("txtDateOccurred")%>" onClick="javascript:show_calendar('newClaim.txtDateOccurred');">
		</td>
	</tr>
	<tr valign="top">
		<td>Invoice:</td>
		<td>
			<SELECT id=txtInvoiceNumber name=txtInvoiceNumber>
				<OPTION value="">[None]</OPTION>
<%

			query = "select invoicenumber from ticket where customersequencenumber = " & l_customerseq
			query = query & " order by ticketnumber desc "
			
			set rs = getdisconnectedrecordset(query)
			
			while not(rs.eof or rs.bof)
%>
				<OPTION value="<%=rs("invoicenumber")%>"><%=rs("invoicenumber")%></OPTION>

<%	
				rs.movenext
			wend
			set rs = nothing
%>
			</SELECT>
		</td>
	</tr>
	<tr valign="top">
		<td>Description:</td>
		<td>
			<TEXTAREA rows=19 name="claimInfo" style="width:390px;border:1px inset;background:white;overflow:auto"></TEXTAREA>
		</td>
	</tr>

</TABLE>


</form>
</BODY>
</HTML>
<%
	function updateDatabase()
	dim sqltxt
	dim strclaim
	dim newclaimid
		claimType = Request.Form("h_claimType")
		'Response.Write claimtype	
		if ClaimType = "claim" then
			strclaim = "C"
		else
			strclaim= "P"
		end if
		dim tempdate
		
		if trim(Request.form("txtDateOccurred")) = "" then
			tempdate = "getDate()"
		else
			tempdate = dbcreateQryString(Request.form("txtDateOccurred"))
		end if
		sqltxt = "SET NOCOUNT ON;"
		sqltxt = sqltxt & "INSERT INTO Claim (storeID, customerSequenceNumber, createdDate,"_
					& "claimType, claimStatus, occurredDate, invoiceNumber,createdemployeeid)"_
					& " VALUES( " _
					& l_storeid _
					& "," & l_customerseq _
					& "," & "getdate()" _
					& "," & dbcreateQryString(strclaim) _
					& "," & "'O'" _
					& "," & tempdate _
					& "," & dbcreateQryString(Request.form("txtInvoiceNumber"))_
					& "," & l_employeeid &  " );"
		sqltxt = sqltxt & "SELECT SCOPE_IDENTITY(); SET NOCOUNT OFF;"
		'Response.Write sqltxt
		dbstartTrans()
		newclaimid = QryExecuteWithTransAndSelect(sqltxt)
		sqltxt = "Insert into claimcomment(claimid, createddate, createdemployeeId,description) values ( " _
					& newclaimid _
					& "," & "getdate()" _
					& "," & l_employeeid _
					& "," & DbcreateQryString(Request.Form("claimInfo") )_
					& " )"
		qryexecutewithTrans(sqltxt)
		
		
		
		if strclaim = "C" then
			sqltxt = "Update customer set totalnbrofclaims  = isnull(totalnbrofclaims, 0) + 1 where customersequencenumber = " & l_customerseq
		else
			sqltxt = "Update customer set totalnbrofcomplaints  = isnull(totalnbrofcomplaints, 0) + 1 where customersequencenumber = " & l_customerseq
		end if
		
		qryexecutewithTrans(sqltxt)
					
	
		sqltxt = "insert into customernote (customersequencenumber, storeguid, source, note)"
		sqltxt = sqltxt & " select " & Session("customersequencenumber")
		sqltxt = sqltxt & ", store.guid"
		sqltxt = sqltxt & ", '" & session("employeename") & "'"
		sqltxt = sqltxt & ", 'Opened Claim:" & newclaimid & "'"
		sqltxt = sqltxt & " from store where storeid = " & session("storeid")
		
		qryexecutewithTrans(sqltxt)
					
		dbEndTrans()
		
		
	end function
	
	Function FormatDate1(varg)
		if trim(varg) = "" then
			formatdate1 = "null"
		else 'mm/dd/yyyy
			formatdate1 = dbcreateqrystring(month(varg) +  "/" + day(varg) + "/" + 20 + year(varg))
		end if
	end function
	
	function verifyInvoiceNumber(InvoiceNum)
	dim sqltxt
	dim rsTemp
	sqltxt = "select ticketnumber from ticket where invoicenumber = " & dbcreateQrystring(invoicenum)
	verifyInvoiceNumber = 0
	set rsTemp = getDisconnectedRecordset(sqltxt)
	if rsTemp.recordcount > 0 then
		verifyInvoiceNumber = 1
	else
		l_error = "Invalid Invoice Number"
	end if
	
	rstemp.close
	set rsTemp = nothing
		
	end function

%>
