<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<%
	const DELIVERY_STATUS_FINISH = 5
	const DELIVERY_STATUS_ADDING = 11
	const DELIVERY_STATUS_VERIFYING = 12
	const DELIVERY_STATUS_PAYMENTS1 = 13
	const DELIVERY_STATUS_MANIFEST = 14
	const DELIVERY_STATUS_UNDELIVERABLE = 15
	const DELIVERY_STATUS_PAYMENTS2 = 16

	const DELIVERY_ITEM_INVOICE_ERROR = -10
	const DELIVERY_ITEM_REMOVED = -1
	const DELIVERY_ITEM_READY = 0
	const DELIVERY_ITEM_ADDED = 1
	const DELIVERY_ITEM_ADDED_CALL = 2
	const DELIVERY_ITEM_STOP_WARNING = 10
	
	const DELIVERY_STOP_DROPOFF = 1
	const DELIVERY_STOP_PICKUP = 2
	
	dim destination
	dim cdDayColumns
	
	cdDayColumns = Array("DeliverSun", "DeliverMon", "DeliverTue", "DeliverWed", "DeliverThu", "DeliverFri", "DeliverSat")

	
	
	select case lcase(request.querystring("useraction"))
	case "addcustomerstops", "view", "open"
		
		createAllStops request.querystring("deliveryid")
		assignItemsToStops request.querystring("deliveryid")
	case "closedelivery"
		closeDelivery request.querystring("deliveryid")
	end select
	
	destination = request.querystring("destination")
	
	if destination <> "" then
		response.redirect destination
	else
		response.redirect "delivery.asp?deliveryid=" & request.querystring("deliveryid")
	end if
		
	function setDeliveryStatus(deliveryid, status)
		dim query, rs, createCCBatch
		
		if deliveryid <> "" then
			query = " update delivery set status = " & status
			query = query & " where deliveryid = " & deliveryid
			
			qryexecute query

            query = "select createCCBatchForDelivery from miscsetup where storeid = " & session("storeid")
            set rs = getdisconnectedrecordset(query)
            if rs.recordcount > 0 then
                createCCBatch = rs("createCCBatchForDelivery")
                if createCCBatch then
                    query = "select RouteNumber from DeliveryRouteAssigned where deliveryId = " & deliveryid
                    set rs = getdisconnectedrecordset(query)
                    response.redirect "creditCardBatchRequest.asp?routeNumber=" & rs("RouteNumber") _
                        & "&storeNumber=" & session("storeid")
                end if
            end if
		end if

	end function
	
	function closeDelivery(deliveryID)
		dim query, rs
		dim terminalID
		dim employeeID
		
		employeeID = Session("employeeID")
		terminalID = Session("terminalID")
		
		query = "execute dbo.PostDeliveryItems " & terminalID & "," & employeeID & "," & deliveryID

		qryexecute query
		
		setDeliveryStatus deliveryid, DELIVERY_STATUS_FINISH
	end function
	
	function getDayOfWeekColumn(deliveryDate, dayNames)
		dim dayOfWeek
		dayOfWeek = DATEDIFF("d", DATEADD("ww", DATEDIFF("ww",0,deliveryDate) - 1, 0), deliveryDate) - 1
		getDayOfWeekColumn = dayNames(dayOfWeek)
	end function

	function findTickets(deliveryID)
		dim query, rs
		
		query = " update deliveryitem set deliveryitem.ticketnumber =  ticket.ticketnumber "
		query = query & " from deliveryitem inner join ticket on "
		query = query & " deliveryitem.invoicenumber = ticket.invoicenumber "
		query = query & " where deliveryitem.deliveryid = " & deliveryid
		query = query & " and deliveryitem.status = " & DELIVERY_ITEM_ADDED

		qryexecute query
		
		query = query & " update deliveryitem set status = " & DELIVERY_ITEM_INVOICE_ERROR
		query = query & " where ticketnumber is null and status = " & DELIVERY_ITEM_ADDED
		
		qryexecute query
	end function

	function getDeliveryDate(deliveryID)
		dim query, rs
		
		query = " select deliverydate from delivery where deliveryid = " & deliveryid
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getDeliveryDate = rs("deliverydate")
		end if
		
		set rs = nothing
	end function 
	
	function getRoutesOnDelivery(deliveryID)
		dim query, rs
		dim result
		
		query = " select routenumber from deliveryrouteassigned where deliveryid = " & deliveryid
		set rs = getdisconnectedrecordset(query)
		
		while not (rs.eof or rs.bof)
			if result <> "" then result = result & ", "
			result = result & rs("routenumber")
			
			rs.movenext
		wend
		getRoutesOnDelivery = result
		set rs = nothing
	end function
	
	function assignItemsToStops(deliveryID)
		dim query, rs
		
		query = " update deliveryitem set deliverystopid = null "
		query = query & " where deliveryid = " & deliveryid
		
		qryexecute query
		
		
		query = " update deliveryitem set "
		query = query & " deliveryitem.deliverystopid = deliverystop.deliverystopid, "
		query = query & " deliveryitem.ticketnumber = ticket.ticketnumber, "
		query = query & " status = " & DELIVERY_ITEM_READY
		query = query & " from deliveryitem inner join ticket on "
		query = query & " deliveryitem.invoicenumber = ticket.invoicenumber "
		query = query & " inner join deliverystop on "
		query = query & " ticket.customersequencenumber = deliverystop.customersequencenumber "
		query = query & " where deliveryitem.deliveryid = " & deliveryid
		query = query & " and deliverystop.deliveryid = " & deliveryid

		qryexecute query
	end function

	function isStopsDirty(deliveryID)
		dim query, rs
		
		isStopsDirty = false
		
		if deliveryID <> "" then
			query = " select stopsdirty from delivery where deliveryid = " & deliveryid
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				isStopsDirty = rs("stopsdirty")
			end if
		end if
	end function
	
	
	function setDeliveryStopsDirty(deliveryID, dirty)
		dim query, rs
		
		if deliveryID <> "" then
			query = " update delivery set "
			if dirty then
				query = query & " stopsdirty = 1 "
			else
				query = query & " stopsdirty = 0 "
			end if
			query = query & " where deliveryid = " & deliveryid
			
			qryexecute query
		end if
	
	end function
	
	function removeOldStops(deliveryID)
		dim query
		
		query = " delete deliverystop where "
		query = query & " deliveryid = " & deliveryid
		query = query & " and stoptype in (" & DELIVERY_STOP_DROPOFF & ", " & DELIVERY_STOP_PICKUP & ") "
		
		qryexecute query
	
	end function
	
	function createAllStops(deliveryID)
		' get customerseq on route
		' get customerseq on delivery
		' add stops for all customseq
		
		dim query, rs
		dim dayOfWeekColumn
		dim deliveryDate
		dim routesOnDelivery


	 	if deliveryID <> "" and isStopsDirty(deliveryID) then
'	 	if deliveryID <> ""  then
			removeOldStops request.querystring("deliveryid")
			assignItemsToStops request.querystring("deliveryid")
			
			findTickets deliveryID
			
			deliveryDate = getDeliveryDate(deliveryID)
			routesOnDelivery = getRoutesOnDelivery(deliveryID)
	
			dayOfWeekColumn = getDayOfWeekColumn(deliveryDate, cdDayColumns)
			
			' dropoffs
			query = " select distinct ticket.customersequencenumber, deliveryitem.customerdeliveryid from "
			query = query & " deliveryitem inner join ticket on "
			query = query & " deliveryitem.ticketnumber = ticket.ticketnumber "
			query = query & " where deliveryitem.deliveryid = " & deliveryID
			query = query & " and deliveryitem.deliverystopid is null "
			
			set rs = getdisconnectedrecordset(query)

			while not(rs.eof or rs.bof)
				addCustomerToStop deliveryID, rs("customersequencenumber"), rs("customerdeliveryid"), DELIVERY_STOP_DROPOFF, "ONE TIME STOP"
				rs.movenext
			wend

			' pickups
			query = " select customerdelivery.customersequencenumber, customerdelivery.id as customerdeliveryid "
			query = query & " from customerdelivery inner join deliveryrouteassigned "
			query = query & " on customerdelivery.routeid = deliveryrouteassigned.routenumber "
			query = query & " inner join customer on "
			query = query & " customerdelivery.customersequencenumber = customer.customersequencenumber "
			query = query & " where customerdelivery.active = 1 "
			query = query & " and customer.isactive = 1 "
			query = query & " and " & dayOfWeekColumn & " in (2, 3) "
			query = query & " and datediff(day, begindate, '" & deliveryDate & "') >= 0 "
			query = query & " and (enddate is null or datediff(day, '" & deliveryDate & "', enddate) <= 0 ) "
			query = query & " and deliveryrouteassigned.deliveryid = " & deliveryID
			query = query & " and customerdelivery.customersequencenumber not in "
			query = query & " (select customersequencenumber from deliverystop where deliveryid = " & deliveryID & ") "

			set rs = getdisconnectedrecordset(query)

			while not(rs.eof or rs.bof)
				addCustomerToStop deliveryID, rs("customersequencenumber"), rs("customerdeliveryid"), DELIVERY_STOP_PICKUP, "ONE TIME STOP"
				rs.movenext
			wend

			
			' pickups
			query = " select deliverystop.parentCustomerSequenceNumber "
			query = query & " from deliverystop "
			query = query & " where deliverystop.deliveryID = " & deliveryID
			query = query & " and not(deliverystop.parentCustomerSequenceNumber is null) "

			set rs = getdisconnectedrecordset(query)

			while not(rs.eof or rs.bof)
				addCustomerToStop deliveryID, rs("parentCustomerSequenceNumber"), null, DELIVERY_STOP_PICKUP, "COMMERICAL ACCOUNT"
				rs.movenext
			wend
			
			
			
			
			setDeliveryStopsDirty deliveryID, false
			
			set rs = nothing
		end if
	end function
	
	function strToSQL(v)
		if isnull(v) then
			strToSQL = "null"
		else
			strToSQL = "'" & replace(v, "'", "''") & "'"
		end if
	end function
	
	function boolToSQL(v)
		if isnull(v) then
			boolToSQL = "null"
		elseif v then
			boolToSQL = 1
		else
			boolToSQL = 0
		end if
	end function
	
	function isStopOnDelivery(deliveryID, customerSequenceNumber, stopType)
		dim query, rs
		
		query = " select count(*) as cnt from deliverystop "
		query = query & " where deliveryid = " & deliveryid
		query = query & " and customersequencenumber = " & customerSequenceNumber
		query = query & " and stoptype = " & stoptype
		
		set rs = getdisconnectedrecordset(query)
		
		isStopOnDelivery = false
		
		if rs.recordcount > 0 then
			isStopOnDelivery = rs("cnt") > 0
		end if
	
		set rs = nothing
	end function
	
	function addCustomerToStop(deliveryID, customerSequenceNumber, customerdeliveryid, stopType, note)
		dim customerData
		
		if not isStopOnDelivery(deliveryID, customerSequenceNumber, stopType) then
		
			set customerData = getCustomerData(customerSequenceNumber, customerdeliveryid, note)
	
			if customerData.recordcount > 0 then
				query = " insert into deliverystop ("
				query = query & " customersequencenumber, "
				query = query & " deliveryaddress, "
				query = query & " deliverynotes, "
				query = query & " routeid, "
				query = query & " customerdeliveryid, "
				query = query & " deliveryid, "
				query = query & " stoporder, "
				query = query & " deliveryphone, "
				query = query & " parentcustomersequencenumber, "
				query = query & " billingcustomersequencenumber, "
				query = query & " stopType "
				query = query & " ) "
				query = query & " values( "
				query = query & customerData("customersequencenumber") & ", "
				query = query & strToSQL(customerData("deliveryaddress")) & ", "
				query = query & strToSQL(customerData("deliverynotes")) & ", "
				query = query & customerData("routeid") & ", "
				query = query & strToSQL(customerData("customerdeliveryid")) & ", "
				query = query & deliveryID & ", "
				query = query & customerData("stopOrder") & ", "
				query = query & strToSQL(customerData("deliveryPhone")) & ", "
				query = query & strToSQL(customerData("parentCustomerSeq")) & ", "
				query = query & strToSQL(customerData("billingCustomerSeq")) & ", "
				query = query & stopType 
				query = query & ") "
	
				qryexecute query
			end if
		end if
	end function
	
	
	function getCustomerData(customerSequenceNumber, customerdeliveryid, note)
		dim query
		
		if isnull(customerdeliveryid) then
			query = " select customer.customersequencenumber, "
			query = query & " dbo.formatCustomerAddress(customer.customersequencenumber, ' ', 2) as deliveryaddress, "
			query = query & " '" & note & "' as deliverynotes, "
			query = query & " 0 as routeid, "
			query = query & " null as customerdeliveryid, "
			query = query & " 0 as stopOrder, "
			query = query & " dbo.formatPhone(customer.mainareacode, customer.mainphone) as deliveryPhone, "
			query = query & " null as parentCustomerSeq, "
			query = query & " null as billingCustomerSeq "
			query = query & " from customer where customersequencenumber = " & customerSequenceNumber
		else
			query = " select  "
			query = query & " customerdelivery.customersequencenumber, "
			query = query & " customerdelivery.deliveryaddress, "
			query = query & " customerdelivery.deliverynotes, "
			query = query & " customerdelivery.routeid, "
			query = query & " customerdelivery.id as customerdeliveryid, "
			query = query & " customerdelivery.stopOrder, "
			query = query & " customerdelivery.deliveryPhone, "
			query = query & " customer.parentCustomerSeq, "
			query = query & " customer.billingCustomerSeq "
			query = query & " from customerdelivery "
			query = query & " inner join customer on "
			query = query & " customerdelivery.customersequencenumber = customer.customersequencenumber "
			query = query & " where customerdelivery.id = " & customerdeliveryid
		end if

		set getCustomerData = getdisconnectedrecordset(query)
	end function
	
	
	function removeStopsWithNoItems(deliveryID)
		dim query, rs
		
		query = " delete deliverystop "
		query = query & " where deliveryid = " & deliveryID
		query = query & " and deliverystopid not in ( "
		query = query & " select deliverystopid from deliveryitem where deliveryid = " & deliveryid
		query = query & " ) "
		
		qryexecute query
	end function
	
%>
