﻿<!-- #include file="../include/miscSetupObject.asp" -->
<!-- #include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("userAction")%>

<%
    Dim rstTransactions
    Dim actionString
    Dim paymentNumber

    If Not IsObject(Session("miscSetUp")) Then
		initializeMiscSetUp
	End If

    actionString = Request.QueryString("userAction")

    Select Case actionString
        Case "voidPayment"
            voidPayment
        Case "cancel"
            cancelForm
    End Select

    Set rstTransactions = GetDailyTransactions()

    Function GetDailyTransactions
        Dim query

        query = "SELECT p.paymentNumber, p.transactionNumber, p.customerSequenceNumber, c.customerName, p.paymentDate, p.amountPaid, p.paymentTypeName, " _
              & "CASE UPPER(p.paymentTypeName) WHEN 'CASH' THEN 'CA' WHEN 'CHECK' THEN 'CH' WHEN 'CREDIT CARD' THEN 'CC' WHEN 'ON ACCOUNT' THEN 'OA' END AS paymentTypeAbbreviation, " _
              & "pg.paymentGroupDescription, e.employeeName, cp.CardPresent " _
              & "FROM dbo.Customer c " _
              & "JOIN dbo.Payment p ON c.customerSequenceNumber = p.customerSequenceNumber AND p.amountPaid > 0 AND CAST(p.paymentDate AS DATE) = CAST(CURRENT_TIMESTAMP AS DATE)" _
              & "JOIN dbo.CardPayment cp ON p.transactionNumber = cp.TransactionID AND p.amountPaid = cp.AmountApplied " _
              & "AND NOT EXISTS(SELECT NULL FROM dbo.ReversePaymentTracking rpt WHERE rpt.PaymentID = p.paymentNumber) " _
              & "JOIN dbo.PaymentGroup pg ON p.paymentGroupNumber = pg.paymentGroupNumber " _
              & "JOIN dbo.Employee e ON p.createdEmployeeID = e.employeeID"

        Set GetDailyTransactions = getDisconnectedRecordset(query)
    End Function

    Sub voidPayment
        Dim paymentType
    
        paymentType = Request.QueryString("paymentType")
        paymentNumber = Request.QueryString("paymentNumber")

        If paymentType <> "Credit Card" Then
            Dim employeeID
            Dim terminalID
            Dim sql

            employeeID = Session("employeeID")
            terminalID = Session("terminalID")

            sql = "EXECUTE dbo.VoidPayment @PaymentType = '" & paymentType &"', "
            sql = sql & "@SalePaymentNumber = " & paymentNumber & ", "
            sql = sql & "@EmployeeID = " & employeeID & ", "
            sql = sql & "@TerminalID = " & terminalID
            QryExecute sql
        End If

    End Sub

    Sub cancelForm()
	    Response.Redirect "\reversePaymentMenu.asp?mode=edit"
	End Sub
 %>

<html>
    <head>
        <title>Void Payment</title>
        <link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
        <link href="../script/greyscale.css" rel="stylesheet" type="text/css">

        <script type="text/javascript" src="/script/printing.js"></script>
        <script type="text/javascript">

            var invoiceNumbers;
            var x;
            function handleRerack() {
                if ('<%=actionString %>' == 'voidPayment') {
                    var i = 0;
                    <%
                    If paymentNumber <> "" Then
                        Dim rs
                        Dim sql

                        sql = "SELECT t.invoiceNumber " _
                            & "FROM dbo.Ticket t " _
                            & "JOIN dbo.PaymentTracking pt " _
                            & "ON t.ticketNumber = pt.targetRefNumber " _
                            & "AND pt.sourceRefNumber = " & paymentNumber & " " _
                            & "AND pt.targetRefType = 'TI' " _
                            & "AND pt.sourceRefType = 'PA' " _
                            & "AND t.ticketStatus = 'FI' "

                        Set rs = GetDisconnectedRecordset(sql)
                        
                        If rs.RecordCount > 0 Then
                            While Not (rs.EOF Or rs.BOF)
                    %>
                        invoiceNumbers[i] = <%=rs("invoiceNumber")%>;

                    <%
                                rs.MoveNext
                            Wend
                        End If
                    End If
                    %>

                    x = 0;
                    cbs_prompt("New rack location for invoice " + invoiceNumbers[x] + ".", afterRackLocSet);
                }
            }

            function afterRackLocSet() {
                clearPromptMsg();
	            var rackLocation = document.getElementById('inputTxtLine').value;
                $.ajax({
                     method: 'GET',
                     async: false,
                     url: 'XWebMethods.asp?method=rerackInvoice&invoiceNumber=' + invoiceNumbers[x] + '&rackLocation=' + rackLocation,
                     success: function() { },
                     failure: function() { }
                });
                x++;
                if (x < invoiceNumbers.length)
                    cbs_prompt("New rack location for invoice " + invoiceNumbers[x] + ".", afterRackLocSet);

            }

            function cancelForm() {
                document.voidPaymentForm.action = "?userAction=cancel";
                document.voidPaymentForm.submit();
            }

            function toggleRowSelected(row) {
                row.className = row.className == 'selected' ? '' : 'selected';
            }

            function doVoid() {
                clearConfirmMsg();
                var transactionNumber = rowElement.getAttribute('data-transactionnumber');
                var paymentType = rowElement.getAttribute('data-paymenttypename');
                var paymentNumber = rowElement.getAttribute('data-paymentnumber');
                var amountPaid = rowElement.getAttribute('data-amountpaid');
                var customerSequenceNumber = rowElement.getAttribute('data-customersequencenumber');
                var cardPresent = rowElement.getAttribute('data-cardpresent');

                if (paymentType == 'Credit Card') {
                    $.ajax({
                        method: 'GET',
                        async: true,
                        dataType: 'json',
                        url: 'XWebMethods.asp?Method=voidPayment&transactionID=' + transactionNumber + "&salePaymentNumber=" + paymentNumber + "&customerSequenceNumber=" + customerSequenceNumber + "&amount=" + encodeURIComponent(amountPaid) + "&cardPresent=" + cardPresent + "&ts=" + new Date().getTime(),
                        success: function (data) {
                            if (data['Success'] == true){
                                cbs_alert('Payment voided');

                                PrintCreditCardReceipt(data['CardPaymentID']);

                                document.voidPaymentForm.action = "?userAction=voidPayment&paymentType=" + paymentType.replace(' ', '%20') + "&paymentNumber=" + paymentNumber;
                                document.voidPaymentForm.submit();
                            } else {
                                var errorMsg = data['ResponseDescription'] + ' - Code: ' + data['ResponseCode'];
                                if (!errorMsg) {
                                    errorMsg = 'The void payment transaction failed.'
                                }

                                cbs_alert(errorMsg);
                            }

                        }
                    });
                } else {
                    document.voidPaymentForm.action = "?userAction=voidPayment&paymentType=" + paymentType.replace(' ', '%20') + "&paymentNumber = " + paymentNumber;
                    document.voidPaymentForm.submit();
                }
            }

            function voidPayment() {
                var row = $('#tblPayments tr.selected:first');
                if (row) {
                    var rowElement = row[0];
                    if (rowElement)
                        cbs_confirm('This will void this entire transaction. Would you like to continue?', doVoid);
                }
                else
                    cbs_alert('Please select a transaction to void');
            }
        </script>
    </head>

    <body topmargin=0 leftmargin=0 onLoad="handleRerack();">
        <!-- #include file="../include/banner.inc" -->

        <form id="voidPaymentForm" name="voidPaymentForm" action="voidPayment.asp" method="post">
            <button style="height:50px;width:100px" onclick="cancelForm()" id=btnCancel name=btnCancel>Cancel</button>
            <table class="itable" id="tblPayments" border="0" cellspacing="0" cellpadding="0">
                <tr>
		            <th style="width: 10%" align="left">Customer</th>
		            <th style="width: 10%" align="left">Date Paid</th>
		            <th style="width: 10%" align="left">Payment Amount</th>
		            <th style="width: 10%" align="left">Payment Type</th>
		            <th style="width: 10%" align="left">Transaction Type</th>
                    <th style="width: 10%" align="left">Employee Name</th>
                </tr>

                <%
                    If rstTransactions.RecordCount <= 0 Then
                %>
                	<tr>
		                <td colspan="7" align="center">There are no transactions today</td>
	                </tr>
                <%
                    Else
                        While Not rstTransactions.EOF
                %>
                <tr onclick="toggleRowSelected(this)" 
                    class=""
                    data-paymentnumber="<%=Trim(rstTransactions("paymentNumber")) %>"
                    data-transactionnumber="<%=Trim(rstTransactions("transactionNumber")) %>"
                    data-customersequencenumber="<%=Trim(rstTransactions("customerSequenceNumber")) %>"
                    data-customername="<%=Trim(rstTransactions("customerName")) %>"
                    data-paymentdate="<%=Trim(rstTransactions("paymentDate")) %>"
                    data-amountpaid="<%=Trim(rstTransactions("amountPaid")) %>"
                    data-paymenttypename="<%=Trim(rstTransactions("paymentTypeName")) %>"
                    data-paymenttypeabbreviation="<%=Trim(rstTransactions("paymentTypeAbbreviation")) %>"
                    data-paymentgroupdescription="<%=Trim(rstTransactions("paymentGroupDescription")) %>"
                    data-employeename="<%=Trim(rstTransactions("employeeName")) %>"
                    data-cardpresent="<%=rstTransactions("cardPresent") %>"
                >
                    <td><%=Trim(rstTransactions("customerName")) %></td>
                    <td><%=Trim(rstTransactions("paymentDate")) %></td>
                    <td><%=FormatCurrency(Trim(rstTransactions("amountPaid"))) %></td>
                    <td><%=Trim(rstTransactions("paymentTypeName")) %></td>
                    <td><%=Trim(rstTransactions("paymentGroupDescription")) %></td>
                    <td><%=Trim(rstTransactions("employeeName")) %></td>
                </tr>
                <%
                            rstTransactions.MoveNext
                        Wend
                %>
                <tr>
                    <td colspan ="6" align="center">
                        <button style="height:75px;width:200px" id="btnVoidPayment" name="btnVoidPayment" onclick="voidPayment();">Void Payment</button>
                    </td>
                </tr>
                <%
                    End If  
                %>
            </table>					
        </form>
    </body>
</html>
