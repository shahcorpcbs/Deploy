<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim storeId
	dim actionstring
	dim customerSeq, customerName, custPhone
	dim cardNo, giftcardId, giftprogramId, validDays
	dim ssql
	dim rst
	dim v_custName,v_giftCard

	storeId = Session("storeId")
	actionString = Request.QueryString("userAction")

	select case actionString
		case "initialize"
			initialize()
		'case "submit"
		case else
			assignNumber()
	end select		

	function initialize()
		dim ssql
		dim objRst
		dim areaCode
			
		Session("customerSequenceNumber") = CLng(Request.QueryString("customerSequenceNumber"))
		ssql = "select customerid, customerName, Isnull(mainAreaCode, '') as mainAreaCode, isnull(mainPhone, '') as mainPhone"_
				& " from customer where customerSequenceNumber =" + Request.QueryString("customerSequenceNumber")
		set objRst = getDisconnectedRecordSet(ssql)
		v_custName = objRst.fields("customerName") + + " (" + trim(objRst.fields("customerId")) + ")"
		areaCode = objRst.fields("mainAreaCode")
		custPhone = objRst.fields("mainPhone")
		customerseq = Request.QueryString("customerSequenceNumber")
		if len(Trim(custPhone)) > 0 then
			if len(Trim(areaCode)) > 0 then
				custPhone = areaCode & "-"  & Mid(custPhone,1,3) & "-" & Mid(custPhone,4,len(custPhone))
			end if
		end if
	end function	
	
	function assignNumber()
		dim ssql
		dim ssql1
		dim objRst
		dim objRst1
		cardNo = Request.Form("giftCardNum")
		customerSeq = Request.Form("customerseq")
		ssql = "select * from giftCard where giftcardnumber = " & dbcreateqrystring(cardNo) & " and (customersequencenumber is null or customersequencenumber = 1)"
		set objRst = getDisconnectedRecordset(ssql)
		if objRst.Recordcount > 0 then
			giftcardId = objRst.fields("giftcardId")
			giftprogramId = objRst.fields("giftprogramId")
		else
			ssql1 = "select * from giftCard where giftcardnumber = " & dbcreateqrystring(cardNo) & " and not (customersequencenumber is null or customersequencenumber = 1)"
			set objRst1 = getDisconnectedRecordset(ssql1)
			if objRst1.Recordcount > 0 then
				Session("errorMessage") = "Gift Card Number has already been assigned to a customer.  Please choose a new gift card number."
				Response.Redirect "ErrorMessages.asp"
			else
				Session("errorMessage") = "Gift Card Number is not valid.  Please choose a new gift card number."
				Response.Redirect "ErrorMessages.asp"
			end if	
		end if	
		ssql = "select validDays from giftprogram"
		set objRst = getDisconnectedRecordset(ssql)
		if objRst.Recordcount > 0 then
			validDays = objRst.fields("validDays")
		end if			
		ssql = "update giftcard set customersequencenumber =" & customerseq & ", effectivedate = getdate(), " _
			& "expirationdate = getdate() + " &  validdays & ", lastuseddate = getdate() " _
			& "where giftcardnumber = " & dbcreateqrystring(cardNo)
		QryExecute(ssql)	
	
		Response.Redirect "issueGiftCard.asp"
	end function	
				
		
		
		
	
	
%>	
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Assign Gift Card to Customer</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		if (validateFormData()) {
			document.issueMultiToCust.action = "?userAction=submit";
			document.issueMultiToCust.submit();
		}	
	}
	
	function cancelForm() {
		document.issueMultiToCust.action="issueGiftCard.asp";
		document.issueMultiToCust.submit()
	}	
	
	function validateFormData() {
		var cardNo
		returnValue = true;
		cardNo = document.issueMultiToCust.giftCardNum.value;
		if (!checkFieldMissing(cardNo)) {
			returnValue = false;
			show_focus("Card Number is required", "Gift Card Number", document.issueMultiToCust.giftCardNum)
			return returnValue;
		}
		return returnValue;
	}	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Issue Gift Card</B>
<FORM id="issueMultiToCust" name="issueMultiToCust" action="issueMultiToCust.asp" method="Post">
<input type="hidden" name = customerseq value=<%=customerseq%>>
<TABLE ALIGN=center WIDTH=450px BORDER=1 CELLSPACING=1 CELLPADDING=10>
	<TR><TD>
	<TABLE ALIGN=center WIDTH=100% BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR height=20px><TD align=center width=80%  valign=bottom colspan=3>
			<b><%=v_custName%></b>
			</TD>
			</TR>
		<TR height=40px valign=top><TD></TD><TD><b><%=custPhone%></b></td></tr>
		<TR height=40px><TD align=right>
			<LABEL for=giftCardNum>Gift Card Number&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=giftCardNum style= width:140px value="<%=v_giftCard%>">
		</TD></TR>
		<TR height=80px><TD ALIGN=CENTER COLSPAN=3 valign=bottom>
			<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
		</TD></TR>
	</TABLE>
	</TD></TR>
</TABLE>	
</FORM>   

</BODY>
</HTML>