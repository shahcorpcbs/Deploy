<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/validatefunction.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs,lotid

	lotid = Request.QueryString("lotId")



	function isInt(input)
		dim i, d
		
		isInt = true
		
		for i=1 to len(input)
			d = Mid(input,i,1)
			if Asc(d) < 48 OR Asc(d) > 57 then
				isInt = false
				exit for
			end if
		next
	
	end function
	
	function getTagsAsCSV(tNum)
		Dim tagsql, tagrs, retcsv
		Dim lastTagNumber
		Dim lastTagColor
		Dim groupFirstTagNumber
		Dim lastLotNumber
		
		lastTagNumber = ""
		lastTagColor = ""
		lastLotNumber = ""
		groupFirstTagNumber = ""

		
		tagsql = "SELECT  lotID, lotNumber, ticketNumber, tagNumber AS TagNumber, isnull(tagColor, '') as tagColor FROM TicketTag "
		tagsql = tagsql & " WHERE ticketNumber IN (" & tNum & ") "
		tagsql = tagsql & " ORDER BY lotNumber, tagColor, "
		tagsql = tagsql & " CASE dbo.isInt(tagNumber) "
		tagsql = tagsql & " WHEN 0 THEN -1 "
		tagsql = tagsql & " ELSE cast(tagNumber as integer) "
		tagsql = tagsql & " END "

		Set tagrs = getDisconnectedRecordset(tagsql)

		if tagrs.RecordCount > 0 then
			lastTagNumber = tagrs.Fields("tagNumber").Value
			lastTagColor = tagrs.Fields("tagcolor").Value
			lastLotNumber = tagrs.Fields("lotNumber").Value
			
			if isInt(lastTagNumber)	then groupFirstTagNumber = lastTagNumber
			
			tagrs.MoveNext

			while Not tagrs.EOF
				
				if isInt(lastTagNumber) then
					if trim(lastLotNumber) = trim(tagrs.Fields("lotNumber").Value) _
					and trim(lastTagColor) = trim(tagrs.Fields("tagcolor").Value) _
					and trim(lastTagNumber + 1) = trim(tagrs.Fields("tagNumber").Value) then
	
					else
	
						if retcsv <> "" then	retcsv = retcsv & ", "

						if lastLotNumber >= 0 then			
							retcsv = retcsv & lastLotNumber & "/"
						end if
					
						if groupFirstTagNumber <> "" then
							if groupFirstTagNumber <> lastTagNumber then
								retcsv = retcsv & groupFirstTagNumber & "-" & lastTagNumber
							else
								retcsv = retcsv & groupFirstTagNumber
							end if
						else
							retcsv = retcsv & lastTagNumber
						end if
						
						if trim(lastTagColor) <> "" then			
							retcsv = retcsv & " (" & trim(lastTagColor) & ")"
						end if
						
						lastTagNumber = tagrs.Fields("tagNumber").Value
						lastTagColor = tagrs.Fields("tagcolor").Value

						if isInt(lastTagNumber)	then
							groupFirstTagNumber = lastTagNumber
						else
							groupFirstTagNumber = ""
						end if
					end if
					lastTagNumber = tagrs.Fields("tagNumber").Value
					lastTagColor = tagrs.Fields("tagcolor").Value
					lastLotNumber = tagrs.Fields("lotNumber").Value
				else
					
					if retcsv <> "" then	retcsv = retcsv & ", "

					if lastLotNumber >= 0 then			
						retcsv = retcsv & lastLotNumber & "/"
					end if
					
					if groupFirstTagNumber <> "" then
						if groupFirstTagNumber <> lastTagNumber then
							retcsv = retcsv & groupFirstTagNumber & "-" & lastTagNumber
						else
							retcsv = retcsv & groupFirstTagNumber
						end if
					else
						retcsv = retcsv & lastTagNumber
					end if
					
					if trim(lastTagColor) <> "" then			
						retcsv = retcsv & " (" & trim(lastTagColor) & ")"
					end if
						
					lastTagNumber = tagrs.Fields("tagNumber").Value
					lastTagColor = tagrs.Fields("tagcolor").Value
					lastLotNumber = tagrs.Fields("lotNumber").Value
					
					if isInt(lastTagNumber)	then
						groupFirstTagNumber = lastTagNumber
					else
						groupFirstTagNumber = ""
					end if
				end if

				tagrs.MoveNext
			wend
			
			if retcsv <> "" then	retcsv = retcsv & ", "
			
			if lastLotNumber >= 0 then			
				retcsv = retcsv & lastLotNumber & "/"
			end if
					
			if groupFirstTagNumber <> "" then
				if groupFirstTagNumber <> lastTagNumber then
					retcsv = retcsv & groupFirstTagNumber & "-" & lastTagNumber
				else
					retcsv = retcsv & groupFirstTagNumber
				end if
			else
				retcsv = retcsv & lastTagNumber
			end if
			
			if trim(lastTagColor) <> "" then			
				retcsv = retcsv & " (" & trim(lastTagColor) & ")"
			end if
			
		end if
		
		getTagsAsCSV = retcsv

	end function

%>
<HTML>
<HEAD>
<TITLE>Lot Manager</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "chkLot") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "chkLot") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}

	function SetRowCheckedStatus(row, check, value) {
		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}


	function cancelForm() {
		document.lotDetails.action =  "lotManager.asp"
		document.lotDetails.submit();
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->


<%
	query = " select *, isnull(color, '') as color from lot where id = " & lotid
	set rs = getdisconnectedrecordset(query)
	if rs.recordcount > 0 then
%>
<H1>Lot Details (Lot <%=rs("color")%> <%=rs("number")%> opened <%=rs("dateopened")%>)</H1>


<%
	end if
	set rs = nothing
%>

<FORM id="lotDetails" name="lotDetails" action="lotDetails.asp" Method = "post">

<center>


<div name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<span style="float:left">

	</span>
	<span style="float:right">
      <button name="cancel" onClick="cancelForm()">Exit</button>
	</span>
</div>	

<table class="itable" BORDER=0 CELLSPACING=0 CELLPADDING=0 style="font-size:16">
	<tr valign=bottom >
		<th align=left>Invoice</th>
		<th align=left>Customer</th>
		<th align=left>Department</th>
		<th align=left>Rack</th>
		<th align=left>Pieces</th>
		<th align=left>Tags</th>
		<th align=left>Date Tagged</th>
		<th align=left>Employee</th>
	</tr>


	<%
		query = "select t.invoicenumber, t.ticketnumber, c.customername, c.customersequencenumber as custseq, dbo.formatphone(c.mainareacode,c.mainphone) as phone, "
		query = query & " dbo.pivotTicketDepartments(t.ticketnumber,',') as depts, dbo.getTotalPieces(t.ticketnumber,null) as pieces, "
		query = query & " t.nettotal, dbo.pivotTicketRackLocationBrief(t.ticketnumber, ', ') as rack, "
		query = query & " tickettag.datecreated, isnull(employee.employeename, '') as employeename "
		query = query & " from ticket t "
		query = query & " inner join customer c on t.customersequencenumber = c.customersequencenumber  "
		query = query & " inner join tickettag on t.ticketnumber = tickettag.ticketnumber "
		query = query & " left outer join employee on tickettag.employeeid = employee.employeeid "
		query = query & " where tickettag.lotid = " & lotid
		query = query & " group by t.ticketNumber, t.invoiceNumber, c.customerName, c.customerSequenceNumber, c.mainareacode, c.mainphone, t.nettotal, datecreated, employeename  "
		query = query & " order by case dbo.isint(min(tickettag.tagNumber)) when 1 then cast(min(tickettag.tagNumber) as int) else -1 end "
		
		
		
		set rs = getdisconnectedrecordset(query)

		while not(rs.eof or rs.bof)
	%>
	<tr align=left>
		<td><%=rs("invoicenumber")%></td>
		<td><%=rs("customername")%></td>
		<td><%=rs("depts")%></td>
		<td><%=rs("rack")%></td>
		<td><%=rs("pieces")%></td>
		<td><%=getTagsAsCSV(rs("ticketnumber"))%></td>
		<td><%=rs("datecreated")%></td>
		<td>&nbsp;<%=rs("employeename")%></td>
	</tr>
	<%
		rs.movenext
		wend
		set rs = nothing
	%>
</table>
</center>
</FORM>
</BODY>
</HTML>
