<style type="text/css">
	#banner #bannerText {
		text-align: center;
		font: 22px arial;
		position: absolute;
		left: 115px;
		top: 17px;
		margin: 0px;
		width: 180px;
		color: #fff;
		background: #d33;
	}
</style>

<TABLE BORDER="0" CELLPADDING="0" CELLSPACING="0" STYLE="width:100%;height:100%">
<TR><TD VALIGN="TOP" style="width:170px;background:fff;">

<TABLE style="margin-bottom:10px;margin-top:10px;width:100%">
	<TR>
		<TD style="border-bottom:3px solid #EEE" COLSPAN="2"><B>Views</B></TD>
	</TR>
	<TR style="cursor:pointer" onmousedown="return loadIframe('sa', '../MainApp/Startpage/TerminalFunctions.asp');">
		<TD style="width:40px" align="right"><IMG SRC="/static/icons/32x32/home.png"></TD>
		<TD>Home</TD>
	</TR>
	<TR style="cursor:pointer" onmousedown="return loadIframe('sa', '../MainApp/Startpage/StoreActivity.asp');">
		<TD style="width:40px" align="right"><IMG SRC="/static/icons/32x32/view_text.png"></TD>
		<TD>Store Activity</TD>
	</TR>
	<TR style="cursor:pointer" onmousedown="return loadIframe('sa', '../MainApp/Startpage/NotesTracker.asp?useraction=defaultsearch');">
		<TD style="width:40px" align="right"><IMG SRC="/static/icons/32x32/note.png"></TD>
		<TD>Invoice Notes</TD>
	</TR>
</TABLE>

<%
	query = "select formid, name from startpageform where storeid = " & session("storeid")
	set rs = getdisconnectedrecordset(query)

	if rs.recordcount > 0 then
%>
<TABLE style="margin-bottom:10px;margin-top:10px;width:100%">
	<TR>
		<TD style="border-bottom:3px solid #EEE" COLSPAN="2"><B>Alerts</B></TD>
	</TR>

<%
	while not (rs.eof or rs.bof)
%>
	<TR style="cursor:pointer" onmousedown="return loadIframe('sa', '../MainApp/Startpage/Custom.asp?formid=<%=rs("formid")%>');">
		<TD style="width:40px" align="right"><IMG SRC="/static/icons/32x32/invoice.png"></TD>
		<TD><%=rs("name")%></TD>
	</TR>
<%
		rs.movenext
	wend
%>
</TABLE>
<%
	end if
	set rs = nothing
%>


<% if printOnHomeScreen then %>
<TABLE style="margin-bottom:10px;margin-top:10px;width:100%">
	<TR>
		<TD style="border-bottom:3px solid #EEE" COLSPAN="2"><B>Tools</B></TD>
	</TR>
	<TR style="cursor:pointer" onmouseup="printTags();">
		<TD style="width:40px" align="right"><IMG SRC="/static/icons/32x32/print.png"></TD>
		<TD>Print Tags</TD>
	</TR>

	<TR style="cursor:pointer" onmouseup="printInvoice();">
		<TD style="width:40px" align="right"><IMG SRC="/static/icons/32x32/print.png"></TD>
		<TD>Print Invoice</TD>
	</TR>
</TABLE>
<% end if %>
<TABLE style="margin-bottom:10px;margin-top:10px;width:100%">
	<TR>
		<TD style="border-bottom:3px solid #EEE"><B>Customer Search</B></TD>
	</TR>

	<TR>
		<TD style="padding-left:10px"><INPUT id="smartQuery" name="smartQuery" STYLE="BORDER:1px solid #CCC;width:100%;margin-right:10px" autocomplete="off" onkeyup="CaptureKey(this.value);"><BR />
		</TD>
	</TR>

</TABLE>

</TD><TD VALIGN="TOP" style="">

<TABLE STYLE="width:100%;margin:10px;margin-top:20px">
<TR><TD ALIGN="CENTER">
<A style="text-decoration:none;color:black" HREF="javascript:Login('/mainapp/customersearch.asp?targetpage=CustomerFunctions')"><IMG style="border:none" SRC="/static/images/start_customerfunctions.jpg"><BR><B>Customer Functions</B></A>
</TD><TD ALIGN="CENTER">
<% if termLicenseType = 1 then %>
<A style="text-decoration:none;color:black" HREF="javascript:Login('/mainapp/racking.asp')"><IMG style="border:none" SRC="/static/images/start_racking.jpg"><BR><B>Racking</B></A>
<% end if %>
</TD><TD ALIGN="CENTER">
<A style="text-decoration:none;color:black" HREF="javascript:Login('/mainapp/managerMenu.asp')"><IMG style="border:none" SRC="/static/images/start_manager.jpg"><BR><B>Manager</B></A>
</TD></TR>
</TABLE>

<IFRAME name="sa" NORESIZE SCROLLING="AUTO" FRAMEBORDER="0" HEIGHT="550px" WIDTH="100%" style="padding-right:20px;padding-left:10px;" SRC="../MainApp/Startpage/TerminalFunctions.asp?routeVersion=<%=getRouteVersion(session("storeid"))%>"></IFRAME>

</TD></TR>
</TABLE>