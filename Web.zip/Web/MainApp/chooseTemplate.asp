<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<%	

dim isSubmitted, alldone
dim filename, dataSource
dim objWord

isSubmitted = Request.QueryString("submitted")
filename = Request.QueryString("templateFile")
alldone = Request.QueryString("Wrapup")

if isSubmitted then
	GetData()
	OpenWord()
elseif allDone then
	closeWord()
	Response.Redirect("start.asp")
end if	

function GetData()
	dim objRS
	dim strSQL
	
	if filename = "BIRTHDAY.DOC" then
		strSQL = "delete from MLBirthday"
		dataSource = "\DATASOURCES\localhost shahcorp MLBirthday.odc"
		qryexecute strSQL
		
		strSQL = "insert into MLBirthday "
		strSQL = strSQL & "select customerid, firstname, lastname, billingAddress1, billingAddress2, billingAddress3, "
		strSQL = strSQL & "billingCity, billingState, billingZipCode, dbo.formatPhone(mainAreaCode, mainPhone) as mainPhone, "
		strSQL = strSQL & "shippingAddress1, shippingAddress2, shippingAddress3, shippingCity, shippingState, shippingZipCode, email " 
		strSQL = strSQL & "from customer where customersequencenumber in (select customersequencenumber from MarketingLettersCSN)"
		qryexecute strSQL
		
	elseif filename = "INACTIVE.DOC" then
		strSQL = "delete from MLInactive"
		dataSource = "\DATASOURCES\localhost shahcorp MLInactive.odc"
		qryexecute strSQL
		
		strSQL = "insert into MLInactive "
		strSQL = strSQL & "select customerid, firstname, lastname, billingAddress1, billingAddress2, billingAddress3, "
		strSQL = strSQL & "billingCity, billingState, billingZipCode, dbo.formatPhone(mainAreaCode, mainPhone) as mainPhone, "
		strSQL = strSQL & "shippingAddress1, shippingAddress2, shippingAddress3, shippingCity, shippingState, shippingZipCode, email, " 
		strSQL = strSQL & "createdDate, lastVisited "
		strSQL = strSQL & "from customer where customersequencenumber in (select customersequencenumber from MarketingLettersCSN)"
		qryexecute strSQL
		
	elseif filename = "NEW.DOC" then
		strSQL = "delete from MLNew"
		dataSource = "\DATASOURCES\localhost shahcorp MLNew.odc"
		qryexecute strSQL
		
		strSQL = "insert into MLNew "
		strSQL = strSQL & "select customerid, firstname, lastname, billingAddress1, billingAddress2, billingAddress3, "
		strSQL = strSQL & "billingCity, billingState, billingZipCode, dbo.formatPhone(mainAreaCode, mainPhone) as mainPhone, "
		strSQL = strSQL & "shippingAddress1, shippingAddress2, shippingAddress3, shippingCity, shippingState, shippingZipCode, email " 
		strSQL = strSQL & "from customer where customersequencenumber in (select customersequencenumber from MarketingLettersCSN)"
		qryexecute strSQL

	elseif filename = "TOP.DOC" then
		strSQL = "delete from MLTop"
		dataSource = "\DATASOURCES\localhost shahcorp MLTop.odc"
		qryexecute strSQL
		
		strSQL = "insert into MLTop "
		strSQL = strSQL & "select customerid, firstname, lastname, billingAddress1, billingAddress2, billingAddress3, "
		strSQL = strSQL & "billingCity, billingState, billingZipCode, dbo.formatPhone(mainAreaCode, mainPhone) as mainPhone, "
		strSQL = strSQL & "shippingAddress1, shippingAddress2, shippingAddress3, shippingCity, shippingState, shippingZipCode, email, " 
		strSQL = strSQL & "accountBalance "
		strSQL = strSQL & "from customer where customersequencenumber in (select customersequencenumber from MarketingLettersCSN)"
		qryexecute strSQL

	elseif filename = "EXPIRED.DOC" then
		strSQL = "delete from MLExpired"
		dataSource = "\DATASOURCES\localhost shahcorp MLExpired.odc"
		qryexecute strSQL
		
		strSQL = "insert into MLExpired "
		strSQL = strSQL & "select c.customerid, c.firstname, c.lastname, c.billingAddress1, c.billingAddress2, c.billingAddress3, "
		strSQL = strSQL & "c.billingCity, c.billingState, c.billingZipCode, dbo.formatPhone(c.mainAreaCode, c.mainPhone) as mainPhone, "
		strSQL = strSQL & "c.shippingAddress1, c.shippingAddress2, c.shippingAddress3, c.shippingCity, c.shippingState, c.shippingZipCode, c.email, " 
		strSQL = strSQL & "convert(varchar, dbo.getCustomerCCExpiryDate(c.customersequencenumber), 101) as CCExpDate, dbo.formatCCNumber(c.creditCardNumber) as CCNumber, "
		strSQL = strSQL & "cctd.name as CCName "
		strSQL = strSQL & "from customer c, creditCardTypeDomain cctd where c.creditCardTypeID = cctd.creditCardTypeID "
		strSQL = strSQL & "and c.customersequencenumber in (select customersequencenumber from MarketingLettersCSN)"
		qryexecute strSQL

	elseif filename = "LABELS.DOC" then
		strSQL = "delete from MLLabels"
		dataSource = "\DATASOURCES\localhost shahcorp MLLabels.odc"
		qryexecute strSQL
		
		strSQL = "insert into MLLabels "
		strSQL = strSQL & "select c.customerid, c.firstname, c.lastname, rtrim(c.billingAddress1), rtrim(c.billingAddress2), rtrim(c.billingAddress3), "
		strSQL = strSQL & "rtrim(c.billingCity), c.billingState, c.billingZipCode "
		strSQL = strSQL & "from customer c where customersequencenumber in (select customersequencenumber from MarketingLettersCSN)"
		qryexecute strSQL				
	end if
end function

function OpenWord()
	set objWord = Server.CreateObject("ShahCorpComponents.MarketingLetters")
	objWord.openMLetter filename, dataSource
end function			

function closeWord()
	objWord = empty
end function		
	
		


function GetTemplateDropDown()
	dim strDropDownTag
	dim objRS
	dim strSQL
	
	strDropDownTag = "<SELECT name=templateID > "
	
	on error resume next
	
	strSQL = "SELECT * from MarketingLetters order by MLID"
	
	set objRS = getDisconnectedRecordset(strSQL)
	
	While not objRS.EOF
		strDropDownTag = strDropDownTag & "<OPTION VALUE=" & objRS("MLfilename") & ">" & _
						 objRS("templateDesc") & "</OPTION>"
		objRS.MoveNext
	Wend
	
	strDropDownTag = strDropDownTag & "</SELECT>"
	GetTemplateDropDown = strDropDownTag
end function		

%>
<HTML>
<HEAD>
<% dim objMM
	set objMM = Server.CreateObject("ShahCorpComponents.MarketingLetters")
%>	
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Choose Marketing Template</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function submitForm(){
		fileName = document.chooseTemplate.templateID.value;
		document.chooseTemplate.action="?Submitted=true&templateFile=" + fileName;
		document.chooseTemplate.submit();	
	}
	
	function cancelForm(){
		document.chooseTemplate.action = "?Submitted=false&Wrapup=true";
		document.chooseTemplate.submit();	
	}

	
</script>
<BODY topmargin=0 leftmargin=0 >

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">&nbsp;Choose Marketing Template</B>
<FORM id="chooseTemplate" name="chooseTemplate" action="" method="post">
	<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=0 CELLPADDING=2 >
		<tr height=50px>
			<td align="center" colspan=2>
				<%= GetTemplateDropDown() %>
			</td>
			
			
		</tr>
		<tr><td></td></tr>
		<tr>
			<td>
				<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
					<tr height=10px>
						<td align="center">
							<INPUT class=touch id=select name=select type=button value="Open File" style="width:150px;height:75px;margin-top:10px;" onClick="submitForm()">
						</td></tr>
					<tr height=200px>	
						<td align="center">	
							<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)"onClick="cancelForm()">
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</form>
</BODY>
</HTML>

