﻿<%@ Language=VBScript %>
<% Option Explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/security.asp" -->
<!-- #include file="../include/creditCardTransaction.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
    Dim message
    Dim forceAuthAmount

    Select Case Request.QueryString("useraction")
        Case "checkBatchStatus"
            checkSettlementBatchStatus
        Case "voidTransaction"
            Dim transactionID: transactionID = Request.QueryString("transactionID")
            voidTransaction transactionID
        Case "forceAuthTransaction"
            Dim amount: amount = Request.QueryString("amount")
            forceAuthTransaction amount
        Case "closeBatch"
            closeBatch
        Case "cancel"
            exitForm
    End Select

    Sub checkSettlementBatchStatus
        Dim cc: Set cc = New CreditCardTransaction
        Dim batchClosed: batchClosed = cc.isSettlementBatchClosed()

        If batchClosed Then
            message = "The current batch has no unsettled transactions"
        Else
            message = "The current batch has unsettled transactions."
        End If
    End Sub

    Sub voidTransaction(transactionID)
        If IsEmpty(transactionID) Then
            message = "Please enter a Transaction #"
        Else
            Dim cc: Set cc = New CreditCardTransaction
            Dim result: Set result = cc.voidSettlementBatchTransaction(transactionID)

            forceAuthAmount = (-1)*result.Amount

            If result.Success = True Then
                message = "Transaction successfully voided"

                Set result = cc.closeSettlementBatch

                If result.Success = True Then
                    message = message & " and settlement batch successfully closed"
                Else
                    If result.ResponseCode <> -1 Then
                        message = message & " but settlement batch could not be closed. Please manually close the batch before submitting the force auth transaction"
                    End If
                End If
            End If
        End If
    End Sub

    Sub forceAuthTransaction(amount)
        If IsEmpty(amount) Then
            message = "Please enter the amount of the transaction you wish to authorize"
        Else
            Dim cc: Set cc = New CreditCardTransaction
            Dim result: Set result = cc.forceAuthSettlementBatchTransaction(amount)

            If result.Success = True Then
                message = "Transaction successfully authorized"

                Set result = cc.closeSettlementBatch

                If result.Success = True Then
                    message = message & " and settlement batch successfully closed"
                Else
                    If result.ResponseCode <> - 1 Then
                        message = message & " but settlement batch could not be closed. Please manually close the batch in order to complete the authorization"
                    End If
                End If
            End If
        End If
    End Sub

    Sub closeBatch
        Dim cc: Set cc = New CreditCardTransaction
        Dim result: Set result = cc.closeSettlementBatch

        message = result.ResponseDescription
    End Sub

    Sub exitForm
        Response.Redirect "/MainApp/accountMgmt.asp"
    End Sub
%>

<html>
    <head>
        <title>Settlement Batch Management</title>
        <link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
        <link href="../script/greyscale.css" rel="stylesheet" type="text/css">

        <style type="text/css">

            table {
                width: 30%;
                margin-left: 35%;
                margin-right: 35%;
                margin-top: 10px;
                margin-bottom: 10px;
                table-layout:fixed;
            }
            
            td {
                padding: 3px;
                width: 15%;
                text-align: center;
            }

            input {
                width: 95%;
            }

            .border-table {
                border:1px solid black;
            }

            .cancel-button{
                background-image:url(../images/Cancel.gif)
            }

        </style>

        <script type="text/javascript">
            function startupActions() {
                <% If Not IsEmpty(message) Then %>
                    cbs_alert("<%=message%>");
                <% End If %>
            }

            function validateField() {
                if (!isNum1(trim(document.creditCardForceAuth.txtForceAuthAmount.value), 0)) {
                    cbs_alert("Please enter a valid amount.");
                    document.creditCardForceAuth.txtForceAuthAmount.value = "";
                    document.creditCardForceAuth.txtForceAuthAmount.focus();
                    return false;
                } else {
                    populateForceAuthAmount();
                }
            }

            function populateForceAuthAmount() {
                var tempval

                if (document.creditCardForceAuth.txtForceAuthAmount.value > 0) {
                    tempval = document.creditCardForceAuth.txtForceAuthAmount.value.replace(/\./, "");
                    document.creditCardForceAuth.txtForceAuthAmount.value = tempval.substr(0, tempval.length - 2) + "." + tempval.substr(tempval.length - 2);
                }
            }

            function checkBatchStatus() {
                document.creditCardForceAuth.action = "?useraction=checkBatchStatus";
                document.creditCardForceAuth.submit();
            }

            function submitVoid() {
                if (document.creditCardForceAuth.txtTransactionNumber.value != '') {
                    document.creditCardForceAuth.action = "?useraction=voidTransaction&transactionID=" + document.creditCardForceAuth.txtTransactionNumber.value;
                    document.creditCardForceAuth.submit();
                } else {
                    cbs_alert("Please enter a transaction #");
                }
            }

            function submitForceAuth() {
                if (document.creditCardForceAuth.txtForceAuthAmount.value > 0) {
                    document.creditCardForceAuth.action = "?useraction=forceAuthTransaction&amount=" + document.creditCardForceAuth.txtForceAuthAmount.value;
                    document.creditCardForceAuth.submit();
                } else {
                    cbs_alert("Please enter the amount of the transaction you wish to authorize");
                }
            }

            function submitCloseBatch() {
                document.creditCardForceAuth.action = "?useraction=closeBatch";
                document.creditCardForceAuth.submit();
            }

            function cancelForm() {
                document.creditCardForceAuth.action = "?useraction=cancel";
                document.creditCardForceAuth.submit();
            }
        </script>
    </head>

    <body topmargin=0 leftmargin=0 onload="startupActions();">

        <!-- #include file="../include/banner.inc" -->

        <form id="creditCardForceAuth" name="creditCardForceAuth" action="" method="POST">
            <h1>Settlement Batch Management</h1>
            
            <table class="border-table">
                <tr>
                    <td>Check Settlement Batch Status</td>
                </tr>
                <tr>
                    <td><button id="btnBatchStatus" onclick="checkBatchStatus();">Check</button></td>
                </tr>
            </table>
            <table class="border-table">
                <colgroup>
                    <col style="width:35%;" />
                    <col style="width:65%;" />
                </colgroup>
                <tr>
                    <td colspan="2">Void Rejected Transaction</td>
                </tr>
                <tr>
                    <td>Transaction #</td>
                    <td>
                        <input id="txtTransactionNumber" name="txtTransactionNumber" />
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <button id="btnSubmitVoid" onclick="submitVoid();">Submit Void</button>
                    </td>
                </tr>
                <tr height="20px"></tr>
                <tr>
                    <td colspan="2">Force Authorization</td>
                </tr>
                <tr>
                    <td>Amount</td>
                    <td>
                        <input id="txtForceAuthAmount" name="txtForceAuthAmont" value="<%=forceAuthAmount %>" onkeyup="validateField();" />
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <button id="btnSubmitForceAuth" onclick="submitForceAuth();">Submit Force Auth</button>
                    </td>
                </tr>
            </table>
            <table class="border-table">
                <tr>
                    <td>Manually Close Settlement Batch</td>
                </tr>
                <tr>
                    <td><button id="btnManuallyCloseBatch" onclick="submitCloseBatch();">Submit</button></td>
                </tr>
            </table>
            <table>
                <tr>
                    <td colspan="2">
                        <input class="touchnoBorder cancel-button" type="button" id="btnCancel" name="btnCancel" onclick="cancelForm();" />
                    </td>
                </tr>
            </table>
        </form>

    </body>
</html>