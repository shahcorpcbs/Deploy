<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!-- #include file="../include/EmployeeSecurity.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim custRs
	
	
	
	
	select case lcase(Request.QueryString("userAction"))
	case "submit"
		saveForm
	case "createdelivery"
		createDelivery
	end select
	
	
	
	
	sub saveForm()
		dim query, rs

		query = "update customer set routenotes = '" & Request.Form("routeNotes") & "', routeaddress = '" & Request.Form("routeAddress") & "' where customersequencenumber = " & session("customersequencenumber")
		qryexecute query
	
	end sub
	
	
	sub createDelivery()
		dim query, rs

		if not checkIfCustomerHasDelivery() then
			query = "insert into customerdelivery(customersequencenumber) values (" & session("customersequencenumber") & ")"
			qryexecute query
		end if
	
	end sub
	function checkIfCustomerHasDelivery()
		dim query, rs
		
		query = "select count(*) as cnt from customerdelivery where customersequencenumber = " & session("customersequencenumber")
		set rs = getdisconnectedrecordset(query)
		
		checkIfCustomerHasDelivery = rs("cnt") > 0
		
		set rs = nothing
	end function
	
	query = "select * from customer where customersequencenumber = " & session("customersequencenumber")
	set custRs = getdisconnectedrecordset(query)
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Customer Routes</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function submitForm(){
		document.customerRoutesForm.action=document.customerRoutesForm.action + "?userAction=submit";
		document.customerRoutesForm.submit();
		return true;
	}

	function cancelForm(){
		document.customerRoutesForm.action = "\CustomerEntry.asp?mode=edit";
		document.customerRoutesForm.submit();
	}
	
	function createDelivery(){
		document.customerRoutesForm.action = "?userAction=createdelivery";
		document.customerRoutesForm.submit();
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0 onload = "">

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">&nbsp;Routes</B>
<FORM id="customerRoutesForm" name="customerRoutesForm" action="" method="Post">

<%
	if not checkIfCustomerHasDelivery() then %>
	
	<CENTER>
	Customer currently is not set up for delivery.	
	<INPUT type="button" value="Create Delivery" onclick="createDelivery()"></INPUT> to continue.<br><br>

	<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">

	</CENTER>
<%	else
%>

<TABLE ALIGN=center>
	<TR>
	<TD>
		<TABLE ALIGN=center  CELLSPACING=20>
		<TR>
			<TD>
				<TABLE width="100%">
					<TR><TD>Sunday</TD><TD><SELECT>    <OPTION value="0"></OPTION><OPTION value="1">Dropoff</OPTION><OPTION value="2">Pickup</OPTION><OPTION value="3">Pickup And Dropoff</OPTION><OPTION value="4">Always Stop</OPTION></SELECT></TD></TR>
					<TR><TD>Monday</TD><TD><SELECT>    <OPTION value="0"></OPTION><OPTION value="1">Dropoff</OPTION><OPTION value="2">Pickup</OPTION><OPTION value="3">Pickup And Dropoff</OPTION><OPTION value="4">Always Stop</OPTION></SELECT></TD></TR>
					<TR><TD>Tuesday</TD><TD><SELECT>   <OPTION value="0"></OPTION><OPTION value="1">Dropoff</OPTION><OPTION value="2">Pickup</OPTION><OPTION value="3">Pickup And Dropoff</OPTION><OPTION value="4">Always Stop</OPTION></SELECT></TD></TR>
					<TR><TD>Wednesday</TD><TD><SELECT> <OPTION value="0"></OPTION><OPTION value="1">Dropoff</OPTION><OPTION value="2">Pickup</OPTION><OPTION value="3">Pickup And Dropoff</OPTION><OPTION value="4">Always Stop</OPTION></SELECT></TD></TR>
					<TR><TD>Thursday</TD><TD><SELECT>  <OPTION value="0"></OPTION><OPTION value="1">Dropoff</OPTION><OPTION value="2">Pickup</OPTION><OPTION value="3">Pickup And Dropoff</OPTION><OPTION value="4">Always Stop</OPTION></SELECT></TD></TR>
					<TR><TD>Friday</TD><TD><SELECT>    <OPTION value="0"></OPTION><OPTION value="1">Dropoff</OPTION><OPTION value="2">Pickup</OPTION><OPTION value="3">Pickup And Dropoff</OPTION><OPTION value="4">Always Stop</OPTION></SELECT></TD></TR>
					<TR><TD>Saturday</TD><TD><SELECT>  <OPTION value="0"></OPTION><OPTION value="1">Dropoff</OPTION><OPTION value="2">Pickup</OPTION><OPTION value="3">Pickup And Dropoff</OPTION><OPTION value="4">Always Stop</OPTION></SELECT></TD></TR>
				</TABLE>
			</TD>
			<TD>
				<TABLE>
					<TR>
						<TD>Notes</TD>
						<TD align =left>
							<TEXTAREA rows="6" cols="40" name="routeNotes"><%=custRs("routenotes")%></TEXTAREA>
						</TD>
					</TR>
					<TR>
						<TD>Delivery Address<br>
							<INPUT type="button" value="Shipping" />
							<INPUT type="button" value="Billing" />
						</TD>
						<TD align =left>
							<TEXTAREA rows="3" cols="40" name="routeAddress"><%=custRs("routeaddress")%></TEXTAREA>
						</TD>
					</TR>
					<TR>
						<TD>Delivery Notification</TD>
						<TD><SELECT><OPTION>None</OPTION><OPTION>Email</OPTION><OPTION>Call</OPTION><OPTION>Email And Call</OPTION></SELECT></TD>
					</TR>
				</TABLE>
			</TD>
		</TR>
		</TABLE>
	</TD>
	</TR>
	<TR>
	<TD valign="top">
		<TABLE border="0" cellspacing="0" cellpadding="4" width="100%" style="border:2px inset;">
			<TR style="background:#CCC;" >
				<TH style="width:10px">Route</TH>
				<TH style="width:200px" align="left">Name</TH>
				<TH style="width:40px">Days</TH>
				<TH style="width:40px">Stops</TH>
				<TH style="width:40px">Distance</TH>
				<TH style="width:60px">Map</TH>
			</TR>
			
			<%
				dim rowColor
				
				query = "select * from route"
				set rs = getdisconnectedrecordset(query)
				
				rowColor = "white"
				
				while not(rs.eof or rs.bof) %>
			<TR style="background:<%=rowColor%>">
				<TD style="width:10px" align="center"><INPUT type="radio" name="selectedRoute"></INPUT></TD>
				<TD style="width:200px" align="left"><A href="/setup/routeSetup.asp?routeNumber=<%=rs("routeNumber")%>&customerRef=<%=Session("customersequencenumber")%>"><%=rs("name")%></A></TD>
				
				<TD style="width:40px" align="center">
					<%
					if rs("deliverySat") then Response.Write "S" else Response.Write "-" end if
					if rs("deliveryMon") then Response.Write "M" else Response.Write "-" end if
					if rs("deliveryTue") then Response.Write "T" else Response.Write "-" end if
					if rs("deliveryWed") then Response.Write "W" else Response.Write "-" end if
					if rs("deliveryThu") then Response.Write "T" else Response.Write "-" end if
					if rs("deliveryFri") then Response.Write "F" else Response.Write "-" end if
					if rs("deliverySun") then Response.Write "S" else Response.Write "-" end if
					%>
				</TD>
				
				<TD style="width:40px" align="center">???</TD>
				<TD style="width:40px" align="center">???</TD>
				<TD style="width:60px" align="center"><IMG style="width:50x;height:40px" src="../<%=rs("MapImage")%>"></IMG></TD>
			</TR>
			<%
                    if rowColor = "white" then
                        rowColor = "#EEE"
                    else
                        rowColor = "white"
                    end if
                    
					rs.movenext
				wend
				
				set rs = nothing
			%>
			
		</TABLE>
	</TD>
	
	</TR>
	


</TABLE>


<DIV style="text-align:center; margin-top:20px">
	<INPUT class=touchnoborder id=okButton name=okButton type=button value=""  style="background-image:url(../images/OK.gif)" onClick= "submitForm()">
	<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
</DIV>
	

<%end if%>
	
</FORM>   

</BODY>
</HTML>


<%
	set custRs = nothing
%>
