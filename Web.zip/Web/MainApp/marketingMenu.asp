<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<HTML>
<HEAD>
<TITLE>Specialized Reports Menu</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function cancelForm(){
		document.marketingMenuForm.action="managerMenu.asp";
		document.marketingMenuForm.submit();
	}	

	function showUserQuery() {
		document.marketingMenuForm.action="/mainapp/querylist.asp";
		document.marketingMenuForm.submit();
	}
	function showSendEmail() {
		document.marketingMenuForm.action="/mainapp/sendemail.asp";
		document.marketingMenuForm.submit();
	}
	function showCustomForm() {
		document.marketingMenuForm.action="/setup/emailFormEditor.asp?fromPage=marketing";
		document.marketingMenuForm.submit();
	}
	
	function showNotifications() {
		document.marketingMenuForm.action="/mainapp/notificationList.asp";
		document.marketingMenuForm.submit();
	}

	function showCustEmailSched() {
		document.marketingMenuForm.action="/setup/custEmailReportSetup.asp";
		document.marketingMenuForm.submit();
	}

	function showEmpReportSched() {
		document.marketingMenuForm.action="/setup/empEmailReportSetup.asp";
		document.marketingMenuForm.submit();
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Specialized Reports Menu</H1>
<FORM id="marketingMenuForm" name="marketingMenuForm" action="start2.asp" method="Post">
<TABLE ALIGN=center BORDER=0 CELLSPACING=0 CELLPADDING=0 >
	<TR height=50px><td></td>
	</TR>

	<TR>    
		<TD align=center >
			<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=customForm onclick="showCustomForm()">Forms</button>
	    </TD>
		<TD align=center >
			<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=userQuery onclick="showUserQuery()">Run Query</button>
	    </TD>
		<TD align=center >
			<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=notification onclick="showNotifications()">Notifications</button>
	    </TD>
	    
	</TR>
	<TR>
		<TD align=center >
			<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=cusReportSch onclick="showCustEmailSched()">Customer Email Schedule</button>
	    </TD>
		<TD align=center >
			<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=empReportSch onclick="showEmpReportSched()">Employee Report Schedule</button>
	    </TD>
		<TD align=center >
			<BUTTON class=std style="width:200px;height:100px;font-size:12px" name=sendEmail onclick="showSendEmail()">Outgoing Messages<br />(No Longer Used)</button>
	    </TD>
	    
	</TR>
	<TR height=100px>
		<TD align=center colspan=3>
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
		</TD>
	</TR>	
	
</TABLE>

</FORM>   

</BODY>
</HTML>
