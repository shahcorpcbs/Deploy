<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
    dim query, rs
    
    function insertNewInventoryList()
        dim rs
        openConnection
        dbInsert "insert into inventorylist (storeid) values (" & session("storeid") & ")"
        set rs = dbselect("select @@IDENTITY as rowid")
        insertNewInventoryList = rs("rowid")
        set rs = nothing
        closeconnection
    end function
    
    
    sub newInventoryList()
        dim itemid
        
        itemid = insertNewInventoryList()
        
        response.redirect "/MainApp/inventoryItem.asp?useraction=view&inventorylistid=" & itemid
    end sub
    
    select case lcase(request.querystring("useraction"))
    case "newinventorylist"

        newInventoryList
    
    
    end select
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">

	function viewInventoryItem(itemid, readonly) {
        document.inventoryList.action = "/MainApp/inventoryItem.asp?useraction=view&inventorylistid=" + itemid + "&readonly=" + readonly;
        document.inventoryList.submit();
    }
    
    function newInventoryList() {
        document.inventoryList.action = "/MainApp/inventoryList.asp?useraction=newinventorylist";
        document.inventoryList.submit();
    }
    
    function exitForm() {
        document.inventoryList.action = "/MainApp/toolsMenu.asp";
        document.inventoryList.submit();
    }
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->

<FORM name="inventoryList" ID="inventoryList" METHOD=POST  style="margin:0;padding:0">
<BR>
<BR>

<TABLE width=100% cellpadding=0 cellspacing=0 border=0>


<TR><TD>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="newInventoryList()">New</BUTTON>
	</SPAN>
	
	<SPAN style="float:right">
		<BUTTON onclick="exitForm()">Exit</BUTTON>
	</SPAN>
</DIV>	

</TD></TR>

<TR><TD>
<TABLE  class="itable" align=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0>
    <TR>
        <TH style="width:60px">&nbsp;</TH>
        <TH align="left">Date Created</TH>
        <TH align="center">Match Criteria</TH>
    </TR>

<%
    query = "select * from inventorylist where storeid = " & session("storeid") & " and inventorylistid in (select distinct inventorylistid from inventoryitem) order by datecreated desc"

    set rs = getdisconnectedrecordset(query)
    

    
    while not(rs.eof or rs.bof)
%>
    <TR> 
        <TD style="width:60px"><INPUT type="button" style="width:55px" value="<%if rs("hasreconciled") then%>View<%else%>Edit<%end if%>" onclick="viewInventoryItem(<%=rs("inventorylistid")%>, <%if rs("hasreconciled") then%>true<%else%>false<%end if%>)"></TD>
        <TD align="left"><%=rs("datecreated")%></TD>
        <TD align="center">
        <%
            select case lcase(rs("matchtype"))
            case "0"  response.write "All"
            case "1"  response.write "Creation date before " & rs("matchend")
            case "2"  response.write "Due date before " & rs("matchend")
            case "3"  response.write "Invoice number between " & rs("matchbegin") & " and " & rs("matchend")
            case "4"  response.write "Rack number between " & rs("matchbegin") & " and " & rs("matchend")
            end select
        %>
        
        </TD>
        
    </TR>
<%
        rs.movenext
    wend
    
    set rs = nothing
%>
</TABLE>
</TD></TR>
</TABLE>
</BODY>
</HTML>
