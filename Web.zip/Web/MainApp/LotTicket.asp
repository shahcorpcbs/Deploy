<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim isSubmitted
	dim actionString
	dim invoiceNo
	dim isValid
	dim ticketNo
	dim colorChange
	dim dupName : dupName = ""

	isSubmitted = Request.QueryString("submitted")
	actionString = Request.QueryString("userAction")
	invoiceNo = Request.QueryString("txtInvoiceNo")
  
	session("s_errmessage") = request.querystring("alert")
  
	if isSubmitted = "" then isSubmitted = false

	if (isSubmitted) then
		if (actionString = "validate") then
			getInvoice()
			if (isValid) then
				Response.Redirect("/Mainapp/assignTicketsToLots.asp?origin=lotticket&ticketNumbers="& ticketNo)
			end if
		end if
	else
		if (actionString = "print") then
			ticketNo = Request.QueryString("ticketNumbers")
			session("s_errmessage") = ""
			session("customerSequencenumber") = getCustomerSeqForTicket(ticketNo)
		end if
	end if

    checkForDups

	function getCustomerSeqForTicket(ticketNumber)
		dim query, rs
		
		if ticketNumber <> "" then
			
			query = " select customersequencenumber from ticket where ticketnumber in (" & ticketNumber & ")"
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getCustomerSeqForTicket = rs("customerSequenceNumber")
			end if
		end if
	
	end function

	function getInvoice()
		dim sqltxt, invoiceRst, duedateDay, dueDate, finishpref, starchpref

		sqltxt = "select * from ticket where ticketstatus = 'AC' and lotid is null and invoicenumber in (" & invoiceno & ")"

		set invoiceRst = getdisconnectedrecordset(sqltxt)

		if invoiceRst.Recordcount = 0 then
			session("s_errmessage") = "Invoice " & invoiceno & " is not active or is already on a lot."
			invoiceno = ""
			isValid = false
		else


			duedateDay = WeekdayName(Weekday(invoiceRst.fields("dueDate").value))
			dueDate = invoiceRst.fields("dueDate").value
			finishpref = invoiceRst.fields("finishpreferencename").value
			starchpref = invoiceRst.fields("starchpreferencename").value
			session("s_errmessage") = ""
			isValid = true
			
			while not (invoiceRst.eof or invoiceRst.bof)
				if ticketNo <> "" then ticketNo = ticketNo & ","
				ticketNo = ticketNo & invoiceRst.fields("ticketnumber").value
				invoiceRst.movenext
			wend
		end if
	end function

	function getData()

		dim sqltxt

		sqltxt = "select * from ticketlineitem where ticketlinetype in ('IT','AC') and ticketnumber = " & ticketno
		set detRst = getdisconnectedRecordSet(sqltxt)
		detRst.Sort = "departmentName ASC"

		if detRst.Recordcount > 0 then
			detRst.MoveFirst
			dept=detRst.Fields("departmentName").Value
			pkgqty = 0
			While Not detRst.eof
			If detRst.Fields("departmentName").Value = dept then
				if not isnull(detRst.Fields("packagedQuantity").value) then
					pkgqty = pkgqty + clng(detRst.Fields("packagedQuantity").value)*clng(detRst.Fields("quantity").value)
				end if
			else
				pkgqty = clng(detRst.Fields("packagedQuantity").value)*clng(detRst.Fields("quantity").value)
			end if
			detRst.moveNext
			wend
		end if
	end function

	function isInt(input)
		dim i, d
		
		isInt = true
		
		for i=1 to len(input)
			d = Mid(input,i,1)
			if Asc(d) < 48 OR Asc(d) > 57 then
				isInt = false
				exit for
			end if
		next
	
	end function

	function getTagColorCode(colorName)
		dim query, rs
		
		query = " select hexcolor from lotcolor where name = '" & trim(colorName) & "'"
		set rs = getdisconnectedrecordset(query)
		
		
		if rs.recordcount > 0 then
			getTagColorCode = "#" & rs("hexcolor")
		else
			getTagColorCode = colorName
		end if
	
		set rs = nothing
	end function
	
	function promptColorChange(newColor)
		colorChange = newColor
	
	end function
	
		
	function formatTicketTagBlock(department, startTagNumber, endTagNumber, lotNumber, lotColor)
		dim result

		result = "<DD style=""background:" & getTagColorCode(lotColor) & """>"
		
		result = result & "<span class=""department"">" & department & "</span>"
		
		if lotNumber <> "" then			
			result = result & lotNumber & "/"
		end if


		if startTagNumber <> "" then
			result = result & startTagNumber
			
			if startTagNumber <> endTagNumber then
				result = result & "-" & endTagNumber
			end if
			
			if startTagNumber = 0 and trim(lotColor) <> "" then
				promptColorChange trim(lotColor)
			end if
			
		else
			result = result & endTagNumber
		end if
	
		if trim(lotColor) <> "" then			
			result = result & " (" & trim(lotColor) & ")"
		end if
		
		result = result & "</DD>"
		
		formatTicketTagBlock = result
	end function
	
	function getHeaderForTag(rs)
		dim result
		
		getHeaderForTag = rs("invoiceNumber") & " " & rs("lotDefaultName") & "|" & rs("departmentName")
	
	end function
	
	function getTagsAsCSV(ticketNumbers)
		Dim query, rs
		Dim lastTagNumber
		Dim lastTagColor
		Dim groupFirstTagNumber
		Dim lastLotNumber
		dim result
		dim lastLotHeader
		dim currentLotHeader
		dim lastPrintedLotHeader
		dim lastLotHeaderParts
		dim lastPrintedLotHeaderParts
		
		lastTagNumber = ""
		lastTagColor = ""
		lastLotNumber = ""
		groupFirstTagNumber = ""
		lastLotHeader = ""
		lastPrintedLotHeader = ""
		currentLotHeader = ""
		
		query = "SELECT  ticket.invoiceNumber, Department.name as departmentName, tickettag.lotID, lotNumber, tickettag.ticketNumber, tagNumber AS TagNumber, isnull(tagColor, '') as tagColor, isnull(LotDefault.name, '') as lotDefaultName FROM TicketTag "
		query = query & " INNER JOIN Ticket ON TicketTag.ticketNumber = Ticket.ticketNumber "
		query = query & " LEFT OUTER JOIN Department ON TicketTag.departmentID = Department.departmentID "
		query = query & " LEFT OUTER JOIN Lot ON TicketTag.lotID = Lot.ID "
		query = query & " LEFT OUTER JOIN LotDefault ON Lot.lotDefaultID = LotDefault.lotDefaultID "
		query = query & " WHERE TicketTag.ticketNumber IN (" & ticketNumbers & ") "
		query = query & " ORDER BY Lot.lotDefaultID, TicketTag.ticketNumber, Department.departmentID, lotNumber, tagColor, "
		query = query & " CASE dbo.isInt(tagNumber) "
		query = query & " WHEN 0 THEN -1 "
		query = query & " ELSE cast(tagNumber as integer) "
		query = query & " END "

		Set rs = getDisconnectedRecordset(query)

		if rs.RecordCount > 0 then

			lastTagNumber = rs("tagNumber")
			lastTagColor = rs("tagcolor")
			lastLotNumber = rs("lotNumber")
			currentLotHeader = getHeaderForTag(rs)
			lastLotHeader = currentLotHeader
			lastPrintedLotHeader = "|"
			lastPrintedLotHeaderParts = split(lastPrintedLotHeader, "|")
			lastLotHeaderParts = split(lastLotHeader, "|")
			

						
			if isInt(lastTagNumber)	then groupFirstTagNumber = lastTagNumber
			

			rs.MoveNext

			while not (rs.eof or rs.bof)
				currentLotHeader = getHeaderForTag(rs)
				lastLotHeaderParts = split(lastLotHeader, "|")

				if isInt(lastTagNumber) then
					if trim(lastLotNumber) = trim(rs("lotNumber")) _
					and trim(lastTagColor) = trim(rs("tagcolor")) _
					and trim(clng(lastTagNumber) + 1) = trim(rs("tagNumber")) _
					and lastLotHeader = currentLotHeader  then
						lastTagNumber = rs("tagNumber")
						lastTagColor = rs("tagcolor")
						lastLotNumber = rs("lotNumber")
						lastLotHeader = currentLotHeader
					else

					'response.write lastLotHeaderParts(0) & "=" & lastPrintedLotHeaderParts(0) & "<br>"
					
						if lastLotHeaderParts(0) <> lastPrintedLotHeaderParts(0) then
							result = result & "<DT>" & lastLotHeaderParts(0) & "</DT>"
							lastPrintedLotHeader = lastLotHeader
							lastPrintedLotHeaderParts = split(lastPrintedLotHeader, "|")
						end if
						
						
						result = result & formatTicketTagBlock(lastLotHeaderParts(1), groupFirstTagNumber, lastTagNumber, lastLotNumber, lastTagColor)
		
						lastTagNumber = rs("tagNumber")
						lastTagColor = rs("tagcolor")
						lastLotNumber = rs("lotNumber")
						lastLotHeader = currentLotHeader
						
						if isInt(lastTagNumber)	then
							groupFirstTagNumber = lastTagNumber
						else
							groupFirstTagNumber = ""
						end if
					end if
				else
				
					if lastLotHeaderParts(0) <> lastPrintedLotHeaderParts(0) then
						result = result & "<DT>" & lastLotHeaderParts(0) & "</DT>"
						lastPrintedLotHeader = lastLotHeader
						lastPrintedLotHeaderParts = split(lastPrintedLotHeader, "|")
					end if
					
					result = result & formatTicketTagBlock(lastLotHeaderParts(1), groupFirstTagNumber, lastTagNumber, lastLotNumber, lastTagColor)
	
					lastTagNumber = rs("tagNumber")
					lastTagColor = rs("tagcolor")
					lastLotNumber = rs("lotNumber")
					lastLotHeader = currentLotHeader
					
					if isInt(lastTagNumber)	then
						groupFirstTagNumber = lastTagNumber
					else
						groupFirstTagNumber = ""
					end if
				end if

				rs.MoveNext
			wend

			lastLotHeaderParts = split(lastLotHeader, "|")
			
			if lastLotHeaderParts(0) <> lastPrintedLotHeaderParts(0) then
				result = result & "<DT>" & lastLotHeaderParts(0) & "</DT>"
				lastPrintedLotHeader = lastLotHeader
			end if
						
			result = result & formatTicketTagBlock(lastLotHeaderParts(1), groupFirstTagNumber, lastTagNumber, lastLotNumber, lastTagColor)
	
		end if
		
		getTagsAsCSV = result
	end function
	
	function getInvoiceNumbers(ticketNumbers)
		dim query, rs
		dim result
		
		query = " select invoicenumber from ticket where ticketnumber in (" & ticketNumbers & ")"

		set rs = getdisconnectedrecordset(query)
		
		while not (rs.eof or rs.bof)
			if result <> "" then result = result & ","
			result = result & rs("invoicenumber")
			rs.movenext
		wend

		set rs = nothing
		
		getInvoiceNumbers = result
	end function

	function checkForDups
	    dim query, rs
	    query = "select name, count(*) cnt from Lot where Status = 'O' group by lotDefaultId, name having count(*) > 1"
	    set rs = getdisconnectedrecordset(query)
        if rs.recordcount > 0 then
            dupName = rs("name")
        end if
	end function


%>
<HTML>
<HEAD>
<TITLE>Assign Invoice Number To Lot</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" src="../external/jquery.js"></script>

<script language="javascript" type="text/javascript" src="/Script/printing.js"></script>

<script language="javascript" type="text/javascript">

	
	function submitForm(element) {
		if(txtInvoiceNo.value == "" || !checkInt(txtInvoiceNo.value)) return false;
		
		if (element == "validate"){
			document.lotsTicketNumber.action = "?submitted=true&userAction=validate&txtInvoiceNo=" + encodeURIComponent(txtInvoiceNo.value);
			document.lotsTicketNumber.submit();
		}
		else{
			document.lotsTicketNumber.action = "?submitted=true&userAction=done";
			document.lotsTicketNumber.submit();
		}
	}

	function cancelForm() {
		document.lotsTicketNumber.action = "toolsMenu.asp";
		document.lotsTicketNumber.submit();
	}


	function captureKeyDownEvent(element){
		if (event.keyCode == 13){
			if (element.name == "txtInvoiceNo" && trim(element.value).length != 0){
				submitForm("validate");
			}
		}
	}

	function captureKeyUpEvent(element){
		if (event.keyCode == 13){
			if (element.name == "txtInvoiceNo" && trim(element.value).length != 0){
				submitForm("validate");
			}
		}
	}

	function setFocusOnControl(element){
			txtInvoiceNo.select();
	}

	function printInvoiceAndTags() {
	    clearAlertMsg();
		var ticketNumber;
		var actionStr;
		var aTicketNo;

		actionStr = document.lotsTicketNumber.actionString.value;
		if (actionStr == "print") {
	           ticketNumber = document.lotsTicketNumber.ticketNo.value;
	           PrintEditInvoice(ticketNumber, 1);
	           PrintTagsForInvoice(ticketNumber);
           }
		setFocusOnControl("invoiceNumber");
	}


</script>


<STYLE  type="text/css" >
	#TicketTagList {
		margin: 10px;
	}
	#TicketTagList .department {
		width: 200px;
		overflow: hidden;
		border-right: 1px dotted black;

		margin-right: 10px;
	}
	#TicketTagList DD {
		padding: 5px;
		font-size: 18;
	}
	#TicketTagList DT {
		padding: 5px;
		font-size: 20;
		font-weight: bold;
	}
	#TicketTagContainer  {
		padding: 20px;
	}
	#TicketTagContainer h3 {
		margin: 0;
		padding: 0;
	}
</STYLE>


<BODY topmargin=0 leftmargin=0 	onLoad= "promptAlerts();">

<meta http-equiv="refresh" content="180;URL=/mainapp/start2.asp">

<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->





<H1>Assign Invoice to Lot</H1>
<FORM id="lotsTicketNumber" name="lotsTicketNumber" action="" method="post" >
<input type=hidden name="actionString" value="<%= actionString%>">
<input type=hidden name="ticketNo" value="<%= ticketNo%>">
</FORM>

<%
	if ticketNo <> "" then 
%>
<div id="TicketTagContainer">
<DL id="TicketTagList">
<%=getTagsAsCSV(ticketNo)%>
</DL>
</div>
<%
	end if
%>

	<TABLE ALIGN=center width=800px BORDER=0 CELLSPACING=0 CELLPADDING=2 >
		<% if len(trim(session("s_errMessage")) ) > 0 then %>
		<tr>
			<td colspan=5><font color = red size =3 ><b><%= session("s_errMessage")%></b></font></td>
		<td></td>
		</tr>
		<% end if %>



		<tr>
			<td colspan=2 class="label" align="center" style=font-size=16>Invoice</td>
		</tr>
		<tr>
			<td colspan=2 align="center" >
				<INPUT id=txtInvoiceNo name=txtInvoiceNo class=text style="HEIGHT: 25px; WIDTH: 200px" value="<%=invoiceno%>"
					  onKeyUp="captureKeyUpEvent(this)" >
			</td>
			<td rowspan=12 valign=top>
					<tr height=20px><td></td></tr>
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=ok name=ok type=button value="" style="background-image:url(../images/OK.gif)" onClick="submitForm('validate')">&nbsp&nbsp&nbsp&nbsp&nbsp
							<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
						</td>
					</tr>
			</td>
		</tr>
	</TABLE>

	

</BODY>
<script language="javascript" type="text/javascript">
	function promptAlerts() {
		<% if colorChange <> "" then %>
            cbs_alert('A new lot has started. Remember to change the tag color to <%=colorChange%>', printInvoiceAndTags);
		<% else %>
		    printInvoiceAndTags();
		<% end if %>

		<% if dupName <> "" then %>
		    cbs_alert("Two lots for [<%=dupName%>] are open at the same time. Possibly two terminals created one " +
		        "at the same time. Please close one before continuing.")
		<% end if %>

	}
	</script>
</HTML>