<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query
	dim rs
	dim useraction
	dim activeStore
	dim activeEmployee
	dim originPage
	dim activeTerminal
	dim employeeSecurityLevel
	
	useraction = trim(Request.QueryString("useraction"))

	activeEmployee = trim(Request.QueryString("employee"))
	if activeEmployee = "" then
		activeEmployee = trim(Request.Form("activeEmployee"))
		if activeEmployee = "" then
		  activeEmployee = -1
		end if
	end if

	employeeSecurityLevel = getEmployeeSecurityLevel(session("employeeid"))

	activeStore = trim(Request.QueryString("store"))
	if activeStore = "" then
		activeStore = trim(Request.Form("activeStore"))
		if activeStore = "" then
			activeStore = Session("storeid")
		end if
	end if
	
	activeTerminal = trim(Request.QueryString("terminal"))
	if activeTerminal = "" then
		activeTerminal = trim(Request.Form("activeTerminal"))
		if activeTerminal = "" then
			activeTerminal = Session("terminalID")
		end if
	end if
	
	originPage = trim(Request.QueryString("originpage"))
	if originPage = "" then
		originPage = trim(Request.Form("rf_originpage"))
		if originPage = "" then
			originPage = trim(Request.Form("originpage"))
		end if
	end if
	
	
	
	
	select case useraction


		case "assign"
			assignFunction
		case "unassign"
			unassignFunction
		case "reassign"
			reassignFunctions
		case "addrole"
		      addRole
		case "selectprimary"
            selectPrimary
        case "saveToAll"
		        unassignOtherTerminals
		    	query = "select terminalID from Terminal where storeID = " & activeStore & " and terminalId != " & activeTerminal
            	set rs = getdisconnectedrecordset(query)
            	while not (rs.eof or rs.bof)
            	    addCurrentRoles rs("terminalID")
                    rs.movenext
                wend
        case "deletetag"
        	deleteTags
        '	deleteTag request.querystring("tagid")
	end select
	
	sub addRole()
	   dim query
	   
	   query = "insert into employeetag (name) values ('" & request.querystring("rolename") & "')"

	   qryexecute query
	end sub
	
	
	function getEmployeeSecurityLevel(employeeID)
		dim query, rs
		
		query = " select count(*) as cnt from "
		query = query & " employeetagassignment "
		query = query & " inner join employeetag on employeetagassignment.tagid = employeetag.id "
		query = query & " where employeetagassignment.employeeid = " & employeeID
		query = query & " and employeetag.name = 'All Functions' "

		set rs = getdisconnectedrecordset(query)

		if rs("cnt") > 0 then
			getEmployeeSecurityLevel = 32000
			set rs = nothing
			exit function
		end if

		set rs = nothing

		query = " select isnull(max(isnull(employeetag.securityLevel, 0)), 0) as securityLevel "
		query = query & " from employeetagassignment "
		query = query & " inner join employeetag on employeetagassignment.tagid = employeetag.id "
		query = query & " where employeetagassignment.employeeid = " & employeeID

		set rs = getdisconnectedrecordset(query)
		
		getEmployeeSecurityLevel = 0
		
		if rs.recordcount > 0 then
			getEmployeeSecurityLevel = rs("securityLevel")
		end if
		
		set rs = nothing
	end function
	
	sub deleteTag(tagid)
		dim query, rs
		dim cnt
		
		query = " select count(*) as cnt from employeetagassignment where tagid = " & tagid
		set rs = getdisconnectedrecordset(query)
		
		cnt = rs("cnt")
		
		set rs = nothing
		
		if cnt <= 0 then
			query = "delete from employeetagsecurity where tagid = " & tagid
			qryexecute query
			
			query = "delete from employeetag where id = " & tagid
			qryexecute query
		end if
		
	end sub
	
	sub deleteTags()
		dim funcNames
		dim name
		set funcNames = Request.Form("toassign")
		
		for each name in funcNames
			deleteTag name
		next
	end sub
	
	sub reassignFunctions()
		dim funcNames
		dim name
		set funcNames = Request.Form("toassign")
		
		for each name in funcNames
			assignFunction name, activeTerminal
		next

        set funcNames = Request.Form("tounassign")

        for each name in funcNames
            unassignFunction name
        next
		
	end sub

	sub selectPrimary()
	   dim query, rs

	   query = "update employeetagassignment "
	   query = query & " set [primary] = 0 "
	   query = query & " where employeeid = " & activeEmployee
	   query = query & " and terminalid = " & activeTerminal
	   
	   qryexecute query
	   

        query = "update employeetagassignment "
        query = query & " set [primary] = 1 "
        query = query & " where employeeid = " & activeEmployee
        query = query & " and terminalid = " & activeTerminal
        query = query & " and tagid = " & request.querystring("tagid")

        
        qryexecute query

	
	end sub
	
	sub assignFunction(tagid, terminalId)
		
        if tagid <> "" and activeEmployee <> "" and activeEmployee <> "-1" then
            query = "insert into EmployeeTagAssignment (EmployeeID, TerminalID, TagID) "
            query = query & " values ("
            query = query & activeEmployee & ","
            query = query & terminalId & ","
            query = query & tagid & ")"
            
            qryexecute(query)
        end if
	end sub
	
	
	sub unassignFunction(tagid)

		
		if tagid <> "" and activeEmployee <> "" then
			query = "delete EmployeeTagAssignment where EmployeeID = " & activeEmployee
			query = query & " and tagid = " & tagid
			query = query & " and TerminalID = " & activeTerminal

			qryexecute(query)
		end if
	
	end sub

	sub unassignOtherTerminals()
	    query = "delete EmployeeTagAssignment where EmployeeID = " & activeEmployee & " and terminalId != " & activeTerminal
		qryexecute(query)
	end sub

	sub addCurrentRoles(terminalId)
	    dim query2, rs2
	    query2 = "select distinct employeetagassignment.tagid from employeetagassignment where"
    	query2 = query2 & " employeetagassignment.employeeid = " & activeEmployee
    	query2 = query2 & " and employeetagassignment.terminalid = " & activeTerminal

        set rs2 = getdisconnectedrecordset(query2)
        while not (rs2.eof or rs2.bof)
            assignFunction rs2("tagid"), terminalId
        rs2.movenext
        wend
	end sub

%>
<HTML>
<HEAD>
<TITLE>Employee Setup</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>
<script language="javascript" type="text/javascript">

	function newRole(){
		cbs_prompt("Enter a name for the new employee role.", handleAddingNewRole);
	}

	function handleAddingNewRole() {
        clearPromptMsg();
        var roleName = document.getElementById('inputTxtLine').value
	    if (roleName) {
			document.es.action = "?useraction=addrole&rolename=" + roleName;
			document.es.submit();
	    }
	}
	
	function done(){
		switch(document.es.originpage.value){
			case "addnewemployee":
				document.es.action = "addNewEmployee.asp?useraction=edit&employee=<%=activeEmployee%>";
				break;

			case "employeemanagement":
			default:
				document.es.action = "employeeManagement.asp";
				break;
		}
		
		document.es.submit();
	}
		
	function assignRole(rID, tID){
			document.es.action = "?useraction=assign" +
					"&tagid=" + tID +
					"&employee=" + eID;
					
			document.es.submit();
	
	}
	function unassignRole(rID, tID){
			document.es.action = "?useraction=unassign" +
					"&tagid=" + tID +
					"&employee=" + eID;
					
			document.es.submit();
	
	}

	function selectEmployee(){
		var selectedEmployee;

		selectedEmployee = document.es.selectedemployee.value;

		document.es.action = "?employee=" + selectedEmployee;
		document.es.submit();
	}
	
	function selectTerminal(){
		var selectedTerminal;

		selectedTerminal = document.es.selectedterminal.value;

		document.es.action = "?terminal=" + selectedTerminal;
		document.es.submit();
	}
	function selectStore(){
		var selectedStore;

		selectedStore = document.es.selectedstore.value;

		document.es.action = "?store=" + selectedStore;
		document.es.submit();
	}
	
	function editRoleSecurity()
	{
        if(document.es.toassign.value != "")
        {
    		document.es.action = "EditRoleSecurity.asp?tagid=" + document.es.toassign.value +
    			"&employeeid=" + document.es.activeEmployee.value;
    					
    		document.es.submit();
		}
		else if(document.es.tounassign.value != "")
		{
    		document.es.action = "EditRoleSecurity.asp?tagid=" + document.es.tounassign.value +
    			"&employeeid=" + document.es.activeEmployee.value;
    					
    		document.es.submit();
		}
		else
		  cbs_alert("Please select a role to edit security permissions.");
		
	}
	function deleteRole() {
        if(document.es.toassign.value != "")
        {
    		document.es.action = "?useraction=deletetag&tagid=" + document.es.toassign.value;
    		document.es.submit();
		}
		else
		  cbs_alert("Please select a role to delete.");
	}
	function reassignFunctions() {
		document.es.action = "?userAction=reassign"
		document.es.submit();
	}
	
	function selectPrimary() {
		document.es.action = "?userAction=selectprimary&tagid=" + document.es.tounassign.value
		document.es.submit();
    }

	function saveToAll() {
		document.es.action = "?userAction=saveToAll";
		document.es.submit();
    }
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Employee Setup</H1>
<FORM id="es" name="es" method="post">


<input type=hidden name="activeEmployee" value="<%=activeEmployee%>">
<input type=hidden name="originpage" value="<%=originpage%>">
<input type=hidden name="activeTerminal" value="<%=activeTerminal%>">

<div style="width:95%;margin-left:5%;">

<div style="padding:0px 5px 20px 5px;text-align: center;">
	<input style="width:100px;height:50px" type=button value="Ok" onclick="done()">
</div>


<div style="padding:0px 5px 20px 5px;text-align: center;">


	<select style="font-size:16;width:260px;" name=selectedstore onchange="selectStore()">
<%	
	query = "select storeid, name from store"
	set rs = getdisconnectedrecordset(query)
	
	while not (rs.eof or rs.bof)
%>
		<option <%if trim(rs("storeid")) = trim(activeStore) then%>selected<%end if%> value = "<%=rs("storeid")%>">
				<%=rs("name")%>
		</option>
<%	
		rs.movenext
	wend
	
	set rs = nothing
%>
	</select>

	<select style="font-size:16;width:260px;" name=selectedterminal onchange="selectTerminal()">
<%	
	query = "select terminalID, name from Terminal where storeID = " & activeStore
	set rs = getdisconnectedrecordset(query)
	
	while not (rs.eof or rs.bof)
%>
		<option <%if trim(rs("terminalID")) = trim(activeTerminal) then%>selected<%end if%> value = "<%=rs("terminalID")%>">
				<%=rs("name")%>
		</option>
<%	
		rs.movenext
	wend
	
	set rs = nothing
%>
	</select>




	<select style="font-size:16;width:260px;" name=selectedemployee onchange="selectEmployee()">
	<option value = "">--- Select Employee ---</option>
<%	
	query = "select employeename, employeeid from employee where employeeStatus = 'A' and storeid = " & activeStore
	query = query & " order by employee.lastname, employee.firstname "
	

	set rs = getdisconnectedrecordset(query)
	
	while not (rs.eof or rs.bof)
%>
		<option <%if trim(rs("employeeid")) = trim(activeEmployee) then%>selected<%end if%> value = "<%=rs("employeeid")%>">
				<%=rs("employeename")%>
		</option>
<%	
		rs.movenext
	wend
	
	set rs = nothing
%>
	</select>
	
</div>


<table align="center">

<tr>
<td>Roles (Security Level <%=employeeSecurityLevel%>)</td>
<td>&nbsp;</td>
<td>Given Roles</td>
</tr>

<tr>

<td>


<select name="toassign" multiple size=10 style="width:300px">
<%

    query = "select employeetag.securityLevel, employeetag.id, employeetag.name, isnull(max(employeetagsecurity.id), 0) as hassecurity from employeetag left outer join employeetagsecurity on employeetag.id = employeetagsecurity.tagid where employeetag.id not in "
	query = query & "(select distinct employeetagassignment.tagid from employeetagassignment where"
	query = query & " employeetagassignment.employeeid = " & activeEmployee
	query = query & " and employeetagassignment.terminalid = " & activeTerminal & ") "



	if trim(Session("employeeID")) <> "1" and trim(activeEmployee) <> "1" then
		query = query & " and employeetag.securityLevel <= " & employeeSecurityLevel
		query = query & " and employeetag.id not in "
		query = query & " (select distinct employeetagsecurity.tagid from employeetagsecurity inner join employeefunction on employeetagsecurity.functionid = employeefunction.id where employeefunction.exclusive = 1)"
	end if
	

  query = query & " group by employeetag.id, employeetag.name, employeetag.securityLevel "

	set rs = getdisconnectedrecordset(query)
	
	while not (rs.eof or rs.bof)
%>
	<option <%if rs("hassecurity") = 0 then%>style="color:gray"<%end if%> value="<%=rs("id")%>"><%=rs("securityLevel") & " - " & rs("Name")%></option>
<%
	rs.movenext
	wend
%>



</select>


</td>


<td style="width:120px" align="center">
	<input style="width:110;height:30px" type="button" value="<-  Move Role  ->" onclick="reassignFunctions()">

</td>

<td>

<select name="tounassign" multiple size=10 style="width:300px">
<%

    query = "select employeetag.securityLevel, employeetag.id, employeetag.name, employeetagassignment.[primary], isnull(max(employeetagsecurity.id), 0) as hassecurity from employeetagassignment inner join employeetag on "
    query = query & " employeetagassignment.tagid = employeetag.id left outer join employeetagsecurity on employeetag.id = employeetagsecurity.tagid  where "
	query = query & " employeetagassignment.employeeid = " & activeEmployee
	query = query & " and employeetagassignment.terminalid = " & activeTerminal
    query = query & " group by employeetag.id, employeetag.name, employeetagassignment.[primary], employeetag.securityLevel "

	set rs = getdisconnectedrecordset(query)
	
	while not (rs.eof or rs.bof)
%>
	<option
    <%if rs("hassecurity") = 0 then%>style="color:gray"<%end if%>
    value="<%=rs("id")%>"><%if rs("primary") then%>(Primary) <%end if%><%=rs("securityLevel") & " - " & rs("Name")%>
    </option>
<%
	rs.movenext
	wend
%>

</select>

</td>

</tr>


<tr>
<td align="center">
<input style="width:100;height:30px" type="button" value="New Role" onclick="newRole();">
<input style="width:100;height:30px" type="button" value="Delete Role" onclick="deleteRole();">
</td>



<td align="center">
    
        <input style="width:100;height:30px" type="button" value="Role Security" onclick="editRoleSecurity()">
</td>


<td align="center">
<input style="width:100;height:30px" type="button" value="Select Primary" onclick="selectPrimary()">
<input style="height:30px" type="button" value="Save To All Terminals" onclick="saveToAll()">
</td>

</tr>

</table>

</FORM>
</BODY>
</HTML>
