<%
	response.redirect "start.asp"
%>