<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/manifest.asp"-->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim manifestid
	dim manifestrs
	dim rackPrefix
	dim datecreate
	dim mtype

	dim search_showClosed
	dim search_daysOfHistory
	dim search_orderBy
	dim search_searchString
	
	rackPrefix = getRackPrefix(session("storeid"))

	manifestid = getReqVar("manifestid")
	datecreate = getManifestDateCreated(manifestid)
	mtype = getManifestType(manifestid)
	
	search_showClosed = getReqVar("showClosed")
	search_daysOfHistory = getReqVar("daysOfHistory")
	search_orderBy = getReqVar("orderBy")
	search_searchString = getReqVar("searchString")
	
	if manifestid = "" then manifestid = 0


	select case lcase(request.querystring("useraction"))
	case "rackinvoices"
		CBS_rackManifest manifestid, session("terminalID"), session("employeeID")
	case "applyfilters"
	case "addfilter"
		addFilter request.querystring("name")
	case "deletefilter"
		deleteFilter request.querystring("manifestfilterid")
	end select

	
	function isOptionEnabled(all, opt)
		dim selopt
		dim i
		
		isOptionEnabled = true

		for each selopt in all
			isOptionEnabled = false
			if lcase(selopt) = lcase(opt) then
				isOptionEnabled = true
				exit function
			end if
		next
	end function
	

	
	if mtype = "TLIST" then
		query = " select isnull(rightside.invoicestatus, leftside.invoicestatus) as invoicestatus, isnull(rightside.invoicenumberkeyed, 1) as invoicenumberkeyed, isnull(rightside.locationkeyed, 1) as locationkeyed, isnull(rightside.invoicenumber, leftside.invoicenumber) as invoicenumber, "
		query = query & " isnull(case when rightside.location is null then leftside.location else rightside.location end, '') as location, "
		query = query & " isnull(leftside.location, '') as leftlocation, "
		query = query & " case when leftside.invoicenumber is null then 'right' else case when rightside.invoicenumber is null then 'left' else 'both' end end as side "
		query = query & " from ( select manifestitem.* from manifestitem where manifestitem.manifestid = " & manifestid & " ) leftside "
		query = query & " full outer join ( select manifestitem.* from manifestitem inner join manifest on manifestitem.manifestid = manifest.manifestid "
		query = query & " where [active] = 1 and [type] in ('TRACKING') and datediff(day, manifest.datecreated, '" & datecreate & "') = 0) rightside "
		query = query & " on leftside.invoicenumber = rightside.invoicenumber "
		query = query & " order by case dbo.isint(isnull(rightside.location, leftside.location)) when 1 then cast(isnull(rightside.location, leftside.location) as int) else 10000000 end "
	else
		query = " select isnull(rightside.invoicestatus, leftside.invoicestatus) as invoicestatus, isnull(rightside.invoicenumberkeyed, 1) as invoicenumberkeyed, isnull(rightside.locationkeyed, 1) as locationkeyed, isnull(rightside.invoicenumber, leftside.invoicenumber) as invoicenumber, "
		query = query & " isnull(case when rightside.location is null then leftside.location else rightside.location end, '') as location, "
		query = query & " isnull(leftside.location, '') as leftlocation, "
		query = query & " case when leftside.invoicenumber is null then 'right' else case when rightside.invoicenumber is null then 'left' else 'both' end end as side "
		query = query & " from ( select manifestitem.* from manifest m1 "
		query = query & " inner join manifest m2 on m1.parentmanifestid = m2.manifestid "
		query = query & " inner join manifestitem on m2.manifestid = manifestitem.manifestid where m1.manifestid = " & manifestid & " ) leftside "
		query = query & " full outer join ( select * from manifestitem where manifestitem.manifestid = " & manifestid & " ) rightside "
		query = query & " on leftside.invoicenumber = rightside.invoicenumber "
		query = query & " order by case dbo.isint(isnull(rightside.location, leftside.location)) when 1 then cast(isnull(rightside.location, leftside.location) as int) else 10000000 end "
	end if

	set manifestrs = getdisconnectedrecordset(query)

	function deleteFilter(manifestfilterid)
		dim query, rs
		
		query = " delete from manifestfilter where manifestfilterid = " & manifestfilterid
		
		qryexecute query
	end function
	
	function addFilter(name)
		dim query, rs
		
		query = " insert into manifestfilter(name, manifesttype, enabled, matchfilter, statusfilter) "
		query = query & " values ( "
		query = query & "'" & dbstr(name) & "'"
		query = query & ", '" & dbstr(mtype) & "'"
		query = query & ", " & request.querystring("enabled")
		query = query & ", '" & dbstr(request.form("match_filter")) & "'"
		query = query & ", '" & dbstr(request.form("status_filter")) & "'"
		query = query & ")"
		
		qryexecute query
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function isManifestOpen(manifestID)
		dim query, rs

		isManifestOpen = false
		
		if manifestid <> "" then
			query = " select 1 from manifest where [active] = 1 and manifestid = " & manifestid
			set rs = getdisconnectedrecordset(query)

			isManifestOpen = rs.recordcount > 0
		
			set rs = nothing
		end if
	end function
	
	function getManifestType(manifestid)
		dim query, rs
		
		getManifestType = "UNKNOWN"
		
		if manifestid <> "" then
			query = " select [type] from manifest where manifestid = " & manifestid
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getManifestType = rs("type")
			end if
		
			set rs = nothing
		end if
		
	end function
	
	
	function getManifestDateCreated(manifestid)
		dim query, rs
		
		getManifestDateCreated = Date()
		
		if manifestid <> "" then
			query = " select datecreated from manifest where manifestid = " & manifestid
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getManifestDateCreated = rs("datecreated")
			end if
		
			set rs = nothing
		end if
		
	end function
	
	function getRackPrefix(storeid)
		dim query, rs
		
		query = " select rackprefix from miscsetup where storeid = " & storeid
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getRackPrefix = rs("rackPrefix")
		end if
	end function

	function getInvoiceCustomer(invoiceNumber)
		dim query, rs
		dim terminalid
		on error resume next

		query = " select customer.customername from customer "
		query = query & " inner join ticket on customer.customersequencenumber = ticket.customersequencenumber "
		query = query & " where ticket.invoicenumber = '" & DBStr(invoiceNumber) & "'"

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getInvoiceCustomer = rs("customername")
		end if

		set rs = nothing
	end function

	function getInvoiceLocationStatus(invoiceNumber, location)
		dim query, rs
		dim terminalid
		on error resume next

		terminalid = session("terminalid")

		query = "exec CheckRackStatus " & terminalid
		query = query & ", '" & DBStr(invoiceNumber) & "'"
		query = query & ", '" & DBStr(location) & "'"
		query = query & ", ''"

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getInvoiceLocationStatus = rs("ErrorMessage")
		end if

		set rs = nothing
	end function

	function getDateOut(invoiceNumber)
		dim query, rs
		
		if invoiceNumber <> "" then
			query = " select dateout from ticket where dateout is not null and invoicenumber = '" & invoiceNumber & "'"
			set rs = getdisconnectedrecordset(query)
		
			if rs.recordcount > 0 then
				getDateOut = rs("dateout")
			end if
			
			set rs = nothing
		end if
		
	end function
	
	function getInvoiceStatus(invoiceNumber)
		dim query, rs
		
		query = " select ticketstatus, invoicetype, onhold, dateout from ticket where invoicenumber = '" & invoiceNumber & "'"
		set rs = getdisconnectedrecordset(query)
		
		getInvoiceStatus = "Unknown"
		
		if rs.recordcount > 0 then
			if rs("invoicetype") = "Q" then
				getInvoiceStatus = "Quick"
			elseif rs("onhold") then
				getInvoiceStatus = "Held"
			else
				select case lcase(rs("ticketstatus"))
				case "ac"
					getInvoiceStatus = "Open"
				case "vo"
					getInvoiceStatus = "Voided"
				case "fi"
					getInvoiceStatus = "Finished"
				end select
			end if
		
			set rs = nothing
		else
			getInvoiceStatus = "Not found"
		end if
	end function
	
	
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" src="../external/jquery-3.4.1.js"></script>


	
<script language="javascript" type="text/javascript">
	var manifestID = <%=manifestid%>;
	var previousInvoiceNumber = null;
	var selectedInvoice = null;
	var previousElement = null;


	var statusFields = {
		'notmatched' : 'Not matched',
		'matched' : 'Matched',
		'added' : 'Out of range'
	};


	function selectRow(element) {
		var childEl;

		if(element.side == "left")
			return;

		if (previousElement != null){
			previousElement.className="";
		}

		selectedInvoice = element.getAttribute("invoicenumber");

		previousElement = element;
		element.className = "selected";
	}


	function getStatusField(val) {
		return statusFields[val];
	}


	function exit() {
		document.manifestList.action = "/mainapp/manifestList.asp";
		document.manifestList.submit();
	}


	function addInvoiceDB(manifestid, invoiceNumber) {
		jQuery.getJSON("/mainapp/manifestActions.asp?a=addinvoice&invoicenumber=" + encodeURIComponent(invoiceNumber) + "&manifestid=" + encodeURIComponent(manifestid),
			function(data) {
				if(data.success != "0") {
					addInvoiceLocation(manifestid, invoiceNumber, '', data.message, data.customer);
				}
				else {
					cbs_alert("Could not add invoice.");
				}
			}
		);
	}

	function addInvoiceLocationDB(manifestid, invoiceNumber, location) {
		jQuery.getJSON("/mainapp/manifestActions.asp?a=addinvoicelocation&invoicenumber=" + encodeURIComponent(invoiceNumber) + "&location=" + encodeURIComponent(location) + "&manifestid=" + encodeURIComponent(manifestid),
			function(data) {
				if(data.success != "0") {
					addInvoiceLocation(manifestid, invoiceNumber, location, data.message, data.customer);
				}
				else {
					cbs_alert("Could not add invoice.");
				}
			}
		);
	}

	function updateInvoiceLocationDB(manifestid, invoiceNumber, location) {
		jQuery.getJSON("/mainapp/manifestActions.asp?a=addlocation&invoicenumber=" + encodeURIComponent(invoiceNumber) + "&location=" + encodeURIComponent(location) + "&manifestid=" + encodeURIComponent(manifestid),
			function(data) {
				if(data.success != "0") {
					updateInvoiceLocation(manifestid, invoiceNumber, location, data.message, data.customer);
				}
				else {
					cbs_alert("Could not update invoice location.");
				}
			}
		);
	}


	function remove_Click() {
		removeInvoiceDB(manifestID, selectedInvoice);
	}

	function removeInvoiceDB(manifestid, invoiceNumber) {
		jQuery.getJSON("/mainapp/manifestActions.asp?a=removeinvoice&invoicenumber=" + encodeURIComponent(invoiceNumber) + "&manifestid=" + encodeURIComponent(manifestid),
			function(data) {
				if(data.success != "0") {
					removeInvoice(manifestid, invoiceNumber);
				}
				else {
					cbs_alert("Could not remove invoice.");
				}
			}
		);
	}



	function invoiceNumber_KeyDown(element){
		if (event.keyCode == 13) {
			var tval = translateRackNumber(element.value);

			if(tval == -1 || (tval == element.value)) {
				previousInvoiceNumber = element.value;
				addInvoiceDB(manifestID, element.value);
			}
			else {
				if(previousInvoiceNumber == null) {
					cbs_alert('Scan locations after invoice numbers.');
				}
				else {
					updateInvoiceLocationDB(manifestID, previousInvoiceNumber, tval);
				}
			}
				
			element.value = "";
		}
	}


	function location_KeyDown(element){
		if (event.keyCode == 13) {
			addInvoiceLocationDB(manifestID, $("#invoiceNumber").val(), element.value);
			element.value = "";
		}
	}


	function removeInvoice(manifestID, invoiceNumber) {
		removeInvoiceLocationToDocument(manifestID, invoiceNumber);
	}

	function addInvoiceLocationToDocument(manifestid, invoiceNumber, location, message, customer) {
		$("#thead").after(
			'<TR class="item" invoicenumber="' + invoiceNumber + '" side="right" onclick="selectRow(this)">' +
			'<TD class="status">&nbsp;</TD>' +
			'<TD class="invoice">' + invoiceNumber + '</TD>' +
			'<TD class="location">' + location + '</TD>' +
			'<TD class="message">' + message + '</TD>' +
			'<TD class="message">&nbsp;</TD>' +
			'<TD class="customer">' + customer + '</TD>' +
			'</TR>'
		);
	}

	function updateInvoiceLocation(manifestid, invoiceNumber, location) {
		var matchedElement;

		matchedElement = $("tr[invoicenumber='" + invoiceNumber + "']");

		if(matchedElement.length > 0) {
			$('.location', matchedElement).html('<span style="background:yellow">' + location + '</span>');
		}
	}


	function removeInvoiceLocationToDocument(manifestid, invoiceNumber) {
		var matchedElement;

		matchedElement = $("tr[invoicenumber='" + invoiceNumber + "']");

		if(matchedElement.length > 0) {
			previousElement.className = "";
			selectedInvoice = null;
			previousElement = null;

			if(matchedElement.attr('side') == 'both') {

				if($('#show_notreconciled:checked').length)
					matchedElement.show();
				else
					matchedElement.hide();
	

				matchedElement.attr("side", "left");

				$('.status', matchedElement).html(getStatusField('notmatched'));

				$('.location', matchedElement).html($('.location', matchedElement).attr('leftlocation'));

				var matched = parseInt($('#count_matched').html()) - 1;
				matched = matched == "" ? "0" : matched;
				$('#count_matched').html(matched);

				var notmatched = parseInt($('#count_notmatched').html()) + 1;
				$('#count_notmatched').html(notmatched);
			}
			else if(matchedElement.attr('side') == 'right') {
				matchedElement.remove();

				var added = parseInt($('#count_added').html()) - 1;
				added = added == "" ? "0" : added;
				$('#count_added').html(added);
			}
		}
	}



	function addInvoiceLocation(manifestID, invoiceNumber, location, message, customer) {
		addInvoiceLocationToDocument(manifestID, invoiceNumber, location, message, customer);

		var added = parseInt($('#count_added').html()) + 1;
		$('#count_added').html(added);
	}


	function rack_Click() {
		document.manifestList.action = "?useraction=rackinvoices";
		document.manifestList.submit();
	}

	function translateRackNumber(rackNumber) {
		var rackPrefix = "<%=rackPrefix%>";
		var index;
		var iRackPrefix;
		var iRackNumber;
		
		index = rackNumber.indexOf("-");
		
		if(index > 0) {
			iRackPrefix = rackNumber.substring(0, index);
			iRackNumber = rackNumber.substring(index + 1);
			
			if(iRackPrefix.toUpperCase() == rackPrefix.toUpperCase())
				return iRackNumber;
			else
				return -1;
		}
		else if(rackPrefix != "")
			return -1;

		return rackNumber;
	}

	$(document).ready(function () {
	    $('#invoiceNumber').focus();
	});


	function showNotReconciled(v) {
		if(v)
			$("tr[side='left']").show();
		else
			$("tr[side='left']").hide();
	}

	function showReconciled(v) {
		if(v)
			$("tr[side='both']").show();
		else
			$("tr[side='both']").hide();
	}

	function showOOR(v) {
		if(v)
			$("tr[side='right']").show();
		else
			$("tr[side='right']").hide();
	}

	function printResults() {
		var print_window = window.open('','','width=300,height=300');
		print_window.document.open("text/html");
		print_window.document.write('<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">');
		print_window.document.write('<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">');
		print_window.document.write('<table class="itable" cellspacing="0">');
		print_window.document.write('<tr>');
		print_window.document.write('<th>&nbsp;</th>');
		print_window.document.write('<th>Invoice</th>');
		print_window.document.write('<th>Location</th>');
		print_window.document.write('<th>Invoice Status</th>');
		print_window.document.write('<th>Customer</th>');
		print_window.document.write('</tr>');
		print_window.document.write('</tr>');
		$('.item:visible').each(function() {
			print_window.document.write('<tr>');
			print_window.document.write(this.innerHTML);
			print_window.document.write('</tr>');
		});
		print_window.document.write('</table>');
		print_window.document.close();
		print_window.print();
		print_window.close();
	}
	
	function resetStatusFilter() {
		$('#status_filter').val([]);
	}
	
	function resetMatchFilter() {
		$('#match_filter').val([]);
	}

	function applyFilters() {
		document.manifestList.action = "?useraction=applyfilters";
		document.manifestList.submit();
	}
	
	function saveFilter() {
		cbs_prompt("Name for new filter:", handleFilterNamed);
	}

    var savFilterName
    function handleFilterNamed() {
        clearPromptMsg();
        var filterName = document.getElementById('inputTxtLine').value;
		if(filterName) {
		    savFilterName = filterName
            cbs_confirm("Enable this filter by default?", finishDefaultTrue, finishDefaultFalse)
		}
    }

    function finishDefaultTrue() {
        clearConfirmMsg();
        finishHandledFilterNamed(true);
    }
    function finishDefaultFalse() {
        clearConfirmMsg();
        finishHandledFilterNamed(false);
    }

    function finishHandledFilterNamed(enabled) {
        var filterName = document.getElementById('inputTxtLine').value;
	    document.manifestList.action = "?useraction=addfilter&name=" + encodeURIComponent(savFilterName) + "&enabled=" + enabled;
		document.manifestList.submit();
    }

	var savManifestFilterID
	function deleteFilter(manifestFilterID) {
	    savManifestFilterID = manifestFilterID;
	    cbs_confirm("Are you sure you want to delete the filter?", gotoDeleteFilter);
	}

	function gotoDeleteFilter() {
        document.manifestList.action = "?useraction=deletefilter&manifestfilterid=" + savManifestFilterID;
        document.manifestList.submit();
	}

	function showFilters() {
		$('#filters').slideDown("fast");
	}

	$(document).ready(function() {
		$("#invoiceNumber").focus();
	});
	
</script>


<style type="text/css">

	UL.legend {
		list-style: none;
		width: 220px;

	}


	UL.legend H1 {
		display: inline;
		width: 130px;
		font-size: 12;
	}

	UL.legend P {
		display: inline;
		width: 50px;
	}
	
	a.reset_filter {
		font-size: 10;
		color: #66f;
	}
	.scanned_item {
		background: #666;
		padding: 0 2 0 2;
		font-weight: bold;
		color: #fff;
	}
</style>

</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->
<FORM name="manifestList" ID="manifestList" METHOD=POST  style="margin:0;padding:0" onSubmit="return false">

<INPUT type="hidden" name="manifestID" value="<%=manifestID%>" />

<INPUT type="hidden" name="showClosed" value="<%=search_showClosed%>" />
<INPUT type="hidden" name="daysOfHistory" value="<%=search_daysOfHistory%>" />
<INPUT type="hidden" name="orderBy" value="<%=search_orderBy%>" />
<INPUT type="hidden" name="searchString" value="<%=search_searchString%>" />


<H1>Manifest</H1>
<BR><BR>






<DIV style="border: 1px solid #ddd; float: right; width:310px; margin: 2px;padding:10px; text-align:center;">

<TABLE style="width:100%">

<%
	dim filtersExist
	
	query = " select * from manifestfilter where manifesttype = '" & dbstr(mtype) & "'"
	set rs = getdisconnectedrecordset(query)
	
	filtersExist = rs.recordcount > 0
	
	while not(rs.eof or rs.bof)
%>
	<TR>
		<TD style="width:20px;"><INPUT name="enabled_manfiestfilterid" value="<%=rs("manifestfilterid")%>" type="checkbox" <%if rs("enabled") then%>checked<%end if%>></TD>
		<TD><%=server.htmlencode(rs("name"))%></TD>
		<TD>(<A href="javascript:deleteFilter(<%=rs("manifestfilterid")%>)">Delete</A>)</TD>
	</TR>
<%
		rs.movenext
	wend
	
	set rs = nothing
%>
</TABLE>



<% if filtersExist then %>
<BUTTON onclick="applyFilters()">Apply Filters</BUTTON>
<% end if %>
<BUTTON onclick="showFilters()">Add Filter</BUTTON>

</BR>
<DIV id="filters" style="float: right; width:300px; padding:10px; text-align:center; display: none">
	<TABLE cellspacing="2" cellpadding="0">
		<TR>
			<TD><A class="reset_filter" href="javascript:resetMatchFilter();">Reset</A></TD>
			<TD><A class="reset_filter" href="javascript:resetStatusFilter();">Reset</A></TD>
		</TR>
		<TR>
			<TD>
			<SELECT name="match_filter" id="match_filter" multiple style="font-size:10;height:100px">
				<OPTION>Matched</OPTION>
				<OPTION>Not matched</OPTION>
				<OPTION>Out of range</OPTION>
			</SELECT>
			</TD>
			<TD>
			<SELECT name="status_filter" id="status_filter" multiple style="font-size:10;height:100px">
				<OPTION>Open</OPTION>
				<OPTION>Finished</OPTION>
				<OPTION>Quick</OPTION>
				<OPTION>Held</OPTION>
				<OPTION>Voided</OPTION>
				<OPTION>Not Found</OPTION>
			</SELECT>
			</TD>
		</TR>
	</TABLE>
	<DIV style="text-align:center">
		<BUTTON onclick="saveFilter()">Save</BUTTON>
	</DIV>
</DIV>

</DIV>



<% if isManifestOpen(manifestID) then %>
<TABLE>

	<TR>
		<TD>
			Invoice Number:<BR />
			<INPUT style="font-size:1.6em" maxlength="20" id="invoiceNumber" onkeydown="invoiceNumber_KeyDown(this)" />
		</TD>
		<TD>
			Location:<BR />
			<INPUT style="font-size:1.6em" maxlength="50" id="location" onkeydown="location_KeyDown(this)" />
		</TD>
	</TR>
</TABLE>
<% end if %>




<%
	class ManifestViewEntry
		dim invoiceNumber
		dim invoiceStatus
		dim customerName
		dim side
		dim location
		dim leftLocation
		dim visible
		dim match
		dim passedFilters
		dim invoiceKeyed
		dim locationKeyed
	end class
	
	dim i
	dim rows()
	dim savedFiltersRS
	
	redim rows(manifestrs.recordcount - 1)
	
	set savedFiltersRS = nothing
	
	if request.form("enabled_manfiestfilterid") <> "" and request.querystring("useraction") = "applyfilters" then
		query = " select * from manifestfilter where enabled = 1 and manifesttype = '" & dbstr(mtype) & "'"
		query = query & " and manifestfilterid in (" & request.form("enabled_manfiestfilterid") & ")"
		set savedFiltersRS = getdisconnectedrecordset(query)
	end if
	
	i = 0
	while not(manifestrs.eof or manifestrs.bof)
		set rows(i) = new ManifestViewEntry
		

		rows(i).invoiceNumber = manifestrs("invoicenumber")
		rows(i).invoiceStatus = manifestrs("invoicestatus")
		rows(i).customerName = getInvoiceCustomer(manifestrs("invoicenumber"))
		rows(i).side = manifestrs("side")
		rows(i).location = manifestrs("location")
		rows(i).leftLocation = manifestrs("leftlocation")
		rows(i).invoiceKeyed = manifestrs("invoicenumberkeyed")
		rows(i).locationKeyed = manifestrs("locationkeyed")
		
		select case lcase(manifestrs("side"))
		case "left"
			rows(i).match = "Not matched"
		case "both"
			rows(i).match = "Matched"
		case else
			rows(i).match = "Out of range"
		end select


		rows(i).visible = true
		
		if not (savedFiltersRS is nothing) then
			if savedFiltersRS.recordcount > 0 then
				rows(i).visible = false
				
				savedFiltersRS.movefirst
				
				while not(savedFiltersRS.eof)
	
					if isOptionEnabled(split(savedFiltersRS("matchfilter"), ", "), rows(i).match) and isOptionEnabled(split(savedFiltersRS("statusfilter"), ", "), rows(i).invoiceStatus) then
						rows(i).visible = true
						if rows(i).passedFilters <> "" then rows(i).passedFilters = rows(i).passedFilters & ", "
						rows(i).passedFilters = rows(i).passedFilters & savedFiltersRS("name")
					end if
					
					savedFiltersRS.movenext
				wend
			end if
		end if
		
			
		i = i + 1
		manifestrs.movenext
	wend
	
	set manifestrs = nothing
%>	


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="clear: both;margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="remove_Click()">Remove</BUTTON>
		<BUTTON style="vertical-align: top" onclick="rack_Click()">Rack<BR>Invoices</BUTTON>
		<BUTTON onclick="printResults()">Print</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" cellspacing="0" id="items">
<TR id="thead">
	<TH>&nbsp;</TH>
	<TH>Invoice</TH>
	<TH>Location</TH>
	<TH>Invoice Status</TH>
	<TH>Date Out</TH>
	<TH>Customer</TH>
</TR>
<%


	for i = lbound(rows) to ubound(rows)
		if rows(i).visible then
%>
	<TR class="item" invoicenumber="<%=rows(i).invoiceNumber%>" onclick="selectRow(this)" side="<%=rows(i).side%>">
		<TD class="status"><%=Server.HTMLEncode(rows(i).passedFilters)%></TD>
		<TD class="invoice"><%if not rows(i).invoiceKeyed then%><SPAN class="scanned_item"><%end if%><%=Server.HTMLEncode(rows(i).invoiceNumber)%><%if not rows(i).invoiceKeyed then%></SPAN><%end if%></TD>
		<TD class="location" leftlocation="<%=rows(i).leftLocation%>"><%if not rows(i).locationKeyed then%><SPAN class="scanned_item"><%end if%><%=Server.HTMLEncode(rows(i).location)%>&nbsp;<%if not rows(i).locationKeyed then%></SPAN><%end if%></TD>
		<TD class="message"><%=Server.HTMLEncode(rows(i).invoiceStatus)%></TD>
		<TD class="dateout"><%=Server.HTMLEncode(getDateOut(rows(i).invoiceNumber))%>&nbsp;</TD>
		<TD class="customer"><%=Server.HTMLEncode(rows(i).customerName)%></TD>
	</TR>
<%
		end if

	next

	
%>

</TABLE>

</FORM>
</BODY>
</HTML>
