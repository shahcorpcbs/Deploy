<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/customerPaymentObj.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim ticketNumber
	dim custSeqNumber
	dim invoiceNumber
	dim ticket_rs
	dim query, rs, showPrintButtons
	
	ticketNumber = getReqVar("TicketNumber")
	custSeqNumber = Session("customerSequenceNumber")
	showPrintButtons = getMSVar("printOnHomeScreen")

	select case lcase(request.querystring("useraction"))
	case "prevticket"
		ticketNumber = getPrevTicket(custSeqNumber, ticketNumber)
	case "nextticket"
		ticketNumber = getNextTicket(custSeqNumber, ticketNumber)
	end select


	query = " select * from ticket where ticketnumber = " & ticketnumber
	set ticket_rs = getdisconnectedrecordset(query)
	
	function getNextTicket(custSeqNumber, ticketNumber)
		dim query, rs
		dim ticketStatus
		
		ticketStatus = getInvoiceStatus(ticketNumber)
		
		query = " select min(ticketnumber) as nextTicketNumber from ticket where "
		query = query & " ticketnumber > " & ticketNumber
		query = query & " and customersequencenumber = " & custSeqNumber
		query = query & " and ticketstatus = '" & ticketStatus & "' "

		set rs = getdisconnectedrecordset(query)
		
		if not isnull(rs("nextTicketNumber")) then
			getNextTicket = rs("nextTicketNumber")
		else
			getNextTicket = ticketnumber
		end if
		
		set rs = nothing
	end function
	
	function getInvoiceStatus(ticketNumber)
		dim query, rs
		dim result
		
		if ticketNumber <> "" then
			query = " select ticketstatus from ticket where ticketnumber = " & ticketNumber
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getInvoiceStatus = trim(rs("ticketstatus"))
			end if
			
			set rs = nothing
		end if
	end function
	

	function getPrevTicket(custSeqNumber, ticketNumber)
		dim query, rs
		dim ticketStatus
		
		ticketStatus = getInvoiceStatus(ticketNumber)
		
		query = " select max(ticketnumber) as prevTicketNumber from ticket where "
		query = query & " ticketnumber < " & ticketNumber
		query = query & " and customersequencenumber = " & custSeqNumber
		query = query & " and ticketstatus = '" & ticketStatus & "' "

		set rs = getdisconnectedrecordset(query)
		
		if not isnull(rs("prevTicketNumber")) then
			getPrevTicket = rs("prevTicketNumber")
		else
			getPrevTicket = ticketnumber
		end if
		
		set rs = nothing
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function
%>

<HTML>
<HEAD>
<TITLE>Finished Invoices</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript" src="/script/printing.js"></script>

<SCRIPT  language="javascript" type="text/javascript">

	function printInvoice() {
		PrintDetailedInvoice(<%=ticketnumber%>);	
	}
	
	function printTags() {
		PrintTagsForInvoice(<%=ticketnumber%>);	
	}

	function viewPrev() {
		document.invoiceDetails.action="?userAction=prevticket";
		document.invoiceDetails.submit();
	}
	
	function viewNext() {
		document.invoiceDetails.action="?userAction=nextticket";
		document.invoiceDetails.submit();
	}
	
	function exit() {
		document.invoiceDetails.action = "customerfunctions.asp";
		document.invoiceDetails.submit();
	}
</SCRIPT>

<STYLE type="text/css">
.inv-desc {
	width: 260px;
	border-bottom: 2px solid #ddd;
}

.inv-lines {
	width: 100%;
}

.inv-attr {
	font-size: 14;
	padding: 5px;
	margin: 2px;
	border-bottom: 1px solid #ccc;
}
.inv-attr b {
	font-size: 20;
}



.inv-lines td {
	font-size: 14;	
}
.inv-track td {
	font-size: 12;
	
}

#print-commands  {
	margin-top: 20px;
	text-align: center;
}

#print-commands button {
	width: 200px;
	height: 50px;
	margin: 5px;
}


</STYLE>


<script language="JavaScript" src="../script/date-picker.js"></script>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->

<FORM name="invoiceDetails" ID="invoiceDetails" METHOD=POST  style="margin:0;padding:0">
<INPUT type="hidden" name="TicketNumber" value="<%= TicketNumber %>">
</FORM>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="viewPrev()">Older<br>Invoice</BUTTON>
		<BUTTON onclick="viewNext()">Newer<br>Invoice</BUTTON>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	


<table width="100%">
<tr>
<td style="vertical-align: top" width="263px">
<div class="inv-desc">
<%
		dim lineItems
		dim subLineItems

		query = " select *, isnull(ticketlineitem.totalupchargeamount, 0) as upchargetotal from ticketlineitem where parentlinenumber < 0 and ticketnumber = " & ticketnumber
		set lineItems = getdisconnectedrecordset(query)
%>
<div class="inv-attr">Invoice: <b><%= ticket_rs("invoicenumber")%></b></div>
<div class="inv-attr">Created:<br><%= ticket_rs("createddate")%></div>
<div class="inv-attr">Due:<br><%= ticket_rs("duedate")%></div>
<div class="inv-attr">Picked up:<br><%= ticket_rs("dateout")%></div>
<table class="inv-lines">
<%
		while not(lineItems.eof or lineItems.bof)

					dim lineDescription
					dim lineQty
					dim lineTotal
					dim lineColor
					
					lineDescription = trim(lineItems("lineitemname"))
					
					query = " select * from ticketlineitem where parentlinenumber = " & lineItems("lineItemNumber") & " and ticketnumber = " & ticketnumber
					set subLineItems = getdisconnectedrecordset(query)
					
					
					if lineItems("ticketLineType") = "IT" or lineItems("ticketLineType") = "AC" then
						lineQty = lineItems("quantity")
						if lineQty < 1 then lineQty = ""
						lineColor = "#000"
					else
						lineQty = ""
						lineColor = "#88d"
					end if

					lineTotal = formatcurrency(lineItems("lineItemTotal") + lineItems("upchargetotal"))
					
					while not (subLineItems.eof or subLineItems.bof)
							lineDescription = lineDescription & ", " & subLineItems("lineitemname")
							subLineItems.MoveNext																
					wend
%>
			<tr>
				<td style="width: 20px;"><%= lineQty %></td>
				<td style="color:<%= lineColor %>"><%= lineDescription %></td>
				<td style="width: 60px;" align="right"><%= lineTotal %></td>
			</tr>
<%
			lineItems.MoveNext
		wend	
%>
		<tr>
			<td style="width: 20px;">&nbsp;</td>
			<td><b>Invoice Total</b></td>
			<td style="width: 60px;" align="right"><b><%= formatcurrency(ticket_rs("invoicetotal")) %></b></td>
		</tr>
</table>
</div>

<% if showPrintButtons then %>
<div id="print-commands">
	<button onclick="printInvoice()">Print Invoice</button>
	<button onclick="printTags()">Print Tags</button>
</div>
<% end if %>

</td><td style="vertical-align: top">
<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="inv-track">
	<TR style="background:#CCC;text-align:left" >
		<TH>Date</TH>
		<TH>Employee</TH>
		<TH>Description</TH>
		<TH>Total</TH>
		<TH>Paid</TH>
	</TR>
	<%
		query = " select distinct ticketevent.date, isnull(ticketevent.description, '') as description, isnull(employee.employeename, '') as employeename, isnull(invoicetotal, 0) as invoicetotal, isnull(amountpaid, 0) as amountpaid from ticketevent "
		query = query & " left outer join employee on ticketevent.employeeid = employee.employeeid "
		query = query & " where ticketevent.ticketnumber = " & ticketnumber
		query = query & " order by [date] "
		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
	%>
	<TR>
		<TD><%=Server.HTMLEncode(rs("date"))%></TD>
		<TD><%=Server.HTMLEncode(rs("employeename"))%></TD>
		<TD><%=Server.HTMLEncode(rs("description"))%></TD>
		<TD><%=formatcurrency(rs("invoicetotal"))%></TD>
		<TD><%=formatcurrency(rs("amountpaid"))%></TD>
	</TR>
	<%
			rs.movenext
		wend
		set rs = nothing
	%>
</TABLE>


<div>

<%
query = " select claimreceipt.*, isnull(note, '') as note from claimreceipt "
query = query & " inner join ticketlog on claimreceipt.claimreceiptid = ticketlog.claimreceiptid "
query = query & " where ticketlog.ticketnumber = " & ticketnumber

set rs = getdisconnectedrecordset(query)

if not (rs.eof or rs.bof) then
%>
	<TABLE ALIGN=left WIDTH="300px" CELLPADDING=1 style="background: #ffa; border: 2px solid #ddd; margin: 5 0 0 10; float: left">
	  <tr><th colspan="2" style="text-align: left">Claim Receipt:</th></tr>
		<tr><td style="width:150px">Name:</td><td><%= rs("name") %></td>&nbsp;</tr>
		<tr><td style="width:150px">Relationship:</td><td><%= rs("relationship") %>&nbsp;</td></tr>
		<tr><td style="width:150px">Identification Type:</td><td><%= rs("identificationType") %>&nbsp;</td></tr>
		<tr><td style="width:150px">Identification:</td><td><%= rs("identification") %>&nbsp;</td></tr>
		<tr><td style="width:150px">Phone Number:</td><td><%= rs("phonenumber") %>&nbsp;</td></tr>
		<tr><td valign="top" style="width:150px">Note:</td><td><%=replace(rs("note"), vbcrlf, "<br>") %>&nbsp;</td></tr>
	</table>
<%
end if
%>

</div>


</td>
</tr>
</table>

</BODY>
</HTML>
