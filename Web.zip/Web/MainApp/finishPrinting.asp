<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->
<!--#include file="../include/json.asp"-->

<%
    On error resume next
	dim ipPath, httpRequest, postResponse, params, userIPAddress

    userIPAddress = Request.ServerVariables("HTTP_X_FORWARDED_FOR")
    If userIPAddress = "" Then
        userIPAddress = Request.ServerVariables("REMOTE_ADDR")
    End If


	if request.querystring("ipPath") <> "" then
		ipPath = request.querystring("ipPath")
	end if

    Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
		params = "/resetCount"


    httpRequest.Open "POST", "http://" & userIPAddress & ipPath & params, False
    httpRequest.SetRequestHeader "Content-Type", "text/plain"
    httpRequest.Send
    postResponse = httpRequest.ResponseText

%>