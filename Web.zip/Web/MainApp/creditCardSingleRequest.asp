<%@ Language=VBScript %>

<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim swipeData
	dim ccprocessor
	dim ccfields
	dim transactRet
	dim transactCode
	dim customerseq
	dim transactionAmt
	dim transactionID
	dim successfulSwipe
	dim invoicecustomername
	dim debitblock
	dim debitkey
	dim verifyerror
	dim cardTypeID
	dim validateOnly
	dim ticketNumbers
	dim transactionType
	dim terminalID
	dim storeID
	dim employeeID
	
	dim onfile_accountnumber
	dim onfile_expirationmonth
	dim onfile_expirationyear
	dim onfile_cvv2
	dim onfile_customername
	dim onfile_customeraddress
	dim onfile_customerzip
	
	dim ms_promptToAddCC
	dim sigboxtype

	sigboxtype = getCurrentSigBoxType()

	storeID = getReqVar("storeID")
	terminalID = getReqVar("terminalID")
	employeeID = getReqVar("employeeID")
	
	if storeID = "" then storeID = session("storeID")
	if terminalID = "" then terminalID = session("terminalID")
	if employeeID = "" then employeeID = session("employeeID")
	
	validateOnly = (getReqVar("validate") = "true")
	
	ms_promptToAddCC = getMSVar("promptToAddCC")
	
	invoicecustomername = getReqVar("invoicecustomername")
	customerseq = getReqVar("customerseq")
	transactionAmt = getReqVar("transactionAmt")
	transactionID = getReqVar("transactionID")
	cardTypeID = getReqVar("cardTypeID")
	ticketNumbers = getReqVar("ticketNumbers")
	transactionType = getReqVar("transactionType")
	
	successfulSwipe = false
	
	select case lcase(Request.QueryString("useraction"))
	case "clear"
		clearCreditCardOnFile
	end select
	
	if Request.QueryString("customerseq") <> "" then
		readCustomerDataOnFile customerseq
	elseif request.querystring("useraction") <> "clear" then
		readCustomerDataFromForm
	end if
	
	set ccprocessor = Server.CreateObject("ShahcorpComponents.creditCardProcessing")
	ccprocessor.DBConnectionString = Session("shahcorpDSN")
	
	swipeData = cstr(Request.Form("swipedata"))
	
	ccprocessor.XChargeDirectory = getMSVar("XChargePath")
	if not isnull(getMSVar("XChargePathKeyed")) then
		ccprocessor.XChargeDirectoryKeyed = getMSVar("XChargePathKeyed")
	end if
	ccprocessor.XChargeTimeout = getMSVar("XChargeTimeout")

	if not fillCCFields(swipeData) then swipeData = ""
	
	if request.querystring("submit") = "true" then
		select case lcase(Request.QueryString("useraction"))
		case "validate"
			
			if isCreditCardNumberValid and isCreditCardExpirationValid then
				cardTypeID = getCardTypeID(ccfields.accountnumber)
				set session("ccfields") = ccfields
	
				if Request.Form("keepCardOnFile") = "Y" then
					saveCustomerDataOnFile customerseq
				end if
			end if
		
		case "transact"
			
			if isCreditCardNumberValid and isCreditCardExpirationValid then
				cardTypeID = getCardTypeID(ccfields.accountnumber)
				set session("ccfields") = ccfields

				if Request.Form("keepCardOnFile") = "Y" then
					saveCustomerDataOnFile customerseq
				end if

				Response.Redirect "/mainapp/creditCardWaiting.asp?checksignature=true&guid=" & ccfields.guid & _
				"&transactionAmt=" & transactionAmt & _
				"&transactionID=" & transactionID & _
				"&cardTypeID=" & cardTypeID & _
				"&customerSequenceNumber=" & customerseq & _
				"&ticketNumbers=" & ticketNumbers & _
				"&transactionType=" & transactionType & _
				"&storeID=" & storeID & _
				"&terminalID=" & terminalID & _
				"&employeeID=" & employeeID & _
				"&target=/mainapp/creditCardSingleRequest.asp"
			end if

		case "transactdebit"
			if isCreditCardNumberValid then
				if ccprocessor.DecipherDUKPT(Request.QueryString("dukpt"), block, key) then
					cardTypeID = getCardTypeID(ccfields.accountnumber)
					ccprocessor.RequestSingleTransactionDebit terminalID, ccfields, 1, transactionID, transactionAmt, "0", block, key
					set session("ccfields") = ccfields
					if Request.Form("keepCardOnFile") = "Y" then
						saveCustomerDataOnFile customerseq
					end if
					Response.Redirect "/mainapp/creditCardWaiting.asp?guid=" & ccfields.guid & _
					"&transactionAmt=" & transactionAmt & _
					"&transactionID=" & transactionID & _
					"&cardTypeID=" & cardTypeID & _
					"&storeID=" & storeID & _
					"&terminalID=" & terminalID & _
					"&employeeID=" & employeeID & _
					"&target=/mainapp/creditCardSingleRequest.asp"
				end if
			end if

		end select
	else

	end if
	function getCardTypeID(ccNumber)
		getCardTypeID = ccprocessor.getCreditCardTypeID(storeID, ccNumber)
	end function
	

	function getMSVar(id)
		dim query, rs
		
		query = "select " & id & " from miscsetup where storeid = " & storeID
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)
		
		set rs = nothing
	end function
	
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function addLeadingZeros(value, leadingZeros)
		value = CStr(value)
		
		while len(value) < leadingZeros
			value = "0" & value
		wend
		
		addLeadingZeros = value
	end function

	sub d_optionRange(minValue, maxValue, selValue, leadingZeros)
		dim index
		
		for index = minValue to maxValue
			Response.Write "<OPTION value=""" & index & """"
			if index = selValue then
				Response.Write " selected"
			end if
			Response.Write ">"
			Response.Write addLeadingZeros(index, leadingZeros)
			Response.Write "</OPTION>"
		next
	end sub

	sub clearCreditCardOnFile()
		dim query
		
		query = " update customer set "
		query = query & " creditCardCVC = null "
		query = query & ", creditCardExpDate = null "
		query = query & ", creditCardNumber = null "
		query = query & ", creditCardNameOnCard = null "
		query = query & " where customersequencenumber = " & customerseq

		qryexecute query
	
	end sub
	
	
	function getExpirationMonth(expDate)
		dim dpos

		if trim(expDate) <> "" then
			dpos = instr(expDate, "/")
	
			if dpos > 0 then
				getExpirationMonth = mid(expDate, 1, dpos - 1)
			else
				getExpirationMonth = left(expDate, 2)
			end if
		else
			getExpirationMonth = "00"
		end if
	end function
	
	function getExpirationYear(expDate)
		dim dpos
		
		if trim(expDate) <> "" then
			dpos = instr(expDate, "/")
	
			if dpos > 0 then
				getExpirationYear = mid(expDate, dpos + 1)
			else
				getExpirationYear = right(expDate, 2)
			end if
		else
			getExpirationYear = "00"
		end if
	end function
	
	sub readCustomerDataOnFile(customerseq)
		dim query, rs
		
		if customerseq <> "" then
			query = "select "
			query = query & "  isnull(creditCardExpDate, '0000') as creditCardExpDate"
			query = query & ", isnull(creditCardNumber, '') as creditCardNumber"
			query = query & ", isnull(creditCardNameOnCard, '') as creditCardNameOnCard"
			query = query & ", isnull(billingAddress1, '') as billingAddress1"
			query = query & ", isnull(billingZipCode, '') as billingZipCode"
			query = query & ", customerName as customerName"
			query = query & " from customer where customersequencenumber = " & customerseq

			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				onfile_accountnumber = rs("creditCardNumber")
				onfile_expirationmonth = getExpirationMonth(rs("creditCardExpDate"))
				onfile_expirationyear = getExpirationYear(rs("creditCardExpDate"))
				
				onfile_customername = rs("creditCardNameOnCard")
				onfile_customeraddress = rs("billingAddress1")
				onfile_customerzip = rs("billingZipCode")
				
				invoicecustomername = rs("customerName")
			end if
		end if
	end sub
	
	
	
	sub readCustomerDataFromForm()
			onfile_accountnumber = Request.Form("accountnumber")
			onfile_expirationmonth = Request.Form("expirationmonth")
			onfile_expirationyear = right(Request.Form("expirationyear"), 2)
			onfile_cvv2 = Request.Form("cvv2")
			
			onfile_customername = Request.Form("customername")
			onfile_customeraddress = Request.Form("customeraddress")
			onfile_customerzip = Request.Form("customerzip")
			
			if len(onfile_expirationmonth) < 2 then
				onfile_expirationmonth = "0" & onfile_expirationmonth
			end if
			if len(onfile_expirationyear) < 2 then
				onfile_expirationyear = "0" & onfile_expirationyear
			end if
	end sub
	
	
	
	
	sub saveCustomerDataOnFile(customerseq)
		dim query, rs
		
		if customerseq <> "" then
			query = "update customer set "
			query = query & " creditCardNumber = " & DbQryString(onfile_accountnumber)
			query = query & ", creditCardExpDate = " & DbQryString(onfile_expirationmonth & onfile_expirationyear)
			query = query & ", creditCardNameOnCard = " & DbQryString(onfile_customername)
			query = query & ", billingAddress1 = " & DbQryString(onfile_customeraddress)
			query = query & ", billingZipCode = " & DbQryString(onfile_customerzip)
			query = query & " where customersequencenumber = " & customerseq

			qryexecute query			
		end if
	end sub

	function fillCCFields(swipeData)
		set ccfields = ccprocessor.FieldsFromSwipe(swipeData)

		successfulSwipe = (ccfields.accountnumber <> "") and (ccfields.firstname <> "" or ccfields.lastname <> "") 
		
		if not successfulSwipe then
			ccfields.zip = onfile_customerzip
			ccfields.address = onfile_customeraddress
	
		
			if trim(ccfields.firstname & ccfields.lastname) = "" then
				ccfields.firstname = onfile_customername
				ccfields.lastname = ""
			end if
			
			if trim(ccfields.accountnumber) = ""  then
				ccfields.accountnumber = onfile_accountnumber
				ccfields.expirationmonth = onfile_expirationmonth
				ccfields.expirationyear = onfile_expirationyear
				ccfields.cvv2 = onfile_cvv2
			end if
		end if
		
		fillCCFields = successfulSwipe
	end function
	
	function getKeyboardsetting()
		dim sqltxt
		dim rsTemp

		getKeyboardsetting = false

		sqltxt = "select switchOnscreenKeyboardAlphabetic from Miscsetup where storeid =  " & storeID
		set rsTemp = getDisconnectedrecordset(sqltxt)

		if rsTemp.recordCount > 0 then
			if rsTemp("switchOnscreenKeyboardAlphabetic")= true then
				getKeyboardsetting = true
			end if
		end if
		
		rstemp.close
		set rstemp = nothing
	end function
	
	

	function trimtodigits(tstring)
	'removes all chars except of 0-9
	     s=""
	     ts=tstring
	     for x=1 to len(ts)
	          ch=mid(ts,x,1)
	          if asc(ch)>=48 and asc(ch)<=57 then
	          s=s & ch
	          end if
	     next
	  trimtodigits=s
	end function


    function isCCTypeValid(cctype)
        dim query, rs

        query = "select name from creditcardtypedomain where storeid = " & storeID
        set rs = getdisconnectedrecordset(query)
        
        while not(rs.eof or rs.bof)
            if lcase(cctype) = lcase(rs("name")) then
                set rs = nothing
                isCCTypeValid = true
                exit function
            end if
            
            rs.movenext
        wend
        
        set rs = nothing

        isCCTypeValid = false        
    end function
    	
    function isCreditCardNumberValid()
        dim cardName
        dim result

  		result = ccprocessor.VerifyCreditCard(ccfields.accountnumber, cardName, verifyerror)
  		
  		if result then
  		    if not isCCTypeValid(cardName) then
  		        verifyerror = cardName & " Is Not An Accepted Credit Card Type."
  		        result = false
  		    end if
  		end if
  		
  		isCreditCardNumberValid = result
	end function
	
	function isCreditCardExpirationValid()
		dim currentDate
		dim y, m
		
		if ccfields.expirationyear = "" or ccfields.expirationmonth = "" then
			isCreditCardNumberValid = false
			exit function
		end if
		
		y = ccfields.expirationyear + 2000
		m = ccfields.expirationmonth
		
		currentDate = Date()
		
		isCreditCardExpirationValid = y > Year(currentDate) or (y = Year(currentDate) and m >= month(currentDate))
	end function
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Process Credit Card</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript" src="/Script/validation.js"></script>

<!-- #include file="../include/signaturepad.inc" -->

<script language="javascript" type="text/javascript">
	var lastFocusControl;
	var magCardPollTimer = null;
	var previousSwipe = "";
	
	history.forward();

	function beginMagCardPoll() {
		magCardPollTimer = setTimeout("pollMagCard();", 600);
	}
	function resetMagCardPoll() {
		clearTimeout(magCardPollTimer);
		magCardPollTimer = setTimeout("pollMagCard();", 600);
	}
	
	function pollMagCard() {
		var response;
		
		if(SigPad_IsResponseReady())
		{
			response = SigPad_GetResponse(1000);
			
			if(response.length > 0)
			{
				document.creditCardSingleRequest.accountnumber.value = response;
				checkForSwipe2();
			}
			else
				resetMagCardPoll();
			//document.creditCardInfo.txtCCData.value
		}
		else
		{
			resetMagCardPoll();
		}
	}
	
	
	function submitSwipe() {
		document.creditCardSingleRequest.action = "?userAction=submitswipe"
		document.creditCardSingleRequest.submit();
	}
	
	function swapOriginalAccountNumber() {
		document.creditCardSingleRequest.style.display = 'none';
		var accountnumber = document.creditCardSingleRequest.accountnumber.value;
		var originalmasked = document.creditCardSingleRequest.originalMaskedAccountNumber.value
		if(accountnumber == originalmasked)
			document.creditCardSingleRequest.accountnumber.value = document.creditCardSingleRequest.originalAccountNumber.value;
	}

	function validateTransaction() {
		var accountnumber;
		var old;
		swapOriginalAccountNumber();
		accountnumber = document.creditCardSingleRequest.accountnumber.value;
		old = accountnumber;
		accountnumber = accountnumber.replace(new RegExp("[^0-9]"), "");
		while(old != accountnumber) {
			old = accountnumber;
			accountnumber = accountnumber.replace(new RegExp("[^0-9]"), "");
		}
		document.creditCardSingleRequest.accountnumber.value = accountnumber;

		<% if ms_promptToAddCC then %>
		if(document.creditCardSingleRequest.keepCardOnFile[1].checked) {
			if(confirm("Update credit card information?")) {
				document.creditCardSingleRequest.keepCardOnFile[0].checked = true;
			}
		
		}
		<% end if %>
		
		document.creditCardSingleRequest.action = "?userAction=validate&submit=true"
		document.creditCardSingleRequest.submit();
	}


	function finishPinPadTransaction(transactionType) {
        clearOptionMsg();
			if(transactionType == 1) {
				var block, pin;
				var result;

				block = '';
				pin = '';
				ppError = '';

				result = PINPad.PromptDebitPIN(document.creditCardSingleRequest.accountnumber.value,
												document.creditCardSingleRequest.transactionAmt.value,
												block, pin);

				if(!result) {
					cbs_alert("PINPad error: " + PINPad.LastError);
					document.creditCardSingleRequest.action = "?";
					document.creditCardSingleRequest.submit();
				}
				else {
		  			document.creditCardSingleRequest.action = "?userAction=transactdebit&submit=true&dukpt=" + result.key + result.block;
		  			document.creditCardSingleRequest.submit();
				}
			}
			else {
				document.creditCardSingleRequest.action = "?userAction=transact&submit=true"
				document.creditCardSingleRequest.submit();
			}
	}
	
	function processTransaction() {
		var dukpt;
		var accountnumber;
		var old;

		swapOriginalAccountNumber();
		accountnumber = document.creditCardSingleRequest.accountnumber.value;
		old = accountnumber;
		accountnumber = accountnumber.replace(new RegExp("[^0-9]"), "");
		while(old != accountnumber) {
			old = accountnumber;
			accountnumber = accountnumber.replace(new RegExp("[^0-9]"), "");
		}
		document.creditCardSingleRequest.accountnumber.value = accountnumber;

		//SigPad_DisplayText("\\n\\n\\n\\n\\nVerifying...");
		
		<% if ms_promptToAddCC then %>
		if(document.creditCardSingleRequest.keepCardOnFile[1].checked) {
			if(confirm("Update credit card information?")) {
				document.creditCardSingleRequest.keepCardOnFile[0].checked = true;
			}
		
		}
		<% end if %>

		<% if sigboxtype = "PINPAD" then %>
            cbs_select('Transaction Type', 2, 'CREDIT|DEBIT', 'finishPinPadTransaction');
		    return;
		<% else %>
		SigPad_PromptCreditOrDebit();
		
		if(SigPad_GetResponse(50000) == SigPad_Accept)
		{
  		if(!checkSignature()) {
  		  cbs_alert("Customer did not accept charges") ;
  		  return false;
  		}
			SigPad_DisplayText("\\n\\n\\n\\nProcessing Credit\\nTransaction...");
			document.creditCardSingleRequest.action = "?userAction=transact&submit=true"
			document.creditCardSingleRequest.submit();
		}
		else
		{
			dukpt = SigPad_GetDUKPTtextPIN(30000, document.creditCardSingleRequest.accountnumber.value)
			
			if(dukpt != "") {
  			SigPad_DisplayText("\\n\\n\\n\\nProcessing Debit\\nTransaction...");
  			document.creditCardSingleRequest.action = "?userAction=transactdebit&submit=true&dukpt=" + dukpt;
  			document.creditCardSingleRequest.submit();
			}
			else {
        cbs_alert("Invalid PIN");
			}
		}
		<%

			end if
		%>
		
		
	}
	function checkSignature() {
	<%if SigPad_HardwareExists <> "True" then%>
		return true;
	<%else%>
		
		var signature;

		SigPad_PromptForSignature("\\n\\n\\nSign Below\\nTotal:" + document.creditCardSingleRequest.transactionAmt.value);
		signature = SigPad_GetResponse(500000);

		while(signature == "" || signature == SigPad_Decline)
		{
			SigPad_PromptForSignature("\\n\\n\\nSign Below\\nTotal:" + document.creditCardSingleRequest.transactionAmt.value);
			signature = SigPad_GetResponse(500000);
		}

		SigPad_DisplayText("\\n\\n\\n\\n\\nThank You");

		window.opener.cct_signature(SigPad_Var2Bmp(signature), "Credit card payment");
	
		return true;
		<%end if%>
	}
	
	function isValidAcountNumber(accountnumber) {
		return isStrNumeric(accountnumber)
	}
	
	
	function isCreditCardSwipe(swipe) {
		//%BXXXXXXXXXXXXXXXX^GAGNON/STEVE E^DDDD1010000000      00170000000?;XXXXXXXXXXXXXXXX=DDDD1010000000170?
		return swipe.length > 20 && swipe.indexOf("%") >= 0 && swipe.indexOf(";") > 0
	}
	
	function checkForSwipe(element) {
		if(event.keyCode == 13)
		{
			checkForSwipe2();
		}
	}	
	
	function checkForSwipe2() {
		if (isCreditCardSwipe(document.creditCardSingleRequest.accountnumber.value))
		{
			document.creditCardSingleRequest.swipedata.value = document.creditCardSingleRequest.accountnumber.value;
			submitSwipe();
			previousSwipe = "";
		}
		else if(isCreditCardSwipe(previousSwipe + document.creditCardSingleRequest.accountnumber.value))
		{ 
			document.creditCardSingleRequest.swipedata.value = previousSwipe + document.creditCardSingleRequest.accountnumber.value;
			submitSwipe();
			previousSwipe = "";
		}
		else
		{
			previousSwipe = document.creditCardSingleRequest.accountnumber.value;
		}
		
		
		selectAccountNumber();
	}
	
	function selectAccountNumber() {
		document.creditCardSingleRequest.accountnumber.focus();
		document.creditCardSingleRequest.accountnumber.select();
	}
	function cancelForm() {
		window.close();
		window.opener.cct_complete(false, "Cancelled", 0, "0.00");
	}
	
	function resetSwipe() {
		document.creditCardSingleRequest.swipedate = "";
	}
	
	function closeIfNeeded() {
	<% if request.querystring("submit") = "true" and _
		lcase(getReqVar("validate")) = "true" and _
		isCreditCardNumberValid and _
		isCreditCardExpirationValid then
	%>
		window.close();
	<% end if %>
	}
	
	function Reconnect() {
		var img;

		
		img = new Image(1,1);
		img.src = 'reconnect.asp';
		
		setTimeout('Reconnect();', 60000);
	}
	
	function clearForm() {
		if(confirm("Clear form and credit card on file?")) {
			document.creditCardSingleRequest.action = "?userAction=clear&customerseq=" + document.creditCardSingleRequest.customerseq.value;
			document.creditCardSingleRequest.submit();
		}
	}
	
	setTimeout('Reconnect();', 60000);
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="closeIfNeeded();selectAccountNumber();beginMagCardPoll();">

<!-- #include file="../include/fakebanner.inc" -->

<%
	if sigboxtype = "PINPAD" then
%>
<OBJECT style="height:3px;width:6px;background:red" ID="PINPad"
	CLASSID="CLSID:5F93745A-5ADD-4232-B5C7-6B3D769BFC71">
</OBJECT>
<%
	end if
%>





<B class="pageHeading">Process Credit Card Transaction <%=transactionID%></B>
<FORM id="creditCardSingleRequest" name="creditCardSingleRequest" action="creditCardSingleRequest.asp" method="post">

<%
	function maskAccountNumber(AccountNumber)
		dim hideCnt
		dim sleft : sleft = 2
		dim sright : sright = 4
		dim i
		
		if len(AccountNumber) < 10 then
			sleft = 0
			sright = 2
		end if
		
		hideCnt = len(AccountNumber) - (sleft + sright)
		if hideCnt < 0 then hideCnt = 0
		
		maskAccountNumber = left(AccountNumber, sleft)
		
		for i = 1 to hideCnt - 2
			maskAccountNumber = maskAccountNumber & "*"
		next

		maskAccountNumber = maskAccountNumber & right(AccountNumber, sright)
	end function
	
	dim maskedAccountNumber
	maskedAccountNumber = maskAccountNumber(ccfields.accountnumber)
%>

<INPUT type="hidden" name="invoicecustomername" value="<%=Server.HTMLEncode(invoicecustomername)%>">
<INPUT type="hidden" name="swipedata" value="<%=swipeData%>">
<INPUT type="hidden" name="customerseq" value="<%=customerseq%>">

<INPUT type="hidden" name="transactionAmt" value="<%=transactionAmt%>">
<INPUT type="hidden" name="transactionID" value="<%=transactionID%>">
<INPUT type="hidden" name="cardTypeID" value="<%=cardTypeID%>">
<INPUT type="hidden" name="validate" value="<%=getReqVar("validate")%>">
<INPUT type="hidden" name="ticketNumbers" value="<%=ticketNumbers%>">
<INPUT type="hidden" name="transactionType" value="<%=transactionType%>">
<INPUT type="hidden" name="originalAccountNumber" value="<%=ccfields.accountnumber%>">
<INPUT type="hidden" name="originalMaskedAccountNumber" value="<%=maskedAccountNumber%>">

<INPUT type="hidden" name="storeID" value="<%=storeID%>">
<INPUT type="hidden" name="terminalID" value="<%=terminalID%>">
<INPUT type="hidden" name="employeeID" value="<%=employeeID%>">

<CENTER>

<TABLE>
<TR>
<TD>




<TABLE style="width:600px">


<TR>
	<TD>
	<TABLE style="" cellspacing=0 cellpadding=2>

	<TR>
		<TD>Amount</TD>
		<TD></TD>
		<TD align=right><H5><B><%=formatcurrency(transactionAmt, 2)%></B></H5></TD>
	</TR>

	
	<TR <%if Request.QueryString("customerseq") = "" and not isCreditCardNumberValid then%>style="background:red;color:white"<%end if%>>
		<TD style="width:150px">Credit Card Number:</TD>
		<TD><INPUT style="font-size:16" name="accountnumber" value="<%=maskedAccountNumber%>" onblur="lastFocusControl = this" onkeydown="resetSwipe();" onkeyup="checkForSwipe(this);"></INPUT></TD>
		<%if ccfields.accountnumber <> "" and Request.QueryString("customerseq") = "" and not isCreditCardNumberValid then%><TD width="200px"><%=verifyerror%></TD><%end if%>
	</TR>

	<TR <%if Request.QueryString("customerseq") = "" and not isCreditCardExpirationValid then%>style="background:red;color:white"<%end if%>>
		<TD>Expiration Date:</TD>
		<TD>
			<SELECT style="font-size:16" name="expirationmonth" onkeydown="resetSwipe();">
				<%d_optionRange 1, 12, ccfields.expirationmonth,  2%>
			</SELECT>
			
			
			<SELECT style="font-size:16" name="expirationyear" onkeydown="resetSwipe();">
				<%d_optionRange Year(Date()), Year(Date()) + 20, 2000 + ccfields.expirationyear, 4%>
			</SELECT>	
		</TD>
		
		<%if  ccfields.accountnumber <> "" and Request.QueryString("customerseq") = "" and not isCreditCardExpirationValid then%><TD width="200px">Date Expired</TD><%end if%>
	</TR>

	<TR>
		<TD>CVV2 Code:</TD>
		<TD><INPUT style="font-size:16" name="cvv2" style="width:35px" value="<%=ccfields.cvv2%>" onblur="lastFocusControl = this;"><BR>
		</TD>
	</TR>

	<TR>
		<TD></TD>
		<TD colspan=2>The CVV2 codes normally appear on the back of the card in the signature area.</TD>
	</TR>

	<TR>
		<TD>Name On Card:<br>(<%=Server.HTMLEncode(invoicecustomername)%>)</TD>
		<TD><INPUT style="font-size:16" name="customername" value="<%=Server.HTMLEncode(trim(trim(ccfields.firstname) & " " & trim(ccfields.lastname)))%>" onblur="lastFocusControl = this;"></TD>
	</TR>


	<TR>
		<TD>Billing Address:</TD>
		<TD><INPUT style="font-size:16" name="customeraddress" value="<%=ccfields.address%>" onblur="lastFocusControl = this;"></TD>
	</TR>

	<TR>
		<TD>Billing Zip Code:</TD>
		<TD><INPUT style="font-size:16" name="customerzip" style="width:55px" value="<%=ccfields.zip%>" onblur="lastFocusControl = this;"></TD>
	</TR>

	<TR>
		<TD>Update card on file?</TD>
		<TD>
			<INPUT style="font-size:16" type="radio" name="keepCardOnFile" value="Y" <%if validateOnly then%>checked<%end if%>>Yes
			<INPUT style="font-size:16" type="radio" name="keepCardOnFile" value="N" <%if not validateOnly then%>checked<%end if%>>No
		</TD>
	<TR>

	<TR style="height:70px">
		<TD></TD>
		<TD colspan="2" valign="bottom">
			<INPUT <%if successfulSwipe then%>style="background:limegreen"<%end if%>  style="width:100px;height:50px;" type=button name="processButton" <%if validateOnly then%> value="Save" onClick="validateTransaction();" <%else%> value="Process"  onClick="processTransaction()"<%end if%> >
			<INPUT style="width:100px;height:50px;" type=button name="clearButton" value="Clear" onclick="clearForm()" >
			<INPUT style="width:100px;height:50px;" type=button value="Cancel" onClick="cancelForm()">
		</TD>
	</TR>
	</TABLE>
	</TD>
</TR>

</TABLE>

</TD>

</TABLE>

<% if getKeyboardsetting() then %>
	<!-- #include file="../include/keyboard_alphabeticalOrder.inc" -->
<% else %>
	<!-- #include file="../include/keyboard.inc" -->
<% end if %>

</CENTER>

</FORM>
</BODY>
</HTML>
