<%@ Language=VBScript %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->

<!--#include file="../include/LicenseCheck.asp" -->
<!--#include file="../include/clientscheck.inc" -->

<!-- #include file="../include/sha1.asp" -->

<!-- #include file="../include/SystemStartup.asp" -->
<!-- #include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%
	dim validLogin
	dim imageCaptureURL
	dim defaultEmployeeForTarget
	dim mytarget
	dim mustClockinPassed
	
	Session("employeeID") = 0		
	Session("employeeName") = ""
		
	mustClockinPassed = true
	
	mytarget = ""
	
	if Request.ServerVariables("QUERY_STRING") <> "" then
			mytarget = mytarget & "?" & Request.ServerVariables("QUERY_STRING")
	end if

	validLogin = true

	imageCaptureURL = Request.Form("imageCaptureURL")
	if imageCaptureURL = "" then

		dim cameraList
														
		ssql = "SELECT brand from StoreHardware where hardwareType = 'IC' and terminalID = '" & Session("terminalID") & "' ORDER BY model DESC"
		set cameraList = getDisconnectedRecordset(ssql)
		
		if not cameraList.EOF then										
			imageCaptureURL = Trim(cameraList("brand"))
		end if
													
		cameraList.Close
		set cameraList = nothing
						
	end if
	
	defaultEmployeeForTarget = sec_GetDefaultAccess(Request.QueryString("target"), "")
	
	
	if Session("employeeID") <> 0 and Session("employeeName") <> "" then
		getLoginLogoutStatus
		Response.Redirect Request.QueryString("target") & mytarget
	end if
	
	if defaultEmployeeForTarget > 0 then
        setEmployeeInfo
	end if


	if Request.Form("password") <> "" then
		dim userID
		dim password
    dim todaysPassword

		userID = Request.Form("accessCode")
		password = Request.Form("password")

		dim loginRs
		dim loginEmployeeID

    todaysPassword = getPasswordForDate(Date())

    if todaysPassword <> "" and password = todaysPassword then
				Session("employeeID") = 1
				Session("employeeName") = "Shahcorp"
				Session("employeeMessageAccount") = ""
    		getLoginLogoutStatus

    		Response.Redirect Request.QueryString("target")& mytarget
    end if

		set loginRs = getDisconnectedRecordset("SELECT employeeID, employeeName, isnull(messageAccount, '') as messageAccount, MustBeClockedIn FROM Employee WHERE employeePassword = " & DbQryString(password) & " AND employeeStatus = 'A'")
		if loginRs is nothing or loginRs.EOF then
			validLogin = false
		else
			loginRs.MoveFirst
			if not loginRs.EOF then
				loginEmployeeID = loginRs("employeeID")
				Session("employeeID") = loginEmployeeID
				Session("employeeName") = loginRs.Fields("employeeName")
				Session("employeeMessageAccount") = loginRs.Fields("messageAccount")

				getLoginLogoutStatus

				if loginRs.fields("MustBeClockedIn") and not Request.QueryString("target") = "/mainapp/employeemenu.asp" then
					mustClockinPassed = trim(Session("loginDate")) <> ""
				end if

				if mustClockinPassed then
					Response.Redirect Request.QueryString("target")& mytarget
				else
					validLogin = false
				end if
			end if
		end if
	end if

	function getPasswordForDate(passwordDate)
    passwordDate = FormatDateTime(passwordDate, 2)
    getPasswordForDate = right(sha1(passwordDate), 6)
	end function

	sub getLoginLogoutStatus
		dim query, rs
		query = "select	clockin from employeetime where"
		query = query & " employeeid = " & Session("employeeid")
		query = query & " and clockout is null"
		query = query & " and clockin >= isnull((select max(clockout) from employeetime where employeeid = " & Session("employeeid") & "), clockin)"

		set rs = getdisconnectedrecordset(query)

		if not (rs.eof or rs.bof) then
			Session("loginDate") = rs("clockin")
		else
			Session("loginDate") = ""
		end if

		set rs = nothing
	end sub

	sub setEmployeeInfo
	    dim query, rs
		query = "select *, isnull(messageAccount, '') as messageAccount from employee where employeeid = " & defaultEmployeeForTarget
		set rs = getdisconnectedrecordset(query)

		Session("employeeID") = defaultEmployeeForTarget
		Session("employeeName") = rs("employeeName")
		Session("employeeMessageAccount") = rs("messageAccount")
		getLoginLogoutStatus

		Response.Redirect Request.QueryString("target") & mytarget

		set rs = nothing
	end sub


%>

<HTML>
<HEAD>
<TITLE>Employee Login</TITLE>
<link href="/script/stylesheet.css" rel="stylesheet" type="text/css">
<script src="/script/validation.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script type="text/javascript">

	//For On Screen Keyboard
	var lastFocusControl;

	function ValidateFields() {
		try {
			var txt;
			/*
			txt = document.getElementById("accessCode");
			if(trim(txt.value) == "") {
				alert("Enter Access Code");
				document.getElementById("accessCode").select();
				document.getElementById("accessCode").focus();
				return false;
			}
			*/
			txt = document.getElementById("password");
			if(trim(txt.value) == "") {
				cbs_alert("Password can not be blank");
				txt.value = "";
				txt.focus();
				return false;
			}
		}
		catch(ex) {
			cbs_alert(ex.description);
			return false;
		}
		return true;
	}
	function onPasswordBlur() {
	}

	function Init() {
		lastFocusControl = document.LoginForm.password;
		
		try {
			document.getElementById("password").focus();
		}
		catch(ex) {
			cbs_alert(ex.description);
		}
	}
	
	function onLogin() {
		try {
		
			var ret = ValidateFields();
			
			if(ret)
			{
/*
				if(LoginForm.imageCaptureURL.value != "")
				{
					var wwwTools = new ActiveXObject("CBSLoTools.WWW");
					var regTools = new ActiveXObject("CBSLoTools.Registry");
					var now = new Date();
					
					wwwTools.CopyURLToFile(LoginForm.imageCaptureURL.value, regTools.GetClientRootDir() + "\\ImageCapture\\" + now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "-" + now.getHours() + "-" + now.getMinutes() + "-" + now.getSeconds() + ".jpg");
				}
*/
			}
			
			return ret;
		}
		catch(ex) {
			cbs_alert(ex.description);
		}
	}
	
</SCRIPT>
</HEAD>

<BODY topmargin=0 leftmargin=0 onLoad="Init();">
<!-- #include file="../include/banner.inc" -->

<FORM name="LoginForm" ID="LoginForm" METHOD=POST  onSubmit="onLogin()"> 
	<input type="hidden" name="functionID" id="functionID" value="<%= Request.Form("functionID") %>">
	<input type="hidden" name="imageCaptureURL" id="imageCaptureURL" value="<%= imageCaptureURL %>">
	
	<TABLE ALIGN=CENTER CELLSPACING=0 CELLPADDING=10>
		<% if not validLogin then %>
		<TR>
			<TD colspan=2 style="font-weight:bold;color:#ff0000;">Invalid Login</TD>
		</TR>
		<% if not mustClockinPassed then %>
		<TR>
			<TD colspan=2 style="font-weight:bold;color:#ff0000;">Employee Must First Clock In</TD>
		</TR>
		<% end if
		end if %>
		<!--
		<TR>
			<TD>Access Code</TD>
			<TD><INPUT class=text type=text name="accessCode" id="accessCode"> </TD>
		</TR>
		-->
		<TR>
			<TD>Password</TD>
			<TD><input type="password" name="password" id="password" class="text" onBlur="onPasswordBlur();"> </TD>
		</TR>
		<TR>
			<TD COLSPAN=2 ALIGN=CENTER VALIGN=MIDDLE><INPUT type="Submit" style="height:50px;width=100px" name="SubmitButton" id="SubmitButton" Value="Login" ></TD>
		</TR>
	</TABLE>
</FORM>

<% getKeyboardsetting()
	if l_keyboard  then %>
	<!-- #include file="../include/keyboard_alphabeticalOrder.inc" -->
<% else %>
	<!-- #include file="../include/keyboard.inc" -->
<%end if %>
</BODY>

<%
	dim l_keyboard

	function getKeyboardsetting()
	dim sqltxt
	dim rsTemp

	l_keyboard = false

	sqltxt = "select switchOnscreenKeyboardAlphabetic from Miscsetup where storeid =  " & session("storeid")
	set rsTemp = getDisconnectedrecordset(sqltxt)
	'Response.Write sqltxt
	if rsTemp.recordCount > 0 then
		if rsTemp("switchOnscreenKeyboardAlphabetic")= true then
			l_keyboard = true
		end if
	end if
	rstemp.close
	set rstemp = nothing


	end function


%>
