<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim pickupDefaultSearch
	dim actionString
	dim query, rs
	dim errorMessage
	
	actionString = lcase(Request.QueryString("userAction"))
	
	select case actionString
		case "search"
			executeSearch
	
	end select
	
	
	getKeyboardsetting()
	
	
	sub executeSearch()
		dim invoiceNo
		invoiceNo = Request.QueryString("invoiceNo")
		if invoiceNo <> "" then
			query = "select customersequencenumber, ticketStatus, invoiceType, onHold "
			query = query & " from Ticket where invoicenumber = '" & invoiceNo & "'"

			set rs = getdisconnectedrecordset(query)
			
			
			if rs.recordcount > 0 then
				if rs("ticketStatus") <> "AC" then
					errorMessage = "Invoice not active"
				elseif rs("invoiceType") <> "D" then
					errorMessage = "Invoice not detailed"
				elseif rs("onHold") then
					errorMessage = "Invoice on hold"
				else
					Response.Redirect "customerfunctions.asp?customerseq=" & rs("customersequencenumber")
				end if

			
			else
				errorMessage = "Invoice number not found"
			end if
			
			set rs = nothing
		end if
	end sub
	
%>
<HTML>
<HEAD>
<TITLE>Pick Up Search</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
	<SCRIPT LANGUAGE=javascript>
	var lastFocusControl;
	<!--
		function test() {
			if(lastFocusControl) {
				if(lastFocusControl.tagName == "INPUT") {
					lastFocusControl.value = lastFocusControl.value + event.srcElement.innerText;
				}
				lastFocusControl.select();
			}
			
		}
	//-->
	
	function showScreen(element){
	var sInvoice
	var sCustomerid
	var sName
		if (element == "null" ){
		
		<%
			select case pickupDefaultSearch
			case 0 %>
			document.pickupSearchForm.txtCustomerName.focus()
		<%	case 1 %>
			document.pickupSearchForm.txtCustomerId.focus()
		<%	case 2 %>
			document.pickupSearchForm.txtInvoiceNumber.focus()
		<%	end select %>
			
			return
		}
		
		if (event.keyCode == 13 || element.name == "searchButton" ){
			if (trim(document.pickupSearchForm.txtInvoiceNumber.value) != ""){
				document.pickupSearchForm.action= "?userAction=search&invoiceNo=" + document.pickupSearchForm.txtInvoiceNumber.value;
				document.pickupSearchForm.submit()
			}
			else {
				sInvoice =trim(document.pickupSearchForm.txtInvoiceNumber.value)
				sCustomerid = trim(document.pickupSearchForm.txtCustomerId.value)
				sName = trim(document.pickupSearchForm.txtCustomerName.value)
				if (sInvoice == "" && sCustomerid == "" && sName == "" ){
					if(element.name != "searchButton")
						return;

					cbs_confirm("Search criteria could result in a large number of records. Would you like to revise your search criteria?", reviseSearch, finishSearch);
					return;
				}
			    finishSearch();
		}
	}

	function reviseSearch() {
        clearConfirmMsg();
		document.pickupSearchForm.txtCustomerName.focus()
	}

	function finishSearch() {
        clearConfirmMsg();
	    document.pickupSearchForm.action= "pickupSearchResults.asp?targetpage=pickupSearch.asp&name=" + document.pickupSearchForm.txtCustomerName.value + "&id=" + document.pickupSearchForm.txtCustomerId.value;
		document.pickupSearchForm.submit()
	}

	function cancelForm(){
			document.pickupSearchForm.action= "start2.asp";
			document.pickupSearchForm.submit()	
	

	}	
	</SCRIPT>

<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function txtCustomerName_onblur() {
	lastFocusControl = event.srcElement;
}

function txtCustomerId_onblur() {
	lastFocusControl = event.srcElement;
}

function txtInvoiceNumber_onblur() {
	lastFocusControl = event.srcElement;
}


//-->
</SCRIPT>
</HEAD>

<SCRIPT LANGUAGE="VBScript">
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload=showScreen('null')>
<!-- #include file="../include/banner.inc" -->

<TABLE width="98%" align=center cellspacing="2" cellpadding="0" border="0" style="WIDTH: 98%">
<TR>
   <TD>
   <FORM id="pickupSearchForm" name="pickupSearchForm" action="" method=post>
   <div style="background:red;color:white;text-align:center"><%=errorMessage%></div>
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
			<TR>
				<TD >
			        <P align=right STYLE="FONT-SIZE: 14px; FONT-WEIGHT: bold">Customer Last Name&nbsp;or&nbsp;Phone Number</P>
			    </TD>
				<TD>
					<INPUT id=txtCustomerName name=txtCustomerName 	class=text LANGUAGE=javascript onKeyup="showScreen(this)" onblur="return txtCustomerName_onblur()" 
						style="HEIGHT: 25px; WIDTH: 255px">
				</TD>
				<TD width = 150>
					<!--<INPUT class=touch id=searchButton name=searchButton type=button value="" style="background-image:url(../images/Search.gif)" onClick="showScreen(this)"><BR>Search-->
					<BUTTON class=reg id=searchButton name=searchButton onClick="showScreen(this)"><img src="../images/Search.gif">Search</button>
				</TD>
			</TR>
			<TR>
				<TD><P align=right><STRONG>Customer ID</STRONG></P></TD>
				<TD ><INPUT id=txtCustomerId name=txtCustomerId class=text LANGUAGE=javascript onKeyup="showScreen(this)" onblur="return txtCustomerId_onblur()" 
						style="HEIGHT: 25px; WIDTH: 254px">
            </TD>
			</TR>
			<TR>
				<TD><P align=right><STRONG>Invoice Number</STRONG></P></TD>
				<TD ><INPUT id=txtInvoiceNumber name=txtInvoiceNumber class=text LANGUAGE=javascript onKeyup="showScreen(this)" onblur="return txtInvoiceNumber_onblur()" 
						style="HEIGHT: 25px; WIDTH: 254px">
				</TD>
				<TD >
			 	<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
				</TD>
		
			</TR>
			<tr>
				<td colspan=3 align="left">
					<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
						<tr>
							<td>
							<% if l_keyboard  then %>
							<!-- #include file="../include/keyboard_alphabeticalOrder.inc" -->								
							<% else %>
							<!-- #include file="../include/keyboard.inc" -->
							<%end if %>
							</td>
							<td width=70></td>
						</tr>
					</TABLE>
				</td>
				
			</tr>
		</TABLE>
		<P>&nbsp;</P>
		
		
		
		<BR>
	</TD>
</TR>
</TABLE></FORM>   

</BODY>
</HTML>

<%
	dim l_keyboard
	
	function getKeyboardsetting()
	dim sqltxt
	dim rsTemp
	
	l_keyboard = false
	
	sqltxt = "select switchOnscreenKeyboardAlphabetic, pickupDefaultSearch from Miscsetup where storeid =  " & session("storeid")
	set rsTemp = getDisconnectedrecordset(sqltxt)
	'Response.Write sqltxt
	if rsTemp.recordCount > 0 then
		if rsTemp("switchOnscreenKeyboardAlphabetic")= true then
			l_keyboard = true
		end if
		
		pickupDefaultSearch = rsTemp("pickupDefaultSearch")
	end if
	rstemp.close
	set rstemp = nothing
		
	
	end function
	
	
%>


