<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/security.asp" -->
<!-- #include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim employeeID
	dim query, rs
	dim otherTimeID
	dim timeDate
	dim timeHours
	dim dateRangeStart
	dim dateRangeEnd
	dim loggedInEmployeeID
	dim message
	

	otherTimeID = getReqVar("otherTimeID")
	employeeID = session("setupEmployeeid")
	loggedInEmployeeID = session("employeeid")
	
	dateRangeStart = getReqVar("dateRangeStart")
	dateRangeEnd = getReqVar("dateRangeEnd")

	
	if dateRangeStart = "" then
		dateRangeStart = dateadd("yyyy", -1, date())
	end if
	
	if dateRangeEnd = "" then
		dateRangeEnd = date()
	end if
	
	select case lcase(request.querystring("useraction"))
		case "updatecycle"
			updateCycle
		case "addcycle"
			addCycle
		case "deletecycle"
			deleteCycle otherTimeID
		case "newcycle"
			otherTimeID = ""
	end select
	
	function updateCycle()
		updateCycle2 otherTimeID, request.form("timeDate"), request.form("timeHours"), Request.form("timeType"), Request.form("oteligible"), request.querystring("note"), loggedInEmployeeID
	end function
	
	function addCycle()
		addCycle2 request.form("timeDate"), request.form("timeHours"), Request.form("timeType"), Request.form("oteligible"), employeeid, loggedInEmployeeID
	end function

	function verifyCycleUpdate(employeeID, otherTimeID, timeDate, timeHours, timeType)
		dim query, rs
		
		query = " select * from employeeOtherTime where "
		query = query & " employeeid = " & employeeid
		if otherTimeID <> "" then
			query = query & " and otherTimeID <> " & otherTimeID
		end if
		query = query & " and timeType <> " & timeType 
		
		set rs = getdisconnectedrecordset(query)
		
		verifyCycleUpdate = (rs.recordcount = 0)
		
		set rs = nothing
	end function
	
	function deleteCycle(otherTimeID)
		dim query, rs

		if otherTimeID then
		  query = " delete from employeeOtherTime where otherTimeID = " & otherTimeID

		  qryexecute query
		end if
	end function
	
	function updateCycle2(otherTimeID, timeDate, timeHours, timeType, oteligible, note, loggedInEmployeeID)
		dim query, rs
		
	    if oteligible = "" then oteligible = 0 end if
		
		if otherTimeID <> "" and timeDate <> "" then
			query = " update employeeOtherTime set timeDate = " & DbCreateQryString(timeDate)
			query = query & ", timeHours = " & timeHours
			query = query & ", timeType = " & DbCreateQryString(timeType)
			query = query & ", oteligible = " & oteligible
			query = query & " where otherTimeID = " & otherTimeID
			
			qryexecute query
			
			query = " insert into employeeOtherTimelog (logtype, otherTimeID, timeDate, timeHours, timeType, otEligible, note, employeeID) "
			query = query & " values ('UP', " & otherTimeID
			query = query & ", " & DbCreateQryString(timeDate)
			query = query & ", " & timeHours
			query = query & ", " & DbCreateQryString(timeType)
			query = query & ", " & otEligible
			query = query & ", " & DbCreateQryString(note)
			query = query & ", " & loggedInEmployeeID & ")"
			
			qryexecute query
			
		end if
	end function
	
	
	function addCycle2(timeDate, timeHours, timeType, oteligible, employeeID, loggedInEmployeeID)
	    dim query, rs
	    
	    if oteligible = "" then oteligible = 0 end if
	    if timeHours = "" then timeHours = 0 end if
	
	    if timeDate <> "" then
			dbstartTrans()
			query = " insert into employeeOtherTime (employeeid, timeDate, timeHours, timeType, oteligible) "
			query = query & " values (" & employeeId
			query = query & ", " & DbCreateQryString(timeDate)
			query = query & ", " & timeHours
			query = query & ", " & DbCreateQryString(timeType) 
			query = query & ", " & oteligible & ")"
			
			qryexecutewithtrans query
			
			query = " insert into employeeOtherTimelog (logtype, otherTimeID, timeDate, timeHours, timeType, otEligible, note, employeeID) "
			query = query & " values ('AD', @@identity "
			query = query & ", " & DbCreateQryString(timeDate)
			query = query & ", " & timeHours
			query = query & ", " & DbCreateQryString(timeType)
			query = query & ", " & oteligible
			query = query & ", 'Add '"
			query = query & ", " & loggedInEmployeeID & ")"
			
			qryexecutewithtrans query
			dbendtrans()
	    end if
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	
	function addLeadingZeros(value, leadingZeros)
		value = CStr(value)
		
		while len(value) < leadingZeros
			value = "0" & value
		wend
		
		addLeadingZeros = value
	end function
	
	sub d_optionRange(minValue, maxValue, selValue, leadingZeros)
		dim index
		
		for index = minValue to maxValue
			Response.Write "<OPTION value=""" & index & """"
			if index = selValue then
				Response.Write " selected"
			end if
			Response.Write ">"
			Response.Write addLeadingZeros(index, leadingZeros)
			Response.Write "</OPTION>"
		next
	end sub
	
	function addLeadingZeros(value, leadingZeros)
		value = CStr(value)
		
		while len(value) < leadingZeros
			value = "0" & value
		wend
		
		addLeadingZeros = value
	end function

	sub d_optionRange(minValue, maxValue, selValue, leadingZeros)
		dim index
		
		for index = minValue to maxValue
			Response.Write "<OPTION value=""" & index & """"
			if index = selValue then
				Response.Write " selected"
			end if
			Response.Write ">"
			Response.Write addLeadingZeros(index, leadingZeros)
			Response.Write "</OPTION>"
		next
	end sub
	
	function getEmployeeName(employeeid)
		dim query, rs

		if employeeid <> "" then
			query = "select employeename from employee where employeeid = " & employeeid
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getEmployeeName = rs("employeename")
			end if
			
			set rs = nothing
		end if
	end function
%>
<HTML>
<HEAD>
<TITLE>Edit Employee Hours</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
<link href="../style/overlay.css" rel="stylesheet" type="text/css">
</HEAD>


<script language="JavaScript" src="../script/webui.js"></script>
<script language="JavaScript" src="../script/date-picker2.js"></script>

<SCRIPT LANGUAGE="JavaScript">
  function selectCycle(otherTimeID) {
    document.editEmpOtherHours.action = "?useraction=selectcycle&otherTimeID=" + otherTimeID;
    document.editEmpOtherHours.submit();
  }
	function selectDate(element) {
		show_calendar("editEmpOtherHours." + element.name);
	}
	
	function newCycle() {
        document.editEmpOtherHours.action = "?useraction=newcycle";
        document.editEmpOtherHours.submit();
	}

	function updateCycle() {
	    cbs_prompt("Update selected cycle?", doUpdateCycle, '', false, false)
	}

	function doUpdateCycle() {
        clearPromptMsg();
	    var note  = document.getElementById('inputTxtLine').value;
		  document.editEmpOtherHours.action = "?useraction=updatecycle&note=" + encodeURIComponent(note);
		  document.editEmpOtherHours.submit();
	}

	function addCycle() {
		document.editEmpOtherHours.action = "?useraction=addcycle";
		document.editEmpOtherHours.submit();
	}

	function deleteCycle() {
	    cbs_confirm("Delete selected cycle", doDeleteCycle);
	}

	function doDeleteCycle() {
        clearConfirmMsg();
	    document.editEmpOtherHours.action = "?useraction=deletecycle&otherTimeID=<%=otherTimeID%>";
        document.editEmpOtherHours.submit();
	}


	function updateDateRange() {
        document.editEmpOtherHours.action = "?useraction=update";
        document.editEmpOtherHours.submit();
	}
	function exitForm() {
        document.editEmpOtherHours.action = "employeeList.asp?userAction=editOtherHours";
        document.editEmpOtherHours.submit();
	}

	function displayMessage() {
	  <% if message <> "" then %>
        cbs_alert("<%=message%>");
      <% end if %>
	}
	
	
	function formatAmount(element)
	{
		var temp = cleanNumeric(element.value)
		element.value = autoFormatNumeric(temp)
	}
</script>

<BODY topmargin=0 leftmargin=0 onLoad="displayMessage()">

<!-- #include file="../include/banner.inc" -->
<H1>Edit Hours For <%=Server.HTMLEncode(getEmployeeName(employeeID))%></H1>
<FORM id="editEmpOtherHours" name="editEmpOtherHours" action="" method="post" onSubmit="return false">

<INPUT type="hidden" value="<%=otherTimeID%>" name="otherTimeID" />
<INPUT type="hidden" value="<%=employeeID%>" name="employeeID" />

<TABLE>
  <TR>
    <TD>
      Date Start<BR />
      <INPUT style="width:80px;text-align:center" name="dateRangeStart" value="<%=dateRangeStart%>" onclick="selectDate(this);" />
    </TD>
    <TD>
      Date End<BR />
      <INPUT style="width:80px;text-align:center" name="dateRangeEnd" value="<%=dateRangeEnd%>" onclick="selectDate(this);" />
    </TD>
    <TD>
      <BR />
      <INPUT type="button" value="Update" onclick="updateDateRange()" />
    </TD>
  </TR>
</TABLE>

<TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
<TR valign="top" style="background:white" cellspacing="0" cellpadding="0" border="0">
<TD>
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin:0">
	<SPAN style="float:left">
    <BUTTON onclick="newCycle()" >New</BUTTON>
	</SPAN>
	
	<SPAN style="float:right;">

	</SPAN>
</DIV>
<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
<TR>
	<TH>Date</TH>
	<TH>Hours</TH>
	<TH>Type</TH>
	<TH>OT Eligible</TH>	
</TR>
<%
	query = " select * from employeeOtherTime where employeeid = '" & employeeID & "'"

	if dateRangeStart <> "" then
		query = query & " and  datediff(d, timeDate, '" & dateRangeStart & "') <= 0 "
	end if
	if dateRangeEnd <> "" then
		query = query & " and datediff(d, timeDate, '" & dateRangeEnd & "') >= 0  "
	end if
	
	query = query & " order by timeDate, timeType desc "
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
%>
<TR
<% if trim(rs("otherTimeID")) = trim(otherTimeID) then %>
class="selected"
<% end if %>
onclick="selectCycle(<%=rs("otherTimeID")%>)">
	<TD align="left"><%=FormatDateTime(rs("timeDate"), vbShortDate)%></TD>
	<TD align="left"><%=rs("timeHours")%></TD>
	<TD align="left"><%=rs("timeType")%></TD>
	<TD align="left"><%=rs("oteligible")%></TD>
</TR>

<%
		rs.movenext
	wend
	set rs = nothing
%>


</TABLE>
</TD>
<TD width="1%" style="border-left:1px solid #aaa">
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin:0">
	<SPAN style="float:left">
	
	<% if otherTimeID <> "" then %>
    <BUTTON onclick="updateCycle()" >Update</BUTTON>
  <% else %>
    <BUTTON onclick="addCycle()" >Add</BUTTON>
  <% end if %>
  
    <BUTTON onclick="deleteCycle()" >Delete</BUTTON>
    
	</SPAN>
	
	<SPAN style="float:right;">
    <BUTTON onclick="exitForm()" >Exit</BUTTON>
	</SPAN>
</DIV>
<%
  dim cycleTimeDate
  dim cycleTimeHours
  dim cycleTimeType
  dim cycleOTEligible
  
  
	cycleTimeDate = now()
	
  if otherTimeID <> "" then
    query = " select * from employeeOtherTime where otherTimeID = " & otherTimeID
    
    set rs = getdisconnectedrecordset(query)
    
    if rs.recordcount > 0 then
      cycleTimeDate = rs("timeDate")
      cycleTimeHours = rs("timeHours")
      cycleTimeType = rs("timeType")
      cycleOTEligible = rs("oteligible")
    end if
  
  end if
%>


<TABLE style="background:#ccc" border="0" cellpadding="5" width="250px" >
  <TR>
    <TD colspan="2">
      <INPUT style="width:100%" value="Cycle" style="text-align:center" readonly />
    </TD>
  </TR>
  <TR>
    <TD>Date</TD>
    <TD align="right">
      <INPUT name="timeDate" value="<%=FormatDateTime(cycleTimeDate, vbShortDate)%>" style="text-align:center" onclick="selectDate(this);" />
    </TD>
  </TR>
  <TR>
    <TD>Hours</TD>
    <TD align="right">
		<INPUT style="width: 40px; text-align: right" name="timehours" value="<%=cycleTimeHours%>" />
	</TD>
  </TR>
  <TR>
    <TD>Type</TD>
    <TD align="right">
		<select style="width: 80px; text-align: right" name="timetype" />
			<option value="V" <%if cycleTimeType = "V" then%> selected <%end if%>>Vacation</option>
			<option value="S" <%if cycleTimeType = "S" then%> selected <%end if%>>Sick</option>
			<option value="H" <%if cycleTimeType = "H" then%> selected <%end if%>>Holiday</option>
			<option value="F" <%if cycleTimeType = "F" then%> selected <%end if%>>Funeral</option>
			<option value="B" <%if cycleTimeType = "F" then%> selected <%end if%>>Birthday</option>
		</select> </TD>
  </TR>
  <TR>
    <TD>OT Eligible</TD>
    <TD align="right">
		<INPUT type=checkbox  name="oteligible" value=1 <%if cycleoteligible then%> checked <%end if%>  /></TD>
  </TR>
</TABLE>
</TD>
</TR>
</FORM>
</BODY>
</HTML>
