<%
	dim dbname
	
	dbname = request.querystring("dbname")
	
	if dbname = "" then
		dbname = session("dbname")
	end if
	
	session.abandon

	response.redirect "start3.asp?dbname=" & dbname
%>
