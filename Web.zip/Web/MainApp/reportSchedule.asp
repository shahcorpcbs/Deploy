<%@ Language=VBScript %>

<%option explicit%>

<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="CheckSessionExpiry.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim objresult  
	dim reportID
	dim reportName
	dim scheduleID

	If isNumeric(Trim(Request.QueryString("scheduleID"))) Then
		scheduleID = CLng(trim(Request.QueryString("scheduleID")))
	Else
		scheduleID = 0
	End if
	
	If isNumeric(Trim(Request.QueryString("reportID"))) Then
		reportID = CLng(trim(Request.QueryString("reportID")))
	Else
		reportID = 0
	End If

	reportName = trim(Request.QueryString("reportName"))
	
	On Error Resume Next
	If scheduleID > 0 And Request.QueryString("action") = "DELETE" Then
		 Call openConnection
	     Call QryExecuteWithTrans("EXECUTE Rpt_DeleteSchedule @scheduleID = " & scheduleID)
	     Call closeConnection
	End if
	
%>

<HTML>
<HEAD>
<TITLE>Schedule Search</TITLE>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

	<SCRIPT LANGUAGE=javascript>
	var lastFocusControl;
	var previousElement=null;
	var x;
				
	function selectRow(element) {

		var childEl;
		if (previousElement !=null){
			previousElement.style.background="white";
			//previousElement.style.background="#EEF8F0";
		}

		childEl = element.children[0];
		var rowChildNodes = childEl.children
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if (childEl.name == "selectid") {
				x = childEl.value;
			}
			 
			/*	if(childEl.tagName == "INPUT") {
				childEl.checked=true;
				break;
			}  */
		}
		previousElement =element;
		element.style.background="#DBF2F4";
		document.searchResults.selectButton.disabled= false;
		document.searchResults.deleteScheduleButton.disabled= false;
	}


	function addNewSchedule(){

		document.searchResults.action = "reportParams.asp?scheduleID=0&reportID="+ document.searchResults.reportID.value+ "&requesterName=SCHEDULE" + "&reportName="+ document.searchResults.reportName.value ;
		document.searchResults.submit();
	}

	function deleteSchedule(){
	    cbs_confirm("This option will permanently remove the selected schedule from the database. Do you wish to continue?", doDeleteSch);
	}

	function doDeleteSch() {
        clearConfirmMsg();
	    document.searchResults.action = "reportSchedule.asp?action=DELETE&scheduleID=" + x + "&reportID="+ document.searchResults.reportID.value + "&reportName="+ document.searchResults.reportName.value + "&requesterName=SCHEDULE";
        document.searchResults.submit();
	}

	function selectSchedule(){
		document.searchResults.action = "reportParams.asp?scheduleID=" + x + "&requesterName=SCHEDULE" + "&reportID="+ document.searchResults.reportID.value + "&reportName="+ document.searchResults.reportName.value;
		document.searchResults.submit();

	}

	function captureKeyUpEvent(element){
		
	  	if (event.keyCode == 13){
	  		event.returnValue = true;	
			selectSchedule();
		}
	}

</SCRIPT>
</HEAD>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Existing Schedules for - <%= reportName %> </H1>

<TABLE width="98%" bgcolor=#A3D8AE align=center cellspacing="2" cellpadding="0" border="0">
<FORM id="searchResults" name="searchResults" action="" method="POST">
<TR>
   <TD>
  
		<BR><!-- Search Results -->
		<DIV STYLE="overflow-y:auto;height:400px; overflow-x:auto; width=700px">

		<input type="hidden" name="reportID" id="reportID" value="<%=reportID%>">
		<input type="hidden" name="reportName" id="reportName" value="<%=reportName%>">

		<TABLE align=center WIDTH="98%" BORDER=1 CELLSPACING=1 CELLPADDING=1 style="WIDTH: 98%;border-color:black;">
			<TR class=head>
				<TD>Schedule Name</TD>
				<TD>Frequency</TD>
			</TR>
			<%
				'Response.Write " going to reterived results "
				getSearchResult(reportID)
				if objresult.recordcount <=0 then %>
					Currently there are no jobs scheduled to run this report. 
			<%	else
			
				while not objresult.EOF
							
			%>
			<TR class=data onClick="selectRow(this)" onKeyPress="captureKeyUpEvent(this)" >
				<TD ALIGN=left>
					<input type="hidden" name="selectid" id="selectid" style="Height=25px;Width=25px" value="<%=objresult("scheduleID")%>">
				<%=cstr(objresult("Schedulename"))%>&nbsp</TD>
				<TD ALIGN=left><%=objresult("frequencyTypeDescription")%>&nbsp</TD>				
			</TR>
			<%
				objresult.movenext
				wend
				objresult.close
				set objresult = nothing
				end if
			%>
									
		</TABLE>
		</div>
		
		<BR>
	</TD>
</TR>
<tr>
	<td>
		<TABLE WIDTH="700px" BORDER=0 CELLSPACING=1 CELLPADDING=2>
			<tr>
				<td align=center>
					<INPUT class=touch id=selectButton name=selectButton type=button value=""  style="background-image:url(../images/select.gif)" disabled onClick="selectSchedule()"><br>Select<br>
				</td>

				<td align=center>
					<INPUT class=touch id=newScheduleButton name=newScheduleButton type=button value=""   style="background-image:url(../images/New-Data.gif)" onClick= "addNewSchedule()" ><br>New<br>
				</td>

				<td align=center>
					<INPUT class=touch id=deleteScheduleButton name=deleteScheduleButton type=button value=""   style="background-image:url(../images/Cancel-2.gif)" disabled onClick= "deleteSchedule()" ><br>Delete<br>
				</td>

				<td align=center>
					<INPUT class=touchnoborder id=backToSearch name=backToSearch type=button value=""  style="background-image:url(../images/Cancel.gif)" onClick="location.href='reportList.asp'"><br>
				</td>
				
			</tr>
		</table>
	</td>
</tr>
</FORM>   
</TABLE>

</BODY>
</HTML>
<% 

	function getSearchResult(reportID)
	dim sqltxt
	
		sqltxt = "SELECT SF.scheduleID, SF.scheduleName, SF.storeID, SF.frequencyType, SFT.frequencyTypeDescription " & _
				 " FROM ScheduleFrequency SF, ScheduleFrequencyTypeDomain SFT" & _
				 " WHERE jobID = " & reportID & _
				 "  AND jobType = 'R'" & _
				 "  AND SF.frequencyType = SFT.frequencyType" & _
				 " ORDER BY SF.scheduleName"

		set objresult = getdisconnectedrecordset(sqltxt)
	
	end function
	
%>