<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="CheckSessionExpiry.asp" -->

<%

Call UpdateSessionParams

reportDisplayASPURL = "reportDisplay.asp"


%>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>CBS Reports</title>
</head>


<!-- frames -->

<!--
<frameset rows="10%,*,5%" framespacing="1" frameborder="yes" bordercolor="#0000FF">
-->

<frameset rows="*,66" framespacing="1" frameborder="yes" bordercolor="#FFF" scrolling="Yes">

 	<!-- 
 	<frame noresize src="reportHeader.htm" name="reportheader" id="reportheader" frameborder="0" scrolling="No" marginwidth="10" marginheight="10">
 	-->
    <frame src="<%=reportDisplayASPURL%>" name="reportbody" id="reportbody" scrolling="Auto" marginwidth="10" marginheight="10">

    <frame noresize src="reportFooter.asp?source=<%=request.querystring("source")%>&requesterName=<%=request.form("requesterName")%>" name="reportfooter" id="reportfooter" frameborder="0" scrolling="No">

</frameset>

</html>
