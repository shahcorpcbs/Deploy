<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim pickupDefaultSearch
	dim actionString
	dim query, rs
	dim ticketNumbers

	ticketNumbers = Request.QueryString("ticketNumber")
	actionString = lcase(Request.QueryString("userAction"))

    if actionString = "done" then
        setPickedUp
    end if

    function getInvNoForTicket(ticketNumber)
        dim invQuery, invRs
        invQuery = "select invoiceNumber from Ticket where TicketNumber = " & ticketNumber
        set invRs = getdisconnectedrecordset(invQuery)
        getInvNoForTicket = invRs("invoiceNumber")
    end function


    function setPickedUp
        dim ids, invoicesSelected, fields, n, updateQuery
        ids = Request.QueryString("ids")

        invoicesSelected = split(ids, ",")
        for n = lbound(invoicesSelected) to ubound(invoicesSelected)
            fields = split(invoicesSelected(n), "_")
            updateQuery = "update InvoiceSubDivision set pickedUp = 1 where ticketNumber = " & fields(0) _
                & " and SubLabel = '" & fields(1) & "'"
            qryexecute updateQuery
        next


        dim ticketNos, j
        ticketNumbers = Request.Form("ticketNumber")
        ticketNos = split(ticketNumbers, ",")
        for n = lbound(ticketNos) to ubound(ticketNos)
            query = "select id from InvoiceSubDivision where pickedup = 0 and TicketNumber = " & ticketNos(n)
            set rs = getdisconnectedrecordset(query)
            if rs.recordcount > 0 then  'Invoice isn't actually finished
                updateQuery = "update Ticket set ticketStatus = 'AC' where TicketNumber = " & ticketNos(n)
                qryexecute updateQuery
                updateQuery = "update TicketLineItem set pickedup = 0 from TicketLineItem tli, InvoiceSubDivision isd, " _
                    & "InvoiceSubDivisionItems isdi where isdi.TicketNumber = " & ticketNos(n) & " and tli.TicketNumber = " _
                    & ticketNos(n) & " and isdi.LineItemId = tli.lineItemNumber and isdi.InvoiceSubNum = isd.Id " _
                    & "and isd.pickedUp = 0"
                qryexecute updateQuery
            else
                updateQuery = "update Ticket set ticketStatus = 'FI' where TicketNumber = " & ticketNos(n)
                qryexecute updateQuery
            end if
        next


         Response.Redirect "customerfunctions.asp?userAction=print&addOrEdit=" & Request.Form("addOrEdit") _
            & "&ticketNumber=" & Request.Form("ticketNumber") _
            & "&invoiceType=P&customerseq=" & Request.Form("customerseq") _
            & "&totalchangedue=" & Request.Form("totalchangedue") _
            & "&action=" & Request.Form("action")
    end function
	
%>
<HTML>
<HEAD>
<TITLE>Pick Up Selection</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<script language="javascript" src="../External/jquery-1.6.4.js"></script>
	<SCRIPT LANGUAGE=javascript>

	    function selectAll(ticketNumber) {
	        jQuery("input[id^='" + ticketNumber +"']").each(function() {
	            this.checked = true;
            });

	    }

	    function selectNone(ticketNumber) {
	        jQuery("input[id^='" + ticketNumber +"']").each(function() {
	            if (!$(this).is('[disabled]'))
	                this.checked = false;
            });
	    }

	    function submitForm() {
	        var path = "?useraction=done&ids=";

            $('input[type=checkbox]').each(function() {
	            if (!$(this).is('[disabled]') && this.checked) {
	                path = path + $(this).attr('id') + ",";
	            }
            });
            if (path.includes(","))
                path = path.slice(0,-1);

            document.pickupChoiceForm.action = path;
            document.pickupChoiceForm.submit();
	    }

	</SCRIPT>

</HEAD>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<FORM id="pickupChoiceForm" name="pickupChoiceForm" action="" method=post>
<input type="hidden" name="ticketNumber" value="<%= ticketNumbers%>">
<input type="hidden" name="addOrEdit" value="<%=Request.QueryString("addOrEdit")%>">
<input type="hidden" name="customerseq" value="<%=Request.QueryString("customerseq")%>">
<input type="hidden" name="totalchangedue" value="<%=Request.QueryString("totalchangedue")%>">
<input type="hidden" name="action" value="<%=Request.QueryString("action")%>">

<H1>Select Items Being Picked Up</H1>

<TABLE width="98%" align=center cellspacing="2" cellpadding="0" border="0" style="WIDTH: 98%">
<TR>
   <TD>
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >


        <%
            dim ticketNos, currTN, i
            ticketNos = split(ticketNumbers, ",")
            for i = lbound(ticketNos) to ubound(ticketNos)
                currTN = ticketNos(i)

                query = "select isd.*, tli.lineItemName from InvoiceSubDivision isd, TicketLineItem tli where isd.ticketNumber = " _
                    & currTN & " and tli.ticketNumber = isd.TicketNumber and tli.lineItemNumber = isd.lineItemId"
                set rs = getdisconnectedrecordset(query)
                if rs.recordcount > 0 then
                %>

                <tr>
                    <td style="text-align: right">Invoice <%= getInvNoForTicket(currTN)%> </td>
                    <td style="white-space: nowrap; width: 10%">
                        <input type="radio" name="source" id="all<%=currTN %>" onClick="selectAll(<%=currTN %>)"><label for="all<%=currTN%>">All</label>
                        <input type="radio" name="source" id="none<%=currTN %>" onClick="selectNone(<%=currTN %>)"><label for="none<%=currTN %>">None</label>
                    </td>
                </tr>
                <%
                while not (rs.eof or rs.bof) %>
                <tr><td></td>
                    <td style="vertical-align: top;">
                        <INPUT type=checkbox id="<%=currTN%>_<%=rs("SubLabel")%>" checked <%if rs("pickedUp") then %> disabled <%end if %>>
                        <label for="<%=currTN%>_<%=rs("SubLabel")%>" <%if rs("pickedUp") then %>style="opacity: 0.5;"<%end if%>><%= rs("SubLabel")%></label></td>
                    <td>
                        <table>
                        <tr><td></td></tr>
                            <tr><td <%if rs("pickedUp") then %> style="opacity: 0.5;"<%end if%>><%=rs("lineItemName")%></td></tr>
                        </table>
                    </td>
                </tr>
           <%
                rs.movenext
                wend
            %>
           <tr><td></td>
                <td style="vertical-align: top;">Not Yet Assigned</td>
                    <td>
                        <table>
                        <tr><td></td></tr>
                            <% dim unsetQuery, unsetRS
                                unsetQuery = "select lineItemName from TicketLineItem where ticketNumber = " _
                                    & currTN & " and ticketLineType = 'IT' and lineItemNumber not in " _
                                    & "(select lineItemId from InvoiceSubDivision where ticketNumber = " & currTN & ")"

                                set unsetRS = getdisconnectedrecordset(unsetQuery)
                                while not (unsetRS.eof or unsetRS.bof) %>
                            <tr><td><%=unsetRS("lineItemName")%></td></tr>
                            <% unsetRS.movenext
                               wend %>
                        </table>
                    </td>
            </tr>
           <%
           end if
           next
            %>
		<BR>
	</TD>
</TR>
		<tr height=30px></tr>
		<tr>
			<TD colspan="6">
				<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=okButton name=okButton style="background-image:url(../images/Ok.gif)" type=button value="" onClick="submitForm()">
						</td>
					</tr>
				</table>
			</TD>
		</tr>
		<tr height=100px><td></td></tr>


</TABLE></FORM>   

</BODY>
</HTML>


