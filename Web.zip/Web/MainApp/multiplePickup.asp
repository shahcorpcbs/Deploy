<%@ language=VBScript%>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	'***********************************************************************
	'Name   :Prompt for on demand coupon
    'Author : Poonam Gupta
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 01-Jul-2002    Poonam			Original Version
    ' 11-Jul-2002	 Poonam			Added the functionality to update multipickup name
	'								& multiPickup Location
	'								Also added the functionality to update
	'								starch & finish preference
    '***********************************************************************
    
	dim storeId
	dim ticketNumber
	dim addOrEdit
	dim multiLoc
	dim multiCustName

	dim originatingPage
	dim sInvoicenumber
	
	dim query, rs
	dim customerSequenceNumber
	
	customerSequenceNumber = session("customerSequenceNumber")
	
	storeId = Session("storeID")
	addOrEdit = Request.QueryString("addOrEdit")
	ticketNumber = Request.QueryString("ticketNumber")
	select case addOrEdit 
		case "add"
				multiCustName =""
				multiLoc =""
		case "edit"
			getCustomerMultiPickUpDetails
			originatingPage = Request.QueryString("originPage")
	end select
	
	sub getCustomerMultiPickUpDetails()
		dim ssql
		dim objResultSet
		ssql = "Select IsNull(multiPickupCustomerName,'') as multiPickupCustomerName, " _
				& " IsNull(multiPickupLocation,'') as multiPickupLocation, " _
				& " ticket.invoicenumber as invoicenumber  FROM Ticket, TicketCustomer " _
				& " Where Ticket.ticketNumber="  & ticketNumber & " And ticket.ticketNumber =" _
				& " ticketCustomer.ticketNumber"
		Set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Recordcount > 0 then
			multiCustName = objResultSet.Fields("multiPickupCustomerName").Value
			multiLoc = objResultSet.Fields("multiPickupLocation").Value
			sInvoicenumber = objResultSet.Fields("invoicenumber").Value
		end if
	end sub

	
	
	function getPreferenceValue(customerSeq, ticketNumber, customerpreferencetypeid, default)
		dim query, rs
		
		getPreferenceValue = default		
		
		if customerSeq <> "" then
			query = " select [value] from customerpreference where "
			query = query & " customerpreferencetypeid = " & customerpreferencetypeid
			query = query & " and customersequencenumber = " & customerSeq
			query = query & " and ticketnumber is null "
			
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getPreferenceValue = rs("value")
			end if
			
			set rs = nothing
			
			if ticketNumber <> "" then
				query = " select [value] from customerpreference where "
				query = query & " customerpreferencetypeid = " & customerpreferencetypeid
				query = query & " and customersequencenumber = " & customerSeq
				query = query & " and ticketnumber = " & ticketNumber
				
				set rs = getdisconnectedrecordset(query)
				
				if rs.recordcount > 0 then
					getPreferenceValue = rs("value")
				end if
				
				set rs = nothing
			end if
		end if
	end function
%>
<HTML>
<HEAD>
<TITLE>Multiple Pickup</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	
	function submitForm(submitAction) {
		var starchPref;
		var finishPref;

		if($("input[name='starchpref']").length > 0)
			starchPref = $("input[name='starchpref']").val();
			
		if($("input[name='finishpref']").length > 0)
			finishPref = $("input[name='finishpref']").val();
		
		document.multiplePickupForm.action = "detailedInvoice.asp?userAction=fromMultiplePickup&submit=" + submitAction + "&starchPref=" + starchPref + "&finishPref=" + finishPref;
		document.multiplePickupForm.submit();
	}
	
	
	function selectPreferenceOption(customerpreferencetypeid, o) {

		$('.opt' + customerpreferencetypeid + 'pref').each(function(i) {
			this.style.background = 'white';
		});

		$('#opt' + customerpreferencetypeid).val(o.value);
		
		o.style.background = 'red';
	}
	
</script>

<BODY topmargin=0 leftmargin=0 onload="document.multiplePickupForm.txtName.focus();">

<!-- #include file="../include/banner.inc" -->
<H1>Multiple Pickup
<%=sinvoicenumber %>&nbsp;</H1>
<FORM id="multiplePickupForm" name="multiplePickupForm" action="multiplePickup.asp" method="post" >

<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
<INPUT type="hidden" name="ticketNumber" value="<%= ticketNumber %>">
<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">

	
<BR>
<div name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<span style="float:left">

	</span>
	<span style="float:right">
      <button name="ok"  onClick="submitForm('ok');">Ok</button>
	</span>
</div>	

<TABLE class="itable" cellspacing="0">
<TR>
	<TD style="width:200px">Name</TD>
	<TD><INPUT id=txtName name=txtName class=text style="WIDTH: 200px" value="<%= multiCustName%>"></TD>
</TR>
<TR>
	<TD style="width:200px">Location</TD>
	<TD><INPUT id=txtLocation name=txtLocation class=text style="WIDTH: 200px" value="<%= multiLoc%>"></TD>
</TR>

<%
	dim preferenceValue
	
	query = " select *, isnull(options, '') as options from customerpreferencetype order by displayorder "
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
		preferenceValue = getPreferenceValue(customerSequenceNumber, ticketNumber, rs("customerpreferencetypeid"), rs("default"))
%>
<TR>
	<TD style="width:200px"><%=rs("name")%></TD>
	<TD style="width:200px"><INPUT style="width:200px" onkeyup="onPreferenceValueKeyUp(this)" id="opt<%=rs("customerpreferencetypeid")%>" name="<%=lcase(rs("name"))%>pref"  value="<%=preferenceValue%>" /></TD>
	<TD>
	&nbsp;
<%
	dim optionsArray
	dim opt
	
	optionsArray = split(rs("options"), "|")
	
	for each opt in optionsArray
%>
	<INPUT type="button" style="width:100px;height:40px;"
		onclick="selectPreferenceOption(<%=rs("customerpreferencetypeid")%>, this)"
		value="<%=opt%>"
		class="opt<%=rs("customerpreferencetypeid")%>pref"
		<% if preferenceValue = opt then %>style="background:red"<%else%>style="background:white"<%end if%>
	/>
<%
	next
%>
	</TD>
</TR>
<%
		rs.movenext
	wend
	set rs = nothing
%>
</TABLE>

</BODY>
</HTML>

