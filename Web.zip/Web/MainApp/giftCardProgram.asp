<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Gift Card Program</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		document.giftCardProgramForm.submit();
	}
	
	function cancelForm() {
		document.giftCardProgramForm.action="ManagerMenu.asp";
		document.giftCardProgramForm.submit()
	}	
	
	function issueGiftCard(){
		document.giftCardProgramForm.action ="issueGiftCard.asp";
		document.giftCardProgramForm.submit();
	}
	
	function giftCardMaintenance(){
		document.giftCardProgramForm.action ="maintGiftCard.asp";
		document.giftCardProgramForm.submit();
	}
	
	function giftCardReports() {
		document.giftCardProgramForm.action="giftCardReports.asp";
		document.giftCardProgramForm.submit();
	}

		
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Gift Card Program</B>
<FORM id="giftCardProgramForm" name="giftCardProgramForm" action="start2.asp" method="Post">
<TABLE ALIGN=CENTER WIDTH=350px BORDER=1 CELLSPACING=0 CELLPADDING=0>
	<TR><TD>
	<TABLE ALIGN=center WIDTH=100% BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<TR height=60px></TR>	
		<TR height=100px>
			<TD align=center colspan = 2>
				<INPUT class=click id=giftIssue name=giftIssue style="" type=button value="Issue Gift Card" onClick="issueGiftCard()">
			</TD>
		</TR>

		<TR height=60px></TR>	
		<TR height=100px>
			<TD align=center colspan = 2>
				<INPUT class=click id=giftMaint name=giftMaint type=button  style="" value="Gift Card Maintenance" onClick="giftCardMaintenance()">
			</TD>
		</TR>	

		<TR height=60px></TR>	
		<TR height=100px>
			<TD align=center colspan = 2>
				<INPUT disabled class=click id=giftReports name=giftReports type=button value="Reports"  style="" onClick="giftCardReports()">
			</TD>
		</TR>

		<TR height=60px></TR>	
		<TR >
			<TD colspan = 2 ALIGN=center>
				<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
			</TD>	
		</TR>			

	</TABLE>
	</TD></TR>
</TABLE>	
</FORM>   

</BODY>
</HTML>