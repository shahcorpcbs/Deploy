﻿<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp"-->
<!-- #include file="../include/creditCardTransaction.asp" -->

<%
    If Not IsEmpty(Request.QueryString("Method")) Then

        If Request.QueryString("Method") = "rerackInvoice" Then
            rerackInvoice
        Else
            Dim cc
            Set cc = New CreditCardTransaction

            Select Case Request.QueryString("Method")

                Case "getCreditSaleUrl"
                    Response.Write cc.getCreditSaleUrl(Request.QueryString("amount"))

                Case "getCreditReturnUrl"
                    Response.Write cc.getCreditReturnUrl(Request.QueryString("amount"))

                Case "processPickupSaleTransaction"
                    Response.Write cc.processPickupSaleTransaction(Request.QueryString("amount")).toJson()

                Case "processApplyPaymentSaleTransaction"
                    Response.Write cc.processApplyPaymentSaleTransaction(Request.QueryString("amount")).toJson()

                Case "processReturnPaymentTransaction"
                    Response.Write cc.processReturnPaymentTransaction(Request.QueryString("amount"), Request.QueryString("customerSequenceNumber"), Request.QueryString("ticketNumber"), Request.QueryString("paymentNumber")).toJson()
            
                Case "getPickupCreditCardResultsResponse"
                    Response.Write cc.getPickupCreditCardResultsResponse

                Case "processPickupCardOnFileTransaction"
                    Response.Write cc.processPickupCardOnFileTransaction(Request.QueryString("amount"), Request.QueryString("alias"), Request.QueryString("expirationDate"), Request.QueryString("zipCode"))

                Case "getApplyPaymentCreditCardResultsResponse"
                    Response.Write cc.getApplyPaymentCreditCardResultsResponse

                Case "processApplyPaymentCardOnFileTransaction"
                    Response.Write cc.processApplyPaymentCardOnFileTransaction(Request.QueryString("amount"), Request.QueryString("alias"), Request.QueryString("expirationDate"), Request.QueryString("zipCode"))

                Case "getReturnPaymentCreditCardResultsResponse"
                    Response.Write cc.getReturnPaymentCreditCardResultsResponse(Request.QueryString("ticketNumber"), Request.QueryString("paymentNumber"))

                Case "updateAliasExpDate"
                    Response.Write cc.updateAliasExpDate(Request.Form("ExpirationMonth") & Request.Form("ExpirationYear"))
            
                Case "voidPayment"            
                    Response.Write cc.voidPayment(Request.QueryString("transactionID"), Request.QueryString("salePaymentNumber"), Request.QueryString("customerSequenceNumber"), Request.QueryString("amount"), CBool(Request.QueryString("cardPresent")))

            End Select
        End If

    End If



    Function rerackInvoice
        Dim invoiceNumber
        Dim rackLocation
        Dim employeeID
        Dim employeeName
        Dim storeID
        Dim terminalID

        invoiceNumber = Request.QueryString("invoiceNumber")
        rackLocation = Request.QueryString("rackLocation")

        employeeID = Session("employeeID")
        employeeName =Session("employeeName")
        storeID = Session("storeID")
        terminalID = Session("terminalID")

        Dim sql
        sql = "EXECUTE dbo.ReactivateTicket @invoiceNumber = '" & invoiceNumber & "', @rackLocation = '" & rackLocation & "', @employeeID = " & employeeID
        sql = sql & ", @employeeName = '" & employeeName & "', @storeID = " & storeID & ", @terminalID = " & terminalID

        QryExecute sql
        
    End Function

%>
