<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<%
	dim accountname
	dim accountid

	
	accountname = Request.QueryString("accountname")
	accountid = getMessageAccountID(accountname)

	
	function getMessageAccountID(username)
		dim query, rs

		query = "select id from messageaccount where lower(username) = '" & lcase(username) & "'"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getMessageAccountID = rs("id")
		else
			getMessageAccountID = ""
		end if

		set rs = nothing
	end function

	function getMessageServerURL()
		dim query, rs
		
		query = "select isnull(messageServerURL, '') as messageServerURL from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getMessageServerURL = trim(rs("messageServerURL"))
		
		set rs = nothing
	end function
	
	function getBrightness(col)
		dim r, g, b
		
		r = clng("&H" & left(col, 2))
		g = clng("&H" & mid(col, 3, 2))
		b = clng("&H" & right(col, 2))

		getBrightness = 0.3 * r + 0.59 * g + 0.11 * b
	end function
	
	function fontContrastColor(col)
		if getBrightness(col) > 128 then
			fontContrastColor = "000000"
		else
			fontContrastColor = "ffffff"
		end if
	end function
	
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<SCRIPT language="javascript" type="text/javascript">
	var w1, w2;
	
	function viewMessage(id) {
		if(w1) w1.close();
		w1 = window.open("<%=getMessageServerURL()%>/MainApp/MessageView.asp?messageid=" + id, "MessageView", "status=no,scrollbars=no,width=600,height=600,modal=yes");
	}
	function viewTask(storeguid, customerseq, taskid) {
		window.opener.jumpToCustomerManagement(storeguid, customerseq, taskid);
		window.close();
	}
	
	function viewTaskBrief(taskid) {
		if(w2) w2.close();
		w2 = window.open("<%=getMessageServerURL()%>/MainApp/viewtask.asp?taskid=" + taskid + "&messageusername=<%=accountname%>", "ViewTask", "status=no,scrollbars=no,width=530,height=550,modal=no");
	}
	
	function closePopups() {
		if(w1) w1.close();
		if(w2) w2.close();
	}
</SCRIPT>


</HEAD>

<BODY STYLE="margin:0;padding:0;background:#FFF" onunload="closePopups();" onclose="closePopups();">

<FORM id="messagehistory" name="messagehistory" method="post" style="margin:0;padding:0;">

<INPUT type="hidden" name="accountname" value="<%=accountname%>">


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="margin:13px; float:left">
		<DIV style="background:white">
		</DIV>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="window.close()">Close</BUTTON>
	</SPAN>
</DIV>

<TABLE class="itable" cellspacing="0" cellpadding="0">



<%
	query = "select task.*, taskpriority.name as priorityname, taskpriority.color as prioritycolor, customertask.customername, customertask.storeguid, customertask.customersequencenumber from "
	query = query & " employeetask inner join task on "
	query = query & " employeetask.taskid = task.id "
	query = query & " inner join taskpriority on "
	query = query & " task.priority = taskpriority.id "
	query = query & " left outer join customertask on "
	query = query & " employeetask.taskid = customertask.taskid "
	query = query & " where employeetask.employeemessageid = '" & accountname & "'"
	query = query & " and task.dateclosed is null"
	query = query & " and (task.dateopen is null or datediff(day, task.dateopen, getdate()) >= 0) "
	query = query & " order by task.priority desc, task.datecreated desc"

	set rs = getdisconnectedrecordset(query)

	if rs.recordcount > 0 then
%>
	<TR align="left">
		<TH align="center" style="width:60px">&nbsp;</TH>
		<TH>Customer</TH>
		<TH>Subject</TH>
		<TH>Sent</TH>
		<TH>Due Date</TH>
	</TR>
<%
	end if
	
	while not(rs.eof or rs.bof)
%>
		
	<TR style="color:black;background:#<%=rs("prioritycolor")%>;color:#<%=fontContrastColor(rs("prioritycolor"))%>">
		<TD align="center" style="width:60px">
		<INPUT type="button" style="height:30px;width:55px" value="View" <%if not isnull(rs("customersequencenumber")) then%>onclick="viewTask('<%=trim(rs("storeguid"))%>', <%=rs("customersequencenumber")%>, <%=rs("id")%>)"<%else%>onclick="viewTaskBrief(<%=rs("id")%>)"<%end if%>></TD>
		<TD><%=rs("customername")%>
		</TD>
		<TD>
		<%
		if len(rs("description")) > 20 then
			response.write left(rs("description"), 20) & "..."
		else
			response.write rs("description")
		end if
		%>
		</TD>
		<TD><%=rs("datecreated")%></TD>
		<TD></TD>
	</TR>

<%
		rs.movenext
	wend
	
	set rs = nothing
%>
	<TR align="left">
		<TH align="center" style="width:60px">&nbsp;</TH>
		<TH>From</TH>
		<TH>Subject</TH>
		<TH>Sent</TH>
		<TH>Received</TH>
	</TR>
<%
	query = "select messageitem.*, fromaccount.username as fromusername, toaccount.username as tousername "
	query = query & " from messageitem inner join messageaccount as fromaccount on messageitem.fromaccount = fromaccount.id "
	query = query & " inner join messageaccount as toaccount on messageitem.toaccount = toaccount.id "
	query = query & " where messageitem.toaccount = " & accountid & " and datediff(day, isnull(messageitem.datereceived, getdate()), getdate()) <= 30 order by messageitem.datesent desc"

	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
%>
		
	<TR <%if isnull(rs("datereceived")) then%>style="font-weight:bold"<%end if%>>
		<TD align="center" style="width:60px">
		<INPUT type="button" style="height:30px;width:55px" value="View" onclick="viewMessage(<%=rs("id")%>)"></TD>
		<TD><%=rs("fromusername")%></TD>
		
		<TD>
		<%
		if len(rs("messagetext")) > 20 then
			response.write left(rs("messagetext"), 20) & "..."
		else
			response.write rs("messagetext")
		end if
		%>
		</TD>
		<TD align="center"><%=rs("datesent")%></TD>
		<TD><%=rs("datereceived")%></TD>
	</TR>

<%
		rs.movenext
	wend
	
	set rs = nothing
%>

</TABLE>

</FORM>
</BODY>
</HTML>
