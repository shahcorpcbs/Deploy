<%@ Language=VBScript %>
<% Option Explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>


<HTML>
<HEAD>
<script language="javascript" type="text/javascript" src="/Script/printing.js"></script>
<TITLE>Print Invoice for Heat Seal</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">


    var processing = false;
	function checkEnter(event){
		var code = event.keyCode;
		if (code==13 && !processing) {
		    document.printHSInvForm.hsNo.disabled = true;
		    processing = true;
			printInvoice();
		}
	}

	function printInvoice() {
		var hsvalue = document.printHSInvForm.hsNo.value;

		if (hsvalue.trim() != '') {
            document.printHSInvForm.hsNo.value = "";
            CbsPrintForm(CbsForm.Detailed, CbsKey.HeatSealNumber, hsvalue);
            document.printHSInvForm.submit();
		}
	}

	function cancelForm() {
		document.printHSInvForm.action="toolsmenu.asp";
		document.printHSInvForm.submit();
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="document.printHSInvForm.hsNo.focus();">
<!-- #include file="../include/banner.inc" -->


<H1>Print Invoice for Heat Seal</H1>
	<FORM id="printHSInvForm" name="printHSInvForm" action="" method="post" onsubmit="return false">

	<TABLE ALIGN=center BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<tr height=100px align=center>
			<td>Please enter heat seal number: <input name="hsNo" value="" style="width:150px;font-size:24px" onkeyup="checkEnter(event);"></input></td>
		</tr>
		<tr align=center>
			<td><button style="width:100;height:50" onclick="printInvoice();" id=bttnPerformPrint name=bttnPerformPrint>Print</button></td>
		</tr>
		<tr height=300px valign=bottom>
			<td  align=center><INPUT class=touchnoBorder id=cancelButton name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
			</td>
		</tr>
		</table>
	</form>
</BODY>
</HTML>