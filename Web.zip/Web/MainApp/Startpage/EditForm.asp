<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../../include/querydatabase.asp" -->
<!-- #include file="../../include/ValidateFunction.asp" -->
<!--#include file="../../include/security.asp" -->


<%
	dim query, rs
	dim message
	dim formid
	dim formstring
	
	formid = getReqVar("formid")
	

	
	if lcase(Request.QueryString("useraction")) = "saveform" then
		saveForm formid
	else
		formstring = readform(formid)
	end if
	
	
	function ReadForm(formid)
		dim query, rs
		
		if formid <> "" then
			query = "select isnull(html, '') as html from startpageform where formid = " & formid

			set rs = getdisconnectedrecordset(query)
			
			ReadForm = rs("html")
	
			set rs = nothing
		end if
		
	end function
	
	function formExists(formid)
		dim query, rs
		
		if formid <> "" then
			query = "select count(*) as cnt from startpageform where formid = " & formid
			set rs = getdisconnectedrecordset(query)
			
			formExists = rs("cnt") > 0
			
			set rs = nothing
		else
			formExists = false
		end if
	end function
	
	sub saveForm(formid)
		dim query, rs
		
		if formExists(formid) then
			query = "update startpageform set "
			query = query & "StoreID = " & session("storeid") & ","
			query = query & "Name = " & DbCreateQryString(Request.Form("formname")) & ","
			query = query & "HTML = " & DbCreateQryString(Request.Form("htmldata")) & " "
			query = query & "where formid = " & formid
			
			message = "Form Updated"
		else
			query = "insert into startpageform (StoreID, Name, HTML) values "
			query = query & "(" & session("storeid") & ","
			query = query & DbCreateQryString(Request.Form("formname")) & ","
			query = query & DbCreateQryString(Request.Form("htmldata")) & ")"
			
			message = "Form Saved"
		end if
		
		qryexecute query
	end sub
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function


    function getFormName(formid)
		dim query, rs
		
		if formid <> "" then
			query = "select isnull(name, '') as name from startpageform where formid = " & formid
			set rs = getdisconnectedrecordset(query)
			
			getFormName = rs("name")
	
			set rs = nothing
		else
			getFormName = "New Alert"
		end if
		
    end function	
%>


<HTML>
<HEAD>




<link rel="stylesheet" type="text/css" href="/external/ext/resources/css/ext-all.css" />

<script type="text/javascript" src="/external/ext/adapter/ext/ext-base.js"></script>
<script type="text/javascript" src="/external/ext/ext-all.js"></script>


<script language="javascript" type="text/javascript">
	var htmlEditor;


	Ext.onReady(function(){

		Ext.QuickTips.init();
		
		htmlEditor = new Ext.form.HtmlEditor({
			width: 600,
			height: 500
		});
		htmlEditor.setValue(Ext.get('formcontents').dom.innerHTML);
		htmlEditor.render('editor');
	});

	function saveForm() {
		document.formeditor.htmldata.value = tinyMCE.getContent();

		document.formeditor.action = "?useraction=saveform";
		document.formeditor.submit();
	}
	
	
	function closeWindow() {
		window.close();
	}
	
	function finishForm() {
		opener.window.location.reload();
		window.close();
	}

</script>



</HEAD>


<BODY style="margin:0;padding:0;background:white" <%if message <> "" then%>onload="finishForm()"<%end if%>>
<%if message = "" then%>
<FORM id="formeditor" name="formeditor" method="post">

<INPUT type="hidden" name="formid" value="<%=formid%>">


<INPUT type="hidden" name="htmldata">

<table cellpadding="2" style="width=100%; background:lightgrey;">
	<tr><td style="font-size:12">
		Form Name:<input name="formname" style="width:300px" value="<%=getFormName(formid)%>">
		<input type="button" value="Save" onclick="saveForm();">
	</td></tr>
</table>



<div id="editor" name="editor" style="width:100%;height:500px"></div>
<div id="formcontents" name="formcontents" style="display:none"><%=formstring%></div>


</FORM>
<%end if%>
</BODY>
</HTML>
