<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../../include/querydatabase.asp" -->
<!--#include file="../../include/security.asp" -->

<%
	dim query, rs



%>


<HTML>
<HEAD>
<link href="../../script/stylesheet.css" rel="stylesheet" type="text/css">

<style type="text/css">

th {
    padding:3px;
    background:rgb(255,255,255);
    border-bottom:1px solid #CCC;
    font-weight:bold;
    color:#555555;
}

</style>

</HEAD>

<script language="javascript" type="text/javascript" src="/Script/printing.js"></script>

<script language="javascript" type="text/javascript">


	function SmartSearch(msg) {
		parent.Login("/mainapp/searchresults.asp?targetpage=CustomerFunctions&smartsearch=" + msg);

	}
	
	
</SCRIPT>

<BODY style="margin:0;padding:0;background:white">



<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" >

    <TR>
        <TH align="left">Date</TH>
        <TH style="width:120px;" align="center">Print</TH>
        <TH align="left">Employee</TH>
        <TH align="left">Action</TH>
        <TH align="left">Name</TH>
        <TH align="right">Amount</TH>
    </TR>
<%

	query = "SELECT TOP 25 tl.*, isnull(tl.payments, 0) as payments, "
	query = query & " c.customerName, "
	query = query & " t.invoiceNumber, "
	query = query & " tl.employeeName, "
	query = query & " dbo.getTicketLogTypeDescription(tl.logtype) as logtypeexpanded, "
	query = query & " (CASE t.invoicetype WHEN 'D' THEN 'Detailed' WHEN 'Q' THEN 'Quick' ELSE 'Unknown' END) as tickettypeexpanded "
	query = query & " FROM TicketLog tl INNER JOIN Ticket t on tl.ticketNumber = t.ticketNumber "
	query = query & " INNER JOIN Customer c ON t.customerSequenceNumber = c.customerSequenceNumber "
	query = query & " WHERE tl.logtype in ('E', 'F', 'C', 'P') "
	query = query & " AND DATEDIFF(DAY, tl.LogDate, GETDATE()) <= 3 "
	query = query & " ORDER BY tl.LogDate DESC "

	set rs = getdisconnectedrecordset(query)
	
		
	while not(rs.eof or rs.bof)
	
	%>
		<TR style="height:30px;background:white">
			<TD style="border-bottom:1px solid #EEE"><%=rs("logDate")%></TD>
			<TD style="width:120px;border-bottom:1px solid #EEE" align="center">
				<a href="javascript:window.parent.CbsPrintForm(CbsForm.Detailed, CbsKey.InvoiceNumber, <%=rs("invoiceNumber")%>)" style="border 1px solid #ccc;">Invoice</a>
				<a href="javascript:window.parent.CbsPrintForm(CbsForm.Tag, CbsKey.InvoiceNumber, <%=rs("invoiceNumber")%>)" style="border 1px solid #ccc;">Tags</a>
			</TD>
			<TD style="border-bottom:1px solid #EEE"><%=rs("employeeName")%></TD>
			<TD style="border-bottom:1px solid #EEE"><%=rs("logtypeexpanded") & " " & rs("tickettypeexpanded") & " (<A HREF=""javascript:SmartSearch(" & rs("invoiceNumber") & ")"">" & rs("invoiceNumber") & "</A>)" %></TD>
			<TD style="border-bottom:1px solid #EEE"><%= "<A HREF=""javascript:SmartSearch('" & rs("invoiceNumber") & "')"">" & rs("customerName") & "</A>"%></TD>
			<TD style="border-bottom:1px solid #EEE" align="right"><%=formatcurrency(rs("payments"))%></TD>

			
		</TR>		
	<%

	
		rs.movenext
	wend
%>
</TABLE>

</BODY>
</HTML>
