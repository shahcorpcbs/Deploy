<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../../include/querydatabase.asp" -->
<!--#include file="../../include/security.asp" -->

<%
	dim query, rs
	dim routeVersion
	
	routeVersion = Request.QueryString("routeVersion")
	
	select case lcase(request.querystring("useraction"))
	case "deleteform"
		deleteForm
	
	end select


	function deleteForm()
		dim query
		
		query = "delete startpageform where formid = " & request.querystring("formid")
	
		qryexecute(query)
		
	end function

%>


<HTML>
<HEAD>
<STYLE  type="text/css" >
 BODY {font-family: "Arial"}
 </STYLE>
</HEAD>



<script language="javascript" type="text/javascript">
	function Login(url, rc) {
		parent.Login(url, rc);
	}
</SCRIPT>

<BODY style="margin:0;padding:0;background:white" <%if request.querystring("useraction") = "deleteform" then%>onload="parent.location.reload()"<%end if%>>



<TABLE align="center" width="100%" height="100%" border="0" cellspacing="0" cellpadding="0" style="background:white">

<TR><TD ALIGN="CENTER">
<% if routeVersion = 1 then %>
<A style="text-decoration:none;color:black" HREF="javascript:Login('/mainapp/routesMenu.asp')"><IMG style="border:none" SRC="/static/images/start_routes.jpg"><BR><B>Routes</B></A>
<% else %>
<A style="text-decoration:none;color:black" HREF="javascript:Login('/mainapp/deliveryManager.asp')"><IMG style="border:none" SRC="/static/images/start_routes.jpg"><BR><B>Routes</B></A>
<% end if %>
</TD><TD ALIGN="CENTER">
<A style="text-decoration:none;color:black" HREF="javascript:Login('/mainapp/toolsMenu.asp')"><IMG style="border:none" SRC="/static/images/start_tools.jpg"><BR><B>Tools</B></A>
</TD></TR>


<TR><TD ALIGN="CENTER">
<A style="text-decoration:none;color:black" HREF="javascript:Login('/mainapp/countersale.asp?useraction=create')"><IMG style="border:none" SRC="/static/images/start_countersales.jpg"><BR><B>Retail Sales</B></A>
</TD><TD ALIGN="CENTER">
<A style="text-decoration:none;color:black" HREF="javascript:Login('/mainapp/employeemenu.asp', false)"><IMG style="border:none" SRC="/static/images/start_employee.jpg"><BR><B>Employee</B></A>
</TD></TR>


</TABLE>

</BODY>
</HTML>
