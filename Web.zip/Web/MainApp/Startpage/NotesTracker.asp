<%@ Language=VBScript %>

<!--#include file="../../include/QueryDatabase.asp"-->
<%

	dim startdate
	dim showunracked
	dim showticketnotes
	
	startdate = getReqVar("startdate")
	showunracked = getReqVar("showunracked")
	showticketnotes = getReqVar("showticketnotes")

	
	if startdate = "" then
		startdate = Date()
		showunracked = "show"
		showticketnotes = "show"
	end if
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	function getResultsRecordset(showunracked, showticketnotes)
		dim query, rs

		query = " select distinct ticket.ticketnumber, ticket.invoicenumber, customer.customername,"
		query = query & " dbo.pivotTicketRackLocationBrief(ticket.ticketnumber, ', ') as racklocation,"
		query = query & " dbo.pivotTicketDepartments(ticket.ticketnumber, ', ') as departments,"
		query = query & " isnull(ticketlineitem.itemnotes, isnull(customer.invoicenotes, '')) as notes"
		query = query & " from ticket inner join ticketlineitem on"
		query = query & " ticket.ticketnumber = ticketlineitem.ticketnumber"
		query = query & " inner join customer on ticket.customersequencenumber = customer.customersequencenumber"
		query = query & " where ticket.ticketstatus = 'AC'"
		query = query & " and (ticketlineitem.itemnotes is not null or customer.invoicenotes is not null)"		
		query = query & " and datediff(d, '" & startdate & "', ticket.duedate) >= 0"

		if showunracked then
			query = query & " and dbo.pivotTicketRackLocationBrief(ticket.ticketnumber, ', ') =''"
		end if		
		
		query = query & " order by departments"
		set getResultsRecordset = getdisconnectedrecordset(query)
	end function
%>


<HTML>
<HEAD>

<link href="../../script/stylesheet.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../../script/date-picker2.js"></script>

<style type="text/css">

th {
    padding:3px;
    background:rgb(255,255,255);
    border-bottom:1px solid #CCC;
    font-weight:bold;
    color:#555555;
}

</style>

<script language="JScript" src="../../External/jquery.js"></script>
<script language="javascript" type="text/javascript">
	function submitForm() {
	    var show = "noshow";
	    if ($('#showunracked').is(":checked"))
	        show = "show";
		document.notestracker.action = "?startdate=" +  $('#startdate').val() + "&showunracked=" + show;
		document.notestracker.submit();
	}
	
	function SmartSearch(msg) {
		parent.location.href ="/mainapp/login.asp?target=/mainapp/searchresults.asp&targetpage=CustomerFunctions&smartsearch=" + msg;

	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0;background:white" onload="">

<FORM id="notestracker" name="notestracker" method="post" style="margin:0;padding:0">


<TABLE style="background:white;width:100%;">
	<TR>
		<TD>
			<INPUT id="showunracked" name="showunracked" type="checkbox" value="show" <%if showunracked = "show" then%>checked<%end if%>>
			Invoices Not Racked 
		</TD>
		<TD>
			Due After
			<INPUT style="width:80px;text-align:center" id="startdate" name="startdate" value="<%=startdate%>" onclick="javascript:show_calendar('notestracker.startdate');">
			<INPUT type="button" value="Search" onclick="submitForm()">
		</TD>
	</TR>
</TABLE>
</TD><TD>


<TABLE cellspacing="0" cellpadding="0" style="width:100%">
	<TR>
		<TH style="width:100px">Invoice Number</TH>
		<TH>Customer</TH>
		<TH>Rack Number</TH>
		<TH style="width:120px">Department</TH>
		<TH style="width:300px">Note</TH>
	</TR>


<%
	dim row
	
	set row = getResultsRecordset(showunracked = "show", showticketnotes = "show")
	
	while not (row.eof or row.bof)
%>
	<TR style="height:30px;background:white">
		<TD style="border-bottom:1px solid #EEE" align="center"><a href="javascript:SmartSearch('<%=row("invoicenumber")%>')" style="border 1px solid #ccc;"><%=row("invoicenumber")%></a></TD>
		<TD style="border-bottom:1px solid #EEE" align="center"><a href="javascript:SmartSearch('<%=row("invoicenumber")%>')" style="border 1px solid #ccc;"><%=row("customername")%></a></TD>
		<TD style="border-bottom:1px solid #EEE" align="center"><%=row("racklocation")%>&nbsp;</TD>
		<TD style="border-bottom:1px solid #EEE" style="width:120px" align="center"><%=row("departments")%></TD>
		<TD style="border-bottom:1px solid #EEE" align="left"><%=row("notes")%></TD>
	</TR>
<%
		row.movenext
	wend
	
	set row = nothing
%>

</TABLE>

</FORM>
</BODY>
</HTML>
