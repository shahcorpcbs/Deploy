<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../../include/querydatabase.asp" -->
<!--#include file="../../include/security.asp" -->

<%
	dim teststring
	dim formstring
	const varprefix = "##"
	const varsuffix = "##"
	
	class Callback
		dim func
		dim iscached
		dim cache
	end class


	dim callbacks
	set callbacks = CreateObject("Scripting.Dictionary")

	dim query, rs


	InitCallbacks

	formstring = ReadForm(Request.QueryString("formid"))
	
	function ReadForm(formid)
		dim query, rs
		
		query = "select isnull(html, '') as html from startpageform where formid = " & formid 
		set rs = getdisconnectedrecordset(query)
		
		ReadForm = rs("html")
		
		set rs = nothing
	end function

	function GetTestString()
		dim item
		dim teststring
		
		teststring = "<table border=""0"" cellspacing=""0"" cellpadding=""0"">" & vbcrlf
		
		for each item in callbacks.Keys()
			teststring = teststring & "    <tr><td>" & item & "</td><td align=""right"">" & varprefix & item & varsuffix & "</td></tr>" & vbcrlf
		next
	
		teststring = teststring & "</table>"
		GetTestString = teststring
	end function
	





	function GetNumberOfVisits()
		dim query, rs
		
		query = "select count(*) as cnt from ticket "
		query = query & " where convert(varchar, statuschangedate, 101) = convert(varchar, getdate(), 101) "
		query = query & " and ticketstatus in ('FI', 'AC') "
		
		
		set rs = getdisconnectedrecordset(query)
		
		GetNumberOfVisits = rs("cnt")
		
		set rs = nothing
	end function
	
	
	function GetNumberNewCustomers()
		dim query, rs
		
		query = "select count(*) as cnt from customer "
		query = query & " where convert(varchar, createddate, 101) = convert(varchar, getdate(), 101) "
		
		set rs = getdisconnectedrecordset(query)
		
		GetNumberNewCustomers = rs("cnt")
		
		set rs = nothing
	end function
	
	
	function GetNumberOfPieces()
		dim query, rs
		
		query = "select isnull(sum(tli.quantity * tli.packagedQuantity), 0) as cnt from ticket t, ticketlineitem tli "
		query = query & " where convert(varchar, t.createddate, 101) = convert(varchar, getdate(), 101) "
		query = query & " and tli.ticketnumber = t.ticketnumber " 
		query = query & " and tli.ticketlinetype in ('IT', 'AC') "
		
		set rs = getdisconnectedrecordset(query)
		
		GetNumberOfPieces = rs("cnt")
		
		set rs = nothing
	end function

	function GetTotalAmount()
		dim query, rs
		
		query = "select isnull(sum(invoiceTotal), 0) as cnt from ticket "
		query = query & " where convert(varchar, createddate, 101) = convert(varchar, getdate(), 101) "
		
		set rs = getdisconnectedrecordset(query)
		
		GetTotalAmount = formatnumber(rs("cnt"), 2)
		
		set rs = nothing
	end function

	function GetPiecesPerVisit()
		if cdbl(executeCallback("NumberOfVisits")) > 0 then
			GetPiecesPerVisit = cdbl(executeCallback("NumberOfPieces")) / cdbl(executeCallback("NumberOfVisits"))
		else
			GetPiecesPerVisit = "0"
		end if
		
		GetPiecesPerVisit = formatnumber(GetPiecesPerVisit, 1)
	end function
	
	function GetAmountPerVisit()
		if cdbl(executeCallback("NumberOfVisits")) > 0 then
			GetAmountPerVisit = cdbl(executeCallback("TotalAmount")) / cdbl(executeCallback("NumberOfVisits"))
		else
			GetAmountPerVisit = 0
		end if
		
		GetAmountPerVisit = formatnumber(GetAmountPerVisit, 1)
	end function


	function GetUpchargePercent()
		if cdbl(executeCallback("TotalAmount")) > 0 then
			GetUpchargePercent = 100 * (cdbl(executeCallback("UpchargeTotal")) / cdbl(executeCallback("TotalAmount")))
		else
			GetUpchargePercent = 0
		end if
		
		GetUpchargePercent = formatnumber(GetUpchargePercent, 1)
	end function
	
	function GetDiscountPercent()
		if cdbl(executeCallback("TotalAmount")) + cdbl(executeCallback("DiscountTotal")) > 0 then
			GetDiscountPercent = 100 * (cdbl(executeCallback("DiscountTotal")) / (cdbl(executeCallback("TotalAmount")) + cdbl(executeCallback("DiscountTotal"))))
		else
			GetDiscountPercent = 0
		end if
		
		GetDiscountPercent = formatnumber(GetDiscountPercent, 1)
	end function


	function GetDiscountTotal()
		dim query, rs
		
		query = "select isnull(sum(tli.lineItemTotal), 0) as cnt from ticket t, ticketlineitem tli "
		query = query & " where convert(varchar, t.createddate, 101) = convert(varchar, getdate(), 101) "
		query = query & " and tli.ticketnumber = t.ticketnumber " 
		query = query & " and tli.ticketlinetype in ('CU', 'PR') "
		
		set rs = getdisconnectedrecordset(query)
		
		GetDiscountTotal = formatnumber(rs("cnt"), 2)
		
		set rs = nothing
	end function
	

	function GetUpchargeTotal()
		dim query, rs
		
		query = "select isnull(sum(tli.lineItemTotal), 0) as cnt from ticket t, ticketlineitem tli "
		query = query & " where convert(varchar, t.createddate, 101) = convert(varchar, getdate(), 101) "
		query = query & " and tli.ticketnumber = t.ticketnumber " 
		query = query & " and tli.ticketlinetype in ('CO', 'PA', 'UP') "
		
		set rs = getdisconnectedrecordset(query)
		
		GetUpchargeTotal = formatnumber(rs("cnt"), 2)
		
		set rs = nothing
	end function
	
	
	
	
	function GetNumberVoids()
		dim query, rs
		
		query = "select count(*) as cnt from ticket "
		query = query & " where convert(varchar, statuschangedate, 101) = convert(varchar, getdate(), 101) "
		query = query & " and ticketstatus = 'VO' "
		
		
		set rs = getdisconnectedrecordset(query)
		
		GetNumberVoids = rs("cnt")
		
		set rs = nothing
	end function




	function GetPaymentsType(paymentTypeName)
		dim query, rs
		
		query = "select isnull(sum(amountPaid), 0) as cnt from payment "
		query = query & " where convert(varchar, paymentDate, 101) = convert(varchar, getdate(), 101) "
		query = query & " and paymentTypeName = '" & paymentTypeName & "' "
		
		
		set rs = getdisconnectedrecordset(query)
		
		GetPaymentsType = rs("cnt")
		
		set rs = nothing
	end function


	function GetPaymentsCash()
		GetPaymentsCash = formatnumber(GetPaymentsType("Cash"), 2)
	end function
	
	function GetPaymentsCheck()
		GetPaymentsCheck = formatnumber(GetPaymentsType("Check"), 2)
	end function
	
	function GetPaymentsCreditCard()
		GetPaymentsCreditCard = formatnumber(GetPaymentsType("Credit Card"), 2)
	end function

	
	function GetPaymentsOther()
		dim query, rs
		
		query = "select isnull(sum(amountPaid), 0) as cnt from payment "
		query = query & " where convert(varchar, paymentDate, 101) = convert(varchar, getdate(), 101) "
		query = query & " and paymentTypeName in ('Trade', 'Coupon Payment', 'Gift Certificate', 'GiftCard', 'On Account')"
		
		
		set rs = getdisconnectedrecordset(query)
		
		GetPaymentsOther = formatnumber(rs("cnt"), 2)
		
		set rs = nothing
	end function
	
	function GetPaymentsTotal()
		GetPaymentsTotal = executeCallback("GetPaymentsOther")
		GetPaymentsTotal = GetPaymentsTotal + executeCallback("GetPaymentsCreditCard")
		GetPaymentsTotal = GetPaymentsTotal + executeCallback("GetPaymentsCheck")
		GetPaymentsTotal = GetPaymentsTotal + executeCallback("GetPaymentsCash")
		GetPaymentsTotal = formatnumber(GetPaymentsTotal, 2)
	end function

	function GetOverdueInvoices()
		dim query, rs
		dim range_min, range_max
		dim catagories
		dim idx
		dim result
		dim counter
		dim value
		
		query = "SELECT inValue, departmentname, SUM(departmenttotal) AS departmenttotal, COUNT(*) AS departmentinvoicetotal "
		query = query & " FROM (SELECT datediff(wk, getdate(), Ticket.dueDate) AS inValue, department.name AS departmentname, SUM(isnull(quantity, 1) * isnull(packagedquantity, 1)) AS departmenttotal "
		query = query & " FROM ticket INNER JOIN "
		query = query & " ticketlineitem ON ticket.ticketnumber = ticketlineitem.ticketnumber INNER JOIN "
		query = query & " pricelist ON ticket.pricelistid = pricelist.pricelistid INNER JOIN "
		query = query & " department ON ticketlineitem.departmentid = department.departmentid "
		query = query & " WHERE department.storeid = 1 AND ticket.ticketstatus = 'AC' AND ticketlineitem.ticketLineType IN ('IT', 'AC') "
		query = query & " GROUP BY Department.name, datediff(wk, getdate(), Ticket.dueDate), Ticket.invoiceNumber) a "
		query = query & " GROUP BY departmentname, inValue "
		query = query & " ORDER BY departmentname, CAST(inValue AS int) "
		
		range_min = -16
		range_max = 2

		set rs = getdisconnectedrecordset(query)
		
		
		while not(rs.eof or rs.bof)
			if clng(rs("invalue")) < clng(range_min) then
				range_min = rs("invalue")
			end if
			
			if clng(rs("invalue")) > clng(range_max) then
				range_max = rs("invalue")
			end if

			rs.movenext
		wend
		
		if range_min < -52 then range_min = -52
		if range_max > 8 then range_max = 8
		
		result = "<div id='vertgraph'><ul>"
		
		counter = 0
		for idx = range_min to range_max
			rs.filter = "invalue = " & idx
			value = 0
			while not(rs.eof or rs.bof)
				value = value + rs("departmenttotal")
				rs.movenext
			wend
			if idx = 0 then
				result = result & "<li style='bottom:1px;background:black;border:none;width:3px;left:" & counter + 2 & "px; height:100%';'></li>"
				counter = counter + 7
			elseif idx mod 4 = 0 then
				result = result & "<li style='bottom:5px;background:#aaa;border:none;width:1px;left:" & counter + 1 & "px; height:16px';'></li>"
				counter = counter + 4
			end if
			
			result = result & "<li style='left:" & counter & "px; height:" & 1 + value & "px';' onclick='alert(""TODO"")'></li>"

			counter = counter + 7
		next

		result = result & "</ul></div>"

		GetOverdueInvoices = result
	end function

	function GetPiecesNotRacked()
		dim query, rs
		dim result
		dim departmentname
		dim keepgoing
		dim rowmax
		dim rowinvoicemax
		dim totalInvoices(4)
		dim totalPieces(4)
		dim grandTotalInvoices
		dim grandTotalPieces
		dim idx
		
		query = "select a.inValue, a.departmentname, sum(a.departmenttotal) as departmenttotal, count(*) as departmentinvoicetotal "
		query = query & " from "
		query = query & "(select Timerange.inValue, department.name as departmentname, sum(isnull(quantity, 1) * isnull(packagedquantity, 1)) as departmenttotal"
		query = query & " from ticket inner join ticketlineitem on ticket.ticketnumber = ticketlineitem.ticketnumber "
		query = query & " inner join pricelist on ticket.pricelistid = pricelist.pricelistid "
		query = query & " inner join department on ticketlineitem.departmentid = department.departmentid "
		query = query & " inner join dbo.unPivotInClause('0,1,3,31') as Timerange on datediff(d, getdate(), Ticket.dueDate) <= Timerange.inValue "
		query = query & " where department.storeid = " & session("storeid")
		query = query & " and ticket.ticketstatus = 'AC' and ticketlineitem.ticketLineType IN ('IT', 'AC') "
		query = query & " and dbo.pivotTicketRackLocationBrief(ticket.ticketnumber, '') = ''"
		query = query & " GROUP BY Department.name, Timerange.inValue, Ticket.invoiceNumber "
		query = query & " ) a "
		query = query & " GROUP BY a.departmentname, a.inValue "
		query = query & " ORDER BY a.departmentname, cast(a.inValue as int)"

		set rs = getdisconnectedrecordset(query)
		
		result = "<TABLE style=""width:100%"">"
		result = result & "<TR>"
		result = result & "<TH align=""left"">Department</TH>"
		result = result & "<TH align=""left"">Today</TH>"
		result = result & "<TH align=""left"">Tomorrow</TH>"
		result = result & "<TH align=""left"">3 Day</TH>"
		result = result & "<TH align=""left"">Remaining</TH>"
		result = result & "<TH align=""left"">Totals</TH>"
		result = result & "</TR>"

		while not(rs.eof or rs.bof)

			departmentname = rs("departmentname")

			result = result & "<TR style=""cursor:hand"" onclick=""javascript:gotoDepartmentNotRacked('" & rs("departmentname") & "')"">"
			result = result & "<TD>" & rs("departmentname") & "</TD>"

			keepgoing = not(rs.eof or rs.bof)
			if keepgoing then keepgoing = (departmentname = rs("departmentname"))

			rowmax = 0
			rowinvoicemax = 0
			idx = 0
			
			while keepgoing
				if rs("departmentinvoicetotal") - rowinvoicemax  <> 0 then
					result = result & "<TD>" & rs("departmentinvoicetotal") - rowinvoicemax & " (" & rs("departmenttotal") - rowmax & ")</TD>"
					totalInvoices(idx) = totalInvoices(idx) + rs("departmentinvoicetotal") - rowinvoicemax
					totalPieces(idx) = totalPieces(idx) + rs("departmenttotal") - rowmax
					grandTotalInvoices = grandTotalInvoices + rs("departmentinvoicetotal") - rowinvoicemax
					grandTotalPieces = grandTotalPieces + rs("departmenttotal") - rowmax
				else
					result = result & "<TD>-</TD>"
				end if
				
				rowmax = rs("departmenttotal")
				rowinvoicemax = rs("departmentinvoicetotal")
				
				rs.movenext
				idx = idx + 1
				keepgoing = not(rs.eof or rs.bof)
				if keepgoing then keepgoing = (departmentname = rs("departmentname"))
			wend
			while idx < 4
				result = result & "<TD>-</TD>"
				idx = idx + 1
			wend
			result = result & "<TD style=""font-weight:bold"">" & rowinvoicemax & "(" & rowmax & ")</TD>"
			result = result & "</TR>"
		wend

		result = result & "<TR style=""font-weight:bold"">"
		result = result & "<TD>Totals</TD>"
		for idx = 0 to 3
			result = result & "<TD>" & totalInvoices(idx) & "(" & totalPieces(idx) & ")</TD>"
		next
		result = result & "<TD>" & grandTotalInvoices & "(" & grandTotalPieces & ")</TD>"
		result = result & "</TR>"
		
		result = result & "</TABLE>"
		
		GetPiecesNotRacked = result
		
		set rs = nothing
	end function




	function GetTodaysCustomers()
		dim query, rs
		dim result
		
		query = " select customer.customername, dbo.formatPhone(mainareacode, mainphone) as [phone], "
		query = query & " isnull(customer.email, '') as [email], employee.employeename "
		query = query & " from customer "
		query = query & " inner join (select distinct customersequencenumber, createdbyemployeeid from ticket where datediff(day, ticket.createddate, getdate()) = 0) as customerEmp "
		query = query & " on customer.customersequencenumber = customerEmp.customersequencenumber "
		query = query & " inner join employee on employee.employeeid = customerEmp.createdbyemployeeid "
		
		
		set rs = getdisconnectedrecordset(query)
		
		result = "<TABLE style=""width:100%"">"
		result = result & "<TR>"
			result = result & "<TH align=""left"">Customer Name</TH>"
			result = result & "<TH align=""left"">Phone</TH>"
			result = result & "<TH align=""left"">Email</TH>"
			result = result & "<TH align=""left"">Employee Name</TH>"
		result = result & "</TR>"
		
		while not(rs.eof or rs.bof)
			result = result & "<TR>"
			result = result & "<TD>" & server.htmlencode(trim(rs("customername"))) & "</TD>"
			result = result & "<TD>" & server.htmlencode(rs("phone")) & "</TD>"
			result = result & "<TD>" & server.htmlencode(rs("email")) & "</TD>"
			result = result & "<TD>" & server.htmlencode(trim(rs("employeename"))) & "</TD>"
			result = result & "</TR>"
			rs.movenext
		wend
		
		result = result & "</TABLE>"

					
		GetTodaysCustomers = result
		
		set rs = nothing
	end function

	function GetYesterdaysCustomers()
		dim query, rs
		dim result
		
		query = " select customer.customername, dbo.formatPhone(mainareacode, mainphone) as [phone], "
		query = query & " isnull(customer.email, '') as [email], employee.employeename "
		query = query & " from customer "
		query = query & " inner join (select distinct customersequencenumber, createdbyemployeeid from ticket where datediff(day, ticket.createddate, getdate()) = 1) as customerEmp "
		query = query & " on customer.customersequencenumber = customerEmp.customersequencenumber "
		query = query & " inner join employee on employee.employeeid = customerEmp.createdbyemployeeid "
		
		
		set rs = getdisconnectedrecordset(query)
		
		result = "<TABLE style=""width:100%"">"
		result = result & "<TR>"
			result = result & "<TH align=""left"">Customer Name</TH>"
			result = result & "<TH align=""left"">Phone</TH>"
			result = result & "<TH align=""left"">Email</TH>"
			result = result & "<TH align=""left"">Employee Name</TH>"
		result = result & "</TR>"
		
		while not(rs.eof or rs.bof)
			result = result & "<TR>"
			result = result & "<TD>" & server.htmlencode(trim(rs("customername"))) & "</TD>"
			result = result & "<TD>" & server.htmlencode(rs("phone")) & "</TD>"
			result = result & "<TD>" & server.htmlencode(rs("email")) & "</TD>"
			result = result & "<TD>" & server.htmlencode(trim(rs("employeename"))) & "</TD>"
			result = result & "</TR>"
			rs.movenext
		wend
		
		result = result & "</TABLE>"

					
		GetYesterdaysCustomers = result
		
		set rs = nothing
	end function
	
	function GetPiecesNotRackedH()
		dim query, rs
		dim result

		dim firstrow
		dim secondrow
		
		query = "select a.departmentname, sum(a.departmenttotal) as departmenttotal, count(*) as departmentinvoicetotal "
		query = query & " from "
		query = query & "(select department.name as departmentname, sum(isnull(quantity, 1) * isnull(packagedquantity, 1)) as departmenttotal"
		query = query & " from ticket inner join ticketlineitem on ticket.ticketnumber = ticketlineitem.ticketnumber "
		query = query & " inner join pricelist on ticket.pricelistid = pricelist.pricelistid "
		query = query & " inner join department on ticketlineitem.departmentid = department.departmentid "
		query = query & " where department.storeid = " & session("storeid")
		query = query & " and ticket.ticketstatus = 'AC' and ticketlineitem.ticketLineType IN ('IT', 'AC') "
		query = query & " and dbo.pivotTicketRackLocationBrief(ticket.ticketnumber, '') = ''"
		query = query & " GROUP BY department.name, ticket.ticketnumber "
		query = query & " ) a "
		query = query & " GROUP BY a.departmentname "
		query = query & " ORDER BY a.departmentname "
		
		set rs = getdisconnectedrecordset(query)
		

		while not(rs.eof or rs.bof)
			firstrow = firstrow & "<TH style=""text-align:center;cursor:hand"" onclick=""javascript:gotoDepartmentNotRacked('" & rs("departmentname") & "')"">" & rs("departmentname") & "</TH>"
			secondrow = secondrow & "<TD style=""text-align:center;cursor:hand"" onclick=""javascript:gotoDepartmentNotRacked('" & rs("departmentname") & "')"">" & rs("departmentinvoicetotal") & " (" & rs("departmenttotal") & ")</TD>"

			rs.movenext
		wend
		
		result = "<TABLE class=""itable"" style=""width:100%"">"
		result = result & "<TR>" & firstrow & "</TR>"
		result = result & "<TR>" & secondrow & "</TR>"
		result = result & "</TABLE>"
					
		GetPiecesNotRackedH = result
		
		set rs = nothing
	end function




	function GetPiecesReady()
		dim query, rs

		query = "select department.name as departmentname, sum(isnull(quantity, 1) * isnull(packagedquantity, 1)) as departmenttotal "
		query = query & " from ticket inner join ticketlineitem on ticket.ticketnumber = ticketlineitem.ticketnumber "
		query = query & " inner join dbo.unPivotInClause('0,1,3,31') as Timerange on datediff(d, getdate(), ticket.dueDate) <= Timerange.inValue "
		query = query & " where ticket.ticketstatus = 'AC' and ticketlineitem.ticketLineType IN ('IT', 'AC') "


		set rs = nothing
	end function




	sub InitCallbacks()
		addCallback "NumberOfVisits", getref("GetNumberOfVisits")
		addCallback "NumberNewCustomers", getref("GetNumberNewCustomers")
		addCallback "NumberOfPieces", getref("GetNumberOfPieces")
		addCallback "TotalAmount", getref("GetTotalAmount")
		addCallback "PiecesPerVisit", getref("GetPiecesPerVisit")
		addCallback "AmountPerVisit", getref("GetAmountPerVisit")
		addCallback "UpchargePercent", getref("GetUpchargePercent")
		addCallback "DiscountPercent", getref("GetDiscountPercent")
		addCallback "DiscountTotal", getref("GetDiscountTotal")
		addCallback "UpchargeTotal", getref("GetUpchargeTotal")
		addCallback "NumberVoids", getref("GetNumberVoids")
		addCallback "PaymentsCash", getref("GetPaymentsCash")
		addCallback "PaymentsCheck", getref("GetPaymentsCheck")
		addCallback "PaymentsCreditCard", getref("GetPaymentsCreditCard")
		addCallback "PaymentsOther", getref("GetPaymentsOther")
		addCallback "PaymentsTotal", getref("GetPaymentsTotal")
		addCallback "PiecesNotRackedH", getref("GetPiecesNotRackedH")
		addCallback "PiecesNotRacked", getref("GetPiecesNotRacked")
		addCallback "PiecesReady", getref("GetPiecesReady")
		addCallback "OverdueInvoices", getref("GetOverdueInvoices")
		addCallback "TodaysCustomers", getref("GetTodaysCustomers")
		addCallback "YesterdaysCustomers", getref("GetYesterdaysCustomers")
		
	end sub



	function TranslateString(str)
		dim lhs, rhs
		dim result
		dim callback
		
		lhs = instr(1, str, varprefix, 1)

		if lhs > 0 then
			rhs = instr(lhs + len(varprefix), str, varsuffix, 1)

			callback = mid(str, lhs + len(varprefix), rhs - lhs - len(varprefix))

			TranslateString = left(str, lhs - 1) & executeCallback(callback) &  TranslateString(right(str, len(str) - rhs - 1))
		else
			TranslateString = str
		end if

	end function
	
	
	sub addCallback(name, func)
		dim newCallback
		set newCallback = new Callback

		set newCallback.func = func
		newCallback.cache = ""

		callbacks.Add name, newCallback
	end sub


	function executeCallback(name)
		dim callback

		if callbacks.exists(name) then
			set callback = callbacks.Item(name)

			if not callback.iscached then
				callback.cache = callback.func()
				callback.iscached = true
			end if
			
			executeCallback = callback.cache
			callbacks.Remove name
			callbacks.Add name, callback
		end if

	end function



%>


<HTML>
<HEAD>

<script language="javascript" type="text/javascript">

	function gotoDepartmentNotRacked(departmentname) {
		location.href = "../../Mainapp/invoiceSearchResults.asp?type=departmentnotracked&value=" + escape(departmentname)
	}
</script>

<style>
    #vertgraph {    				

        height: 100px; 
        position: relative; 
    }
    #vertgraph ul { 

        margin: 0; 
        padding: 0; 
    }
    #vertgraph ul li {  
        position: absolute; 
        width: 6px; 
        height: 160px; 
        bottom: 10px; 
        padding: 0 !important; 
        margin: 0 !important; 
        background: #e00;
		font-size:0;

        border:1px solid #800;

    }

</style>

</HEAD>

<BODY style="margin:0;padding:0;">

<%Response.Write TranslateString(formstring)%>
</BODY>
</HTML>
