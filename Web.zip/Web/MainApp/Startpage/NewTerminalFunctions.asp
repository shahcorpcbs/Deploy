<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../../include/querydatabase.asp" -->
<!--#include file="../../include/security.asp" -->
<!--#include file="../../include/LicenseCheck.asp" -->
<!--#include file="../../include/services.asp" -->

<%
	dim routeVersion
	
	routeVersion = Request.QueryString("routeVersion")
	
	select case lcase(request.querystring("useraction"))
	case "deleteform"
		deleteForm
	
	end select


	function deleteForm()
		dim query
		
		query = "delete startpageform where formid = " & request.querystring("formid")
	
		qryexecute(query)
		
	end function

%>


<HTML>
<HEAD>
<STYLE  type="text/css" >
 BODY {font-family: "Arial"}
 </STYLE>
<script type="text/javascript" src="../../Script/webui.js"></script>
 <script language="javascript" type="text/javascript">
 	function Login(url, rc) {
 		parent.Login(url, rc);
 	}

 document.addEventListener("click", (e) => {
 console.log("!!!!!")
 parent.setSearchFocus();
 window.parent.document.getElementById("smartQuery").focus();
 });

 </SCRIPT>
</HEAD>




<BODY style="margin:0;padding:0;background:white;margin-top:-25px" <%if request.querystring("useraction") = "deleteform" then%>onload="parent.location.reload()"<%end if%>>



<TABLE align="center" STYLE="width:100%;border-spacing:25px">

<TR><TD ALIGN="CENTER" style="border:solid; border-radius: 25px; width:50%">
<% if routeVersion = 1 then %>
<A style="text-decoration:none;color:black; width:100%;display:block;padding:10px" HREF="javascript:Login('/mainapp/routesMenu.asp')"><IMG style="border:none" SRC="/images/<%=routeIconPath%>"><BR><B>Routes</B></A>
<% else %>
<A style="text-decoration:none;color:black; width:100%;display:block;padding:10px" HREF="javascript:Login('/mainapp/deliveryManager.asp')"><IMG style="border:none" SRC="/images/<%=routeIconPath%>"><BR><B>Routes</B></A>
<% end if %>
</TD><TD ALIGN="CENTER" style="border:solid; border-radius: 25px;  width:50%">
<A style="text-decoration:none;color:black; width:100%;display:block;padding:10px" HREF="javascript:Login('/mainapp/toolsMenu.asp')"><IMG style="border:none" SRC="/images/<%=toolsIconPath%>"><BR><B>Tools</B></A>
</TD></TR>
<TR><TD ALIGN="CENTER" style="border:solid; border-radius: 25px;">
<A style="text-decoration:none;color:black;width:100%;display:block;padding:10px" HREF="javascript:Login('/mainapp/countersale.asp?useraction=create')"><IMG style="border:none" SRC="/images/<%=retailIconPath%>"><BR><B>Retail Sales</B></A>
</TD><TD ALIGN="CENTER" style="border:solid; border-radius: 25px;">
<A style="text-decoration:none;color:black;width:100%;display:block;padding:10px" HREF="javascript:Login('/mainapp/employeemenu.asp', false)"><IMG style="border:none" SRC="/images/<%=empIconPath%>"><BR><B>Employee</B></A>
</TD></TR>


</TABLE>

</BODY>
</HTML>
