<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<HTML>
<HEAD>
<TITLE>Gift Card Maintenance</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		document.maintGiftCardForm.submit();
	}
	
	function cancelForm() {
		document.maintGiftCardForm.action="giftCardProgram.asp";
		document.maintGiftCardForm.submit()
	}	
	
	function addValueGift() {
		document.maintGiftCardForm.action ="addValue.asp";
		document.maintGiftCardForm.submit();
	}
	
	function mergeAccountsGift() {
		document.maintGiftCardForm.action ="mergeAccounts.asp";
		document.maintGiftCardForm.submit();
	}
	

		
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Gift Card Maintenance</H1>
<FORM id="maintGiftCardForm" name="maintGiftCardForm" action="start2.asp" method="Post">'
<TABLE ALIGN=CENTER WIDTH=350px BORDER=1 CELLSPACING=0 CELLPADDING=10>
	<TR><TD>
	<TABLE ALIGN=center WIDTH=100% BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<TR height=60px></TR>	
		<TR height=100px>
			<TD align=center>
				<INPUT class=click id=addValue name=addValue style="" type=button value="Add Value" onClick="addValueGift()">
			</TD>
		</TR>
		</TR>	
			<TD align=center>
				<INPUT class=click id=mergeAccounts name=mergeAccounts type=button  style="" value="Merge Gift Card Accounts" onClick="mergeAccountsGift()">
			</TD>
		</TR>

		<TR height=60px></TR>	
		<TR >
			<TD colspan = 2 ALIGN=center>
				<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
			</TD>	
		</TR>			
	</TABLE>
	</TD></TR>
</TABLE>	
</FORM>   

</BODY>
</HTML>