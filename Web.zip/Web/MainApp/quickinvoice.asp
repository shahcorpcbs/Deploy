<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	const maxDeptCount =4
	dim actionString
	dim invoice
	dim custSeqNumber
	dim customerName, custPhone, custPriceList
	dim storeId
	dim selDept
	dim isDueDateSet
	dim invoiceNumber
	dim addOrEdit
	dim Inv_submit
	dim inv_onHold
	dim deptStartIndex
	dim ObjMiscSetUp
	dim hasNotes
	dim priceTableSourceID


	if Not IsObject(Session("miscSetUp")) then
		initializeMiscSetUp
	end if
	set ObjMiscSetUp = Session("miscSetUp")
	storeId = Session("storeID")
	customerName = session("customername")
	custPhone =session("customerphone")
	custPriceList = Session("priceList")
	custSeqNumber = session("customersequencenumber")
	isDueDateSet = Request.Form("isDueDateSet")
	actionString = Request.QueryString("userAction")
	addOrEdit = Request.Form("addOrEdit")
	selDept = Request.Form("selDeptId")
	setStartIndexForPaging
	
	priceTableSourceID = getPriceTableSourceID(custPriceList)

	setDeptDueDates
	
	select case actionString
		case "create"
				addOrEdit ="add"
				selDept = -1
				isDueDateSet =0
				
				set invoice = Server.CreateObject("ShahCorpComponents.quickInvoice")
				getCustomerDetails
				invoice.createdDate = Now()
				invoice.DBConnectionString = Session("shahcorpDSN")
				invoice.custSeqNumber = custSeqNumber
				invoice.starchPref = Session("starchPref")
				invoice.finishPref = Session("finishPref")		
				invoice.priceListId = custPriceList 
				invoice.setStoreDays storeId	
					
				set Session("invoice") = invoice
				getAllDepartments
				getAllStarchPref
				getAllFinishPref
				invoice.loadCustomerPreferences custSeqNumber, ""
		case "addLine"
				addLineToInvoice
		case "delete"
				deleteItem
		case "returnFromNotes"
				attachNotes					   
		case "clear"
				set invoice = Session("invoice")
				invoice.clearInvoice
		case "save"
				checkForSplit
		case "newInvoiceNo"
				' this case is true when the user submits newInvoiceNumber.asp
				saveWithInvNumber
		case "hold"
				holdInvoice
		case "nextPage"
				set invoice = Session("invoice")
		case "changeStarchPref"
				changePref("starch")
		case "changeFinishPref"
				changePref("finish")
		case "cancel"
				Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
		case "split"			
			saveInvoiceWithSplitAndInvNo
		case "nosplit"
			saveInvoiceWithNoSplit
		case "fromCustomerNotes"
				fromCustomerNotesScreen
		case "changePreference"
			changePreference request.querystring("preferenceTypeID"), request.querystring("value"), request.querystring("save")
	end select
	
	setInvoiceDueDate
	
	

	function getPriceTableSourceID(priceListID)
		dim query, rs

		getPriceTableSourceID = -1

		if priceListID <> "" then
			query = "select dynamicSourceID from pricelist where pricelistid = " & priceListID
			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				getPriceTableSourceID = rs("dynamicSourceID")
			end if

			set rs = nothing
		end if
	end function


	function changePreference(preferenceTypeID, value, save)
		dim query
		
		set invoice = Session("invoice")
		invoice.setCustomerPreference preferenceTypeID, value
		
		if save then
			query = " delete customerpreference  "
			query = query & " where ticketnumber is null "
			query = query & " and customerpreferencetypeid = " & preferenceTypeID
			query = query & " and customersequencenumber = " & custSeqNumber
			
			qryexecute query
			
			query = " insert into customerpreference (value, ticketnumber, customerpreferencetypeid, customersequencenumber) "
			query = query & " values ('" & DBStr(value) & "'"
			query = query & ", null "
			query = query & ", " & preferenceTypeID
			query = query & ", " & custSeqNumber
			query = query & ")"

			qryexecute query
			
		
		end if
	end function
	
	sub setDeptDueDates()
		dim cntDeptsOnInvoice
		dim i
		dim dueDate
		dim deptName
		
		
		
		
		if isobject(Session("invoice")) then
		    if not (Session("invoice") is nothing) then
			    set invoice = Session("invoice")
			
			    cntDeptsOnInvoice = Request.Form("deptOnInvoice").count
		 
			    for i = 1 to cntDeptsOnInvoice
			    	deptName = Request.Form("deptOnInvoice")(i)
			    	dueDate = trim(Request.Form("deptDueDate" & replace(deptName, " ", "")))

			    	if dueDate <> "" then
			    	   invoice.setDeptDueDate deptName, dueDate
			    	end if
			    next
			    
'				invoice.adjustDueDatesForRoute custSeqNumber
'			    invoice.adjustDueDatesForWorkload
			end if
		end if
	end sub
	sub fromCustomerNotesScreen()
		addOrEdit = Request.QueryString("addOrEdit")
		selDept = Request.QueryString("selDept")
		deptStartIndex = Request.QueryString("DeptPageCount")
		if(IsEmpty(deptStartIndex)) Or deptStartIndex=0 then
			deptStartIndex=1
		else
			deptStartIndex=Int(deptStartIndex)
		end if
	end sub
	
	sub checkForSplit()
		dim splitPrompt
		dim splitInvoice
		
		on error resume next
		Set invoice = Session("invoice")
		if ObjMiscSetUp.Count > 0 then
			splitPrompt = ObjMiscSetUp.Item("promptBefoerInvSpli")
		else
			splitPrompt =false
		end if
		splitInvoice = invoice.isSplitInvoice()
				
		setInvoiceDueDate 'Added by vivek on 10 Feb 2003
		
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Quick Invoice invoiceDone-isSplitInvoice"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		if splitInvoice = true then
			if splitPrompt = true then
				Response.Redirect "promptToSplitForQuickInv.asp?addOrEdit=" & addOrEdit _
									& "&dept=" & selDept _
									& "&deptIndex=" & deptStartIndex
			else
				saveInvoiceWithSplit 
			end if
		else
			saveInvoiceWithoutSplit 
		end if		
	end sub
	
	sub saveInvoiceWithoutSplit()
		
		dim ObjMiscSetUp
		dim autoInvNos
		
		on error resume next		
		set invoice = Session("invoice")
		if Not IsObject(Session("miscSetUp")) then
			initializeMiscSetUp
		end if
		set ObjMiscSetUp = Session("miscSetUp")
		if ObjMiscSetUp.Count > 0 then
			autoInvNos = ObjMiscSetUp.Item("useAutomaticInvoiceNumbers")
		else
			autoInvNos = false
		end if
		'Response.Write autoInvNos
		if autoInvNos then
			if addOrEdit = "add" then
				invoice.invoiceNo =""
			end if
			saveInvoice false
		else
			if addOrEdit = "add" then
				Response.Redirect "newInvoiceNumber.asp?addOrEdit=" & addOrEdit _
										& "&onHold=0" & "&targetPage=quick" _
										& "&dept=" & selDept & "&deptIndex=" & deptStartIndex
			else
				saveInvoice false
			end if
		end if
	end sub
	
	sub saveInvoiceWithNoSplit()		
		' when the user selects no split in split prompt & auto invoice no. is set to true
		set invoice = Session("invoice")
		if addOrEdit = "add" then
			invoice.invoiceNo =""
		end if
		saveInvoice false
	end sub
	
	sub saveInvoiceWithSplitAndInvNo()
		
		' from prompt to split yes when auto invoice no is set to true		
		on error resume next
		set invoice = Session("invoice")
		saveInvoice true
	end sub
	
	sub saveInvoice(splitTheInvoice)
		dim invoicesDictionary
		dim invoicesArray
		dim counter
		dim aInvoice
		dim empId
		dim terminalId
		dim invNumber
		dim empName, storeName
		dim pickUp
		dim notifyPickup
		dim ssql, objResultSet
		
		on error resume next
		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")				
		setInvoiceDueDate 'Added by vivek on 06 Feb 2003
		if splitTheInvoice then
			set invoicesDictionary = invoice.splitInvoice()
			if addOrEdit = "add" then
				invoice.invoiceNo = ""
			end if
			invoicesArray = invoicesDictionary.Items
			for counter=0 to invoicesDictionary.Count-1
				set aInvoice = invoicesArray(counter)
				aInvoice.invoiceNo =""
			next			
		end if
		
		invoice.saveInvoice addOrEdit, empId, terminalId, 0, empName, storeName, true
		
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= quick Invoice save"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if
		'invNumber = invoice.ticketNo
		invNumber = invoice.getTicketNosForPrinting()
		
		pickUp ="0"
		notifyPickup = ObjMiscSetUp.Item("notifyPickup")
		

		if notifyPickup then
			ssql = "Select distinct Ticket.ticketNumber From Ticket, RackAssignment Where customersequencenumber=" & custSeqNumber _
					& " AND ticketStatus='AC' AND invoiceType='D' AND onHold=0 AND Ticket.ticketNumber = rackAssignment.ticketNumber"
			set objResultSet = getDisconnectedRecordset(ssql)

			if objResultSet.Recordcount > 0 then
				pickUp = "1"
			end if
		end if
		
		Response.Redirect "customerfunctions.asp?userAction=print&addOrEdit=" _
							& addOrEdit & "&ticketNumber=" & invNumber _
							& "&invoiceType=Q&customerseq=" & custSeqNumber _
							& "&pickup=" & pickUp
	end sub
	
	sub changePref(prefType)
		dim pref
		dim changeStatus
		dim ssql
		
		set invoice = Session("invoice")
		pref = Request.QueryString("pref")
		changeStatus = Request.QueryString("changeStatus")
		select case prefType
			case "starch"
					invoice.starchPref = pref	
					Session("starchPref") = pref
					if changeStatus = "yes" then
						ssql = "Update Customer Set starchPreferenceName ='" & pref & "' Where customerSequenceNumber=" &  custSeqNumber
						QryExecute ssql
					end if
			case "finish"
					invoice.finishPref = pref
					Session("finishPref") = pref
					if changeStatus = "yes" then
						ssql = "Update Customer Set finishPreferenceName ='" & pref & "' Where customerSequenceNumber=" &  custSeqNumber
						QryExecute ssql
					end if
		end select
		
	end sub
	
	sub setInvoiceDueDate()
	on error resume next
		dim dueDate
		set invoice = Session("invoice")

		if isDueDateSet ="1" then
			dueDate = Request.Form("txtDueDate")			
			if DateDiff("d", Now, dueDate) < 0 then
				alertMessage = "Due date set is prior to current date."
			end if
			invoice.setInvoiceDueDate dueDate
			if err.number <> 0 then
				set errorList =  Server.CreateObject("Scripting.Dictionary")
				errorList.Add err.number,err.description & "-Function= Detailed Invoice setInvoiceDueDate"
				set session("errorList") = errorList
				Response.redirect("../include/error.asp")
			end if 
			isDueDateSet ="0"
		end if
	end sub
			
	sub saveWithInvNumber()
		dim Inv_submit
		dim invoiceNumber
		dim inv_onHold
		dim empId
		dim terminalId
		dim empName, storeName
		
		on error resume next
		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")
		set invoice = Session("invoice")
		Inv_submit = Request.QueryString("submit")
		selDept = Request.QueryString("dept")
		addOrEdit = Request.QueryString("addOrEdit")
		if not IsEmpty(Request.QueryString("deptIndex")) then
			deptStartIndex = clng(Request.QueryString("deptIndex"))
		else
			deptStartIndex =0
		end if
		if Inv_submit = "ok" then
			invoiceNumber = Request.QueryString("invNo")
			inv_onHold = Request.QueryString("onHold")
			invoice.invoiceNo =invoiceNumber
			if inv_onHold = 1 then
				invoice.saveInvoice addOrEdit, empId, terminalId, 1, empName, storeName, true
				if err.number <> 0 then
					set errorList =  Server.CreateObject("Scripting.Dictionary")
					errorList.Add err.number,err.description & "-Function= quick Invoice holdInvoice"
					set session("errorList") = errorList
					Response.redirect("../include/error.asp")
				end if
				Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
			else
				saveInvoice false
			end if
		end if
	end sub
	
	sub attachNotes()
		dim selLineNo
		dim itemNotes
		selLineNo = Request.Form("selLineNo")
		itemNotes = Request.Form("itemNotes")
		selDept = Request.Form("selectedDept")
		set invoice = Session("invoice")
		invoice.updateNotes selLineNo, itemNotes
	end sub
	
	sub setStartIndexForPaging()
		deptStartIndex = Request.Form("DeptPageCount")
		if(IsEmpty(deptStartIndex)) Or deptStartIndex=0 then
			deptStartIndex=1
		else
			deptStartIndex=Int(deptStartIndex)
		end if
	end sub
	
	sub holdInvoice()
		dim ObjMiscSetUp
		dim autoInvNos
		dim empId
		dim terminalId
		dim empName, storeName
		
		on error resume next
		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")	
		set invoice = Session("invoice")
		if Not IsObject(Session("miscSetUp")) then
			initializeMiscSetUp
		end if
		set ObjMiscSetUp = Session("miscSetUp")
		if ObjMiscSetUp.Count > 0 then
			autoInvNos = ObjMiscSetUp.Item("useAutomaticInvoiceNumbers")
		else
			autoInvNos = false
		end if
		'Response.Write autoInvNos
		if autoInvNos then
			if addOrEdit = "add" then
				invoice.invoiceNo =""
			end if
			invoice.saveInvoice addOrEdit, empId, terminalId, 1, empName, storeName, true
			if err.number <> 0 then
				set errorList =  Server.CreateObject("Scripting.Dictionary")
				errorList.Add err.number,err.description & "-Function= quick Invoice holdInvoice"
				set session("errorList") = errorList
				Response.redirect("../include/error.asp")
			end if
			Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
		else
			if addOrEdit = "add" then
				Response.Redirect "newInvoiceNumber.asp?addOrEdit=" & addOrEdit _
										& "&onHold=1" & "&targetPage=quick" _
										& "&dept=" & selDept & "&deptIndex=" & deptStartIndex
			else
				invoice.saveInvoice addOrEdit, empId, terminalId, 1, empName, storeName, true
				if err.number <> 0 then
					set errorList =  Server.CreateObject("Scripting.Dictionary")
					errorList.Add err.number,err.description & "-Function= quick Invoice holdInvoice"
					set session("errorList") = errorList
					Response.redirect("../include/error.asp")
				end if
				Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
			end if
		end if
	end sub
	
	sub saveInvoiceWithSplit()
		dim autoInvNos
			
		on error resume next
		if ObjMiscSetUp.Count > 0 then
			autoInvNos = ObjMiscSetUp.Item("useAutomaticInvoiceNumbers")
		else
			autoInvNos = false
		end if
		set invoice = Session("invoice")
		if autoInvNos = true then
			saveInvoice	true
		else
			Response.Redirect "multipleInvoiceNosForQuickInv.asp?targetPage=quick&addOrEdit=" & addOrEdit _
								& "&dept=" & selDept & "&deptIndex=" & deptStartIndex
		end if
	end sub
	
	sub deleteItem()
		dim selLineNo
		selLineNo = Request.QueryString("lineNumber")
		set invoice = Session("invoice")
		invoice.deleteLineItem selLineNo
	end sub
	
	sub addLineToInvoice()
		dim ObjMiscSetUp
		dim quantity
		dim adjustDueDateForRoute
		on error resume next
		
		if Not IsObject(Session("miscSetUp")) then
			initializeMiscSetUp
		end if
		set ObjMiscSetUp = Session("miscSetUp")
		if ObjMiscSetUp.Count > 0 then
			adjustDueDateForRoute = ObjMiscSetUp.Item("adjustDueDateForRoute")
		else
			adjustDueDateForRoute = false
		end if
		
		quantity = Request.Form("txtAmountEntered")
		selDept = Request.QueryString("deptId")
		set invoice = Session("invoice")
		invoice.addLineItem quantity, selDept
		if err.number <> 0 then
			set errorList =  Server.CreateObject("Scripting.Dictionary")
			errorList.Add err.number,err.description & "-Function= Quick Invoice addLineToInvoice"
			set session("errorList") = errorList
			Response.redirect("../include/error.asp")
		end if 
		
		if adjustDueDateForRoute then
			invoice.adjustDueDatesForRoute custSeqNumber
		end if
	end sub
	
	sub getAllDepartments()
		dim ssql
		dim objResultSet

		ssql = " Select departmentID, name, splitInvoice, imageFileName, maxItemsInReceipt from Department where "
		ssql = ssql & " storeId =" & clng(storeId) & " AND disabled=0 "

		if priceTableSourceID > 0 then
			ssql = ssql & " AND priceListID = " & priceTableSourceID
		else
			ssql = ssql & " AND priceListID = " & custPriceList
		end if

		ssql = ssql & " And name <> 'SpecialOffers' "
		ssql = ssql & " Order by priceListID, displaySequence "

		Set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.RecordCount > 0 then
			objResultSet.PageSize = maxDeptCount
		end if
		set Session("departmentMaster") = objResultSet
	end sub

	
	sub getAllStarchPref()
		dim ssql
		dim objResultSet
		ssql ="SELECT starchPreferenceName, imageFileName FROM StoreStarchPreference where storeid=" & clng(storeId) _
				& " AND enabled=1 Order by displaySequence" 
		Set objResultSet = getDisconnectedRecordset(ssql)
		set Session("starchPrefMaster") = objResultSet
	end sub
	
	sub getAllFinishPref()
		dim ssql
		dim objResultSet
		ssql ="SELECT finishPreferenceName, imageFileName FROM StoreFinishPreference where storeid=" & clng(storeId) _
				& " AND enabled=1 Order by displaySequence" 
		Set objResultSet = getDisconnectedRecordset(ssql)
		set Session("finishPrefMaster") = objResultSet
	end sub
	
	sub getCustomerDetails()
		dim ssql
		dim objResultSet
		dim areaCode
		ssql = "Select IsNull(starchPreferenceName, '') as starchPreferenceName, IsNull(finishPreferenceName, '') as finishPreferenceName, defaultPriceListId, " _
				& " IsNull(firstName, '') as firstName, IsNull(middleInitial,'') as middleInitial, " _
				& " IsNull(lastName, '') as lastName, Isnull(mainAreaCode, '') as mainAreaCode, " _
				& " isnull(mainPhone, '') as mainPhone, IsNull(screenNotes, '') as screenNotes, routeNumber from customer where customerSequenceNumber=" _
				& clng(custSeqNumber)
		Set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Recordcount > 0 then	
			objResultSet.MoveFirst
			customerName  = Trim(objResultSet.fields("firstName") &  " "  & objResultSet.fields("middleInitial") & " " & objResultSet.fields("lastName"))
			session("customername") = customerName
			areaCode = objResultSet.fields("mainAreaCode")
			custPhone = objResultSet.fields("mainPhone")
			if len(Trim(custPhone)) > 0 then
				if len(Trim(areaCode)) > 0 then
					custPhone = areaCode & "-"  & Mid(custPhone,1,3) & "-" & Mid(custPhone,4,len(custPhone))
				end if
			end if
			session("customerphone") = custPhone 
			if isnull(objResultSet.fields("defaultPriceListId")) then
				Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
			end if
			custPriceList = objResultSet.fields("defaultPriceListId")
			Session("priceList") = custPriceList
			Session("starchPref") = objResultSet.fields("starchPreferenceName")
			Session("finishPref") = objResultSet.fields("finishPreferenceName")
			Session("ScreenNotes") = objResultSet.fields("screenNotes")

			invoice.routeNumber = objResultSet.Fields("routeNumber").Value
		end if
		
	end sub

	'MWiemann 01 DEC 03 -- procedure to determine if customer has notes saved for them
	sub doesCustHaveNotes()
		dim ssql
		dim notesRst
		dim screen, invoice
		hasNotes = 0
		ssql = "select screennotes, invoicenotes FROM customer " _
			   & "WHERE customersequencenumber = " & custSeqNumber
		set notesRst = getDisconnectedRecordset(ssql)	
		screen = notesRst.fields("screennotes").value
		invoice = notesRst.fields("invoicenotes").value
		if (len(screen) > 0 or len(invoice)) > 0 then
			hasNotes = 1
		end if	
	end sub	
	
	function getDeptDueDate(lines, deptID)
		dim linesClone
		dim max
		dim datedue
		
		set linesClone = lines.clone()
		
		max = "1/1/1980"
		linesClone.filter = "deptID='" & deptID & "'"
		
		if linesClone.recordcount > 0 then
			linesClone.movefirst
			while not (linesClone.eof or linesClone.bof)
				datedue = linesClone("duedate")
				if datediff("d", max, datedue) > 0 then
					max = datedue
				end if
				linesClone.moveNext
			wend
		end if
		set linesClone = nothing
		
		datedue = max
		
		getDeptDueDate = datepart("m", datedue) & "/" & datepart("d", datedue) & "/" & datepart("yyyy", datedue)
	end function
%>
<HTML>
<HEAD>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<SCRIPT LANGUAGE=javascript>
	var lastFocusControl;
	var previousElement=null;
	<!--
		
	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.style.background="#eee";
		}
		childEl = element.children[0];
		var rowChildNodes = childEl.children
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if(childEl.tagName == "INPUT") {
				childEl.checked=true;
				break;
			}
		}
		previousElement =element;
		element.style.background="#aaa";
		 
	}
	//-->
</SCRIPT>
<script language="javascript" src="../script/date-picker.js"></script>
<script language="javascript" type="text/javascript">
	

	function doQuickInvoice(){
		var itemCount;
		itemCount = document.quickInvoice.txtTotal.value;
		if (itemCount > 0) {
			document.quickInvoice.done.disabled = true;
			document.quickInvoice.action = "?userAction=save";
			document.quickInvoice.submit();
		}else{
			cbs_alert("Must have at least an item on the invoice.")
		}
	}
	
	function nextDeptPage() {
		document.quickInvoice.DeptPageCount.value = eval(eval(document.quickInvoice.DeptPageCount.value) + eval(1));
		document.quickInvoice.action = "?userAction=nextPage";
		document.quickInvoice.submit();
	}
	
	function prevDeptPage() {
		document.quickInvoice.DeptPageCount.value = eval(1);
		document.quickInvoice.action = "?userAction=nextPage";
		document.quickInvoice.submit();
	}
	
	function addLineItem(element) {
		var quantity;
		var deptId;
		
		deptId = element.id;
		quantity = document.quickInvoice.txtAmountEntered.value
		if (!checkInt(quantity)) {
			show_focus("Must enter all numbers.", "CBS Error", document.quickInvoice.txtAmountEntered);
			return false;
		}else{
			if (quantity.length == 0) {
				document.quickInvoice.txtAmountEntered.value = 1;
			}
				document.quickInvoice.action = "?userAction=addLine&deptId=" + deptId;
				document.quickInvoice.submit();
		}
	}
	
	function clearInvoice() {	
		document.quickInvoice.action = "?userAction=clear";
		document.quickInvoice.submit();
	}
	
	function deleteLineItem(){
		var itemId;
		itemId = null;
		if (invoiceTable.rows.length > 0) {
			if(invoiceTable.rows.length == 2)
			{
				if(document.quickInvoice.select.checked) {
					itemId = document.quickInvoice.select.value;
				}
			}
			else{
				for (var i = 0; i < document.quickInvoice.select.length; i++) {
					if(document.quickInvoice.select[i].checked){
						itemId = document.quickInvoice.select[i].value;
						break;
					}
				}
			}
			if(itemId!= null){
				document.quickInvoice.action = "?userAction=delete&lineNumber=" + itemId;
				document.quickInvoice.submit();
			}
			
		}
	}
	
	function setDueDate() {
				
		document.quickInvoice.isDueDateSet.value ="1";
		show_calendar("quickInvoice.txtDueDate");
	}
	
	function showNotes() {
		var itemId;
		itemId = null;

		if (invoiceTable.rows.length > 0) {
			if(invoiceTable.rows.length ==2) 
			{
				if(document.quickInvoice.select.checked) {
					itemId = document.quickInvoice.select.value;
				}
			}
			else{
				for (var i = 0; i < document.quickInvoice.select.length; i++) {
					if(document.quickInvoice.select[i].checked){
						itemId = document.quickInvoice.select[i].value;
						break;
					}
				}
			}
			if(itemId!= null){
				document.quickInvoice.action ="ItemNotes.asp?lineNumber=" + itemId + "&targetPage=quick"
				document.quickInvoice.submit();
			}
			
		}
	}
	
	function holdTicket() {
		var itemCount;
		itemCount = document.quickInvoice.txtTotal.value;
		if (itemCount > 0) {
			document.quickInvoice.action = "?userAction=hold";
			document.quickInvoice.submit();
		}else{
			cbs_alert("Must have at least an item on the invoice.")
		}
	}
	
	function changeStarchPref() {
		document.quickInvoice.action = "starchPreferences.asp?targetPage=quick";
		document.quickInvoice.submit();		
	}
	
	function changeFinishPref() {
		document.quickInvoice.action = "finishPreferences.asp?targetPage=quick";
		document.quickInvoice.submit();		
	}
	
	function cancelForm() {
		document.quickInvoice.action =  "?userAction=cancel";
		document.quickInvoice.submit();
	}
	
	function hideScrollBars(){
		document.body.style.overflow='hidden';
	}
	
	function startupActions(){
		var selected;
		hideScrollBars();
		lastFocusControl = eval(document.quickInvoice.txtAmountEntered);

		
		<% if selDept > 0 then %>
		selected = document.quickInvoice.selected.parentNode.parentNode;
		selectRow(selected);
		<% end if %>
	}
	
	
	function showCustomerNotes() {
		document.quickInvoice.action = "customerNotes.asp?targetPage=quick";
		document.quickInvoice.submit();
	}
	
	function selectDeptDueDate(element, deptName) {
		show_calendar("quickInvoice." + element.name);
	}

	var savPrefTypeId
	var savOptionSelected
	var savOptions
	function changePreference(preferenceTypeID, preferenceName, options, defaultOption) {
	    savPrefTypeId = preferenceTypeID;
	    savOptions = options;
		cbs_select('Preference', 1, options, "handlePrefReturn");
	}

    function handlePrefReturn(returnVal) {
        clearOptionMsg();
        savOptionSelected = savOptions.split("|")[returnVal]
        cbs_confirm("Save customer preference?", savePrefTrue, savePrefFalse);
   }

	function savePrefTrue() {
	    togoSavePref(true);
	}
	function savePrefFalse() {
	    togoSavePref(false);
	}

	function togoSavePref(savePreference) {
        clearConfirmMsg();
        document.quickInvoice.action = "?userAction=changePreference" +
            "&preferenceTypeID=" + savPrefTypeId +
            "&value=" + savOptionSelected +
            "&save=" + savePreference;
        document.quickInvoice.submit();
	}

</script>


<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function txtAmountEntered_onblur() {
	lastFocusControl = event.srcElement;
}

//-->
</SCRIPT>
</HEAD>

<BODY topmargin=0 leftmargin=0 onLoad ="startupActions();">

<!-- #include file="../include/banner.inc" -->
<H1>Quick Invoice</H1>
<TABLE  WIDTH="100%" BORDER=0 style="border:1px solid black;" CELLSPACING=0 CELLPADDING=0 >
	<FORM id="quickInvoice" name="quickInvoice" action="quickInvoice.asp" method="post" onSubmit="return false">
		<INPUT type="hidden" name="isDueDateSet" value="<%= isDueDateSet %>">
		<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
		<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
		<INPUT type="hidden" name="selDeptId" value="<%= selDept %>">
		<TR>
			<td valign=top width=200px>
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=1 >
					<tr height=50px><td></td></tr>
					<TR>
						<TD>
							<INPUT id=txtAmountEntered name=txtAmountEntered class=text style="HEIGHT: 25px; WIDTH: 200px" onblur="return txtAmountEntered_onblur()">
						</TD>
					</TR>
					<tr height=20px><td></td></tr>
					<TR>
						<TD style="vertical-align:middle;text-align:center;height:100px">
							<!-- #include file="../include/integerPad.inc" -->
						</TD>
					</TR>
				</table>
			</td>
			<td valign=top>
				<TABLE ALIGN=center BORDER=0  CELLPADDING=1>
					<tr>
						
						<td align="center">
							<BUTTON class=small style="width: 80px; height: 60px" id=bttnHoldTicket name=bttnHoldTicket onClick="holdTicket();"><img src="../images/Paused-Data.gif"><br>Hold Ticket</button>
							<!--<INPUT class=touch id=bttnHoldTicket name=bttnHoldTicket type=button value="" style="width:35px;height:35px;background-image:url(../images/Paused-Data.gif);" onClick="holdTicket();"><br>Hold Ticket-->
						</td>
						<td align="center">
							<!--<INPUT class=touch id=deleteItem name=deleteItem type=button value="" style="width:35px;height:35px;background-image:url(../images/Cancel-Data.gif);" onClick="deleteLineItem();"><br>Delete Item-->
							<BUTTON class=small style="width: 80px; height: 60px" id=deleteItem name=deleteItem onClick="deleteLineItem();"><img src="../images/Cancel-Data.gif"><br>Delete Item</button>
						</td>
											
						<!-- <td align="center">
							<INPUT class=touch id=customerNotes name=customerNotes type=button value="" style="width:35px;height:35px" onClick="showCustomerNotes()"><br>Customer Notes
						</td> -->
					</tr>
					<tr>
						<td align="center">
							<!--<INPUT class=touch id=bttnclearInvoice name=bttnclearInvoice type=button value="" style="width:35px;height:35px;background-image:url(../images/New-Data-Blank.gif);" onClick="clearInvoice();"><br>Clear Invoice-->
							<BUTTON class=small style="width: 80px; height: 60px" id=bttnclearInvoice name=bttnclearInvoice  onClick="clearInvoice();"><img src="../images/New-Data-Blank.gif"><br>Clear Invoice</button>
						</td>
						<td align="center">
							<!--<INPUT class=touch id=Notes name=Notes type=button value="" style="width:35px;height:35px;background-image:url(../images/Notes.gif);" onClick="showNotes();"><br>Notes-->
							<BUTTON class=small style="width: 80px; height: 60px" id=Notes name=Notes onClick="showNotes();"><img src="../images/Notes.gif"><br>Notes</button>
						</td>
					</tr>
					<tr height=30px><td></td></tr>
					<%	
						dim deptRst
						dim lStart, noOfElements
						set deptRst =  Session("departmentMaster")
						if deptRst.RecordCount > 0 then
							lStart =deptStartIndex
							noOfElements = deptRst.PageCount
							deptRst.AbsolutePage = lStart
							while not (deptRst.EOF or deptRst.AbsolutePage <> lStart)
					%>
							<tr height=60px>
								<td colspan="2" align="center">
									<BUTTON class=small style="width: 80px; height: 60px" id="<%= deptRst.Fields("departmentID")%>" name="<%= deptRst.Fields("departmentID")%>" style="
									<%
										if selDept = deptRst.Fields("departmentID") then
									%>
										border:2px inset #CCCCCC;
									<%
										end if
									%>
									" onClick="addLineItem(this);"><%= Replace(deptRst.Fields("name"), " ", "<br>")%></button>
								</td>
							</tr>
					<%
								deptRst.MoveNext
							wend
							if lStart < noOfElements then
					%>		
							<tr height=60px>
								<td colspan="2" align="center">
									<!--<INPUT class=touch id=otherDept name=otherDept type=button value="" style="width:35px;height:35px;background-image:url(../images/bluearrow.gif);" onClick="nextDeptPage();"><br>Other Dept.-->
									<BUTTON class=small style="width: 80px; height: 60px" id=otherDept name=otherDept onClick="nextDeptPage();"><img src="../images/bluearrow.gif"><br>Other Dept</button>
								</td>				
							</tr>
					<%
							else
								if lStart > 1 And lStart >= noOfElements then
								
					%>
								<tr height=60px>
									<td colspan="2" align="center">
										<!--<INPUT class=touch id=prevDept name=prevDept type=button value="" style="width:35px;height:35px;" onClick="prevDeptPage();"><br>Previous-->
										<BUTTON class=small style="width: 80px; height: 60px" id=prevDept name=prevDept onClick="prevDeptPage();"><img src="../images/previous.gif"><br>Previous</button>
									</td>				
								</tr>				
					<%			
								end if
							end if
						end if
					%>
				</table>	
			</td>
			<td align="center">
				<!-- 3rd column -->
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0>
					<!-- customer name & phone -->
					<tr>
						<td align=center>
							<TABLE WIDTH="290px" BORDER=0 CELLSPACING=0 CELLPADDING=0>
								<tr>
									<td width=35px rowspan=2 style="border-left:1px solid black;border-top:1px solid black;border-bottom:1px solid black;">
										<!--<INPUT class=touch id=customerNotes name=customerNotes type=button value="" style="width:35px;height:35px;vertical-align:middle;background-image:url(../images/Notes.gif);" onClick="showCustomerNotes();">-->
										<%
											doesCustHaveNotes
											if hasNotes = 1 then
										%>	
										<BUTTON class=small id=customerNotes name=customerNotes style="background-color:coral" onClick="showCustomerNotes();"><img src="../images/Notes.gif"><br>Notes</button>
										<%
											else
										%>	
										<BUTTON class=small id=customerNotes name=customerNotes onClick="showCustomerNotes();"><img src="../images/Notes.gif"><br>Notes</button>
										<%
											end if
										%>	
									</td>
									<td class="label" align=center style="border-top:1px solid black; border-right:1px solid black;height:20px;"><%= Server.HTMLEncode(customerName)%>&nbsp;</td>
								</tr>
								<tr>
									<td class="label" align=center style="border-right:1px solid black;border-bottom:1px solid black;height:20px;"><%= custPhone%>&nbsp;</td>
									
								</tr>
								
							</table>
						</td>
						
					</tr>
					
					<!-- list -->
					<tr>
						<td align=center>
							<DIV STYLE="overflow-y:auto;height:420px; overflow-x:auto; width=290px">
									<TABLE WIDTH="100%" style="height:420px;border-color:#2F4F4F;border-style:solid;background-color:white;" BORDER=1 CELLSPACING=0>
										<tr rowspan =5>
											<td valign="top">
												<TABLE name="invoiceTable" id ="invoiceTable" WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=3>
													<%
														dim lineItemsRst
														dim deptDueDate
														dim deptName
														
														set lineItemsRst = invoice.lineItems
														if lineItemsRst.RecordCount > 0 then
															lineItemsRst.MoveFirst
															while Not lineItemsRst.eof
															
																deptDueDate = getDeptDueDate(lineItemsRst, lineItemsRst.Fields("deptID").Value)
																deptName = lineItemsRst.Fields("deptName").Value
													%>
															<tr onclick="selectRow(this);" style="background:#eee">
																<td>
																	<input type="radio" name="select" id="select" value="<%= lineItemsRst.Fields("lineNumber")%>">
																	<% if trim(lineItemsRst.Fields("deptID")) = trim(selDept) then %> 
																	<input type=hidden name="selected"></input>
																	<% end if %>
																</td>
																<td><span style="font-size:16;font-weight:bold"><%= lineItemsRst.Fields("quantity")%></span></td>
																<td><input style="background:#EEE;width:120px" name="deptOnInvoice" value="<%=lineItemsRst.Fields("itemName")%>" readonly></td>
																<td><input name="deptDueDate<%= replace(deptName, " ", "")%>"  onclick="selectDeptDueDate(this, '<%=deptName%>');" style="width:80px;text-align:center" value="<%= deptDueDate%>"></td>
															</tr>
															
															<% 
																if not isNull(lineItemsRst.Fields("notes")) then
															%>
																<tr><td colspan="4"><span style="color:#009b01"><%= lineItemsRst.Fields("notes") %></span></td></tr>
															<%
																end if
																if not isNull(lineItemsRst.Fields("peNotes")) then
															%>
																<tr><td colspan="4"><span style="color:#4381Ef"><%= lineItemsRst.Fields("peNotes") %></span></td></tr>
															<%
																end if
															%>	
													<%
																lineItemsRst.MoveNext
															wend
														end if
													%>
													
												</table>
											</td>
										</tr>
								</table> <!-- table for border -->
							</div>
						</td>
					</tr>
					<!-- buttons -->
					<tr>
						<td align=center>
							<TABLE WIDTH="290px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
								<tr>
									<td align=left class="label" width=100px>Total Pieces</td>
									<td>
										<INPUT id=txtTotal name=txtTotal class=text style="WIDTH: 100px;height:22px;text-align:right;" value="<%= invoice.getTotalItemCount() %>" readonly>
									</td>
								</tr>
								<tr>
									<td align=center colspan="2">
<%
				dim customerPreference
				dim customerPreferences
				dim customerPreferencesRS
				dim query
				
				set customerPreferences = invoice.preferences

				query = " select * from customerpreferencetype order by displayorder "
        set customerPreferencesRS = getdisconnectedrecordset(query)
        
        while not (customerPreferencesRS.eof or customerPreferencesRS.bof)
        	if customerPreferences.exists(clng(customerPreferencesRS("customerPreferenceTypeID"))) then
        		response.write "<button style=""margin:2px;width:80px;height:55px;vertical-align: top"" onclick=""changePreference(" & clng(customerPreferencesRS("customerPreferenceTypeID")) & ", '" & customerPreferencesRS("name") & "', '" & customerPreferencesRS("options") & "', '" & customerPreferences(clng(customerPreferencesRS("customerPreferenceTypeID"))) & "');"">"
        		response.write customerPreferencesRS("name") & "<br/>" & customerPreferences(clng(customerPreferencesRS("customerPreferenceTypeID")))
        		response.write "</button>"
        	end if

        	customerPreferencesRS.movenext
        wend
%>
									</td>
								</tr>
								<tr>
									<td align=left class="label">Date Due</td>
									<td>
										<INPUT readonly id=txtDueDate name=txtDueDate class=text style="WIDTH: 100px;height:22px;vertical-align:middle;" value="<%= invoice.InvDueDate%>">
									</td>
								</tr>
								<tr>
									<td align="center">
										<INPUT class=touchnoborder id=done name=done type=button value="" style="background-image:url(../images/ok.gif);" onClick="doQuickInvoice()">
									</td>
									<td align="center">
										<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm();">
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table> <!-- 3rd column ends -->
			</td>
		</tr>
	</form>
</table>


</BODY>
</HTML>
