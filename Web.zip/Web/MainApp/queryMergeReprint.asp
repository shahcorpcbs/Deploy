<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 360 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim queryName
	dim queryTransformed
	dim query, rs
	dim userQueryID
	dim invoiceNumberField
	
	userQueryID = getReqVar("userQueryID")
	queryTransformed = getReqVar("query")
	queryName = getReqVar("queryName")
	invoiceNumberField = getReqVar("invoiceNumberField")
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function invoiceToTicketNumber(invoiceNumber)
		dim query, rs

		query = "select ticketnumber from ticket where invoicenumber = '" & invoiceNumber & "'"
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			invoiceToTicketNumber = rs("ticketnumber")
		end if
	
		set rs = nothing
	end function

	
%>

<HTML>
<HEAD>
<TITLE>Email</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript" src="/Script/printing.js"></script>
<SCRIPT LANGUAGE="javascript" >

	function selectInvoiceNumberField(invoiceField) {
		document.queryMergeReprint.action = "?invoiceNumberField=" + encodeURIComponent(invoiceField);
		document.queryMergeReprint.submit();
	}
	
	function exit() {
		document.queryMergeReprint.action = "querydb.asp?userQueryID=<%=userQueryID%>&query=<%=Server.URLEncode(queryTransformed)%>";
		document.queryMergeReprint.submit();
	}

	function reprintTags() {
		var tickets;
		var idx;
		
		tickets = getSelectedTickets();
		
		for(idx = 0; idx < tickets.length; idx++) {
			PrintTagsForInvoiceNoPrompt(tickets[idx]);
		}
	}
	function reprintInvoices() {
		var tickets;
		var idx;
		
		tickets = getSelectedTickets();

		for(idx = 0; idx < tickets.length; idx++) {
			PrintPickupInvoiceNoPrompt(tickets[idx]);
		}
	}
	
	function getSelectedTickets() {
		var result;
		var counter;
		
		counter = 0;
<%
	if invoiceNumberField <> "" then
	dim invoiceNumber
	set rs = getdisconnectedrecordset(queryTransformed)
%>
		result = new Array();
<%
	
	while not(rs.eof or rs.bof)
		invoiceNumber = invoiceToTicketNumber(rs(invoiceNumberField))
		if invoiceNumber then
%>
		result.push(<%=invoiceNumber%>);
<%
		end if
		rs.movenext
	wend
	set rs = nothing
	end if
%>

		return result;
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<FORM name="queryMergeReprint" ID="queryMergeReprint" METHOD=POST  style="margin:0;padding:0"> 
<INPUT type="hidden" name="queryName" value="<%=Server.URLEncode(queryName)%>" />
<INPUT type="hidden" name="query" value="<%=queryTransformed%>" />
<INPUT type="hidden" name="userQueryID" value="<%=userQueryID%>" />

<H1>Reprint</H1><BR />
<BR />

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="reprintInvoices()" value="" >Print<BR />Invoices</BUTTON>
		<BUTTON onclick="reprintTags()" value="" >Print<BR />Tags</BUTTON>
	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="exit()" value="" >Exit</BUTTON>
	</SPAN>
</DIV>

<TABLE class="itable" style="width:100%" cellpadding="0" cellspacing="0">
	<TR align="left">
		<TH>Attribute</TH>
		<TH>Value</TH>
	</TR>
	<TR>
		<TD>Invoice Number Field</TD>
		<TD>
			<SELECT name="invoiceNumberField" onchange="selectInvoiceNumberField(this.value)">
				<OPTION value=""></OPTION>
<%
		dim idx
		
		query = queryTransformed
		set rs = getdisconnectedrecordset(query)

		for idx = 0 to rs.Fields.Count - 1
%>
				<OPTION value="<%=Server.HTMLEncode(rs.Fields(idx).Name)%>" <%if trim(invoiceNumberField) = trim(rs.Fields(idx).Name) then%>selected<%end if%>><%=Server.HTMLEncode(rs.Fields(idx).Name)%></OPTION>
<%
		next
%>
			</SELECT>
		</TD>
	</TR>
</TABLE>

</FORM>
</BODY>
</HTML>

