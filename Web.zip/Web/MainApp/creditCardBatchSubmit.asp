<%@ Language=VBScript %>
<%option explicit%>

<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="CheckSessionExpiry.asp" -->
<!--#include file="../include/messages.asp" -->


<%
	'*******************************************************************
	'Name   : creditCardBatchSubmit.asp
    'Author : James Johnston
    'Created: 04Feb2004
    'Modification History
    '===================================================================
    ' Date			Changed By		Change Log
    ' ------------------------------------------------------------------
    ' 04Feb2004		Johnston		Original version
	'*******************************************************************
%>

<%

dim ObjMiscSetUp
dim empID
dim xChargePath
dim terminalId
dim sessionName

if Not IsObject(Session("miscSetUp")) then
	initializeMiscSetUp
end if
set ObjMiscSetUp = Session("miscSetUp")
empID = Session("employeeID")
xChargePath = ObjMiscSetUp.Item("XChargePath")
'xChargePath = replace(xChargePath,"\","\\")
terminalId = Session("terminalID")
sessionName = Session.SessionID


'REPORT.ASP section
	Call UpdateSessionParams
	

	

%>





<HTML>

<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Credit Card Batch Submission</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript">

	var checkboxClicked=false;
	var custSeqNum;
	var CCString;
	var tranType;
	var empID;
	var ccTotal;
	var accountNumber;
	var expirationDate;	
	var ccZip;
	var ccAddress;
	var ccCity;
	var ccState;
	var ccCVC;
	var swipeData;

	//NOTE: CHANGE THIS NEXT AFTER SWIPE DATA IS STORED/RETRIEVED FROM DB
	swipeData = "";

	function selectRow(element) 
	{
		var childEl;
		if(!checkboxClicked)
		{
			childEl = element.children[0];
			
			var rowChildNodes = childEl.children
			
			for(i=0; i<rowChildNodes.length; i++)
			{
				childEl = rowChildNodes[i];
				
				if(childEl.tagName == "INPUT") 
				{
					if(childEl.checked) 
					{
						childEl.checked=false;
						element.style.background="white";
					}
					else
					{
						childEl.checked=true;
						element.style.background="#DBF2F4";
					}
					break;
				}
			}
		}
		checkboxClicked=false;
	}


	function selectRowForCheckBox(element) 
	{
		var parentEl;
		parentEl=element;
		while(parentEl.tagName != "TR") {
			parentEl = parentEl.parentElement;
		}
		if (element.checked){
			parentEl.style.background="#DBF2F4";
		}else{
			parentEl.style.background="white";
		}
		
		checkboxClicked=true;
	}
	
	
	function selectAll() 
	{
		var collINPUT = document.all.tags("INPUT");
		var parentEl;
		
		if (collINPUT!=null) 
		{
		    for (i=0; i<collINPUT.length; i++) 
		    {
				if(collINPUT[i].type == "checkbox")
				{
					collINPUT[i].checked=true;
					parentEl=collINPUT[i].parentElement;
					parentEl=parentEl.parentElement;
					parentEl.style.background="#DBF2F4";
				}				
			}
		}

	}	
	
	
	function unSelectAll() 
	{
		var collINPUT = document.all.tags("INPUT");
		var parentEl;
		
		if (collINPUT!=null) 
		{
		    for (i=0; i<collINPUT.length; i++) 
		    {
				if(collINPUT[i].type == "checkbox")
				{
					collINPUT[i].checked=false;
					parentEl=collINPUT[i].parentElement;
					parentEl=parentEl.parentElement;
					parentEl.style.background="white";
				}				
			}
		}

	}
	
	
	function processBatch()
	{
	//Main function. 
	// Builds and names xCharge file, retrieves answer file, cleans up files, and
	// returns to appropriate page.	
		var rUSure;
		var fileContent;
		fileContent = "";
		
		rUSure=cbsConfirm("Are you certain you which to process the selected accounts?",cbsQuestion + cbsYesNo,"Process Accounts?");
		
		if(rUSure == 6)
		{
			initializeProcess();
			
			//Loop through and Process selected customers
			// Write lines
			fileContent = processSelectedCustomers();

			
			//Build file
			if(fileContent != "")
			{
				createTempFile(fileContent);
					
				//Check for .tmp file. If exists, rename as .req
				if(!renameFile(fileName))
				{
					return;				
				}
				
				getAnswerFile(fileName);
				
			}		

			
			//Remove files
//			removeOldFiles(fileName);
			
			//reset PROCESS button
			document.creditCardBatch.processButton.disabled = false;
			
			//Proceed to REPORT page
			document.creditCardBatch.action="creditCardBatchSubmitReport.asp";
			document.creditCardBatch.submit();
			
		}
		else
		{
			return;
		}
	}
	
	
	function initializeProcess()
	{
		//Disable PROCESS button
		document.creditCardBatch.processButton.disabled = true;
		//Set common variables
		CCString = "";
		tranType = "C1";
		empID = document.creditCardBatch.empID.value;	
	}
	
	
	function processSelectedCustomers() 
	{
		var max;
		var numSelectedLines;
		var lineNumber;
		var fileString;
		var custString;
		max = 0;
		numSelectedLines = 0;
		lineNumber = 0;
		fileString = "";
		custString = "";
		
		if (ccAccounts.rows.length > 0) 
		{
			max = document.creditCardBatch.select.length;

			//How many lines are selected?
			for (i = 0; i < max; i++) 
			{
				if (document.creditCardBatch.select[i].checked) 
				{
					numSelectedLines = numSelectedLines+1;
				}			
			}			

			
			for (i = 0; i < max; i++) 
			{
				if (document.creditCardBatch.select[i].checked) 
				{
					//NOT checking data quality:
					// Rely on XCharge to return denial, then
					// report failures in end report.
					
					//Retrieve info from table for each customer
					setCustVars();
					
					//Build string
					custString = buildCustString();
					fileString = fileString + custString;
					lineNumber = lineNumber + 1;
					
					//If NOT last line, add line feed
					if(lineNumber < numSelectedLines)
					{
						//fileString = fileString + String.fromCharCode(10,13);
						//fileString = fileString + unescape("%0A") + unescape("%0D");
						fileString = fileString + "\n";
					}
				}
			}
		}
		
		return fileString;
	}	
	
	
	function setCustVars()
	{
	//Sets variables for each row
		
		custSeqNum = document.creditCardBatch.select[i].value;
		ccTotal = document.all.ccAccounts.rows[i+1].cells[8].innerText;
		ccZip = document.all.ccAccounts.rows[i+1].cells[6].innerText;
		ccZip = trimString(ccZip);
		ccAddress = document.all.ccAccounts.rows[i+1].cells[3].innerText;
		ccAddress = trimString(ccAddress);
		ccCity = document.all.ccAccounts.rows[i+1].cells[4].innerText;
		ccCity = trimString(ccCity);
		ccState = document.all.ccAccounts.rows[i+1].cells[5].innerText;
		ccState = trimString(ccState);
		//Leave CVC blank for now.  Will add code to retreive from db later.
		//ccCVC = document.creditCardBatch.select[i].value;
		ccCVC = "";
		accountNumber = document.all.ccAccounts.rows[i+1].cells[9].innerText;
		expirationDate = document.all.ccAccounts.rows[i+1].cells[10].innerText;
		//If not swiped, only send expiration date
		//Must reverse date to 'yymm'
		expirationDate = expirationDate.substr(2,2)+expirationDate.substr(0,2);
	
		custSeqNum = custSeqNum.replace(",", "")
	}
	
	
	function buildCustString()
	{
		var strQCQ = '","';
		var strQ = '"';
		CCString = strQ+tranType+strQCQ;	//0
		CCString = CCString + empID + strQCQ;	//1
		CCString = CCString + custSeqNum + strQCQ;	//2
		CCString = CCString + accountNumber + strQCQ;	//3
		CCString = CCString + expirationDate + strQCQ;	//4

		if(swipeData!="")//swiped card
		{
			CCString = CCString + ccTotal + strQ;	//5
		}
		else//NOT a swiped card
		{
			//Collect info from manual enter fields			
			//Add to string
			if(ccZip!="")
			{
				CCString = CCString + ccTotal + strQCQ;
				CCString = CCString + ccZip + strQ;
			}
			else
			{
				CCString = CCString + ccTotal + strQCQ;
				//if zip is empty, send default
				CCString = CCString + "99999" + strQ;	
			}

			if(ccAddress!="" && ccCity!="" && ccState!="")
			{
				ccAddress = ccAddress + " " + ccCity + " " + ccState;
				ccAddress = ccAddress.toUpperCase();
				CCString = CCString + ',"' + ccAddress + strQ;
			}
			if(ccAddress=="")
			{
				CCString = CCString + ',""'
			}
			
			if(ccCVC!="")
			{
				CCString = CCString + ',"' + ccCVC + strQ
			}
			else
			{
				CCString = CCString + ',""'
			}
		}
		
		return CCString;
	}
	
	
	function createTempFile(inCCString)
	{
		var sessionName;
		sessionName = document.creditCardBatch.sessionName.value;
		
		var termName;
		termName = document.creditCardBatch.terminalId.value;
		
		var pathName;
		pathName = document.creditCardBatch.xChargePath.value;
		
		var fsoTempFile = new ActiveXObject("Scripting.FileSystemObject");
		
		if(fsoTempFile.FolderExists(pathName))
		{
			fileName = pathName+"\\"+termName+sessionName;
			document.creditCardBatch.fileName.value=fileName;
		}
		else
		{
			cbs_alert("X-Charge Transaction folder does not exist.\nCheck path in Miscellaneous Setup.");
			return;
		}
		

//		removeOldFiles(fileName);
		

		var a = fsoTempFile.CreateTextFile(fileName+".tmp", true);
		var b = fsoTempFile.CreateTextFile(fileName+".bak", true);
		
		a.WriteLine(inCCString);
		a.Close();
		
		b.WriteLine(inCCString);
		b.Close();
		
		void fsoTempFile;
		
	}
	
	
	function removeOldFiles(fileName)
	{
	  var fsoRemove, newName;
	  newName = fileName + ".tmp";
	  fsoRemove = new ActiveXObject("Scripting.FileSystemObject");

	  //.tmp file
	  if(fsoRemove.FileExists(newName))
	  {
		fsoRemove.DeleteFile(newName);
	  }
	  //.req file 
	  newName = fileName + ".req";
	  if(fsoRemove.FileExists(newName))
	  {
		fsoRemove.DeleteFile(newName);
	  }	  
	  //.hld file 
	  newName = fileName + ".hld";
	  if(fsoRemove.FileExists(newName))
	  {
		fsoRemove.DeleteFile(newName);
	  }	
	  //.ans file 
	  newName = fileName + ".ans";
	  if(fsoRemove.FileExists(newName))
	  {
		fsoRemove.DeleteFile(newName);
	  }	
	  //.bak file 
	  newName = fileName + ".bak";
	  if(fsoRemove.FileExists(newName))
	  {
		fsoRemove.DeleteFile(newName);
	  }		
	  //.err file 
	  newName = fileName + ".err";
	  if(fsoRemove.FileExists(newName))
	  {
		fsoRemove.DeleteFile(newName);
	  }	  
	  
	  void fsoRemove;
  	  
	}
	
	
	function renameFile(fileName)
	{
		var fsoRename;
		var f;
		var newName;
		var attemptCounter;
		attemptCounter = 0;
		
		fsoRename = new ActiveXObject("Scripting.FileSystemObject");
		while(attemptCounter<=10)
		{
			if (fsoRename.FileExists(fileName + ".tmp"))
			{
				f = fsoRename.GetFile(fileName+".tmp");
				newName = fsoRename.getfilename(fileName)+".req";
				f.Name=newName;
	
				return true;
			}
			
			attemptCounter = attemptCounter + 1;	
		}
		
		if(!fsoRename.FileExists(fileName + ".req"))
		{
			cbs_alert("Unable to process file.\nPlease try again.");
			return false;
		}
	}		
		

	function getAnswerFile(fileName)
	{
		var fsoAnswer;
		var fsoBatch;
		var batchFile;
		var newName;
		var ansString;
		var reqString;
		var splitReqString;
		var pairString;
		var timedOut;
		var lineNum;
		var d;
		var timer;
		var MinMilli;
		
		//Initialize variables
		fsoAnswer = new ActiveXObject("Scripting.FileSystemObject");
		fsoBatch = new ActiveXObject("Scripting.FileSystemObject");

		newName = fileName + ".ans";;		
		ansString = "?";
		reqString = "%";
		splitReqString = "";
		pairString = "";
		timedOut = false;
		lineNum = "";
		MinMilli = 1000 * 300;	//Set time-out to 300 seconds
		
		//Loop until answer is found, or time-out reached
		d = new Date();
		timer = d.getTime();
	
		//For next 300 seconds...
		do
		{
			d = new Date();
			if(fsoAnswer.FileExists(newName))
			{
				break;
			}
		}
		while(d.getTime() < (timer+MinMilli));
		
		
		//If the answer is found...
		if(fsoAnswer.FileExists(newName))
		{
			//...open the request and answer files
			var custID;
			var amtPaid;			
			var acctNum;
			var returnCode;
			var ccCardType;			
			var expireDate;
			
			//Open request file
			var fBak, tsBak;
			fBak = fsoAnswer.GetFile(fileName+".bak");
			tsBak = fBak.OpenAsTextStream(1, 0);
			
			//Open answer file
			var fAnswer, tsAnswer;
			fAnswer = fsoAnswer.GetFile(newName);
			tsAnswer = fAnswer.OpenAsTextStream(1, 0);
			
			//create file to store details for reporting
			batchFile = fsoBatch.CreateTextFile(fileName + ".scb", true);
							
			//Loop through files
			while (!tsBak.AtEndOfStream)
			{
				//save line number
				lineNum = tsBak.Line;
				lineNum = '"' + lineNum + '",';
				
				//read request line
				reqString = tsBak.ReadLine();
				splitReqString = reqString.split(",");
					acctNum = splitReqString[3];
					expireDate = splitReqString[4];
					custID = splitReqString[2];
					amtPaid = splitReqString[5];

				//read answer line													
				ansString = tsAnswer.ReadLine();

				if(ansString.substr(1,1)=="Y")
				//if(true)	//Set to TRUE for TESTING
				{
					trimAnsString = ansString.substr(2,ansString.length-3)
				}
				else
				{
					trimAnsString = ansString.substr(5,ansString.length-3)
				}
												
				ansString = lineNum + ansString + "?";
																
				reqString = lineNum + reqString + "%";

				pairString = ansString + reqString + "\n";
				
				//Write to file
				batchFile.WriteLine(pairString);

			}	// END LOOP
						
			//Close files
			tsAnswer.Close();
			tsBak.Close();
			batchFile.Close();
	
		}
		else
		{
			cbs_alert("TRANSACTION TIMED OUT.\n\n MAKE SURE X-CHARGE and MODEM ARE WORKING PROPERLY");
			timedOut = true;
//			removeOldFiles(fileName);
			return;
		}
		
	}




			
	
	function trimString(inString)
	{
	//Trims leading and following spaces
		var str;
		str = inString;

		while(str.substr(0,1)==" ")
		{
			str = str.substr(1);
		}
		while(str.substr(str.length-1)==" ")
		{
			str = str.substr(0,str.length-1)		
		}	
		
		return str;
	}
	
	
	function WaitTimer(InTime)
	{
		//JJ, 7Jan04
		//This function allows user to set a wait period.
		//Incoming parameter is the number of seconds to wait.
		//Displays the text message "PROCESSING" in the credit card form.
		//If used in another form, comment out or change the 2 lines beginning
		// with "document..."
		
		//Set timer
		var d, timer;
		var MinMilli;
		MinMilli = 1000 * InTime;
		d = new Date();
		timer = d.getTime();
	
		//For "time" number of seconds...
		while(d.getTime() < (timer+MinMilli))
		{
			d = new Date();
			//document.creditCardInfo.txtProcessing.style.visibility="visible";
		}
		
		//document.creditCardInfo.txtProcessing.style.visibility="hidden";
	}	

</SCRIPT>



<BODY topmargin=0 leftmargin=0 onLoad = "selectAll();">
<!-- #include file="../include/bettergui.inc" -->

<FORM ID="creditCardBatch" name="creditCardBatch" action="creditCardBatchSubmit.asp" METHOD=post><!-- 8888888888888888888888888888888888888888888888888888888888888888888888888 -->
	<INPUT type="hidden" name="empID" value="<%= empID%>">
	<INPUT type="hidden" name="xChargePath" value="<%= xChargePath%>">
	<INPUT type="hidden" name="terminalId" value="<%= terminalId%>">
	<INPUT type="hidden" name="sessionName" value="<%= sessionName%>">
	<INPUT type="hidden" name="fileName" value="">
<%
'REPORTDISPLAY.ASP section

	on error resume next
	
    dim objReport 
	dim previousTimeoutValue
	dim reportTimeoutValue
	dim reportStream
	
    set objReport = CreateObject("CBSReports.clsReport")
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & "-Function= Report Display. Error while creating Report Object (CBSReports.clsReport). Please make sure that the latest version of the component (CBSReports.dll) is installed."
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if
	
	Server.ScriptTimeout = reportTimeoutValue
	
	objReport.CreateStandardReport(Session("objRP"))
	Response.Write Session("objRP").reportStream
	reportStream = Session("objRP").reportStream
	
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.Source & err.description 
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if

	Server.ScriptTimeout = 	previousTimeoutValue
		

%>

<BR>
<BR>

		&nbsp;&nbsp;&nbsp;&nbsp;
		<INPUT class=touchnoborder id=selectAllButton name=selectAllButton type=button style="BORDER-RIGHT: turquoise thick outset; BORDER-TOP: silver thick ridge; FONT-WEIGHT: bold; FONT-SIZE: x-small; BACKGROUND-IMAGE: url(../images/Select-All.gif); BORDER-LEFT: silver thick ridge; BORDER-BOTTOM: turquoise thick outset; FONT-STYLE: italic; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: turquoise" onClick="selectAll()" value="Select All" align=textTop>
		<BR><BR>&nbsp;&nbsp;&nbsp;&nbsp;
		<INPUT class=touchnoborder id=clearAllButton name=clearAllButton type=button style="BORDER-RIGHT: khaki thick outset; BORDER-TOP: silver thick ridge; FONT-WEIGHT: bold; FONT-SIZE: x-small; BACKGROUND-IMAGE: url(../images/Un-Select-All.gif); BORDER-LEFT: silver thick ridge; BORDER-BOTTOM: khaki thick outset; FONT-STYLE: italic; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: khaki" onClick="unSelectAll()" value="Clear All" align=textTop>
<CENTER>
		<TR><P><BR></TR>
		<TR><P><BR></TR>
		<TR><P><BR></TR>
		<TR><P><BR></TR>
		<% if InStr(1,reportStream,"There is no data to satisfy the selection criteria.") = 0 then %>
			<INPUT class=touchnoborder id=processButton name=processButton type=button style="BORDER-RIGHT: deepskyblue thick outset; BORDER-TOP: silver thick ridge; FONT-WEIGHT: bold; FONT-SIZE: 12pt; BORDER-LEFT: silver thick ridge; BORDER-BOTTOM: deepskyblue thick outset; BACKGROUND-REPEAT: no-repeat; FONT-STYLE: italic; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: deepskyblue" onClick="processBatch()" value="HIIIIIIProcess">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<%end if%>

		<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button style="BACKGROUND-IMAGE: url(../images/Cancel.gif)" onClick="history.back()" >

</CENTER>
</FORM>
</BODY>
</HTML>
