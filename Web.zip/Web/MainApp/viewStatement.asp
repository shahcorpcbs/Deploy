<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 900 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim bodyText
	dim accountStatementID
	dim HelperFunctions
	
	accountStatementID = request.querystring("accountStatementID")

	if accountStatementID <> "" and accountStatementID <> "undefined" then
		query = " select statementstream from accountstatement where accountstatementid = " & accountStatementID
		set rs = getdisconnectedrecordset(query)

		

		
		if rs.recordcount > 0 then
			set HelperFunctions = Server.CreateObject("ShahCorpComponents.HelperFunctions")
			bodyText = CStr(HelperFunctions.ASPStrConv(rs("statementstream"), 64))

		end if
	end if
%>

<HTML>
<HEAD>
<TITLE>Statement</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT language="javascript" type="text/javascript">
	function printStatement() {
		var print_window = window.open('','','width=300,height=300');
		var statement_el;
		var statement_html;
		
		statement_el = document.getElementById('statement_container');
		
		
		print_window.document.open("text/html");
		print_window.document.write('<head>');
		print_window.document.write('<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">');
		print_window.document.write('<link href="../script/greyscale.css" rel="stylesheet" type="text/css">');
		print_window.document.write('</head>');
		print_window.document.write('<body>' + statement_el.innerHTML + '</body>');
		print_window.document.close();
		print_window.print();
		print_window.close();
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0>


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="printStatement()">Print</BUTTON>
	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="window.close()" value="" >Exit</BUTTON>
	</SPAN>
</DIV>	
<DIV id="statement_container">
<%=bodyText%>
</DIV>

</BODY>
</HTML>

