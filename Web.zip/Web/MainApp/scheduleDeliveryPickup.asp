<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<%
	dim query, rs
	dim customerSequenceNumber
	dim originPage
	dim note
	
	
	note = "Scheduled Pickup"
	
	
	customerSequenceNumber = getReqVar("customerSequenceNumber")
	originPage = getReqVar("originPage")
	
	select case(lcase(request.querystring("useraction")))
	case "schedulepickup"
		schedulePickUp customerSequenceNumber, request.form("pickUpDate"), request.form("note")
		returnToOriginPage originPage, customerSequenceNumber
	case "cancel"
		returnToOriginPage originPage, customerSequenceNumber
	case "cancelpickup"
		cancelPickUp customerSequenceNumber
		returnToOriginPage originPage, customerSequenceNumber
	end select

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function cancelPickUp(customerSequenceNumber)
		dim query, rs

		query = " update deliverywillcall set status = -1 "
		query = query & " where status = 0 and actionrequired = 'PICKUP' and customersequencenumber = " & customerSequenceNumber
		qryexecute query
	end function
	
	function schedulePickUp(customerSequenceNumber, scheduledDate, note)
		dim query, rs
		
		if scheduledDate <> "" then
			query = " update deliverywillcall set status = -1 "
			query = query & " where status = 0 and actionrequired = 'PICKUP' "
			query = query & " and customersequencenumber = " & customersequencenumber
			
			qryexecute query
			
			query = " insert into deliverywillcall (customersequencenumber, actionrequired, scheduledDate, note) "
			query = query & " values (" & customerSequenceNumber
			query = query & ", 'PICKUP'"
			query = query & ", '" & scheduledDate & "'"
			query = query & ", " & DbCreateQryString(note)
			query = query & ")"


			qryexecute query
		end if
	end function
		
	function returnToOriginPage(originPage, customerSeq)
		select case lcase(originPage)
		case "customerfunctions"
			response.redirect "customerfunctions.asp?customerSeq=" & customerSeq
		end select
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">


<style type="text/css">

</style>

<script language="javascript" type="text/javascript" src="/Script/validation.js"></script>
<script language="JavaScript" src="../script/date-picker.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<script language="javascript" type="text/javascript">
	function submitForm() {
		document.scheduleDeliveryPickUp.action = "?useraction=schedulepickup";
		document.scheduleDeliveryPickUp.submit();
	}
	function cancelForm() {
		document.scheduleDeliveryPickUp.action = "?useraction=cancel";
		document.scheduleDeliveryPickUp.submit();
	}
	
	function cancelPickup() {
		document.scheduleDeliveryPickUp.action = "?useraction=cancelpickup";
		document.scheduleDeliveryPickUp.submit();
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="scheduleDeliveryPickUp.pickupDate.focus()">
<!-- #include file="../include/banner.inc" -->
<FORM name="scheduleDeliveryPickUp" ID="scheduleDeliveryPickUp" METHOD=POST  style="margin:0;padding:0"> 
<INPUT type="hidden" name="customerSequenceNumber" value="<%=customerSequenceNumber%>" />
<INPUT type="hidden" name="originPage" value="<%=originPage%>" />



<H1>Select Delivery Pickup</H1>

<BR /><BR />


<CENTER>
Date<BR />
<INPUT style="width:100px;height:30px;font-size:16;text-align:center;" name="pickupDate" onclick="show_calendar('scheduleDeliveryPickUp.pickupDate');" readonly />

<BR />
Note <BR />
<TEXTAREA name="note" style="overflow: auto" cols="40" rows="5"><%=Server.HTMLEncode(note)%></TEXTAREA>
<BR /><BR />
</CENTER>


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">

		<BUTTON style="width:100px;height:50px" onclick="cancelPickup()">Cancel Pickup</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON style="width:100px;height:50px" onclick="cancelForm()">Cancel</BUTTON>
		<BUTTON style="width:100px;height:50px" onclick="submitForm()">Ok</BUTTON>
	</SPAN>
</DIV>	

</FORM>
</BODY>
</HTML>
