<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<HTML>
<HEAD>
<TITLE>Run Statements</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->

<P>
<H1>&nbsp;&nbsp;Run Statements</H1>
<P>


<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px><td></td></tr>

		<tr >
			<td align=center>
				<!--<INPUT class=touch id=stdAccountStmt name=stdAccountStmt type=button value=""  style="background-image:url(../images/Report-Data.gif);" onClick="location.href='reportParams.asp?reportID=25&reportName=AR Statement&customerSequenceNumber=<%=Request.QueryString("customerseq")%>&requesterName=STMT_RUN';"><br>AR Statement-->
				<BUTTON class=std id=stdAccountStmt name=stdAccountStmt onClick="location.href='reportParams.asp?reportID=25&reportName=AR Statement&customerSequenceNumber=<%=Request.QueryString("customerseq")%>&requesterName=STMT_RUN';">AR Statement</button>
			</td>
		</tr>

		<tr >
			<td align=center>
				<!--<INPUT class=touch id=accountSummary name=accountSummary type=button value=""  style="background-image:url(../images/Report-Data-2.gif);" onClick="location.href='reportParams.asp?reportID=27&reportName=AR Multi Pickup Statement&customerSequenceNumber=<%=Request.QueryString("customerseq")%>&requesterName=STMT_RUN';"><br>AR Multi Pickup Statement-->
<!--				<INPUT class=touch id=accountSummary name=accountSummary type=button value=""  style="background-image:url(../images/Report-Data-2.gif);" onClick="location.href='reportParams.asp?reportID=27&reportName=AR Multi Pickup Statement';"><br>AR Multi Pickup Statement  -->
				<BUTTON class=std id=accountSummary name=accountSummary onClick="location.href='reportParams.asp?reportID=27&reportName=AR Multi Pickup Statement&customerSequenceNumber=<%=Request.QueryString("customerseq")%>&requesterName=STMT_RUN';">Multi Pickup Statement</button>
			</td>
		</tr>
		<tr height=80px>
			<td align=center>
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value=""   style="background-image:url(../images/cancel.gif);" onClick="location.href='accountMgmt.asp';">
			</TD>
		</tr>
</table>
</BODY>
</HTML>
