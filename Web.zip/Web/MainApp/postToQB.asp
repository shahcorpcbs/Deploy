<%@ Language=VBScript %>
<% option explicit %>

<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!-- #include file="CheckSessionExpiry.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%	
	dim rangeStartDate
	dim rangeEndDate
	dim sqlStr
	dim dateRst
	dim fileloc
	
	sqlStr = "select dateadd(day,1,enddate) as datestart,dateadd(month,1,dateadd(day,1,enddate))-1 as dateend from arpostingdates"
	set dateRst = getDisconnectedRecordset(sqlStr)
	
	if not dateRst.EOF and not dateRst.BOF then
		rangeStartDate = dateRst.Fields("datestart")
		rangeEndDate = dateRst.Fields("dateend")
	end if	
	

%>
<HTML>
<HEAD>
<TITLE>Post to Quickbooks</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="JavaScript" src="../script/validation.js"></script>
<script language="javascript" type="text/javascript">
	function setRangeStartDate() {
		var prevValue;
		var newValue;
		prevValue = document.postToQBForm.rangeStartDate.value;
		show_calendar("postToQBForm.rangeStartDate");
		newValue = document.postToQBForm.rangeStartDate.value;		
	}

	function setRangeEndDate() {
		show_calendar("postToQBForm.rangeEndDate");
	}

	function postToQB() {
		document.postToQBForm.action="postToQB.asp";
		document.postToQBForm.submit();
	}
	function cancelForm() {
		document.postToQBForm.action="start2.asp";
		document.postToQBForm.submit();
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Post Accounts Receivable Invoices to QuickBooks</H1>
<FORM id="postToQBForm" name="postToQBForm"  method="Post">
	<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR height=50px><td></td></TR>	
			<tr>
				<td width = 50% class = "label"  align=center Style="Font-weight=bold">Start Date
				</td>
				<td width = 50% class = "label"  align=center Style="Font-weight=bold">End Date
				</td>				
			<tr height=35px>
				<td width = 50% class = "label"  align=center Style="Font-weight=normal">
					<INPUT readonly id=rangeStartDate name=rangeStartDate class=text style="WIDTH: 100px;vertical-align:middle;" value="<%=rangeStartDate%>">
					<INPUT class=touch id=bttnRangeStartDate name=bttnRangeStartDate type=button value="" style="width:25px;height:25px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="setRangeStartDate();">
				</td>
				<td width = 50% class = "label"  align=center Style="Font-weight=normal">
					<INPUT readonly id=rangeEndDate name=rangeEndDate class=text style="WIDTH: 100px;vertical-align:middle;" value="<%=rangeEndDate%>">
					<INPUT class=touch id=bttnRangEndDate name=bttnRangeEndDate type=button value="..." style="width:25px;height:25px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="setRangeEndDate();">
				</td>
			</tr>	
			<tr height=60>
				<td class=label colspan=2 align=center>File Name:&nbsp
					<INPUT type=text name=fileloc value="<%=fileloc%>">
				</td>	
			</tr>	
		</tr>
		<TR ></TR>
		<tr height=80>
			<td colspan=2 align="center">
				<INPUT class=touchnoborder id=ok name=ok type=button value="" onClick="submitForm();" style="background-image:url(../images/Ok.gif);">
				<INPUT class=touchnoborder id=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" name=cancel onClick="cancelForm()">
			</td>
		</tr>
	</TABLE>
</FORM>   

</BODY>
</HTML>
