<%@ Language=VBScript %>
<% Server.ScriptTimeout = 600 %>

<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%

	dim ccprocessor
	dim customerSequenceNumber
	dim ticketNumbers
	dim ccfields
	dim amount
	dim signatureid
	dim code
	dim result
	dim transactionID
	dim cardTypeID
	dim transactionType
	dim terminalID
	dim storeID
	dim employeeID
	
	storeID = getReqVar("storeID")
	terminalID = getReqVar("terminalID")
	employeeID = getReqVar("employeeID")
	
	customerSequenceNumber = getReqVar("customerSequenceNumber")
	ticketNumbers = replace(getReqVar("ticketNumbers"), "'", "")
	amount = getReqVar("transactionAmt")
	signatureid = getReqVar("signatureid")
	transactionID = getReqVar("transactionID")
	cardTypeID = getReqVar("cardTypeID")
	transactionType = getReqVar("transactionType")

	set ccprocessor = Server.CreateObject("ShahcorpComponents.creditCardProcessing")
	set ccfields = Session("ccfields")
		
	ccprocessor.XChargeDirectory = getMSVar("XChargePath")
	if not isnull(getMSVar("XChargePathKeyed")) then
		ccprocessor.XChargeDirectoryKeyed = getMSVar("XChargePathKeyed")
	end if
	ccprocessor.XChargeTimeout = getMSVar("XChargeTimeout")

	result = (processTransaction(customerSequenceNumber, ticketNumbers, ccfields, amount, signatureid, transactionType, code) = "True")

	function getMSVar(id)
		dim query, rs
		
		query = "select " & id & " from miscsetup where storeid = " & storeID
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)
		
		set rs = nothing
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	


	function processTransaction(customerSequenceNumber, ticketNumbers, ccfields, amount, signatureid, transactionType, code)
		processTransaction = ccprocessor.ProcessFullTransaction(storeid,terminalid,employeeid,customerSequenceNumber, ticketNumbers, ccfields, amount, signatureid, transactionType, code)
	end function
	
	function d_rackTable()
		dim query, rs
		dim invoiceNumbers
		dim invoiceNumber
		dim rackLocations
		
		if transactionID <> "" then
			invoiceNumbers = split(transactionID, ",")
			
			Response.Write "<TABLE style=""width:500px;margin:50px;background:white;border:2px inset"">"
			Response.Write "<TR>"
			Response.Write "<TH style=""height:40px"" align=""center"">Invoice</TH>"
			Response.Write "<TH style=""height:40px"" align=""center"">Rack Location(s)</TH>"
			Response.Write "</TR>"
			for each invoiceNumber in invoiceNumbers
				query = "select dbo.pivotTicketRackLocationBrief(" & invoiceNumber & ", ',') as rackLocations"
				set rs = getdisconnectedrecordset(query)
				
				
				if rs.recordcount > 0 then
					rackLocations = rs("rackLocations")
					query = "select invoicenumber from ticket where ticketnumber = " & invoiceNumber
					set rs = getdisconnectedrecordset(query)
					
					Response.Write "<TR>"
					Response.Write "<TD align=""center""><H2>" & rs("invoicenumber") & "</H2></TD>"
					Response.Write "<TD align=""center""><H2>" & rackLocations & "</H2></TD>"

					Response.Write "</TR>"
				end if
				
			next
		
			Response.Write "</TABLE>"
		end if
	end function
	

	function addLeadingZeros(value, leadingZeros)
		value = CStr(value)
		
		while len(value) < leadingZeros
			value = "0" & value
		wend
		
		addLeadingZeros = value
	end function
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Process Credit Card</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>

<!-- #include file="../include/signaturepad.inc" -->

<script language="javascript" type="text/javascript">
	
	function submitForm() {
		window.close();
		<% if ticketNumbers <> "" then %>
		window.opener.cct_complete_tickets(
			document.creditCardWaiting.result.value,
			document.creditCardWaiting.code.value,
			document.creditCardWaiting.cardTypeID.value,
			document.creditCardWaiting.amount.value,
			document.creditCardWaiting.transactionType.value);
		<% else %>
		window.opener.cct_complete(
			document.creditCardWaiting.result.value,
			document.creditCardWaiting.code.value,
			document.creditCardWaiting.cardTypeID.value,
			document.creditCardWaiting.amount.value,
			document.creditCardWaiting.transactionType.value);
		<% end if %>
	}
	
	function printReceipt() {
	<%if result <> "" then
		if result then
	%>
		PrintCreditReceipt(
		"<%=transactionID%>",
		"<%=code%>",
		"<%=(addLeadingZeros(ccfields.expirationyear, 2) & addLeadingZeros(ccfields.expirationmonth,2))%>",
		"",
		"<%=ccfields.accountnumber%>",
		"<%=trim(ccfields.firstname & " " & ccfields.lastname)%>",
		"<%=amount%>");
	<%  end if
    end if %>
	}
	
	function promptOnSigPad() {
	<%if result then%>
    	SigPad_DisplayText("\\n\\n\\n\\nCard Accepted\\n<%=code%>");
	<%else%>
    	SigPad_DisplayText("\\n\\n\\n\\nCard Declined\\n<%=code%>");
	<%end if%>
	}
	
	function doOnLoad() {
			setTimeout('submitForm()', 15000);
	    printReceipt();
	    promptOnSigPad();
	}
	
	function retry() {
	    document.creditCardWaiting.action = "/mainapp/creditCardWaiting.asp" +
				"?transactionAmt=<%=amount%>" +
				"&transactionID=<%=transactionID%>" +
				"&cardTypeID=<%=cardTypeID%>" +
				"&customerSequenceNumber=<%=customerSequenceNumber%>" +
				"&ticketNumbers=<%=ticketNumbers%>" +
				"&transactionType=<%=transactionType%>";
        document.creditCardWaiting.submit();
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0 	onload="doOnLoad()">

<!-- #include file="../include/fakebanner.inc" -->
<!-- #include file="../include/localprinter.inc" -->

<B class="pageHeading">Response</B>

<FORM id="creditCardWaiting" name="creditCardWaiting" action="" method="post">
<INPUT type="hidden" name="result" value="<%=result%>">
<INPUT type="hidden" name="code" value="<%=code%>">

<INPUT type="hidden" name="cardTypeID" value="<%=cardTypeID%>">
<INPUT type="hidden" name="transactionType" value="<%=transactionType%>">	

<INPUT type="hidden" name="amount" value="<%=amount%>">		
<INPUT type="hidden" name="transactionAmt" value="<%=amount%>">

<INPUT type="hidden" name="customerSequenceNumber" value="<%=customerSequenceNumber%>">
<INPUT type="hidden" name="ticketNumbers" value="<%=ticketNumbers%>">	
<INPUT type="hidden" name="signatureid" value="<%=signatureid%>">	
<INPUT type="hidden" name="transactionID" value="<%=transactionID%>">	


	
<CENTER>
<TABLE align=center border=0 width=350px cellspacing=0 cellpadding=5>
	<%if result then%>
	<TR style="background:green;color:white;height:50px" ><TD align=center>Credit Card Authorized</TD></TR>
	<TR style="height:50px">
	<TD align=center style="border:1px solid green">
	<%=code%>
	</TD>
	</TR>
	<%else%>
	<TR style="background:red;color:white;height:50px"><TD align=center>Credit Card Authorization Failed</TD></TR>
	<TR style="height:50px"><TD align=center style="border:1px solid red"><%=code%></TD></TR>		
	<%end if%>
	
	
	
	<%if result then%>
	<TR style="background:green">
	<%else%>
	<TR style="background:red">
	<%end if%>
		<TD align=center>
			<%if result then%>
			<input type="button" style="width:100px;height:50px" value="Print Receipt" onclick="printReceipt()">
			<%else%>
			<input type="button" style="width:100px;height:50px" value="Retry" onclick="retry()">
			<%end if%>
			<INPUT style="width:100px;height:50px" type=button value="Ok" onClick="submitForm()">
		</TD>
	</TR>
</TABLE>
	
<%=d_rackTable()%>

</CENTER>

</FORM>
</BODY>
</HTML>

<%

	
	



%>
