<%@ Language=VBScript %>
<%option explicit%>
<%
	dim dbname
	
	dbname = request.querystring("dbname")
	if dbname = "" then dbname = "default"
%>

<!--#include file="../include/SystemStartup.asp"-->
<% selectDatabase dbname %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->
<!--#include file="../include/json.asp"-->

<%
	dim query, rs
	dim limit
	dim start
	
	dim storeID
	dim terminalID
	dim employeeID
	dim customerSeq
	dim rkey
	dim routeNumber
	dim invoiceNumber
	dim sentElec
	dim overwritePrinter, overwriteDriver
	dim releaseOnly

	if request.querystring("electronic") <> "" then
		sentElec = true
	else
		sentElec = false
	end if

	if request.querystring("limit") <> "" then
		limit = request.querystring("limit")
	else
		limit = null
	end if
	
	if request.querystring("start") <> "" then
		start = request.querystring("start")
	else
		start = null
	end if

	
	if request.querystring("terminalid") <> "" then
		terminalID = request.querystring("terminalid")
	else
		terminalID = session("terminalid")
	end if

	if request.querystring("employeeID") <> "" then
		employeeID = request.querystring("employeeID")
	else
		employeeID = session("employeeID")
	end if

	if request.querystring("customerSeq") <> "" then
		customerSeq = request.querystring("customerSeq")
	else
		customerSeq = session("customersequencenumber")
	end if

	rkey = request.querystring("key")
	if rkey = "" then
		rkey = request.querystring("ticketnumber")
	end if
	
	if rkey = "" and request.querystring("invoicenumber") <> "" then
		rkey = getTicketNumber(request.querystring("invoicenumber"))
	end if
	
	if rkey = "" and request.querystring("hsn") <> "" then
		rkey = hsNumToTicketNum(request.querystring("hsn"))
	end if
	
	invoiceNumber = request.querystring("invoicenumber")
	
	storeID = getStoreID(terminalID)
	
	select case request.querystring("type")
	case "quick"
		response.write getGenericPrinter(request.querystring("type"), "2", rkey)
	case "detailed"
		response.write getGenericPrinter(request.querystring("type"), "3", rkey)
	case "pdf"
		response.write getPDF(rkey)
	case "counter"
		response.write getGenericPrinter(request.querystring("type"), "4", rkey)
	case "edit"
		response.write getGenericPrinter(request.querystring("type"), "1", rkey)
	case "pickup"
		response.write getGenericPrinter(request.querystring("type"), "0", rkey)
	case "tag"
		response.write getGenericPrinter(request.querystring("type"), "5,6", rkey)
	case "heatseal"
		response.write getGenericPrinter(request.querystring("type"), "7", rkey)
	case "rackslip"
		response.write getGenericPrinter(request.querystring("type"), "12", rkey)
	case "bagtag"
		response.write getGenericPrinter(request.querystring("type"), "10", customerSeq)
	case "creditcard"
		response.write getGenericPrinter(request.querystring("type"), "8", rkey)
	end select

	

	function getPrintGroupForTickets(ticketNumbers)
		dim query, rs
		dim result
		
		query = query & " select distinct department.printgroup "
		query = query & " from ticketlineitem "
		query = query & " inner join Department on ticketlineitem.departmentID = department.departmentID "
		query = query & " where ticketlineitem.ticketNumber in (" & ticketNumbers & ") "
		
		set rs = getdisconnectedrecordset(query)
		
		while not (rs.eof or rs.bof)
			if result <> "" then result = result & ","
			result = result & rs(0)
			rs.movenext
		wend
		
		set rs = nothing
		
		getPrintGroupForTickets = result
	end function
	
	function getLotForTickets(ticketNumbers)
		dim query, rs
		dim result
				
		query = query & " select distinct lot.Name "
		query = query & " from Ticket "
		query = query & " inner join Lot on ticket.LotID = lot.ID "
		query = query & " where ticket.ticketNumber in (" & ticketNumbers & ") "
		
		set rs = getdisconnectedrecordset(query)
		
		while not (rs.eof or rs.bof)
			if result <> "" then result = result & ","
			result = result & rs(0)
			rs.movenext
		wend
		
		set rs = nothing
		
		getLotForTickets = result
	end function
	
	function getRoutesForTickets(ticketNumbers)
		dim query, rs
		dim result
		
		query = query & " select distinct route.name "
		query = query & " from Route "
		query = query & " inner join Ticket on ticket.routeNumber = route.routeNumber "
		query = query & " where ticket.ticketNumber in (" & ticketNumbers & ") "
		
		set rs = getdisconnectedrecordset(query)
		
		while not (rs.eof or rs.bof)
			if result <> "" then result = result & ","
			result = result & rs(0)
			rs.movenext
		wend
		
		set rs = nothing
		
		getRoutesForTickets = result
	end function
	
	
	function applyPrinterModifiers(record, printerid, ticketnumbers)
		dim query, rs
		dim c, cf
		
		query = " select * from printermodifier where printerid = '" & dbstr(printerid) & "'"
		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
			select case lcase(rs("triggersource"))
			case "printgroup"
				c = getPrintGroupForTickets(ticketnumbers)
			case "lot"
				c = getLotForTickets(ticketnumbers)
			case "route"
				c = getRoutesForTickets(ticketnumbers)
			end select
			
			c = lcase(c)

			select case lcase(rs("triggercriteria"))
			case "ct"
				cf = (instr(c, lcase(rs("triggervalue").value)) > 0)
			case "nct"
				cf = not (instr(c, lcase(rs("triggervalue").value)) > 0)
			end select

			if cf then
				select case lcase(rs("targetfield"))
				case "copies"
					if record.exists("copies") then
						record.remove("copies")
					end if
					
					record.add "copies", trim(rs("targetvalue").value)
				case "form"

				end select
			end if

			
			rs.movenext
		wend
		
		set rs = nothing
	end function
	


		function checkForOverwriteURLFields(printerid, ticketnumbers)
    		dim query, rs
    		dim c, cf

    		query = " select * from printermodifier where printerid = '" & dbstr(printerid) & "'"

    		set rs = getdisconnectedrecordset(query)

    		while not(rs.eof or rs.bof)
    			select case lcase(rs("triggersource"))
    			case "printgroup"
    				c = getPrintGroupForTickets(ticketnumbers)
    			case "lot"
    				c = getLotForTickets(ticketnumbers)
    			case "route"
    				c = getRoutesForTickets(ticketnumbers)
    			end select

    			c = lcase(c)

    			select case lcase(rs("triggercriteria"))
    			case "ct"
    				cf = (instr(c, lcase(rs("triggervalue").value)) > 0)
    			case "nct"
    				cf = not (instr(c, lcase(rs("triggervalue").value)) > 0)
    			end select

    			if cf then
    				select case lcase(rs("targetfield"))
    				case "printer"
    					overwritePrinter = trim(rs("targetvalue").value)
                    case "driver"
                        overwriteDriver = trim(server.urlencode(rs("targetvalue").value))
    				end select
    			end if
    			rs.movenext
    		wend

    		set rs = nothing
    	end function


	
	function hsNumToTicketNum(hsnumber)
		dim sqltxt, rs

		sqltxt = "select max(t.ticketnumber) as ticketnumber "
		sqltxt = sqltxt + "from ticket t, ticketlineitemtaggeditem tliti, taggedpiece tp "
		sqltxt = sqltxt + "where t.ticketnumber = tliti.ticketnumber "
		sqltxt = sqltxt + "and tliti.taggeditemid = tp.taggeditemid "
		sqltxt = sqltxt + "and t.ticketstatus = 'AC' "
		sqltxt = sqltxt + "and tp.heatsealid = '" + hsnumber + "'"
   		set rs = getdisconnectedrecordset(sqltxt)

		if rs.recordcount > 0 then
		        hsNumToTicketNum = rs("ticketnumber")
     	end if

     	set rs = nothing
	end function
	
	function getTicketRoute(ticketNumber)
		dim query, rs

		getTicketRoute = 0
		
		if ticketNumber <> "" then
			query = " select routenumber from ticket where ticketnumber in  (" & ticketNumber & ")"
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getTicketRoute = rs(0)
			end if
			
			set rs = nothing
		end if
	end function
	
	function getInvoiceType(ticketNumber)
		dim query, rs

		getInvoiceType = ""
		
		if ticketNumber <> "" then
			query = " select invoicetype from ticket where ticketnumber in (" & ticketNumber & ")"
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getInvoiceType = rs("invoicetype")
			end if
			
			set rs = nothing
		end if
	end function

	function getStoreID(terminalID)
		dim query, rs

		getStoreID = 0
		
		if terminalID <> "" then
			query = " select storeid from terminal where terminalid = " & terminalID
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getStoreID = rs("storeid")
			end if
			
			set rs = nothing
		end if
	end function
	
	function getTicketTicketNumber(invoiceNumber)
		dim query, rs
		
		query = " select ticketnumber from ticket where invoicenumber = '" & dbstr(invoiceNumber) & "'"
		set rs = getdisconnectedrecordset(query)
		
		getTicketTicketNumber = 0
		
		if rs.recordcount > 0 then
			getTicketTicketNumber = rs("ticketnumber")
		end if
		
		set rs = nothing
	end function
	
	function getTicketNumberLI(invoiceNumber)
		dim query, rs
		
		query = " select ticketnumber from ticketlineitem where invoicenumber = '" & dbstr(invoiceNumber) & "'"
		set rs = getdisconnectedrecordset(query)
		
		getTicketNumberLI = 0
		
		if rs.recordcount > 0 then
			getTicketNumberLI = rs("ticketnumber")
		end if
		
		set rs = nothing
	end function
	
	
	function getTicketNumber(invoiceNumber)
		dim result
		
		result = getTicketTicketNumber(invoiceNumber)
		if result <= 0 then
			result = getTicketNumberLI(invoiceNumber)
		end if
		
		getTicketNumber = result
	end function
	
	
	function getPrinterDriver(rs)
	    if overwriteDriver <> "" then
	        getPrinterDriver = overwriteDriver
		elseif rs("u200") then
			select case trim(rs("u200type").value)
			case "0"
				getPrinterDriver = "u200"
			case "1"
				getPrinterDriver = "sp500"
			case "2"
				getPrinterDriver = "u200dbl"
			case "3"
				getPrinterDriver = "sp500dbl"
			case "4"
				getPrinterDriver = "bixolon"
			case "5"
				getPrinterDriver = "bixolondbl"
			case else
				getPrinterDriver = "windows"
			end select
		else
			getPrinterDriver = "windows"
		end if
	end function
	
	function getTagUrls(urls, ticketNumbers, pt, pid, rs)
		dim tagNumbers
		dim tagNumbersArray
		dim url
		dim i
		dim tagDesc


		tagNumbers = getAllTagNumbers(terminalID, ticketNumbers, pid)
		tagNumbersArray = split(tagNumbers, ",")


		redim urls(ubound(tagNumbersArray))
		
		for i = lbound(tagNumbersArray) to ubound(tagNumbersArray)

			tagDesc = split(tagNumbersArray(i), "|||")
			
			url = "http://" & Request.ServerVariables("LOCAL_ADDR") & "/mainapp/getrtf.asp?db=default"
		    url = url & "&key=" & trim(tagDesc(0))
		    url = url & "&tag=" & trim(tagDesc(1))
		    url = url & "&pt=" & pt
		    url = url & "&pid=" & pid
		    url = url & "&emp=" & employeeID
		    url = url & "&cust=" & customerSeq
		    url = url & "&store=" & storeID
		    url = url & "&terminal=" & terminalID
		    url = url & "&dbname=" & dbname
		    url = url & "&driver=" & getPrinterDriver(rs)


		    if overwritePrinter <> "" then
		        url = url & "&overwritePrinter=" & trim(server.urlencode(overwritePrinter))
            end if

		    urls(i) = url
		next
	end function

	function getAltRoutePrinter(p_rs, terminalID, printerTypeNumber, routeNumber)
		dim rs
		dim pTypeNum
		
		set getAltRoutePrinter = p_rs
		
		if printerTypeNumber = 1 then
			pTypeNum = 3
		else
			pTypeNum = printerTypeNumber
		end if
		
		if pTypeNum = 3 and routeNumber > 0 then
			query = " select printertypedomain.printertypenumber, printer.*, case when printertypedomain.printertype like '% 1' then 1 else 0 end as combined "
			query = query & " from printer "
			query = query & " inner join printertypedomain on printer.printertype = printertypedomain.printertype "
			query = query & " inner join storehardware on printer.hardwareid = storehardware.hardwareid and storehardware.terminalid = " & terminalID
			query = query & " where printertypedomain.printertypenumber in (" & pTypeNum & ")"
			query = query & " and printer.printertype like 'route%' "
			query = query & " and printer.routenumber is null or printer.routenumber = " & routeNumber

			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				if lcase(rs("printertype")) = "route printer" and lcase(p_rs("printertype")) = "detailed invoice 2" then
					set getAltRoutePrinter = nothing
				else
					set getAltRoutePrinter = rs
				end if
				
				
			end if
		end if		
		
	end function
	

	function getMSVar(storeid, id)
		dim query, rs
		
		query = "select " & id & " from miscsetup where storeid = " & storeid
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)
		
		set rs = nothing
	end function
	
	
	function getReleaseForms(ticketCSV)
		dim query
		
		
		query = query & " select distinct pricelistitem.itemReleaseInvoiceFormName as [formname] from TicketLineItem "
		query = query & " inner join PriceListItem on ticketlineitem.lineItemID = pricelistitem.priceListItemID  "
		query = query & " where ticketlineitem.ticketLineType = 'IT' and ticketNumber in (" & ticketCSV & ") "
		query = query & " and pricelistitem.itemReleaseInvoiceFormName is not null and pricelistitem.itemReleaseInvoiceFormName <> ''"

		set getReleaseForms = getdisconnectedrecordset(query)
	end function

	function getReleaseFormsForQuick(ticketCSV)
		dim query

		query = "select distinct department.itemReleaseInvoiceForm as [formname] from TicketLineItem " _
		    & " inner join Department on ticketlineitem.departmentId = Department.departmentID  " _
		    & " where ticketlineitem.ticketLineType = 'DE' and ticketNumber in (" & ticketCSV & ") " _
		    & " and department.itemReleaseInvoiceForm is not null and department.itemReleaseInvoiceForm <> ''"

		set getReleaseFormsForQuick = getdisconnectedrecordset(query)
	end function

	function getGenericPrinter(printerType, printerTypeNumber, keyCSV)
		dim query, rs
		dim url
		dim urls()
		dim record
		dim records()
		dim i, j
		dim keyIdx
		dim json_writer
		dim keyArr
		dim invoiceType
		dim desc
		dim routeNumber
		dim p_rs
		dim releaseRS, releaseIdx

		randomize

		if printerTypeNumber = "3" and getInvoiceType(keyCSV) = "Q" then
			printerType = "quick"
			printerTypeNumber = 2
		end if

		routeNumber = getTicketRoute(keyCSV)

		query = " select printertypedomain.printertypenumber, printer.*, case when printertypedomain.printertype like '% 1' then 1 else 0 end as combined "
		query = query & " from printer "
		query = query & " inner join printertypedomain on printer.printertype = printertypedomain.printertype "
		query = query & " inner join storehardware on printer.hardwareid = storehardware.hardwareid "
		query = query & " where storehardware.terminalid = " & terminalID
		query = query & " and printertypedomain.printertypenumber in (" & printerTypeNumber & ")"
		query = query & " and printer.printertype not in ('route printer', 'route tag printer', 'route tag printer 2') "

		
		set rs = getdisconnectedrecordset(query)
		
		
		
		redim records(rs.recordcount - 1)
		i = 0

		keyArr = split(keyCSV, ",")
		
		while not (rs.eof or rs.bof)
			
			set p_rs = getAltRoutePrinter(rs, terminalID, printerTypeNumber, routeNumber)
			
			
			
			if p_rs is nothing then
			
			elseif p_rs("numcopies") = 0 and not (printerTypeNumber = 3 and getMSVar(storeID, "alwaysPrintReleases")) then

			else
				
				set record = Server.CreateObject("Scripting.Dictionary")
				
				desc = cstr(p_rs("printertype"))
				if printerType <> "bagtag" then
					checkForOverwriteURLFields p_rs("printerid"), keyCSV
				end if

				select case printerType
				case "tag"
					getTagUrls urls, keyCSV, p_rs("printertypenumber"), p_rs("printerid"), rs
				case "bagtag"
					redim urls(0)
					
					url = "http://" & Request.ServerVariables("LOCAL_ADDR") & "/mainapp/getrtf.asp?db=default"
				    url = url & "&pt=" & printerTypeNumber
				    url = url & "&pid=" & p_rs("printerid")
				    url = url & "&emp=" & employeeID
				    url = url & "&cust=" & customerSeq
				    url = url & "&store=" & storeID
				    url = url & "&terminal=" & terminalID
		    		url = url & "&dbname=" & dbname
		            url = url & "&driver=" & getPrinterDriver(rs)

				    urls(0) = url
				case "pickup", "rackslip"
					redim urls(0)
					
					url = "http://" & Request.ServerVariables("LOCAL_ADDR") & "/mainapp/getrtf.asp?db=default"
				    url = url & "&key=" & trim(keyArr(0))
				    url = url & "&pickup=" & keyCSV
				    url = url & "&pt=" & printerTypeNumber
				    url = url & "&pid=" & p_rs("printerid")
				    url = url & "&emp=" & employeeID
				    url = url & "&cust=" & customerSeq
				    url = url & "&store=" & storeID
				    url = url & "&terminal=" & terminalID
		    		url = url & "&dbname=" & dbname
		            url = url & "&driver=" & getPrinterDriver(rs)

				    urls(0) = url
				case "creditcard"
                    if keyCSV <> "" then

                    dim query2, rs2

                        query2 = "select a.transactionId from Cardpayment a, payment b, ticketlog c where " _
                            & "c.ticketNumber in (" & keyCSV & ") " _
                            & "and c.paymentGroupNumber = b.paymentGroupNumber and b.paymentTypeName = 'Credit Card' and " _
                            & "(b.transactionNumber = a.transactionId or (b.customerSequenceNumber = a.customerSequenceNumber and a.rawAnswer like concat('%<APPROVALCODE>', RTRIM(LTRIM(b.approvalCode)), '</APPROVALCODE>%') ))"
                    	set rs2 = getdisconnectedrecordset(query2)

                    	if rs2.recordcount > 0 then
                            redim urls(rs2.recordcount - 1)
                            keyIdx = 0
                            while not rs2.eof

                            url = "http://" & Request.ServerVariables("LOCAL_ADDR") & "/mainapp/getForm.asp?db=default&formname=" & server.urlencode(p_rs("formname"))
                             url = url & "&transactionid=" & rs2("transactionId")
                             url = url & "&voidpaymentid=" & request.querystring("voidpaymentid")
                             url = url & "&driver=" & getPrinterDriver(rs)
                             url = url & "&pid=" & p_rs("printerid")

                                urls(keyIdx) = url
                                keyIdx = keyIdx + 1
                                rs2.MoveNext
                            wend
                        end if

                    else
					    Redim urls(0)
						url = "http://" & Request.ServerVariables("LOCAL_ADDR") & "/mainapp/getForm.asp?db=default&formname=" & server.urlencode(p_rs("formname"))
                        url = url & "&transactionid=" & request.querystring("transactionid")
                        url = url & "&voidpaymentid=" & request.querystring("voidpaymentid")
                        url = url & "&driver=" & getPrinterDriver(rs)
                        url = url & "&pid=" & p_rs("printerid")
					    urls(0) = url
		            end if
				case else
                    redim urls(0)
				    if p_rs("numcopies") > 0 then
					if (p_rs("combineInvoices") = 1 and (getMSVar(storeID, "combineSplitDetailed") and p_rs("combined") = "1" and routeNumber = "0")) _
					or (p_rs("combineInvoices") = 2 and clng(routeNumber) = 0) _
					or (p_rs("combineInvoices") = 4 and clng(routeNumber) > 0) _
					or (p_rs("combineInvoices") = 6) _
					then

						url = "http://" & Request.ServerVariables("LOCAL_ADDR") & "/mainapp/getrtf.asp?db=default"
					    url = url & "&key=" & trim(keyArr(0))
					    url = url & "&pickup=" & keyCSV
					    url = url & "&pt=" & 0
					    url = url & "&pid=" & p_rs("printerid")
					    url = url & "&emp=" & employeeID
					    url = url & "&cust=" & customerSeq
					    url = url & "&store=" & storeID
					    url = url & "&terminal=" & terminalID
					    url = url & "&invoiceNumber=" & invoiceNumber
					    url = url & "&dbname=" & dbname
		                url = url & "&driver=" & getPrinterDriver(rs)

                            urls(0) = url
                        else
                            redim urls(ubound(keyArr))

                            for keyIdx = lbound(keyArr) to ubound(keyArr)
                                invoiceType = getInvoiceType(keyArr(keyIdx))

                                url = "http://" & Request.ServerVariables("LOCAL_ADDR") & "/mainapp/getrtf.asp?db=default"
                                url = url & "&key=" & trim(keyArr(keyIdx))
                                if invoiceType = "Q" then
                                    url = url & "&pt=2"
                                else
                                    url = url & "&pt=" & printerTypeNumber
                                end if
                                url = url & "&pid=" & p_rs("printerid")
                                url = url & "&emp=" & employeeID
                                url = url & "&cust=" & customerSeq
                                url = url & "&store=" & storeID
                                url = url & "&terminal=" & terminalID
                                url = url & "&invoiceNumber=" & invoiceNumber
                                url = url & "&dbname=" & dbname
                                url = url & "&driver=" & getPrinterDriver(rs)

                                urls(keyIdx) = url
                            next
                        end if
                    else
                        releaseOnly = 1
			    	end if
			 end select
    	
				
				if rs("isDemandPrinter") and releaseOnly <> 1 then
					for j = lbound(urls) to ubound(urls)
						urls(j) = urls(j) & "&appendcoupons=1"
					next
				end if

			  if lcase(desc) = "detailed invoice 1" then
			  	set releaseRS = getReleaseForms(keyCSV)
			  	
			  	if releaseRS.recordcount > 0 then
			  	
			  		releaseIdx = ubound(urls)
			  		redim preserve urls(releaseIdx + (releaseRS.recordcount * 2))

					releaseIdx = releaseIdx + 1
					
			  		while not(releaseRS.eof or releaseRS.bof)
						url = "http://" & Request.ServerVariables("LOCAL_ADDR") & "/mainapp/getForm.asp?db=default&formname=" & server.urlencode(releaseRS("formname"))
						url = url & "&cust=" & customerSeq
						url = url & "&emp=" & employeeID
						url = url & "&tnum=" & keyArr(0)
				        url = url & "&pid=" & p_rs("printerid")
				        url = url & "&driver=windows"

						
						urls(releaseIdx) = url
						urls(releaseIdx + 1) = url
						
			  			releaseIdx = releaseIdx + 2
			  			releaseRS.movenext
			  		wend
			  	
			  		set releaseRS = nothing
			  	end if

			  elseif printerType = "quick" then
			  	set releaseRS = getReleaseFormsForQuick(keyCSV)

			  	if releaseRS.recordcount > 0 then

			  		releaseIdx = ubound(urls)
			  		redim preserve urls(releaseIdx + (releaseRS.recordcount * 2))

					releaseIdx = releaseIdx + 1

			  		while not(releaseRS.eof or releaseRS.bof)
						url = "http://" & Request.ServerVariables("LOCAL_ADDR") & "/mainapp/getForm.asp?db=default&formname=" & server.urlencode(releaseRS("formname"))
						url = url & "&cust=" & customerSeq
						url = url & "&emp=" & employeeID
						url = url & "&tnum=" & keyCSV
				        url = url & "&pid=" & p_rs("printerid")
				        url = url & "&driver=windows"

						urls(releaseIdx) = url
						'Unlike the other releases, for quick we're only printing it once for now
						'Some discussion about making this a setting for both it and item releases instead
						'but for now not deemed worth doing
			  			releaseIdx = releaseIdx + 1
			  			releaseRS.movenext
			  		wend

			  		set releaseRS = nothing
			  	end if

			  end if


				for keyIdx = lbound(keyArr) to ubound(keyArr)
					AddTicketEvent keyArr(keyIdx), employeeID, "PRINT", left(desc, 16), "Printed " & desc & " on " & cstr(p_rs("printername"))
				next
	
				record.add "id", clng(2000000000 * rnd)
				record.add "type", "application/rtf"
				if releaseOnly = 1 then
				    record.add "copies", 1
				else
				    record.add "copies", clng(p_rs("numcopies"))
				end if
				record.add "description", desc
				record.add "driver", getPrinterDriver(rs)
				record.add "printer", cstr(p_rs("printername"))
				record.add "url", urls

				if printerType <> "bagtag" then
					applyPrinterModifiers record, p_rs("printerid"), keyCSV
				end if

                if sentElec and p_rs("promptAfterSms") then
                    record.add "smsPrompt", 1
                else
                    record.add "smsPrompt", 0
                end if

				
				if p_rs("promptbeforeprint") then
					record.add "prompt", 1
				else
					record.add "prompt", 0
				end if
				
				set records(i) = record
				i = i + 1
				
			end if
			
			
			rs.movenext
		wend
		
		redim Preserve records(i)
		
		set rs = nothing

		set json_writer = new JSON
		getGenericPrinter = json_writer.toJSON("jobs", records, false, null)
	end function


	function getPDF(keyCSV)
	    dim keyArr, url, urls(), record, records(), keyIdx, json_writer

	    keyArr = split(keyCSV, ",")
	    set record = Server.CreateObject("Scripting.Dictionary")
	    redim urls(ubound(keyArr))
	    keyIdx = 0
	    for keyIdx = lbound(keyArr) to ubound(keyArr)

            url = "http://" & Request.ServerVariables("LOCAL_ADDR") & "/mainapp/getRTF.asp?db=default"
            url = url & "&key=" & getTicketNumber(keyArr(keyIdx))
            url = url & "&emp=" & employeeID
            url = url & "&cust=" & customerSeq
            url = url & "&store=" & storeID
            url = url & "&terminal=" & terminalID
            url = url & "&type=pdf"
            url = url & "&pt=3"
            url = url & "&formname=" & server.urlencode("Invoice PDF")
            urls(keyIdx) = url
       next


       record.add "type", "application/pdf"
       record.add "copies", 1
       record.add "printer", "pdf"
       record.add "url", urls

       redim records(0)
       set records(0) = record
       set json_writer = new JSON

       getPDF = json_writer.toJSON("jobs", records, false, null)

	end function

	
	function AddTicketEvent(ticketNumber, employeeID, eventType, eventTypeEx, desc)
		dim query
		
		query = " exec dbo.AddTicketEvent " & ticketNumber & ", " & employeeID & ", '" & dbstr(eventType) & "', '" & dbstr(eventTypeEx) & "', '" & dbstr(desc) & "'"
		qryexecute query
	
	end function
	


	function getPrinterPrintGroup(printerID)
		dim query, rs, result
		
		query = " select printGroup from printer where printerid = " & printerID
		set rs = getdisconnectedrecordset(query)
		
		result = null
		
		if rs.recordcount > 0 then
			result = "'" & rs("printGroup") & "'"
		end if
		
		query = "select TriggerValue from printerModifier where printerId = " & printerId & " and triggerSource = 'printGroup'"
		set rs = getdisconnectedrecordset(query)
		while not rs.EOF
		    result = result & ",'" & rs("TriggerValue") & "'"
		    rs.MoveNext
        wend
		set rs = nothing
		getPrinterPrintGroup = result

	end function
	
	function getAllTagNumbers(terminalID, ticketNumber, tagPrinter)
		dim query, rs
		dim exclusiveDepartment
		dim result
		dim printGroup
		
		printGroup = getPrinterPrintGroup(tagPrinter)
		
		query = " select tickettag.ticketNumber, tickettag.tagnumber "
		query = query & " from tickettag "
		query = query & " left outer join department on tickettag.departmentid = department.departmentid "
		query = query & " where tickettag.ticketnumber in (" & ticketNumber & ")"
		
		if not isnull(printGroup) then
			query = query & " and department.printgroup in (" & printGroup & ")"
		end if
		
		query = query & " ORDER BY department.name, TicketTag.departmentID, CASE dbo.isInt(TicketTag.tagNumber) WHEN 1 THEN CONVERT(int, TicketTag.tagNumber) ELSE -1 END "

		set rs = getdisconnectedrecordset(query)
		
		result = ""
		
		while not (rs.eof or rs.bof)
			if result <> "" then result = result & ", "
			result = result & rs("ticketNumber") & "|||" & rs("tagNumber")
			rs.movenext
		wend
		
		set rs = nothing
		
		getAllTagNumbers = result
	end function

%>