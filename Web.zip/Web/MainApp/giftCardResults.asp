<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->

<%
	dim query, rs
	dim searchText
	dim customerSeq
	
	searchText = request.form("searchText")
	customerSeq = request.form("customerSeq")
	
	query = " select giftcardid, giftcardnumber, convert(varchar, expirationDate, 101) as expiration, giftvalue, isnull(customer.customername, '') as customername from giftcard "
	query = query & " left outer join customer on giftcard.customersequencenumber = customer.customersequencenumber "
	query = query & " where 1 = 1 "
	
	if searchText <> "" then
		query = query & " and giftcardnumber = '" & searchText & "'"
	end if

		
	if customerSeq <> "" then
		query = query & " and giftcard.customersequencenumber = " & customerSeq
	end if
	
	set rs = getdisconnectedrecordset(query)

%>


<TABLE class="itable" BORDER=0 CELLSPACING=0 CELLPADDING=0>
	<TR>
		<TH align="left">Card Number</TH>
		<TH align="left">Customer</TH>
		<TH align="left">Expires</TH>
		<TH align="left">Balance</TH>
	</TR>
	<%
		dim cnt
		
		cnt = 0
		
		if rs.recordcount <=0 then %>
	<TR>
		<TD colspan="4" align="center">
			No matching gift cards found.
		</TD>
	</TR>
	<% if searchText <> "" then %>
	<TR>
		<TD colspan="4" align="center">
			
			
			<button style="height: 50px;" onclick="createNewCard()">Create New Gift Card</button>&nbsp;
			<button style="height: 50px;" onclick="cancelNewCard(); doUpdate(); focusSearchField();">Cancel</button>
		</TD>
	</TR>
	<% end if %>
	<%	else
	
		while not rs.EOF
					
	%>
	<TR id="giftcard" cardnumber="<%=rs("giftcardnumber")%>" onClick="selectRow(this)">
		<TD><%=Server.HTMLEncode(MaskString(rs("giftcardnumber"), 4))%>&nbsp</TD>
		<TD><%=Server.HTMLEncode(rs("customername"))%>&nbsp</TD>
		<TD><%=Server.HTMLEncode(rs("expiration"))%>&nbsp</TD>
		<TD><%=formatcurrency(rs("giftvalue"))%></TD>
	</TR>
	<%
			if cnt mod 10 = 0 then response.flush
			rs.movenext
		wend
		

		set rs = nothing
		end if
	%>
</TABLE>


