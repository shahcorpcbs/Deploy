<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/EmployeeSecurity.asp" -->
<!-- #include file="../include/email.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim l_storeid
	dim isSubmitted 
	issubmitted = Request.QueryString("Submitted")
	if issubmitted then
		updateDatabase()
		Response.Redirect("start.asp")		
	end if
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">

<TITLE>Rack Error Messages</TITLE>
<link href="../script/setup.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript">
	function submitForm() {
		document.rackErrForm.action = "?Submitted=true";
		document.rackErrForm.submit();
	}
	
	function cancelForm(){
		document.rackErrForm.action = "\start.asp"
		document.rackErrForm.submit();
	}
	
	function checkAll(){
		if ( document.rackErrForm.chkRackId.length > 0) {
			i = 0;
			while (i < document.rackErrForm.chkRackId.length){
				if ( !document.rackErrForm.chkRackId(i).disabled )
					document.rackErrForm.chkRackId(i).checked = true;
				i++;
			}
		}
	}
	
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/localprinter.inc" -->
<B class="pageHeading">&nbsp;Rack Error Messages</B>
<FORM id="rackErrForm" name="rackErrForm" action="" Method = "post">
<input type= hidden name=pickup  value="<%=Request.querystring("pickup")%>">

<TABLE WIDTH= 650px BORDER=2 CELLSPACING=0 CELLPADDING=0 Style = "MARGIN-LEFT: 50px"><!-- header row -->
 <tr >
	<td align=left valign=top>
	<DIV STYLE="HEIGHT: 380px; OVERFLOW-X: auto; OVERFLOW-Y: auto; WIDTH: 655px" >
			<TABLE id = "rack" name = "rack" width = 100% style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =2 CELLSPACING=0>
			<tr><td width = 5></td>
				<td width = 120><B>Invoice Number</td>
				<td width = 100 align = middle><B>Rack Start</td>
				<td width = 100 align = middle><B>Group Start</td>
				<td width =100 align = middle><B>Rack End</td>
				<td width = 400 align = middle><B>Error Message</td>
			</tr>
			<%	dim listRack 
					dim sRackItem
					dim element
					dim arrtemp
					dim sInvoice
					dim srackStart
					dim srackGroupstart
					dim srackGroupEnd
					dim sMessage
					dim sValue					
					dim ArrElement 'vivek Issue 315
					dim InvCount 'vivek Issue 315
					dim sErrorMessage ' to print error message 
					InvCount = 0 
					set listRack =  Server.CreateObject("Scripting.Dictionary")
					if isobject(session("listRackMessage"))  then
						if not session("listRackMessage")is nothing then
							set listRack = session("listRackMessage")
							if isobject(listRack) and not listRack is nothing then															
								dim InvoiceRacked()  'vivek - Declaring an array of total invoices giving error Issue 315
								Redim InvoiceRacked(listRack.Count,2) 'vivek Issue 315
								sRackItem = listRack.Keys
								dim mon,dt,month1,day1
								mon="010203040506070809101112"
								dt="01020304050607080910111213141516171819202122232425262728293031"
								
								Month1=mid(mon,month(date) * 2-1,2)
								day1 = mid(dt,day(date) * 2-1,2)
								
								sErrorMessage = time() & " / "  & month1 & "-" & day1 & "-" & year(date) & vbTab  & Session("employeename") & vbcrlf  & vblf
																						
								for each element in sRackItem
				 					arrTemp = split(listRack(element), "|||")
				 					'Response.Write listRack(element)
									sInvoice = trim(arrtemp(0))
									srackStart = trim(arrtemp(1))
									srackGroupstart = trim(arrtemp(2))
									srackGroupEnd = trim(arrtemp(3))
									sMessage = trim(arrtemp(4))
									sValue = trim(arrtemp(5))																		
									
									'Included By vivek on 18 Feb 2003 Issue 315
									'This part of code will check for duplication of the Invoices with the same Rack Number
									'to prevent the primary key violation
									'Making all checkboxes disabled with the duplicate entries by resetting the value sValue = 1.
									Dim i
									for i = 0 to Ubound(InvoiceRacked)
										if (sInvoice = InvoiceRacked(i,1) and srackStart = InvoiceRacked(i,2)) then
											sValue = 1
											sMessage = "Invoice is racked to this location. It cannot be racked"
											exit for
										end if
									next
									InvCount = InvCount + 1
									InvoiceRacked(InvCount,1) = sInvoice
									InvoiceRacked(InvCount,2) = srackStart																		
									'end - vivek
								
									sErrorMessage = sErrorMessage  & sMessage & VbCrLf & vblf
									
					%>				<tr>
									<td >
									<INPUT type = checkbox name=chkRackId value= "<%=listRack(element)%>"
									<% if sValue = 1 then %>
										Disabled
									<%end if %>
									>
									</td>
									<td ><%=sInvoice%>&nbsp;</td>
									<td ><%=srackStart%>&nbsp;</td>
									<td ><%=srackGroupstart%>&nbsp;</td>
									<td ><%=srackGroupEnd%>&nbsp;</td>
									<td ><font color = red><b><%=sMessage%>&nbsp;</b></font></td>
									</tr>
							<% next
					end if
					end if
						'set Session("listRackMessage") = nothing
					end if
				%>
			
			
			</table>
		</DIV>
		<input type=hidden name="errormessage" value="<%=sErrorMessage%>">
		<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5>
		<tr>
		<td align= center >
			<INPUT class=touch   id=selectButton name=selectButton type=button onClick="checkAll()" style="background-image:url(../images/Select-All.gif);background-position=center"value=""><br>Select All
		</td>
		<td align= center >
		<INPUT class=touch id=btnPrint name=btnPrint type=button style="background-image:url(../images/Print-Invoice.gif);background-position:center" value="" onClick = "javascript:PrintRackErrors1();"><Br>Print Results
		</td>
		<td align=center>
			<INPUT class=touchnoborder   id=okButton name=okButton type=button style="background-image:url(../images/Ok.gif)" value=""
			<%'if Request.QueryString("hideError") = "1" then  disabled%>
				
			<% 'end if %>
			onClick="submitForm()">
		</td>
		<td align=center>
			<INPUT class=touchnoborder   id=cancelButton name=cancelButton type=button style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()" value="">
		</td>	</tr>
		</table>
		<br><BR>
	</td></tr>
	</TABLE></FORM>
</BODY>
</HTML>

<script language="JavaScript">
function PrintRackErrors1() {
		var sError;
		sError = document.rackErrForm.errormessage.value;
		PrintRackErrors(sError);
		//window.open('/mainapp/PrintRackError.asp?' + "tm=" + (new Date()).getTime(), 'resultsWindow', 'left=100,top=100,height=50,width=50,toolbar=no,menubar=no,resizable=no,scrollbars=no,status=no');
	}

</Script>
<%


	Function UpdateDatabase()
	dim sqltxt
	dim totalcount
	dim i 
	dim sInvoice
	dim srackStart
	dim srackEnd
	dim arrTemp
	dim bpickup
	
	Bpickup= request.Form("pickup")
	totalcount = 0
	totalcount = Request.Form("chkRackId").count
	
	dim lstEmailInvoice 
	
	set lstEmailInvoice = Server.CreateObject("Scripting.Dictionary")
	
	dbstartTrans()
	
	for i = 1 to totalcount 
		arrTemp = split( Request.Form("chkRackId")(i), "|||")
		sInvoice = trim(arrtemp(0))
		srackStart = trim(arrtemp(1))
		if srackstart = "" then
			srackStart = trim(arrtemp(2))
		end if
		srackEnd = trim(arrtemp(3))
		sqltxt = "INSERT INTO RackAssignment ([ticketNumber], [rackLocationStart], [rackLocationEnd], [rackedEmployeeID], [rackedDate],[storeID]) select  ticketnumber " _
							& "," & dbcreateqrystring(srackstart)_
							& "," & dbcreateqrystring(srackend)_
							& "," & session("employeeid")_
							& ", getdate()"_
							& " ," & session("storeid")_
							& " from ticket where invoicenumber = " & dbcreateqrystring(sInvoice)
		'Response.Write sqltxt
		qryexecutewithtrans(sqltxt)
		lstEmailInvoice.Add sInvoice & i, sInvoice
	next 
	dbendtrans()
	
	if trim(bpickup)  =  "1" then
		sendOrderEmail  lstEmailInvoice
	end if
	end function
	
	
function sendOrderEmail(lstEmailInvoice )
	
	dim sqltxt 
	dim rsEmail
	dim sEmailToAddress
	dim sEmailToName
	dim sEmailMessage
	dim sEmailSubject
	dim sEmailFrom
	dim sEmailFromAddress
	dim sInvoice
	dim listKeys
	dim element
	dim sCCName
	dim sCCAddress
	dim sBccName
	dim sBccAddress
	dim sAttachment1
	dim sAttachment2
	
	sAttachment2= ""
	sAttachment1 = ""
	sBccAddress = ""
	sBccName = ""
	sCCName = ""
	sccAddress = ""
	sEmailFrom = "Shahcorp"
	sEmailFromAddress = "Shahcorp"
	sEmailSubject = "Order Pickup Notification"
	
	listKeys = lstEmailInvoice.keys
	
	for each element in listKeys
	
		sinvoice = lstEmailInvoice(element)
		
		sqltxt = "select c.email, p.emailtext, c.Customername, t.invoicenumber from  " _
					& "ticket t , pricelist  p , customer c  where t.invoicenumber = " & dbcreateqrystring(trim(sInvoice)) _
					 & " and t.pricelistid = p.pricelistid and t.customersequencenumber = c.customersequencenumber " _
					 & " and  p.emailtext is not null and c.email is not null"
				 
		'Response.Write sqltxt				 
	
		set rsEmail = getDisconnectedRecordset(sqltxt)
	
		if rsEmail.recordcount > 0 then
	
			sEmailToAddress = rsEmail("email")	
			sEmailToName = rsEmail("Customername")
			sEmailMessage = rsEmail("emailtext")	
			sEmailSubject = sEmailSubject & " for Invoice Number: " & rsEmail("invoicenumber")

			CBSSendMail sEmailFrom, sEmailFromAddress, sEmailToName, sEmailToAddress, sCCName, sccAddress, sBccName, sBccAddress, sEmailSubject, sEmailMessage, sAttachment1, sAttachment2
		end if
	
		rsEmail.close
		
		set rsEmail = nothing
	
		next 
	
	end function
%>

