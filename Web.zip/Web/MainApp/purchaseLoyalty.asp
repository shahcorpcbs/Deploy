<%@ language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim customerSeq, customerName, custPhone, areaCode, custVisitCount, routeNumber
	dim storeId, pricelistId, deptId, employeeID, empName, terminalID, storeName
	dim cardNo
	dim price, taxCode, discountId, noOfUses, taxDesc
	dim invoiceTotal, taxAmount
	dim loyaltyId
	dim actionString
	dim ticketNo, invoiceNo
	dim LI 
	dim taxPercent
	dim pickupInvoices,pickupInvoicesRst
	
	set session("pickupInvoices")= nothing
	set session("pickupobj") = nothing
	employeeId = session("employeeId")
	empName = Session("employeeName")
	terminalID = session("terminalId")
	customerSeq = session("customerSequenceNumber")
	customerName = session("customerName")
	storeid = session("storeId")
	storeName = Session("storeName")
	loyaltyId = Request.Form("loyaltyList")
	actionString = Request.QueryString("userAction")
	
	getCustomerDetails
	
	select case actionString
		case "submit"
			checkLoyalty()
			gotoPickupScreen
	end select		
	
	function checkLoyalty()
		dim ssql
		dim objRst

		ssql = "select * from loyaltycustomer where customersequencenumber = " & customerseq & " and loyaltyid = " & loyaltyid
		set objRst = getDisconnectedRecordset(ssql)
		if objRst.recordcount > 0 then
			Session("errorMessage") = "Customer has already purchased this loyalty program.  Please go back and choose another program."
			Response.Redirect "ErrorMessages.asp"
		end if	
	end function	
	
	function addTicket()
		dim firstVisit
		dim ssql
		dim objResultSet
		
		if custVisitCount = 0 then
			firstVisit = 1
		else
			firstVisit = 0
		end if		

		ssql = "exec InsertTicket " _
			& storeid _
			& "," & dbcreateqrystring(NULL) _
			& "," & dbcreateqrystring("D") _
			& "," & dbcreateqrystring("AC") _
			& "," & priceListId _
			& "," & routeNumber _ 
			& "," & employeeId _
			& "," & dbcreateqrystring(now)  _
			& "," & customerSeq _
			& "," & dbcreateqrystring(NULL) _
			& "," & dbcreateqrystring(NULL) _
			& "," & 0 _
			& "," & terminalId _
			& "," & 0 _
			& "," & invoiceTotal _
			& "," & dbcreateqrystring(NULL) _
			& "," & dbcreateqrystring(NULL) _
			& "," & firstVisit _
			& "," & 0 _
            & "," & 0 _
            & "," & 0 _
            & "," & 0 _ 
            & "," & 0 _
            & "," & 0 _ 
            & "," & invoiceTotal _
            & "," & 0 _
            & "," & 0 _
            & "," & dbcreateqrystring(empName) _
            & "," & dbcreateqrystring(storeName) _
            & "," & 0 _
            & "," & dbcreateqrystring(Null)
        Response.Write ssql    

		Set objResultSet = getDisconnectedRecordSet(ssql)
		ticketNo = objResultSet.Fields("TicketNumber").Value
		invoiceNo = objResultSet.Fields("InvoiceNumber").Value
	end function	
						
	function getAllLoyalty()
		dim ssql
		ssql = "Select loyaltyId, name from loyalty where enabled=1"
		set getAllLoyalty = getDisconnectedRecordset(ssql)
	end function

	sub getCustomerDetails()
		dim ssql
		dim objResultSet
		dim areaCode
		ssql = "Select IsNull(starchPreferenceName, '') as starchPreferenceName, IsNull(finishPreferenceName, '') as finishPreferenceName, defaultPriceListId, " _
				& " IsNull(firstName, '') as firstName, IsNull(middleInitial,'') as middleInitial, " _
				& " IsNull(lastName, '') as lastName, Isnull(mainAreaCode, '') as mainAreaCode, " _
				& " isnull(mainPhone, '') as mainPhone, vipExpiryDate, vipQualAmount, " _
				& " vipEligible, vipQualified, referralQualified, routeNumber, dbo.getCustomerVisits(customer.customersequencenumber, null, null) as visitCount, " _
				& " IsNull(screenNotes,'') as screenNotes from customer where customerSequenceNumber=" _
				& clng(customerseq)
		Set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Recordcount > 0 then	
			objResultSet.MoveFirst
			areaCode = objResultSet.fields("mainAreaCode")
			custPhone = objResultSet.fields("mainPhone")
			if len(Trim(custPhone)) > 0 then
				if len(Trim(areaCode)) > 0 then
					custPhone = areaCode & "-"  & Mid(custPhone,1,3) & "-" & Mid(custPhone,4,len(custPhone))
				end if
			end if
			custVisitCount = objResultSet.Fields("visitCount").Value
			routeNumber = objResultSet.Fields("routeNumber").Value
		end if
	end sub
	
	function addLineItems()
		'calculate tax
		taxAmount = Round(price*(CDbl(taxPercent)/100),2)
		invoiceTotal = price + taxAmount
		
		set LI = server.CreateObject("ADODB.recordset")
	    LI.Fields.Append "lineNumber", adInteger
		LI.Fields.Append "parentLineNumber", adInteger
		LI.Fields.Append "deptId", adInteger, , adFldIsNullable
		LI.Fields.Append "deptName", adVarChar, 64, adFldIsNullable
		LI.Fields.Append "itemType", adVarChar, 20
		LI.Fields.Append "lineItemId", adInteger, , adFldIsNullable
		LI.Fields.Append "itemName", adVarChar, 64, adFldIsNullable
		LI.Fields.Append "originalUnitPrice", adDouble
		LI.Fields.Append "unitPrice", adDouble
		LI.Fields.Append "quantity", adInteger, , adFldIsNullable
		LI.Fields.Append "lineItemTotal", adDouble
		LI.Fields.Append "totalTax", adDouble
	    LI.Fields.Append "totalSurcharge", adDouble
		LI.Fields.Append "prepay", adDouble
		LI.Fields.Append "taxableAmt", adDouble
		LI.Fields.Append "daysToProcess", adInteger, , adFldIsNullable
		LI.Fields.Append "notes", adVarChar, 255, adFldIsNullable
		LI.Fields.Append "balance", adDouble
		LI.Fields.Append "upchargeTotal", adDouble, , adFldIsNullable
		LI.Fields.Append "colorTotal", adDouble, , adFldIsNullable
		LI.Fields.Append "patternTotal", adDouble, , adFldIsNullable
		LI.Fields.Append "discountable", adBoolean, , adFldIsNullable
		LI.Fields.Append "couponable", adBoolean, , adFldIsNullable
		LI.Fields.Append "VIPDiscountable", adBoolean, , adFldIsNullable
		LI.Fields.Append "VIPQualified", adBoolean, , adFldIsNullable
		LI.Fields.Append "parentId", adInteger, , adFldIsNullable
		LI.Fields.Append "saleOnly", adBoolean, , adFldIsNullable
		LI.Fields.Append "chargeTaxCode", adInteger, , adFldIsNullable
		LI.Fields.Append "pkgQuantity", adInteger, , adFldIsNullable
		LI.Fields.Append "peNotes", adVarChar, 255, adFldIsNullable
		LI.CursorLocation = adUseClient
		LI.Open
		Set LI.ActiveConnection = Nothing
		'Add line for Loyalty
		LI.AddNew Array("lineNumber", "parentLineNumber", "deptId", _
                "deptName", "itemType", "lineItemId", "itemName", _
                "originalUnitPrice", "unitPrice", "quantity", "lineItemTotal", _
                "totalTax", "totalSurcharge", "prepay", _
                "taxableAmt", "daysToProcess", "notes", "balance", _
                "upchargeTotal", "colorTotal", "patternTotal", _
                "discountable", "couponable", "VIPDiscountable", _
                "saleOnly", "VIPQualified", "pkgQuantity", "peNotes"), _
				Array(1, -1, deptId, "SpecialOffers", "SO", 1, "Loyalty Program", _
				price, price, 1, price, taxAmount, 0, 0, _
				price, Null, Null, invoiceTotal, 0, 0, 0, _
				Null, Null, Null, Null, Null, 1, Null)
		'Add line for Tax
		if not (isempty(taxCode) or isnull(taxCode)) then
			LI.AddNew Array("lineNumber", "parentLineNumber", "deptId", _
                "deptName", "itemType", "lineItemId", "itemName", _
                "originalUnitPrice", "unitPrice", "quantity", "lineItemTotal", _
                "totalTax", "totalSurcharge", "prepay", _
                "taxableAmt", "daysToProcess", "notes", "balance"), _
                Array(2, -1, deptId, "SpecialOffers", "TA", taxCode, rtrim(taxDesc), 0, 0, 1, taxAmount, 0, 0, 0, 0, 0, Null, 0)
        end if         
	end function                 

	function addTicketItems()
		Dim ssql
		
		LI.MoveFirst
		While Not LI.EOF 
			ssql = "INSERT INTO TicketLineItem(ticketNumber, lineItemNumber, " _
                & " createdByEmployeeID, lastModifiedByEmployeeID, " _
                & " parentLineNumber, displaySequence, departmentID, " _
                & " departmentName, ticketLineType, lineItemID, saleOnly, " _
                & " lineItemName, originalUnitPrice, unitPrice, quantity, " _
                & " lineItemTotal, totalTaxPercent, totalSurchargePercent, " _
                & " lineItemTaxableAmount, itemNotes, " _
                & " outsideService, totalUpchargeAmount, chargeTaxCode, packagedQuantity) VALUES(" _
                & ticketNo & "," & LI.Fields("lineNumber").Value _
                & "," & employeeId & "," & employeeId & "," & LI.Fields("parentLineNumber").Value & "," _
                & LI.Fields("lineNumber").Value & "," & LI.Fields("deptId").Value & ",'" _
                & LI.Fields("deptName").Value & "','" & LI.Fields("itemType").Value & "'," _
                & LI.Fields("lineItemId").Value & "," _
                & 0 & ",'" & LI.Fields("itemName").Value & "'," _
                & LI.Fields("originalUnitPrice").Value & "," _
                & LI.Fields("unitPrice").Value & "," & LI.Fields("quantity").Value & "," _
                & LI.Fields("lineItemTotal").Value & "," _
                & LI.Fields("totalTax").Value & "," & LI.Fields("totalSurcharge").Value & "," _
                & LI.Fields("taxableAmt").Value & "," _
                & "NULL, 0, 0, NULL, 1)"
			QryExecute(ssql)
			LI.MoveNext
		Wend
	end function	
	
	function getLoyaltyPrice(loyaltyId)
		dim query, rs
		
		query = "select * from loyalty where loyaltyId = " & loyaltyId
		set rs = getDisconnectedRecordSet(query)

		if rs.recordcount > 0 then
			getLoyaltyPrice = rs("price")
		else
			getLoyaltyPrice = 0
		end if
	end function	
	
	function createInvoice(storeid)
		dim invoice
		dim query, rs
		dim objResultSet
		dim areaCode
		dim pricelistid
		dim customerseq
		
		set invoice = nothing
		
		query = "GetCounterSaleCustomer " & storeid
		Set rs = getDisconnectedRecordset(query)
		
		
		if rs.recordcount > 0 then
			rs.movefirst
			if isnull(rs.fields("defaultpriceListId")) then
				Response.Redirect "start2.asp"
			else
				pricelistid = rs.fields("defaultpriceListId")
				customerseq = rs.Fields("customerSequenceNumber")
				
				session("priceList") = pricelistid
				session("customersequencenumber") = customerseq
			end if
			
			set invoice = Server.CreateObject("ShahCorpComponents.invoice")
			invoice.DBConnectionString = Session("shahcorpDSN")
	
			invoice.isAdd = true
			invoice.amountPaid = 0
			invoice.counterSaleOnly = true
			invoice.custSeqNumber = customerseq
			invoice.starchPref = ""
			invoice.finishPref = ""
			invoice.multiPickUpCustName	= ""
			invoice.multiPickUpLoc = ""
			invoice.loadCustomerPreferences customerseq, ""
			invoice.priceListId = pricelistid
			invoice.setStoreDays storeid
		end if
		
		set createInvoice = invoice
	end function
	
	
	sub goToPickUpScreen()
		dim storeid
		dim invoice
		dim pickupObj
		dim price
		
		storeid = session("storeid")
			
		session("loyaltycardnumber") = request.form("cardno")
		session("loyaltyid") = loyaltyId
		session("loyaltycustomerseq") = session("customersequencenumber")

			
		set invoice = createInvoice(storeid)

		if not (invoice is nothing) then
			price = getLoyaltyPrice(loyaltyId)
			invoice.addChargeLine -1, price, "Loyalty Card", 1, -1

			set pickupObj = Server.CreateObject("ShahCorpComponents.pickup")
			pickupObj.DBConnectionString = Session("shahcorpDSN")
			pickupObj.storeId = storeid
			pickupObj.initStorePaymentTypeInfo()
			pickupObj.addInvoiceObjToPickup invoice
			pickupObj.userAction = "prepay"
			pickupObj.addOrEdit = "add"
			pickupObj.custSeqNumber = invoice.custSeqNumber

			set session("invoice") = invoice
			set Session("pickupObj") = pickupObj

			Response.Redirect "/mainapp/pickup.asp?targetPage=loyalty&userAction=prepay&addOrEdit=add"
		end if
		
		
		
		
	end sub
	
%>
<HTML>
<HEAD>
<TITLE>Purchase Loyalty</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function cancelForm(){
		history.back(-1);
		/*document.PurchaseLoyalty.action=parent.frames[0].history.back(-1);
		document.PurchaseLoyalty.submit();*/
	}

	function submitForm(){
		if (validateFormData()) {
			document.PurchaseLoyalty.action = "?userAction=submit";
			document.PurchaseLoyalty.submit();
		}
	}
	
	function validateFormData() {
		var cardNo
		cardNo = document.PurchaseLoyalty.cardNo.value;
		returnValue = true;
		if (!checkFieldMissing(cardNo)) {
			returnValue = false;
			show_focus("Card Number is required", "Invalid Card Number", document.PurchaseLoyalty.cardNo)
			return returnValue;
		}	
		return returnValue;
	}

</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Purchase Loyalty Program</H1>
<FORM id="PurchaseLoyalty" name="PurchaseLoyalty" action="PurchaseLoyalty.asp" method="post">
<TABLE ALIGN=center WIDTH=350px BORDER=1 CELLSPACING=0 CELLPADDING=0>
	<TR><TD WIDTH="100%">
		<table align=center border=0 width=100% cellpadding=0>
		<TR>
			<td colspan=2 class=label align=center><%= customerName%></td>
		</tr><TR>	
			<td colspan=2 class=label align=center><%= custphone%></td>
		</tr>	
		<TR height=50px valign=bottom>
			<TD align=right class=label width=150px>Loyalty Program</td>
			<td>
				<select name="loyaltyList" style="font-size:14px;width=150px" >
					<%	dim rstLoyalty
						set rstLoyalty = getAllLoyalty()
						while not rstLoyalty.eof
							if loyaltyid = rstLoyalty.Fields("LoyaltyId") then %>
							<OPTION	Selected VALUE= "<%=rstLoyalty.Fields("LoyaltyId") %>">
								<%= rstLoyalty.Fields("Name") %>
						<% else	%>
							<OPTION VALUE= "<%= rstLoyalty.Fields("LoyaltyID") %>">
								<%= rstLoyalty.Fields("Name") %>
						<% end if 
							rstLoyalty.movenext
						wend
					%>
					</select>&nbsp&nbsp&nbsp
			</td>
		</tr>
		<tr>
			<td class=label align=right width=150px>Card No</td>
			<td>
			<input type=text name=cardNo>
			</td>
		</tr>				
		<TR height=120 valign=middle>
			<TD colspan = 3 ALIGN=CENTER width=100%>
				<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" 
					style="background-image:url(../images/Ok.gif)" onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
				<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button 
					style="BACKGROUND-IMAGE: url(../images/Cancel.gif)" onClick="cancelForm()">
			</TD>	
		</TR>			

<P>&nbsp;</P>

</BODY>
</HTML>
