<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<% 
	Dim l_customerseq
	dim l_storeid
	dim isSubmitted 
	dim l_employeeId
	dim l_claimid
	
	l_Customerseq = session("Customersequencenumber")
	l_storeid = session("Storeid")
	isSubmitted = Request.QueryString("Submitted")
	l_employeeId = session("EmployeeId")
	
	l_claimid = session("ClaimID")
	
	if isSubmitted then
		updatedatabase()
	end if
	
%>
<HTML>
<HEAD>
<TITLE>Add New Info</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function addNewInfo() {
		// do the validation
		document.addNewInfoForm.action = "?Submitted=true";
		document.addNewInfoForm.submit();
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0 <%if lcase(request.querystring("Submitted")) = "true" then%>onload="opener.window.location.reload();window.close();"<%else%>onload="document.addNewInfoForm.claimInfo.focus()"<%end if%>>

<FORM id="addNewInfoForm" name="addNewInfoForm" action="" method="Post">
<!--<input name =h_claimid type=hidden value="<%=l_claimid%>">-->

	
	
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="addNewInfo()">Submit</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="window.close();">Close</BUTTON>
	</SPAN>
</DIV>

<H1>Add New Info</H1>

<TABLE style="background:#F8F8F8;margin:20px">
	<tr valign="top">
		<td>Description:</td>
		<td>
			<TEXTAREA rows=19 name="claimInfo" style="width:390px;border:1px inset;background:white;overflow:auto"></TEXTAREA>
		</td>
	</tr>
</TABLE>

</form>
</BODY>
</HTML>
<%

	Function updateDatabase()
	dim sqltxt
	
		sqltxt = "Insert into claimcomment(claimid, createddate, createdemployeeId,description) values ( " _
					& l_claimid _
					& "," & "getdate()" _
					& "," & l_employeeid _
					& "," & DbcreateQryString(Request.Form("claimInfo") )_
					& " )"
		
		dbstartTrans()					
		qryexecutewithTrans(sqltxt)
		dbEndTrans()
 
	
	end function

%>
