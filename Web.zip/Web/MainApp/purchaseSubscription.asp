<%@ language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs, customerSeq, customerName, custVisitCount, routeNumber
	dim storeId, pricelistId, deptId, employeeID, empName, terminalID, storeName
	dim price, taxCode, discountId, noOfUses, taxDesc
	dim invoiceTotal, subPrice, taxAmount
	dim currSubId, currSubName, currSubBilling, nextBillingDate, isCanceled, isAutoPickup, currSubxCustId
	dim actionString
	dim ticketNo, invoiceNo
	dim LI 
	dim taxPercent
	dim disableSubAvail
	dim nextMonthSub

    nextMonthSub = ""
	disableSubAvail = false
	employeeId = session("employeeId")
	empName = Session("employeeName")
	storeid = session("storeId")
	terminalID = session("terminalId")
	customerSeq = session("customerSequenceNumber")
	customerName = session("customerName")
	actionString = Request.QueryString("userAction")
	query = "select s.name, s.id, sc.billingDay, sc.canceled, sc.autoPickup, sc.id scid from subscription s, SubxCust sc where sc.enabled = 1 and s.id = sc.subId and sc.custSeqNum = " & customerSeq
    set rs = getDisconnectedRecordset(query)
    if rs.recordcount > 0 then
        currSubId = rs("id")
        currSubName = rs("name")
        currSubBilling = rs("billingDay")
        isCanceled = rs("canceled")
        isAutoPickup = rs("autoPickup")
        currSubxCustId = rs("scid")

        dim currDayOfMonth, currMonth, currYear
        currDayOfMonth = Day(Now)
        currMonth = Month(Now)
        currYear = Year(Now)

        if currDayOfMonth >= currSubBilling then
            if currMonth = 12 then
                currYear = currYear + 1
                currMonth = 1
            else
                currMonth = currMonth + 1
            end if
        end if

        if currMonth = 2 and currSubBilling > 28 then
            currSubBilling = 28
        elseif (currMonth = 4 or currMonth = 6 or currMonth = 9 or currMonth = 11) and currSubBilling = 31 then
            currSubBilling = 30
        end if

        nextBillingDate = currMonth & "/" & currSubBilling & "/" & currYear

        query = "select s.name from subscription s, SubxCust sc where nextBilling = 1 and canceled = 0 and s.id = sc.subId and sc.custSeqNum = " & customerSeq
        set rs = getDisconnectedRecordset(query)
        if rs.recordcount > 0 then
            nextMonthSub = rs("name")
        end if

        query = "select id from SubXCustItems where subId = " & currSubId & " and custSeqNum = " & customerSeq
        set rs = getDisconnectedRecordset(query)
        if rs.recordcount = 0 then
            disableSubAvail = true
        end if



    end if
	
	select case actionString
		case "submit"
            changeSubscription
            Response.Redirect "/mainapp/customerfunctions.asp"
        case "submitAuto"
            updatePickup
            Response.Redirect "/mainapp/customerfunctions.asp"
	end select

	function updatePickup
	    dim autoPickup
	    autoPickup = Request.QueryString("autoPickup")
	    query = "update SubXCust set autoPickup = " & autoPickup & " where Id = " & currSubxCustId
	    QryExecute(query)
	end function


	function changeSubscription
	    dim newSubId, disableSub, waitNextBilling, autoPickup
	    newSubId = Request.QueryString("newSubId")
	    waitNextBilling = Request.QueryString("waitNextBilling")
	    autoPickup = Request.QueryString("autoPickup")

	    if currSubId <> "" then
	        disableSub = Request.QueryString("disableSub")
	        if (newSubId <> 0 and not waitNextBilling) or disableSub then
	            query = "update SubxCust set canceled = 1, enabled = 0, nextBilling = 0 where custSeqNum = " & customerSeq
	        else
	            query = "update SubxCust set canceled = 1, nextBilling = 0  where custSeqNum = " & customerSeq
	        end if
            QryExecute(query)
	    end if

	    if newSubId <> 0 then
	        dim dayOfMonth
	        dayOfMonth = Day(Date())

	        query = "update SubXCust set nextBilling = 0 where custSeqNum = " & customerSeq
	        QryExecute(query)

	        if waitNextBilling then
                query = "insert into SubXCust (subId, custSeqNum, billingDay, enabled, nextBilling, autoPickup) values (" & newSubId & ", " & customerSeq _
                    & ", " & dayOfMonth & ", 0, 1, " & autoPickup & ")"
	        else
                query = "update SubXCust set enabled = 0 where custSeqNum = " & customerSeq
                QryExecute(query)
                query = "insert into SubXCust (subId, custSeqNum, billingDay, enabled, autoPickup) values (" & newSubId & ", " & customerSeq _
                    & ", " & dayOfMonth & ", 1, " & autoPickup & ")"
            end if
	        QryExecute(query)
            subPrice = Request.QueryString("newPrice")
            getCustomerDetails
            if not waitNextBilling then
                addTicket newSubId
            end if
	    end if

	end function

	sub getCustomerDetails()
		dim ssql
		dim objResultSet
		dim areaCode
		ssql = "Select IsNull(starchPreferenceName, '') as starchPreferenceName, IsNull(finishPreferenceName, '') as finishPreferenceName, defaultPriceListId, " _
				& " IsNull(firstName, '') as firstName, IsNull(middleInitial,'') as middleInitial, " _
				& " IsNull(lastName, '') as lastName, Isnull(mainAreaCode, '') as mainAreaCode, " _
				& " isnull(mainPhone, '') as mainPhone, vipExpiryDate, vipQualAmount, " _
				& " vipEligible, vipQualified, referralQualified, routeNumber, dbo.getCustomerVisits(customer.customersequencenumber, null, null) as visitCount, " _
				& " IsNull(screenNotes,'') as screenNotes from customer where customerSequenceNumber=" _
				& clng(customerseq)
		Set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Recordcount > 0 then
			objResultSet.MoveFirst
			custVisitCount = objResultSet.Fields("visitCount").Value
			routeNumber = objResultSet.Fields("routeNumber").Value
			priceListId = objResultSet.Fields("defaultPriceListId").Value
		end if
	end sub
	
	function addTicket(newSubId)
		dim firstVisit
		dim ssql, rs
		dim objResultSet
		
		if custVisitCount = 0 then
			firstVisit = 1
		else
			firstVisit = 0
		end if

        dim taxAmt, totalTaxAmt, taxAmts, taxNames
        totalTaxAmt = 0

		ssql = "select taxPercent, description from Tax a, SubscriptionTax b where b.taxCode = a.taxCode and subId = " & newSubId
        set rs = getdisconnectedrecordset(ssql)
        while not(rs.eof or rs.bof)
            taxAmt = Cdbl(rs("taxPercent")) * Cdbl(subPrice) / 100
            taxAmts = taxAmts & taxAmt & ","
            taxNames = taxNames & rs("description") & ","
            totalTaxAmt = totalTaxAmt + taxAmt
            rs.movenext
        wend
        invoiceTotal = subPrice + totalTaxAmt


        dim surAmt, totalSurAmt, surAmts, surNames
        totalSurAmt = 0
		ssql = "select fixedAmount, surchargePercent, name from Surcharge a, SubscriptionSurcharge b where b.surCode = a.surchargeCode and subId = " & newSubId
        set rs = getdisconnectedrecordset(ssql)
        while not(rs.eof or rs.bof)
            if rs("fixedAmount") <> "" then
                surAmt = Cdbl(rs("fixedAmount"))
            else
                surAmt = Cdbl(rs("surchargePercent")) * Cdbl(subPrice) / 100
            end if
            surAmts = surAmts & surAmt & ","

            surNames = surNames & trim(rs("name")) & ","
            totalSurAmt = totalSurAmt + surAmt
            rs.movenext
        wend
        invoiceTotal = invoiceTotal + totalSurAmt


		ssql = "exec InsertTicket " _
			& storeid _
			& "," & dbcreateqrystring(NULL) _
			& "," & dbcreateqrystring("D") _
			& "," & dbcreateqrystring("AC") _
			& "," & priceListId _
			& "," & routeNumber _ 
			& "," & employeeId _
			& "," & dbcreateqrystring(now)  _
			& "," & customerSeq _
			& "," & dbcreateqrystring(NULL) _
			& "," & dbcreateqrystring(NULL) _
			& "," & 0 _
			& "," & terminalId _
			& "," & 0 _
			& "," & invoiceTotal _
			& "," & dbcreateqrystring(NULL) _
			& "," & dbcreateqrystring(NULL) _
			& "," & firstVisit _
			& "," & 0 _
            & "," & 0 _
            & "," & 0 _
            & "," & 0 _ 
            & "," & 0 _
            & "," & 0 _ 
            & "," & invoiceTotal _
            & "," & 0 _
            & "," & 0 _
            & "," & dbcreateqrystring(empName) _
            & "," & dbcreateqrystring(storeName) _
            & "," & 0 _
            & "," & dbcreateqrystring(Null)
        Response.Write ssql    

		Set objResultSet = getDisconnectedRecordSet(ssql)
		ticketNo = objResultSet.Fields("TicketNumber").Value
		invoiceNo = objResultSet.Fields("InvoiceNumber").Value

        'I know this is weird, but need to make sure this doesn't trigger the prepay discount because that screws up subscriptions calculations when prepaying
		ssql = "update ticket set createdDate = DATEADD(HOUR, -3, createdDate) where ticketNumber = " & ticketNo
		QryExecute(ssql)

        dim departId
		ssql = "select departmentId from Department where name = 'Subscription' and priceListId = " & priceListId
		set rs = getDisconnectedRecordSet(ssql)
		departId = rs("departmentId")

	    ssql = "INSERT INTO TicketLineItem(ticketNumber, lineItemNumber, " _
                & " createdByEmployeeID, lastModifiedByEmployeeID, " _
                & " parentLineNumber, displaySequence, departmentID, " _
                & " departmentName, ticketLineType, lineItemID, saleOnly, " _
                & " lineItemName, originalUnitPrice, unitPrice, quantity, " _
                & " lineItemTotal, totalTaxPercent, totalSurchargePercent, " _
                & " lineItemTaxableAmount, itemNotes, outsideService, totalUpchargeAmount, " _
                & " chargeTaxCode, packagedQuantity) VALUES(" _
                & ticketNo & ", 1," & employeeId & "," & employeeId & ", -1, 1," _
                & departId & ",'Subscription','IT', 0, 1,'Subscription'," _
                & subPrice & "," & subPrice & ", 1," _
                & subPrice & ", " & totalTaxAmt & ", " & totalSurAmt & ", " & subPrice & ", NULL, 0, 0, NULL, 1)"
		QryExecute(ssql)

        if taxAmts <> "" then
            dim taxLI, currTaxId, i, currTaxName, taxNameLI
            taxLI = Split(taxAmts,",")
            taxNameLI = Split(taxNames,",")
            for i = 0 to UBound(taxLI)
                currTaxId = trim(taxLI(i))
                currTaxName = trim(taxNameLI(i))
                if currTaxId <> "" then

                ssql = "INSERT INTO TicketLineItem(ticketNumber, lineItemNumber, " _
                        & " createdByEmployeeID, lastModifiedByEmployeeID, " _
                        & " parentLineNumber, displaySequence, departmentID, " _
                        & " departmentName, ticketLineType, lineItemID, saleOnly, " _
                        & " lineItemName, originalUnitPrice, unitPrice, quantity, " _
                        & " lineItemTotal, totalTaxPercent, totalSurchargePercent, " _
                        & " lineItemTaxableAmount, itemNotes, outsideService, totalUpchargeAmount, " _
                        & " chargeTaxCode, packagedQuantity) VALUES(" _
                        & ticketNo & ", " & i + 2 & "," & employeeId & "," & employeeId & ", -1, " & i + 2 & "," _
                        & departId & ",'Subscription','TA', 0, 1, '" & currTaxName & "'," _
                        & 0 & "," & 0 & ", 1," _
                        & currTaxId & ", " & 0 & ", 0, " & 0 & ", NULL, 0, 0, NULL, 1)"
                QryExecute(ssql)
                end if
            next
        end if

        if surAmts <> "" then
            dim surLI, currSurAmt, currSurName, surNameLI, j
            surLI = Split(surAmts,",")
            surNameLI = Split(surNames,",")

            for j = 0 to UBound(surLI)
                currSurAmt = trim(surLI(j))
                currSurName = trim(surNameLI(j))

                if currSurAmt <> "" then
                ssql = "INSERT INTO TicketLineItem(ticketNumber, lineItemNumber, " _
                        & " createdByEmployeeID, lastModifiedByEmployeeID, " _
                        & " parentLineNumber, displaySequence, departmentID, " _
                        & " departmentName, ticketLineType, lineItemID, saleOnly, " _
                        & " lineItemName, originalUnitPrice, unitPrice, quantity, " _
                        & " lineItemTotal, totalTaxPercent, totalSurchargePercent, " _
                        & " lineItemTaxableAmount, itemNotes, outsideService, totalUpchargeAmount, " _
                        & " chargeTaxCode, packagedQuantity) VALUES(" _
                        & ticketNo & ", " & i + j + 2 & "," & employeeId & "," & employeeId & ", -1, " & i + 2 & "," _
                        & departId & ",'Subscription','SU', 0, 0, '" & currSurName & "'," _
                        & 0 & "," & 0 & ", 1," _
                        & currSurAmt & ", " & 0 & ", 0, " & currSurAmt & ", NULL, 0, 0, NULL, 1)"
                QryExecute(ssql)
                end if
            next
        end if

	end function
	
	
	function createInvoice(storeid)
		dim invoice
		dim query, rs
		dim objResultSet
		dim areaCode
		dim pricelistid
		dim customerseq
		
		set invoice = nothing
		
		query = "GetCounterSaleCustomer " & storeid
		Set rs = getDisconnectedRecordset(query)
		
		
		if rs.recordcount > 0 then
			rs.movefirst
			if isnull(rs.fields("defaultpriceListId")) then
				Response.Redirect "start2.asp"
			else
				pricelistid = rs.fields("defaultpriceListId")
				customerseq = rs.Fields("customerSequenceNumber")
				
				session("priceList") = pricelistid
				session("customersequencenumber") = customerseq
			end if
			
			set invoice = Server.CreateObject("ShahCorpComponents.invoice")
			invoice.DBConnectionString = Session("shahcorpDSN")
	
			invoice.isAdd = true
			invoice.amountPaid = 0
			invoice.counterSaleOnly = true
			invoice.custSeqNumber = customerseq
			invoice.starchPref = ""
			invoice.finishPref = ""
			invoice.multiPickUpCustName	= ""
			invoice.multiPickUpLoc = ""
			invoice.loadCustomerPreferences customerseq, ""
			invoice.priceListId = pricelistid
			invoice.setStoreDays storeid
		end if
		
		set createInvoice = invoice
	end function

	function getCustUsedAmt(promoId, promoType)
	    dim query, rs, result, lastBillingDay

        dim currDayOfMonth, currMonth, currYear
        currDayOfMonth = Day(Now)
        currMonth = Month(Now)
        currYear = Year(Now)

        if currDayOfMonth < currSubBilling then
            if currMonth = 1 then
                currMonth = 12
                currYear = currYear - 1
            else
                currMonth = currMonth - 1
            end if
        end if
        lastBillingDay = currYear & "-" & currMonth & "-" & currSubBilling


	    if promoType = 1 then
            query = "select case when sum(tli.quantity) is null then 0 else sum(tli.quantity) end totalAmt from TicketLineItem tli, SubXCustItems ci, Ticket t " _
                & "where t.ticketStatus != 'VO' and t.ticketNumber = ci.ticketNumber and tli.ticketLineType = 'IT' and " _
                & "tli.ticketNumber = ci.ticketNumber and tli.lineItemNumber = ci.ticketLineItemNumber " _
                & "and ci.custSeqNum = " & customerSeq & " and ci.dateCreated >= '" & lastBillingDay & "' and tli.departmentId in " _
                & "(select departId from SubPromotionxDept where promoId = " & promoId & ")"
	    else
            query = "select case when sum(tli.quantity) is null then 0 else " _
                & "sum(case when tli.lineItemName = 'Per LB' then tli.quantity else (case when tli.lineItemName = 'Per Tenth LB' then cast(tli.quantity as decimal) / 10 else 0 end) end) end totalAmt " _
                & "from TicketLineItem tli, SubXCustItems ci, Ticket t where tli.ticketLineType = 'UP' and t.ticketNumber = tli.ticketNumber and t.ticketStatus != 'VO' " _
                & "and tli.ticketNumber = ci.ticketNumber and tli.lineItemNumber = ci.ticketLineItemNumber " _
                & "and ci.custSeqNum = " & customerSeq & " and ci.dateCreated >= '" & lastBillingDay & "' and tli.departmentId in " _
                & "(select departId from SubPromotionxDept where promoId = " & promoId & ")"
	    end if
        set rs = getDisconnectedRecordSet(query)

	    getCustUsedAmt = rs("totalAmt")

	end function


%>
<HTML>
<HEAD>
<TITLE>Purchase Subscription</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function cancelForm(){
		document.PurchaseSubscription.action = "customerfunctions.asp"
		document.PurchaseSubscription.submit();
	}

	function submitForm(){
	    var newSubInfo = document.PurchaseSubscription.subList.value;
	    var formValues = newSubInfo.split("|||")
        var newSubId = formValues[0];
        var newSubName = formValues[1]
        var newSubPrice = formValues[2]

	    <% if currSubId = "" then %>
	        if(newSubId == 0)
	            cancelForm()    //No change
	        else
	            cbs_confirm("You wish to add subscription [" + newSubName + "] with a charge of $" + newSubPrice, confirmYes);
	    <% else %>
	        if(newSubId == 0)
	            cbs_confirm("You wish to cancel subscription [<%=currSubName%>]" +
	            <% if not disableSubAvail then%>"\n Subscription will end on next billing date."<% else%>""<% end if %>, confirmYes);
	        else if (newSubId == '<%=currSubId%>')
	            updatePickupOnly();
            else {
                cbs_select("Changing from [<%=currSubName%>] to [" + newSubName
                    + "].\nShould the new subscription start immediately or during the next billing period?", 1,
                    'Immediately|Next Billing|Cancel', "handleOpt");
            }
		<% end if %>
	}

    function updatePickupOnly(disableSub, waitForNextBilling) {
        var autoPickup = document.getElementById('doAutoPickup').checked ? "1" : "0";
        document.PurchaseSubscription.action = "?userAction=submitAuto&autoPickup=" + autoPickup;
        document.PurchaseSubscription.submit();
    }

    function handleOpt(selOpt) {
        clearOptionMsg();
        if (selOpt == 0)
            doRun(true, false);
        else if (selOpt == 1)
            doRun(false, true);
    }

    function confirmYes() {
        clearConfirmMsg();
        <% if disableSubAvail and currSubId <> "" then %>
        	var newSubInfo = document.PurchaseSubscription.subList.value;
        	var formValues = newSubInfo.split("|||")
            var newSubId = formValues[0];
            if(newSubId == 0)
                cbs_confirm("The old subscription has never been used, should it be disabled or continue until next billing cycle", confirmDisable, confirmCon, "Disable", "Continue")
            else
                doRun(true, false);
        <% else %>
        doRun(false, false);
        <% end if %>
    }

    function confirmDisable() {
        doRun(true, false);
    }

    function confirmCon() {
        doRun(false, false);
    }


function doRun(disableSub, waitForNextBilling) {
	    var newSubInfo = document.PurchaseSubscription.subList.value;
	    var formValues = newSubInfo.split("|||")
        var newSubId = formValues[0];
        var newSubName = formValues[1]
        var newSubPrice = formValues[2]
        var autoPickup = document.getElementById('doAutoPickup').checked ? "1" : "0";
        document.PurchaseSubscription.action = "?userAction=submit&newSubId=" + newSubId + "&newPrice=" + newSubPrice +
            "&disableSub=" + disableSub + "&waitNextBilling=" + waitForNextBilling + "&autoPickup=" + autoPickup;
        document.PurchaseSubscription.submit();
    }



</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Purchase Subscription</H1>
<FORM id="PurchaseSubscription" name="PurchaseSubscription" action="PurchaseSubscription.asp" method="post" onsubmit="return false">
<TABLE ALIGN=center WIDTH=650px BORDER=1 CELLSPACING=0 CELLPADDING=0>
	<TR><TD WIDTH="100%">
		<table align=center border=0 width=100% cellpadding=0>
            <tr><td  height="20px"></td></tr>
		<TR>
			<td colspan=2 class=label align=center><%= customerName%></td>
		</tr>
        <tr>
            <td style="white-space:nowrap">Current Subscription:</td>
            <td><%= currSubName %></td>
        </tr>
        <% if nextMonthSub <> "" then %>
        <tr>
            <td>Next Month Subscription:</td>
            <td><%= nextMonthSub %></td>
        </tr>
        <tr>
            <td>Renewal Day:</td>
        <% else %>
        <tr>
            <td><% if isCanceled then %><div style="color:red">Ending Date:</div><%else%>Renewal Date:<%end if%></td>
        <% end if %>
            <td><%= nextBillingDate %></td>
        </tr>

        <% if currSubId <> "" then
            dim innerQuery, innerRs, currUsed
             innerQuery = "select sxp.promoId, sp.name, sp.maxAmt, sp.type, sp.percentAfterLimit from SubxPromo sxp, SubPromotion sp where sp.Id = sxp.promoId and sxp.subId = " & currSubId
            set innerRs = getDisconnectedRecordSet(innerQuery)
            while not innerRs.eof
                currUsed = getCustUsedAmt(innerRs("promoId"), innerRs("type"))
            %>

            <tr>
                <td><%=innerRs("name") %>:</td>
                <% if innerRs("maxAmt") = 0 then %>
                    <td>Unlimited</td>
                <% elseif cInt(innerRs("maxAmt")) <  cInt(currUsed) then %>
                    <td style="white-space: nowrap">
                        Limit Reached<% if innerRs("percentAfterLimit") <> 0 then %>, Current Discount <%=innerRs("percentAfterLimit")%>% Off<% end if %>
                    </td>
                <% else %>
                    <td><%=currUsed%> of <% =innerRs("maxAmt")%>
                        <% if innerRs("type") = "1" then%> Pieces <% else %> LBs <% end if %> Used
                    </td>
                <% end if %>
            </tr>
            <%
                innerRs.movenext
                wend
            %>
        <% end if %>




		<TR height=50px valign=bottom>
			<TD align=right class=label width=150px>Subscription</td>
			<td>
				<select name="subList" style="font-size:14px;width=150px" >
				<OPTION	VALUE="0|||0|||0">None</option>
					<%
					    query = "select id, name, price from Subscription"
					    set rs = getDisconnectedRecordSet(query)
						while not rs.eof
							if currSubId = rs.Fields("id") then %>
							<OPTION selected VALUE= "<%=rs.Fields("id") %>|||<%=rs.Fields("Name")%>|||<%=rs.Fields("price")%>">
								<%= rs.Fields("Name") %>
						<% else	%>
							<OPTION VALUE="<%=rs.Fields("id") %>|||<%=rs.Fields("Name")%>|||<%=rs.Fields("price")%>">
								<%= rs.Fields("Name") %> : $<%= rs.Fields("price") %> dollars
						<% end if 
							rs.movenext
						wend
					%>
					</select>&nbsp&nbsp&nbsp
			</td>
		</tr>
			<TD align=right class=label width=150px>Auto Pickup</td>
			<td>
                <input type=checkbox id="doAutoPickup" <% if isAutoPickup then %> checked <% end if %>>
            </td>
        </tr>

		<TR height=120 valign=middle>
			<TD colspan = 3 ALIGN=CENTER width=100%>
				<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" 
					style="background-image:url(../images/Ok.gif)" onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
				<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button 
					style="BACKGROUND-IMAGE: url(../images/Cancel.gif)" onClick="cancelForm()">
			</TD>	
		</TR>			

<P>&nbsp;</P>

</BODY>
</HTML>
