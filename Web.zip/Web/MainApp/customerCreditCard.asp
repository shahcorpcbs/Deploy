<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/customerPaymentObj.asp"-->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>

<%
	'*******************************************************************
	'Name   : customerCreditCard.asp
    'Author : James Johnston
    'Created: 20-Jan-2004
    'Modification History
    '===================================================================
    ' Date           Changed By    Change Log
    ' ------------------------------------------------------------------
    ' 20-Jan-2004    Johnston		Original version
	'*******************************************************************

'COMMON variables
dim originatingPage
dim ObjMiscSetUp
dim custSeqNumber
dim customername
dim storeId
dim empID
dim terminalId
dim sessionName
dim onFile
dim fileStatus
dim custPaymentObj
dim custCreditCardTypeID
dim custCreditCardNo
dim custCreditCardExpDate
dim custCreditCardExpMonth
dim custCreditCardExpYear
dim custCreditCardName
dim custCreditCardCVC
dim allowCCBatch
dim billingAddress1, billingAddress2, billingAddress3, billingCity, billingState, billingZipCode
dim billingAddressCombined
dim firstDigits, cardTypeArray
dim isSubmitted 

isSubmitted = Request.QueryString("submitted")
if (isSubmitted) then
	UpdateDatabase()
end if

'Set COMMON variables
originatingPage = Request.QueryString("OPage")	'Added by JJ, 13Jan04

if Not IsObject(Session("miscSetUp")) then
	initializeMiscSetUp
end if
set ObjMiscSetUp = Session("miscSetUp")

custSeqNumber = Session("customerSequenceNumber")
Session("customerSequenceNumber")=custSeqNumber

customerName = session("customername")
storeId = Session("storeID")
empID = Session("employeeID")
terminalId = Session("terminalID")
sessionName = Session.SessionID
fileStatus = 0

getCustomerCreditCardInfo

Function getCreditCardsTypes()
'This function retrieves all credit card types setup for store.
' Returns an array of valid c.c. names (cardTypeArray)
' and an array of valid first digits for those c.c. types (firstDigits)
'Used for all C.C. payments

	dim sqltxt
	dim rsCreditTypes
	dim typeArray(),cardArray(15)
	dim i,x
	
	i=0
	x=0
	
	sqltxt = "select creditcardTypeId, name from creditcardtypedomain where storeid = " & storeId
	set rsCreditTypes = getdisconnectedRecordset(sqltxt)
	
	if rsCreditTypes.recordcount > 0 then
		'Set array of valid first digits
		redim typeArray(rsCreditTypes.recordcount-1)
		while not rsCreditTypes.EOF
			if ucase(left(rsCreditTypes.fields("name").value,2))="VI" then
				typeArray(i)=4
				cardArray(i)=x
			elseif ucase(left(rsCreditTypes.fields("name").value,2))="MA" then
				typeArray(i)=5
				cardArray(i)=x
			elseif ucase(left(rsCreditTypes.fields("name").value,2))="AM" then
				typeArray(i)=34
				cardArray(i)=x
				redim preserve typeArray(ubound(typeArray)+1)
				i=i+1
				typeArray(i)=37
				cardArray(i)=x
			elseif ucase(left(rsCreditTypes.fields("name").value,3))="DIS" then
				typeArray(i)=6
				cardArray(i)=x
			elseif ucase(left(rsCreditTypes.fields("name").value,3))="DIN" then
				typeArray(i)=30	
				cardArray(i)=x	
			elseif ucase(left(rsCreditTypes.fields("name").value,4))="CART" then
				typeArray(i)=36
				cardArray(i)=x
				redim preserve typeArray(ubound(typeArray)+1)
				i=i+1
				typeArray(i)=38
				cardArray(i)=x	
			elseif ucase(left(rsCreditTypes.fields("name").value,3))="ENR" then
				typeArray(i)=201
				cardArray(i)=x
				redim preserve typeArray(ubound(typeArray)+1)
				i=i+1
				typeArray(i)=214
				cardArray(i)=x		
			elseif ucase(left(rsCreditTypes.fields("name").value,3))="JCB" then
				typeArray(i)=213
				cardArray(i)=x
				redim preserve typeArray(ubound(typeArray)+1)
				i=i+1
				typeArray(i)=180
				cardArray(i)=x											
			end if
			i=i+1
			x=x+1
			rsCreditTypes.movenext
		wend
	
		firstDigits = join(typeArray,",")
		cardTypeArray = join(cardArray,",")
		rsCreditTypes.movefirst
	end if
	
	set getCreditCardsTypes = rsCreditTypes
	
End Function


sub getCustomerCreditCardInfo()
'This proc retrieves stored customer C.C. info
' Sets C.C. type, number, exp. date 
'Used for all C.C. payments

	initializeCustomerPaymentInfo

	set custPaymentObj = Session("customerPayment")
	
	if custPaymentObj.Count > 0 then
		custCreditCardTypeID = custPaymentObj.Item("creditCardTypeId")
		custCreditCardNo = custPaymentObj.Item("creditCardNumber")
		custCreditCardName = ucase(custPaymentObj.Item("creditCardNameOnCard"))
		custCreditCardCVC = custPaymentObj.Item("creditCardCVC")
		billingAddress1 = ucase(custPaymentObj.Item("billingAddress1"))
		billingAddress2 = ucase(custPaymentObj.Item("billingAddress2"))
		billingAddress3 = ucase(custPaymentObj.Item("billingAddress3"))
		billingCity = ucase(custPaymentObj.Item("billingCity"))
		billingState = ucase(custPaymentObj.Item("billingState"))
		billingZipCode = custPaymentObj.Item("billingZipCode")
		allowCCBatch = custPaymentObj.Item("allowCCBatch")
		if allowCCBatch then
			allowCCBatch = 1
		else
			allowCCBatch = 0
		end if
	
		if not isnull(custCreditCardNo) then
			onFile = 1
		else
			onFile = 0
		end if
		
		custCreditCardExpDate = custPaymentObj.Item("creditCardExpDate")
		if not isnull(custCreditCardExpDate) then
			custCreditCardExpMonth = left(custCreditCardExpDate,2)
			custCreditCardExpYear = right(custCreditCardExpDate,2)
		end if
		
		if not isempty(billingAddress1) AND not isnull(billingAddress1) AND billingAddress1<>"" then
			billingAddressCombined = billingAddress1
			if not isempty(billingAddress2) or not isnull(billingAddress2) or billingAddress2<>"" then
				billingAddressCombined = billingAddressCombined & ", " & billingAddress2
				if not isempty(billingAddress3) or not isnull(billingAddress3) or billingAddress3<>"" then
				billingAddressCombined = billingAddressCombined & ", " & billingAddress3
				end if
			end if
		end if
		
	end if
	
end sub


function updateDatabase()
' This function returns entered values to the CUSTOMER table.
'  Commented lines are there in the event we wish to allow billing address info to be edited.

	dim sqltxt
	dim allowCCBatch
	dim ccType
	
	custCreditCardTypeID = Request.form("selCreditType")
	custCreditCardNo = Request.form("txtCCNumber")
	custCreditCardExpDate = Request.form("txtCCExpDate")
	custCreditCardName = Request.form("txtCCCustName")
	custCreditCardCVC = Request.form("txtCCcvc")
	'billingAddress1 = Request.form("txtCCAddress")
	'billingAddress2 = Request.form("billingAddress2")
	'billingAddress3 = Request.form("billingAddress3")
	'billingCity = Request.form("txtCCCity")
	'billingState = Request.form("txtCCState")
	'billingZipCode = Request.form("txtCCZip")
	custSeqNumber = session("Customersequencenumber")
	allowCCBatch = Request.Form("ccBatchChk")
	if allowCCBatch = "on" then
		allowCCBatch = 1
	else
		allowCCBatch = 0
	end if

'	sqltxt = "update customer set " _
'        & "creditcardtypeid = " & dbcreateQrynumeric(custCreditCardTypeID) _
'        & ",creditcardnumber = "  & dbcreateQrystring(custCreditCardNo)  _
'        & ",creditcardexpdate = " & dbcreateQrystring(custCreditCardExpDate) _
'        & ",creditCardNameOnCard = " & ucase(dbcreateQrystring(custCreditCardName)) _
'        & ",billingAddress1 = " & ucase(dbcreateQrystring(billingAddress1)) _
'        & ",billingCity = " & ucase(dbcreateQrystring(billingCity)) _
'        & ",billingState = " & ucase(dbcreateQrystring(billingState)) _
'        & ",billingZipCode = " & dbcreateQrystring(billingZipCode) _
'        & " where customersequencenumber = " & custSeqNumber
        		
    ccType = dbcreateQrynumeric(custCreditCardTypeID)
    if ccType <= 0 then
		ccType = "null"
	end if
	sqltxt = "update customer set " _
        & "creditcardtypeid = " & ccType _
        & ",creditcardnumber = "  & dbcreateQrystring(custCreditCardNo)  _
        & ",creditcardexpdate = " & dbcreateQrystring(custCreditCardExpDate) _
        & ",creditCardNameOnCard = " & ucase(dbcreateQrystring(custCreditCardName)) _
        & ",creditCardCVC = " & ucase(dbcreateQrystring(custCreditCardCVC)) _
        & ",allowCCBatch = " & dbcreateQrynumeric(allowCCBatch) _
        & " where customersequencenumber = " & custSeqNumber

    dbstartTrans()
	QryExecutewithtrans(sqltxt)
	dbEndTrans()
	
	Response.redirect("CustomerEntry.asp?mode=edit")
	
end function


%>

<HTML>

<HEAD>

<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">

<TITLE>Customer Credit Card Information</TITLE>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>

<script language="javascript" type="text/javascript">

	var lastFocusControl;
	var lastControl;
	var cardType;
	var accountNumber;
	var expirationDate;
	var expirationMonth;
	var expirationYear;
	var ccCustName;
	var fileName;
	var approvalCode;
	var timedOut;
	var swipeData;
	var onFile;
	
	lastControl = "txtCCNumber";
	timedOut = false;
	
	function submitForm(doValidation)
	{
		if (!doValidation || validateForm() == true) 
		{
		document.creditCardInfo.action=document.creditCardInfo.action + "?submitted=true"
		document.creditCardInfo.submit();
		}
	}	
	
	
	function  validateForm()
	{		
		//Check for valid and needed data
		//Type of card
		if (document.creditCardInfo.selCreditType.value==0)
		{
			alert("Please select the TYPE of card.");			
			document.creditCardInfo.selCreditType.focus();
			return false;
		}
		
		//Account number or Expiration date missing
		if (document.creditCardInfo.txtCCNumber.value=="" ||
				document.creditCardInfo.txtCCExpDate.value=="")
		{
			alert("Please enter \nACCOUNT NUMBER\n and/or \nEXPIRATION DATE.");
			if (document.creditCardInfo.txtCCNumber.value=="")
			{
				document.creditCardInfo.txtCCNumber.focus();
			}
			else
			{
				document.creditCardInfo.txtCCExpDate.focus();
			}
			return false;
		}
		
		//Account number alphanumeric
		accountNumber=document.creditCardInfo.txtCCNumber.value;
		if(isNaN(accountNumber))
		{
			alert("ACCOUNT NUMBER is not a number.");
			document.creditCardInfo.txtCCNumber.focus();
			return false;
		}
		
		//Expiration date invalid
		expirationDate = document.creditCardInfo.txtCCExpDate.value;
		var result
		result = expDateCheck(expirationDate);
		if(result==false)
		{
			return false;
		}		
		
		return true;
	}
	
	
	function checkEnter(event)
	{ 	
		var code = 0;
		
		code = event.keyCode;
		if (code==13)
			submitForm(true);
	}
	
	
	function validateEnterKey() 
	{
		return false;
	}
	
	
	//set the default focus after loading the page.
	function setFocusOnFirstControl()
	{										
		document.creditCardInfo.txtCCData.focus();	
	}
	
	
	//Set the focus on PROCESS button.
	function setFocusOnControl()
	{				
		document.creditCardInfo.processButton.focus();
	}	
	

	//Set the focus on PROCESS button when enter key pressed.
	function captureKeyUpEvent()
	{
		if (event.keyCode == 13)
		{			
			event.returnValue = true;
			setFocusOnControl();
			event.keyCode = 0;
		}
	}
	
	
	function onNumberBlur() 
	{
	//This function fills the c.c. type, account#, exp.date, and name on card fields
	// when card is swiped.
	// If manually entering data, displays extra data entry fields.
	// Warns user of unsupported c.c. types
	//Used for all C.C. payments	
	
		document.creditCardInfo.style.cursor="default";
		swipeData = document.creditCardInfo.txtCCData.value;

		if(swipeData!="")	//This is a swiped card
		{
			var firstSwipeChar;
			firstSwipeChar = swipeData.substr(0,1);
		
			if(firstSwipeChar==";" || firstSwipeChar=="%") //This is a swiped CREDIT card
			{
					
				var splitSwipedData;
				splitSwipedData = swipeData.split(";");	//split into 2 lines
				
				var firstLine;
				firstLine = splitSwipedData[0];	//capture 1st line

				var splitFirstLine;
				splitFirstLine = firstLine.split("^");	//split 1st line
		
				ccCustName = splitFirstLine[1];
				if(ccCustName=="" || ccCustName == null)
				{
					ccCustName=""
				}
		
				var secondLine;
				secondLine=splitSwipedData[1];	//capture 2nd line

				var splitSecondLine;
				splitSecondLine = secondLine.split("=");	//split 2nd line
		
				accountNumber = splitSecondLine[0];
				if(isNaN(accountNumber.substr(0,1)))
				{
					accountNumber="";
				}
				
				if(splitSecondLine[1]!=null)
				{
					expirationDate = splitSecondLine[1];
					expirationDate = expirationDate.substr(0,4);
					expirationDate = expirationDate.substr(2,2)+expirationDate.substr(0,2);

				}
				else
				{
					expirationDate="";
				}
		
				document.creditCardInfo.txtCCNumber.value = accountNumber;
				document.creditCardInfo.txtCCExpDate.value = expirationDate;
				document.creditCardInfo.txtCCCustName.value = ccCustName;
		
				validCreditCard()
	
			}
			else	//This is NOT a CREDIT card
			{

			}
			
			document.creditCardInfo.txtCCData.value="";
			document.creditCardInfo.selCreditType.focus();
			return;
		}
		else	//This is NOT a swiped card
		{

			accountNumber = document.creditCardInfo.txtCCNumber.value;

			if (accountNumber.length != "")
			{
				validCreditCard()
			}

		}
		
		document.creditCardInfo.txtCCData.value="";
		lastFocusControl = document.getElementById(lastControl);

	}
	
	
	function validCreditCard()
	{
	//This function warns user of unsupported c.c. types
	//Called from onNumberBlur().  Used for all C.C. payments
	
		var firstDigits = document.creditCardInfo.firstDigits.value;
		var splitFirstDigits = firstDigits.split(",");
		var cardTypeArray = document.creditCardInfo.cardTypeArray.value;
		var splitcardTypeArray = cardTypeArray.split(",");				
		var validtype;
		validtype = false;
							
		for (i=0;i<splitFirstDigits.length;i++)
		{
			if(accountNumber.substr(0,1) == splitFirstDigits[i]
					|| accountNumber.substr(0,2) == splitFirstDigits[i]
					|| accountNumber.substr(0,3) == splitFirstDigits[i])
			{
				validtype = true;
				document.creditCardInfo.selCreditType.selectedIndex=splitcardTypeArray[i];
			}
		}
							
		if (validtype!=true)
		{
			alert("This is not an accepted credit card type.");
			document.creditCardInfo.selCreditType.selectedIndex=splitFirstDigits.length;
			document.creditCardInfo.txtCCNumber.value = "";
		}				
	}
	
	
	function setLastControl()
	{
		lastControl = document.activeElement.id;
	}
	
	
	function cancelForm() 
	{
		var custSeqNumber;
		custSeqNumber = document.creditCardInfo.custSeqNumber.value;
		document.creditCardInfo.action = "";
		document.creditCardInfo.submit();		
	}	
	
	function clearAll()
	{
		document.creditCardInfo.style.cursor="default";
		document.creditCardInfo.selCreditType.value = 0;
		document.creditCardInfo.txtCCNumber.value = "";
		document.creditCardInfo.txtCCExpDate.value = "";
		document.creditCardInfo.txtCCCustName.value = "";
		document.creditCardInfo.txtCCData.value = "";
		document.creditCardInfo.txtCCZip.value="";
		document.creditCardInfo.txtCCAddress.value="";
		document.creditCardInfo.txtCCcvc.value="";
		document.creditCardInfo.txtCCCity.value="";
		document.creditCardInfo.txtCCState.value="";
		document.creditCardInfo.fileStatus.value = 0;		
		accountNumber = null;
		expirationDate = null;
		ccCustName = null;
		document.creditCardInfo.processButton.disabled = false;
		setFocusOnFirstControl();
		submitForm(false);
	}
		
	
	//Checks if c.c. expiration date is valid
	function expDateCheck(expirationDate)
	{
		var d;
		var m, y;
		
		d = new Date();
		m = d.getMonth()+1;
		m = parseInt(m);
		y = d.getFullYear();
		y = parseInt(y);
	
		expirationYear = 20+expirationDate.substr(2,2);
		expirationYear = parseInt(expirationYear);
		expirationMonth = expirationDate.substr(0,2);
		expirationMonth = parseFloat(expirationMonth);	//for some reason parseInt will not properly convert all months

		if(expirationYear <= y)
		{
			if(expirationMonth < m)
			{
				return false;
			}
		}
		
		if(expirationMonth > 12)
		{
			alert("Invalid month.");
			return false;
		}
		
		return true;
	}


	function changeMouse()
	{
		document.creditCardInfo.style.cursor="wait";
	}
	
	
</script>

<BODY topmargin=0 leftmargin=0 onload="setFocusOnFirstControl();">

<center>

<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/cashdrawer.inc" -->
<!-- #include file="../include/localprinter.inc" -->

<B class="pageHeading">Please swipe or enter Credit Card information</B>
</center>

<FORM id="creditCardInfo" name="creditCardInfo" action="customerCreditCard.asp" method="post" onSubmit ="return validateEnterKey();" >

	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>"><!-- JJ added, 13Jan04	-->
	<INPUT type="hidden" name="custSeqNumber" value="<%= custSeqNumber%>">
	<INPUT type="hidden" name="empID" value="<%= empID%>">
	<INPUT type="hidden" name="terminalId" value="<%= terminalId%>">
	<INPUT type="hidden" name="sessionName" value="<%= sessionName%>">
	<INPUT type="hidden" name="custCreditCardTypeID" value="<%= custCreditCardTypeID%>">
	<INPUT type="hidden" name="custCreditCardNo" value="<%= custCreditCardNo%>">
	<INPUT type="hidden" name="custCreditCardName" value="<%= custCreditCardName%>">	
	<%custCreditCardExpDate = custCreditCardExpMonth&custCreditCardExpYear%>
	<INPUT type="hidden" name="custCreditCardExpDate" value="<%= custCreditCardExpDate%>">
	<INPUT type="hidden" name="custCreditCardCVC" value="<%= custCreditCardCVC%>">
	<INPUT type="hidden" name="billingAddress1" value="<%= billingAddress1%>">
	<INPUT type="hidden" name="billingAddress2" value="<%= billingAddress2%>">
	<INPUT type="hidden" name="billingAddress3" value="<%= billingAddress3%>">
	<INPUT type="hidden" name="billingCity" value="<%= billingCity%>">
	<INPUT type="hidden" name="billingState" value="<%= billingState%>">
	<INPUT type="hidden" name="billingZipCode" value="<%= billingZipCode%>">
	<INPUT type="hidden" name="billingAddressCombined" value="<%= billingAddressCombined%>">
	<INPUT type="hidden" name="onFile" value="<%= onFile%>">
	<INPUT type="hidden" name="fileStatus" value="<%= fileStatus%>">

	<INPUT id=txtCCData name=txtCCData maxLength=200 class=text style=" HEIGHT:1px; WIDTH:1px" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()" onClick="setLastControl()" onKeyPress="changeMouse()" tabindex=-1>
					
	<!-- Data fields -->
	<TABLE ALIGN=center WIDTH=90% BORDER=0 cols=4 CELLSPACING=2 CELLPADDING=0 style="font-size=12pt">
				
		<!-- Card Type -->
		<TR>
			<TD class="label" align="right" width=20%>Credit Card Type<font color=red> * </font>&nbsp;</TD>
			
			<TD><SELECT id=selCreditType name=selCreditType style="font-size=12pt" tabindex=1>
					<%
						dim creditCardTypes
						Set creditCardTypes = getCreditCardsTypes()
						if creditCardTypes.recordcount <> 0 then
							while not creditCardTypes.EOF
						%>
							<OPTION VALUE= "<%= creditCardTypes.Fields("creditcardTypeId").Value %>" <%if creditCardTypes.Fields("creditcardTypeId").Value = custCreditCardTypeID then %>selected<%end if%>> <%= creditCardTypes.Fields("name").Value %></OPTION>
						<%
								creditCardTypes.MoveNext
							wend
						else
						%>
							<OPTION VALUE= "1">No Credit Cards setup in Setup | Customer Setup</OPTION>
						<%
						end if
					%>	
			<Option value = "0" ></option>
			</SELECT></TD>
			
		<!-- Address -->
			<TD class="label" align="right">Address&nbsp;</TD>
			<TD width=40%><INPUT id=txtCCAddress name=txtCCAddress maxlength=50 class=text  align=left style="font-size=12pt;width=100%;border=0" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()" onClick="setLastControl()" tabindex=-1 readonly value="<%= billingAddressCombined%>" >  </TD>
		</TR>
		
		<!-- Card Number -->
		<TR>
			<TD class="label" align="right">Account Number<font color=red> * </font>&nbsp;</TD>
			<TD><INPUT id=txtCCNumber tabindex=2 name=txtCCNumber maxLength=200 class=text style="font-size=12pt" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()" onClick="setLastControl()" value="<%= custCreditCardNo%>" ></TD>
		<!-- City -->
			<TD class="label" align="right">City&nbsp;</TD>
			<TD><INPUT id=txtCCCity name=txtCCCity maxLength=55 class=text align=left style="font-size=12pt;border=0" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()"  tabindex=-1 readonly value="<%= billingCity%>"></TD>
			<INPUT type="hidden" name="firstDigits" value="<%= firstDigits%>" tabindex=-1>
			<INPUT type="hidden" name="cardTypeArray" value="<%= cardTypeArray%>" tabindex=-1>	
		</TR>
		
		<!-- Expiration Date -->
		<TR>
			<TD class="label" align="right">Expiration Date ("mmyy")<font color=red> * </font>&nbsp;</TD>
			<TD><INPUT id=txtCCExpDate tabindex=3 name=txtCCExpDate maxLength=4 class=text style="WIDTH: 50px;font-size=12pt" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" value="<%= custCreditCardExpDate%>"></TD>		
		<!-- State -->
			<TD class="label" align="right">State&nbsp;</TD>			
			<TD><INPUT id=txtCCState name=txtCCState maxLength=2 class=text align=left style="font-size=12pt;width=10%;border=0" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" tabindex=-1 readonly value="<%= billingState%>"></TD>						
		</TR>
		
		<!-- Customer Name on CARD -->
		<TR>
			<TD class="label" align="right" >Customer Name (on Credit Card)&nbsp;</TD>
			<TD><INPUT id=txtCCCustName name=txtCCCustName maxLength=20 class=text style="font-size=12pt;width=100%" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" tabindex=4 value="<%= custCreditCardName%>"></TD>
		<!-- Zip -->
			<TD class="label" align="right">Zip&nbsp;</TD>			
			<TD><INPUT id=txtCCZip name=txtCCZip maxLength=5 class=text align=left style="font-size=12pt;width=20%;border=0" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" tabindex=-1 readonly value="<%= billingZipCode%>"></TD>
		</TR>
		
		<!-- Space holders -->
		<TR>

		<!-- CVC -->
			<TD class="label" align="right">CVC&nbsp;</TD>			
			<TD> <INPUT id=txtCCcvc name=txtCCcvc maxLength=5 class=text  align=left style="font-size=12pt;width=23%" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()"  onClick="setLastControl()" tabindex=5 value="<%= custCreditCardCVC%>"></TD>				
			<TD align=right>
				<INPUT type=checkbox style = "height=28px;width=28px" id=ccBatchChk name=ccBatchChk 
					<%If allowCCBatch = 1 then %>
						checked						
					<%end if %>
						></TD>
			<TD>Allow Batch Credit Card Billing</TD>		
		</TR>
		

		
		<tr height=10><td align="middle" colspan=4><font color=red>Items marked with * are required.</td></tr>
		
		<!-- Buttons -->
		<tr>	
			<td align="middle" colspan=4>
				<INPUT class=touchnoborder id=processButton name=processButton type=button tabindex=6 style="BORDER-RIGHT: deepskyblue thick outset; BORDER-TOP: silver thick ridge; FONT-WEIGHT: bold; FONT-SIZE: 12pt; BORDER-LEFT: silver thick ridge; BORDER-BOTTOM: deepskyblue thick outset; BACKGROUND-REPEAT: no-repeat; FONT-STYLE: italic; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: deepskyblue" onClick="submitForm(true)" value="Add/Update">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<INPUT class=touchnoborder id=clearButton name=clearButton type=button tabindex=7 style="BORDER-RIGHT: thick outset; BORDER-TOP: snow thick ridge; FONT-WEIGHT: bold; FONT-SIZE: 12pt; BORDER-LEFT: snow thick ridge; BORDER-BOTTOM: thick outset; FONT-STYLE: italic; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: gainsboro; FONT-VARIANT: small-caps" onClick="clearAll()" value="Clear All">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;			
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button tabindex=8 style="BACKGROUND-IMAGE: url(../images/Cancel.gif)" onClick="history.back()" >
			</td>
		</tr>
		
	</TABLE>
	
	<!-- Keyboard -->
	<table ALIGN=center width="100%">
		<tr height=20><td></td></tr>
		<TR height=20 colspan="4"></TR>
		<tr>
			<td><!-- #include file="../include/keyboard.inc" --></td>
		</tr>
				
	</table>
	
</FORM>
</BODY>
</HTML>
