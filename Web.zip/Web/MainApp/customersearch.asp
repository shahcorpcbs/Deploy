<%@ Language=VBScript %>
<%option explicit%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->

<!--#include file="../external/include.asp" -->
<!--#include file="../include/messages.asp" -->
<%
	include getBarcodeEncoderFilename()
	function getBarcodeEncoderFilename()
		on error resume next
		getBarcodeEncoderFilename = "/include/barcode.asp"
		getBarcodeEncoderFilename = getMSVar("BarcodeEncoderFile")
	end function
%>


<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim smartsearch
	dim customerid
	dim customerseq
	dim shownotes
	dim targetpage
	dim fromCustSeqNum
	dim routeID
	dim customerDeliveryID
	dim matched, matchedCustId

    matched = 0
	smartsearch = request.querystring("smartsearch")
	if smartsearch = "" then
		smartsearch = request.querystring("q")
	end if

	customerid = request.querystring("customerid")
	fromCustSeqNum = Request.QueryString("fromCustSeqNum")
	if fromCustSeqNum = "" then fromCustSeqNum = Request.Form("fromCustSeqNum")
	routeID = Request.QueryString("routeID")
	customerDeliveryID = Request.QueryString("customerDeliveryID")
	
	loadCustomer customerID
	if smartsearch <> "" then
		checkForBarcode smartsearch
		checkForTickets smartsearch
		checkForPhone smartsearch
		if matched = 1 then
		    loadCustomer matchedCustId
		end if
	end if
	targetpage = trim(request.querystring("targetpage"))

	if targetpage = "" then
		targetpage =  request.querystring("useraction")
		if targetpage = "" then
			targetpage = "customerfunctions"
		end if
	end if

	function checkForTickets(smartsearch)
		dim query, rs
		
		query = "select customer.customerid from customer, ticket where customer.isactive = 1 and customer.customersequencenumber = ticket.customersequencenumber and ticket.invoicenumber = '" & DBStr(trim(smartsearch)) & "'"
		set rs = getdisconnectedrecordset(query)

		matched = matched + rs.recordcount
		if rs.recordcount = 1 then
			matchedCustId = rs("customerid")
		end if

		query = "select c.customerid, t.invoiceNumber from customer c, ticket t, InvoiceSubDivision isd where c.isactive = 1 and " _
		    & "c.customersequencenumber = t.customersequencenumber and t.ticketNumber = isd.ticketNumber and " _
		    & "SubLabel = '" & DBStr(trim(smartsearch)) & "'"
		set rs = getdisconnectedrecordset(query)

		matched = matched + rs.recordcount
		if rs.recordcount = 1 then
			matchedCustId = rs("customerid")
			smartSearch = rs("invoiceNumber")
		end if

	end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

	
	function checkForBarcode(smartsearch)
		dim barcode
		dim query, rs

		set barcode = new BarcodeEncoder

		if barcode.LoadBarcode(smartsearch) then
			if barcode.TicketNumber <> "" then
				query = " select customer.customerid from "
				query = query & " ticket "
				query = query & " inner join customer on ticket.customersequencenumber = customer.customersequencenumber "
				query = query & " where ticket.ticketnumber = " & barcode.TicketNumber
			elseif barcode.InvoiceNumber <> "" then
				query = " select customer.customerid from "
				query = query & " ticket "
				query = query & " inner join customer on ticket.customersequencenumber = customer.customersequencenumber "
				query = query & " where ticket.invoicenumber = '" & dbstr(barcode.InvoiceNumber) & "'"
			end if
			
			set rs = getdisconnectedrecordset(query)

            matched = matched + rs.recordcount
            if rs.recordcount = 1 then
                matchedCustId = rs("customerid")
            end if
		end if
	end function

	function checkForPhone(smartsearch)
		dim query, rs
		dim phoneSearch
		
		phoneSearch = smartsearch
		phoneSearch = replace(phoneSearch, "(", "")
		phoneSearch = replace(phoneSearch, ")", "")
		phoneSearch = replace(phoneSearch, "-", "")
		phoneSearch = replace(phoneSearch, " ", "")
		 
		query = "select customer.customerid from customer where customer.isactive = 1 and (customer.mainphone = '" & DBStr(trim(phoneSearch)) & "' or customer.mainareacode + customer.mainphone = '" & DBStr(trim(phoneSearch)) & "'"
		query = query & " or customer.altphone = '"  & DBStr(trim(phoneSearch)) & "' or customer.altareacode + customer.altphone = '" & DBStr(trim(phoneSearch)) & "'"
		query = query & " or customer.cellphone = '" & DBStr(trim(phoneSearch)) & "' or right(customer.cellphone, 7) = '" & DBStr(trim(phoneSearch)) & "')"

		set rs = getdisconnectedrecordset(query)

		matched = matched + rs.recordcount
		if rs.recordcount = 1 then
			matchedCustId = rs("customerid")
		end if
	
	end function
	
	function loadCustomer(customerID)
		dim query, rs
		
		if customerID <> "" then
			query = "select customersequencenumber, shownotesoneachaccess from customer where customer.isactive = 1 and customerid = '" & customerid & "'"
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount = 1 then
			
				customerseq = rs("customersequencenumber")
				
				if rs("shownotesoneachaccess") then
					shownotes = 1
				else
					shownotes = 0
				end if
				
			end if
			set rs = nothing
		end if
	end function

%>

<HTML>
<HEAD>
<TITLE>Customer Search</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../External/jquery-1.6.4.js"></script>

<SCRIPT language="javascript" type="text/javascript">

	var previousElement=null;
	var timer = null;


	function resetTimeout() {
		if(timer != null) {
			clearTimeout(timer);
		}
		timer = setTimeout("doUpdate();", 200);
	}
	function cancelTimeout() {
		clearTimeout(timer);
		timer = null;
	}	

	function gotoTargetPage(targetPage, customerSeq, showNotes){

		if (showNotes && targetPage != "commonbilling") {
		    if (targetPage =="mergeCustTo")
		        document.custSearch.action = "CustomerNotes.asp?targetpage=" + targetPage +  "&customerseq=" + customerSeq +"&fromCustSeqNum=" + fromCustSeqNum.value;
		    else
                document.custSearch.action = "CustomerNotes.asp?targetpage=" + targetPage +  "&customerseq=" + customerSeq;
            document.custSearch.submit();
		}
		else{
			if (targetPage=="CustomerFunctions") {
                document.custSearch.action = "CustomerFunctions.asp?customerseq=" + customerSeq + "&entry=<%=Server.URLEncode(smartsearch)%>";
                document.custSearch.submit();
			}
			else if (targetPage=="search") {
                document.custSearch.action = "<%=request.querystring("dest")%>" + customerSeq;
                document.custSearch.submit();
			}
			else if (targetPage=="ChangeCustomerFunctions") {
                document.custSearch.action = "CustomerFunctions.asp?customerseq=" + customerSeq;
                document.custSearch.submit();
			}
			else if (targetPage=="route") {
                document.custSearch.action = "/setup/RouteAddEdit.asp?mode=edit&customerseq=" + customerSeq + "&routeID=" + routeID.value ;
                document.custSearch.submit();
			}
			else  if (targetPage =="applypayments") {
                document.custSearch.action = "/mainapp/ApplyPayments.asp?customerseq=" + customerSeq;
                document.custSearch.submit();
			}
			else  if (targetPage =="issuecharge") {
                document.custSearch.action = "/mainapp/issueCreditOrCharge.asp?customerseq=" + customerSeq;
                document.custSearch.submit();
			}
			else  if (targetPage =="runstatements") {
				document.custSearch.action = "/mainapp/runStatements.asp?customerseq=" + customerSeq;
                document.custSearch.submit();
			}
			else  if (targetPage =="scheduledelivery") {
				document.custSearch.action = "/mainapp/scheduleDelivery.asp?customerseq=" + customerSeq;
                document.custSearch.submit();
			}
			else  if (targetPage =="reportParams") {
				document.custSearch.action = "/mainapp/reportParams.asp?customerSequenceNumber=" + customerSeq;
                document.custSearch.submit();
			}
			else  if (targetPage =="mergeCustFrom") {
				document.custSearch.action = "/mainapp/mergeCustomers.asp?fromPage=searchFrom&fromCustSeqNum=" + customerSeq;
                document.custSearch.submit();
			}						
			else  if (targetPage =="mergeCustTo") {
				document.custSearch.action = "/mainapp/mergeCustomers.asp?fromPage=searchTo&toCustSeqNum=" + customerSeq + "&fromCustSeqNum=" + fromCustSeqNum.value;
                document.custSearch.submit();
			}
			else if (targetPage == "issueSingleGiftCard") {
				document.custSearch.action = "/mainapp/issueSingleGiftCard.asp?userAction=initialize&customerSequenceNumber=" + customerSeq;
                document.custSearch.submit();
			}
			else if (targetPage == "issueMultiToCust") {
				document.custSearch.action = "/mainapp/issueMultiToCust.asp?userAction=initialize&customerSequenceNumber=" + customerSeq;
                document.custSearch.submit();
			}	
			else if (targetPage == "customerdiscount") {
				document.custSearch.action =  "/mainapp/customerdiscount.asp?targetpage=customerentry&customerseq=<%=session("prevcustomersequencenumber")%>&referredby=" + customerSeq;
                document.custSearch.submit();
			}	
			else if (targetPage == "commonbilling") {
				document.custSearch.action =  "/mainapp/customerpayment.asp?targetpage=customerentry&customerseq=<%=session("prevcustomersequencenumber")%>&billingcustomerseq=" + customerSeq;
                document.custSearch.submit();
			}	
			else if (targetPage == "parentcustomer") {
				document.custSearch.action =  "/mainapp/customerpayment.asp?targetpage=customerentry&customerseq=<%=session("prevcustomersequencenumber")%>&parentcustomerseq=" + customerSeq;
                document.custSearch.submit();
			}	
			else if (targetPage == "routesetup") {
				document.custSearch.action =  "/setup/routeSetup.asp?userAction=adddelivery&customerseq=" + customerSeq;
                document.custSearch.submit();
			}	
			else if (targetPage == "customermanagement") {
				document.custSearch.action =  "/mainapp/customermanagement.asp?customerseq=" + customerSeq;
                document.custSearch.submit();
			}	
			else if (targetPage == "queryparams") {
				document.custSearch.action =  "/mainapp/queryparams.asp?customerseq=" + customerSeq;
                document.custSearch.submit();
			}	
			else if (targetPage=="routecustomerbilling") {
				document.custSearch.action = "/setup/routesetup.asp?useraction=assignbilling&routeNumber=" + routeID.value + "&customerSeq=" + customerSeq + "&customerDeliveryID=" + customerDeliveryID.value;
                document.custSearch.submit();
			}
			else {
				document.custSearch.action = "CustomerFunctions.asp?customerseq=" + customerSeq + "&entry=<%=Server.URLEncode(smartsearch)%>";
                document.custSearch.submit();
			}
		}
	}
	
	function cancelForm(targetPage){
		if (targetPage=="CustomerFunctions") {
				document.custSearch.action = "start2.asp";
                document.custSearch.submit();
			}
			else if (targetPage=="seach") {
				document.custSearch.action = "<%=request.querystring("dest")%>";
                document.custSearch.submit();
			}
			else if (targetPage=="ChangeCustomerFunctions") {
				document.custSearch.action = "/mainapp/customerfunctions.asp?customerseq=<%=session("customersequencenumber")%>";
                document.custSearch.submit();
			}
			else if (targetPage=="route") {
				document.custSearch.action = "/setup/RouteAddEdit.asp?routeID=" + routeID.value ;
                document.custSearch.submit();
			}
			else  if (targetPage =="applypayments") {
				document.custSearch.action = "/mainapp/accountMgmt.asp";
                document.custSearch.submit();
			}
			else  if (targetPage =="issuecharge") {
				document.custSearch.action = "/mainapp/accountMgmt.asp";
                document.custSearch.submit();
			}
			else  if (targetPage =="runstatements") {
				document.custSearch.action = "/mainapp/accountMgmt.asp";
                document.custSearch.submit();
			}
			else  if (targetPage =="scheduledelivery") {
				document.custSearch.action = "/mainapp/scheduleDelivery.asp";
                document.custSearch.submit();
			}
			else if (targetPage=="routesetup") {
					document.custSearch.action = "/setup/routeSetup.asp";
                document.custSearch.submit();
			}
			else if (targetPage=="customermanagement") {
					document.custSearch.action = "/mainapp/customermanagement.asp?customerseq=<%=session("prevcustomersequencenumber")%>";
                document.custSearch.submit();
			}
			else if (targetPage=="customerdiscount") {
					document.custSearch.action = "/mainapp/customerdiscount.asp?targetpage=customerentry&customerseq=<%=session("prevcustomersequencenumber")%>";
                document.custSearch.submit();
			}
			else if (targetPage=="commonbilling") {
				document.custSearch.action = "/mainapp/customerpayment.asp?targetpage=customerentry&customerseq=<%=session("prevcustomersequencenumber")%>";
                document.custSearch.submit();
			}
			else if (targetPage=="parentcustomer") {
				document.custSearch.action = "/mainapp/customerpayment.asp?targetpage=customerentry&customerseq=<%=session("prevcustomersequencenumber")%>";
                document.custSearch.submit();
			}
			else if (targetPage=="queryparams") {
				document.custSearch.action = "/mainapp/queryparams.asp";
                document.custSearch.submit();
			}
			else if (targetPage=="routecustomerbilling") {
				document.custSearch.action = "/setup/routesetup.asp?routeNumber=" + routeID.value;
                document.custSearch.submit();
			}
			else {
				document.custSearch.action = "start2.asp";
                document.custSearch.submit();
			}
	}




function exit() {
	cancelForm(targetPage.value);
}


function loadDefaultSearch() {
	if(custSearch.searchField.value != "") {
		doUpdate(custSearch.searchField.value);
	}
		
  	<% if getDefaultSearchMethod(session("storeid")) = "CUSTOMERID" then %>

  	  custSearch.customerID.focus();
  	  custSearch.customerID.select();
  	<% else %>
  	  custSearch.searchField.focus();
  	  custSearch.searchField.select();
  	<% end if %>
  	

	
}

function filterPickups() {
	$("tr[rackedinvoices=0][isactive=1]").toggle();
	if (!$('#customerID').is(':focus')) {
        custSearch.searchField.focus();
        custSearch.searchField.select();
	}
}

function toggleInactives() {
	$("tr[isactive=0]").toggle();
 	$("#showInactiveButton").toggle();
	custSearch.searchField.focus();
	custSearch.searchField.select();
}

document.onkeypress = function (e) {
    e = e || window.event;
    if (e.keyCode == 13) {
        if (previousElement != null)
		    selectCustomer();
    }
};


function updateSearch() {
	var text = custSearch.searchField.value;
	if(event.keyCode == 13) {
		if(text.length > 0) {
			cancelTimeout();
			doUpdate();
		}
		else {
            cbs_confirm("Show all customers?", showAll);
		}
	} else if(text.length > 2) {
		//doUpdate();
		resetTimeout();
	}
	else {
		clearResults();
	}
}

    function showAll() {
        clearConfirmMsg();
        cancelTimeout();
        doUpdate();
    }

function clearResults() {
	$("#searchResults").empty();
	$("#searchResults").append("<H3>No Results</H3>");
}

function showWaiting() {
	$('#searchResults').empty();
	$('#searchResults').append('<DIV style="margin-top: 30px; text-align: center"><IMG src="/static/images/spinner.gif" /></DIV>');


}

function doUpdate() {
	var text = custSearch.searchField.value;
	
	previousElement = null;
	showWaiting();
	$("#searchResults").load("customersearchresults.asp", {searchText: text} );
}

function selectRow(element) {
	if (previousElement != null){
		previousElement.className= "";
	}
	previousElement = element;
	element.className = "selected";
}

function selectCustomer() {
    if (previousElement != null) {
        if(previousElement.getAttribute('isactive') == 1 || targetPage.value === "reportParams") {
            gotoTargetPage(targetPage.value, previousElement.getAttribute('customerseq'), (previousElement.getAttribute('shownotes') === "true"));
        }
        else {
            cbs_alert("Customer must first be activated.");
        }
	}
}

function checkForCustomerSeq() {
	if(customerSeq.value != "") {
		gotoTargetPage(targetPage.value, customerSeq.value, (showNotes.value != "0"));
	}
	else {
		$("#searchResults").append("<H3>No Results</H3>");
	}

}

function searchByCustomerID(customerID) {
	if(event.keyCode == 13) {
		document.custSearch.action = "customersearch.asp?targetpage=" + targetPage.value + "&customerid=" + customerID +
						"&fromCustSeqNum=" + fromCustSeqNum.value;
		document.custSearch.submit();
	}
}

function addNewCustomer(){
	var search;
	
	search = custSearch.searchField.value;
	
	if(isInteger(search)) {
		if(search.length >= 7)
			document.custSearch.action = "customerentry.asp" + "?mode=add&phone=" + escape(search) ;
		else
			document.custSearch.action = "customerentry.asp" + "?mode=add";
	}
	else
		document.custSearch.action = "customerentry.asp" + "?mode=add&lastname=" + escape(search) ;

	document.custSearch.submit();
}

function isInteger(s)
{
	var i, c;
	
	for (i = 0; i < s.length; i++) {   
		c = s.charAt(i);
		if ((c < "0") || (c > "9"))
			return false;
	}
	return true;
}

</SCRIPT>

</HEAD>
<BODY topmargin=0 leftmargin=0 onload="checkForCustomerSeq();loadDefaultSearch();">
<!-- #include file="../include/banner.inc" -->

<INPUT type="hidden" name="targetPage" id="targetPage" value="<%= trim(targetpage) %>">
<INPUT type="hidden" name="customerSeq" id="customerSeq" value="<%= trim(customerseq) %>">
<INPUT type="hidden" name="showNotes" id="showNotes" value="<%= trim(shownotes) %>">
<INPUT type="hidden" name="fromCustSeqNum" id="fromCustSeqNum" value="<%= trim(fromCustSeqNum) %>">
<INPUT type="hidden" name="routeID" id="routeID" value="<%= trim(routeID) %>">
<INPUT type="hidden" name="customerDeliveryID" id="customerDeliveryID" value="<%= trim(customerDeliveryID) %>">

<H1>Customer Search</H1>

<FORM name="custSearch" ID="custSearch" onSubmit="return false;" METHOD=POST  style="margin:0;padding:0">
<TABLE align="center">
	<TR>
		<TD>
			Name, Invoice, or Phone<BR />
			<INPUT name="searchField" id="searchField" style="font-size:20" onkeyup="updateSearch()" value="<%=smartsearch%>" />
		</TD>
		<TD>
			Customer ID<BR />
			<INPUT name="customerID" id="customerID" style="font-size:20" onkeyup="searchByCustomerID(this.value)" />
		</TD>
		<TD style="padding-left:20px">
			<BUTTON style="height:50px;width:100px" onclick="filterPickups()">Only Racked<BR />Invoices</BUTTON>
		</TD>
	</TR>

</TABLE>
<BR />

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="selectCustomer()">Select</BUTTON>
	</SPAN>

	<SPAN style="float:right">
		<BUTTON style="vertical-align: top" onclick="addNewCustomer()">New<BR />Customer</BUTTON>
		<BUTTON onclick="exit()">Exit</BUTTON>

	</SPAN>
</DIV>	

<DIV id="searchResults" style="height:550px;width:100%;overflow-y:scroll;background:white" >
	
</DIV>
</FORM>
</BODY>
</HTML>

