
<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!-- #include file="CheckSessionExpiry.asp" -->
<!--#include file="../include/SystemStartup.asp"-->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim storeID
	dim ObjMiscSetUp
	dim buttonCount
	'on error resume next
	
	buttonCount = 1
	storeID = Session(storeid)
	if storeID = "" then
		'Response.Redirect "/mainapp/login.asp?target=/mainapp/autoReporting.asp"
		' Security needs to be implemented. For now set store to 1
		storeID = 1
	end if
	
	dim objRSReportList
	Set objRSReportList = getDisconnectedRecordset("select * from reportGroupDomain") 
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & "-Function= Report List. Error while creating the report list."
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if
	
		
%>

<HTML>
<HEAD>
<META HTTP-EQUIV="refresh" content="120;URL=../MainApp/start2.asp">
<TITLE>Report List</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="JavaScript">
	function ExitApplication() {
		document.getElementById('ExitForm').submit();
		//window.setTimeout("window.close()", 000);
	}
</script>
<FORM name="ExitForm" ID="ExitForm" METHOD="POST" ACTION="/mainapp/exit.asp"></FORM>

<script language="javascript" type="text/javascript">
	function setFrequency(reportName) {
		//alert(reportName);
		document.autoReportingForm.action = "frequency.asp?reportName=" + reportName;
		document.autoReportingForm.submit();
	}
	function toggleGroup(groupName) {
		document.autoReportingForm.action = "?toggleGroup=" + groupName;
		document.autoReportingForm.submit();
	}
	function goToReport(reportLink) {
	    document.autoReportingForm.action = reportLink;
	    document.autoReportingForm.submit();
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->

<H1>Report Groups</H1>


<FORM id="autoReportingForm" name="autoReportingForm" action="" method="post">

	<INPUT type="hidden" name="functionID" value="<%=ACCESS_MANAGER_MENU_FROM_HOME_PAGE%>">

<TABLE WIDTH="600px" ALIGN=center BORDER=0 CELLSPACING=0 CELLPADDING=0>
	<%		
	if objRSReportList.recordcount > 0 then
		while (not objRSReportList.EOF)
	%>
		<% if buttonCount = 1 then %>
		<tr>
		<% end if %>		
		<% buttonCount = buttonCount + 1%>
		<td align="center" >
			<BUTTON class=std style="width:200px;height:100px;font-size:12px" id=PreviewReportGroup1 name=PreviewReportGroup1
				onClick="goToReport('reportList.asp?reportGroupID=<%= objRSReportList("reportGroupID") %>&groupName=<%=Server.URLEncode(objRSReportList("reportGroupName"))%>')">
                <%= objRSReportList("reportGroupName") %></button>
		</td>
			<% if buttonCount = 4 then 
				buttonCount = 1 %>
			</tr>
			<% end if %>
	<%		
		
		objRSReportList.MoveNext
					
		wend
		
		objRSReportList.Close
		set objRSReportList = nothing
		
	end if
	%>

</table>

<P>
<P>
<TABLE width=100%>
<tr>
			<td width = 100% align=center >
				<INPUT class=touchnoborder id=close name=close type=button value="" onClick="location.href='managermenu.asp'" 
					style="background-image:url(../images/Cancel.gif);">
			</td>

</tr>
</TABLE>

</BODY>
</HTML>
