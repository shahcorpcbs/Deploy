<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs, query2, rs2
	dim dateBegin, dateEnd
	dim searchText, msgDirection, storeId, storeType
	dim pagenum, idx, cnt

	pagenum = Request.QueryString("pagenum")
	if pagenum = "" then pagenum = 1


    query = "select storeType from store"
    set rs = getdisconnectedrecordset(query)
    storeType = cInt(rs("storeType"))


    msgDirection = Request.QueryString("msgDirection")
    if msgDirection = "" then msgDirection = 0


    storeId = getReqVar("storeId")
    if storeId = "" then storeId = 0

	dateBegin = getReqVar("dateBegin")
	dateEnd = getReqVar("dateEnd")
	if dateBegin = "" then dateBegin = dateadd("m",-1,date())
	if dateEnd = "" then dateEnd =  dateadd("d",1,date())


    query = "select Id, CreatedDate, storeId, ItemCnt, MessageStatus, MessageType, Direction from StoreConnectionHistory where " _
        & " datediff(day, CreatedDate, '" & dateBegin & "') <= 0 and datediff(day, CreatedDate, '" & dateEnd & "') >= 0 "

    if storeId <> 0 then
        query = query & " and storeId = " & storeId
    end if

    if msgDirection = 1 then
        query = query & " and direction = 1 "
    elseif msgDirection = 2 then
        query = query & " and direction = 2 "
    end if

	query = query & " order by createdDate asc "
	set rs = getdisconnectedrecordset(query)
	cnt = rs.recordcount
	rs.pagesize = 40
	if cnt > 0 then
        rs.absolutepage = pagenum
    end if


	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
%>
<HTML>
<HEAD>
<TITLE>Manifest History</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">

	function nextPage() {
		document.plantManifestHistory.action  = "?pagenum=" + (parseInt(document.plantManifestHistory.pagenum.value) + 1)  + createActionString();
		document.plantManifestHistory.submit();
	}

	function prevPage() {
		document.plantManifestHistory.action  = "?pagenum=" + (parseInt(document.plantManifestHistory.pagenum.value) - 1) + createActionString();
		document.plantManifestHistory.submit();
	}

	function goToPage(pagenumber) {
		document.plantManifestHistory.action  = "?pagenum=" + pagenumber + createActionString();
		document.plantManifestHistory.submit();
	}

	function createActionString() {
	    return "&dateBegin=" + $("#dateBegin").val() + "&dateEnd=" + $("#dateEnd").val() + "&msgDirection=" +
	        $("#directSel").val() + "&storeId=" + $("#setupIdSel").val();
	}

    function update() {
		document.plantManifestHistory.action = "?useraction=update" + createActionString();
		document.plantManifestHistory.submit();
    }

	function viewItems(connectionId) {
        document.plantManifestHistory.action = "/MainApp/plantManifestItems.asp?connectionId=" + connectionId;
        document.plantManifestHistory.submit();
	}

	function connectStoreToManifest(connectionId) {
        document.plantManifestHistory.action = "/MainApp/connectManifest.asp?connectionId=" + connectionId;
        document.plantManifestHistory.submit();
	}

	function goToMissing(direction) {
        document.plantManifestHistory.action = "/MainApp/plantNotArrivedItems.asp?direction=" + direction;
        document.plantManifestHistory.submit();
	}

	function exit() {
        document.plantManifestHistory.action = "/MainApp/toolsMenu.asp"
        document.plantManifestHistory.submit();
	}
</script>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Plant/Drop Store Manifests</H1>

<FORM id="plantManifestHistory" name="plantManifestHistory" action="" method="post" onsubmit="return false;">
<input type=hidden name="pagenum" value="<%= pagenum%>">

<table>
    <tr>
        <td>Date range</td>
        <td>
            <INPUT id="dateBegin" name="dateBegin" value="<%=dateBegin%>" readonly onclick="javascript:show_calendar('plantManifestHistory.dateBegin');">
            to
            <INPUT id="dateEnd" name="dateEnd" value="<%=dateEnd%>" readonly onclick="javascript:show_calendar('plantManifestHistory.dateEnd');">
        </td>
        <td rowspan="2"><BUTTON type="button" class="cmdbar" style="min-width: 75px" onclick="update()">Search</BUTTON></td>
    </tr>
    <tr>
        <td>Direction</td>
        <td>
            <select id="directSel" >
                <option value="0" <% if msgDirection = 0 then %>selected <% end if %>>Both</option>
                <option value="1" <% if msgDirection = 1 then %>selected <% end if %>>Received</option>
                <option value="2" <% if msgDirection = 2 then %>selected <% end if %>>Sent</option>
            </select>
        </td>
    </tr>
    <tr>
    <td>
        <% if storeType = 1 then %>Drop<% else %>Plant<% end if %> Store
    </td>
    <td>
            <select id="setupIdSel" >
                <option value="0" <% if storeId = 0 then %>selected <% end if %>>All</option>
                <% if storeType = 1 then
                    query2 = "select id, nickName from DropStoreSetup where disabled = 0"
                else
                    query2 = "select id, nickName from PlantStoreSetup where disabled = 0"
                end if
                set rs2 = getdisconnectedrecordset(query2)
                while not(rs2.eof or rs2.bof)
                %>
                <option value='<%= rs2("id")%>' <% if cInt(rs2("id")) = cInt(storeId) then %>selected <% end if %>>
                <%= rs2("nickName")%></option>
                <%
                	rs2.movenext
                	wend
                %>
            </select>
    <td>

    </td>
    </tr>

</table>
<br />
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
        <BUTTON onclick="goToMissing(1)">Waiting For At Plant</BUTTON>
        <BUTTON onclick="goToMissing(3)">Waiting For At<div style="white-space:nowrap">Drop Store</div></BUTTON>
        <SPAN style="float:right">
            <BUTTON onclick="exit()">Exit</BUTTON>
        </SPAN>
</DIV>
<div style="height: 640px; overflow: scroll">
<table class="itable" width="100%" cellspacing="0">
<tr>
	<% if msgDirection = 1 then %>
	    <th>Date Received</th>
	<% elseif msgDirection = 2 then %>
	    <th>Date Sent</th>
	<% else %>
	    <th>Date Received/Sent</th>
	<% end if %>
	<% if msgDirection = 0 then %>
	    <th>Direction</th>
	<% end if %>
	<th>Type</th>
	<th>Store Alias</th>
	<th>Count</th>
	<% if msgDirection <> 1 then %>
	    <th>Status</th>
	<% end if %>
	<th>&nbsp;</th>
</tr>

<%
	while not(rs.eof or rs.bof) and idx < rs.pagesize
%>
    <tr connectionId="<%=rs("id")%>">
        <td><%= rs("CreatedDate") %></td>
	    <% if msgDirection = 0 then %>
	        <td>
            <% if rs("direction") = 1 then %>
            Received
            <% else %>
            Sent
            <% end if %>
            </td>
	    <% end if %>
	    <td>
            <% if rs("MessageType") = 1 then %>
            Manifest Created
            <% elseif rs("MessageType") = 2 then %>
            Received At Plant
            <% elseif rs("MessageType") = 3 then %>
            Cleaned At Plant
            <% elseif rs("MessageType") = 4 then %>
            Returned to Drop
            <% end if %>
        </td>
        <td>
           <% if rs("storeId") <> "" then
                if storeType = 1 then
                    query2 = "select nickName from DropStoreSetup where id = " & rs("storeId")
                else
                    query2 = "select nickName from PlantStoreSetup where id = " & rs("storeId")
                end if
                set rs2 = getdisconnectedrecordset(query2)
                if rs2.recordcount > 0 then %>
                     <%= rs2("nickName") %>
                 <% else %>
                     <a href="#" onclick="connectStoreToManifest('<%=rs("id")%>'); return false">Unable to Connect</a>
                 <% end if %>
            <% else %>
                <a href="#" onclick="connectStoreToManifest('<%=rs("id")%>'); return false">Unable to Connect</a>
            <% end if %>
        </td>
        <td><%= rs("ItemCnt") %></td>
        <% if msgDirection <> 1 then %>
            <td>
                <% if rs("direction") = 1 then %>
                    Received
                <% elseif rs("MessageStatus") = 0 then %>
                    Created
                <% elseif rs("MessageStatus") = 1 then %>
                    Sent Successfully
                <% elseif rs("MessageStatus") = -1 then %>
                    Error, Will Not Retry
                <% elseif rs("MessageStatus") = -2 then %>
                    Error Connecting, Will Retry
                <% end if %>
            </td>
        <% end if %>
        <td><input type="button" value="View Items" class="btn" onclick="viewItems('<%=rs("id")%>')" /></td>
    </tr>
<%
    idx = idx + 1
	rs.movenext
	wend
%>
</table>

<%
				if rs.pagecount > 1 then
%>
				<span style="float:left">
				<button style="height:50px;width:80px" onclick="prevPage()" <% if pagenum = 1 then %>disabled <%end if %>>Prev</button>
				<button style="height:50px;width:80px" onclick="nextPage()" <% if cInt(pagenum) = rs.pagecount then %>disabled <%end if %>>Next</button>

				Page
				<select onchange="goToPage(this.value)" >
<%
				for idx = 1 to rs.pagecount
%>
					<option value="<%=idx%>" <%if trim(idx) = trim(pagenum) then%>selected<%end if%>><%=idx%></option>
<%
				next
%>
				</select>
				of <%=rs.pagecount%>
				</span>
<%
				end if
%>
</div>

<div style="height: 100px"></div>

</FORM>
</BODY>
</HTML>

