<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<%
	dim query, rs
	dim customerseq
	dim selectedroute
	dim primaryroute
	
	customerseq = getReqVar("customerseq")
	selectedroute = getReqVar("selectedroute")
	primaryroute = getPrimaryRoute(customerseq)
	
	select case lcase(request.querystring("useraction"))
	case "submit"
		updateCustomerPrimaryRoute
	end select
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function updateCustomerPrimaryRoute()
		dim query, rs
		
		query = " update customer set routeNumber = " & request.form("routeNumber")
		query = query & " where customersequencenumber = " & customerseq
		
		
		qryexecute query
	end function
	
	function getPrimaryRoute(customerseq)
		dim query, rs
		
		query = " select routenumber from customer where customersequencenumber = " & customerseq
		
		set rs = getdisconnectedrecordset(query)
		
		getPrimaryRoute = rs("routenumber")
		
		set rs = nothing
	
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">
	function submitForm() {
		document.customerPrimaryRoute.action = "?useraction=submit";
		document.customerPrimaryRoute.submit() ;
	}
	
	function closeForm() {
		opener.primaryRouteSelected()
		window.close();
	}
	
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="<%if request.querystring("useraction") = "submit" then response.write "closeForm()" end if%>">

<FORM id="customerPrimaryRoute" name="customerPrimaryRoute" method="post" style="padding:10px">
<INPUT type="hidden" name="customerseq" value="<%=customerseq%>" />
<INPUT type="hidden" name="selectedroute" value="<%=selectedroute%>" />

<CENTER>
Select primary route for customer.  This is the route the customer will appear under for reporting purposes.
<BR />
<BR />
<%
	query = " select distinct route.routeNumber, route.name "
	query = query & " from route "
	query = query & " where route.routeNumber in (select customerDelivery.routeid from customerDelivery where active = 1 and customerDelivery.customersequencenumber = " & customerseq 

	if selectedroute <> "" then
		query = query & " union select " & selectedroute 
	end if
	
	query = query & " union select 0)"
	

	set rs = getdisconnectedrecordset(query)
%>
	<SELECT name="routeNumber">
<%	
	while not (rs.eof or rs.bof)
%>
		<OPTION value="<%=rs("routeNumber")%>" <%if trim(rs("routenumber")) = trim(selectedroute) then%>selected<%end if%>><%=rs("name")%> <%if rs("routenumber") = primaryroute then%> (Selected)<%end if%></OPTION>
<%
		rs.movenext
	wend
%>
	</SELECT>
<%
	set rs = nothing
%>
<BR /> <BR />
<INPUT style="width:100px;height:50px" type="button" value="Ok" onclick="submitForm()" />

</CENTER>

</FORM>

</BODY>
</HTML>
