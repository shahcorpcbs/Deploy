<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim l_storeid
	dim isSubmitted 
	dim l_customerseq

    dim userIPAddress, printerIP, printerName
	getCashDrawerFields()
		
	l_storeid = Session("storeid")

	l_customerseq = trim(Request.QueryString("CustomerSeq"))

	if l_customerseq = "" then
		l_customerseq = Request.form("customerseq")
	end if
	isSubmitted = Request.QueryString("submitted")
	
	if isSubmitted then
		updateDatabase()
		
		if trim(Request.QueryString("continue")) <> "true" then
			Response.Redirect ("accountMgmt.asp")
		end if
	end if

	getCustomerInfo()

	function getCashDrawerFields()
	    dim query, rs
	    printerIP = getPrinterShortPath()

        query = " select storehardware.cashdrawertype, isnull(printer.printername, '') as printername "
        query = query & " from storehardware "
        query = query & " left outer join printer on storehardware.cashdrawerattachedprinterid = printer.printerid "
        query = query & " where storehardware.hardwaretype = 'CD' "
        query = query & " and storehardware.terminalid = " & session("terminalid")

        set rs = getdisconnectedrecordset(query)
        if rs.recordcount > 0 then
            printerName = Replace(rs("printername"), "'", "\'")
        end if


        userIPAddress = getLocalPrinterAddress(session("terminalid"))

	end function
%>

<HTML>
<HEAD>
<TITLE>Issue Credit Or Charge</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="/script/cashdrawer.js"></script>
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">

	function submitForm(cont){
		if (trim(document.issueCreditChargeForm.txtDesc.value) == "" ){
			cbs_alert("Description is a required field");
			return false;
		}
		
		
	/*	if (document.issueCreditChargeForm.paymentTypeName.value != "ON ACCOUNT" ){
			if (document.issueCreditChargeForm.chargeCreditOption[1].checked && 
				document.issueCreditChargeForm.creditType.value == "R")
				tempz = "";
			else{
				alert("Customer is not an account holder. Only Cash Credit can be issued ")
				return false;
				}				
		}
	*/	
		
		var temp = cleanNumeric(document.issueCreditChargeForm.txtAmount.value);
		if(temp == "" || temp == null || temp == 0)	{
				show_focus("Enter valid amount.", "Amount", document.issueCreditChargeForm.txtAmount);
				return;
		}

		
		if (document.issueCreditChargeForm.chargeCreditOption[0].checked && temp > <%=formatnumber(l_availableCredit, 2, , , 0)%>)
		{
			cbs_alert("Amount of charge ($" + temp + ") is over the customers available credit (<%=formatcurrency(l_availableCredit)%>).");
			return;
		}
		else if (document.issueCreditChargeForm.chargeCreditOption[1].checked && 
				document.issueCreditChargeForm.creditType.value == "R"){
                var url = "http://<%=userIPAddress%><%=printerIP%>/openCashDrawer"
                OpenCashDrawer(url, '<%= printerName %>');
		}

		document.issueCreditChargeForm.action ="?Submitted=true&continue=" + cont;
		document.issueCreditChargeForm.submit();
	}
	
	function creditOrCharge(){
		if(document.issueCreditChargeForm.chargeCreditOption[0].checked) {
			document.issueCreditChargeForm.creditType.disabled=true;
		}else{
			document.issueCreditChargeForm.creditType.disabled=false;
		}
	}	
	
	function formatAmount(element){
		var temp = cleanNumeric(element.value)
		element.value = autoFormatCurrency(temp)
	}
	
	
	function cancelForm(){
		document.issueCreditChargeForm.action ="accountMgmt.asp";
		document.issueCreditChargeForm.submit();
	}
	
	function captureKeyUpEvent(element){
		
	  	if (event.keyCode == 13){
	  		event.returnValue = true;	
			submitForm('true');
		}
	}
		
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onLoad="issueCreditChargeForm.txtDesc.focus()">

<!-- #include file="../include/banner.inc" -->

<H1>Issue Credit or Charge</H1>
<FORM id="issueCreditChargeForm" name="issueCreditChargeForm" action="" method="Post">

<Input type=hidden name= paymentTypeName value= "<%=l_paymentTypename%>">
<Input type=hidden name= customerseq value= "<%=l_customerseq%>">

<TABLE ALIGN=center valign=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 onKeyPress="captureKeyUpEvent(this)" >	
	<tr height=20px><td></td></tr>
	<tr>
		<td align=right class="label">Customer Name</td>
		<td>
			<INPUT id=txtCustName name=txtCustName class=text readonly style="width:300px;"value="<%=Server.HTMLEncode(l_custname)%>">
		</td>
	</tr>
	<tr>
		<td align=right class="label">Account Balance</td>
		<td>
			<INPUT id=txtAccountBalance name=txtAccountBalance class=text readonly style="width:300px;"value="<%=l_accountbalance%>">
		</td>
	</tr>
	<tr>
		<td align=right valign=top>
			<input type=radio style="height:25px;width:25px" name="chargeCreditOption"  value="D" style="vertical-align:middle" onClick="creditOrCharge();" 
			<% if ucase(l_paymentTypename) <> "ON ACCOUNT" then  %>
				disabled  
			<% else%>
				checked 
			<%End if %>
			><b class="label">&nbsp;Charge</b>
		</td>
		<td valign=top>
			<input type=radio style="height:25px;width:25px" name="chargeCreditOption" value="C" style="vertical-align:middle" onClick="creditOrCharge();"
			<% if ucase(l_paymentTypename) <> "ON ACCOUNT" then  %>
				checked  
			<% else%>

			<%End if %>
			><b class="label">Credit</b>&nbsp;&nbsp;&nbsp;
			<select name=creditType style="width:120px;font-size:16px" >
				<option value="C">On Account
				<option value="R">Cash
			</select>
		</td>
	</tr>
	<tr>
		<td align=right class="label">Description <font color = red>* </font></td>
		<td>
			<INPUT id=txtDesc name=txtDesc class=text maxlength=64 style="width:300px;">
		</td>
	</tr>
	<tr>
		<td align=right class="label">Amount <font color = red>* </font></td>
		<td>
			<INPUT id=txtAmount name=txtAmount class=text style="width:250px;"  onkeyUp="formatAmount(this)">
		</td>
	</tr>
	<tr>
		<td align=right class="label">Effective Date</td>
		<td>
			<INPUT style="vertical-align:middle" id=txtEffectiveDt name=txtEffectiveDt class=text style="width:200px;" readonly value="<%=Cdate(formatdatetime(now(), vbshortdate)) %>">
			<INPUT style="vertical-align:middle" class=touch id=effectiveDate name=effectiveDate type=button value="" style="background-image:url(../images/Calender.gif);width:25px;height:25px;" onClick="javascript:show_calendar('issueCreditChargeForm.txtEffectiveDt');">
		</td>
	</tr>
	<tr>
		<td></td>
		<td>
			<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
	<!--				<tr>
						<TD colspan=3 align=center >
							<INPUT id=okAndContButton name=okAndContButton type=button value="Apply and Continue" style="width:150px;height:50px;" onClick="submitForm('true')">
						</td>
					</tr>
	-->				
					<TR>

						<TD align=center width=40px>
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)" onClick="submitForm()">
						</td>
						<td width=25></td>
						<td align=center width=40px>
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
						</TD>
						<td width=70%></td>
					</TR>     
			</TABLE>
		</td>
	</tr>

</table>
</form>
</BODY>
</HTML>
<%
	
	dim l_custname
	dim l_accountbalance
	dim l_paymentTypename
	dim l_availableCredit
	
	function GetCustomerinfo()
	dim rstTemp
	dim sqltxt
	l_accountbalance = 0.00
	
	sqltxt = "Execute dbo.GetCustomerAccountBalance " & l_customerseq
	set rstTemp = getdisconnectedrecordset(sqltxt)
	'Response.write sqltxt
	if rstTemp.recordcount > 0 then
		l_custname =  rstTemp("CustomerName")
		l_accountbalance =  rstTemp("accountbalance")
		l_availableCredit = formatnumber(cdbl(rstTemp("availableCredit")), 2)
		'l_paymentTypename = ucase(rstTemp("paymentTypename"))
		if isnull(l_accountbalance 	) then
			l_accountbalance = 0.00
		else
			l_accountbalance= Formatnumber(l_accountbalance, 2)
		end if
		if rstTemp("permanentaccount")  or  rstTemp("Temporaryaccount")  then
				l_paymentTypename = "ON ACCOUNT"
		end if	
		'Response.Write l_paymentTypename 
	end if
	rsttemp.close
	set rstTemp = nothing	
	end function

	function updatedatabase()
	dim sqltxt
	
	sqltxt = "execute InsertMiscCharge " & session("storeid")_
					& " , " & session("employeeid") _
					& " ,"   & l_customerseq _
					& " ,"   & dbcreateqrystring(Request.form("chargeCreditOption")) _
					& " ,"   & Request.form("txtamount") _
					& " ,"   & dbcreateqrystring(Request.form("txtEffectiveDt")) _
					& " ,"   & dbcreateqrystring(Request.form("txtdesc")) _
					& " ,"   & dbcreateqrystring(Request.form("creditType")) _
					& " ,"   & dbcreateqrynumeric(session("terminalid")) _
					& ","    & 1
					
		'Response.Write sqltxt
		dbstartTrans()
		qryexecutewithtrans(sqltxt)
		dbendtrans()


        Dim data, httpRequest, postResponse
        dim query, rs


        if isMessengerEnabled then
            on error resume next

            data = "custSeq=" & l_customerseq & "&employeeId=" & session("employeeid")_
                & "&creditType=" & Server.URLEncode(Request.form("creditType")) & "&amount=" & Request.form("txtamount")_
                & "&description=" & Server.URLEncode(Request.form("txtdesc")) & "&chgCredOpt=" & Request.form("chargeCreditOption")


            Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
            httpRequest.Open "POST", getMessengerFullPath("main") & "/creditCreated", False
            httpRequest.SetRequestHeader "Content-Type", "application/x-www-form-urlencoded"
            httpRequest.Send data
            postResponse = httpRequest.ResponseText
        end if
		
	end function


%>
