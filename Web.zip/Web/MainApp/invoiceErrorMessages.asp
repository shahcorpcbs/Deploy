<%@ Language=VBScript %>
<html>
<head>
    <title>Error</title>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
</head>

<body topmargin=100px leftmargin=20px>
<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5>
	<tr height=30px><td></td></tr>
	<tr>
		<td>

			<blockquote><font face=arial>
			<%
				dim errorMessage
				errorMessage = Session("errorMessage")
				if errorMessage = "" then
			%>
				We are sorry, but we are unable to process your request:
				If possible, please go back and correct the problem and try again.
			<%
				else
			%>
			<span style="font-weight:normal; font-size:16px; font-family:Arial, Helvetica, sans-serif; color:red;">
				<%= errorMessage%>
			</span>
			<%
				end if
			%>
			</blockquote></FONT>
		</td>
	</tr>
	<tr height=30px><td></td></tr>
	<tr>
		<td align=center>
			<INPUT class=click id=back name=back type=button value="Back" style="width:100px;height=50px" onClick="history.back(-1);">
		</td>
	</tr>
	</table>
</body>
</html>
