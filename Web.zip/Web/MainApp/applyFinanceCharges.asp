<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim query, rs
	dim isSubmitted
		isSubmitted = Request.QueryString("submitted")
		if (isSubmitted) then
			updateDatabase()
			Response.Redirect("accountMgmt.asp")
		end if 
		
		
	getPastDueAccounts()
	dim l_chargepercent
	dim l_chargeamount
	
	l_chargepercent = Request.QueryString("chargepercent")
	l_chargeamount = Request.QueryString("chargeAmount")
	
	if l_chargepercent <> "" then
		query = "update miscsetup set financecharge = '" & l_chargepercent & "' where storeid = " & session("storeid")
		qryexecute query
	else
		query = "select financecharge from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
			l_chargepercent = rs("financecharge")
		end if
		set rs = nothing
	end if
	
	
	
	if l_chargeamount <> "" then
		query = "update miscsetup set financeminamt = '" & l_chargeamount & "' where storeid = " & session("storeid")
		qryexecute query
	else
		query = "select financeminamt from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
			l_chargeamount = rs("financeminamt")
		end if
		set rs = nothing
	end if
	
	
%>

<HTML>
<HEAD>
<TITLE>Apply Finance Charges</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	var checkboxClicked=false;
	function doFinanceChargeSetup(){
		document.applyFinanceCharges.action="financeChargeSetup.asp";
		document.applyFinanceCharges.submit();
	}
	function selectRow(element) {
		var childEl;
		if(!checkboxClicked){
			childEl = element.children[0];
			var rowChildNodes = childEl.children
			for(i=0; i<rowChildNodes.length; i++){
				childEl = rowChildNodes[i];
				if(childEl.tagName == "INPUT") {
					if(childEl.checked) {
						childEl.checked=false;
						element.style.background="white";
					}
					else{
						childEl.checked=true;
						element.style.background="#DBF2F4";
					}
					break;
				}
			}
		}
		checkboxClicked=false;
	}		
	
	function selectRowForCheckBox(element) {
		var parentEl;
		parentEl=element;
		while(parentEl.tagName != "TR") {
			parentEl = parentEl.parentElement;
		}
		if (element.checked){
			parentEl.style.background="#DBF2F4";
		}else{
			parentEl.style.background="white";
		}
		checkboxClicked=true;
	}
	
	function applyFinanceCharge(){
		document.applyFinanceCharges.action="?submitted=true";
		document.applyFinanceCharges.submit();
	}
	function cancelForm() {
		document.applyFinanceCharges.action="accountMgmt.asp";
		document.applyFinanceCharges.submit();
	}
	function selectAllRows() {
		for (i = 0; i < document.applyFinanceCharges.select.length; i++) {
			document.applyFinanceCharges.select[i].checked = true;
			selectRowForCheckBox(document.applyFinanceCharges.select[i]);
		}

	}
	function deSelectAllRows() {
		for (i = 0; i < document.applyFinanceCharges.select.length; i++) {
			document.applyFinanceCharges.select[i].checked = false;
			selectRowForCheckBox(document.applyFinanceCharges.select[i]);
		}

	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Apply Finance Charges</H1>
<FORM id="applyFinanceCharges" name="applyFinanceCharges" onSubmit="return false" method="Post">
<input type=hidden name ="chargePercent" value = "<%=l_chargepercent%>">
<input type=hidden name ="chargeAmount" value = "<%=l_chargeAmount%>">
	<TABLE WIDTH="100%" align=center BORDER=0 CELLSPACING=1 CELLPADDING=5>
	<tr height=20px></tr>
	<!-- header row -->
	<tr>
		<td align=center>
			<TABLE WIDTH="680px" BORDER=0 CELLSPACING=1 CELLPADDING=5>
				<!-- heading -->
				<tr>
					<th width=22px></th>
					<th width =200px align=left class="label">Customer Name</th>
					<th width =120px align=left class="label">Amount Due</th>
					<th width =120px align=left class="label">Amount Past Due</th>
					<th width =120px align=left class="label">Last Date Assessed</th>
					<th width=16px></th>
				</tr>
			</table>
		</td>
	</tr>
	<!-- list -->
	<tr>
		<td align=center>
			<DIV STYLE="overflow-y:auto;height:200px; overflow-x:auto; width=680px">
					<TABLE WIDTH="100%" style="border-color:#2F4F4F;border-style:solid;background-color:white;" BORDER=1 CELLSPACING=0>
						<tr rowspan =5>
							<td>
								<TABLE WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=3>
								<!-- to be removed while coding -->	
									
									<%
										if rstAccounts.recordcount > 0 then
											while not rstAccounts.eof
									
									%>
										<tr onClick="selectRow(this)">
										<td width=22px><input type="checkbox" name="select" id="select"  onClick="selectRowForCheckBox(this)" style="height=25px;width=25px;"value = "<%=rstAccounts("customersequencenumber")%>"></td>
										<td width = 200px  STYLE="FONT-SIZE: 12px;"><%=Server.HTMLEncode(rstAccounts("Customername"))%></td>
										<td width = 120px  STYLE="FONT-SIZE: 12px;"><%=rstAccounts("amountdue")%></td>
										<td width = 120px  STYLE="FONT-SIZE: 12px;"><%=rstAccounts("amountpastdue")%></td>
										<td width = 120px  STYLE="FONT-SIZE: 12px;"><%=rstAccounts("lastFinancechargedate")%></td>
									</tr>
									<% rstAccounts.movenext
										wend
										rstAccounts.close
										set rstaccounts = nothing
										end if
									%>
									
									<tr height =50px><td></td></tr>
									<tr height=50px><td></td></tr>	
									<tr height =50px><td></td></tr>
									<tr height=50px><td></td></tr>
									<tr height =50px><td></td></tr>
									<tr height=50px><td></td></tr>
									<!-- till here -->	
								</table>
							</td>
						</tr>
				</table> <!-- table for border -->
			</div>
		</td>
	</tr>
	<!-- buttons -->
	<tr>
		<td align=center>
			<TABLE WIDTH="300px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
				<tr height=20px></tr>
				<tr>
					<td >
						<!--<INPUT class=touch id=markAll name=markAll type=button value="" style="background-image:url(../images/Select-All.gif)"  onClick="selectAllRows()"><br>Mark All-->
						<BUTTON class=std id=markAll name=markAll onClick="selectAllRows()">Mark All</button>
					</td>
					<td >
						<!--<INPUT class=touch id=uncheckAll name=uncheckAll type=button value="" style="background-image:url(../images/Un-select-All-2.gif)" onClick="deSelectAllRows()"><br>Uncheck All-->
						<BUTTON class=std id=uncheckAll name=uncheckAll onClick="deSelectAllRows()">Uncheck All</button>
					</td>
					<!--<td>
						<INPUT class=touch id=selectButton name=selectButton type=button style="background-image:url(../images/select.gif)"  value=""><br>Select
						<BUTTON class=std id=selectButton name=selectButton><img src="../images/select.gif"><br>Select</button>
					</td>-->
					<td >
						<!--<INPUT class=touch id=setup name=setup type=button value="" style="background-image:url(../images/SetUP.gif)"  onClick="doFinanceChargeSetup()"><br>Set Up-->
						<BUTTON class=std id=setup name=setup onClick="doFinanceChargeSetup()">Set Up</button>
					</td>
				</tr>
				<tr height=100px>	
					<td colspan=4 align=center>
						<INPUT class=touchnoborder id=apply name=apply type=button value="" style="background-image:url(../images/Ok.gif)"  onClick="applyFinanceCharge()">&nbsp&nbsp&nbsp&nbsp&nbsp
						<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
					</td>
				</tr>
			</table>
		</td>
	<tr>
</table>
	
</FORM>   

</BODY>
</HTML>
<%
	dim rstAccounts
	
	function getPastDueAccounts()
	dim sqltxt
	sqltxt = "execute dbo.GetCustomersForFinanceCharges "
	set rstAccounts = getDisconnectedRecordset(sqltxt)
		
	end function
	
	function updateDatabase()
	dim sqltxt
	dim counter 
	
	if  (Request.Form("select").Count > 0  and (len(trim(Request.Form("chargePercent"))) > 0   or len(trim(Request.Form("chargeamount"))) > 0)) then
		 dbStartTrans()
		 for counter = 1 to Request.Form("select").Count
			sqltxt = "Execute dbo.ApplyFinanceCharge " _
						& Request.Form("select").Item(counter) _
						& " , " & dbcreateQrynumeric(Request.Form("chargePercent")) _
						& ", " & dbcreateQrynumeric(Request.Form("chargeamount")) _
						& ", " & session("storeid") _
						& ", " & session("employeeid")
			'Response.Write sqltxt
			qryexecutewithtrans(sqltxt)						
						
		 next 
		 dbendTrans()
	end if
	
	end function
	
	
	
%>
