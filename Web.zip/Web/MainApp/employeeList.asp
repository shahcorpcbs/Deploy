<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim l_storeid
	dim isSubmitted 
	dim actionstring
	dim query, rs
	
	Session("setupEmployeeid") = null
	
	l_storeid = Request.QueryString("storeid")
	
	if l_storeid = "" then
	    l_storeid = Session("storeid")
	end if
	
	isSubmitted = Request.QueryString("submitted")
	
	if isSubmitted then
		Session("setupEmployeeid")= Request.Form("emplist")
		'Response.Write Session("setupEmployeeid")
		Response.redirect(Request.QueryString("targetPage") & "?UserAction=" & Request.QueryString("UserAction") )
	end if
	
	actionstring= Request.QueryString("useraction")
	
	getEmployeesList()
%>
<HTML>
<HEAD>
<TITLE>Employee List</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function enableButton(){
		
		if (document.employeeListForm.empList.size > 0 ) 
			document.employeeListForm.select.disabled = false;
		else
			document.employeeListForm.select.disabled = true;
	}
	
	
	function selectEmployee() {
	
		if (document.employeeListForm.empList.selectedIndex < 0 ) {
			cbs_alert("Please select an employee from list");
			return false;
		}
		
		if(document.employeeListForm.targetPage.value == "editHours"){
			document.employeeListForm.action=  "?Submitted=true&Targetpage=editEmployeeHours.asp&userAction=editHours";
		}
			
		else if (document.employeeListForm.targetPage.value == "editOtherHours"){
			document.employeeListForm.action=  "?Submitted=true&Targetpage=editEmployeeOtherHours.asp&userAction=editOtherHours";
		}

		else
		{
			document.employeeListForm.action= "?Submitted=true&Targetpage=addNewEmployee.asp&userAction=edit";
		}

		document.employeeListForm.submit();
		
	}
	
	function cancelForm(){
		document.employeeListForm.action = "employeeManagement.asp";
		document.employeeListForm.submit();
	
	}
	function selectStore(id) {
		document.employeeListForm.action = "?storeid=" + id;
		document.employeeListForm.submit();
	}
	
</script>
<BODY topmargin=0 leftmargin=0 onload ="enableButton()">

<!-- #include file="../include/banner.inc" -->
<H1>Employee List</H1>
<FORM id="employeeListForm" name="employeeListForm" action="" method="post">
	<INPUT type="hidden" name="targetPage" value="<%= actionString %>">
	<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=0 CELLPADDING=2 >
		<tr height=40px>
		<select onchange="selectStore(this.value);">
		<%
		    query = "select storeid, name from store"
		    set rs = getdisconnectedrecordset(query)
		    
		    while not(rs.eof or rs.bof)
		%>
		        <option <% if trim(rs("storeid")) = l_storeid then %>selected<% end if %>
		        value="<%=rs("storeid")%>" ><%=rs("name")%></option>
		<%
		        rs.movenext
		    wend
		    set rs = nothing
		%>
		</select>
		</tr>
		<tr>
			<td align="center" colspan=2>
				<%GetEmployeesList() %>
				<select id=empList name=empList style="width:500px;font-size=16px" size=20 >
				
				 <%if rstList.recordcount > 0 then
					while not rstlist.eof 
				%>
					<option value ="<%=rstList("Employeeid")%>">
					<% if trim(rstList("LastName")) <> "" then
							Response.Write rstList("LastName") & ", "
						end if
						Response.Write rstList("firstname")%>
					</option>
				<%rstlist.movenext
					wend
					 end if
					 rstList.close
					 set rstlist = nothing
				%>
				
				</select>
			</td>
		</tr>
		<tr height=20px></tr>
		<tr>
			<td>
				<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
					<tr>
						<td align="center">
							<INPUT class=touchnoborder id=select name=select type=button value="" style="background-image:url(../images/Ok.gif)" onClick="selectEmployee()">						</td><td align="center">
							<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)"onClick="cancelForm()">
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</form>
</BODY>
</HTML>
<%
	dim rstList
	function getEmployeesList()
	dim sqltxt
		sqltxt = "select * from employee where employeestatus = 'A' and storeid = " & l_storeid & " order by lastname"
		set rstList = GetDisconnectedRecordset(sqltxt)
	end function
%>