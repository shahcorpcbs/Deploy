<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<%
	dim deliveryID
	
	deliveryID = trim(getReqVar("deliveryID"))

	select case(request.querystring("useraction"))
	case "checkadd"
		if adjustCreditCardBatchTotals(deliveryID) <= 0 then
			response.redirect "delivery.asp?deliveryID=" & deliveryID
		end if
	case "addbatch"
		adjustCreditCardBatchTotals deliveryID
	case "createbatch"
		createCreditCardBatch deliveryID
	case "viewbatch"
		viewPaymentBatch deliveryID
	case "closebatch"
		closePaymentBatch request.querystring("batchid")
	case "closedeliverybatches"
		closeDeliveryBatches deliveryID
	case "updatebatch"
		updatePaymentBatch deliveryID
	case "removepayments"
		removePayments
	end select
	
	function removePayments()
		dim query, rs
		dim deliveryPayments
		
		deliveryPayments = cstr(request.form("deliveryPaymentID"))
		
		if deliveryPayments <> "" then
			query = "delete deliverypayment where deliverypaymentid in (" & deliveryPayments & ")"
			qryexecute query
		end if		
	end function
	
	function closeDeliveryBatches(deliveryID)
		dim query, rs
		dim ccprocessor
		dim storeid
		dim employeeid
		dim terminalid
		
		if deliveryid <> "" then
			query = " select distinct batchid from "
			query = query & " deliverypayment inner join deliverystop on "
			query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
			query = query & " where not (deliverypayment.batchid is null) and deliverystop.deliveryid = " & deliveryid
			
			set rs = getdisconnectedrecordset(query)
			
			set ccprocessor = getCCProcessor()
		
			storeid = session("storeid")
			employeeid = session("employeeid")
			terminalid = session("terminalid")
			
			while not(rs.eof or rs.bof)
				ccprocessor.CloseBatchGroup(rs("batchid")), storeid, employeeid, terminalid
				
				query = " update deliverypayment set deliverypayment.status = case paymentbatch.stage when 0 then 10 else paymentbatch.stage + (10 * sign(paymentbatch.stage)) end "
				query = query & " from deliverypayment inner join deliverystop on "
				query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
				query = query & " inner join paymentbatch on "
				query = query & " deliverypayment.batchid = paymentbatch.batchid and deliverystop.customersequencenumber = paymentbatch.customersequencenumber "
				query = query & " where deliverypayment.batchid = " &  rs("batchid")

				qryexecute query
				
				rs.movenext
			wend
			
			set rs = nothing

		end if
	end function
	
	function closePaymentBatch(batchid)
		dim query, rs
		dim ccprocessor
		dim storeid
		dim employeeid
		dim terminalid

		set ccprocessor = getCCProcessor()
	
		storeid = session("storeid")
		employeeid = session("employeeid")
		terminalid = session("terminalid")

		ccprocessor.CloseBatchGroup batchid, storeid, employeeid, terminalid
		
		query = " update deliverypayment set deliverypayment.status = case paymentbatch.stage when 0 then 10 else paymentbatch.stage + (10 * sign(paymentbatch.stage)) end "
		query = query & " from deliverypayment inner join deliverystop on "
		query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
		query = query & " inner join paymentbatch on "
		query = query & " deliverypayment.batchid = paymentbatch.batchid and deliverystop.customersequencenumber = paymentbatch.customersequencenumber "
		query = query & " where deliverypayment.batchid = " &  batchid

		qryexecute query

	end function
	

	
	
	function updatePaymentBatch(deliveryID)
		dim query, rs
		dim ccprocessor

		if deliveryid <> "" then
			query = " select distinct batchid from "
			query = query & " deliverypayment inner join deliverystop on "
			query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
			query = query & " where not (deliverypayment.batchid is null) and deliverystop.deliveryid = " & deliveryid
			
			set rs = getdisconnectedrecordset(query)
			
			set ccprocessor = getCCProcessor()

			while not(rs.eof or rs.bof)
				ccprocessor.UpdateBatchGroup(rs("batchid"))

				query = " update deliverypayment set deliverypayment.status = case paymentbatch.stage when 0 then 10 else paymentbatch.stage + (10 * sign(paymentbatch.stage)) end "
				query = query & " from deliverypayment inner join deliverystop on "
				query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
				query = query & " inner join paymentbatch on "
				query = query & " deliverypayment.batchid = paymentbatch.batchid and deliverystop.customersequencenumber = paymentbatch.customersequencenumber "
				query = query & " where deliverypayment.batchid = " &  rs("batchid")

				qryexecute query

				if ccprocessor.IsBatchReadyToClose(rs("batchid")) then
					closePaymentBatch rs("batchid")
				end if
				
				rs.movenext
			wend

			set rs = nothing
		end if
	end function

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function


	function isCreditCardBatchOpen(deliveryID)
		dim query, rs
		dim paymentbatchid
		dim ccprocessor
		
		query = "select * from delivery where not (paymentbatchid is null) and deliveryid = " & deliveryid
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			paymentbatchid = rs("paymentbatchid")
			
			set ccprocessor = getCCProcessor()

			isCreditCardBatchOpen = ccprocessor.IsBatchOpen(paymentbatchid)
		
			set ccprocessor = nothing
		end if
	end function
	
	function isCreditCardBatchReadyToClose(deliveryID)
		dim query, rs
		dim paymentbatchid
		dim ccprocessor
		
		query = "select * from delivery where not (paymentbatchid is null) and deliveryid = " & deliveryid
		set rs = getdisconnectedrecordset(query)

    isCreditCardBatchReadyToClose = true

		if rs.recordcount > 0 then
			paymentbatchid = rs("paymentbatchid")
			
			set ccprocessor = getCCProcessor()

			isCreditCardBatchReadyToClose = ccprocessor.IsBatchReadyToClose(paymentbatchid)
		
			set ccprocessor = nothing
		end if
	end function
	
	function getCCProcessor()
		dim ccprocessor
		
		set ccprocessor = Server.CreateObject("ShahcorpComponents.creditCardProcessing")
		
		ccprocessor.DBConnectionString = Session("shahcorpDSN")
		
		ccprocessor.XChargeDirectory = getMSVar("XChargePath")
		if isobject(getMSVar("XChargePathKeyed")) then
			ccprocessor.XChargeDirectoryKeyed = getMSVar("XChargePathKeyed")
		end if
		ccprocessor.XChargeTimeout = 120
		
		set getCCProcessor = ccprocessor
	end function
	
	function getMSVar(id)
		dim query, rs
		
		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)
		
		set rs = nothing
	end function
	
	
	function createFieldsFromCustomerSeq(customerseq)
		dim query, rs
		dim result
		
		set result = Server.CreateObject("ShahcorpComponents.creditCardFields")
		
		if customerseq <> "" then
			query = "select "
			query = query & " isnull(creditCardCVC, '') as creditCardCVC"
			query = query & ", isnull(creditCardExpDate, '0000') as creditCardExpDate"
			query = query & ", isnull(creditCardNumber, '') as creditCardNumber"
			query = query & ", isnull(creditCardNameOnCard, customerName) as creditCardNameOnCard"
			query = query & ", isnull(billingAddress1, '') as billingAddress1"
			query = query & ", isnull(billingZipCode, '') as billingZipCode"
			query = query & ", customerName as customerName"
			query = query & " from customer where customersequencenumber = " & customerseq

			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				result.accountnumber = rs("creditCardNumber")
				result.expirationmonth = clng(left(rs("creditCardExpDate"), 2))
				result.expirationyear = clng(right(rs("creditCardExpDate"), 2))
				result.cvv2 = rs("creditCardCVC")
				
				result.firstname = rs("creditCardNameOnCard")
				result.address = rs("billingAddress1")
				result.zip = rs("billingZipCode")
			end if
		end if
		
		set createFieldsFromCustomerSeq = result
	end function
	
	function createCreditCardBatch(deliveryID)
		dim query, rs
		dim ccprocessor
		dim paymentbatchid
		dim fields
		dim amountdue
		dim customerseq
		dim terminalID
		
		terminalID = session("terminalID")
		
		set ccprocessor = getCCProcessor()

		query = " select deliverypaymentid, amounttobeapplied, accountnumber, expirationmonth, expirationyear, customersequencenumber "
		query = query & " from deliverypayment inner join deliverystop on "
		query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
		query = query & " where deliverystop.deliveryid = " & deliveryid
		query = query & " and deliverypayment.status = 1 "
		query = query & " and deliverypayment.paymentmethod = 'Credit Card' "
		query = query & " and deliverypayment.amounttobeapplied > 0 "
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			paymentbatchid = ccprocessor.GetNextBatchGroup()

			while not(rs.eof or rs.bof)
				customerseq = rs("customersequencenumber")
				
				set fields = createFieldsFromCustomerSeq(customerseq)
				
				set result = Server.CreateObject("ShahcorpComponents.creditCardFields")
				
				result.accountnumber = rs("accountnumber")
				result.expirationmonth = rs("expirationmonth")
				result.expirationyear = rs("expirationyear")
				result.cvv2 = ""
				
				result.firstname = ""
				result.address = ""
				result.zip = ""
				
				amountdue = rs("amounttobeapplied")

				if not ccprocessor.AddTransactionToBatch(terminalID, fields, customerseq, paymentbatchid, 1, amountdue) then
					response.write "Could not add transaction to batch"
					
					exit function
				end if

				query = " update deliverypayment set status = 2, "
				query = query & " batchid = " & paymentbatchid
				query = query & " where deliverypaymentid = " & rs("deliverypaymentid")
				
				qryexecute query
			
				rs.movenext
			wend

			query = " update delivery set paymentbatchid = " & paymentbatchid
			query = query & " where deliveryid = " & deliveryID
			
			qryexecute query
		end if

		set rs = nothing
		set ccprocessor = nothing
	end function
	
	
	function getTicketStatusHTML(status)
		dim result
		
		select case status
			case "AC"
				result = "Active"
			case "FI"
				result = "Finished"
			case "VO"
				result = "Voided"
		end select
		
		getTicketStatusHTML = result
	end function
	
	function getPaymentStatusHTML(status)
		dim result
		
		select case status
			case 1
				result = "<span style=""background:#f0f;color:#fff;padding:2px"">"
				result = result & "Pending"
				result = result & "</span>"
			case 2
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Pending Batch"
				result = result & "</span>"
			case 10
				result = "<span style=""background:#af0;color:#000;padding:2px"">"
				result = result & "Paid"
				result = result & "</span>"
			case 11
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Request Made"
				result = result & "</span>"
			case 12
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Waiting"
				result = result & "</span>"
			case 13
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Transaction Made"
				result = result & "</span>"
			case -11
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Missing Request"
				result = result & "</span>"
			case -12
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Process Error"
				result = result & "</span>"
			case -13
				result = "<span style=""background:#f0f;color:#0f0;padding:2px"">"
				result = result & "Cancelled"
				result = result & "</span>"

		end select
	
		getPaymentStatusHTML = result
	end function


	function clearPendingCreditCardBatch(deliveryID)
		dim query, rs
		
		query = " delete deliverypayment from deliverypayment inner join deliverystop on "
		query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
		query = query & " where deliverystop.deliveryid = " & deliveryid
		query = query & " and deliverypayment.paymentmethod = 'Credit Card' "
		query = query & " and status = 1 "
		
		
		qryexecute query
		
	end function

	function getPaymentsForStop(deliverystopid)
		dim query, rs
		
		query = " select isnull(sum(amounttobeapplied), 0) as amount from "
		query = query & " deliverypayment where deliverystopid = " & deliverystopid
 		query = query & " and status >= 0 "
 		
		set rs = getdisconnectedrecordset(query)

		getPaymentsForStop = rs("amount")
		
		set rs = nothing
	
	end function
	
	function canMakePaymentOnRoute(routeNumber)
		dim query, rs
		
		canMakePaymentOnRoute = true
		
		query = " select count(*) as cnt from routedepartment where routenumber = " & routenumber
		set rs = getdisconnectedrecordset(query)
		
		if rs("cnt") > 0 then
			canMakePaymentOnRoute = false
		end if
		
		if canMakePaymentOnRoute then
			set rs = nothing
			
			query = " select count(*) as cnt from route where not ((billingResponsibility is null) or not (discountPercent is null)) and routenumber = " & routenumber
			set rs = getdisconnectedrecordset(query)
			
			if rs("cnt") > 0 then
				canMakePaymentOnRoute = false
			end if
		end if
		
		set rs = nothing
	end function
	
	function adjustCreditCardBatchTotals(deliveryID)
		dim query, rs
		dim paymentTotal
		dim deliveryStatus
		dim paymentsAdded
		
		paymentsAdded = 0
		
		if deliveryID <> "" then
		
			query = " select deliveryitem.deliverystopid, "
			query = query & " 'Credit Card' as paymentmethod, "
			query = query & " sum(ticket.invoicetotal - ticket.amountpaid) as amountToBeApplied, "
			query = query & " customer.creditCardNumber as accountnumber, "
			query = query & " left(customer.creditCardExpDate, 2) as expirationmonth, "
			query = query & " right(customer.creditCardExpDate, 2) as expirationyear, "
			query = query & " deliverystop.routeid as routenumber, "
			query = query & " dbo.getAccountBalance(customer.customersequencenumber, getdate()) as customerBalance from "
			query = query & " deliveryitem inner join ticket on "
			query = query & " deliveryitem.ticketnumber = ticket.ticketnumber "
			query = query & " inner join deliverystop on "
			query = query & " deliveryitem.deliverystopid = deliverystop.deliverystopid "
			query = query & " inner join customerdelivery on "
			query = query & " deliverystop.customerdeliveryid = customerdelivery.id "
			query = query & " inner join customer on "
			query = query & " customerdelivery.customersequencenumber = customer.customersequencenumber "
			query = query & " where deliverystop.deliveryid = " & deliveryID
			query = query & " and customerdelivery.paymenttype = 'Credit Card' "
			query = query & " and customer.allowccbatch = 1 "
			query = query & " and not (creditCardNumber is null or creditCardNumber = '') "
			query = query & " group by deliveryitem.deliverystopid, deliverystop.routeid, customer.customersequencenumber, customer.creditCardNumber, customer.creditCardExpDate  "

			set rs = getdisconnectedrecordset(query)

			
			while not(rs.eof or rs.bof)

				if canMakePaymentOnRoute(rs("routeNumber")) then
					paymentTotal = getPaymentsForStop(rs("deliverystopid"))
					paymentsAdded = paymentsAdded + 1
					
					if rs("customerBalance") < 0 then
						paymentTotal = paymentTotal - rs("customerBalance")
					end if
					
					if rs("amountToBeApplied") - paymentTotal > 0 then
	
						query = " insert into deliverypayment (deliverystopid, paymentmethod, amounttobeapplied, accountnumber, expirationmonth, expirationyear) "
						query = query & " values ("
						query = query & rs("deliverystopid")
						query = query & ",'" & rs("paymentmethod") & "'"
						query = query & "," & rs("amounttobeapplied") - paymentTotal
						query = query & ",'" & rs("accountnumber") & "'"
						query = query & "," & clng(rs("expirationmonth"))
						query = query & "," & clng(rs("expirationyear"))
						query = query & ")"
						
						qryexecute query
						
						
					end if
				end if
				rs.movenext
			wend
		end if
		
		adjustCreditCardBatchTotals = paymentsAdded
	end function

	function getCreditCardPaymentsCount(deliveryid)
		dim query, rs
		
		query = " select count(*) as cnt from "
		query = query & " deliverypayment inner join deliverystop on "
		query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
		query = query & " where deliverystop.deliveryid = " & deliveryid
 		query = query & " and deliverypayment.status = 1 "
 		query = query & " and deliverypayment.paymentmethod = 'Credit Card' "
 		query = query & " and deliverypayment.batchid is null "
 		
		set rs = getdisconnectedrecordset(query)

		getCreditCardPaymentsCount = rs("cnt")
		
		set rs = nothing
	
	end function
	
	function getCreditCardBatchCount(deliveryid)
		dim query, rs
		
		query = " select count(*) as cnt from "
		query = query & " deliverypayment inner join deliverystop on "
		query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
		query = query & " where deliverystop.deliveryid = " & deliveryid
 		query = query & " and deliverypayment.status between 1 and 9 "
 		query = query & " and deliverypayment.paymentmethod = 'Credit Card' "
 		query = query & " and not(deliverypayment.batchid is null) "

		set rs = getdisconnectedrecordset(query)

		getCreditCardBatchCount = rs("cnt")
		
		set rs = nothing
	
	end function
	
	function isPaymentBatchReadyToClose(deliveryid)
		dim query, rs
		
		query = " select count(*) as cnt from "
		query = query & " deliverypayment inner join deliverystop on "
		query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
		query = query & " where deliverystop.deliveryid = " & deliveryid
		query = query & " and deliverypayment.status >= 10 "
		
		set rs = getdisconnectedrecordset(query)
		
		isPaymentBatchReady = rs("cnt") <= 0
		
		set rs = nothing
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">


<style type="text/css">

</style>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<script language="javascript" type="text/javascript">
	function createCCBatch() {
		document.deliveryCCBatch.action = "?useraction=createbatch";
		document.deliveryCCBatch.submit();
	}
	function closeCCBatch(batchid) {
		document.deliveryCCBatch.action = "?useraction=closebatch&batchid=" + batchid;
		document.deliveryCCBatch.submit();
	}
	
	function viewCCBatch(batchid) {
		document.deliveryCCBatch.action = "/mainapp/creditCardBatchStatus.asp?batchid=" + batchid + "&deliveryid=<%=deliveryID%>";
		document.deliveryCCBatch.submit();
	}

	function updateCCPayments() {
		document.deliveryCCBatch.action = "?useraction=updatebatch";
		document.deliveryCCBatch.submit();
	}
	
	function addCCPayments() {
		document.deliveryCCBatch.action = "?useraction=addbatch";
		document.deliveryCCBatch.submit();
	}
	function closeCCDeliveryBatches() {
		document.deliveryCCBatch.action = "?useraction=closedeliverybatches";
		document.deliveryCCBatch.submit();
	}
	function removeCCPayments() {
		document.deliveryCCBatch.action = "?useraction=removepayments";
		document.deliveryCCBatch.submit();
	}
	
	function continueDelivery() {
		document.deliveryCCBatch.action = "delivery.asp?deliveryID=<%=deliveryID%>";
		document.deliveryCCBatch.submit();
	}
	
	function exit() {
		document.deliveryCCBatch.action = "deliveryManager.asp"
		document.deliveryCCBatch.submit();
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->


<H1>Delivery - Credit Card Payment (2/5)</H1>

<FORM name="deliveryCCBatch" id="deliveryCCBatch" method=POST > 

<INPUT type="hidden" name="deliveryID" value="<%=deliveryID%>">

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">

		<% if getCreditCardBatchCount(deliveryID) > 0 then %>
		<BUTTON onclick="updateCCPayments()">Update<BR />Batch</BUTTON>
		<% if isPaymentBatchReadyToClose(deliveryid) then %>
		<BUTTON onclick="closeCCDeliveryBatches()">Close<BR />Batch</BUTTON>
		<% end if %>
		<% else %>
		<BUTTON onclick="addCCPayments()">Add<BR />Payments</BUTTON>
		<% if getCreditCardPaymentsCount(deliveryID) > 0 then %>
		<BUTTON onclick="removeCCPayments()">Remove<BR />Payment</BUTTON>
		<BUTTON onclick="createCCBatch()">Create<BR />Batch</BUTTON>
		<% end if %>
		<% end if %>


	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
		<BUTTON onclick="continueDelivery()">Next</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" width="100%" cellspacing="0" cellpadding="0">
<TR>
	<TH>&nbsp;</TH>
	<TH>Customer Name</TH>
	<TH align="center">Account Number</TH>
	<TH align="center">Status</TH>
	<TH align="right">Amount</TH>
</TR>
<%
	dim batchid
	
	query = " select deliverypayment.status, deliverypayment.deliveryPaymentID, deliverypayment.amounttobeapplied, deliverypayment.accountnumber, customer.customername, deliverypayment.batchid "
	query = query & " from deliverypayment inner join deliverystop on "
	query = query & " deliverypayment.deliverystopid = deliverystop.deliverystopid "
	query = query & " inner join customer on "
	query = query & " deliverystop.customersequencenumber = customer.customersequencenumber "
	query = query & " where deliverystop.deliveryid = " & deliveryID
	query = query & " and deliverypayment.paymentmethod = 'Credit Card'"
	query = query & " order by case deliverypayment.batchid when null then -1 else deliverypayment.batchid end  "
	
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.bof or rs.eof)
	
%>
	
<% if trim(batchid) <> trim(rs("batchid")) or (not isnull(rs("batchid")) and isnull(batchid)) then %>
	<TR>
		<TD colspan="5"  align="center" style="font-weight:bold;border-bottom:2px inset;background:#eee">
		Batch <%=rs("batchid")%>
		<INPUT type="button" onclick="viewCCBatch(<%=rs("batchid")%>)" value="View" />

		</TD>
	</TR>
<% elseif isnull(rs("batchid")) and not isnull(batchid) then %>
	<TR>
		<TD colspan="5"  align="center" style="font-weight:bold;border-bottom:2px inset;background:#eff">
		Credit Card Payments
		</TD>
	</TR>
<% end if %>


	<TR>
		<TD><%if isnull(rs("batchid")) then %><INPUT type="checkbox" name="deliveryPaymentID" value="<%=rs("deliveryPaymentID")%>" /><%else%>&nbsp;<%end if%></TD>
		<TD><%=rs("customername")%></TD>
		<TD align="center"><%="XXXXXXXXXXXX" & right(rs("accountnumber"), 4)%></TD>
		<TD align="center"><%=getPaymentStatusHTML(rs("status"))%></TD>
		<TD align="right"><%=formatcurrency(rs("amounttobeapplied"))%></TD>
	</TR>
<%
		batchid = rs("batchid")
		rs.movenext
	wend
	
	set rs = nothing
%>

</TABLE>


</FORM>

</BODY>
</HTML>
