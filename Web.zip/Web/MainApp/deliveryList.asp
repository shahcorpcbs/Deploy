<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	const DELIVERY_STATUS_FINISH = 5
	const DELIVERY_STATUS_ADDING = 11
	const DELIVERY_STATUS_VERIFYING = 12
	const DELIVERY_STATUS_PAYMENTS1 = 13
	const DELIVERY_STATUS_MANIFEST = 14
	const DELIVERY_STATUS_UNDELIVERABLE = 15
	const DELIVERY_STATUS_PAYMENTS2 = 16
	
	dim query, rs
	dim showClosed
	dim daysOfHistory
	
	showClosed = getReqVar("showClosed")
	daysOfHistory = getReqVar("daysOfHistory")
	
	if daysOfHistory = "" then daysOfHistory = 1
	
	select case lcase(request.querystring("useraction"))
	case "removedelivery"
		removeDelivery
	case "opendelivery"
		openDelivery request.querystring("deliveryid")
	case "viewdelivery"
		viewDelivery request.querystring("deliveryid")
	end select
	
	function removeDelivery()
		dim query, rs
		dim deliveryid
	
		
		deliveryid = request.form("deliveryid")
		
		if isDeliveryRemovable(getDeliveryStatus(deliveryid)) then
			query = " delete delivery where deliveryid = " & deliveryid

			qryexecute query
		end if
	end function
	
	function openDelivery(deliveryID)
		if deliveryid <> "" then
			response.redirect "/MainApp/deliveryfunction.asp?useraction=open&deliveryid=" & deliveryid
		end if
	end function
	
	function viewDelivery(deliveryID)
		if deliveryid <> "" then
			response.redirect "/MainApp/deliveryfunction.asp?useraction=view&deliveryid=" & deliveryid
		end if
	end function
	
	function getDeliveryStatus(deliveryid)
		dim query, rs
		
		getDeliveryStatus = ""
		
		if deliveryid <> "" then
			query = " select status from delivery where deliveryid = " & deliveryid
			set rs = getdisconnectedrecordset(query)
			
			getDeliveryStatus = rs("status")
		end if
	end function
	

	function getDeliveryStatusHTML(status)
		dim result

		select case status
			case DELIVERY_STATUS_FINISH
				result = "FINISH"
			case DELIVERY_STATUS_ADDING
				result = "ADDING INVOICES"
			case DELIVERY_STATUS_VERIFYING
				result = "VERIFYING INVOICES"
			case DELIVERY_STATUS_PAYMENTS1
				result = "PREDELIVERY PAYMENT"
			case DELIVERY_STATUS_MANIFEST
				result = "DELIVERY / MANIFEST"
			case DELIVERY_STATUS_UNDELIVERABLE
				result = "UNDELIVERABLES"
			case DELIVERY_STATUS_PAYMENTS2
				result = "POSTDELIVERY PAYMENT"
				
			case 0
				result = "(Empty)"
			case 1
				result = "(New Delivery)"
			case 2
				result = "(Locked Delivery)"
			case 3
				result = "(Payments Pending)"
			case 4
				result = "(Payments Applied)"

		end select
		
		getDeliveryStatusHTML = result
	end function
	
	function isDeliveryRemovable(status)
		isDeliveryRemovable =  status = 0
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getRouteNamesForDeliveryID(deliveryID)
		dim query, rs
		
		if deliveryID <> "" then
			query = " select distinct route.name as routename from "
			query = query & " route inner join DeliveryRouteAssigned "
			query = query & " on route.routenumber = DeliveryRouteAssigned.routenumber "
			query = query & " where deliveryid = " & deliveryID
			
			set rs = getdisconnectedrecordset(query)
			
			while not(rs.eof or rs.bof)
				if getRouteNamesForDeliveryID <> "" then getRouteNamesForDeliveryID = getRouteNamesForDeliveryID & ", "
				getRouteNamesForDeliveryID = getRouteNamesForDeliveryID & rs("routename")
				
				rs.movenext
			wend
			
			set rs = nothing
		end if
	end function
	
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">
	var previousElement = null;
	var selectedDelivery = null;

	
	function viewDelivery() {
	      document.deliveryList.action = "?useraction=viewdelivery&deliveryid=" + selectedDelivery;
	      document.deliveryList.submit();
	  }

	

	function updateFilter() {
	      document.deliveryList.action = "?useraction=updatefilter";
	      document.deliveryList.submit();
	}
	
	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}
		selectedDelivery = element.getAttribute("deliveryid");
	
		previousElement =element;
		
		element.className = "selected";
		
		deliveryList.btnOpenDelivery.disabled = false;
	}
	
	
	function exit() {
	    document.deliveryList.action = "deliveryManager.asp"
	    document.deliveryList.submit();
	}
	
	function openDelivery() {
	      document.deliveryList.action = "?useraction=opendelivery&deliveryid=" + selectedDelivery;
	      document.deliveryList.submit();
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<FORM name="deliveryList" ID="deliveryList" METHOD=POST  style="margin:0;padding:0"> 

<TABLE cellpadding="10" align="center" style="width:300px">
	<TR>

		
		<TD valign="center">
			<INPUT type="checkbox" style="height=28px;width=28px" name="showClosed" value="1"  onclick="updateFilter()" <%if showClosed <> "" then%>checked<%end if%> />
			Show Closed
		</TD>

		<%if showClosed <> "" then%>
		<TD>
			<SELECT name="daysOfHistory" onchange="updateFilter()">
				<OPTION value="0" <%if daysOfHistory = 0 then%>selected<%end if%>>Today</OPTION>
				<OPTION value="1" <%if daysOfHistory = 1 then%>selected<%end if%>>Yesterday</OPTION>
				<OPTION value="7" <%if daysOfHistory = 7 then%>selected<%end if%>>Last Week</OPTION>
				<OPTION value="30" <%if daysOfHistory = 30 then%>selected<%end if%>>Last Month</OPTION>
				<OPTION value="90" <%if daysOfHistory = 90 then%>selected<%end if%>>Last Quarter</OPTION>
				<OPTION value="365" <%if daysOfHistory = 365 then%>selected<%end if%>>Last Year</OPTION>
				<OPTION value="32000" <%if daysOfHistory = 32000 then%>selected<%end if%>>All</OPTION>
			</SELECT>
		</TD>
		<% end if %>
	</TR>
</TABLE>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">

	</SPAN>
	<SPAN style="float:right">
        <BUTTON onclick="exit()">Exit</BUTTON>
        <% if showClosed <> "" then %>
        <BUTTON id="btnOpenDelivery" onclick="viewDelivery()" disabled>View</BUTTON>
        <% else %>
        <BUTTON id="btnOpenDelivery" onclick="openDelivery()" disabled>Next</BUTTON>
        <% end if %>
	</SPAN>
</DIV>	

<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH style="width:150px" align="center">Delivery</TH>
		<TH>Employee</TH>
		<TH>Route</TH>
		<TH>Date Create</TH>
		<TH>Delivery Date</TH>
		<TH>Status</TH>
	</TR>
<%

	query = " select delivery.*, isnull(employee.employeename, '') as employeename, convert(varchar, delivery.deliverydate, 101) as deliverydate from delivery left outer join employee on "
	query = query & " delivery.employeeid = employee.employeeid "
	
	if showClosed <> "" then
		query = query & " where delivery.status = 5 "
		query = query & " and datediff(day, delivery.datecreated, getdate()) <= " & daysOfHistory
	else
		query = query & " where delivery.status <> 5 "
	end if
	
	query = query & " order by delivery.deliveryid "
	
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
%>
	<TR deliveryid="<%=rs("deliveryid")%>" onclick="selectRow(this)">

		<TD  style="width:150px" align="center"><%=rs("deliveryid")%></TD>
		<TD><%=rs("employeename")%></TD>
		<TD><%=getRouteNamesForDeliveryID(rs("deliveryid"))%></TD>
		<TD><%=rs("datecreated")%></TD>
		<TD><%=rs("deliverydate")%></TD>
		<TD><%=getDeliveryStatusHTML(rs("status"))%></TD>
	</TR>
<%
		rs.movenext
	wend
	
	set rs = nothing
%>
</TABLE>

</FORM>
</BODY>
</HTML>
