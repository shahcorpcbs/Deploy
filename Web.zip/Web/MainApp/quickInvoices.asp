<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	
	on error resume next

	dim objRSQuickInvoices

	'	Getting Quick Invoices for all Stores and Date Ranges in this release.
	'	In the future, if filtering is to be done, the SP already has these parameters.
	Set objRSQuickInvoices = getDisconnectedRecordset("EXECUTE GetQuickInvoices" ) 
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & "-Function= Quick Invoices. Error while getting the list of Quick Invoices."
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if

%>

<HTML>
<HEAD>
<TITLE>Quick Invoices</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript">
	var previousElement=null;
	var l_ticketnumber = null;
	
	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.style.background="white";
		}
		childEl = element.children[0];
		var rowChildNodes = childEl.children
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if(childEl.tagName == "INPUT") {
				childEl.checked=true;
				l_ticketnumber = childEl.value;
				document.currentInvoices.trackDetail.disabled = false
				document.currentInvoices.view.disabled  = false
				break;
			}
		}
		previousElement =element;
		element.style.background="#DBF2F4";
		 
	}
	function goToPickup(tnum)
	{
		document.quickInvoices.action = "Detailedinvoice.asp?userAction=edit&Ticketnumber=" + tnum + "&multiplePickup=0&originPage=quickinvtool";
		document.quickInvoices.submit();
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->

<H1>&nbsp;List of Quick Invoices</H1>

<FORM id="quickInvoices" name="quickInvoices" action="" method="post">

<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=0>
	<tr>
		<td align="center">
			<TABLE WIDTH="750px" BORDER=0 CELLSPACING=1 CELLPADDING=5>
				<!-- heading -->
				<tr>
					<th width =50px align=left class="label">Invoice Number</th>
					<th width =120px align=left class="label">Customer Name</th>
					<th width =50px align=left class="label">Date In</th>
					<th width =100px align=left class="label">Department</th>
					<th width =10px  align = right class="label">Qty</th>
					<th width =220px align=left class="label">Notes</th>
				</tr>
			</table>
		</td>
	</tr>
	<!-- list -->
	<tr>
		<td align="center">
			<DIV STYLE="overflow-y:auto;height:350px; overflow-x:auto; width=750px">
					<TABLE WIDTH="100%" style="border-color:#2F4F4F;border-style:solid;background-color:white;" BORDER=1 CELLSPACING=0>
						<tr rowspan =5>
							<td>
								<TABLE WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=3>
									<%while not objRSQuickInvoices.eof 
									%>	
										
											<tr onClick="javascript:goToPickup(<%=objRSQuickInvoices("ticketNumber")%>)">

											<td width = 50px  STYLE="FONT-SIZE: 12px;"><%=objRSQuickInvoices("invoiceNumber") %></td>
											<td width = 120px  STYLE="FONT-SIZE: 12px;"><%=objRSQuickInvoices("customerName") %></td>
											<td width = 50px  STYLE="FONT-SIZE: 12px;"><%=objRSQuickInvoices("createdDate") %></td>
											<td width = 100px  STYLE="FONT-SIZE: 12px;"><%=objRSQuickInvoices("departmentName") %></td>
											<td width = 10px  STYLE="FONT-SIZE: 12px;"  align = right><%=objRSQuickInvoices("totalPieces") %></td>
											<td width = 220px  STYLE="FONT-SIZE: 12px;"><%=objRSQuickInvoices("itemNotes")%></td>

										</tr>

									<%	objRSQuickInvoices.MoveNext
										wend
										
										objRSQuickInvoices.Close
										set objRSQuickInvoices = Nothing

									%>	
									
								</table>
							</td>
						</tr>
				</table> <!-- table for border -->
			</div>
		</td>
	</tr>
	<!-- buttons -->
	<tr>
		<td align="center">
			<TABLE WIDTH="750px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
				<tr height=20px></tr>
				<tr>
					<td align="center">
						<INPUT class=touchnoborder id=close name=close type=button value="" style="background-image:url(../images/cancel.gif)" onClick="location.href='/mainapp/toolsmenu.asp';">
					</td>
				</tr>
			</table>
		</td>
	<tr>
</TABLE>
</FORM>
</BODY>
</HTML>
