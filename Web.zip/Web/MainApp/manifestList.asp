<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp" -->

<!-- #include file="../include/manifest.asp" -->

<!-- #include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim showClosed
	dim daysOfHistory
	dim orderBy
	dim searchString
	
	showClosed = getReqVar("showClosed")
	daysOfHistory = getReqVar("daysOfHistory")
	if daysOfHistory = "" then daysOfHistory = 0
	orderBy = getReqVar("orderBy")
	searchString = getReqVar("searchString")

	select case lcase(request.querystring("useraction"))
	case "close"
		closeSelectedManifests

	end select

	function closeSelectedManifests()
		dim manifestid
		
		
		for each manifestid in request.form("chkManifest")
			CBS_closeManifest manifestid
			CBS_inactiveManifest manifestid
		next
	
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	

%>


<HTML>
<HEAD>


<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">


<script language="javascript" src="../external/jquery-3.4.1.js"></script>

<script language="javascript" type="text/javascript">

	
	function viewSelectedManifest() {
		var il = document.manifestList;
		var len = il.elements.length;
		var manifestID = 0;
		var invoiceCount = 0;
		
		for (var i = 0; i < len; i++) {
		    var e = il.elements[i];
		    if (e.name == "chkManifest" && e.checked) {
				manifestID = e.value;
				++invoiceCount;
		    }
		}

		if(invoiceCount > 1) {
			cbs_alert("Can only view a manifest invoice (" + invoiceCount + " selected).")
		}
		else if(invoiceCount == 1) {
			document.manifestList.action = "/mainapp/manifest.asp?manifestid=" + manifestID;
			document.manifestList.submit();
		}
		else {
			cbs_alert("Must select an manifest before performing action.");
		}
	}
	
	function closeSelectedManifest() {
	    cbs_confirm("Close selected manifests?", closeManifest);
	}

	function closeManifest() {
        clearConfirmMsg();
        document.manifestList.action = "?useraction=close";
        document.manifestList.submit();
	}

	function exit() {
	    document.manifestList.action = "/mainapp/toolsMenu.asp";
	    document.manifestList.submit();
	}

	function updateFilter() {
	      document.manifestList.action = "?useraction=updatefilter";
	      document.manifestList.submit();
	}
	
	function SetRowCheckedStatus(row, check, value) {
				
		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "chkManifest") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked), false);
				break;
			}
			else if (childEl.name == "chkManifest") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked), false);
				break;
			}
		}
	}
	

	function addManifest() {
		var manifestName  = cbs_prompt("Manifest name:", handleManifestNamed, "Scanned");
	}

	function handleManifestNamed() {
        clearPromptMsg();
	    var manifestName = document.getElementById('inputTxtLine').value
		var parentManifestID = "";
		if(manifestName) {
			jQuery.getJSON("/mainapp/manifestActions.asp?a=createmanifest&name=" + encodeURIComponent(manifestName),
				function(data) {
					if(data.success != "0") {
						document.manifestList.action = "/mainapp/manifest.asp?manifestid=" + data.answer;
						document.manifestList.submit();
					}
					else {
						cbs_alert("Could not create manifest.");
					}
				}
			);
		}
	}

</script>

<style type="text/css">

</style>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<FORM name="manifestList" ID="manifestList" METHOD=POST  style="margin:0;padding:0" onSubmit="return false">
<H1>Manifests</H1>



<DIV style="text-align: center; font-size: 18; padding: 8px" >
Show since
<SELECT name="daysOfHistory">
	<OPTION value="0" <%if daysOfHistory = 0 then%>selected<%end if%>>Today</OPTION>
	<OPTION value="1" <%if daysOfHistory = 1 then%>selected<%end if%>>Yesterday</OPTION>
	<OPTION value="7" <%if daysOfHistory = 7 then%>selected<%end if%>>Last Week</OPTION>
	<OPTION value="30" <%if daysOfHistory = 30 then%>selected<%end if%>>Last Month</OPTION>
	<OPTION value="90" <%if daysOfHistory = 90 then%>selected<%end if%>>Last Quarter</OPTION>
	<OPTION value="365" <%if daysOfHistory = 365 then%>selected<%end if%>>Last Year</OPTION>
	<OPTION value="32000" <%if daysOfHistory = 32000 then%>selected<%end if%>>All</OPTION>
</SELECT>

closed
<INPUT type="checkbox" style="height=28px;width=28px" name="showClosed" value="1" <%if showClosed <> "" then%>checked<%end if%> />
order
<SELECT name="orderby">
	<OPTION value="asc" <%if orderBy = "asc" then%>selected<%end if%>>Ascending</OPTION>
	<OPTION value="desc" <%if orderBy = "desc" then%>selected<%end if%>>Descending</OPTION>
</SELECT>

<INPUT value="<%=searchString%>" name="searchString" />&nbsp;
<BUTTON onclick="updateFilter()">Search</BUTTON>

</DIV>


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="viewSelectedManifest()">View</BUTTON>
		<BUTTON onclick="addManifest()">New</BUTTON>
		<BUTTON onclick="closeSelectedManifest()">Close</BUTTON>


	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" cellspacing="0">

	<TR>
		<TH>&nbsp;</TH>
		<TH style="width:100px">Manifest #</TH>
		<TH>Name</TH>
		<TH>Date Created</TH>
		<TH>Note</TH>
		<TH>Invoice Count</TH>
	<TR>

<%
	query = " select isnull(convert(varchar, m1.dateracked, 101), '') as dateracked, m1.name, m1.manifestid, m1.parentmanifestid, m1.datecreated, isnull(m2.name, '') as parentname, dbo.getItemCountOnManifest(m1.manifestID) as itemCount from "
	query = query & " manifest m1 "
	query = query & " left outer join manifest m2 on m1.parentmanifestid = m2.manifestid "
	if showClosed = "" then
		query = query & " where m1.active = 1 and m1.[type] <> 'TLIST' "
	else
		query = query & " where m1.active = 0 and m1.[type] <> 'TLIST' "
	end if
	
	query = query & " and datediff(day, m1.datecreated, getdate()) <= " & daysOfHistory
	
	if searchString <> "" then
		query = query & " and m1.manifestid in (select distinct manifestid from manifestitem where invoicenumber = '" & dbstr(searchString) & "')"
	end if
	
	if orderBy = "desc" then
		query = query & " order by isnull(m1.parentmanifestid, m1.manifestid) desc, m1.parentmanifestid desc  "
	else
		query = query & " order by isnull(m1.parentmanifestid, m1.manifestid), m1.parentmanifestid  "
	end if

	
	set rs = getdisconnectedrecordset(query)


	while not(rs.eof or rs.bof)
%>
	<% if isnull(rs("parentmanifestid")) then %>
		<TR manifestID="<%=rs("manifestid")%>" onclick="ToggleRowChecked(this)" class="manifest_head">
			<TD align="center"><INPUT type="checkbox" onclick="ToggleRowChecked(this.parentNode.parentNode);" value="<%=rs("manifestid")%>" name="chkManifest"></TD>
			<TD align="center"><IMG src="/static/icons/16x16/copy.png"> <%=rs("manifestid")%></TD>
			<TD><%=Server.HTMLEncode(rs("name"))%></TD>
			<TD><%=rs("datecreated")%></TD>
			<TD><%
				if rs("dateracked") <> "" then
					response.write "Racked " & rs("dateracked")
				else
					response.write "&nbsp;"
				end if
			%></TD>
			<TD><%=rs("itemCount")%></TD>
		</TR>
	<% else %>
		<TR manifestID="<%=rs("manifestid")%>" onclick="ToggleRowChecked(this)" class="manifest_item">
			<TD align="center"><INPUT type="checkbox" onclick="ToggleRowChecked(this.parentNode.parentNode);" value="<%=rs("manifestid")%>" name="chkManifest"></TD>
			<TD align="center"><IMG src="/static/icons/16x16/new.png"> <%=rs("manifestid")%></TD>
			<TD><%=Server.HTMLEncode(rs("name"))%></TD>
			<TD><%=rs("datecreated")%></TD>
			<TD><%
				if rs("dateracked") <> "" then
					response.write "Racked " & rs("dateracked")
				else
					response.write "&nbsp;"
				end if
			%></TD>
			<TD><%=rs("itemCount")%></TD>
		</TR>
	<% end if %>
<%
		rs.movenext
	wend

	set rs = nothing
%>

</TABLE>


</FORM>
</BODY>
</HTML>
