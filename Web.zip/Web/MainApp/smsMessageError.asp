<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim customerseq, messageId, directSel, searchText, includeErrors, dateBegin, dateEnd

    customerSeq = getReqVar("customerSeq")
	messageId = getReqVar("messageId")
	directSel = getReqVar("directSel")
	searchText = getReqVar("searchText")
	includeErrors = getReqVar("includeErrors")
	dateBegin = getReqVar("dateBegin")
	dateEnd = getReqVar("dateEnd")

	query = " select smh.employeeId, e.employeeName, requestDate, customerId, phoneNumber, queueStatus, twilioErrorCode, errorMessage "_
	    & "from TwilioSendSmsApiCall smh left join employee e on smh.employeeId = e.employeeId "
	query = query & " where smh.id = " & messageId
	set rs = getdisconnectedrecordset(query)


	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

%>
<HTML>
<HEAD>
<TITLE>SMS Error</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript">
	function createActionString() {
	    var searchText = '<%=searchText%>'
	    var action = "";
	    if (searchText.length > 0) {
	        action = action + "&searchText=" + encodeURIComponent(searchText)
	    }

	    action = action + "&directSel=" + encodeURIComponent(<%=directSel%>)
	    action = action + "&dateBegin=<%=dateBegin%>"
	    action = action + "&dateEnd=<%=dateEnd%>"
        action = action + "&includeErrors=<%=includeErrors%>"
	    return action;
	}

	function exit() {
        document.smsMessageError.action = "/mainapp/SMSHistory.asp?customerseq=<%=customerSeq%>" + createActionString();
        document.smsMessageError.submit();
	}

</script>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>
    SMS Error
</H1>

<FORM id="smsMessageError" name="smsMessageError" action="" method="post">
<INPUT type="hidden" name="customerseq" value="<%=customerseq%>" />
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
    <SPAN style="float:right">
        <BUTTON onclick="exit()">Exit</BUTTON>
    </SPAN>
</DIV>
<div style="height: 640px; overflow: scroll">
<table class="itable" width="100%" cellspacing="0">
<tr>
	<th>Employee</th>
	<th>Time</th>
	<th>Customer</th>
	<th>Phone Number</th>
	<th>Status</th>
	<th>Twilio Error Code</th>
	<th>Error Message</th>
</tr>

<%
	while not(rs.eof or rs.bof)
%>
<tr>

	<td>
        <% if rs("employeeId") = 0 then %>
            Scheduler Service
        <% elseif rs("employeeId") = -1 then %>
            Auto Handler
        <% else %>
            <%=rs("employeeName")%>
        <% end if %>
	</td>
	<td><%=rs("requestDate")%></td>
	<td><%=rs("customerId")%></td>
	<td><%=rs("phoneNumber")%></td>
	<td>
        <% if rs("queueStatus") = 0 then %>
            Queued
        <% elseif rs("queueStatus") = 1 then %>
            Sent
        <% elseif rs("queueStatus") = -1 then %>
            Will Retry Later
        <% elseif rs("queueStatus") = -2 then %>
            Won't Retry
       <% elseif rs("queueStatus") = -3 then %>
            Blocked Due to Limit
        <% end if %>
	</td>
	<td><%=rs("twilioErrorCode")%></td>
	<td><%=rs("errorMessage")%></td>
</tr>

<%
		rs.movenext
	wend
	set rs = nothing
%>
</table>
</div>

</FORM>
</BODY>
</HTML>

