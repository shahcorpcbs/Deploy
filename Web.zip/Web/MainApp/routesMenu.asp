<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	select case lcase(Request.QueryString("userAction"))
		case "gotoreport"
			GotoReport Request.QueryString("id")

			
	end select
	
	
	sub GotoReport(reportID)
		Response.Redirect "reportParams.asp?reportID=" & reportID & "&requesterName=" & RPT_Requester_Name_Route
	end sub

%>
<HTML>
<HEAD>
<TITLE>Routes Menu</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function showCheckIn() {
		document.routesMenuForm.action="checkIn.asp";
		document.routesMenuForm.submit();
	}
	function showCheckOut() {
		document.routesMenuForm.action="checkOut.asp";
		document.routesMenuForm.submit();
	}
	function showScheduleDelivery() {
		document.routesMenuForm.action="customersearch.asp?userAction=scheduledelivery";
		document.routesMenuForm.submit();
	}
	function GotoReport(id) {
		document.routesMenuForm.action="?userAction=gotoreport&id=" + id;
		document.routesMenuForm.submit();
	}
	
</script>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Routes</H1>
<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >	
	<FORM id="routesMenuForm" name="routesMenuForm" action="" method="post">
		<tr height=50px></tr>
		<tr height=80px>
		<td align=center>
				<BUTTON class=std  id=checkOut name=checkOut  onClick="showCheckOut()"><img src="../images/check-Out.gif"><br>Check Out</button>
				<!--<INPUT class=touch id=checkOut name=checkOut type=button value="" style="background-image:url(../images/check-Out.gif)" onClick="showCheckOut()"><br>Check Out-->
			</td>
		</tr>
		<tr height=80px>
			<td align=center>
				<!--<INPUT class=touch id=checkIn name=checkIn type=button value="" style="background-image:url(../images/Check-In.gif)" onClick="showCheckIn()"><br>Check In-->
				<BUTTON class=std  id=checkIn name=checkIn onClick="showCheckIn()"><img src="../images/Check-In.gif"><br>Check In</button>
			</td>
		</tr>
		
		<tr height=80px>
			<td align=center>
				<BUTTON class=std id=scheduleDelivery name=scheduleDelivery  onClick="showScheduleDelivery()"><img src="../images/Calender-3.gif"><br>Schedule Delivery</button>
				<!--<INPUT class=touch id=scheduleDelivery name=scheduleDelivery type=button value="" style="background-image:url(../images/Calender-3.gif)" onClick="showScheduleDelivery()"><br>Schedule Delivery-->
			</td>
		</tr>
		
		<tr height=100px>
			<td align=center>
			Generate Report<br>
			<span style="border:2px inset;padding:15px">
			<input type=button style="width:130px;height:50px" value="Delivery List" onclick="GotoReport(17)" id=button1 name=button1></button>
			<input type=button style="width:130px;height:50px" value="Delivery Manifest"  onclick="GotoReport(18)" id=button2 name=button2></button>
			</span>
			</td>
		</tr>
	</form>
</table>
</BODY>
</HTML>
