

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!-- #include file="../include/security.asp" -->
<!-- #include file="../external/include.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	Dim userAction
    Dim dateTypeCriteria
    Dim customerNameCriteria
    Dim invoiceNumberCriteria
    Dim paymentAmountCriteria

    dateTypeCriteria = Request.QueryString("dateTypeCriteria")
    fromDateCriteria = Request.QueryString("fromDateCriteria")
    toDateCriteria = Request.QueryString("toDateCriteria")
    customerNameCriteria = Request.QueryString("customerNameCriteria")
    invoiceNumberCriteria = Request.QueryString("invoiceNumberCriteria")
    paymentAmountCriteria = Request.QueryString("paymentAmountCriteria")

	userAction = Request.QueryString("userAction")

	Select Case userAction
		Case "searchByInvoice"
		    GetInvoiceDetails
		Case "updatePayment"
		    updateDatabase
		Case "cancel"
		    cancelForm
	End Select
	
	Sub cancelForm()
	    Response.Redirect "\reversePaymentMenu.asp?mode=edit"
	End Sub

	Sub updateDatabase()
			
		Dim query
		Dim sqltxt
	    Dim employeeid
	    Dim l_terminalid
	    Dim employeename
	    Dim l_storeid  
        Dim ticketNumber
        Dim paymentNumber
        Dim voidReason
        Dim rackLocation
        Dim l_status
        Dim voidApplied
        Dim invoiceNum
        Dim paymentAmount
        Dim tranType
        
        employeeid = Session("employeeID")
		l_terminalid = Session("terminalID")
		employeename = Session("employeeName")
		l_storeid = Session("storeId")
		
        ticketNumber = Request.QueryString("ticketNumber")
        paymentNumber = Request.QueryString("paymentNumber")
        invoiceNum = Request.QueryString("invoiceNum")
        voidReason = Request.QueryString("voidReason")
        rackLocation = Request.QueryString("rackLocation")
        l_status = Request.QueryString("status")
        paymentAmount = Request.QueryString("paymentAmount")
        tranType = Request.QueryString("tranType")

        Response.Write voidReason

        If ticketNumber = " " Then
            ticketNumber = 0
            invoiceNum = 0
        End If 
 	 
        dbstartTrans()
	
	    sqltxt = "execute ApplyReversePayment @paymentNumber= " & paymentNumber & ",@ticketNumber= " & ticketNumber & ",@employeeid=" & employeeid & ",@storeid= " & l_storeid & _
	    ",@terminalid=" & l_terminalid & ",@reversePayment=" & paymentAmount & ",@status =" & l_status & ",@voidReason=" & voidReason & ",@rackLocation=" & rackLocation & ",@invoiceNumber = " & invoiceNum
	
	    QryExecuteWithTrans(sqltxt)
			    
	    DbEndTrans()

	End Sub
%>
	
<!DOCTYPE html>
<html>
    <head>
        <title>Return Payment</title>
        <link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
        <link href="../script/greyscale.css" rel="stylesheet" type="text/css">

        <script language="JavaScript" src="../script/date-picker.js"></script>
        <script language="javascript" type="text/javascript">

            var previousElement=null;

            function cancelForm(){
                document.reversepaymentform.action = "?userAction=cancel";
                document.reversepaymentform.submit();	
            }

            function submitForm() {
                var selection = getSelectedInvoice();

                if (selection) {
                    var ticketNumber = selection.getAttribute('data-ticketnumber');
                    var paymentNumber = selection.getAttribute('data-paymentnumber');

                    var dateTypeCriteria = document.getElementById('selDate').value;
                    var fromDateCriteria = document.getElementById('txtFromDate').value;
                    var toDateCriteria = document.getElementById('txtToDate').value;
                    var customerNameCriteria = document.getElementById('custName').value;
                    var invoiceNumberCriteria = document.getElementById('invoiceNumber').value;
                    var paymentAmountCriteria = document.getElementById('paymentAmount').value;

                    document.reversepaymentform.action = 'applyReturnPayment.asp?ticketNumber=' + ticketNumber + '&paymentNumber=' + paymentNumber + '&dateTypeCriteria=' + encodeURIComponent(dateTypeCriteria) + 
                                                         '&fromDateCriteria=' + encodeURIComponent(fromDateCriteria) + '&toDateCriteria=' + encodeURIComponent(toDateCriteria) + '&customerNameCriteria=' + encodeURIComponent(customerNameCriteria) +
                                                         '&invoiceNumberCriteria=' + invoiceNumberCriteria + '&paymentAmountCriteria=' + encodeURIComponent(paymentAmountCriteria);
                    document.reversepaymentform.submit();
                } else {
                    cbs_alert('Please select an invoice');
                }
                
            }
	
	        function SetRowChecked(r, value) {
		        var childEl;
		        var rowChildNodes = r.children;

		        for(i=0; i<rowChildNodes.length; i++){
			        childEl = rowChildNodes[i];

			        if (childEl.children[0] && childEl.children[0].name == "chkInvoice") {
				        SetRowCheckedStatus(r, childEl.children[0], value, false);
				        break;
			        }
			        else if (childEl.name == "chkInvoice") {
				        SetRowCheckedStatus(r, childEl, value, false);
				        break;
			        }
		        }
	        }

	        function startupActions() {
	            if (document.getElementById('selDate').value == 'Date Range') {
	                document.getElementById('fromDate').style.display = "block";
	                document.getElementById('toDate').style.display = "block";
	            }
                reloadData();
            }

	
	        function searchByDate(value) {
	            var text;
	
                if( value == "Date Range")
	            {
	                document.getElementById('fromDate').style.display = "block";
	                document.getElementById('toDate').style.display = "block";
	            }
	            else
	            {
	                document.getElementById('fromDate').style.display = "none";
	                document.getElementById('toDate').style.display = "none";

	                document.getElementById('txtFromDate').value = "";
	                document.getElementById('txtToDate').value = "";
	
	                reloadData();
	            }
            }
  
	        function setDateRange() {
	
	            var value;
	            var fromDt;
	            var toDt;
	            var text;
	
	            fromDt = document.getElementById('txtFromDate').value;
	            toDt = document.getElementById('txtToDate').value;
	
	            value = "Date Range";
	
	            if(fromDt == "" || toDt == "")
	            {
	                cbs_alert("Please provide from and to dates");
	                return false;
	            }
	
	            if(new Date(fromDt) > new Date(toDt))
	            {
	                cbs_alert("Please select valid dates");
	                return false;
	            }
		
	            reloadData();
	        }
	
	
	        function searchByCustomerName() {
	            var text;
	
	            text = document.getElementById('custName').value;
	
	            if(event.keyCode == 13) {
		            if(text.length > 0 ) {
			            cancelTimeout();
			            doUpdate();
		            }
	            } else if(text.length > 2) {
		            document.getElementById('fromDate').style.display = "none";
	                document.getElementById('toDate').style.display = "none";
		
		            $("#searchResults1").load("returnPaymentSearchResults.asp", {searchText: text} );
	            }
            }

            function searchByInvoice() {
	            var text;
	            text = document.getElementById('invoiceNumber').value;
	
	            if(event.keyCode == 13) {
	                document.getElementById('fromDate').style.display = "none";
	                document.getElementById('toDate').style.display = "none";
	                if(text.length > 0 ) {
	                    $("#searchResults1").load("returnPaymentSearchResults.asp", {searchText: text} );
	                }
		        }
            }

            function reloadData() {
                var criteria = {};

                var customerName = document.getElementById('custName').value;
                var invoiceNumber = document.getElementById('invoiceNumber').value;
                var dateType = document.getElementById('selDate').value;
                var fromDate = document.getElementById('txtFromDate').value;
                var toDate = document.getElementById('txtToDate').value;
                var paymentAmount = document.getElementById('paymentAmount').value;

                $("#searchResults1").load("returnPaymentSearchResults.asp", {
                    customerName: customerName,
                    invoiceNumber: invoiceNumber,
                    dateType: dateType,
                    fromDate: fromDate,
                    toDate: toDate,
                    paymentAmount: paymentAmount
                });
            }

            function formatAmount() {
                if (document.reversepaymentform.paymentAmount.value > 0) {
                    var tempval = document.reversepaymentform.paymentAmount.value.replace(/\./, "");
                    document.reversepaymentform.paymentAmount.value = tempval.substr(0, tempval.length - 2) + "." + tempval.substr(tempval.length - 2);
                } else {
                    document.reversepaymentform.paymentAmount.value = "";
                }
            }

	        function resetTimeout() {
		        if(timer != null) {
			        clearTimeout(timer);
		        }

		        timer = setTimeout("doUpdate();", 200);
	        }

	        function cancelTimeout() {
		        clearTimeout(timer);
		        timer = null;
	        }
	
	        function clearResults() {
	            $("#searchResults").empty();
	            $("#searchResults").append("<H3>No Results</H3>");
            }
        </script>
    </head>

    <body topmargin=0 leftmargin=0 onLoad="startupActions();">
        <!-- #include file="../include/banner.inc" -->

        <form id="reversepaymentform" name="reversepaymentform" action="" method="post" onload ="startupActions();" >
            <table align="center" cellspacing="10" cellpadding="5" >
	            <tr>
	                <td>
	                    By Date
	                    <br/>
				        <select style="font-size:20" onChange="searchByDate(this.value)" id="selDate" name="selDate">
                            <option value="" <% If Trim(dateTypeCriteria) = "" Then  %> selected  <% End If %>></option>
			                <option value="Yesterday" <% If Trim(dateTypeCriteria) = "Yesterday" Or IsEmpty(Request.QueryString("dateTypeCriteria")) Then  %> selected  <% End If %>>Yesterday</option>
				            <option value="Last 7 days" <% If Trim(dateTypeCriteria) = "Last 7 days" Then  %> selected  <% End If %>>Last 7 days</option>
				            <option value="Current Month" <% If Trim(dateTypeCriteria) = "Current Month" Then  %> selected  <% End If %>>Current Month</option>
				            <option value="Date Range" <% If Trim(dateTypeCriteria) = "Date Range" Then  %> selected  <% End If %>>Date Range</option>
				        </select>
	                </td>
		            <td>
			            Customer Last Name<BR />
			            <input name="custName" id="custName" style="font-size:20" onkeyup="reloadData();" value="<%=customerNameCriteria %>" />
		            </td>
		            <td>
			            Invoice Number<BR />
			            <input name="invoiceNumber" id="invoiceNumber" style="font-size:20" value="<%=invoiceNumberCriteria %>" onkeyup="reloadData();">
		            </td>
                    <td>
			            Payment Amount<BR />
			            <input name="paymentAmount" id="paymentAmount" style="font-size:20" value="<%=paymentAmountCriteria %>" onkeyup="formatAmount();reloadData();">
		            </td>
		            <td style="padding-left:20px">
			            <button style="height:50px;width:100px" onclick="cancelForm()" id="btnCancel" name="btnCancel">Cancel</button>
		            </td> 
                    <td>
			            <button style="height:50px;width:120px" onclick="submitForm()" id="btnSubmit" name="btnSubmit">Return Payment</button>
		            </td> 
	            </tr>
	            <tr>
	                <td id="fromDate" style="display:none">
	                    From
	                    <input name="txtFromDate" onclick="show_calendar('reversepaymentform.txtFromDate');" readonly value="<%=fromDateCriteria %>" />
	                </td>
	
	                <td id="toDate" style="display:none">
	                    To
	                    <input name="txtToDate" onclick="show_calendar('reversepaymentform.txtToDate');" readonly value="<%=toDateCriteria %>" />
	                    &nbsp &nbsp
                        <button onclick="setDateRange();" id=button1 name=button1>Search</button>
	                </td>
	            </tr>
            </table>

            <br/>
            <br/>

            <div id="searchResults1" style="height:550px;overflow-y:scroll;background:white" >
            </div>
									
        </form>
    </body>
</html>

