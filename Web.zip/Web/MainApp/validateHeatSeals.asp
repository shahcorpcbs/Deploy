<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	'***********************************************************************
	'Name   :Validate Heat Seal Numbers
    'Author : Poonam Gupta
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 12-SEPT-2002    Poonam			Original Version
    '***********************************************************************

    dim invoice
    dim itemsHeatSealInfo
    'invoice details
    dim lineInfo
    dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim dueDateSet
	dim dueDate
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim targetPage, originatingPage
	dim actionString

    actionString = Request.QueryString("userAction")
    set invoice = Session("invoice")
    set itemsHeatSealInfo = invoice.rstHeatSealInfo

    select case actionString
		case "fromDetail"
			collectInvDataFromQueryString
		case "delete"
			collectInvDataFromForm
			deleteSelectedHeatSealNos
		case "submit"
			collectInvDataFromForm
			submitForm
	end select

   sub collectInvDataFromQueryString()
		curr_LineNo = Request.QueryString("lineNo")
		selectedDept = Request.QueryString("dept")
		itemsStartIndex = Request.QueryString("itIndex")
		upChargeStartIndex = Request.QueryString("upIndex")
		colorsStartIndex = Request.QueryString("cIndex")
		patternStartIndex = Request.QueryString("pIndex")
		addOrEdit = Request.QueryString("addOrEdit")
		deptStartIndex = Request.QueryString("deptIndex")
		selItemId = Request.QueryString("selItemId")
		selUpchargeValue = Request.QueryString("selUp")
		selColorValue = Request.QueryString("selColor")
		selPatternValue = Request.QueryString("selPattern")
		originatingPage = Request.QueryString("originPage")
	end sub

	sub collectInvDataFromForm()
		curr_LineNo = Request.Form("lineNumber")
		selectedDept = Request.Form("selectedDept")
		itemsStartIndex = Request.Form("ItemPageCount")
		upChargeStartIndex = Request.Form("upChargePageCount")
		colorsStartIndex = Request.Form("colorsPageCount")
		patternStartIndex = Request.Form("PatternPageCount")
		addOrEdit = Request.Form("addOrEdit")
		deptStartIndex = Request.Form("DeptPageCount")
		selItemId = Request.Form("selItemId")
		selUpchargeValue = Request.Form("selUpcharge")
		selColorValue = Request.Form("selColor")
		selPatternValue = Request.Form("selPattern")
		originatingPage = Request.Form("originPage")
	end sub

	sub deleteSelectedHeatSealNos()
		dim counter
		dim selHSNumber

		for counter =1 to Request.Form("select").Count
			selHSNumber = Request.Form("select")(counter)
			invoice.deleteHeatSealNumber selHSNumber
		next
		submitForm
	end sub

	sub submitForm()
		Response.Redirect "detailedInvoice.asp?userAction=fromValHeatSeal" _
							& "&addOrEdit=" & addOrEdit & "&lineNo=" & curr_LineNo _
							& "&dept=" & selectedDept & "&upIndex=" & upChargeStartIndex _
							& "&cIndex=" & colorsStartIndex & "&pIndex=" & patternStartIndex _
							& "&itIndex=" & itemsStartIndex & "&deptIndex=" & deptStartIndex _
							& "&selItemId=" & selItemId  & "&selUp=" & selUpchargeValue _
							& "&selColor=" & selColorValue & "&selPattern=" & selPatternValue
	end sub


%>

<HTML>
<HEAD>
<TITLE>Validate Heat Seal</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	var checkboxClicked=false;
	function selectRow(element) {
		var childEl;
		if(!checkboxClicked){
			childEl = element.children[0];
			var rowChildNodes = childEl.children
			for(i=0; i<rowChildNodes.length; i++){
				childEl = rowChildNodes[i];
				if(childEl.tagName == "INPUT") {
					if(childEl.checked) {
						childEl.checked=false;
						element.style.background="#F7FBFC";
					}
					else{
						childEl.checked=true;
						element.style.background="#DBF2F4";
					}
					break;
				}
			}
		}
		checkboxClicked=false;
	}

	function selectRowForCheckBox(element) {
		var parentEl;
		parentEl=element;
		while(parentEl.tagName != "TR") {
			parentEl = parentEl.parentElement;
		}
		if (element.checked){
			parentEl.style.background="#DBF2F4";
		}else{
			parentEl.style.background="#F7FBFC";
		}
		checkboxClicked=true;
	}

	function deleteSelectedHeatSeal() {
		document.valHeatSeal.action = "?userAction=delete";
		document.valHeatSeal.submit();
	}

	function submitForm() {
		document.valHeatSeal.action = "?userAction=submit";
		document.valHeatSeal.submit();
	}
</script>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Heat Seal Numbers</H1>
<FORM id="valHeatSeal" name="valHeatSeal" action="validateHeatSeals.asp" method="Post">
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<INPUT type="hidden" name="txtDueDate" value="<%= dueDate %>">
	<INPUT type="hidden" name="isDueDateSet" value="<%= dueDateSet %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	<TABLE ALIGN=center WIDTH="450px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=30px><td></td></tr>
		<tr>
			<td colspan=2>
				<TABLE ALIGN=center WIDTH="450px" BORDER=2 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td></td>
						<td>Department</td>
						<td>Item</td>
						<td>Heat Seal Number</td>
					</tr>
					<%
						itemsHeatSealInfo.MoveFirst
						while not itemsHeatSealInfo.eof
					%>
					<tr onClick="selectRow(this)">
						<td width=30px>
							<input type="checkbox" name="select" id="select" onClick="selectRowForCheckBox(this)" value="<%= itemsHeatSealInfo.Fields("heatSealID")%>" >
						</td>
						<td class="label"><%= itemsHeatSealInfo.Fields("deptName")%></td>
						<td class="label"><%= itemsHeatSealInfo.Fields("itemName")%></td>
						<% if itemsHeatSealInfo.Fields("heatSealID") <> -1 then %>
						<td class="label"><%= itemsHeatSealInfo.Fields("heatSealID")%></td>
						<%else%>
						<td class="label">&nbsp;</td>
						<%	end if	%>
					</tr>
					<%
							itemsHeatSealInfo.MoveNext
						wend
					%>
				</table>
			</td>
		</tr>
		<tr height=20px><td></td></tr>
		<tr>
			<td align=center>
				<INPUT class=touch id=delete name=delete type=button value="Delete" style="height:50;width:100" onclick="deleteSelectedHeatSeal()">
			</td>
			<td align=center>
				<INPUT class=touchnoborder id=ok name=ok type=button value="" style="background-image:url(../images/ok.gif);" onclick="submitForm()">
			</td>

		</tr>
	</table>
</form>

</BODY>
</HTML>