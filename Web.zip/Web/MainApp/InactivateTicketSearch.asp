<%@ Language=VBScript %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	'******************************************************************************
	'Name	: InactivateTicket.asp
	'==============================================================================
	' Date			Changed By		Change Log
    ' -----------------------------------------------------------------------------
	' 26-Sep-2003	MWiemann		Created 	
	'******************************************************************************

	dim actionString
	dim l_storeid 
	dim isSubmitted 
	
	l_storeid = session("storeid")
	isSubmitted = Request.QueryString("Submitted")
	
	if (isSubmitted ) then
		dim str
		
		actionString = Request.QueryString("userAction")	
		
		if (actionstring ="search") then
		
			str= "InactivateTicket.asp" & "?name=" & urlencode(Request.Form("txtcustomername"))_
					& "&customerid=" & urlencode(Request.Form("txtcustomerid"))	_
					& "&userAction=results"
					Response.Redirect(str)
					
		end if
	end if
	
	getKeyboardsetting()
	%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<HTML>
<HEAD>
<TITLE>Ticket Search</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<SCRIPT LANGUAGE=javascript>
	var lastFocusControl;
	<!--
		
	//-->
	
function txtInvoiceNumber_onblur() {
	lastFocusControl = event.srcElement;
}

</SCRIPT>
	


<script language="javascript" type="text/javascript">

	function cancelForm(){
	 	document.inactivateTicketSearchForm.action = "ManagerMenu.asp";
		document.inactivateTicketSearchForm.submit();
	}
	
	function searchTicket() {
		var invNum;
		
		invNum = trim(document.inactivateTicketSearchForm.txtInvoiceNumber.value);
		if ((invNum) != ""){
			document.inactivateTicketSearchForm.action= "InactivateTicket.asp?userAction=results&invoicenumber=" + invNum;
			document.inactivateTicketSearchForm.submit();
		}
		else {
			show_focus("Invoice Number cannot be blank", "CBS Error", document.inactivateTicketSearchForm.txtInvoiceNumber);
			return false;
		}
	}
	
	function captureKeyup(element){
		if (event.keyCode == "\r"){
			searchTicket()
		}	
	}


		
</SCRIPT>
</HEAD>

<BODY topmargin=0 leftmargin=0 onLoad ="document.inactivateTicketSearchForm.txtInvoiceNumber.focus()">
<!-- #include file="../include/banner.inc" -->
<H1>Invoice Search</H1>
<center>
<TABLE width="100%" align=center cellspacing="2" cellpadding="0" border="0">
<TR>
   <TD>
   <FORM id="inactivateTicketSearchForm" name="inactivateTicketSearchForm"  action="javascript: searchTicket()" method="Post">
   <input type="hidden" name="functionID" id="functionID" value="">
	
	<TABLE ALIGN=center BORDER=0 CELLSPACING=0 CELLPADDING=0 >
			<TR>
				<TD width=100px class=label>Invoice Number&nbsp</TD>
				<TD width=200px><INPUT id=txtInvoiceNumber name=txtInvoiceNumber class=text LANGUAGE=javascript onKeyup="captureKeyup(this)" onblur="return txtInvoiceNumber_onblur()" 
						style="HEIGHT: 25px; WIDTH: 150px">
				</TD>
				<TD valign=middle>
					<INPUT style="width:100px;height:50px" id=searchButton name=searchButton type=button value="Search" onclick="searchTicket()" />
					<INPUT style="width:100px;height:50px" id=cancelButton name=cancelButton type=button value="Cancel" onClick="cancelForm()" />
				</TD>
			</TR>
			<TR height=20px><TD></TD></TR>			
			<tr height=30px><td></td></tr>
		</TABLE>
		<TABLE width=100% align=center>	
			<tr>
				<td>
					<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=0 >
						<tr>
							<% if l_keyboard  then %>
							<!-- #include file="../include/keyboard_alphabeticalOrder.inc" -->								
							<% else %>
							<!-- #include file="../include/keyboard.inc" -->
							<%end if %>
						</tr>
					</table>
				</td>
				
			</tr>
		</TABLE>
		<P>&nbsp;</P>
		
		
		
		<BR>
	</TD>
</TR>
</TABLE></FORM>   
</center>
</BODY>
</HTML>
<%
	dim l_keyboard
	
	function getKeyboardsetting()
	dim sqltxt
	dim rsTemp
	
	l_keyboard = false
	
	sqltxt = "select switchOnscreenKeyboardAlphabetic from Miscsetup where storeid =  " & session("storeid")
	set rsTemp = getDisconnectedrecordset(sqltxt)
	'Response.Write sqltxt
	if rsTemp.recordCount > 0 then
		if rsTemp("switchOnscreenKeyboardAlphabetic")= true then
			l_keyboard = true
		end if
	end if
	rstemp.close
	set rstemp = nothing
		
	
	end function
%>
