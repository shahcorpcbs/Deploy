<%@ Language=VBScript %>
<%option explicit%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->

<%sec_RequestAccess Request.QueryString("userAction")%>
<%

%>

<HTML>
<HEAD>
<TITLE>HTML Form</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">


<link rel="stylesheet" type="text/css" href="/external/ext/resources/css/ext-all.css" />

<script type="text/javascript" src="/external/ext/adapter/ext/ext-base.js"></script>
<script type="text/javascript" src="/external/ext/ext-all-debug.js"></script>



<script type="text/javascript">
	var htmlEditor;
	var formEditor;
	var formList;

	var formStore = new Ext.data.Store({
	    remoteSort: true,
	    proxy: new Ext.data.HttpProxy({ url: 'editformactions.asp?a=getform' }),
	    reader: new Ext.data.JsonReader(
			{
	            root: 'rows',
	            totalProperty: 'recordcount'
	        },
	        [
				'formname',
				'formlayout'
			])
	});

	var formListStore = new Ext.data.Store({
	    remoteSort: true,
	    proxy: new Ext.data.HttpProxy({ url: 'editformactions.asp?a=getformlist' }),
	    reader: new Ext.data.JsonReader(
			{
	            root: 'rows',
	            totalProperty: 'recordcount'
	        },
	        [
				'formname',
				'type'
			])
	});
	
    var formListCM = new Ext.grid.ColumnModel([
		{ id: "formname", header: "Name", dataIndex: 'formname' },
		{ id: "formtype", header: "Type", dataIndex: 'type', hidden: true }
		]);


	function saveForm() {
		var form = formEditor.getForm();

		if(form.isValid()) {
			form.submit({
				url: 'editformactions.asp?a=saveform',
				scope: formEditor,
				waitMsg: 'Saving',
				failure: function(frm, act) {
					Ext.MessageBox.alert('Saving', 'Error saving form.');
				},
				success: function(frm, act) {
					Ext.MessageBox.alert('Saving', "Form has been saved.")
					formList.store.load();
				}
			});
		}
		else
			Ext.MessageBox.alert('Saving', 'Form not complete.')
	}

	function deleteForm() {
		var form = formEditor.getForm();


		form.submit({
			url: 'editformactions.asp?a=deleteform',
			scope: formEditor,
			waitMsg: 'Deleting',
			failure: function(frm, act) {
				Ext.MessageBox.alert('Deleting', 'Error deleting form.');
			},
			success: function(frm, act) {
				formList.store.load();
			}
		});

	}


	Ext.onReady(function(){

		Ext.QuickTips.init();
		

		var formListSel = new Ext.grid.RowSelectionModel({singleSelect:true});


		formList = new Ext.grid.GridPanel({
			region: 'west',
			width:200,
			split:true,
			store: formListStore,
			cm: formListCM,
			sm: formListSel,
			trackMouseOver:false,
			loadMask: {msg:'Loading Forms'},
			autoExpandColumn: 'formname'
		});


		formEditor = new Ext.FormPanel({
			labelAlign: 'top',
			region: 'center',
			frame:true,
	    	reader: new Ext.data.JsonReader(
			{
	            root: 'rows',
	            totalProperty: 'recordcount'
	        },
	        [
				'formname',
				'formlayout'
			]),
			items: [{
					xtype:'textfield',
	                fieldLabel: 'Name',
	                name: 'formname',
					allowBlank:false
	            },{
		            xtype:'htmleditor',
		            id: 'formlayout',
		            fieldLabel:'Body',
		            height:200
	            }],
	        buttons: [{
	            text: 'Delete',
				handler:deleteForm
	        },{
	            text: 'Save',
				handler:saveForm
	        }]
		});


		var formEditorPanel = new Ext.Panel({
			title: 'Forms',
			layout:'border',
			height: 500,
			renderTo: 'formeditor',
			items: [formList, formEditor]
		});

		formList.store.load();

	    formListSel.on('rowselect', function(sm, index, record) {
			formEditor.load({url:'editformactions.asp?a=getform&formname=' + record.data.formname, waitMsg:'Loading'});
	    });




	});


	function exit() {
		document.editForm.action = "/mainapp/marketingMenu.asp"
		document.editForm.submit();
	}
</script>





</HEAD>





<BODY topmargin=0 leftmargin=0 onload="">
<!-- #include file="../include/banner.inc" -->

<FORM name="editForm" ID="editForm" METHOD=POST  style="margin:0;padding:0">
<H1>Edit Form</H1>

<div name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<span style="float:left">

	</span>
	<span style="float:right">
		<button onclick="exit()">Exit</button>
	</span>
</div>

<div id="formeditor" name="formeditor" style=""></div>


</FORM>
</BODY>

</HTML>

