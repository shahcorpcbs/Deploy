<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim l_storeid
	dim l_mode
	dim isSubmitted 
	dim l_action
	
	l_storeid = Session("storeid")
	isSubmitted = Request.QueryString("submitted")
	
	if isSubmitted then
		session("Roleid") = Request.Form("rdname")
		l_action = Request.QueryString("useraction")	
		l_mode = Request.QueryString("mode")
		Response.Redirect(l_action & "?mode=" & l_mode)
	end if
%>
<HTML>
<HEAD>
<TITLE></TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">


	function submitForm(element) {
		var x;
			
		if (element=="add"){
				x = "AddEmployeeRole.asp";
				document.employeeRole.action="?Submitted=true&userAction=" + x  + "&mode=add";
			}
		else if	(element=="edit"){
				x = "AddEmployeeRole.asp";
				document.employeeRole.action="?Submitted=true&userAction=" + x  + "&mode=edit";
			}
		else {
			 x = "EmployeeManagement.asp";
			 document.employeeRole.action="?Submitted=true&userAction=" + x ;
			}
		document.employeeRole.submit();
	}			
	
	function enableEditButton(){
		document.employeeRole.edit.disabled = false;
	
	}
	
	function cancelForm(){
		document.employeeRole.action = "employeeManagement.asp";
		document.employeeRole.submit();
	
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<H1>Employee Roles</H1>
<FORM id="employeeRole" name="employeeRole" action="employeeManagement.asp" Method = "post">
<input type=hidden name="mode">
<TABLE WIDTH="600px" BORDER=0 align = center CELLSPACING=0 CELLPADDING=0 ><!-- header row -->
 <tr >
	<td align=left>
	<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0>
	<tr>
		<td>
		<DIV STYLE="HEIGHT: 212px; OVERFLOW-X: auto; OVERFLOW-Y: auto; WIDTH: 400px" >
		<TABLE style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =1 CELLSPACING=0>
			<tr><td>
			<TABLE  style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =1 CELLSPACING=0>
				<tr height =30>	
					<td width = 10></td>
					<td width = 100 >Role Name</td>
					<td width = 100 >Security Level</td>
				</tr>
				<%
					dim sqltxt
					dim rsRoles
					sqltxt = "select *  from employeeRole where storeid =" & l_storeid
					set rsRoles= getdisconnectedRecordset(sqltxt)
				%>
				<%	while not rsRoles.BOF and not rsRoles.EOF 
				%>
				<tr height =30>	
					<td width = 20 align = left ><Input type=radio name=rdname value="<%=rsRoles("RoleID")%>" style="height=28px;width=28px" onClick="enableEditButton()"></td>
					<td	width = 300 ><%=rsRoles("Name")%></td>
					<td width = 250 align = center ><%=rsRoles("SecurityLevel")%></td>
				</tr>	
				<%	rsRoles.movenext	
					wend		
					rsRoles.close
					set rsRoles = nothing 
				%>
			</TABLE>
		</td></tr>
		</table>
		</DIV>
		</TD>
		<td valign=top width=200px>
		<TABLE border=0 cellpadding=0 cellspacing=0 width="100%">
		<tr>
			<td align=center>
				<!--<INPUT class = touch name=add type=button value=""  style="background-image:url(../images/New-Employee.gif)" onClick="submitForm(this.name)"  ><br>Add Role-->
				<BUTTON class=std name=add onclick="submitForm(this.name)"><img src="../images/New-Employee.gif"><br>Add Role</button>
			</td>
		</tr>
		<tr>
			<td align=center> 
				<!--<INPUT class = touch name=edit type=button value=""   style="background-image:url(../images/Account-Management.gif)" disabled onClick="submitForm(this.name)"  ><br>Edit Role-->
				<BUTTON class=std name=edit onClick="submitForm(this.name)"><img src="../images/Account-Management.gif"><br>Edit Role</button>
			</td>
		</tr>
		</table>
	</tr>
	</table>
	</td>
	</tr>
	<tr>
		<td align=center  >
			<INPUT class = touchnoborder name=cancel id = cancel type=button value=""  style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
		</td>
	</tr>
</TABLE>
</FORM>
</BODY>
</HTML>
