<%@ Language=VBScript %>
<%option explicit%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim giftprogramid
	dim cardnumber
	dim customerseq
	
	customerseq = trim(getReqVar("customerseq"))
	
	if customerseq = "" then
		customerseq = session("giftcardcustseq")
		session("customersequencenumber") = customerseq
	elseif request.querystring("useraction") = "" then
		session("giftcardcustseq") = customerseq
	end if
	
	cardnumber = request.querystring("cardnumber")
	
	giftprogramid = getGiftCardProgramId(session("storeid"))

	select case lcase(request.querystring("useraction"))
	case "newcard"
		createNewCard giftprogramid, request.querystring("cardnumber"), customerseq
	case "assign"
		assignCard request.querystring("cardnumber"), request.querystring("customerseq")
	case "purchasevalue"
		purchaseValue request.querystring("cardnumber"), request.querystring("amount")
	case "assignvalue"
		assignValue request.querystring("cardnumber"), request.querystring("amount")
	case "frompickup"
		fromPickup
	
	end select
	
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function addValueToCard(cardnumber, amount)
		dim query, rs
		
		if cardnumber = "" or amount = "" then exit function
		
		query = " update giftcard set giftvalue = giftvalue + " & amount
		query = query & " where giftcardnumber = '" & dbstr(cardnumber) & "'"

		qryexecute query
	end function
	
	function fromPickup()
		dim paid
		dim pickupObj
		dim applyPrepayDiscount
		dim prepayDiscount
		dim signatureId
		dim amount
		dim invoice
		
		set invoice = Session("invoice")
		paid = Request.QueryString("paid")
		cardnumber = Session("giftcardnumber")
		amount =  Session("giftcardamount")
		
		'customerseq = invoice.custSeqNumber

		signatureId = Request.Form("PickupSignatureId")
		if signatureId = "" then
			signatureId = -1
		end if
		
		if paid = "true" then
			set pickupObj = Session("pickupObj")

			saveInvoiceToDatabase
			addValueToCard cardnumber, amount
		else
			invoice.cancelDoneOperation
		end if
		
		'if customerseq <= 1 then customerseq = ""
	end function
	
	sub saveInvoiceToDatabase()
		dim empId
		dim terminalId
		dim empName
		dim storeName
		dim invNumber
		dim transactionchangedue
		dim invoice
		dim pickupObj
		
		on error resume next
		
		set invoice = Session("invoice")

		empId = Session("employeeID")
		terminalId = Session("terminalID")
		empName = Session("employeeName")
		storeName = Session("storeName")
		
		invoice.saveInvoice "add", empId, terminalId, 0, empName, storeName, true
		
		
		set pickupObj = session("pickupObj")
		'pickupObj.userAction = "pickup"
		pickupObj.applyPayments empId, terminalId, "'" & invoice.getTicketNosForPrinting() & "'" , -1
		'transactionchangedue = pickupObj.getChangeDue()
	end sub


	
	function assignValue(cardnumber, amount)
		addValueToCard cardnumber, amount
	end function 
	
	function purchaseValue(cardnumber, amount)
		dim invoice
		dim pickupObj
		dim storeid

			
		storeid = session("storeid")
		
		set invoice = createInvoice(storeid)

		'invoice.custSeqNumber = customerseq
		
		if not (invoice is nothing) then
			invoice.addChargeLine -1, amount, "Gift Card", 1, -1

			set pickupObj = Server.CreateObject("ShahCorpComponents.pickup")
			pickupObj.DBConnectionString = Session("shahcorpDSN")
			pickupObj.storeId = storeid
			pickupObj.initStorePaymentTypeInfo()
			pickupObj.addInvoiceObjToPickup invoice
			pickupObj.userAction = "prepay"
			pickupObj.addOrEdit = "add"
			pickupObj.custSeqNumber = invoice.custSeqNumber
			
			set session("invoice") = invoice
			set Session("pickupObj") = pickupObj
			session("giftcardnumber") = cardnumber
			session("giftcardamount") = amount

			Response.Redirect "/mainapp/pickup.asp?targetPage=giftCard&userAction=prepay&addOrEdit=add"
		end if
	end function 

	
	function createInvoice(storeid)
		dim invoice
		dim query, rs
		dim objResultSet
		dim areaCode
		dim pricelistid
		dim customerseq
		
		set invoice = nothing
		
		query = "GetCounterSaleCustomer " & storeid
		Set rs = getDisconnectedRecordset(query)
		
		
		if rs.recordcount > 0 then
			rs.movefirst
			if isnull(rs.fields("defaultpriceListId")) then
				Response.Redirect "start2.asp"
			else
				pricelistid = rs.fields("defaultpriceListId")
				customerseq = rs.Fields("customerSequenceNumber")
				
				session("priceList") = pricelistid
				session("customersequencenumber") = customerseq
			end if
			
			set invoice = Server.CreateObject("ShahCorpComponents.invoice")
			invoice.DBConnectionString = Session("shahcorpDSN")
	
			invoice.isAdd = true
			invoice.amountPaid = 0
			invoice.counterSaleOnly = true
			invoice.custSeqNumber = customerseq
			invoice.starchPref = ""
			invoice.finishPref = ""
			invoice.multiPickUpCustName	= ""
			invoice.multiPickUpLoc = ""
			invoice.loadCustomerPreferences customerseq, ""
			invoice.priceListId = pricelistid
			invoice.setStoreDays storeid
		end if
		
		set createInvoice = invoice
	end function
	
	function assignCard(cardnumber, customerseq)
		dim query, rs
		
		if cardnumber = "" or customerseq = "" then exit function
		
		query = " update giftcard set customersequencenumber = " & customerseq
		query = query & " where giftcardnumber = '" & dbstr(cardnumber) & "'"

		qryexecute query
	
	end function
	
	function getGiftCardProgramId(storeid)
		dim query, rs
		
		query = " select giftprogramid from giftprogram where storeid = " & storeid
		set rs = getdisconnectedrecordset(query)
		
		getGiftCardProgramId = 0
		
		if rs.recordcount > 0 then
			getGiftCardProgramId = rs("giftprogramid")
		end if
		
		set rs = nothing
	end function
	
	

	
	function createNewCard(giftprogramid, cardnumber, customerSeq)
		dim query, rs

		query = " select 1 from giftcard where giftcardnumber = '" & dbstr(cardnumber) & "'"
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			set rs = nothing
			exit function
		end if
		
		query = " INSERT INTO giftcard(giftprogramid, giftcardnumber, customersequencenumber, giftValue, effectivedate, expirationdate, lastUsedDate) "
		query = query & " SELECT giftprogramid, '" & dbstr(cardnumber) & "', " & DbCreateQryNumeric(customerSeq) & ", 0, getdate(), dateadd(day, validdays, getdate()), getdate() "
		query = query & " FROM giftprogram WHERE giftprogramid = " & giftprogramid

		qryexecute query
	end function
	
%>

<HTML>
<HEAD>
<TITLE>Gift Cards</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript" src="/script/webui.js"></script>

<script language="javascript" type="text/javascript">

	var previousElement=null;
	var timer = null;
	var selectedCardNumber = null;
	
	function cbs_customer_search(dest) {
	    document.giftcard.action = "/mainapp/customersearch.asp?targetpage=search&dest=" + encodeURIComponent(dest);
	    document.giftcard.submit();
	}


	function resetTimeout() {
		if(timer != null) {
			clearTimeout(timer);
		}

		timer = setTimeout("doUpdate();", 200);
	}
	function cancelTimeout() {
		clearTimeout(timer);
		timer = null;
	}	

	
	function exit() {
		<% if customerseq <> "" then %>
            document.giftcard.action = "/mainapp/customerfunctions.asp?customerseq=<%=customerseq%>";
            document.giftcard.submit();
		<% else %>
			document.giftcard.action = "/mainapp/managermenu.asp";
            document.giftcard.submit();
		<% end if %>
	}

	function updateSearch() {
		var text;
		
		text = searchField.value;
		
		if(event.keyCode == 13) {
			if(text.length > 0) {
			    cbs_confirm("Show all gift cards?", showAll);
			}
		} else if(text.length > 2) {
			resetTimeout();
		}
		else {
				clearResults();
		}
	}

	function showAll() {
        clearConfirmMsg();
        cancelTimeout();
        doUpdate();
	}
	
	function clearResults() {
		$("#searchResults").empty();
		$("#searchResults").append("<H3>No Results</H3>");
	}
	
	function showWaiting() {
		$('#searchResults').empty();
		$('#searchResults').append('<DIV style="margin-top: 30px; text-align: center"><IMG src="/static/images/spinner.gif" /></DIV>');
	}
	
	function doUpdate() {
		var text;
		var customerSeq;
		
		text = searchField.value;
		customerSeq = document.giftcard.customerseq.value;
		
		previousElement = null;
	
		showWaiting();
	
		$("#searchResults").load("giftcardresults.asp", {searchText: text, customerSeq: customerSeq}, function() {
			selectRowByCardNumber(text);
		});
	}
	
	function selectRowByCardNumber(cardnumber) {
		$("tr[cardnumber='" + cardnumber + "']").each(function() {
			selectRow(this);
		});
		
	}
	
	function selectRow(element) {
		if (previousElement != null){
			previousElement.className= "";
		}
		previousElement = element;
		element.className = "selected";
		selectedCardNumber = element.getAttribute("cardnumber");
	}
	
	function cancelNewCard() {
		searchField.value = "";
	}
	
	function createNewCard() {
		cbs_prompt("Scan card again to verify number.", handleCreateNewCard);
	}

	function handleCreateNewCard() {
        clearPromptMsg();
        var verifyNumber = document.getElementById('inputTxtLine').value
		var text = searchField.value;

		if(verifyNumber == text) {
			document.giftcard.action = "?useraction=newcard&cardnumber=" + encodeURIComponent(text);
			document.giftcard.submit();
		}
		else if (verifyNumber) {
			cbs_alert("Card numbers do not match.");
		}
	}
	
	
	function focusSearchField() {
		searchField.select();
		searchField.focus();
	}


	function assignCard() {
		if(selectedCardNumber == null) {
			cbs_alert("Select a card to assign.");	
		}
		else {
			cbs_customer_search("/mainapp/giftcards.asp?useraction=assign&cardnumber=" + encodeURIComponent(selectedCardNumber) + "&customerseq=");
		}
	}

	
	function purchaseValue() {
		var amount;
		
		if(selectedCardNumber == null)
			cbs_alert("Select a card to purchase value.");
		else
			cbs_prompt("How much value do you wish you purchase?", handlePurchaseAmt, "", false, true);
	}

	function handlePurchaseAmt() {
        clearPromptMsg();
        var amount = document.getElementById('inputTxtLine').value
			if(amount != null) {
				document.giftcard.action = "?useraction=purchasevalue&cardnumber=" + encodeURIComponent(selectedCardNumber) + "&amount=" + encodeURIComponent(amount);
				document.giftcard.submit();
			}
	}

	function assignValue() {
		var amount;
		if(selectedCardNumber == null)
			cbs_alert("Select a card to purchase value.");
		else
			cbs_prompt("How much value do you wish you purchase?", handleAssignAmt, "", false, true);
	}

	function handleAssignAmt() {
        clearPromptMsg();
	    var amount  = document.getElementById('inputTxtLine').value;
			if(amount != null) {
				document.giftcard.action = "?useraction=assignvalue&cardnumber=" + encodeURIComponent(selectedCardNumber) + "&amount=" + encodeURIComponent(amount);
				document.giftcard.submit();
			}
	}

</SCRIPT>








</HEAD>
<BODY topmargin=0 leftmargin=0 onload="focusSearchField();doUpdate();">
<!-- #include file="../include/banner.inc" -->

<H1>Gift Cards</H1>

<FORM id="giftcard" name="giftcard" action="" method="post">
	<INPUT type="hidden" name="customerseq" value="<%=customerseq%>">
	
</FORM>

<TABLE align="center">
	<TR>
		<TD>
			Gift Card Number<BR />
			<INPUT type="password" name="searchField" id="searchField" style="font-size:20" onkeyup="updateSearch()" value="<%=cardnumber%>" />
		</TD>
	</TR>

</TABLE>
<BR />

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
	<% if customerseq = "" then %>
		<BUTTON onclick="assignValue()">Assign<BR>Value</BUTTON>
	<% end if %>
		<BUTTON onclick="purchaseValue()">Purchase<BR>Value</BUTTON>
		<BUTTON onclick="assignCard()">Assign<BR>Card</BUTTON>
	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<DIV id="searchResults" style="height:550px;overflow-y:scroll;background:white" >
	
</DIV>

</BODY>
</HTML>

