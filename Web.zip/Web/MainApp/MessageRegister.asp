<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<%
    dim finished
    dim message
    dim username
    
    finished = false
    message = ""
    
    username = request.form("username")
    
    select case lcase(request.querystring("useraction"))
        case "register"
            registerAccount
        
        
        
    end select
    
    function isAccountPresent(username)
        dim query, rs
        
        query = "select count(*) as accountcnt from messageaccount where username = '" & username & "'"
        
        set rs = getdisconnectedrecordset(query)
        
        isAccountPresent = rs("accountcnt") > 0
        
        set rs = nothing
    end function
    
    sub registerAccount()
        dim query, rs
        dim username
        
        username = request.form("username")
        
        if isAccountPresent(username) then
            message = "Account name already exists."
        else
            query = " insert into messageaccount(username) "
            query = query & " values ('" & username & "')"
            qryexecute query
            
            message = "Now registered as: " & username
            finished = true
        end if
    
    end sub
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<SCRIPT language="javascript" type="text/javascript">
    function submitUsername() {
        document.messageregister.action = "?useraction=register"
        document.messageregister.submit();
    }

	function updateOpener() {
		window.opener.updateMessageID('<%=username%>');
	}
	
	function CaptureKey(){

		if (event.keyCode == 13){
			submitUsername();
		}
	}
	
</SCRIPT>


</HEAD>

<BODY STYLE="margin:0;padding:0" <%if finished then%>onload="updateOpener();window.close();"<%else%>onload="document.messageregister.username.focus()"<%end if%>>

<FORM id="messageregister" name="messageregister" method="post" style="margin:0;padding:0;" action="javascript:;">

<BR><BR><BR><BR>

<TABLE align="center">
    <TR>
        <TD colspan="2" align="center"><%=message%></TD>
    </TR>
    

    <TR>
        <TD>Username</TD>
        <TD><INPUT name="username" onkeyup="CaptureKey()"></TD>
    </TR>
    
    <TR>
        <TD colspan="2" align="center"><INPUT type="button" value="Ok" onclick="submitUsername();"  >
        <INPUT type="button" value="Close" onclick="window.close()"></TD>
    </TR>

<TABLE>

</FORM>
</BODY>
</HTML>
