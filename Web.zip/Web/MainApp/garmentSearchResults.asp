<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	searchItems()
%>

<HTML>
<HEAD>
<TITLE>Garment Search Results</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	var previousElement=null;
	var checkedRow = null;
	
	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.style.background="white";
		}
		childEl = element.children[0];
		var rowChildNodes = childEl.children
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if(childEl.tagName == "INPUT") {
				childEl.checked=true;
				checkedRow = childEl;
				break;
			}
		}
		previousElement = element;
		element.style.background="#DBF2F4";
	}

	function cancelForm() {
        document.garmentSearchResults.action = "garmentsearch1.asp"
		document.garmentSearchResults.submit();
	}
	
	
	function submitForm(){
	    if (checkedRow != null){
			var stemp = checkedRow.value;
			var sTicket = stemp.substring(0, stemp.indexOf(";"));
			var spickup = stemp.substring(stemp.indexOf(";")+1)
			document.garmentSearchResults.action = "Detailedinvoice.asp?userAction=edit&originPage=garmentsearch&Ticketnumber=" +
			    sTicket + "&multiplePickup=" + spickup;
			document.garmentSearchResults.submit();
		}
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Garment Search Results</H1>
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLPADDING=1 >
		<FORM id="garmentSearchResults" name="garmentSearchResults" action="" method="post">
			<tr height=20px></td></td></tr>
			<!-- header row -->
			<tr>
				<td align=center>
					<TABLE WIDTH="950px" BORDER=0 CELLSPACING=1 CELLPADDING=5>
						<!-- heading -->
						<tr>
							<th width=25px></th>
							<th width =120px align=left class="label">Invoice Number</th>
							<th width =200px align=left class="label">Customer Name</th>
							<th width =100px align=left class="label">Invoice Total</th>
							<th width =150px align=left class="label">Date Created</th>
							<th width =150px align=left class="label">Racked Date</th>
							<th width =150px align=left class="label">Rack Location</th>
							<th width=16px></th>
						</tr>
					</table>
				</td>
			</tr>
			<!-- list -->
			<tr>
				<td align=center>
					<DIV STYLE="overflow-y:auto;height:300px; overflow-x:auto; width=950px">
							<TABLE WIDTH="100%" style="border-color:#2F4F4F;border-style:solid;background-color:white;" BORDER=1 CELLSPACING=0>
								<tr rowspan =5>
									<td>
										<TABLE WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=3>
										<!-- to be removed while coding -->	
											<% dim l_multiplePickup
											if isObject(rstSearchresult) then 
												if rstSearchresult.recordcount > 0 then
												rstSearchresult.movefirst
												while not rstSearchresult.eof 
													if rstSearchresult("multiplepickup") = true then
														l_multiplePickup = 1
													else
														l_multiplePickup = 0
													end if
										%>
											<tr onClick="selectRow(this)">
												<td width=25px><input type="radio" name="select" id="select" STYLE="height : 25px; width : 25px;"
												value="<%=rstSearchresult("Ticketnumber")& ";" & l_multiplePickup%>">
												
												</td>
												<td width = 120px  STYLE="FONT-SIZE: 12px;"><%=rstSearchresult("Invoicenumber")%></td>
												<td width = 200px  STYLE="FONT-SIZE: 12px;"><%=rstSearchresult("Customername")%></td>
												<td width = 100px  STYLE="FONT-SIZE: 12px;"><%=rstSearchresult("invoicetotal")%></td>
												<td width = 150px  STYLE="FONT-SIZE: 12px;"><%=rstSearchresult("createddate")%></td>
												<td width = 150px  STYLE="FONT-SIZE: 12px;"><%=rstSearchresult("rackeddate")%></td>
												<td width = 150px  STYLE="FONT-SIZE: 12px;"><%=rstSearchresult("racklocation")%></td>
											</tr>
										<%
												rstSearchresult.movenext
												wend
												rstSearchresult.close
												set rstSearchresult = nothing
												end if
											end if
										%>
											<tr height =50px><td></td></tr>
											<tr height=50px><td></td></tr>	
											<tr height =50px><td></td></tr>
											<tr height=50px><td></td></tr>
											<tr height =50px><td></td></tr>
											<tr height=50px><td></td></tr>
											<!-- till here -->	
										</table>
									</td>
								</tr>
						</table> <!-- table for border -->
					</div>
				</td>
			</tr>
			<!-- buttons -->
			<tr>
				<td align=center>
					<TABLE WIDTH="680px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
						<tr height=10px></tr>
						<tr>
							<td width=80%></td>
							<td>
								<INPUT align=center class=touchnoborder id=select name=select type=button value="" style="background-image:url(../images/Ok.gif)" onclick="submitForm()">
							</td>
							<td>
								<INPUT align=center class=touchnoborder id=cancel name=cancel style="background-image:url(../images/cancel.gif)"type=button value="" onclick="cancelForm()">
							</td>
						</tr>
					</table>
				</td>
			<tr>
		</form>
	</table>
</BODY>
</HTML>
<% 
		dim invoice
		dim rstLineItems
		dim sqltxt
		
	sub searchItems()

		set invoice = Session("gsinvoice")
		if isobject(invoice) then
			set rstLineItems = invoice.lineitems
			if rstLineItems.recordcount  >0 then
				createsearchquery()
				'rstlineitems.close
				set rstlineitems  = nothing
			end if
			
		end if
		set invoice = nothing
	end sub
	
	dim l_pricelistid
	dim it_itemid
	dim co_itemid
	dim pa_itemid
	dim up_itemid
	dim it_qty
	dim it_list
	dim up_list
	dim co_list
	dim pa_list
	dim qty_list
	
	dim rstClone
	dim rstSearchResult
	
	sub createSearchQuery()
	 l_pricelistid = invoice.priceListId
	 rstlineitems.movefirst
	
	set rstClone = 	rstlineitems.clone
	 while not rstlineitems.eof 
		select case rstLineitems.fields("itemtype")
			case "IT"
			
				it_itemid = rstLineitems.fields("lineitemid")
				it_qty = rstLineitems.fields("quantity")
			
				rstClone.filter = 	"parentLineNumber=" & rstLineitems.Fields("lineNumber")
				co_itemid = "%"
				pa_itemid = "%"
				up_itemid = "%"
				if rstClone.Recordcount > 0 then
					rstClone.MoveFirst
					
					while not rstClone.Eof
						select case rstClone.fields("itemtype")
						case "CO"
							CO_itemid = rstClone.fields("itemname") + co_itemid
						case "PA"
							PA_itemid = rstClone.fields("itemname")+ pa_itemid
						case "UP"
							UP_itemid = rstClone.fields("itemname")+ up_itemid
						end select
					rstClone.MoveNext																
					wend
					end if
				rstClone.Filter = 0	
				if len(trim(it_list) ) > 0 then
					it_list = it_list   & ", " & it_itemid
					Co_list = Co_list   & ", " & co_itemid
					up_list = up_list   & ", " & up_itemid
					pa_list = pa_list   & ", " & pa_itemid
					Qty_list = Qty_list & ", " & it_qty
				else
					it_list =  it_itemid
					Co_list =  co_itemid
					up_list =   up_itemid
					pa_list =  pa_itemid
					Qty_list =  it_qty
				end if
		end select
		rstLineitems.movenext
	 wend
	 

	 
	 sqltxt = "exec dbo.garmentSearch " _
				& dbcreateqrystring(session("storeid")) _
				& ","  & dbcreateqrystring(session("ticketStatus"))_
				& ","  & dbcreateqrystring(l_Pricelistid)_
				& ","  & dbcreateqrystring(it_list)_
				& ","  & dbcreateqrystring(co_list)_
				& ","  & dbcreateqrystring(pa_list)_
				& ","  & dbcreateqrystring(up_list)_
				& ","  & dbcreateqrystring(Qty_list)

		set rstSearchresult = getdisconnectedrecordset(sqltxt)
	
	end sub
%>