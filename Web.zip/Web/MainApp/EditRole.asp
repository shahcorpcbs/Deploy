<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!-- #include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim query
	dim rs

%>
<HTML>
<HEAD>
<TITLE>Employee Role Setup</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>
<script language="javascript" type="text/javascript">

</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Employee Role Setup</H1>
<FORM id="editrole" name="editrole"  Method = "post">

<table>
<%
    query = "select * from employeetag"
    set rs = getdisconnectedrecordset(query)
    
    while not(rs.eof or rs.bof)
%>
    <tr>
        <td>
            <%=rs("name")%>
        </td>
    </tr>        
<%
        rs.movenext
    wend
    
    set rs = nothing
%>
</table>

</FORM>
</BODY>
</HTML>
