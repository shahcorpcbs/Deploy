<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim departmentFilter
	dim priceListFilter

	departmentFilter = getReqVar("departmentFilter")
	priceListFilter = getReqVar("priceListFilter")


	select case lcase(request.querystring("useraction"))

	end select


	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	
	function get_avg_price(pricelistitemid, base_price, result)
		dim query, rs
		
		query = " select avg(ticketlineitem.lineitemtotal + totalupchargeamount) as avg_price "
		query = query & " from ticketlineitem "
		query = query & " where ticketlinetype = 'IT' and lineitemid = " & pricelistitemid
		
		set rs = getdisconnectedrecordset(query)
		
		result = base_price
		
		if rs.recordcount > 0 then
			if rs("avg_price") then
				result = rs("avg_price")
			end if
		end if
	
	end function
	
	
	function get_upcharges(pricelistitemid)
		dim query, rs
		dim result
		
		query = " select descriptorname, descriptortype, price "
		query = query & " from itemdescriptorprice "
		query = query & " where disabled = 0 "
		query = query & " and price <> 0 "
		query = query & " and pricelistitemid = " & pricelistitemid
		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
			if result <> "" then result = result & ", "
			if rs("price") >= 0 then
				result = result & rs("descriptorname") & " +" & formatnumber(rs("price"), 2)
			else
				result = result & rs("descriptorname") & " -" & formatnumber(rs("price"), 2)
			end if
		
			rs.movenext
		wend
		
		set rs = nothing
		
		get_upcharges = result
	
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">


<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<script language="javascript" type="text/javascript">

	function updateFilter() {
		document.priceAdjustmentParams.action = '?useraction=updatefilter';
		document.priceAdjustmentParams.submit();
	}

	function printPriceList() {
		var html;
		var pricelist_el = document.getElementById("pricelist");
		
		if(pricelist_el) {
			var pricelist_window = window.open('','','width=300,height=300');
			pricelist_window.document.open("text/html");
			pricelist_window.document.write(pricelist_el.innerHTML);
			pricelist_window.document.close();
			pricelist_window.print();
			pricelist_window.close();
		}
	}
	
	function exit() {
	    document.priceAdjustmentParams.action = "/mainapp/toolsMenu.asp"
        document.priceAdjustmentParams.submit();
	}
</script>



</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->

<CENTER>

<BR>

<FORM name="priceAdjustmentParams" ID="priceAdjustmentParams" METHOD=POST  style="margin:0;padding:0"> 


<SELECT name="priceListFilter" onchange="updateFilter()">
	<OPTION value="">All Price Lists</OPTION>
<%
	query = " select name, pricelistid from pricelist "
	set rs = getdisconnectedrecordset(query)

	while not(rs.eof or rs.bof)
%>
	<OPTION value="<%=rs("pricelistid")%>" <%if trim(priceListFilter) = trim(rs("pricelistid")) then%>selected<%end if%>><%=server.htmlencode(rs("name"))%></OPTION>
<%
		rs.movenext
	wend
	set rs = nothing
%>
</SELECT>


<SELECT name="departmentFilter" onchange="updateFilter()">
	<OPTION value="">All Departments</OPTION>
<%
	query = " select pricelist.name + ' - ' + department.name as [name], department.departmentid from department "
	query = query & " inner join pricelist on department.pricelistid = pricelist.pricelistid "

	if priceListFilter <> "" then
		query = query & " where department.pricelistid = " & priceListFilter
	end if

	set rs = getdisconnectedrecordset(query)

	while not(rs.eof or rs.bof)
%>
	<OPTION value="<%=rs("departmentid")%>" <%if trim(departmentFilter) = trim(rs("departmentid")) then%>selected<%end if%>><%=server.htmlencode(rs("name"))%></OPTION>
<%
		rs.movenext
	wend
	set rs = nothing
%>
</SELECT>

</FORM>





<%
	query = " select pricelistitem.pricelistitemid, pricelistitem.itemname, pricelistitem.price, department.name as departmentname, "
	query = query & " pricelist.name as pricelistname, department.departmentid, pricelist.pricelistid "
	query = query & " from pricelistitem "
	query = query & " inner join department on pricelistitem.departmentid = department.departmentid "
	query = query & " inner join pricelist on department.pricelistid = pricelist.pricelistid "



	if departmentFilter <> "" then
		query = query & " where department.departmentid = " & departmentFilter
	elseif priceListFilter <> "" then
		query = query & " where pricelist.pricelistid = " & priceListFilter
	end if
	
	query = query & " and pricelistitem.disabled = 0 "

	query = query & " order by pricelist.pricelistid, department.departmentid, pricelistitem.displaysequence, pricelistitem.itemname"


	set rs = getdisconnectedrecordset(query)
%>

</CENTER>
<BR>


<DIV class="cmdbar" style="margin-bottom:1" id="commandButtons">
		<SPAN style="float:left">
			<BUTTON onclick="printPriceList()" >Print</BUTTON>
		</SPAN>

		<SPAN style="float:right">
			<BUTTON onclick="exit()" >Exit</BUTTON>
		</SPAN>
</DIV>	

<FORM name="priceAdjustment" ID="priceAdjustment" METHOD=POST  style="margin:0;padding:0"> 

<DIV id="pricelist">

<TABLE border="0" cellspacing="0" cellpadding="5" width="100%">
<%

	dim cur_pl
	dim prev_pl

	
	while not(rs.eof or rs.bof)
		cur_pl = rs("pricelistid") & "-" & rs("departmentid")
		if cur_pl <> prev_pl then
%>

	<TR>
		<TD colspan="2">&nbsp;</TD>
	</TR>
	
	<TR style="background:#ddd;" >
		<TH colspan="3" align="center" style="border-top: 2px groove;border-bottom: 2px groove;"><%=server.htmlencode(rs("pricelistname"))%> - <%=server.htmlencode(rs("departmentname"))%></TD>
	</TR>
	<TR style="background:#ddd" >
		<TH style="border-bottom: 2px groove;border-right: 2px groove;font-size:14;">Garment</TH>
		<TH style="border-bottom: 2px groove;font-size:14;" align="center">Additional Charges</TH>
	</TR>
<%
		end if

%>


	<TR>
		<TD style="font-size: 13;font-weight: bold"><%=server.htmlencode(rs("itemname"))%> - <%=formatcurrency(rs("price"))%></TD>
		<TD align="center" style="font-size: 10"><%=get_upcharges(rs("pricelistitemid"))%></TD>
	</TR>

<%
		
		prev_pl = cur_pl
		rs.movenext
	wend
	
	set rs = nothing
%>
</TABLE>
</DIV>

</FORM>
</BODY>
</HTML>
