<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim l_storeid
	dim isSubmitted 
	
	l_storeid = Session("storeid")
	isSubmitted = Request.QueryString("submitted")
	
	if isSubmitted then
		UpdateDatabase()
		Response.Redirect ("employeeManagement.asp")
	end if
	
	getFunctionList()
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>SetUp</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function setsecuritylevel(element){
	var x, i
		if ( document.applicationsecurity.chkFunctionId.length > 0) 
		{	i = 0;
			while (i < document.applicationsecurity.chkFunctionId.length){
				if (document.applicationsecurity.chkFunctionId(i).checked){
					document.applicationsecurity.h_securitylevel(i).value = element.name;
					document.all("appFunction").rows[i +1].cells(2).innerText = element.name;
				}
				i++;
			}
		
		}
	
	
	}
	function submitForm() {
	var x, i;
		if ( document.applicationsecurity.chkFunctionId.length > 0) {
			i = 0;
			while (i < document.applicationsecurity.chkFunctionId.length){
				document.applicationsecurity.chkFunctionId(i).checked = true;
				i++;
			}
				document.applicationsecurity.action = "?Submitted=true";
				document.applicationsecurity.submit();
		}
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->
<B class="pageHeading">&nbsp;Application Security</B>
<FORM id="applicationsecurity" name="applicationsecurity" action="MainSetup.asp" Method = "post">
<TABLE WIDTH= 100%  BORDER=0 CELLSPACING=0 CELLPADDING=0 ><!-- header row -->
 <tr >
	<td align = center valign=top>	
	<TABLE width = 550px border="0" cellpadding="7" cellspacing="0" Style = "MARGIN-LEFT: 5px">
	<tr><td width = 90% align=left valign=top><B><FONT Color = red>NOTE: 0 is lowest and 9 is highest</font><B>
		<DIV STYLE="HEIGHT: 450px; OVERFLOW-X: auto; OVERFLOW-Y: auto; WIDTH: 450px" >
			<TABLE id = "appFunction" name = "appFunction" width = 100% style="BACKGROUND-COLOR: white; BORDER-BOTTOM-COLOR: #2f4f4f; BORDER-LEFT-COLOR: #2f4f4f; BORDER-RIGHT-COLOR: #2f4f4f; BORDER-TOP-COLOR: #2f4f4f" BORDER =2 CELLSPACING=0>
			<tr class=head><td width = 5></td>
				<td width = 330><B>Application Function Name</td>
				<td width = 80 align = middle><B>Security Level</td>
			</tr>
			<% if rstlist.recordcount > 0 then
				while not rstlist.eof %>
				<tr class=data ><td >
					<INPUT type = checkbox style="height:28px;width:28px"name=chkFunctionId value= "<%=rstlist("Functionid")%>"><INPUT type = hidden name=h_securitylevel value= "<%=rstlist("securitylevel")%>"> 
				</td>
				<td align=left><b><%=rstlist("Name")%></B></td>
				<td align = middle>
					<%=rstlist("securitylevel")%></td>
				</tr>
			<% 
				rstlist.movenext
				wend
				rstlist.close
				set rstlist = nothing	
				end if %>
			</table>
		</DIV>
	</TD>
	<td align= left vAlign=top width = 20%>
	<TABLE  width = 120px border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td >
		<!--<INPUT class = touch  type=button name="0" style="background-image=url(../images/0.gif)" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 5px"><br>&nbsp;&nbsp;&nbsp;&nbsp;0<br></td>-->
		<BUTTON class=std name="0" onClick="setsecuritylevel(this)"><img src="../images/0.gif"></button>
		</td><td>
		<!--<INPUT class = touch  type=button name="1" style="background-image=url(../images/1.gif)" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 20px"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1<br>-->
		<BUTTON class=std name="1" onClick="setsecuritylevel(this)"><img src="../images/1.gif"></button>
		</td></tr>
		<tr><td>
		<!--<INPUT class = touch  type=button name="2" style="background-image=url(../images/2.gif)" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 5px"><Br>&nbsp;&nbsp;&nbsp;&nbsp;2<br></td>-->
		<BUTTON class=std name="2" onClick="setsecuritylevel(this)"><img src="../images/2.gif"></button>
		</td><td>
		<!--<INPUT class = touch  type=button name="3" style="background-image=url(../images/3.gif)" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 20px"><Br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3<bR>-->
		<BUTTON class=std name="3" onClick="setsecuritylevel(this)"><img src="../images/3.gif"></button>
		</td></tr>
	<tr><td>
		<!--<INPUT class = touch  type=button name="4" style="background-image=url(../images/4.gif)" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 5px"><Br>&nbsp;&nbsp;&nbsp;&nbsp;4<br></td>-->
		<BUTTON class=std name="4" onClick="setsecuritylevel(this)"><img src="../images/4.gif"></button>
		</td><td>
		<!--<INPUT class = touch  type=button name="5" style="background-image=url(../images/5.gif)" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 20px"><Br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5<br>-->
		<BUTTON class=std name="5" onClick="setsecuritylevel(this)"><img src="../images/5.gif"></button>
		</td></tr>
	<tr><td  >
		<!--<INPUT class = touch  type=button name="6" style="background-image=url(../images/6.gif)" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 5px"><Br>&nbsp;&nbsp;&nbsp;&nbsp;6<br></td>-->
		<BUTTON class=std name="6" onClick="setsecuritylevel(this)"><img src="../images/6.gif"></button>
		</td><td>
		<!--<INPUT class = touch  type=button name="7" style="background-image=url(../images/7.gif)" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 20px"><Br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7<br>-->
		<BUTTON class=std name="7" onClick="setsecuritylevel(this)"><img src="../images/7.gif"></button>
		</td></tr>
	<tr><td  >
		<!--<INPUT class = touch  type=button name="8" style="background-image=url(../images/8.gif)" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 5px"><Br>&nbsp;&nbsp;&nbsp;&nbsp;8<br></td>-->
		<BUTTON class=std name="8" onClick="setsecuritylevel(this)"><img src="../images/8.gif"></button>
		</td><td>
		<!--<INPUT class = touch  type=button	name="9" style="background-image=url(../images/9.gif)" onClick="setsecuritylevel(this)"  style="HEIGHT: 30px; WIDTH:30px;Margin-left= 20px"><Br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;9<br>-->
		<BUTTON class=std name="9" onClick="setsecuritylevel(this)"><img src="../images/9.gif"></button>
		</td></tr>
	</table> 
	</td></tr>
	</TABLE>
	<table width = 120px >
	<tr>
	<td align = center><br> 
		<INPUT class = touchnoborder name=OK type=button value="" style="background-image:url(../images/ok.gif)" onClick="submitForm()" >&nbsp&nbsp&nbsp&nbsp&nbsp
		<INPUT class = touchnoborder name=Cancel type=button value="" style="background-image:url(../images/cancel.gif)" onClick="history.back(-1)" >
	</td></tr>
	</table>
	</td></tr>
	</TABLE></FORM>
</BODY>
</HTML>
<%
	dim rstList
	Function getFunctionlist()
	dim sqltxt
		sqltxt = "select functionid, name,securitylevel = isnull(securitylevel, 0) from applicationfunctiondomain " 'order by name "
		set rstList = getdisconnectedrecordset(sqltxt)
	end function
	
	Function UpdateDatabase()
	dim sqltxt
	dim totalcount
	dim i 
	totalcount = 0
	totalcount = Request.Form("chkFunctionid").count
	dbstartTrans()
	for i = 1 to totalcount 
		 sqltxt = "update applicationfunctiondomain set securitylevel = " & Request.Form("h_securitylevel")(i) _
					& " where functionid = " & Request.Form("chkfunctionid")(i)
		qryexecutewithtrans(sqltxt)
	next 
	 dbendtrans()
	end function
	


%>

