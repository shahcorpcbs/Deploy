<%@ Language=VBScript %>
<% Option Explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!-- #include file="../include/security.asp" -->
<!-- #include file="../external/include.asp" -->
<%

	include getBarcodeEncoderFilename()
	Function getBarcodeEncoderFilename()
		On Error Resume Next
		getBarcodeEncoderFilename = "/include/barcode.asp"
		getBarcodeEncoderFilename = getMSVar("BarcodeEncoderFile")
	End Function
%>

<%
	Dim rstInvoice
	
    If Request.Form("customerName") <> "" Or Request.Form("invoiceNumber") <> "" Or Request.Form("dateType") <> "" Or Request.Form("paymentAmount") <> "" Then
        Set rstInvoice = loadData
    End If

    Function loadData()
        Dim query
        Dim customerName
        Dim invoiceNumber
        Dim dateType
        Dim fromDate
        Dim toDate
        Dim paymentAmount
        
        Dim customerNameCondition
        Dim invoiceNumberCondition
        Dim dateCondition
        Dim paymentAmountCondition

        customerName = Request.Form("customerName")
        invoiceNumber = Request.Form("invoiceNumber")
        dateType = Request.Form("dateType")
        fromDate = Request.Form("fromDate")
        toDate = Request.Form("toDate")
        paymentAmount = Request.Form("paymentAmount")

        If customerName <> "" Then
            customerNameCondition = "WHERE c.LastName LIKE '" & customerName & "%' "
        Else
            customerNameCondition = ""
        End If

        If invoiceNumber <> "" Then
            invoiceNumberCondition = "AND RTRIM(t.invoiceNumber) = " & invoiceNumber & " "
        Else
            invoiceNumberCondition = ""
        End If

        If paymentAmount <> "" Then
            paymentAmountCondition = "AND t.amountPaid = " & paymentAmount & " "
        Else
            paymentAmountCondition = ""
        End If

        Select Case dateType
            Case "Yesterday"
                dateCondition = "AND CAST(p.paymentdate AS DATE) = CAST(CURRENT_TIMESTAMP - 1 AS DATE) "
            Case "Last 7 days"
                dateCondition = "AND CAST(p.paymentdate AS DATE) > CAST(CURRENT_TIMESTAMP - 7 AS DATE) "
            Case "Current Month"
                dateCondition = "AND CONVERT(CHAR(4), CAST(paymentdate AS DATE), 100) = CONVERT(CHAR(4), CAST(current_timestamp AS DATE), 100) AND CONVERT(CHAR(4), CAST(paymentdate AS DATE), 120) = CONVERT(CHAR(4), CAST(current_timestamp AS DATE), 120) "
            Case "Date Range"
                dateCondition = "AND CAST(p.paymentdate AS DATE) BETWEEN CAST ('" & fromDate & "' AS DATE ) AND CAST ('" & toDate & "' AS DATE) "
            Case Else
                dateCondition = ""
        End Select

        query = "SELECT TOP 50 i.invoiceNumber, i.ticketNumber, i.paymentNumber, i.customerName, i.department, i.paymentDate, i.amountPaid, i.ticketStatus FROM ( " _
            & "SELECT DISTINCT TOP 50 t.invoiceNumber, " _
	        & "t.ticketNumber, " _
            & "NULL AS paymentNumber, " _
    	    & "c.customerName, " _
    	    & "dbo.pivotTicketDepartments(t.ticketnumber, ',') AS department, " _
            & "MAX(p.paymentDate) AS paymentDate, " _
    	    & "pm.amountPaid, " _
	        & "CASE WHEN t.ticketstatus = 'AC' THEN 'Active' WHEN t.ticketstatus = 'FI' THEN 'Finished' END AS ticketStatus " _
            & "FROM dbo.Customer c " _
            & "JOIN dbo.Ticket t " _
            & "ON c.customerSequenceNumber = t.customerSequenceNumber " _
            & "AND t.amountPaid > 0 " _
            & "AND t.ticketStatus in ( 'AC' ,'FI') " _
            & invoiceNumberCondition _
            & "JOIN (SELECT t2.ticketNumber, CASE WHEN t2.ticketStatus = 'AC' THEN t2.amountPaid WHEN t2.ticketStatus = 'FI' THEN t2.amountPaid - SUM(ISNULL(rpt.Amount, 0)) END AS amountPaid FROM dbo.Ticket t2 LEFT JOIN dbo.ReversePaymentTracking rpt ON t2.ticketNumber = rpt.TicketID GROUP BY t2.ticketNumber, t2.ticketStatus, t2.amountPaid) AS pm " _
            & "ON t.ticketNumber = pm.ticketNumber " _
            & "AND pm.amountPaid > 0 " _
            & "JOIN dbo.Payment p " _
            & "ON t.customerSequenceNumber = p.customerSequenceNumber " _
            & "AND p.amountPaid > 0 " _
            & "AND NOT EXISTS(SELECT NULL FROM dbo.ReversePaymentTracking rpt WHERE rpt.PaymentID = p.paymentNumber AND rpt.Amount IS NULL) " _
            & "AND (CAST (p.paymentdate AS DATE) < CAST (CURRENT_TIMESTAMP AS DATE) OR p.paymentnumber IN (SELECT sourceRefNumber FROM paymenttracking GROUP BY sourcerefnumber HAVING COUNT(*) = 1 )) " _
            & dateCondition _
            & paymentAmountCondition _
            & "JOIN dbo.PaymentTracking pt " _
            & "ON p.paymentNumber = pt.sourceRefNumber " _
            & "AND t.ticketNumber = pt.targetRefNumber " _
            & customerNameCondition _
            & "GROUP BY t.invoiceNumber, " _
            & "t.ticketNumber, " _
		    & "c.customerName, " _
		    & "pm.amountPaid, " _
		    & "t.ticketStatus " _
            & "ORDER BY paymentDate DESC"

            If invoiceNumberCondition = "" Then

                If paymentAmount <> "" Then
                    paymentAmountCondition = "AND p.amountPaid = " & paymentAmount & " "
                Else
                    paymentAmountCondition = ""
                End If

                query = query & " UNION " _

                & "SELECT TOP 50 'ON ACCOUNT' AS invoiceNumber, " _
                & "NULL AS ticketNumber, " _
                & "p.paymentNumber, " _
                & "c.customerName, " _
                & "NULL AS department, " _
                & "p.paymentDate, " _
                & "pm.amountPaid, " _
                & "NULL AS ticketStatus " _
                & "FROM dbo.Customer c " _
                & "JOIN dbo.Payment p " _
                & "ON c.customerSequenceNumber = p.customerSequenceNumber " _
                & "AND p.amountPaid > 0 " _
                & "AND NOT EXISTS(SELECT NULL FROM dbo.ReversePaymentTracking rpt WHERE rpt.PaymentID = p.paymentNumber AND rpt.Amount IS NULL) " _
                & "AND (CAST (p.paymentdate AS DATE) < CAST (CURRENT_TIMESTAMP AS DATE) OR p.paymentnumber IN (SELECT sourceRefNumber FROM paymentTracking GROUP BY sourceRefNumber HAVING COUNT(*) = 1 )) " _
                & dateCondition _
                & paymentAmountCondition _
                & "JOIN (SELECT p2.paymentNumber, p2.amountPaid - SUM(ISNULL(rpt.Amount, 0)) AS amountPaid FROM dbo.Payment p2 LEFT JOIN dbo.ReversePaymentTracking rpt ON p2.paymentNumber = rpt.PaymentID GROUP BY p2.paymentNumber, p2.amountPaid) AS pm " _
                & "ON p.paymentNumber = pm.paymentNumber " _
                & "AND pm.amountPaid > 0 " _
                & "JOIN dbo.PaymentGroup pg " _
                & "ON p.paymentGroupNumber = pg.paymentGroupNumber " _
                & "AND pg.paymentGroupDescription = 'ON ACCOUNT' " _
                & customerNameCondition _
                & "ORDER BY paymentDate DESC"
            End If

            query = query & ") AS i ORDER BY i.paymentDate DESC"
                

        Set loadData = getDisconnectedRecordset(query)
    End Function


%>
<script language="JavaScript" src="../script/date-picker.js"></script>
<script type="text/javascript" src="/script/printing.js"></script>
<script language="javascript" type="text/javascript">

    function captureKeyUpEvent(element) {

        if (event.keyCode == 13) {

            event.returnValue = true;
            document.getElementById('searchField').value = element
            searchByInvoice();
        }
    }

    function toggleRowSelected(rowElement) {
        var currentSelectedRow = $('#tblInvoices tr.selected:first');
        if (currentSelectedRow) {
            var currentSelectedRowElement = currentSelectedRow[0];
            if (currentSelectedRowElement) {
                if (currentSelectedRowElement == rowElement) {
                    rowElement.className = '';
                } else {
                    currentSelectedRowElement.className = '';
                    rowElement.className = 'selected';
                }
            } else {
                rowElement.className = 'selected';
            }
        } else {
            rowElement.className = 'selected';
        }
    }

    function getSelectedInvoice() {
        var selection = null;

        var selectedRow = $('#tblInvoices tr.selected:first');
        if (selectedRow) {
            var selectedRowElement = selectedRow[0];
            if (selectedRowElement) {
                selection = selectedRowElement
            }
        }

        return selection;
    }


</script>

<!-- TODO Figure out why tblInvoices is inheriting its font-size from body (in stylesheet.css) rather than table.itable (in greyscale.css) -->
<style type="text/css">
    table.itable {
        font-size: 16px;
    }
</style>

<table class="itable" id="tblInvoices" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<th style="width: 10%" align="left">InvoiceNumber</th>
		<th style="width: 10%" align="left">Customer</th>
		<th style="width: 10%" align="left">Department</th>
		<th style="width: 10%" align="left">Date Paid</th>
		<th style="width: 10%" align="left">Payment Amount</th>
		<th style="width: 10%" align="left">Ticket Status</th>
	</tr>
	
	<%  Dim invoicesFound: invoicesFound = False

        If Not IsEmpty(rstInvoice) Then
            If rstInvoice.RecordCount > 0 Then
                invoicesFound = True
            End If
        End If
        

        If Not invoicesFound Then 
        
    %>
	<tr>
		<td colspan="9" align="center">Search criteria could not find any matching invoices</td>
	</tr>
    <%
        Else
		    While Not rstInvoice.EOF 			
	%>

	<tr onclick="toggleRowSelected(this);"
        class=""
        data-invoicenumber="<%=trim(rstInvoice("invoicenumber"))%>"
        data-ticketnumber="<%=trim(rstInvoice("ticketNumber"))%>"
        data-paymentnumber="<%=trim(rstInvoice("paymentNumber"))%>"
        data-customername="<%=trim(rstInvoice("customername")) %>"
        data-department="<%=trim(rstInvoice("department"))%>"
        data-paymentdate="<%=trim(rstInvoice("paymentDate")) %>"
        data-amountpaid="<%=trim(rstInvoice("amountpaid"))%>"
        data-ticketstatus="<%=trim(rstInvoice("ticketstatus"))%>"
    >
        <td><%=trim(rstInvoice("invoicenumber")) %> </td>
        <td><%=trim(rstInvoice("customername")) %> </td>
        <td><%=trim(rstInvoice("department")) %> </td>
        <td><%=trim(rstInvoice("paymentDate")) %> </td>
        <td><%=formatcurrency(rstInvoice("amountPaid"), 2)%></td>
        <td><%=trim(rstInvoice("ticketstatus")) %> </td>
	</tr>
	<%	
		        rstInvoice.MoveNext
		    Wend		
        End If
    %>

</table>
