
<%
	dim dbname
	
	dbname = request.querystring("dbname")
	if dbname = "" then dbname = "default"
%>

<!-- #include file="../include/SystemStartup.asp" -->
<% selectDatabase dbname %>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!DOCTYPE html>
<html>
<head>
<title>dygraph test</title>


<script type="text/javascript" src="/external/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="/external/excanvas.js"></script>
<script type="text/javascript" src="/external/dygraph-combined.js"></script>
<script type="text/javascript" src="/external/jquery.sparkline.min.js"></script>

</head>

<body>

<h3>Outgoing Sales</h3>
<div id="graph" style=""></div>
<script type="text/javascript">
  g = new Dygraph(
    document.getElementById("graph"),
    "/data/outgoing-sales.asp",
	{
		axes: {
			x: {
				axisLabelFormatter: function(n) {
					var nf = Math.floor(n) % 12;
					var decimal = n - Math.floor(n);
					var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
					
					if(decimal > 0) {
						return '';
					}
					else {
						return m[nf - 1];
					}
				}
			}
		}
	}
  );
</script>


<div id="graph2" style=""></div>
<div class="sparkpie">34,6,23,77,2,1</div>

<script type="text/javascript">
var colors = ['#8a56e2','#e28956','#56e289','#56aee2','#aee256','#e256ae',];

$('.sparkpie').sparkline('html', {type: 'pie', height: 200, sliceColors: colors});

  g = new Dygraph(
    document.getElementById("graph2"),
    "/data/outgoing-total-route.asp",
    {
      rollPeriod: 4,
      showRoller: true
    }
  );

  
</script>

<%
	dim query, rs
	
	query = " select routenumber, name from route where routenumber > 0 "
	set rs = getdisconnectedrecordset(query)
	
	while not (rs.eof or rs.bof)
%>
<h3><%=server.htmlencode(rs("name"))%></h3>
<div id="graph-r<%=rs("routenumber")%>" style=""></div>
<script type="text/javascript">
  g = new Dygraph(
    document.getElementById("graph-r<%=rs("routenumber")%>"),
    "/data/outgoing-sales.asp?route=<%=rs("routenumber")%>",
	{
		axes: {
			x: {
				axisLabelFormatter: function(n) {
					var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
					return m[n - 1];
				}
			}
		}
	}
  );
</script>

<%
		rs.movenext
	wend
%>


</body>
</html>