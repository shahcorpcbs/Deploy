<%@ Language=VBScript %>
<!--#include file="../include/QueryDatabase.asp"-->
<%
	dim query, rs
	dim storeguid
	dim customerseq
	dim employeeid
	
	employeeid = Session("EmployeeID")
	customerseq = request.querystring("customerseq")
	storeguid = request.querystring("storeguid")

	function getMessageServerURL()
		dim query, rs
		
		query = "select isnull(messageServerURL, '') as messageServerURL from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getMessageServerURL = trim(rs("messageServerURL"))
		
		set rs = nothing
	end function
	
	function getBrightness(col)
		dim r, g, b
		
		r = clng("&H" & left(col, 2))
		g = clng("&H" & mid(col, 3, 2))
		b = clng("&H" & right(col, 2))

		getBrightness = 0.3 * r + 0.59 * g + 0.11 * b
	end function
	
	function fontContrastColor(col)
		if getBrightness(col) > 128 then
			fontContrastColor = "000000"
		else
			fontContrastColor = "ffffff"
		end if
	end function
%>
<HTML>
<HEAD>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

<SCRIPT language="javascript" type="text/javascript">

	function viewTask(taskid) {
		var w = window.open("<%=getMessageServerURL()%>/MainApp/viewtask.asp?taskid=" + taskid, "ViewTask", "status=no,scrollbars=no,width=530,height=500,modal=no");
	}

</SCRIPT>
</HEAD>
<BODY STYLE="margin:0;padding:0;background:white;border:1px inset">



<%
	query = "select task.*, convert(varchar, task.datecreated, 101) as datecreated, taskpriority.color as prioritycolor from "
	query = query & " task inner join customertask on "
	query = query & " task.id = customertask.taskid "
	query = query & " inner join taskpriority on "
	query = query & " task.priority = taskpriority.id "
	query = query & " where customertask.customersequencenumber = " & customerseq
	query = query & " and customertask.storeguid = '" & storeguid & "'"
	query = query & " order by task.id desc"
	set rs = getdisconnectedrecordset(query)
	
	
	while not(rs.eof or rs.bof)
%>
	<div onclick="viewTask(<%=rs("id")%>)" style="cursor:hand;width:100%;margin:2px;padding:4px;background-color:#<%=rs("prioritycolor")%>;text-align:center;color:#<%=fontContrastColor(rs("prioritycolor"))%>">	
	<div style="font-size:10;border-bottom:1px dotted #<%=fontContrastColor(rs("prioritycolor"))%>">Task <%=rs("id")%> Date Created <%=rs("datecreated")%></div>

	<%
		if len(rs("description")) > 130 then
			response.write left(rs("description"), 130) & "..."
		else
			response.write rs("description")
		end if
	%>
	</div>
<%
		rs.movenext
	wend
	
	set rs = nothing
%>



</BODY>
</HTML>
