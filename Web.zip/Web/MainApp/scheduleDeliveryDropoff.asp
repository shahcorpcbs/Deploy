<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<%
	dim query, rs
	dim customerSequenceNumber
	dim originPage
	dim ticketNumber
	dim note
	
	
	note = "Scheduled Drop Off"
	
	ticketNumber = getReqVar("ticketNumber")
	customerSequenceNumber = getReqVar("customerSequenceNumber")
	originPage = getReqVar("originPage")
	
	select case(lcase(request.querystring("useraction")))
	case "scheduledropoff"
		scheduleDropOff customerSequenceNumber, request.form("selectedInvoice"), request.form("dropOffDate"), request.form("note")
		returnToOriginPage originPage, customerSequenceNumber
	case "cancel"
		returnToOriginPage originPage, customerSequenceNumber
	case "canceldropoff"
		cancelDropOff customerSequenceNumber, request.form("selectedInvoice")
		returnToOriginPage originPage, customerSequenceNumber
	end select

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	function cancelDropOff(customerSequenceNumber, ticketNumbers)
		dim query, rs
		
		if ticketNumbers <> "" then
			query = " update deliverywillcall set status = -1 "
			query = query & " where status = 0 and actionrequired = 'DROPOFF' and ticketnumber in (" & ticketNumbers & ")"
			qryexecute query
		end if
	end function
	function scheduleDropOff(customerSequenceNumber, ticketNumbers, scheduledDate, note)
		dim query, rs
		
		if ticketNumbers <> "" then
			query = " update deliverywillcall set status = -1 "
			query = query & " where status = 0 and actionrequired = 'DROPOFF' and ticketnumber in (" & ticketNumbers & ")"
			qryexecute query
			
			query = " insert into deliverywillcall (ticketnumber, customersequencenumber, actionrequired, scheduledDate, note) "
			query = query & " select ticketnumber "
			query = query & ", " & customerSequenceNumber
			query = query & ", 'DROPOFF'"
			
			if scheduledDate <> "" then
				query = query & ", '" & scheduledDate & "'"
			else
				query = query & ", getdate()"
			end if
			
			query = query & ", " & DbCreateQryString(note)
			
			
			query = query & " from ticket where ticketnumber in (" & ticketNumbers & ")"

			qryexecute query
		end if
	end function
	
	function returnToOriginPage(originPage, customerSeq)
		select case lcase(originPage)
		case "customerfunctions"
			response.redirect "customerfunctions.asp?customerSeq=" & customerSeq
		end select
	end function
	
	function existsInDelim(searchIn, searchFor, delim)
    dim chunks
    dim idx
    
    chunks = split(searchIn, delim)
    
    existsInDelim = false

    for idx = lbound(chunks) to ubound(chunks)
      if trim(chunks(idx)) = trim(searchFor) then
        existsInDelim = true
        exit function
      end if
    next
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">


<style type="text/css">

</style>

<script language="javascript" type="text/javascript" src="/Script/validation.js"></script>
<script language="JavaScript" src="../script/date-picker.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<script language="javascript" type="text/javascript">
	function submitForm() {
		document.scheduleDeliveryDropOff.action = "?useraction=scheduledropoff";
		document.scheduleDeliveryDropOff.submit();
	}
	function cancelForm() {
		document.scheduleDeliveryDropOff.action = "?useraction=cancel";
		document.scheduleDeliveryDropOff.submit();
	}
	
	function cancelDropoff() {
		document.scheduleDeliveryDropOff.action = "?useraction=canceldropoff";
		document.scheduleDeliveryDropOff.submit();
	}
	
	function SetRowCheckedStatus(row, check, value) {

		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "selectedInvoice") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "selectedInvoice") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}
	
	function selectInvoices() {
		 $("INPUT").each(function(i){
		   if(this.name == "selectedInvoice" && this.selected == "true") {
		   	ToggleRowChecked(this.parentNode.parentNode);
		   }
		 });
	}
	
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="selectInvoices();scheduleDeliveryDropOff.dropOffDate.focus()">
<!-- #include file="../include/banner.inc" -->
<FORM name="scheduleDeliveryDropOff" ID="scheduleDeliveryDropOff" METHOD=POST  style="margin:0;padding:0"> 
<INPUT type="hidden" name="customerSequenceNumber" value="<%=customerSequenceNumber%>" />
<INPUT type="hidden" name="originPage" value="<%=originPage%>" />

<H1>Select Delivery Dropoff</H1>

<BR /><BR />


<CENTER>
Date<BR />
<INPUT style="width:100px;height:30px;font-size:16;text-align:center;" name="dropOffDate" onclick="show_calendar('scheduleDeliveryDropOff.dropOffDate');" readonly />
<BR />
Note <BR />
<TEXTAREA name="note" style="overflow: auto" cols="40" rows="5"><%=Server.HTMLEncode(note)%></TEXTAREA>
<BR /><BR />
</CENTER>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">

		<BUTTON style="width:100px;height:50px" onclick="cancelDropoff()">Cancel Dropoff</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON style="width:100px;height:50px" onclick="cancelForm()">Cancel</BUTTON>
		<BUTTON style="width:100px;height:50px" onclick="submitForm()">Ok</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" cellspacing="0" cellpadding="0">
<TR>
	<TH>&nbsp;</TH>
	<TH align="left">Invoice Number</TH>
	<TH align="left">Due Date</TH>
</TR>
<%
	query = "select ticketnumber, invoicenumber, duedate from ticket where "
	query = query & " customersequencenumber = " & customerSequenceNumber
	query = query & " and ticketstatus = 'AC' "
	
	
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
%>
	<TR onclick="ToggleRowChecked(this)" >
		<TD><INPUT type="checkbox" value="<%=rs("ticketnumber")%>" name="selectedInvoice" <%if existsInDelim(ticketNumber, rs("ticketnumber"), ",") then%>selected="true"<%end if%> /></TD>
		<TD><%=rs("invoicenumber")%></TD>
		<TD><%=rs("duedate")%></TD>
	</TR>
<%
		rs.movenext
	wend
	set rs = nothing
%>
</TABLE>


</FORM>
</BODY>
</HTML>
