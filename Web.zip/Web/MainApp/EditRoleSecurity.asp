<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!-- #include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim query, rs
	dim tagid
	dim employeeid
	dim securityLevel
	dim employeeSecurityLevel

	employeeSecurityLevel = getEmployeeSecurityLevel(session("employeeid"))

	tagid = trim(Request.QueryString("tagid"))
	if tagid = "" then
		tagid = trim(Request.Form("tagid"))
	end if
	
	securityLevel = trim(Request.Form("securityLevel"))
	if securityLevel = "" then
		securityLevel = getTagSecurityLevel(tagid)
	end if
	
  

	employeeid = trim(Request.QueryString("employeeid"))
	if employeeid = "" then
		employeeid = trim(Request.Form("employeeid"))
	end if




    select case lcase(request.querystring("useraction"))


    case "done"
        reassignFunctions
        response.redirect "/MainApp/EditEmployeeRoles.asp?employee=" & employeeid
    case "cancel"
        response.redirect "/MainApp/EditEmployeeRoles.asp?employee=" & employeeid
    case "reassign"
        reassignFunctions
    end select




  function getTagSecurityLevel(tagID)
  	dim query, rs
  	
  	query = " select securityLevel from employeeTag where id = " & tagID
  	set rs = getdisconnectedrecordset(query)
  	
  	getTagSecurityLevel = 0
  	
  	if rs.recordcount > 0 then
  		getTagSecurityLevel = rs("securityLevel")
  	end if
  	
  	set rs = nothing
  end function
  
  function saveTagSecurityLevel(tagID, securityLevel)
  	dim query, rs
  	
  	query = " update employeetag set securityLevel = " & securityLevel
  	query = query & " where id = " & tagID
  	
  	qryexecute query
  
  end function

	sub reassignFunctions()
		dim query, rs
		dim status, exclusive

		query = "update employeefunction set exclusive = 0 "
		query = query & " where id in "
		query = query & "(select EmployeeFunction.id from EmployeeFunction, EmployeeTagSecurity where"
		query = query & " EmployeeTagSecurity.TagID = " & tagid
		query = query & " and EmployeeTagSecurity.FunctionID = EmployeeFunction.ID)"
		qryexecute(query)
		
		query = "delete EmployeeTagSecurity where TagID = " & tagid 
		qryexecute(query)
			
		query = "select * from employeefunction"
		set rs = getdisconnectedrecordset(query)

		
		saveTagSecurityLevel tagid, securityLevel
		
		while not(rs.eof or rs.bof)
			status = Request.Form("s" & rs("id"))
			exclusive = Request.Form("e" & rs("id"))

			if status = "0" then

				if exclusive = "1" then
					query = "delete EmployeeTagSecurity "
					query = query & " where FunctionID = " & rs("id")
					qryexecute(query)
						
					query = "update employeefunction set exclusive = 1 "
					query = query & " where id = " & rs("id")
					qryexecute(query)
				end if
				
				query = "insert into EmployeeTagSecurity(TagID, FunctionID, DenyAccess) VALUES ("
				query = query & tagid
				query = query & "," & rs("id") 
				query = query & "," & "0"
				query = query & ")"
				
				qryexecute(query)
				
			elseif status = "1" then
				
				query = "insert into EmployeeTagSecurity(TagID, FunctionID, DenyAccess) VALUES ("
				query = query & tagid
				query = query & "," & rs("id") 
				query = query & "," & "1"
				query = query & ")"
				
				qryexecute(query)
			end if
			
			rs.movenext
		wend
	end sub

	
	function getEmployeeSecurityLevel(employeeID)
		dim query, rs
		
		query = " select count(*) from "
		query = query & " employeetagassignment "
		query = query & " inner join employeetag on employeetagassignment.tagid = employeetag.id "
		query = query & " where employeetagassignment.employeeid = " & employeeID
		query = query & " and employeetag.name = 'All Functions' "

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getEmployeeSecurityLevel = 32000
			set rs = nothing
			exit function
		end if

		set rs = nothing

		query = " select isnull(max(isnull(employeetag.securityLevel, 0)), 0) as securityLevel "
		query = query & " from employeetagassignment "
		query = query & " inner join employeetag on employeetagassignment.tagid = employeetag.id "
		query = query & " where employeetagassignment.employeeid = " & employeeID

		set rs = getdisconnectedrecordset(query)
		
		getEmployeeSecurityLevel = 0
		
		if rs.recordcount > 0 then
			getEmployeeSecurityLevel = rs("securityLevel")
		end if
		
		set rs = nothing
	end function
	
%>
<HTML>
<HEAD>
<TITLE>Employee Function Setup</TITLE>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<STYLE>
.securitySection UL     { cursor: hand; text-align:center;font-size:14;margin:5px;padding:3px;background:#EEE;border:2px outset;margin-bottom:10px }
.securitySection UL LI                { display: none;list-style:none;text-align:left }
.securitySection UL.showList          {  }
.securitySection UL.showList LI       { display: block;margin:1px;padding:2px;background:white; }
.securitySection UL.defaultStyles LI  { display: none; }
</STYLE>

</HEAD>
<script language="javascript" type="text/javascript">

	
	function reassignFunctions() {
			document.editrolesecurity.action = "?useraction=reassign";
			document.editrolesecurity.submit();
	}
	
	function exitAndSave() {
			document.editrolesecurity.action = "?useraction=done";
			document.editrolesecurity.submit();
    }
	
	function exitOnly() {
			document.editrolesecurity.action = "?useraction=cancel";
			document.editrolesecurity.submit();
    }

    function onload() {
        var selects = document.getElementsByTagName('select');
        var sel;
        for(var z=0; z<selects.length; z++){
             sel = selects[z];
             if(sel.name.indexOf('s') === 0){
                 updateColor(sel);
             }
        }
    }

    function updateColor(element) {
        if (element.value == "-1")
            element.style.color = "gray"
        else if (element.value == "0")
            element.style.color = "green"
        else if (element.value == "1")
            element.style.color = "red"
    }
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0 onload="onload()">
<!-- #include file="../include/banner.inc" -->
<H1>Employee Role Setup</H1>
<FORM id="editrolesecurity" name="editrolesecurity"  Method = "post">


<input type=hidden name="tagid" value="<%=tagid%>">
<input type=hidden name="employeeid" value="<%=employeeid%>">


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;height: 53px">
	<SPAN style="float:left">
		<BUTTON onclick="exitAndSave()">Save</BUTTON>
		
		<SPAN style="width: 200px; padding-bottom: 12px" >
			Security Level: <INPUT name="securityLevel" style="width: 50px;" value="<%=securityLevel%>" />
		</SPAN>
	</SPAN>
	<SPAN style="float:right">
        <BUTTON onclick="exitOnly()">Cancel</BUTTON>
	</SPAN>
</DIV>	





<DIV class="securitySection" >
<%
	dim functionstatus
	dim splitName
	dim curGroupName, curSubGroupName
	dim lastGroupName
	
	query = "SELECT EmployeeFunction.*,  isnull(convert(int, EmployeeTagSecurity.DenyAccess), -1) AS DenyAccess, " _
	    & " case when sup.id is not null then 1 else 0 end as restricted " _
	    & " FROM EmployeeFunction LEFT OUTER JOIN" _
	    & " EmployeeTagSecurity ON EmployeeFunction.ID = EmployeeTagSecurity.FunctionID " _
        & " AND EmployeeTagSecurity.TagID = " & tagid _
        & " left join SuperUserPages sup on lower(EmployeeFunction.Location) = lower(sup.location) " _
        & " order by EmployeeFunction.name"

	set rs = getdisconnectedrecordset(query)

	
	while not (rs.eof or rs.bof)
		splitName = Split(rs("Name"), "::")
		curGroupName = splitName(0)
		
		if ubound(splitName) > 0 then
			curSubGroupName = splitName(1)
		else
			curSubGroupName = curGroupName
		end if

		if curGroupName <> lastGroupName then
			if lastGroupName <> "" then
%>
	</UL>
<%
			end if
%>		
	<UL class="showList"><%=curGroupName%>
<%		
		end if
%>
		<LI>
			<select name="e<%=rs("id")%>">
				<option value=""></option>
				<option value="1" style="background:yellow" <%if rs("exclusive") then%>selected<%end if%>>Exclusive</option>
			</select>
			
			
			<select onchange="updateColor(this)" name="s<%=rs("id")%>" id="s<%=rs("id")%>" <%if rs("exclusive") or rs("restricted") = 1  then%>disabled<%end if%>>
				<option style="color:gray" value="-1" <%if rs("DenyAccess") = -1 then %>selected<%end if%>>No Rule (Will Deny)</option>
				<option style="color:green" value="0"  <%if rs("DenyAccess") = 0 then %>selected<%end if%>>Allowed</option>
				<option style="color:red" value="1" <%if rs("DenyAccess") = 1 then %>selected<%end if%>>Denied</option>
				<% if rs("restricted") = 1 then %>
				<option style="color:red" value="1" selected>System Admin Only</option>
				<% end if %>
			</select>

			<%if rs("exclusive") then%>
			<input type="hidden" value="<%=rs("DenyAccess")%>" name="s<%=rs("id")%>" />
			<%end if%>
			
			
			<%=curSubGroupName%>
			<span style="color: #f3f3f3"><%=rs("location")%></span>
		</LI>
<%
		lastGroupName = curGroupName
	rs.movenext
	wend
	
	set rs = nothing
%>
	</UL>
</DIV>


</FORM>
</BODY>
</HTML>
