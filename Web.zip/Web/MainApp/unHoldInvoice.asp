<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim isSubmitted 
	
		isSubmitted = Request.QueryString("submitted")
		if isSubmitted then
		
			updatedatabase()
			
		end if
		
	
	getOnHoldInvoice()
%>
<HTML>
<HEAD>
<TITLE>Unhold Invoice</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
/*	function unHoldSelectedInvoice() {
		var counter =document.unHoldInvoiceForm.invoiceNumbers.selectedIndex;
		if(counter >=0) {
			var element = document.unHoldInvoiceForm.invoiceNumbers(counter);
			var invoiceNumber = element.text;
			document.unHoldInvoiceForm.action ="detailedInvoice.asp";
			document.unHoldInvoiceForm.submit();
		}
	}
*/
	function unHoldSelectedInvoice(){
		var counter =document.unHoldInvoiceForm.invoiceNumbers.selectedIndex;
		if(counter >=0) {
			document.unHoldInvoiceForm.action = "?Submitted=true";
			document.unHoldInvoiceForm.submit();
		}
		else 
		cbs_alert("Please select an invoice from the onhold list");
	
	}
	function cancelForm(){
		document.unHoldInvoiceForm.action ="toolsMenu.asp";
		document.unHoldInvoiceForm.submit();
	}	
	
	function enableButton(){
		if (document.unHoldInvoiceForm.invoiceNumbers.length > 0 )
			document.unHoldInvoiceForm.select.disabled = false;
		else
			document.unHoldInvoiceForm.select.disabled = true;
	}		
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload = "enableButton()">
<!-- #include file="../include/banner.inc" -->
<H1> &nbsp;Unhold Invoice</H1>
	<FORM id="unHoldInvoiceForm" name="unHoldInvoiceForm" action="" method="Post">
		<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5>
			<tr height=50px></tr>
			<tr>
				<td width=200px></td>
				<td align=center class="label">List of Invoices on Hold
				</td>
			
			</tr>
			<tr>
				<td width=200px></td>
				<td align=center rowspan=2>
					<select name="invoiceNumbers" size=10 style="width=200px;font-size=16px">
						<%
							if rstInvoice.recordcount > 0 then
								dim bMultiple
								dim invoicetype
								while not rstInvoice.eof 
								
								invoicetype = rstInvoice("invoicetype")
								if rstInvoice("multiplePickup")then
									bMultiple =1 
								else
									bMultiple =0
								end if
						%>		
							<option value="<%=rstInvoice("ticketnumber") & "-" & bMultiple & "-" & invoicetype %>"><%=rstInvoice("invoicenumber")%>
						<%
							rstinvoice.movenext
							wend
							rstinvoice.close
							set rstinvoice = nothing
							end if
						%>
					</select>
				</td>
				<td align=center>
					<INPUT class=touchnoborder id=select name=select type=button value="" style="background-image:url(../images/Ok.gif)" onClick="unHoldSelectedInvoice()">
				</td>
				<td width=200px></td>
			</tr>
			<tr>
				<td width=200px></td>
				<td valign=top align=center>
					<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
				</td>
			</tr>
		</table>
	</form>
</BODY>
</HTML>

<%
	dim rstInvoice
	function getOnHoldInvoice()
	dim sqltxt
		'sqltxt = "Select ticketnumber, invoicenumber , isnull(multiplepickup, 0) as 'multiplepickup' from ticket T , customer C where t.customersequencenumber = c.customersequencenumber and invoicetype = 'D' and ticketstatus = 'AC' and onhold = 1" 
		sqltxt = "Select ticketnumber, invoicenumber , isnull(multiplepickup, 0) as 'multiplepickup',invoicetype from ticket T , customer C where t.customersequencenumber = c.customersequencenumber  and ticketstatus = 'AC' and onhold = 1" 
		set rstInvoice = getdisconnectedrecordset(sqltxt)
	end function

	function updatedatabase()
	dim sqltxt
	dim arrtemp
	dim l_ticketnumber
	dim l_multiplepickup
	dim invoiceType
	dim  targetString
	
		arrtemp = split(Request.Form("invoiceNumbers"), "-")
		l_ticketnumber = arrtemp(0)
		l_multiplepickup = arrtemp(1)
		invoiceType =  trim(arrtemp(2))
		sqltxt = "update ticket set onhold = 0, wasHeld = 1 where ticketnumber = " & l_ticketnumber
		'Response.Write sqltxt
		dbstarttrans()
		qryexecutewithtrans(sqltxt)
		dbendtrans()
'		If invoiceType = "D" then
			targetstring = "DetailedInvoice.asp" & "?userAction=edit&ticketnumber=" & l_ticketnumber & "&multiplePickup=" & l_multiplepickup & "&originPage=customerfunctions" 
'		else
'			targetstring = "DetailedInvoice.asp" & "?userAction=edit&ticketnumber=" & l_ticketnumber & "&multiplePickup=" & l_multiplepickup & "&originPage=customerfunctions" 
'		end if
		'Response.Write targetstring
		Response.Redirect(targetString) 
	end function
%>
