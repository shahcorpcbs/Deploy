<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../include/SystemStartup.asp"-->
<% selectDatabase request.querystring("dbname") %>

<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../external/json.asp" -->

<%

	dim query, rs
	dim result
	dim json_encoder
	dim pcs_past_due : pcs_past_due = 0
	dim pcs_due_today : pcs_due_today = 0
	dim pcs_due_later : pcs_due_later = 0
	dim store_id
	dim store_name
	

	set result = server.createobject("scripting.dictionary")
	set json_encoder = new JSON

	query = " SELECT Store.name, Store.storeID "
	query = query & " FROM Store "
	query = query & " WHERE Store.storeID = (SELECT MIN(storeID) From Store) "
	set rs = getdisconnectedrecordset(query)
	
	if rs.recordcount > 0 then
		store_id = rs("storeid").Value
		store_name = rs("name").Value
	end if
	
	result.add "store_id", store_id
	result.add "store_name", store_name

	query = "select id from TwilioResponseMessage trm where (id not in (select TwilioResponseMessageId from SMSMessageHistory) " _
	    & "or (select top 1 status from SMSMessageHistory where TwilioResponseMessageId = trm.id order by datechanged desc) = 0)" _
	    & " and  errorCode in (0, 11200)"
	set rs = getdisconnectedrecordset(query)
	result.add "unreadMessages", rs.recordcount
	
	query = ""
	query = query & " SELECT isnull(SUM(dbo.getTotalPieces(Ticket.ticketNumber, null)), 0) as pcs_past_due "
	query = query & " FROM Ticket "
	query = query & " WHERE Ticket.ticketStatus = 'AC' "
	query = query & " AND Ticket.invoicetype = 'D' "
	query = query & " AND DATEDIFF(day, Ticket.dueDate, getdate()) >= 0 "
	query = query & " AND dbo.pivotTicketRackLocationBrief(Ticket.ticketNumber, ',') = '' "
	
	set rs = getdisconnectedrecordset(query)
	
	if rs.recordcount > 0 then
		pcs_past_due = rs("pcs_past_due")
	end if
	
	result.add "pcs_due_later", pcs_due_later
	result.add "pcs_past_due", pcs_past_due
	result.add "pcs_due_today", pcs_due_today
	
	
	
	response.write json_encoder.toJSON("store", result, 0, null)
	
%>