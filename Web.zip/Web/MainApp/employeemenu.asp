<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%

	function getAlert()
		getAlert = request.querystring("alert")
	end function


	function getStoreName()
		dim query, rs

		query = "select name from store where storeid = " & Session("storeid")
		set rs = getdisconnectedrecordset(query)

		getStoreName = rs("name")

		set rs = nothing
	end function
%>
<HTML>
<HEAD>
<TITLE>Employee Menu</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function showClockInClockOut(userSelection){
		document.employeeMenuForm.action = "clockInClockOut.asp?userAction=" + userSelection;
		document.employeeMenuForm.submit();
	}
	
	function cancelForm(){
		document.employeeMenuForm.action ="start2.asp";
		document.employeeMenuForm.submit();	
	}

	function showEOSReport(reportName){
		
		if (reportName == "cashOut") {
			document.employeeMenuForm.action = "employeeEOSRParams.asp?reportID=2";
		}
		else {
			document.employeeMenuForm.action = "employeeEOSRZParams.asp?reportID=1";
		}

		document.employeeMenuForm.submit();

		// alert("You have selected to run one of the End Of Shift Reports. This feature is not yet implemented. Please check back in again later.")

	}
	


</SCRIPT>
<BODY topmargin=0 leftmargin=0 <%if getAlert() <> "" then%>onload="cbs_alert('<%=getAlert()%>')" <%end if%> >

<!-- #include file="../include/banner.inc" -->
<H1>Employee Menu</H1>
<FORM id="employeeMenuForm" name="employeeMenuForm" action="" method="Post">
<CENTER>
<TABLE>
<TR>
<TD>
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<TR height=30px></TR>	
		<TR height=80px>
			<TD align=center>
				<BUTTON class=std id=clockIn name=clockIn onClick="showClockInClockOut('ClockIn')"><img src="/static/icons/32x32/clock.png"><br>Clock In</button>
			</TD>
		</tr>
		<tr height=80px>		
			<TD align=center>
				<BUTTON class=std  id=clockOut name=clockOut onClick="showClockInClockOut('ClockOut')"><img src="/static/icons/32x32/clock_disable.png"><br>Clock Out</button>
			</TD>
		</tr>
	 </TABLE>
</TD>
<TD>
</TD>

<TD>
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<TR height=30px></TR>	

		<!-- Changes by Vinny on 09-Jul-2002 as follows.
			 1. Removed the End of Shift Reporting button.
			 2. Added two buttons for Cash Out and Z reports

		<tr height=80px>
			<TD align=center>
				<INPUT class=touch id=endOfShiftReport name=endOfShiftReport type=button value=""><br>End of Shift Reporting
			</TD>
		</TR>

		-->
		
		<tr height=80px>		
			<TD align=center>
				<!--<INPUT class=touch id=cashOut name=cashOut type=button value="" style="background-image:url(../images/report-Money.gif)" onClick="showEOSReport('cashOut')"><br>Cash Out Report-->
				<BUTTON class=std id=cashOut name=cashOut onClick="showEOSReport('cashOut')"><img src="/static/icons/32x32/money.png"><br>Cash Out Report</button>
			</TD>
		</tr>

		<tr height=80px>		
			<TD align=center>
				<BUTTON class=std id=cashOutZ name=cashOutZ onClick="showEOSReport('cashOutZ')"><img src="/static/icons/32x32/money.png"><br>Cash Out Z Report</button>
				<!--<INPUT class=touch id=cashOutZ name=cashOutZ type=button value="" style="background-image:url(../images/Report-Money.gif)" onClick="showEOSReport('cashOutZ')"><br>Cash Out Z Report-->
			</TD>
		</tr>

	 </TABLE>
</TD>
</TABLE>
</CENTER>
</FORM>   

</BODY>
</HTML>
