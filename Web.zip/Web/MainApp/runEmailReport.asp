<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!-- #include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<!--#include file="../include/queryParamFunctions.asp" -->

<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim queryName, queryTransformed, userQueryID, formTemplate
	dim employeeEmailAddr, params, dateString
	dim from, schId, l_sendAsAttachment, userAction, l_formatType, l_sendGrid

	from = getReqVar("from")
	l_sendGrid = getMSVar("useSendGrid")

	
	userQueryID = getReqVar("userQueryID")
	queryTransformed = getReqVar("query")
	queryName = getReqVar("queryName")
	schId = getReqVar("schId")
	dateString = trim(Request.QueryString("dateString"))
	employeeEmailAddr = getEmployeeEmailAddr(session("employeeid"))

	if from = "schedule" and queryTransformed = "" then

        query = "select e.userQueryId, e.query, e.sendAsAttachment, e.formatType, u.name from userQuery u, " _
            & " EmailReportSchedule e where e.userQueryId = u.UserQueryId and e.Id = " & schId
        set rs = getdisconnectedrecordset(query)

        userQueryID = rs("userQueryId")
        queryName = rs("name")
        queryTransformed = rs("query")
        l_sendAsAttachment = rs("sendAsAttachment")
        l_formatType = rs("formatType")
	    set params = getQueryParams(queryTransformed)
	end if


	queryName = getQueryName(userQueryID)

    userAction = lcase(request.querystring("useraction"))
	select case userAction
	case "run"
        prepareEmail
	end select


	function prepareEmail
        dim query, rs
        set params = getQueryParams(queryTransformed)
        queryTransformed = transformQuery(queryTransformed, params, request.form, dateString)
        set params = getQueryParams(queryTransformed)
        queryname = Request.QueryString("subject")
        employeeEmailAddr = Request.QueryString("toEmail")
        l_sendAsAttachment = Request.QueryString("useAtt")
        l_formatType = Request.QueryString("formatType")
	end function
	
	function getEmployeeEmailAddr(employeeID)
		dim query, rs
		
		if employeeID <> "" then
			query = " select isnull(email, '') as email from employee where employeeid = " & employeeid
			
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getEmployeeEmailAddr = rs("email")
			end if
			
			set rs = nothing
		end if
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

	function getQueryName(userQueryID)
		dim query, rs
		
		if userQueryID <> "" then
			query = "select name from userquery where userqueryid = " & userqueryid
			
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then getQueryName = rs("name")
		end if
	
	end function
%>

<HTML>
<HEAD>
<TITLE>Email Report</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<SCRIPT LANGUAGE="javascript" >


	function exit() {
        <% if from = "query" then %>
            document.runOnceForm.action = "querydb.asp";
        <% else %>
            document.runOnceForm.action = "../setup/empEmailReportSetup.asp";
        <% end if %>
            document.runOnceForm.submit();
	}

    function showHideDates() {
        var dateSel = document.getElementById('dateField').value;
        if (dateSel == 5) {
            document.getElementById('start_Date').style.visibility = "visible";
            document.getElementById('end_Date').style.visibility = "visible";
        }
        else {
            document.getElementById('start_Date').style.visibility = "hidden";
            document.getElementById('end_Date').style.visibility = "hidden";
        }
    }

	function run() {
	    if (document.getElementById("subject").value == "") {
	        cbs_alert("Must enter a subject");
	        return;
	    }
	    if (document.getElementById("email").value == "") {
	        cbs_alert("Must enter email address to send report to");
	        return;
	    }


	    <% if from = "query" then %>
	        sendEmailRequest(`<%= trim(queryTransformed) %>`);
	    <% else %>
	        <% if l_sendGrid then %>
            var useAtt = document.getElementById('sendAtt').checked ? "1" : "0";
            <% else %>
            var useAtt = "0"
            <% end if %>
            var dateString = ""
            if (document.getElementById('dateField') != null) {
                dateString = document.getElementById('dateField').value;
                if (dateString == 5) {
                    var start = document.getElementById('start_Date').value;
                    var end = document.getElementById('end_Date').value;
                    if (start == "") {
                        cbs_alert("If using custom date, then start date must be entered")
                        return;
                    }
                    else if (end == "") {
                        cbs_alert("If using custom date, then end date must be entered")
                        return;
                    }
                    dateString = dateString + "_" + start + "_" + end;
                }
            }

            document.runOnceForm.action = "?useraction=run" +
                "&subject=" + encodeURIComponent(document.getElementById("subject").value) +
                "&toEmail=" + encodeURIComponent(document.getElementById("email").value) +
                <% if l_sendGrid then %>
                "&formatType=" + encodeURIComponent(document.getElementById("formatType").value) +
                <% else %>
                "&formatType=1" +
                <% end if %>
                "&useAtt=" + useAtt +
                "&dateString=" + encodeURIComponent(dateString);
            document.runOnceForm.submit();
        <% end if %>
    }


    function sendEmailRequest(body) {
        var url = "<%=getMessengerFullPath("main")%>/sendEmail?" +
            "emailAddress=" + encodeURIComponent(document.getElementById("email").value) +
            "&employeeId=<%=session("employeeid")%>" +
            "&subject=" + encodeURIComponent(document.getElementById("subject").value) +
            <% if l_sendGrid then %>
            "&attachment=" + (document.getElementById('sendAtt').checked ? "1" : "0") +
            "&formatType=" + (document.getElementById("formatType").value);
            <% else %>
            "&attachment=0&formatType=1";
            <% end if %>

        $.ajax({
            type: "POST",
            url: url,
            data :body,
            contentType: "text/plain",
            Accept: "text/plain",
            timeout: "120000",
            success: function(xhr) {
                cbs_alert("Email request sent to CBS Service", afterEmailSent);
            },
            error: function(xhr, ajaxOptions, thrownError) {
                console.log(xhr);
                cbs_alert("Error sending email request to CBS Service, make sure service is running", afterEmailSent);
            }
        });
    }

    function afterEmailSent() {
        clearAlertMsg();
        <% if from = "query" then %>
            cbs_confirm("Would you like to create a schedule for emailing this report?", createSchedule, returnToResult)
        <% else %>
            document.runOnceForm.action = "../setup/empEmailReportSetup.asp"
            document.runOnceForm.submit();
        <% end if %>
    }

    function createSchedule() {
        document.runOnceForm.action = "/setup/editEmailReportSch.asp?addoredit=add&userQueryId=<%=userQueryId%>";
        document.runOnceForm.submit();
    }

    function returnToResult() {
        document.runOnceForm.action = "querydb.asp?userQueryID=<%=Server.URLEncode(userQueryID)%>&query=<%=Server.URLEncode(queryTransformed)%>"
        document.runOnceForm.submit();
    }

    function init() {
        <% if userAction = "run" then %>
            sendEmailRequest(`<%= trim(queryTransformed) %>`);
        <% end if %>
    }
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onLoad="init();">
<!-- #include file="../include/banner.inc" -->

<FORM name="runOnceForm" ID="runOnceForm" METHOD=POST onsubmit="return false" style="margin:0;padding:0">
<INPUT type="hidden" name="queryName" value="<%=Server.URLEncode(queryName)%>" />
<INPUT type="hidden" name="query" value="<%=queryTransformed%>" />
<INPUT type="hidden" name="userQueryID" value="<%=userQueryID%>" />
<INPUT type="hidden" name="from" value="<%=from%>" />

<H1>Email Report</H1><BR />
<BR />

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">

	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="exit()" value="" >Cancel</BUTTON>
		<BUTTON onclick="run()" value="" >Run</BUTTON>
	</SPAN>
</DIV>

<TABLE class="itable" style="width:100%" cellpadding="0" cellspacing="0">
	<TR align="left">
		<TH>Attribute</TH>
		<TH>Value</TH>
	</TR>
	<TR>
		<TD>Email Subject</TD>
		<TD><INPUT id="subject" style="width:200px" value="<%=queryName%>"></TD>
	</TR>
	<TR>
        <TD>Send To Email Addresses (use semi-colons to separate multiple addresses)</TD>
		<TD><INPUT id="email" style="width:200px" value="<%=employeeEmailAddr%>"></TD>
	</TR>
	<% if l_sendGrid then %>
	<TR>
		<TD>Send As Attachment</TD>
		<TD>
			<input type="checkbox" id="sendAtt" <% if l_sendAsAttachment then %> checked <%end if %>>
		</TD>
	</TR>
	<TR>
        <TD>Format Type</TD>
		<TD>
		    <SELECT id=formatType STYLE="font-size:16px;">
                <option value="1" <% if l_formatType = 1 then %> selected <% end if %>>HTML</option>
                <option value="2" <% if l_formatType = 2 then %> selected <% end if %>>CSV</option>
                <option value="3" <% if l_formatType = 3 then %> selected <% end if %>>PDF</option>
            </SELECT>
        </TD>
	</TR>
	<% end if %>

	<% if from = "schedule" and userAction <> "run" then %>
        <tr height="50px"><td></td></tr>
        <tr><td colspan=2><b>Variables:</b></td></tr>
        <%
            dim item
            dim listedParameters

            set listedParameters = Server.CreateObject("Scripting.Dictionary")

            if ubound(params.items) >= 0 then
            for each item in params.items
                if not listedParameters.exists(replace(item.paramName, "@", "")) then
                    listedParameters.add item.paramName, ""
        %>
        <% if item.paramName <> "End_Date" then %>
        <TR>
            <TD>
                 <% if item.paramName = "Start_Date" then %>
                    Date Range
                 <% else %>
                    <%=Server.HTMLEncode(Replace(item.paramName, "_", " ") )%>
                 <% end if %>
            </TD>
            <TD>
                <%=getParamField(item, request.form(item.paramName), 0)%>

            </TD>
        </TR>
    <% end if %>
    <%
            end if
        next
        else
    %>
        <TR>
            <TD colspan="2">This query does not have any parameters.</TD>
        </TR>
    <%
        end if
    %>
<% end if %>

</TABLE>

</FORM>
</BODY>
</HTML>

