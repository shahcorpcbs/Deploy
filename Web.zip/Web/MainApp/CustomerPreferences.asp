<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim customerSequenceNumber
	dim ticketNumber
	
	customerSequenceNumber = getReqVar("customerSeq")
	
	select case lcase(request.querystring("useraction"))
	case "done"
		updatePreferences
		response.redirect "CustomerEntry.asp?mode=edit&customerseq=" & customerSequenceNumber

	end select
	
	
	function updatePreferences()
		dim query, rs
		dim updateQuery
		dim value
		dim customerSeq
		dim ticketNumber
		dim deleteQuery
		
		customerSeq = request.form("customerSeq")
		ticketNumber = request.form("ticketNumber")
		
		
		query = " select * from customerpreferencetype "
		set rs = getdisconnectedrecordset(query)
		
		while not (rs.eof or rs.bof)
			if updateQuery <> "" then updateQuery = updateQuery & ", "
			
			value = request.form("opt" & rs("customerpreferencetypeid"))
			
			
			
			updateQuery = " insert into customerpreference (customerpreferencetypeid, customersequencenumber, ticketnumber, value) "
			updateQuery = updateQuery & " values (" & rs("customerpreferencetypeid")
			updateQuery = updateQuery & ", " & DbCreateQryString(customerSeq)
			updateQuery = updateQuery & ", " & DbCreateQryString(ticketNumber)
			updateQuery = updateQuery & ", " & DbCreateQryString(value)
			updateQuery = updateQuery & ")"
			
			deleteQuery = " delete customerpreference where "
			deleteQuery = deleteQuery & " customerpreferencetypeid = " & rs("customerpreferencetypeid")
			deleteQuery = deleteQuery & " and customersequencenumber = " & DbCreateQryString(customerSeq)
			if ticketNumber <> "" then
				deleteQuery = deleteQuery & " and ticketnumber = " & ticketNumber
			else
				deleteQuery = deleteQuery & " and ticketnumber is null "
			end if
			
			qryexecute deleteQuery
			qryexecute updateQuery
		
			rs.movenext
			
		wend
		
	
	end function
	
	
	
	function getPreferenceValue(customerSeq, ticketNumber, customerpreferencetypeid, default)
		dim query, rs
		
		getPreferenceValue = default		
		
		if customerSeq <> "" then
			query = " select [value] from customerpreference where "
			query = query & " customerpreferencetypeid = " & customerpreferencetypeid
			query = query & " and customersequencenumber = " & customerSeq
			query = query & " and ticketnumber is null "
			
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				getPreferenceValue = rs("value")
			end if
			
			set rs = nothing
			
			if ticketNumber <> "" then
				query = " select [value] from customerpreference where "
				query = query & " customerpreferencetypeid = " & customerpreferencetypeid
				query = query & " and customersequencenumber = " & customerSeq
				query = query & " and ticketnumber = " & ticketNumber
				
				set rs = getdisconnectedrecordset(query)
				
				if rs.recordcount > 0 then
					getPreferenceValue = rs("value")
				end if
				
				set rs = nothing
			end if
		end if
	end function
	

  
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
%>
<HTML>
<HEAD>
<TITLE>Customer Preferences</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function exitForm() {
			document.customerPreferences.action = "?useraction=done";
			document.customerPreferences.submit();
	}
	
	function selectPreferenceOption(customerpreferencetypeid, o) {

		$('.opt' + customerpreferencetypeid + 'option').each(function(i) {
			this.style.background = 'white';
		});

		$('#opt' + customerpreferencetypeid).val(o.value);
		
		o.style.background = 'red';
	}
	
	function onPreferenceValueKeyUp(o) {
		$('.' + o.id + 'option').each(function(i) {
			this.style.background = (o.value == this.value ? 'red' : 'white');
		});
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0 onload="">
<!-- #include file="../include/banner.inc" -->
<H1>Customer Preferences</H1>
<BR /><BR />

<FORM id="customerPreferences" name="customerPreferences" method="post">
<INPUT type="hidden" name="customerSeq" value="<%=customerSequenceNumber%>" />
<INPUT type="hidden" name="ticketNumber" value="<%=ticketNumber%>" />



<div name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<span style="float:left">

	</span>
	<span style="float:right">
      <button name="exit" onClick="exitForm()">Exit</button>
	</span>
</div>	

<TABLE class="itable" cellspacing="0">
<TR>
	<TH>Name</TH>
	<TH>Value</TH>
	<TH>Options</TH>	
</TR>
<%
	dim preferenceValue
	
	query = " select *, isnull(options, '') as options from customerpreferencetype order by displayorder "
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
		preferenceValue = getPreferenceValue(customerSequenceNumber, ticketNumber, rs("customerpreferencetypeid"), rs("default"))
%>
<TR>
	<TD style="width:200px"><%=rs("name")%></TD>
	<TD style="width:200px"><INPUT style="width:200px" onkeyup="onPreferenceValueKeyUp(this)" id="opt<%=rs("customerpreferencetypeid")%>" name="opt<%=rs("customerpreferencetypeid")%>" value="<%=preferenceValue%>" /></TD>
	<TD>
	&nbsp;
<%
	dim optionsArray
	dim opt
	
	optionsArray = split(rs("options"), "|")
	
	for each opt in optionsArray
%>
	<INPUT type="button" style="width:100px;height:40px;<% if preferenceValue = opt then %>background:red<%else%>background:white<%end if%>"
		onclick="selectPreferenceOption(<%=rs("customerpreferencetypeid")%>, this)"
		value="<%=opt%>"
		class="opt<%=rs("customerpreferencetypeid")%>option"
	/>
<%
	next
%>
	</TD>
</TR>
<%
		rs.movenext
	wend
	set rs = nothing
%>
</TABLE>
</FORM>
</BODY>
</HTML>
