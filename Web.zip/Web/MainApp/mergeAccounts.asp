<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim actionString
	dim toBal, fromBal, newBal, toCard, fromCard
	dim toCardId, fromCardId
	
	actionString = Request.QueryString("userAction")
	
	select case actionString
		case "process"
			updateBalances()
		case "submit"
			processBalanceTransfer()
	end select
		
	function updateBalances() 
		dim ssql
		dim rst
		
		toCard = Request.Form("giftCardTo")
		if not isEmpty(toCard) then
			ssql = "select * from GIFTCARD where giftCardNumber = " & dbcreateqrystring(toCard)
			set rst = getDisconnectedRecordset(ssql)
			if rst.Recordcount > 0 then
				toBal = FormatNumber(rst.fields("giftValue").value,2)
				toCardId = rst.Fields("giftcardid")
			else
				Session("errorMessage") = "To Gift card number not found.  Please enter a valid gift card number"
				Response.Redirect "ErrorMessages.asp"
			end if
		end if	
		fromCard = Request.Form("giftCardFrom")
		if not isEmpty(fromCard) then
			ssql = "select * from GIFTCARD where giftCardNumber = " & dbcreateqrystring(fromCard)
			set rst = getDisconnectedRecordset(ssql)
			if rst.Recordcount > 0 then
				fromBal = FormatNumber(rst.fields("giftValue").value,2)
				fromCardId = rst.Fields("giftCardId")
			else
				Session("errorMessage") = "From Gift card number not found.  Please enter a valid gift card number"
				Response.Redirect "ErrorMessages.asp"
			end if
		end if		
		newBal = FormatNumber(CLng(toBal) + CLng(fromBal),2)
		
	end function
	
	function processBalanceTransfer()
		dim ssql
		
		toCardId = Request.Form("toId")
		fromCardId = Request.Form("fromId")
		newBal = Request.Form("newBalance")
		ssql = "UPDATE giftcard SET giftvalue = 0 where giftcardid = " & fromCardId
		QryExecute(ssql)
		ssql = "UPDATE giftcard SET giftvalue = " & newBal & " where giftcardid = " & toCardId
		QryExecute(ssql)
		Response.Redirect "maintGiftCard.asp"
		
	end function	
		
%>
<HTML>
<HEAD>
<TITLE>Gift Card Maintenance</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function cancelForm() {
		document.mergeAccountsForm.action="maintGiftCard.asp";
		document.mergeAccountsForm.submit()
	}	
	
	function processUpdate() {
		document.mergeAccountsForm.action = "?userAction=process";
		document.mergeAccountsForm.submit();
	}		
	
	function submitForm() {
		var tCard, fCard, tBal, fBal, nBal, qReturn
		
		tCard = document.mergeAccountsForm.giftCardTo.value;
		if (!checkFieldMissing(tCard)) {
			show_focus("Gift card number cannot be blank", "Gift Card Number", document.mergeAccountsForm.giftCardTo)
			return;
		}
		fCard = document.mergeAccountsForm.giftCardFrom.value;
		if (!checkFieldMissing(fCard)) {
			show_focus("Gift card number cannot be blank","Gift Card Number", document.mergeAccountsForm.giftCardFrom)
			return;
		}
		tBal = document.mergeAccountsForm.toBalance.value;
		if (!checkFieldMissing(tBal)) {
			show_focus("Must press process button before OK","Process Form", document.mergeAccountsForm.toBalance)
			return;
		}
		fBal = document.mergeAccountsForm.fromBalance.value;
		if (!checkFieldMissing(fBal)) {
			show_focus("Must press process button before OK","Process Form",document.mergeAccountsForm.fromBalance)
			return;
		}
		nBal = document.mergeAccountsForm.newBalance.value;
		if (!checkFieldMissing(nBal)) {
			show_focus("Must press process button before OK","Process Form",document.mergeAccountsForm.newBalance)
			return;
		}

		cbs_confirm("Do you wish to process this balance transfer?", gotoProcess);
	}

	function gotoProcess() {
        clearConfirmMsg();
	    document.mergeAccountsForm.action = "?userAction=submit";
        document.mergeAccountsForm.submit();
	}
	
	function formatCurrency(num) {
		sign = (num == (num = Math.abs(num)));
		num = Math.floor(num*100+0.50000000001);
		cents = num%100;
		num = Math.floor(num/100).toString();
		if (cents<10)
			cents = "0" + cents;
		for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
			num = num.substring(0,num.length-(4*i+3))+','+num.substring(num.length-(4*i+3));
		return (((sign)?'':'-') + num + '.' + cents);
	}
	
	
		
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onLoad="document.forms.mergeAccountsForm.giftCardFrom.focus();">
<!-- #include file="../include/banner.inc" -->
<H1>Merge Gift Card Accounts</H1>
<FORM id="mergeAccountsForm" name="mergeAccountsForm" action="mergeAccounts.asp" method="Post">
<INPUT TYPE="hidden" name=toId value=<%=toCardId%>>
<INPUT TYPE="hidden" name=fromId value=<%=fromCardId%>>
<TABLE ALIGN=CENTER WIDTH=600px BORDER=1 CELLSPACING=0 CELLPADDING=10>
	<TR><TD>
	<TABLE ALIGN=center WIDTH=100% BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<TR height=60px>
		<TD colspan = 4 align=center><B>Enter FROM and TO Card numbers and press PROCESS to show amounts to be transferred.<br>Click OK to process the transfer, CANCEL to abort.</B></TD></TR>
		<TR height=40px><TD align=right width=200px>
			<LABEL for=giftCardFrom tabindex=0>Gift Card Number to Transfer Balance <b>From</b>&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=giftCardFrom style= width:140px  tabindex=1 value="<%=fromCard%>">
			</TD>
			<TD align=right width=150px>
			<LABEL for=fromBalance  tabindex=0>Balance To Transfer&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text readonly name=fromBalance style=width:70px value="<%=fromBal%>"  tabindex=0>
		</TD></TR>
		<TR height=40px><TD align=right>
			<LABEL for=giftCardTo tabindex=0>Gift Card to Move Balance <b>To</b>&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT class=text name=giftCardTo style=width:140px  tabindex=2 value="<%=toCard%>">
			</TD>
			<TD align=right>
			<LABEL for=toBalance tabindex=0>Balance&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text readonly name=toBalance style=width:70px tabindex=0 value="<%=toBal%>">
		</TD></TR>
		<TR height=60px>
			<TD></td><td align=right>
			<INPUT type=button style="height:50px;width:100px" value="Process" onclick="processUpdate()" tabindex=3>
		</TD><TD align=right>
			<LABEL for=newBalance tabindex=0 >New Balance&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT class=text tabindex=0 readonly name=newBalance style=width:70px value="<%=newBal%>" onBlur="this.value=formatCurrency(this.value);">
			</TD></TR>	
		<TR height=80px><TD ALIGN=CENTER COLSPAN=4 valign=bottom>
			<INPUT class=touchnoBorder id=okButton name=okButton tabindex=4 type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton tabindex=5 type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
		</TD></TR>
	</TABLE>
	</TD></TR>
</TABLE>	
</FORM>   

</BODY>
</HTML>
	