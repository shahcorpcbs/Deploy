<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<!--#include file="../external/include.asp" -->
<%
	include getBarcodeEncoderFilename()
	function getBarcodeEncoderFilename()
		on error resume next
		getBarcodeEncoderFilename = "/include/barcode.asp"
		getBarcodeEncoderFilename = getMSVar("BarcodeEncoderFile")
	end function
%>

<%
    dim query, rs
    dim inventorylistid
    dim matchtype
    dim matchbegin
    dim matchend
    dim orderby
    
    dim filteropen
    dim filternotfound
    dim filtervoided
    dim filternotreconciled
    dim filterclosed
    dim filternotinrange
    
    dim readonly
    
            
    inventorylistid = getReqVar("inventorylistid")
	readonly = getReqVar("readonly")

    select case lcase(request.querystring("useraction"))
    case "view"
    
    case "collectinventorydata"
        saveMatchCriteria "datecreated desc", 0
        collectInventoryData
    case "removeinventoryitem"
        saveMatchCriteria request.form("orderby"), 0
        removeInventoryItem
    case "reconcileinventory"
        saveMatchCriteria request.form("orderby"), 1
        reconcileInventory
    case "savecriteria"
        saveMatchCriteria request.form("orderby"), 0
    case "setorderby"
		saveOrderBy request.form("orderby")
    end select
    
    getMatchCriteria
    
	
		function getMSVar(id)
			dim query, rs
	
			query = "select " & id & " from miscsetup where storeid = " & session("storeid")
			set rs = getdisconnectedrecordset(query)
	
			getMSVar = rs(id)
	
			set rs = nothing
		end function
	
    sub collectInventoryData()
        dim inventoryData
        dim invoicenumbers
        dim invoicenumber

        inventoryData = request.form("inventoryData")

        invoicenumbers = split(inventoryData, "|")

        for each invoicenumber in invoicenumbers
            newInventoryItem invoicenumber
        next
    end sub

    sub getMatchCriteria()
        dim query, rs

        query = "select * from inventorylist where inventorylistid = " & inventorylistid
        set rs = getdisconnectedrecordset(query)

        matchtype = rs("matchtype")
        matchbegin = rs("matchbegin")
        matchend = rs("matchend")
        orderby = rs("orderby")


        filteropen = rs("filteropen")
        filternotfound = rs("filternotfound")
        filtervoided = rs("filtervoided")
        filternotreconciled = rs("filternotreconciled")
        filterclosed = rs("filterclosed")
        filternotinrange = rs("filternotinrange")
    end sub


    function getFormCheckbox(name)
        if request.form(name) <> "" then getFormCheckbox = 1 else getFormCheckbox = 0
    end function

    sub saveMatchCriteria(orderby, reconcile)
        dim query

        query = "update inventorylist set "
        query = query & " matchtype = '" & request.form("searchcriteria") & "',"
        query = query & " matchbegin = '" & request.form("criteriaBegin") & "',"
        query = query & " matchend = '" & request.form("criteriaEnd") & "',"
        query = query & " orderby = '" & orderby & "',"
        query = query & " filteropen = " & getFormCheckbox("filteropen") & ","
        query = query & " filternotfound = " & getFormCheckbox("filternotfound") & ","
        query = query & " filtervoided = " & getFormCheckbox("filtervoided") & ","
        query = query & " filternotreconciled = " & getFormCheckbox("filternotreconciled") & ","
        query = query & " filterclosed = " & getFormCheckbox("filterclosed") & ","
        query = query & " filternotinrange = " & getFormCheckbox("filternotinrange") & ","
        query = query & " hasreconciled = hasreconciled | " & reconcile
        query = query & " where inventorylistid = " & inventorylistid


        qryexecute query
    end sub


    sub saveOrderBy(orderby)
        dim query

        query = "update inventorylist set "
        query = query & " orderby = '" & orderby & "'"
        query = query & " where inventorylistid = " & inventorylistid


        qryexecute query
    end sub


	function isInteger(str)
		dim i
		dim charAscii

		isInteger = true

	    for i = 1 To len(str)
	        charAscii = asc(mid(str, i, 1))

	        if charAscii <= 47 or charAscii >= 58 then
	            isInteger = false
	            exit function
	        end if
	    next
	end function

    sub newInventoryItem(invScan)
        dim query, rs
        dim ticketstatus
        dim customername
        dim racklocation
        dim customerphone
        dim invoicedepartment
        dim invoicepieces
        dim invoicetotal
    		dim barcode
    		dim ticketNumber
    		dim invoiceNumber

    		set barcode = new BarcodeEncoder

				if barcode.LoadBarcode(invScan) then
					if barcode.TicketNumber <> "" then
						ticketNumber = barcode.TicketNumber
					elseif barcode.InvoiceNumber <> "" then
						invoiceNumber = barcode.InvoiceNumber
					end if
				elseif isInteger(invScan) then
					invoiceNumber = invScan
				else
					exit sub
				end if


        query = "select t.*, c.customername, dbo.pivotTicketRackLocationBrief(ticketnumber, ', ') as racklocation, "
        query = query & " dbo.formatPhone(c.mainAreaCode, c.mainPhone) as CustomerPhone, "
        query = query & " dbo.pivotTicketDepartments(t.ticketNumber, ', ' ) as InvoiceDepartment, "
        query = query & " dbo.getTotalPieces(t.ticketNumber, null) as InvoicePieces, "
        query = query & " t.netTotal as InvoiceTotal "


        if invoiceNumber <> "" then
        	query = query & " from ticket t inner join customer c on c.customersequencenumber = t.customersequencenumber where invoicenumber = '" & invoicenumber & "'"
        elseif ticketNumber <> "" then
        	query = query & " from ticket t inner join customer c on c.customersequencenumber = t.customersequencenumber where t.ticketnumber = " & ticketNumber
        else
        	exit sub
        end if

        set rs = getdisconnectedrecordset(query)

        if rs.recordcount > 0 then
            ticketstatus = rs("ticketstatus")
            customername = rs("customername")
            racklocation = rs("racklocation")

            customerphone = rs("customerphone")
            invoicedepartment = rs("invoicedepartment")
            invoicepieces = rs("invoicepieces")
            invoicetotal = rs("invoicetotal")

        else
            ticketstatus = "NF"
            customername = ""
            racklocation = ""

            customerphone = ""
            invoicedepartment = ""
            invoicepieces = "0"
            invoicetotal = "0.00"
        end if

        set rs = nothing

        query = "delete inventoryitem where inventorylistid = " & inventorylistid
        query = query & " and invoicenumber = " & invoicenumber
        qryexecute query

        query = "insert into inventoryitem (inventorylistid, invoicenumber, invoicestatus, customername, racklocation, CustomerPhone, InvoiceDepartment, InvoicePieces, InvoiceTotal) values "
        query = query & " (" & inventorylistid
        query = query & ", " & invoicenumber
        query = query & ", '" & ticketstatus & "'"
        query = query & ", '" & customername & "'"
        query = query & ", '" & racklocation & "'"

        query = query & ", '" & customerphone & "'"
        query = query & ", '" & invoicedepartment & "'"
        query = query & ", " & invoicepieces
        query = query & ", " & invoicetotal

        query = query & ")"

        qryexecute query
    end sub



    sub reconcileInventory()
        dim query, rs

        query = "exec dbo.UpdateInventoryList " & inventorylistid
        query = query & ", " & request.form("searchcriteria")
        query = query & ", '" & request.form("criteriaBegin") & "'"
        query = query & ", '" & request.form("criteriaEnd") & "'"

        qryexecute query
    end sub

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

    sub removeInventoryItem()
        dim query
        dim inventoryitemid

        for each inventoryitemid in request.form("selectedInventoryItemId")
            query = "delete inventoryitem where inventoryitemid = '" & inventoryitemid & "'"
            qryexecute query
        next
    end sub

	function AppendWD(dlm, base, item)
		if item = "" then
			AppendWD = base
		elseif base <> "" then
			AppendWD = base & dlm & item
		else
			AppendWD = item
		end if
	end function

    function getFilterForList()
        dim statusfilter
        dim criteriafilter

		statusfilter = AppendWD(",", statusfilter, "'UN'")

		if filteropen then statusfilter = AppendWD(",", statusfilter, "'AC'")
		if filternotfound then statusfilter = AppendWD(",", statusfilter, "'NF'")
		if filtervoided then statusfilter = AppendWD(",", statusfilter, "'VO'")
		if filternotreconciled then statusfilter = AppendWD(",", statusfilter, "'NR'")
		if filterclosed then statusfilter = AppendWD(",", statusfilter, "'FI'")

		if filternotinrange then
			criteriafilter = "(meetscriteria <> 0 or (meetscriteria = 0 and InvoiceStatus <> 'NR'))"
		else
			criteriafilter = "(meetscriteria <> 0)"
		end if

		if statusfilter <> "" then
		statusfilter = " InvoiceStatus in (" & statusfilter & ") "
		end if


		getFilterForList = ""
		getFilterForList = AppendWD(" and ", getFilterForList, criteriafilter)
		getFilterForList = AppendWD(" and ", getFilterForList, statusfilter)
		getFilterForList = AppendWD(" and ", getFilterForList, "inventorylistid = " & inventorylistid)

    end function
%>

<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../script/date-picker2.js"></script>
<SCRIPT language="javascript" type="text/javascript">


	var timer = null;

	function resetTimeout() {
		if(timer != null) {
			clearTimeout(timer);
			timer = setTimeout("submitInventoryData();", 1000);
		}
	}

	function submitInventoryData() {
		document.inventoryItem.action = "?useraction=collectinventorydata";
		document.inventoryItem.submit();
	}


	function newInventoryItem() {
	   var InvoiceNumber;
	   var tInvoiceNumber;

	   InvoiceNumber = document.inventoryItem.InvoiceNumber.value;


		tInvoiceNumber = translateInvoiceNumber(InvoiceNumber);

		if(tInvoiceNumber != -1) {
			InvoiceNumber = tInvoiceNumber;
		}


        if(document.inventoryItem.inventoryData.value != "")
        	document.inventoryItem.inventoryData.value += "|";

        document.inventoryItem.inventoryData.value += InvoiceNumber;

        if(timer != null)
        	clearTimeout(timer);

        timer = setTimeout("submitInventoryData();", 1000);

        resetForm();
	}

	function resetForm() {
		document.inventoryItem.InvoiceNumber.value = "";
		document.inventoryItem.InvoiceNumber.focus();
	}

    function reconcileInventory() {
        document.inventoryItem.action = "?useraction=reconcileinventory";
        document.inventoryItem.submit();
    }
    function saveCriteria() {
        document.inventoryItem.action = "?useraction=savecriteria";
        document.inventoryItem.submit();
    }
    function selectSearchCriteria(op) {
        document.inventoryItem.criteriaBegin.value = "";
        document.inventoryItem.criteriaEnd.value = "";
    }

    function captureKeyUpEvent(element) {
   		if (event.keyCode == 13) {

			event.returnValue = true;

			switch(element.name) {
            case "InvoiceNumber":
                newInventoryItem();
			}
		}

	}


	function exitForm() {
        document.inventoryItem.action = "/MainApp/inventoryList.asp"
        document.inventoryItem.submit();
    }

    function removeSelectedItem() {
        document.inventoryItem.action = "?useraction=removeinventoryitem";
        document.inventoryItem.submit();
    }


	function setOrderBy(columnname) {
	   document.inventoryItem.orderby.value = columnname;
        document.inventoryItem.action = "?useraction=setorderby";
        document.inventoryItem.submit();
    }

	function printPage() {

		window.print();

	}


	function viewCFDetails(invoicenumber) {
        document.inventoryItem.action = "CustomerFunctionsTracker.asp?invoicenumber=" + invoicenumber;
        document.inventoryItem.submit();
	}
</SCRIPT>


</HEAD>

<BODY STYLE="margin:0;padding:0" <%if not readonly then%>onload="inventoryItem.InvoiceNumber.focus()"<%end if%>>
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->
<FORM id="inventoryItem" name="inventoryItem" method="post" style="margin:0;padding:0;" onsubmit="return false">

<INPUT type="hidden" name="inventoryData" value="">
<INPUT type="hidden" name="inventorylistid" value="<%=inventorylistid%>">
<INPUT type="hidden" name="orderby" value="<%=orderby%>">
<INPUT type="hidden" name="readonly" value="<%=readonly%>">



<TABLE width=100% cellpadding=0 cellspacing=0 border=0>


<TR>
<%if not readonly then%>
    <TD ALIGN="center">
        Invoice Number:
        <INPUT name="InvoiceNumber" onKeyup="captureKeyUpEvent(this)">
    </TD>
<%end if%>

    <TD align="center">
        <SELECT name="searchcriteria" onchange="selectSearchCriteria(value)">
            <OPTION <%if matchtype = 0 then%>selected<%end if%> value="0">Show All</OPTION>
            <OPTION <%if matchtype = 1 then%>selected<%end if%> value="1">Creation Date</OPTION>
            <OPTION <%if matchtype = 2 then%>selected<%end if%> value="2">Due Date</OPTION>
            <OPTION <%if matchtype = 3 then%>selected<%end if%> value="3">Invoice Number</OPTION>
            <OPTION <%if matchtype = 4 then%>selected<%end if%> value="4">Rack Number</OPTION>
        </SELECT>


        between <INPUT  style="width:80px" name="criteriaBegin" value="<%=matchbegin%>" onClick="javascript:show_calendar('inventoryItem.criteriaBegin');"> and <INPUT style="width:80px" name="criteriaEnd" value="<%=matchend%>" onClick="javascript:show_calendar('inventoryItem.criteriaEnd');">
<%if not readonly then%>
        <INPUT type="button" value="Reconcile" onclick="reconcileInventory()">
<%else%>
		<INPUT type="button" value="Update" onclick="saveCriteria()">
<%end if%>
    </TD>

    <TD>
        <TABLE cellpadding="0" cellspacing="3">
            <TR>
                <TD><INPUT name="filteropen" type="checkbox" <%if filteropen then%>checked<%end if%>>Open</TD>
                <TD><INPUT name="filternotfound" type="checkbox" <%if filternotfound then%>checked<%end if%>>Not Found</TD>
            </TR>
            <TR>
                <TD><INPUT name="filtervoided" type="checkbox" <%if filtervoided then%>checked<%end if%>>Voided</TD>
                <TD><INPUT name="filternotreconciled" type="checkbox" <%if filternotreconciled then%>checked<%end if%>>Not Reconciled</TD>
            </TR>
            <TR>
                <TD><INPUT name="filterclosed" type="checkbox" <%if filterclosed then%>checked<%end if%>>Finished</TD>
                <TD><INPUT name="filternotinrange" type="checkbox" <%if filternotinrange then%>checked<%end if%>>Not In Range</TD>
            </TR>
        </TABLE>
    </TD>
</TR>



<TR><TD colspan="3">

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<%if not readonly then%><BUTTON type="button" style="margin-right:50px;" onclick="removeSelectedItem()">Remove</BUTTON><%end if%>
	</SPAN>
	<SPAN style="float:right">
        <%if not readonly then%><BUTTON type="button" onclick="printPage()">Print</BUTTON><%end if%>
		<BUTTON type="button" onclick="exitForm()">Exit</BUTTON>
	</SPAN>
</DIV>	

</TD></TR>
<TR><TD colspan="3">
<TABLE  align=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0>
    <TR style="background:#DDD;padding-bottom:7px;padding-top:7px">
        <%if not readonly then%><TH>&nbsp;</TH><%end if%>
        <TH align="left"><A style="text-decoration:none;color:black;" href="javascript:setOrderBy('invoicenumber')">Invoice</A></TH>
        <TH align="left"><A style="text-decoration:none;color:black;" href="javascript:setOrderBy('customername asc')">Customer</A></TH>
        <TH align="left"><A style="text-decoration:none;color:black;" href="javascript:setOrderBy('invoicestatus asc')">Status</A></TH>
        <TH align="left" style="width:100px"><A style="text-decoration:none;color:black;" href="javascript:setOrderBy('racklocation')">Rack</A></TH>
        
        <TH align="left"><A style="text-decoration:none;color:black;" href="javascript:setOrderBy('customerphone asc')">Phone</A></TH>
        <TH align="left"><A style="text-decoration:none;color:black;" href="javascript:setOrderBy('invoicedepartment asc')">Department</A></TH>
        <TH align="right"><A style="text-decoration:none;color:black;" href="javascript:setOrderBy('invoicepieces asc')">Pieces</A></TH>
        <TH align="right"><A style="text-decoration:none;color:black;" href="javascript:setOrderBy('invoicetotal asc')">Total</A></TH>
    </TR>

<%
	dim totalValue
	dim totalPieces
	
    query = "select * from inventoryitem "
    query = query & " where " & getFilterForList()

    select case orderby
    case "racklocation"
    	query = query & " order by case dbo.isint(racklocation) when 1 then cast(racklocation as int) else -1 end "
    case "invoicenumber"
    	query = query & " order by case dbo.isint(invoicenumber) when 1 then cast(invoicenumber as int) else -1 end "
    case else
    	query = query & " order by " & orderby
    end select
    
    set rs = getdisconnectedrecordset(query)
    
    totalValue = 0
    totalPieces = 0
    
    while not(rs.eof or rs.bof)
%>
    <TR <%if rs("meetscriteria") = -1 then%>style="background:lightgreen"<%end if%> > 
        <%if not readonly then%><TD><INPUT type="checkbox" name="selectedInventoryItemId" value="<%=rs("inventoryitemid")%>"></TD><%end if%>
        <TD style="font-size:12" align="left" style="cursor:pointer;" onclick="viewCFDetails(<%=rs("invoicenumber")%>)"><%=rs("invoicenumber")%></TD>
        <TD style="font-size:12" align="left" style="cursor:pointer;" onclick="viewCFDetails(<%=rs("invoicenumber")%>)"><%=rs("customername")%></TD>
        <TD style="font-size:12" align="left">
        <%
           
            select case lcase(rs("invoicestatus"))
            case "ac"  response.write "Open"
            case "vo"  response.write "Voided"
            case "fi"  response.write "Finished"
            case "un"  response.write "Unknown"
            case "nf"  response.write "Not Found"
            case "nr"  response.write "Not Reconciled"
            end select

            if rs("meetscriteria") = 0 then
                response.write ", Not In Range"
            end if
            
        %>
        </TD>

        <TD style="font-size:12" align="left" style="width:100px"><%=rs("racklocation")%></TD>
        <TD style="font-size:12" align="left"><%=rs("customerphone")%></TD>
        <TD style="font-size:12" align="left"><%=rs("invoicedepartment")%></TD>
        <TD style="font-size:12" align="right"><%=rs("invoicepieces")%></TD>
        <TD style="font-size:12" align="right"><%=formatcurrency(rs("invoicetotal"))%></TD>
    </TR>
<%

		totalPieces = totalPieces + rs("invoicepieces")
		totalValue = totalValue + rs("invoicetotal")
		
        rs.movenext
    wend
    
    set rs = nothing
%>

    <TR> 
        <%if not readonly then%><TD></TD><%end if%>
        <TD colspan="6" style="font-size:12" align="left"><STRONG>Total</STRONG></TD>
        <TD style="font-size:12" align="right"><%=totalPieces%></TD>
        <TD style="font-size:12" align="right"><%=formatcurrency(totalValue)%></TD>
    </TR>
</TABLE>
</TD></TR>
</TABLE>
</FORM>
</BODY>
</HTML>
