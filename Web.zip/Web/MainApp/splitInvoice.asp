<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim ticketnumber
	dim invoicenumber
	
	ticketnumber = getReqVar("ticketnumber")
	if ticketnumber = "" then ticketnumber = 0
	invoicenumber = getInvoiceNumberFromTicket(ticketnumber)
	
	select case lcase(request.querystring("useraction"))
	case "split"
		doSplit
		response.redirect "/mainapp/customerfunctions.asp?customerseq=" & session("customersequencenumber")
	end select
	
	function doSplit()
		dim lineItemNumber
		dim lineInvoiceNumber
		dim origInvoiceNumber
		dim newInvoiceNumber
		dim conveyorType

		if isTicketHeatSealEnabled(ticketnumber) then
			conveyorType = getMSVar("conveyorType")
		else
			conveyorType = ""
		end if

		newInvoiceNumber = ""
		
		for each lineItemNumber in request.form("lineItemNumbers")
			lineInvoiceNumber = request.form("lineInvoiceNumber_" & lineItemNumber)
			origInvoiceNumber = request.form("origInvoiceNumber_" & lineItemNumber)
			
			if trim(lineInvoiceNumber) <> trim(origInvoiceNumber) then
				if origInvoiceNumber = "" then
					origInvoiceNumber = invoicenumber
				end if
				
				if trim(invoicenumber) = trim(lineInvoiceNumber) then
					lineInvoiceNumber = ""
				end if
			
				if lineInvoiceNumber = "new" then
					if newInvoiceNumber = "" then
						newInvoiceNumber = getNewInvoiceNumber(invoicenumber)
					end if
					
					
					
					updateLineInvoiceNumber ticketnumber, lineItemNumber, newInvoiceNumber
					
					select case conveyorType
					case "MP"
						updateConveyorMP getHeatSealID(ticketnumber, lineItemNumber), origInvoiceNumber, newInvoiceNumber
					end select
				else
					updateLineInvoiceNumber ticketnumber, lineItemNumber, lineInvoiceNumber
					
					select case conveyorType
					case "MP"
						updateConveyorMP getHeatSealID(ticketnumber, lineItemNumber), origInvoiceNumber, lineInvoiceNumber
					end select
					
				end if
			end if
		next

	end function
	
	function isTicketHeatSealEnabled(ticketNumber)
		dim query, rs
		
		isTicketHeatSealEnabled = false
		
    query = "exec dbo.isHeatSealDept " & ticketNumber
    set rs = getdisconnectedrecordset(query)
    
    If rs.recordcount > 0 Then
        isTicketHeatSealEnabled = rs("Result")
    End If
    
    set rs = nothing
	end function
	
	function updateConveyorMP(heatseal, origInvoiceNumber, invoiceNumber)
		dim query, rs
		
		query = " exec SplitGarmentFromTicketMP '" & heatseal & "', '" & origInvoiceNumber & "', '" & invoiceNumber & "'"

		qryexecute query
	
	end function
	
	function updateLineInvoiceNumber(ticketNumber, lineNumber, invoiceNumber)
		dim query, rs

		query = " update ticketlineitem set invoicenumber = '" & invoiceNumber & "'"
		query = query & " where ticketnumber = " & ticketNumber
		query = query & " and lineItemNumber = " & lineNumber

		qryexecute query
	end function
	
	function invoiceNumberExists(invoiceNumber)
		dim query, rs
		
		query = " select 1 from ticket where invoicenumber = '" & trim(invoiceNumber) & "'"
		set rs = getdisconnectedrecordset(query)

		invoiceNumberExists = (rs.recordcount > 0)
		
		if not invoiceNumberExists then
			set rs = nothing
			
			query = " select 1 from ticketlineitem where invoicenumber = '" & trim(invoiceNumber) & "'"
			set rs = getdisconnectedrecordset(query)
	
			invoiceNumberExists = (rs.recordcount > 0)
		end if
		
		set rs = nothing 
	end function

	private function createSuffix(value)
		dim alphabit
		dim result
		dim base : base = 26
		dim n : n = value
		
		alphabit = "abcdefghijklmnopqrstuvwxyz"

		while n > 0
			result = mid(alphabit, (n mod base) + 1, 1) & result
			n = n \ base
		wend

		createSuffix = result
	end function
	
	function getNewInvoiceNumber2(invoiceNumber)
		dim i

		i = 1

		while invoiceNumberExists(invoiceNumber & createSuffix(i))
			i = i + 1
		wend

		getNewInvoiceNumber2 = invoiceNumber & createSuffix(i)
	end function

	
	function getNewInvoiceNumber(origInvoiceNumber)
		dim query, rs
		dim invoiceNumber
		dim storeID
		
		storeID = session("storeid")
		
		query = "exec dbo.GenerateInvoiceNumber " & storeID
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			invoiceNumber = rs("invoicenumber")
			query = "exec dbo.CommitInvoiceNumber " & storeID & ", '" & invoiceNumber & "'"
			qryexecute query
		end if

		getNewInvoiceNumber = invoiceNumber
	end function
	
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	function getInvoiceNumberFromTicket(ticketNumber)
		dim query, rs

		if ticketNumber <> "" then
			query = " select invoicenumber from ticket where ticketnumber = " & ticketNumber
			set rs = getdisconnectedrecordset(query)
	
			if rs.recordcount > 0 then
				getInvoiceNumberFromTicket = rs("invoicenumber")
			end if
	
			set rs = nothing
		end if
	end function
	
	function getHeatSealID(ticketNumber, lineItemNumber)
		dim query, rs
		dim result
		
		query = " select taggedpiece.heatsealid "
		query = query & " from taggedpiece "
		query = query & " inner join ticketlineitemtaggeditem on taggedpiece.taggeditemid = ticketlineitemtaggeditem.taggeditemid "
		query = query & " where ticketlineitemtaggeditem.ticketnumber = " & ticketNumber
		query = query & " and ticketlineitemtaggeditem.lineitemnumber = " & lineItemNumber
		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
			if result <> "" then result = result & ","
			result = result & rs("heatsealid")
			rs.movenext
		wend
		
		set rs = nothing
	
		getHeatSealID = result
	end function
	
	function getDescriptors(ticketNumber, lineItemNumber)
		dim query, rs
		dim result
		
		query = " select lineItemName "
		query = query & " from ticketlineitem "
		query = query & " where ticketNumber = " & ticketNumber
		query = query & " and parentLineNumber = " & lineItemNumber
		
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
			if result <> "" then result = result & ","
			result = result & rs("lineItemName")
			rs.movenext
		wend
		
		set rs = nothing
	
		getDescriptors = result
	end function
	
	function getInvoiceListFromTicket(ticketnumber, invoicenumber)
		dim query, rs
		dim result
		
		query = " select distinct invoicenumber "
		query = query & " from ticketlineitem "
		query = query & " where ticketnumber = " & ticketnumber
		query = query & " and invoicenumber <> ''"
		query = query & " and invoicenumber <> '" & invoicenumber & "'"
		
		set rs = getdisconnectedrecordset(query)
		
		result = ""
		while not(rs.eof or rs.bof)
			if result <> "" then result = result & ","
			result = result & rs("invoicenumber")
			rs.movenext
		wend
		
		set rs = nothing
		
		getInvoiceListFromTicket = result
	end function
	
	function dropDownOptions(optionlist, default)
		dim opArr
		dim i
		dim result
		
		opArr = split(optionlist, ",")
		
		for i = lbound(opArr) to ubound(opArr)
			
			
			if trim(opArr(i)) = trim(default) then
				result = result & "<option selected value=""" & opArr(i) & """>"
			else
				result = result & "<option value=""" & opArr(i) & """>"
			end if
			
			result = result  & server.htmlencode(opArr(i)) & "</option>"
		next
		
		dropDownOptions = result
	end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function
%>

<HTML>
<HEAD>
<TITLE>Split Invoice</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script type="text/javascript">
	
	function SetRowCheckedStatus(row, check, value) {
				
		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var elChecked = false;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "chkLineItem") {
				elChecked = !(childEl.children[0].checked);
				SetRowCheckedStatus(r, childEl.children[0], elChecked, false);
				break;
			}
			else if (childEl.name == "chkLineItem") {
				elChecked = !(childEl.checked);
				SetRowCheckedStatus(r, childEl, elChecked, false);
				break;
			}
		}
		
		if(elChecked) {
			$("#lineInvoiceNumber_" + r.lineitemnumber).val("new");
		}
		else
		{
			$("#lineInvoiceNumber_" + r.lineitemnumber).val($("#origInvoiceNumber_" + r.lineitemnumber).val());

		}
	}
	
	function cancel() {
		document.splitInvoice.action = "/mainapp/customerfunctions.asp?customerseq=<%=session("customersequencenumber")%>";
		document.splitInvoice.submit();
	}
	
	function beginSplit() {
	    cbs_confirm("Are you sure you want to create a new invoice for these items?", doSplit);
	}

	function doSplit() {
        clearConfirmMsg();
	    document.splitInvoice.action = "?useraction=split";
        document.splitInvoice.submit();
	}
</script>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Split Invoice <%=invoicenumber%></H1>
	<FORM id="splitInvoice" name="splitInvoice"  method="post" onsubmit="return false">
	
	<input type="hidden" name="ticketnumber" value="<%=ticketnumber%>" >
		
	
	<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
		<SPAN style="float:left">
	
		</SPAN>
		<SPAN style="float:right">
			<BUTTON onclick="beginSplit()">Split</BUTTON>
	    <BUTTON onclick="cancel()">Cancel</BUTTON>
		</SPAN>
	</DIV>	

		<table class="itable" cellspacing="0" cellpadding="0">
			<tr>
				<th style="width:50px">&nbsp;</th>
				<th style="width:100px">Invoice</th>
				<th>Heat Seal</th>
				<th>Item Name</th>
				<th>Descriptors</th>
			</tr>
		<%
			dim invoicelist
			invoicelist = getInvoiceListFromTicket(ticketnumber, invoicenumber)
			if invoicelist <> "" then
				invoicelist = "," & invoicelist & "," & invoicenumber & ",new"
			else
				invoicelist = "," & invoicenumber & ",new"
			end if
			
			
			query = " select * from ticketlineitem "
			query = query & " where ticketnumber = " & ticketnumber
			query = query & " and ticketlinetype in ('it', 'ac') "

			set rs = getdisconnectedrecordset(query)
			
			
			while not(rs.eof or rs.bof)
		%>
		
			<tr lineitemnumber="<%=rs("lineItemNumber")%>">
				<TD align="center"><INPUT type="hidden" onclick="ToggleRowChecked(this.parentNode.parentNode);" name="chkLineItem"></TD>
				<td>
					<input type="hidden" name="lineItemNumbers" value="<%=rs("lineItemNumber")%>">
					<input type="hidden" name="origInvoiceNumber_<%=rs("lineItemNumber")%>" id="origInvoiceNumber_<%=rs("lineItemNumber")%>" value="<%=rs("invoicenumber")%>">
					<select name="lineInvoiceNumber_<%=rs("lineItemNumber")%>" id="lineInvoiceNumber_<%=rs("lineItemNumber")%>"><%=dropDownOptions(invoicelist, rs("invoicenumber"))%></select>
				</td>
				<td onclick="ToggleRowChecked(this.parentNode);"><%=Server.HTMLEncode(getHeatSealID(ticketnumber, rs("lineItemNumber")))%>&nbsp;</td>
				<td onclick="ToggleRowChecked(this.parentNode);"><%=Server.HTMLEncode(rs("lineitemname"))%></td>
				<td onclick="ToggleRowChecked(this.parentNode);"><%=Server.HTMLEncode(getDescriptors(ticketnumber, rs("lineItemNumber")))%></td>
			</tr>
		
		<%
				rs.movenext
			wend
		%>
		</table>
	</FORM>
</body>
</HTML>
