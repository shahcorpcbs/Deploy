<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	Dim rsResults
	Dim bNothingToPrint
	
	Dim ps, sps
	
	ps = Request.QueryString("ps")
	if ps = "" then
		ps = "0"
	end if
	
	select case ps
		case "0"
			sps = ""
		case "1"
			sps = "Found"
		case "2"
			sps = "Not Found"
		case "3"
			sps = "Out of Specified Range"
		case "4"
			sps = "Not Reconciled"
		case else
			
	end select
	'Response.Write( ps & "<BR>" & sps & "<BR>")
	'Response.Write(ps)
	bNothingToPrint = False
	
	if IsObject(Session("inventoryelements")) and not Session("inventoryelements") is nothing then
		Set rsResults = Session("inventoryelements")
	else
		Set rsResults = nothing
	end if
	
	if not rsResults  is nothing then
		if sps <> "" then
			rsResults.Filter = "status = '" & sps & "'"
		end if
	end if
	if not rsResults is nothing then
		if rsResults.RecordCount > 0  then
			bNothingToPrint = false
		else
			bNothingToPrint = true	
			rsResults.Filter = ""
		end if
	else
		bNothingToPrint = True
	end if
	
	
	
%>
<%
if not bNothingToPrint then
%>

<HTML>
<HEAD>
<SCRIPT language="javascript">
	function PrintAndClose() {
		window.print();
		setTimeout('window.close();', 1000);
		
	}
</SCRIPT>

<STYLE>
	BODY {
		font-family : Arial, Verdana;
		font-size : 12px;
	}
	H2 {
		font-family : Arial, Verdana;
	}
	TD {
		font-family : Arial, Verdana;
		font-size : 12px;
	}
	TD.Heading {
		font-weight : bold;
	}
</STYLE>
</HEAD>
<BODY onLoad="javascript:PrintAndClose();">
<H2 STYLE="text-align:center;">Inventory Search Results</H2>
<TABLE BGCOLOR="#CCCCCC"BORDER=0 CELLSPACING=1 CELLPADDING=3 WIDTH="99%" ALIGN="CENTER">
	<TR>
		<TD class="Heading">Status</TD>
		<TD class="Heading">Invoice No.</TD>
		<TD class="Heading">Invoice Date</TD>
		<TD class="Heading">Customer Name</TD>
		<TD class="Heading">Phone No.</TD>
		<TD class="Heading">Ticket Status</TD>
		<TD class="Heading">Rack Location</TD>
	</TR>
	<%
	
	rsResults.MoveFirst
	while Not rsResults.EOF
	%>
	<!--
		rstInventory.Fields("Customername") = ""
		rstInventory.Fields("rackLocation") = ""
		rstInventory.Fields("TicketStatus") = ""
		rstInventory.Fields("InvoiceNumber") = sInvoice
		rstInventory.Fields("status") = "Not Found"
	-->
	<TR>
		<TD BGCOLOR="#FFFFFF"><%= rsResults("Status").Value %></TD>
		<TD BGCOLOR="#FFFFFF"><%= rsResults("InvoiceNumber").Value %></TD>
		<TD BGCOLOR="#FFFFFF"><%= rsResults("invoiceDate").Value %></TD>
		<TD BGCOLOR="#FFFFFF"><%= rsResults("CustomerName").Value %></TD>
		<TD BGCOLOR="#FFFFFF"><%= rsResults("customerPhone").Value %></TD>
		<TD BGCOLOR="#FFFFFF"><%= rsResults("TicketStatus").Value %></TD>
		<TD BGCOLOR="#FFFFFF"><%= rsResults("rackLocation").Value %></TD>


	</TR>
	<%
	rsResults.MoveNext
	Wend
	
	rsResults.Filter = ""
	
	
	%>
</TABLE>

</BODY>
</HTML>

<%
else
%>
<!-- This is when Nothing is there to print.. -->
<HTML>
<HEAD>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<SCRIPT language = "JavaScript">
	function FixWindowSize() {
		window.resizeTo(320,180);
	}
</SCRIPT>
<TITLE>Print Inventory Search Results</TITLE>
</HEAD>
<BODY onLoad="javascript:FixWindowSize();">

<TABLE BORDER=0 WIDTH="100%" ALIGN="CENTER" VALIGN="middle">
	<TR><TH style="font-size:13px;">There are no rows to print</TH></TR>
	<TR><TD ALIGN="center">&nbsp;<BR><A STYLE="text-decoration:underline;" href="javascript:window.close();">Close Window</A></TD></TR>
</TABLE>

</BODY>
</HTML>
	
<%
end if
set rsResults = nothing
%>