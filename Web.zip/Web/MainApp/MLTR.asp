<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->

<%
	select case lcase(Request.QueryString("useraction"))
	case "releaselicense"
		releaseLicense
		Response.Redirect "/mainapp/start2.asp"
	case "releasealllicenses"
		releaseAllLicenses
		Response.Redirect "/mainapp/start2.asp"
	end select


	function releaseLicense()
		dim query
		
		query = " delete from clientterminal "
		query = query & " where clientterminalid in "
		query = query & " (select top 1 clientterminalid from clientterminal "
		query = query & " order by lastseen asc)"
		
		qryexecute query
	end function
	
	function releaseAllLicenses()
		dim query
		
		query = " delete from clientterminal "

		qryexecute query
	end function
%>

<HTML>
<HEAD>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">


</HEAD>
<BODY topmargin=0 leftmargin=0><!-- #include file="../include/banner.inc" -->


<script language="JavaScript">
	function ExitApplication() {
		document.getElementById('ExitForm').submit();
		//window.setTimeout("window.close()", 100);
	}
	function ReleaseLicense() {
		document.ExitForm.action = "?useraction=releaselicense"
		document.ExitForm.submit();
	}
	
	function ReleaseAllLicenses() {
		document.ExitForm.action = "?useraction=releasealllicenses"
		document.ExitForm.submit();
	}
</script>
<FORM name="ExitForm" ID="ExitForm" METHOD="POST" ACTION="/mainapp/exit.asp"></FORM>




	<TABLE WIDTH=500 STYLE="BACKGROUND-COLOR:
	 #2F4F4F" ALIGN=center BORDER=0 CELLSPACING=1 CELLPADDING=5>
		<TR>
			<TH BGCOLOR="#2F4F4F" STYLE="COLOR: #ffffff" COLSPAN="2" >License Error</TD>
		</TR>

		<TR>
			<TD STYLE="BACKGROUND-COLOR: #f7fbfc;color:#ff2222;padding-top:10px;padding-bottom:10px;text-align:center;vertical-align:middle;" COLSPAN="2" >
			You do not have enough client licenses to access this application from this terminal.
			Please contact Shah Corp., to buy additional licenses.

			</TD>
			
		</TR>
			<TD align="center">
			<input type="button" value="Release Single License" onclick="ReleaseLicense()" />
			<input type="button" value="Release All Licenses" onclick="ReleaseAllLicenses()" />
			</TD>
		<TR>
			
		</TR>
	</TABLE>

</BODY>
</HTML>
