<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim l_StartDate
	dim l_EndDate
	dim paramStatus
	dim l_terminalID
	dim l_terminalName
	dim userAction 
	dim l_storeID
	dim l_cashOutID
	dim l_employeeID
	dim l_employeeName
	dim cashOutRst
	dim l_reportID
	dim isSubmitted
	
	isSubmitted = Request.QueryString("Submitted")
	
	if isSubmitted then
		updateReportParams()
	end if	
	
	l_storeID = session("storeID")
	l_reportID = 39
	
	If GetReportParams(l_reportid, True, "", 0)= "NEW" Then
	End	if	
	
	l_employeeID = clng(Request.Form("selEmployeeID"))
	l_terminalID = clng(Request.Form("selTerminalID"))
	l_cashoutID = clng(Request.Form("selCashoutID"))

	
	function GetTerminalDropDown(storeID)

		dim	strDropDownTag
		dim	objRSTerminal
		dim	strSQL
	
		strDropDownTag = "<SELECT id='terminalID' name=terminalID onChange=""retrieveTerminal();"">"
														
		'on	error resume next

		if storeID <> "" then
			strSQL = "SELECT terminalID, rtrim(name) as name, storeID FROM	Terminal" &	_
				  "	WHERE storeID =	" &	storeID	& _
				  "	ORDER BY name"
	
			set	objRSTerminal =	getDisconnectedRecordset(strSQL)

			While not objRSTerminal.EOF
				if l_terminalID = 0 then
					l_terminalID = clng(objRSTerminal("terminalId"))
				end if	
				if l_terminalID = objRSTerminal("terminalId").value then
					strDropDownTag = strDropDownTag	& "<OPTION SELECTED VALUE= "	& objRSTerminal("terminalId") &	 ">" & _
							 objRSTerminal("name") & "</OPTION>"
				else
					strDropDownTag = strDropDownTag	& "<OPTION VALUE= "	& objRSTerminal("terminalId") &	 ">" & _
							 objRSTerminal("name") & "</OPTION>"
				end if			 
				objRSTerminal.MoveNext
			Wend
		end	if
	
		strDropDownTag = strDropDownTag	& "</SELECT>"

		GetTerminalDropDown	= strDropDownTag
	
	end	function	

	function GetEmployeeDropDown()
	
		dim	strDropDownTag
		dim	objRSEmployee
		dim	strSQL
	
		strDropDownTag = "<SELECT id='employeeID' name=employeeID onchange=""retrieveEmployee();""> "
							
		' As long an option	to select all is there,	we don't care if there is an error.
		'on error resume	next
		
		strSQL = "Select employeeid, employeeName from employee where employeestatus = 'A' and storeID =" & l_storeID

		strSQL = strSQL	& "	ORDER BY employeeName"
	
		set	objRSEmployee =	getDisconnectedRecordset(strSQL)

		While not objRSEmployee.EOF
			if l_employeeID = 0 then
				l_employeeID = clng(objRSEmployee("employeeID"))
			end if	
			if l_employeeID = objRSEmployee("employeeID").value then
				strDropDownTag = strDropDownTag	& "<OPTION SELECTED VALUE= "	& objRSEmployee("employeeId") &	 ">" & _
						 objRSEmployee("employeeName") & "</OPTION>"
			else			 
				strDropDownTag = strDropDownTag	& "<OPTION VALUE= "	& objRSEmployee("employeeId") &	 ">" & _
						 objRSEmployee("employeeName") & "</OPTION>"
			end if			 
			objRSEmployee.MoveNext
		Wend

		strDropDownTag = strDropDownTag	& "</SELECT>"

		GetEmployeeDropDown	= strDropDownTag
	
	end	function

	function GetDateDropDown()

		dim	strDropDownTag
		dim	objRSDate
		dim	strSQL
	
		strDropDownTag = "<SELECT id='cashOutID' name=cashOutID onChange=""retrieveCashout();"">"
									
		'on	error resume next
		if l_employeeid <> 0 and l_terminalID <> 0 then		
			strSQL = "SELECT cashOutID, convert(varchar,dateRan,100) as dateRan FROM Cashout" &	_
			  "	WHERE employeeID = " & l_employeeID	& _
			  " AND terminalID = " & l_terminalID & _
			  "	ORDER BY cast(dateRan as datetime)"
		end if	  		  
 
		set	objRSDate =	getDisconnectedRecordset(strSQL)

		While not objRSDate.EOF	
			if l_cashoutID = 0 then
				l_cashoutID = clng(objRSDate("cashOutID"))	
			end if	
			if l_cashoutID = objRSDate("cashOutID").value then
				strDropDownTag = strDropDownTag	& "<OPTION SELECTED VALUE= "	& objRSDate("cashOutID") & ">" & _
				 objRSDate("dateRan") & "</OPTION>"
			else	 
				strDropDownTag = strDropDownTag	& "<OPTION VALUE= "	& objRSDate("cashOutID") & ">" & _
				 objRSDate("dateRan") & "</OPTION>"
			end if	 
			objRSDate.MoveNext
		Wend	

		strDropDownTag = strDropDownTag	& "</SELECT>"

		GetDateDropDown	= strDropDownTag
	
	end	function		
	
	function updateReportParams()
		dim	objRSCashOut
		dim	strSQL
	
		If Request.Form("cashOutID") <> "" then
		
			strSQL = "select * from	cashout	where cashoutID	= "	& Request.Form("cashOutID")
		
			set	objRSCashOut = getDisconnectedRecordset(strSQL)
		
			While not objRSCashOut.EOF
				Session("objRP").rangeStartDate	= objRSCashOut("startDate")
				Session("objRP").rangeEndDate =	objRSCashOut("endDate")
				Session("objRP").terminalID	= objRSCashOut("terminalID")
				Session("objRP").employeeID	= objRSCashOut("employeeID")
				Session("objRP").cashoutID = Request.Form("cashOutID")
				Session("objRP").rangeStartAmount =	objRSCashOut("startingAmount")			
				Session("objRP").nbrOf1cents = objRSCashOut("pennies")		
				Session("objRP").nbrOf5cents = objRSCashOut("nickels")
				Session("objRP").nbrOf10cents = objRSCashOut("dimes")
				Session("objRP").nbrOf25cents = objRSCashOut("quarters")
				Session("objRP").nbrOf1Dollars = objRSCashOut("ones")
				Session("objRP").nbrOf5Dollars = objRSCashOut("fives")
				Session("objRP").nbrOf10Dollars	= objRSCashOut("tens")
				Session("objRP").nbrOf20Dollars	= objRSCashOut("twenties")
				Session("objRP").nbrOf50Dollars	= objRSCashOut("fifties")
				Session("objRP").nbrOf100Dollars = objRSCashOut("hundreds")
				Session("objRP").checkAmount = objRSCashOut("checkAmt")
				Session("objRP").ccAmount =	objRSCashOut("creditCardAmt")
				Session("objRP").tradeAmount = objRSCashOut("tradeAmt")
				Session("objRP").couponAmount =	objRSCashOut("couponAmt")
				Session("objRP").endingAmount = objRSCashOut("endingAmount")
				objRSCashout.moveNext
			wend
			objRSCashOut.close
			Response.Redirect("overrideCashoutZParams.asp")
		End if	
	end function
	
%>
<HTML>
<HEAD>
<TITLE>Override Cashout Z</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function submitForm() {
		document.cashOutForm.action = "?Submitted=true";
		document.cashOutForm.submit();
	}
	
	function closeForm() {
		document.cashOutForm.action = "managermenu.asp";
		document.cashOutForm.submit();
	}
	
	function retrieveEmployee() {
	var x;
		x = document.getElementById("employeeID").selectedIndex;
		if (x >= 0){
			document.getElementById("selEmployeeID").value = document.getElementById("employeeID").options[x].value;
			document.cashOutForm.submit();
		}
	}
	
	function retrieveTerminal() {
	var x;
		x = document.getElementById("terminalID").selectedIndex;
		if (x >= 0){
			document.getElementById("selTerminalID").value = document.getElementById("terminalID").options[x].value;
			document.cashOutForm.submit();
		}
	}
	
	function retrieveCashout() {
	var x;
		x = document.getElementById("cashOutID").selectedIndex;
		if (x >= 0){
			document.getElementById("selCashoutID").value = document.getElementById("cashOutID").options[x].value;
			document.cashOutForm.submit();
		}
	}	
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0 
	<% if trim(Request.QueryString("useraction")) <> "" then %>
		onLoad="captureOnBlur('')" 
	<% end if %>
>
<!-- #include file="../include/banner.inc" -->
<H1>Override CashOut Z Values </H1>

	<TABLE ALIGN=center WIDTH="800px" BORDER=0 CELLPADDING=1 >
	<FORM id="cashOutForm" name="cashOutForm" action="" method="POST" onload="">

		<input type="hidden" id="reportID" name="reportID" value="<%= l_reportID %>">
		<input type="hidden" id="storeID" name="storeID" value="<%= l_storeID %>">
		<input type="hidden" id="selTerminalID" name="selTerminalID" value="<%= l_terminalID%>">
		<input type="hidden" id="selEmployeeID" name="selEmployeeID" value="<%= l_employeeID%>">
		<input type="hidden" id="selCashoutID" name="selCashoutID" value="<%= l_cashoutID%>">
			<tr height=100px><td></td></tr>
			<tr height=30px>
				<td width = 40% class = "label"  align=right Style="Font-weight=normal">Terminal: </td>
				<td align=left ><B> &nbsp;<%= GetTerminalDropDown(l_storeid) %> </b>
				</td>
				<td rowspan=18>
					<INPUT class=touchnoborder id=ok name=ok type=button value="" onClick="submitForm()"
						style="background-image:url(../images/Ok.gif);"><br><br>
					<INPUT class=touchnoborder id=close name=close type=button value="" onClick="closeForm();" 
						style="background-image:url(../images/Cancel.gif);">
				</td>
			</tr>

			<tr height=30px>
				<td width = 30% class = "label"  align=right Style="Font-weight=normal" >Employee: </td>
				<td align=left > <b>&nbsp;<%= GetEmployeeDropDown()%></b>
				</td>
			</tr>

			<tr height=30px>
				<td width = 30% class = "label"  align=right Style="Font-weight=normal">Date: </td>
				<td align=left > <b>&nbsp<%= GetDateDropDown()%></b>
				</td>

			</tr>
</form>
</table>
</BODY>
</HTML>
