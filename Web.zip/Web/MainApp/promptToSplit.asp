<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim ObjMiscSetUp
	dim autoInvNos
	dim deptStartIndex
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim targetPage, originatingPage
	
	if IsObject(Session("miscSetUp")) then
		set ObjMiscSetUp = Session("miscSetUp")
	else
		set ObjMiscSetUp = Server.CreateObject("Scripting.Dictionary")	
	end if
	if ObjMiscSetUp.Count > 0 then
		autoInvNos = ObjMiscSetUp.Item("useAutomaticInvoiceNumbers")
		if autoInvNos then
			autoInvNos ="1"
		else
			autoInvNos ="0"
		end if
	else
		autoInvNos = "0"
	end if	
	curr_LineNo = Request.QueryString("lineNo")
	selectedDept = Request.QueryString("dept")
	itemsStartIndex = Request.QueryString("itIndex")
	upChargeStartIndex = Request.QueryString("upIndex")
	colorsStartIndex = Request.QueryString("cIndex")
	patternStartIndex = Request.QueryString("pIndex")
	addOrEdit = Request.QueryString("addOrEdit")
	'dueDateSet = Request.QueryString("isDueDateSet")
	'targetPage = Request.QueryString("targetPage")
	deptStartIndex = Request.QueryString("deptIndex")
	selItemId = Request.QueryString("selItemId")
	selUpchargeValue = Request.QueryString("selUp")
	selColorValue = Request.QueryString("selColor")
	selPatternValue = Request.QueryString("selPattern")	
	targetPage = Request.QueryString("targetPage")
	originatingPage = Request.QueryString("originPage")
%>
<HTML>
<HEAD>
<TITLE>Prompt To Split</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(userAction) {
		var autoInvNos
		var addOrEdit
		var targetPage;
		
		addOrEdit = document.splitPrompt.addOrEdit.value;
		autoInvNos = document.splitPrompt.autoInvNos.value;
		targetPage = document.splitPrompt.tPage.value;
		if (userAction == "yes") {
			switch (targetPage) {
				case "detail":
					document.splitPrompt.action = "detailedInvoice.asp?userAction=split";
					break;
				case "counterSale":
					document.splitPrompt.action = "counterSale.asp?userAction=split";
					break;
			}
			
		}else{
			
				switch (targetPage) {
					case "detail":
						document.splitPrompt.action = "detailedInvoice.asp?userAction=nosplit";
						break;
					case "counterSale":
						document.splitPrompt.action = "counterSale.asp?userAction=nosplit";
						break;
				}
						
			
		}
		document.splitPrompt.submit();
	}
</script>
<BODY topmargin=0 leftmargin=0>
	<!-- #include file="../include/banner.inc" -->
<TABLE ALIGN=center WIDTH="250px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
	<FORM id="splitPrompt" name="splitPrompt" action="promptToSplit.asp" method="post">
		<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
		<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
		<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
		<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
		<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
		<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
		<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
		<INPUT type="hidden" name="onHold" value="0">
		<INPUT type="hidden" name="tPage" value="<%= targetPage%>">
		<INPUT type="hidden" name="autoInvNos" value="<%= autoInvNos%>">
		<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
		<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
		<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
		<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
		<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
		<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
		<tr height=100px><td></td></tr>
		<tr>
			<td class=label colspan=2> Do you want to split the invoices?
			</td>
		</tr>
		<tr height=10px><td></td></tr>
		<tr>
			<td align="center" width="80px">
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/yes.gif);" onClick= "submitForm('yes')">
			</td>
			<td align="center" width="80px">
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/no.gif);" onClick="submitForm('no')">
			</td>
		</tr>
		
	</form>
</table>
</BODY>
</HTML>
