<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim ccprocessor
	
	set ccprocessor = Server.CreateObject("ShahcorpComponents.creditCardProcessing")
	

	if trim(batchid) = "" then batchid = getLastBatchID()
	if trim(hasrefreshed) = "" then hasrefreshed = false
	
	function getMSVar(id)
		dim query, rs
		
		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)
		
		set rs = nothing
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Credit Card Review</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="">

<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/localprinter.inc" -->


<FORM id="creditCardReview" name="creditCardReview" action="creditCardReview.asp" method="post">


</FORM>
</BODY>
</HTML>
