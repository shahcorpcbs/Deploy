<%@ Language=VBScript %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/messages.asp" -->

<%
	''	If the session is timed out, this will set the storeid
    ''   and terminal id to session again.
%>


<!-- #include file="../include/SystemStartup.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim validLogin
	validLogin = true

	if Request.Form("password") <> "" then
		dim userID
		dim password

		userID = Request.Form("accessCode")
		password = Request.Form("password")

		dim loginRs
		dim loginEmployeeID


		set loginRs = getDisconnectedRecordset("SELECT employeeID, employeeName FROM Employee WHERE employeePassword = '" & password & "' AND employeeStatus = 'A'")
		if loginRs is nothing or loginRs.EOF then
			validLogin = false
		else
			loginRs.MoveFirst
			if not loginRs.EOF then
				loginEmployeeID = loginRs("employeeID")
				Session("employeeID") = loginEmployeeID
				Session("employeeName") = loginRs.Fields("employeeName")
				'Check employee permissions
				'Following include file will redirect to /MainApp/AccessDenied.asp if insufficient previlege
				%>
				<!--#include file="../include/EmployeeSecurity.asp"-->
				<%
				'OK, now permit the user to use the function
				Response.Redirect Request.QueryString("target")& mytarget
			end if
		end if
	end if
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Employee Login</TITLE>
<link href="/script/stylesheet.css" rel="stylesheet" type="text/css">
<script src="/script/validation.js"></script>
<SCRIPT LANGUAGE=javascript>

	//For On Screen Keyboard
	var lastFocusControl;

	function ValidateFields() {
		try {
			var txt;
			/*
			txt = document.getElementById("accessCode");
			if(trim(txt.value) == "") {
				alert("Enter Access Code");
				document.getElementById("accessCode").select();
				document.getElementById("accessCode").focus();
				return false;
			}
			*/
			txt = document.getElementById("password");
			if(trim(txt.value) == "") {
				cbs_alert("Password can not be blank");
				txt.value = "";
				txt.focus();
				return false;
			}
		}
		catch(ex) {
			cbs_alert(ex.description);
			return false;
		}
		return true;
	}
	function onPasswordBlur() {
		lastFocusControl = document.getElementById("password");
	}

	function Init() {
		try {
			document.getElementById("password").focus();
		}
		catch(ex) {
			cbs_alert(ex.description);
		}
	}
</SCRIPT>
</HEAD>

<BODY topmargin=0 leftmargin=0 onLoad="Init();">
<!-- #include file="../include/banner.inc" -->

<FORM name="LoginForm" ID="LoginForm" METHOD=POST > <!-- onSubmit="try {return ValidateFields();}catch(ex){alert(ex.description);}"> -->
	<input type="hidden" name="functionID" id="functionID" value="<%= Request.Form("functionID") %>">
	<TABLE ALIGN=CENTER CELLSPACING=0 CELLPADDING=10>
		<% if not validLogin then %>
		<TR>
			<TD colspan=2 style="font-weight:bold;color:#ff0000;">Invalid login</TD>
		</TR>
		<% end if %>
		<!--
		<TR>
			<TD>Access Code</TD>
			<TD><INPUT class=text type=text name="accessCode" id="accessCode"> </TD>
		</TR>
		-->
		<TR>
			<TD>Password</TD>
			<TD><input type="password" name="password" id="password" class="text" onBlur="onPasswordBlur();"> </TD>
		</TR>
		<TR>
			<TD COLSPAN=2 ALIGN=CENTER VALIGN=MIDDLE><INPUT type="Submit" name="SubmitButton" id="SubmitButton" Value="Login" onClick="try {return ValidateFields();}catch(ex){cbs_alert(ex.description);}"></TD>
		</TR>
	</TABLE>
</FORM>

<% getKeyboardsetting()
	if l_keyboard  then %>
	<!-- #include file="../include/keyboard_alphabeticalOrder.inc" -->
<% else %>
	<!-- #include file="../include/keyboard.inc" -->
<%end if %>
</BODY>

<%
	dim l_keyboard

	function getKeyboardsetting()
	dim sqltxt
	dim rsTemp

	l_keyboard = false

	sqltxt = "select switchOnscreenKeyboardAlphabetic from Miscsetup where storeid =  " & session("storeid")
	set rsTemp = getDisconnectedrecordset(sqltxt)
	'Response.Write sqltxt
	if rsTemp.recordCount > 0 then
		if rsTemp("switchOnscreenKeyboardAlphabetic")= true then
			l_keyboard = true
		end if
	end if
	rstemp.close
	set rstemp = nothing


	end function


%>