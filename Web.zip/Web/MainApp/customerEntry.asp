<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("mode")%>
<%
	dim isSubmitted
	dim sqltxt
	dim customerseq
	dim actionString
	dim objWord
	dim datasource
	dim l_customerid
	dim l_firstname
	dim l_lastname
	dim l_mareacode
	dim l_mphone
	dim l_aareacode
	dim l_aphone
	dim l_cellphone, orig_cellPhone
	dim l_currentrec
	dim l_totalrec
	dim l_saddress1
	dim l_saddress2
	dim l_saddress3
	dim l_scity
	dim l_sstate
	dim l_szip
	dim l_baddress1
	dim l_baddress2
	dim l_baddress3
	dim l_bcity
	dim l_bstate
	dim l_bzip
	dim l_pricelistid
	dim l_customersourceid
	dim l_email
	dim l_birthdate
	dim l_currec
	dim l_storeid
	dim l_baddress
	dim l_broute
	dim l_bdob
	dim l_bnotes
	dim l_bpaypromo
	dim l_bpref
	dim l_beditcustid
	dim l_bautocustid
	dim l_mode
	dim l_brfirstname
	dim l_brdob
	dim l_brmainphone
	dim l_brmainAddress
	dim l_bremail
	dim l_useraction
	dim l_labelrec
	dim l_brAutoZIP
	dim l_err
	dim l_wantsEmail
	dim l_SendTextAlert
	dim l_multiPickup
	dim l_billingAddressSameAsShipping
	dim l_brCustomerSource
	dim l_brcellphone
	dim l_sendText
	dim l_contactPref
	dim l_notificationsSetup
	dim l_twilioBlackList
	dim queryFields, fieldChgRs

	isSubmitted = Request.QueryString("Submitted")

	l_storeid = session("storeid")

	if l_storeid = "" then
		l_storeid = 1
	end if



	if len(trim(Request.QueryString("useraction"))) > 0  then
		SaveFormData()
	else

	l_mode = Request.QueryString("mode")

	end if

	if l_mode = "edit" then
		customerseq = Session("customerSequenceNumber")
		if customerseq = "" then
		    customerseq = Request.QueryString("customerseq")
		    Session("customerSequenceNumber") = customerSeq
		end if

	    dim query, rs
		query = "select (case when exists  (select 1 from CustomerMessageSetup where customerId = " & customerseq _
		    & ") then count(*) else -1 end) cnt from CustomerMessageSetup cms, QueryAlert qa where cms.sms = 1 and customerId = " & customerseq _
		    & " and qa.Id = cms.queryId and qa.triggerType != 0 and qa.Id != -10"
		set rs = getdisconnectedrecordset(query)
        if rs("cnt") = -1 then
            query = "select count(*) cnt from CustomerMessageSetup cms, QueryAlert qa where cms.sms = 1 and customerId = 0" _
		    & " and qa.Id = cms.queryId and qa.triggerType != 0 and qa.Id != -10"
		set rs = getdisconnectedrecordset(query)
        end if

		l_notificationsSetup = rs("cnt")

		queryFields = getTrackedFields
		query = "select " & queryFields & " from customer where customerSequenceNumber = " & customerseq
		set fieldChgRs = getdisconnectedrecordset(query)

	else
		customerseq = ""
		session("customersequencenumber") = ""
            query = "select count(*) cnt from CustomerMessageSetup cms, QueryAlert qa where cms.sms = 1 and customerId = 0" _
                & " and qa.Id = cms.queryId and qa.triggerType != 0 and qa.Id != -10"
            set rs = getdisconnectedrecordset(query)
        l_notificationsSetup = rs("cnt")
	end if

	If isSubmitted then
		updateDatabase()
		actionString = trim(Request.QueryString("userAction"))
		customerseq = Session("customerSequenceNumber")
		if customerseq = "" then
		    customerseq = Request.QueryString("customerseq")
		    Session("customerSequenceNumber") = customerseq
		end if


		if len(trim(actionstring)) > 0  then
			if actionstring = "CustomerFunction" then
				Response.Redirect("CustomerFunctions.asp")
			else
				Response.Redirect(actionstring & "?targetpage=customerentry&customerseq=" & customerseq)
			end if
		END IF
	else
		actionString = lcase(trim(Request.QueryString("userAction")))
		select case actionString
		case "togglemultipickup"
			toggleMultiPickup customerseq
			getCustomerInfo()
		end select
	end if




	l_baddress = 0
	l_broute = 0
	l_bdob = 1
	l_bpaypromo= 0
	l_bpref = 0
	l_bnotes = 0
	l_beditcustid	 = 0
	l_bautocustid	 = 0

	GetCustomersetupOptions()

	if l_useraction = ""   then
		getCustomerInfo()
	end if

	'added by steve gagnon
	if len(trim(Request.QueryString("useraction"))) <= 0 and l_mode = "add" then
		getStoreDefaults()
	end if

	getRequiredFields()

	function getTrackedFields
		dim first, result
		first = true
		result = ""
		query = "select Field from CustFieldWatch"
		set rs = getdisconnectedrecordset(query)
		while not(rs.eof or rs.bof)
		    if not first then
		        result = result & ", "
		    end if
		    result = result & rs("field")
		    first = false
		    rs.movenext
		wend
	getTrackedFields = result

	end function


%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft FrontPage 4.0">
<TITLE>Customer</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<script type="text/javascript" src="/external/jquery-3.4.1.js"></script>

<SCRIPT type="text/javascript">
var tc, lc, bc, rc;


	function copyAddress(){
		document.customerEntryForm.txtBillAddr1.value =	document.customerEntryForm.txtShipAddr1.value;
		document.customerEntryForm.txtBillAddr2.value =	document.customerEntryForm.txtShipAddr2.value;
		document.customerEntryForm.txtBillAddr3.value =	document.customerEntryForm.txtShipAddr3.value;
		document.customerEntryForm.txtBillZip.value =	document.customerEntryForm.txtShipZip.value;
		document.customerEntryForm.txtBillCity.value =	document.customerEntryForm.txtShipCity.value;
		document.customerEntryForm.txtBillState.value =	document.customerEntryForm.txtShipState.value;

	}

	function validateRequiredFields(){

		if ( document.customerEntryForm.mode.value=="edit" &&
			 document.customerEntryForm.txtCustomerID.value==""){
			 cbs_alert ("Customer ID is a required field");
			 return false;
			 }
		if (document.customerEntryForm.mode.value=="add" &&
			document.customerEntryForm.brautocustid=="0" &&
			document.customerEntryForm.txtCustomerID.value==""){
			 cbs_alert ("Customer ID is a required field");
			 return false;
			 }
		if (	trim(document.customerEntryForm.txtLastName.value)=="" ){
				cbs_alert ("Last Name is a required field");
				return false;
			}
		if 	( document.customerEntryForm.brfirstname.value =="1" &&
				trim(document.customerEntryForm.txtFirstName.value) =="" ){
				cbs_alert ("First Name is a required field");
				return false;
		}

		if 	( document.customerEntryForm.brmainphone.value =="1" &&
				(trim(document.customerEntryForm.txtMainAreaCode.value) =="" ||
				trim(document.customerEntryForm.txtMainPhone.value) =="") ){
				cbs_alert ("Main phone is a required field");
				return false;
		}

		if 	( document.customerEntryForm.brdob.value =="1" &&
				trim(document.customerEntryForm.txtBirthDate.value) =="" ){
				cbs_alert ("Date of Birth is a required field");
				return false;
		}

		if 	( document.customerEntryForm.bremail.value =="1" &&
				trim(document.customerEntryForm.txtEmail.value) =="" ){
				cbs_alert ("Email address is a required field");
				return false;
		}

		if 	( document.customerEntryForm.braddress.value =="1" ){
				if (	trim(document.customerEntryForm.txtShipAddr1.value) ==""  ||
				trim(document.customerEntryForm.txtShipZip.value) == ""  ||
				trim(document.customerEntryForm.txtShipCity.value) ==""  ||
				trim(document.customerEntryForm.txtShipState.value) ==""){
				cbs_alert ("Shipping Address is a required field");
				return false;
			}
		}

		if 	( document.customerEntryForm.brcellphone.value =="1" ){
		    if (trim(document.customerEntryForm.txtCellPhoneAreaCode.value) === "" ||
		        trim(document.customerEntryForm.txtCellPhone.value) === "") {
				cbs_alert ("Cell Phone is a required field");
				return false;
			}
		}


		if 	( document.customerEntryForm.brCustomerSource.value =="1" ){
				if (document.customerEntryForm.customerSources.selectedIndex == 0){
				cbs_alert ("Customer source is a required field.");
				return false;
			}
		}


		if (trim(document.customerEntryForm.txtCellPhoneAreaCode.value) === "" ||
		        trim(document.customerEntryForm.txtCellPhone.value) === "") {
		    if ($("#chkTextAlert").attr("checked")) {
		        cbs_alert ("Cannot have marketing texts selected with no cell number");
                return false;
		    }
		}
		else if (trim(document.customerEntryForm.txtCellPhoneAreaCode.value).length != 5 ||
		        trim(document.customerEntryForm.txtCellPhone.value).length != 8) {
		    cbs_alert("Cell phone incorrect format");
		    return false;
		}


        <% if l_baddress then %>
		if (trim(document.customerEntryForm.txtShipZip.value).length != 0 &&
		    trim(document.customerEntryForm.txtShipZip.value).length != 5 &&
		    trim(document.customerEntryForm.txtShipZip.value).length != 10) {
                cbs_alert("Shipping Zip must be 5 digits or 9 with a dash");
                return false;
		}

		if (trim(document.customerEntryForm.txtBillZip.value).length != 0 &&
		    trim(document.customerEntryForm.txtBillZip.value).length != 5 &&
		    trim(document.customerEntryForm.txtBillZip.value).length != 10) {
                cbs_alert("Billing Zip must be 5 digits or 9 with a dash");
                return false;
		}
        <% end if %>
		return true;
	}

function setEmailPrefs(){
		if  (document.customerEntryForm.chkEmailAlert.checked )
			document.customerEntryForm.chkEmailAlert.value = 1 ;
		else
			document.customerEntryForm.chkEmailAlert.value = 0 ;
	}


	function cancelForm(){
		if (document.customerEntryForm.mode.value=="add" )
			document.customerEntryForm.action=  "CustomerSearch.asp";
		else
			document.customerEntryForm.action=  "Customerfunctions.asp";

		document.customerEntryForm.submit();
	}


	function captureKeyUpEvent(element){

		if (document.customerEntryForm.brZip.value != 1)
			return ;

		if (element.name == "txtShipZip" && trim(document.customerEntryForm.txtShipZip.value) != ""   ){
            document.customerEntryForm.txtShipZip.value = document.customerEntryForm.txtShipZip.value.replaceAll(/[^\d{5,5}(-\d{4,4})?]/g, '');
				document.customerEntryForm.action =  "?useraction=shipzipcode&isCellChk=" + (document.getElementById('cellPhoneSameAsMain').checked ? "1" : "0");
				document.customerEntryForm.submit();
		}
		else if (element.name == "txtBillZip" && trim(document.customerEntryForm.txtBillZip.value) != "" ) {
            document.customerEntryForm.txtBillZip.value = document.customerEntryForm.txtBillZip.value.replaceAll(/[^\d{5,5}(-\d{4,4})?]/g, '');
				document.customerEntryForm.action =  "?useraction=billzipcode&isCellChk=" + (document.getElementById('cellPhoneSameAsMain').checked ? "1" : "0");
				document.customerEntryForm.submit();
		}

	}

	function validateNameAndPhone() {
		document.customerEntryForm.action =  "?useraction=validatenameandphone";
		document.customerEntryForm.submit();
	}

	function toggleMultiPickup() {
		document.customerEntryForm.action =  "?useraction=togglemultipickup";
		document.customerEntryForm.submit();
	}

	function formatAreacodeOnFocus(element){
		var tempval
		tempval = new String(trim(element.value))
		tempval= tempval.replace(")", "")
		tempval= tempval.replace("(", "")
		tempval = tempval.replace(/[^0-9.]/g, '');
		element.value = tempval
		element.select()

	}

	function formatAreacodeOnBlur(element){
		var tempval
		tempval = new String(trim(element.value))
		tempval = tempval.replace(/[^0-9.]/g, '');
		if (tempval.length >= 3 ) {
			tempval= tempval.replace(")", "")
			tempval= tempval.replace("(", "")
			element.value = tempval
			element.value = "(" + tempval.substring(0,3) + ")"
			if (element.name == "txtMainAreaCode" )
				document.customerEntryForm.txtMainPhone.focus()
			else if (element.name == "txtCellPhoneAreaCode" )
				document.customerEntryForm.txtCellPhone.focus()
			else
				document.customerEntryForm.txtAltPhone.focus()
		}
        else
            element.value = tempval

        if (element.name == "txtMainAreaCode" && document.getElementById('cellPhoneSameAsMain').checked) {
            document.getElementById('txtCellPhoneAreaCode').value = element.value;
        }

	}

	function copyAddressInfoOnBlur(element) {

		if(document.customerEntryForm.txtBillAddr1.value == "")
			document.customerEntryForm.txtBillAddr1.value = document.customerEntryForm.txtShipAddr1.value

		if(document.customerEntryForm.txtBillAddr2.value == "")
			document.customerEntryForm.txtBillAddr2.value = document.customerEntryForm.txtShipAddr2.value

		if(document.customerEntryForm.txtBillAddr3.value == "")
			document.customerEntryForm.txtBillAddr3.value = document.customerEntryForm.txtShipAddr3.value


		if(document.customerEntryForm.txtBillZip.value == "")
			document.customerEntryForm.txtBillZip.value = document.customerEntryForm.txtShipZip.value

		if(document.customerEntryForm.txtBillCity.value == "")
			document.customerEntryForm.txtBillCity.value = document.customerEntryForm.txtShipCity.value

		if(document.customerEntryForm.txtBillState.value == "")
			document.customerEntryForm.txtBillState.value = document.customerEntryForm.txtShipState.value

		captureKeyUpEvent(element);
	}


	function formatPhoneOnKeyUp(element){
		var tempval
		var tempx
		tempval = new String(ltrim(element.value))
		tempval = tempval.replace("-", "")
		tempval = tempval.replace(/[^0-9.]/g, '');
		if (tempval.length > 7)
		    tempval = tempval.substring(0, 7);
		if (tempval.length > 3){
				element.value = tempval.substring(0, 3) + "-" + tempval.substring(3)
		}
        else
            element.value = tempval

        if (element.name == "txtMainPhone" && document.getElementById('cellPhoneSameAsMain').checked) {
            document.getElementById('txtCellPhone').value = element.value;
        }
	}

	function setCellPhone(isChecked) {
	    if (isChecked) {
	        var areaCode = $("#txtMainAreaCode").val();
	        var number = $("#txtMainPhone").val();

            $("#txtCellPhoneAreaCode").val(areaCode);
            $("#txtCellPhone").val(number);
            $("#txtCellPhoneAreaCode").attr("disabled", true);
            $("#txtCellPhone").attr("disabled", true);
	    }
	    else {
            $("#txtCellPhoneAreaCode").attr("disabled", false);
            $("#txtCellPhone").attr("disabled", false);
	    }
	}


	function setFocusOnControl(element){
		var l_err;
		var continueSubmit;

		if (element == "shipzipcode")
			document.customerEntryForm.txtShipCity.focus();
		else if (element == "billzipcode")
			document.customerEntryForm.txtBillCity.focus();
		else
			document.customerEntryForm.txtFirstName.focus();

	}


	function suspendCustomer() {
		document.customerEntryForm.action= "CustomerFunctions.asp?useraction=suspend";
		document.customerEntryForm.submit();
	}



	function isAlpha(obj) {
		if (obj.value != "") {
			for (var i = 0; i < obj.value.length; i++) {
			    if ((obj.value.charAt(i) < "a" || obj.value.charAt(i) > "z") &&
			       (obj.value.charAt(i) < "A" || obj.value.charAt(i) > "Z") && obj.value.charAt(i) != " "
				   && obj.value.charAt(i) != "/" && obj.value.charAt(i) != "&" && obj.value.charAt(i) != "." ) {
						return false;
			    }
			}
		}
		return true;
	}

	function showBillingAddress(visible) {
		if(visible)
			$('.billingAddress').show();
		else
			$('.billingAddress').hide();
	}

	function SelectedValue(userSelection){
		if 	(validateRequiredFields()) {
            document.customerEntryForm.action += "?Submitted=true&mode=" +
                document.customerEntryForm.mode.value + "&userAction=" + userSelection + "&customerseq=<%=customerseq%>";

            var newCell = $("#txtCellPhoneAreaCode").val() + $("#txtCellPhone").val();
            newCell = newCell.replace("(", "").replace(")", "").replace("-", "");
            if (newCell.length == 10 && newCell !== '<%=orig_CellPhone%>')
                document.customerEntryForm.action += "&newCell=1"
            document.customerEntryForm.submit();
            return(true);
		}
		else
		    return false;
	}

	function handleContinueTrue() {
        clearConfirmMsg();
	    document.customerEntryForm.okButton.disabled = SelectedValue(nextAction);
	}

    var nextAction
	function validateCompleted(data)
	{
	    saveData = null;
		if(data.valid)
		{
		    nextAction = data.useraction;
		    if (document.customerEntryForm.brcellphone.value !="1" &&
         			            (trim(document.customerEntryForm.txtCellPhoneAreaCode.value) === "" || trim(document.customerEntryForm.txtCellPhone.value) === "") &&
         		                <%= l_notificationsSetup %> != 0 && document.customerEntryForm.nextPage == "CustomerFunction") {
		        cbs_confirm('Customer is setup for sms notifications but has no cell phone.  Continue?', handleContinueTrue, enableOkButton)
		    }
		    else
		        handleContinueTrue();
		}
		else
		{
			document.customerEntryForm.txtFirstName.style.background = 'yellow';
			document.customerEntryForm.txtLastName.style.background = 'yellow';
			document.customerEntryForm.txtMainAreaCode.style.background = 'yellow';
			document.customerEntryForm.txtMainPhone.style.background = 'yellow';

			document.customerEntryForm.okButton.disabled = false;

			<% if isDupCustomerNameAllowed() then %>
                cbs_confirm('Customer already exists based on name and phone number. Continue?', handleContinueTrue)
			<% else %>
				cbs_alert('Customer already exists based on name and phone number.');
			<% end if %>
		}
	}


	function enableOkButton() {
        clearConfirmMsg();
		document.customerEntryForm.okButton.disabled = false;
	}


	function submitForm(userAction) {
		document.customerEntryForm.okButton.disabled = true;
		document.customerEntryForm.nextPage = userAction;

        $("#txtCellPhone").attr("disabled", false);
        $("#txtCellPhoneAreaCode").attr("disabled", false);

		jQuery.ajax({
			type: "POST",
            async : false,
			url: "validateCustomer.asp",
			success: function(data) {
                validateCompleted(data)
            },
			error: function() {
			    enableOkButton();
            },
			dataType: "json",
			data: {
				userAction: userAction,
				customerseq: document.customerEntryForm.customerseq.value,
				firstname: document.customerEntryForm.txtFirstName.value,
				lastname: document.customerEntryForm.txtLastName.value,
				fullphone: document.customerEntryForm.txtMainAreaCode.value + document.customerEntryForm.txtMainPhone.value
			}
		});
	}

	function init() {
	    <% if IsNumeric(Request.QueryString("isCellChk")) and Request.QueryString("isCellChk") = "1" then %>
	        setCellPhone(true);
            $("#cellPhoneSameAsMain").attr('checked','checked')
        <% else %>
	    var cellPhone = '<%=l_cellphone %>'
	    if (cellPhone.length === 10) {
	        var cellAreaCode = "(" + cellPhone.substring(0, 3) + ")";
	        var cellNumber = cellPhone.substring(3, 6) + "-" + cellPhone.substring(6);
	        var mainAreaCode = '<%=l_mareacode %>'
	        var mainNumber = '<%=l_mphone %>'
	        if (mainAreaCode === cellAreaCode && cellNumber === mainNumber) {
	            setCellPhone(true);
                $("#cellPhoneSameAsMain").attr('checked','checked')
	        }
	        else {
                $("#txtCellPhoneAreaCode").val(cellAreaCode);
                $("#txtCellPhone").val(cellNumber);
	        }
	    }
	    <% end if %>
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0 onLoad="setFocusOnControl('<%=Request.querystring("useraction")%>'); init()">
<!-- #include file="../include/banner.inc" -->

<script language="javascript" type="text/javascript">

  $(document).ready(function(){
	  showBillingAddress(!($("input[name='billingAddressSameAsShipping']").is(":checked")))

  });

</SCRIPT>

<FORM id="customerEntryForm" name="customerEntryForm" method="Post" action="customerEntry.asp" onsubmit="return false">
<INPUT type=hidden name="l_err" style="height:0" value="<%= l_err %>">
<INPUT type="hidden" id="customerseq" name="customerseq" value="<%=customerseq%>" />
<% if queryFields <> "" then
dim fieldArr, i
fieldArr = Split(queryFields, ", ")
    For i = LBound(fieldArr) To UBound(fieldArr) %>
    <INPUT type="hidden" id="old_<%=fieldArr(i)%>" name="old_<%=fieldArr(i)%>" value="<%=fieldChgRs(fieldArr(i))%>" />
<%
    Next
end if %>


<H1>&nbsp;</H1>

	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<tr align=center><td>
			<button style="vertical-align: top;width: 120px" class=std  id=discountButton name=discountButton onClick= "submitForm('customerdiscount.asp')"><img src="/static/icons/32x32/discount.png"><br>Discount<br>Info</button>



			<%if (l_bpref) then%>
				<button style="vertical-align: top;width: 120px" class=std id=preferencesButton name=preferencesButton onClick= "submitForm('customerPreferences.asp')"><img src="/static/icons/32x32/settings.png"><br>Preferences</button>
			<%end if%>

			<%if (l_bnotes) then%>
				<button style="vertical-align: top;width: 120px" class=std id=notesButton name=notesButton onClick= "submitForm('customerNotes.asp')"><img src="/static/icons/32x32/note.png"><br>Notes</button>
			<%end if%>

			<%if (l_bpaypromo) then%>
				<button style="vertical-align: top;width: 120px" class=std id=paymentInfoButton name=paymentInfoButton  onClick= "submitForm('Customerpayment.asp')"><img src="/static/icons/32x32/money.png"><br>Payment<br>Info</button>
			<% end if%>

			<button style="vertical-align: top;width: 120px" class=std id=notificationBtn name=notificationBtn  onClick= "submitForm('editCustomerNotifications.asp')"><img src="/static/icons/32x32/loyalty.png"><br>Notifications</button>


			<% if (l_broute) then %>
                <% if getRouteVersion(session("storeid")) = 1 then %>
                    <button style="vertical-align: top;width: 120px" class=std id=routeInfoButton name=routeInfoButton onClick= "submitForm('customerroutes.asp')"><img src="/static/icons/32x32/route.png"><br>Route<br>Info</button>
                <% else %>
                    <button style="vertical-align: top;width: 120px" class=std id=routeInfoButton name=routeInfoButton onClick= "submitForm('customerdeliverylist.asp')"><img src="/static/icons/32x32/route.png"><br>Route<br>Info</button>
                <% end if %>
			<% end if %>

			<% if l_customerid <> "" and sec_FindPermission("/mainapp/customerfunctions.asp", "suspend", Session("EmployeeID"), false) then %>
				<button style="vertical-align: top;width: 120px" class=std id=suspendButton name=suspendButton onClick= "suspendCustomer();"><img src="/static/icons/32x32/stop.png"><br>Suspend</button>
			<% end if %>
		</td></tr>
	</TABLE>
	<DIV id="message" style="text-align:center; color: red; font-size: 20">

	</DIV>
	<TABLE style="margin:2%" BORDER=0 ALIGN=center WIDTH="96%" BORDER= CELLSPACING=1 CELLPADDING=2 >
		<TR>

			<TD><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold"><b> <font color =red >*</font>Customer ID</P></TD>
			<TD>
				<INPUT id=txtCustomerID name=txtCustomerID style="HEIGHT: 25px; WIDTH: 254px" maxlength = <% if l_mode = "edit" then Response.write ("16") else Response.Write("15") end if %>
				<% if l_beditcustid  = 0 then %>
					readonly
				<% end if %>
				<%if l_mode = "add" and l_bautocustid then %>
					readonly
				<%else %>
				value= "<%=l_customerid%>"
				<%end if%> size="20" tabindex="0"
				>
			</TD>
			<TD><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">Record Number</P></TD>
			<TD width =20><P align=left STYLE="FONT-SIZE: 14px; FONT-WEIGHT: bold"><%=l_labelRec%></P></TD>

		</TR>
		<TR>
			<TD><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">
			<%if l_brfirstname then  %>
			<b> <font color =red >*</font>
			<%end if %>
			First Name</P></TD>
			<TD>
				<INPUT id=txtFirstName name=txtFirstName  style="HEIGHT: 25px; WIDTH: 254px"  maxlength = 64 value="<%=Server.HTMLEncode(l_firstname)%>" onkeydown="this.style.background = 'white';" size="20" tabindex="1">
			</TD>
			<TD><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold"><b> <font color =red >*</font>Last Name</P></TD>
			<TD width =20%>
				<INPUT id=txtLastName name=txtLastName  style="HEIGHT: 25px; WIDTH: 254px" maxlength = 64 value="<%=Server.HTMLEncode(l_lastname)%>" onkeydown="this.style.background = 'white';" size="20" tabindex="2">
			</TD>
		</TR>
		<TR>
			<TD><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">
			<%if l_brmainphone then  %>
			<b> <font color =red >*</font>
			<%end if %>Main Phone
			</P></TD>
			<TD>
				<P align=left STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">
					<INPUT id=txtMainAreaCode name=txtMainAreaCode  style="HEIGHT: 25px; WIDTH:50px" maxlength = 5  onclick="this.select()" onFocus="formatAreacodeOnFocus(this)" onBlur = "formatAreacodeOnBlur(this)"  onkeyup="formatAreacodeOnBlur(this)" value="<%=l_mareacode%>" size="20" tabindex="3">
                	<INPUT id=txtMainPhone name=txtMainPhone  style="HEIGHT: 25px; WIDTH:200px" maxlength = 64 onkeyup= "formatPhoneOnKeyUp(this)"  value="<%=l_mphone%>" size="20" tabindex="4">
					<INPUT type="checkbox" id="cellPhoneSameAsMain" name="cellPhoneSameAsMain" style="HEIGHT: 28px; WIDTH: 28px; vertical-align: middle" onclick="setCellPhone(this.checked)" >
					Is Cell Phone
				</P>
			</TD>
			<TD><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">Alt Phone</P></TD>
			<TD width =20%>
				<INPUT id=txtAltAreaCode name=txtAltAreaCode  style="HEIGHT: 25px; WIDTH:50px"  onFocus="formatAreacodeOnFocus(this)"  onclick="this.select()" onBlur = "formatAreacodeOnBlur(this)" onkeyup = "formatAreacodeOnBlur(this)" maxlength = 5 value="<%=l_aareacode%>" size="20">
				<INPUT id=txtAltPhone name=txtAltPhone  style="HEIGHT: 25px; WIDTH:195px"  onkeyup= "formatPhoneOnKeyUp(this)"   maxlength = 64 value="<%=l_aphone%>" size="20" tabindex="14">
			</TD>
		</TR>
		<TR>
		    <TD><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">
				<%if l_brcellphone then  %>
				<b> <font color =red >*</font>
				<%end if %>
			Cell Phone</P></TD>
		    <TD style="white-space: nowrap">
		    	<INPUT id=txtCellPhoneAreaCode name=txtCellPhoneAreaCode  style="HEIGHT: 25px; WIDTH:50px"  onFocus="formatAreacodeOnFocus(this)"  onclick="this.select()" onBlur = "formatAreacodeOnBlur(this)" tabindex="5" onKeyup = "formatAreacodeOnBlur(this)" maxlength = 5 size="20">
            	<INPUT id=txtCellPhone name=txtCellPhone style="height: 25px; width:200px" maxlength=15 onclick="this.select()" onkeyup="formatPhoneOnKeyUp(this)" size="20" tabindex="5" >
		        <INPUT id="chkTextAlert" name="chkTextAlert" type="checkbox" tabindex="6" style="HEIGHT: 28px; WIDTH: 28px;vertical-align:middle" <% if l_sendText then %>Checked <%end if%>>
		        <label for="chkTextAlert"  STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold;">Opt in to Marketing Texts<% if l_twilioBlackList then %>*<%end if %></label>
		       <% if l_twilioBlackList then %> <br /><span style="font-size: 12px">* Customer has unsubscribed from receiving sms messages</span><%end if %>

		    </TD>
			<TD align=right class="label" STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">
			Preferred<br />Contact Method</TD>
			<TD width =20%>


				<SELECT id="contactPref" name="contactPref" STYLE="font-size: 14px; width: 100;" tabindex="26">
					<OPTION value="1" <%if l_contactPref = 1 then %> selected <% end if %>>SMS</option>
					<OPTION value="2" <%if l_contactPref = 2 then %> selected <% end if %>>Email</option>
				</SELECT>
			</TD>
		</TR>
		<% if l_baddress then %>
		<TR>
			<TD></TD>
			<TD><P align=left STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">Shipping Address</P></TD>
			<TD></TD>
			<TD>
				<P align=left STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">
					<INPUT type="checkbox" id="billingAddressSameAsShipping" name="billingAddressSameAsShipping" style="HEIGHT: 28px; WIDTH: 28px" onclick="showBillingAddress(!this.checked)"  <%if l_billingAddressSameAsShipping or l_mode = "add" then %>checked<% end if %> />
					Use Shipping Address For Billing
				</P>
			</TD>
		</TR>
		<!-- address 1 -->
		<TR>

			<TD><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">
				<%if l_brmainaddress then  %>
				<b> <font color =red >*</font>
				<%end if %>

			Address 1</P></TD>
			<TD>
				<INPUT id=txtShipAddr1 name=txtShipAddr1  style="HEIGHT: 25px; WIDTH: 254px" maxlength = 255 onchange = "copyAddressInfoOnBlur(this)" value="<%=l_saddress1%>" size="20" tabindex="7">
					</TD>
			<TD><SPAN class="billingAddress"><SPAN class="billingAddress"><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">Address 1</P></SPAN></TD>
			<TD width =20%>
				<SPAN class="billingAddress">
				<INPUT id=txtBillAddr1 name=txtBillAddr1  style="HEIGHT: 25px; WIDTH: 254px" maxlength = 255 value="<%=l_baddress1%>" size="20" tabindex="15">
				</SPAN>
			</TD>
		</TR>
		<!-- address 2 -->
		<TR>
			<TD><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">Address 2</P></TD>
			<TD>
				<INPUT id=txtShipAddr2 name=txtShipAddr2  style="HEIGHT: 25px; WIDTH: 254px" maxlength = 255 onchange = "copyAddressInfoOnBlur(this)" value="<%=l_saddress2%>" size="20" tabindex="8">
					</TD>
			<TD><SPAN class="billingAddress"><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">Address 2</P></SPAN></TD>
			<TD width =20%>
				<SPAN class="billingAddress">
				<INPUT id=txtBillAddr2 name=txtBillAddr2  style="HEIGHT: 25px; WIDTH: 254px" maxlength = 255 value="<%=l_baddress2%>" size="20" tabindex="16">
				</SPAN>
			</TD>
		</TR>
		<!-- address 3 -->
		<TR>
			<TD><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">Address 3</P></TD>
			<TD>
				<INPUT id=txtShipAddr3 name=txtShipAddr3  style="HEIGHT: 25px; WIDTH: 254px" maxlength = 255 onchange = "copyAddressInfoOnBlur(this)" value="<%=l_saddress3%>" size="20" tabindex="9">
					</TD>
			<TD><SPAN class="billingAddress"><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">Address 3</P></SPAN></TD>
			<TD width =20%>
				<SPAN class="billingAddress">
				<INPUT id=txtBillAddr3 name=txtBillAddr3  style="HEIGHT: 25px; WIDTH: 254px" maxlength = 255 value="<%=l_baddress3%>" size="20" tabindex="17">
				</SPAN>
			</TD>
		</TR>
		<!-- zip -->
		<TR>
			<TD><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">
				<%if l_brmainaddress then  %>
				<b> <font color =red >*</font>
				<%end if %>
			Zip</P></TD>
			<TD>
				<INPUT id=txtShipZip name=txtShipZip  style="HEIGHT: 25px; WIDTH: 100px" maxlength = 15 onchange = "copyAddressInfoOnBlur(this)"  value="<%=l_szip%>" size="20" tabindex="10">&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
				<button id=copyButton name=copyButtonstyle="height=25px" onClick="copyAddress();" tabindex="11">Bill To Same</button>
			</TD>
			<TD><SPAN class="billingAddress"><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">Zip</P></SPAN></TD>
			<TD width =20%>
				<SPAN class="billingAddress">
				<INPUT id=txtBillZip name=txtBillZip  style="HEIGHT: 25px; WIDTH: 100px" maxlength = 15 onfocusout= "captureKeyUpEvent(this)" value="<%=l_bzip%>" size="20" tabindex="18">
				</SPAN>
			</TD>

		</TR>
		<!-- city, state -->
		<TR>
			<TD><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">
				<%if l_brmainaddress then  %>
				<b> <font color =red >*</font>
				<%end if %>
			City, State</P></TD>
			<TD>

				<INPUT id=txtShipCity name=txtShipCity  style="HEIGHT: 25px; WIDTH: 150px" maxlength = 64 onchange = "copyAddressInfoOnBlur(this)" value="<%=l_scity%>" size="20" tabindex="11">&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<B STYLE="FONT-SIZE: 14px">,</B>
				<INPUT id=txtShipState name=txtShipState maxlength=64  style="HEIGHT: 25px; WIDTH: 50px" maxlength = 64 onchange = "copyAddressInfoOnBlur(this)" value="<%=l_sstate%>" size="20" tabindex="12">
					</TD>

			<TD><SPAN class="billingAddress"><P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">City, State</P></SPAN></TD>

			<TD width =20%>
				<SPAN class="billingAddress">
				<INPUT id=txtBillCity name=txtBillCity  style="HEIGHT: 25px; WIDTH: 150px" maxlength = 64 value="<%=l_bcity%>" size="20" tabindex="19">&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<B STYLE="FONT-SIZE: 14px">,</B>
				<INPUT id=txtBillState name=txtBillState  maxlength=64 style="HEIGHT: 25px; WIDTH: 50px" maxlength = 64 value="<%=l_bstate%>" size="20" tabindex="20">
				</SPAN>
			</TD>
		</TR>
		<%end if%>
		<!-- price table -->
		<TR>
			<TD align=right class="pricetable" STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">Price Table</TD>
			<TD>
				<SELECT name=priceTable STYLE="font-size: 14px; width: 211; height: 23" tabindex="21">
						<%
							dim rspricetable
				            sqltxt = "Select pl.defaultind, pl.PriceListId, (pl.name + ' at ' + s.name) as name from Pricelist pl, store s where (pl.storeid = " & l_storeid & " or pl.pricelistid in (select pricelistid from storealtpricelist where storeid = " & l_storeid & ")) and pl.disable = 0 "
				            sqltxt = sqltxt & " and s.storeid = pl.storeid  order by pl.defaultind"
							set rspricetable = getDisconnectedRecordset(sqltxt)
							dim isselected
							isselected = false
							while not rspricetable.BOF and not rspricetable.EOF
						%>
							<OPTION
								<% if not isnull(l_pricelistid) and l_pricelistid <> "" and not isselected and (trim(l_pricelistid) = trim(rspricetable("PriceListId")))then
									isselected= true
								%>
										selected
								<% elseif rspricetable("defaultind") = "True" and not isselected  then	%>
										selected
								<%	end if	%>
								VALUE= "<%=rspricetable("PriceListId") %>"><%=rspricetable("Name") %>
							</option>
						<%
							rspricetable.MoveNext
							wend
							rsPricetable.close
							set rsPricetable = nothing
						%>
				</SELECT>


			</TD>
			<TD align=right class="label" STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">
				<%if l_brCustomerSource then  %>
				<b> <font color =red >*</font>
				<%end if %>
			Customer Source</TD>
			<TD width =20%>


				<SELECT name=customerSources STYLE="font-size: 14px; width: 254; height: 27" tabindex="22">
					<OPTION selected value = "0">None</option>
				<%
						dim rsCustomerSource
						sqltxt = "select * from CustomerSourceDomain where storeid = " & l_storeid
						if l_customersourceid <> "" then
						sqltxt = sqltxt & " and (active = 1 or customersourceid = " & l_customersourceid & ") "
						else
						sqltxt = sqltxt & " and active = 1 "
						end if
						set rsCustomerSource = getdisconnectedrecordset(sqltxt)
						while not rsCustomerSource.BOF and not rsCustomerSource.EOF

				%>

					<OPTION
						<% if trim(l_customersourceid) = trim(rscustomerSource("CustomerSourceId")) then %>
								selected
						<%	end if	%>
						VALUE= "<%=rscustomerSource("CustomerSourceId") %>"><%= rsCustomerSource("Name") %></option>
					<%
						rsCustomerSource.MoveNext
						Wend
						rsCustomerSource.close
						set rsCustomerSource = nothing
					%>
				</SELECT>
			</TD>
		</TR>
		<!-- email address -->
		<TR>
			<TD>
				<P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">
				<%if l_bremail then  %>
				<b> <font color =red >*</font>
				<%end if %>
				Email Address</b></P>
			</TD>

			<TD>
				<INPUT id=txtEmail name=txtEmail  style="HEIGHT: 25px; WIDTH: 200px" maxlength = 64 value="<%=l_email%>" size="20" tabindex="13"><INPUT id=chkEmailAlert name=chkEmailAlert type=checkbox style="HEIGHT: 28px; WIDTH: 28px;vertical-align:middle" <% if l_wantsEmail then %>Checked <%end if%> tabindex="24"><label for="chkEmailAlert" STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold; white-space: nowrap">Opt in to Marketing Emails</label>

			</TD>



			</TD>

			<%if l_bdob then %>
			<td>
				<P align=right STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">
					<%if l_brdob then  %>
					<b> <font color =red >*</font>
					<%end if %>
				Birth Date(mm/dd/yyyy)</P>
			</td>
			<td>
			<INPUT id=txtBirthDate name=txtBirthDate  style="HEIGHT: 25px; WIDTH: 100px" maxlength =10 value="<%=l_birthDate%>" size="20" tabindex="25">
			</td>

			<%end if%>


		</TR>
	</TABLE>
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=2 >
		<TR>
			<TD colspan="3">
				<P align=center STYLE="FONT-SIZE: 12px; FONT-WEIGHT: bold">Options</P>
			</TD>
		</TR>
		<TR>
			<TD colspan="3" align=center style="font-size:12px;">
				<INPUT type="button" style="width:90px;height:40px;<%if l_multiPickup then%>background:gold"<%else%>background:white"<%end if%> value="Multi Pickup" onclick="toggleMultiPickup()" />
			</TD>
		</TR>
	</TABLE>
	<TABLE style="margin-top:10px" ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=2 >
		<TR>
			 <td width=300px></td>
			 <TD align =center>
			 	<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)" onClick="submitForm('CustomerFunction')" ><br><br>
			 </TD>
			 <TD align =center>
			 	<INPUT class=touchNoBorder id=cancelButton name=cancelButton type=button style="background-image:url(../images/Cancel.gif)" value="" onClick="cancelForm()"><br><br>
			</TD>
			<td width=300px></td>
		</TR>
	</TABLE>


	<input type = hidden name=mode value="<%=l_mode%>">
	<input type=hidden name="baddress" value="<%=l_baddress%>">
	<input type=hidden name="bdob" value="<%=l_bdob%>">
	<input type=hidden name="bpref" value="<%=l_bpref%>">
	<input type=hidden name="bpaypromo" value="<%=l_bpaypromo%>">
	<input type=hidden name="bnotes" value="<%=l_bnotes%>">
	<input type=hidden name="broutes" value="<%=l_broute%>">
	<input type=hidden name="brfirstname" value="<%=l_brfirstname%>">
	<input type=hidden name="brdob" value="<%=l_brdob%>">
	<input type=hidden name="brmainphone" value="<%=l_brmainphone%>">
	<input type=hidden name="brcellphone" value="<%=l_brcellphone%>">
	<input type=hidden name="breditcustid" value="<%=l_beditcustid%>">
	<input type=hidden name="brautocustid" value="<%=l_bautocustid%>">
	<input type=hidden name="braddress" value="<%=l_brmainAddress%>">
	<input type=hidden name="bremail" value="<%=l_bremail%>">
	<input type=hidden name="recordlabel" value="<%=l_labelrec%>">
	<input type=hidden name="brZip" value="<%=l_brAutoZIP%>">
	<input type=hidden name="brCustomerSource" value="<%=l_brCustomerSource%>">

</FORM>

</BODY>
</HTML>
<%

	function GetCustomersetupOptions()
	dim rsSetupOptions
	Sqltxt = "Select * from customerSetupoptions where storeid =" & l_storeid
		set rsSetupOptions= getdisconnectedrecordset(sqltxt)

		if not rsSetupOptions.BOF and not rsSetupOptions.EOF then
			if rsSetupoptions("allowentrycustaddr") then
				l_baddress = 1
			end if
			if rsSetupoptions("allowentrycustrouteinfo") then
				l_broute = 1
			end if
			if rsSetupoptions("allowentrycustDoB") then
				l_bdob = 1
			end if
			if rsSetupoptions("allowentrycustPayPromo") then
				l_bpaypromo = 1
			end if
			if rsSetupoptions("allowentrycustPref") then
				l_bpref = 1
			end if
			if rsSetupoptions("allowentrycustNotes") then
				l_bnotes = 1
			end if
			if rsSetupoptions("allowEditCustomerid") then
				l_beditcustid = 1
			end if
			if rsSetupoptions("autoCustomerid") then
				l_bautocustid = 1
			end if
			if rsSetupoptions("AutoZipToCity") then
				l_brAutoZIP = 1
			end if


			rsSetupOptions.close
		end if
		set rsSetupOptions = nothing
	end function


	function SaveFormData()
		l_mode = request.form("mode")
		if len(request.form("txtCustomerID"))=0 then
			l_customerid = ""
		else
			l_customerid = request.form("txtCustomerID")
		end if

		l_firstname= request.form("txtFirstName")
		l_lastname= request.form("txtLastName")
		l_mareacode= request.form("txtMainAreaCode")
		l_mphone= request.form("txtMainPhone")
		l_aareacode= request.form("txtAltAreaCode")
		l_aphone= request.form("txtAltPhone")
		l_cellphone= request.Form("txtCellPhoneAreaCode") & request.Form("txtCellPhone")
		l_currentrec= request.form("mode")
		l_totalrec= request.form("mode")
		l_saddress1= request.form("txtShipAddr1")
		l_saddress2= request.form("txtShipAddr2")
		l_saddress3= request.form("txtShipAddr3")
		l_baddress1= request.form("txtBillAddr1")
		l_baddress2= request.form("txtBillAddr2")
		l_baddress3= request.form("txtBillAddr3")
		l_scity= request.form("txtShipCity")
		l_sstate= request.form("txtShipState")
		l_szip= request.form("txtShipZip")
		l_bcity= request.form("txtBillCity")
		l_bstate= request.form("txtBillState")
		l_bzip= request.form("txtBillZip")
		l_pricelistid= trim(request.form("priceTable"))
		l_customersourceid= request.form("customerSources")
		l_email= request.form("txtEmail")
		l_birthdate= request.form("txtBirthDate")
		l_labelrec= trim(request.form("recordlabel"))
		l_useraction= Request.QueryString("useraction")
		l_brAutoZIP = trim(request.form("brzip"))
		l_wantsEmail = evalRequestValue(Request.form("chkEmailAlert"))
		l_sendText = evalRequestValue(Request.Form("chkTextAlert"))
		l_billingAddressSameAsShipping = evalRequestValue(Request.form("billingAddressSameAsShipping"))
		l_contactPref = trim(Request.Form("contactPref"))

		if l_useraction = "shipzipcode" then
			getShipPostaldetails()
		elseif l_useraction = "billzipcode" then
			getBillPostaldetails()
		elseif l_mode = "add" and l_useraction = "validatenameandphone" then
			validateNameAndPhone()
		end if


	end function
	'added by steve gagnon
	function getStoreDefaults

	'added by steve gagnon
	'contains store records
	dim rsstoreinfo

		'added by steve gagnon
		sqltxt = "select * from Store where storeID = " & l_storeid
		set rsstoreinfo = getdisconnectedrecordset(sqltxt)


		if not rsstoreinfo.BOF and not rsstoreinfo.EOF then

			if len(trim(l_mareacode)) <= 0 then
				l_mareacode = checkfornull(rsstoreinfo("areaCode"))

				if len(trim(l_mareacode)) > 0 then
					l_mareacode = "(" & l_mareacode & ")"
				end if
			end if




			l_aareacode = l_mareacode
			l_szip = trim(checkfornull(rsstoreinfo("zipCode")))
			l_scity = trim(checkfornull(rsstoreinfo("city")))
			l_sstate = trim(checkfornull(rsstoreinfo("state")))

			l_bcity = l_scity
			l_bstate = l_sstate
			l_bzip = l_szip

		end if

	end function


	Function GetcustomerInfo
	dim rscustomer
	dim rstotalRec

		dim rstotal

		if	l_mode = "edit" and not isnull(customerseq) and len(customerseq) <> 0 then

			l_bautocustid=0

			sqltxt = "select totalrec=Count(*) from customer"

			set rstotalrec = getdisconnectedrecordset(sqltxt)

			sqltxt = "Select * from customer where customersequencenumber = " & customerseq

			set rscustomer = getdisconnectedrecordset(sqltxt)

			if not rscustomer.BOF and not rscustomer.EOF then

				l_customerid = checkfornull(rscustomer("customerid"))
				l_firstname = checkfornull(rscustomer("firstname"))
				l_lastname= checkfornull(rscustomer("lastname"))
				l_mareacode= checkfornull(rscustomer("mainareacode"))

				if len(trim(l_mareacode)) > 0 then
					l_mareacode = "(" & l_mareacode & ")"
				end if

				l_mphone= checkfornull(rscustomer("mainphone"))

				if len(trim(l_mphone)) >=7 then
					l_mphone = left(l_mphone, 3) & "-" & right(l_mphone,len(l_mphone) -3)
				end if

				l_aareacode= checkfornull(rscustomer("altareacode"))

				if len(trim(l_aareacode)) > 0 then
					l_aareacode = "(" & l_aareacode & ")"
				end if

				l_aphone= checkfornull(rscustomer("altphone"))
				if len(trim(l_aphone)) >= 7 then
					l_aphone = left(l_aphone, 3) & "-" & right(l_aphone,len(l_aphone) -3)
				end if

                l_cellPhone= checkfornull(rscustomer("cellphone"))
                orig_cellPhone = l_cellPhone
				l_currec = customerseq
				l_totalrec =rstotalrec("totalrec")
				l_saddress1= checkfornull(rscustomer("shippingaddress1"))
				l_saddress2= checkfornull(rscustomer("shippingaddress2"))
				l_saddress3= checkfornull(rscustomer("shippingaddress3"))
				l_scity= checkfornull(rscustomer("shippingcity"))
				l_sstate= checkfornull(rscustomer("shippingstate"))
				l_szip= checkfornull(rscustomer("shippingzipcode"))
				l_baddress1= checkfornull(rscustomer("billingaddress1"))
				l_baddress2= checkfornull(rscustomer("billingaddress2"))
				l_baddress3= checkfornull(rscustomer("billingaddress3"))
				l_bcity= checkfornull(rscustomer("billingcity"))
				l_bstate= checkfornull(rscustomer("billingstate"))
				l_bzip= checkfornull(rscustomer("billingzipcode"))
				l_pricelistid = trim(rscustomer("DefaultPricelistid"))
				l_customersourceid = rscustomer("Customersourceid")
				l_email= checkfornull(rscustomer("email"))
				l_birthdate= checkfornull(rscustomer("birthdate"))
				l_labelrec= l_currec & "/" & l_totalrec
				l_wantsEmail = rscustomer("wantsEmailAlerts")
				l_sendText = rscustomer("SendTextAlert")
				l_contactPref = rscustomer("contactPref")
				l_multiPickup = rscustomer("multiplePickup")
				l_billingAddressSameAsShipping = rscustomer("billingAddressSameAsShipping")
				l_twilioBlackList = rscustomer("twilioBlackList")

				rscustomer.close
			end if
			set rscustomer=nothing
		end if
			if not isnumeric(Request.QueryString("lastname")) then
				l_lastname = Request.QueryString("lastname")
			end if

		dim plen
		dim pbeg
		plen = len(trim(Request.QueryString("phone")))
		pbeg = 1

		if plen > 0 then
			if plen > 7 then
				l_mareacode = "(" & Left(Request.QueryString("phone"), 3) & ")"
				pbeg = pbeg + 3
			end if

			l_mphone = Mid(Request.QueryString("phone"), pbeg, 3) & "-" & Mid(Request.QueryString("phone"), pbeg + 3, 4)
		end if

	end function

	function getNextCustomerID()
		dim sql
		sql = "select isnull(max(convert(bigint, c.i)) + 1, 1) as 'nextCustomerID' from (select replace(replace(customerid, ' ', ''), ',', '') as i from customer) as c where isnumeric(c.i) = 1"
		dim rs
		Set rs = getDisconnectedRecordset(sql)
		if not rs is nothing and not rs.EOF and not rs.BOF then
			rs.MoveFirst
			getNextCustomerID = (rs("nextCustomerID").Value)
			rs.Close
		else
			getNextCustomerID = 1
		end if
		Set rs = Nothing
	end function

	function  getRequiredFields()
	dim rstrequired

	l_brfirstname = 0
	l_brdob = 0
	l_brmainphone = 0
	l_brmainAddress = 0
	l_bremail = 0
	l_brCustomerSource = 0
	l_brcellphone = 0

	sqltxt = "select * from requiredcustomerfields where storeid =" & l_storeid

	set rstrequired = getdisconnectedrecordset(sqltxt)

	 while  not rstrequired.bof and not rstrequired.eof

		select case lcase(rstrequired("fieldname"))

		case "firstname"
			if rstrequired("required") then
				l_brfirstname= 1
			end if
		case "dateofbirth"
			if rstrequired("required") then
				l_brdob= 1
			end if
	    case "mainphone"
			if rstrequired("required") then
				l_brmainphone= 1
			end if
		case "email"
			if rstrequired("required") then
				l_bremail= 1
			end if

		case "mainaddress"
			if rstrequired("required") then
				l_brmainAddress= 1
			end if

		case "cellphone"
		    if rstrequired("required") then
		        l_brcellphone= 1
		    end if

		case "customersource"
			if rstrequired("required") then
				l_brCustomerSource= 1
			end if



		end select


	    rstrequired.movenext
	 wend
	rstrequired.close
	set rstrequired = nothing

end function

function validateNameAndPhone()
	dim query, rs
	dim areacode
	dim phone

	areacode = l_mareacode
	phone = l_mphone

	areacode = replace(areacode, "(", "")
	areacode = replace(areacode, ")", "")
	areacode = replace(areacode, " ", "")

	phone = replace(phone, "-", "")
	phone = replace(phone, " ", "")

	query = "select * from customer where firstname = '" & DBStr(l_firstname) & "'" _
	& " and lastname = '" & DBStr(l_lastname) & "'" _
	& " and mainareacode = '" & areacode & "'" _
	& " and mainphone = '" & phone & "'"


	set rs = getdisconnectedrecordset(query)


	if rs.recordcount > 0 then
		l_err = "Duplicate customer already exists"
	else
		l_err = ""
	end if

	set rs = nothing
end function


function getShipPostaldetails()
Dim sqltxt
dim rstTemp
sqltxt = "select postalcode, cityname, stateabbreviation from postalcode where postalcode = " & dbcreateqrystring(Request.form("txtshipZip"))
'Response.Write sqltxt
set rsttemp = getdisconnectedRecordset(sqltxt)
l_scity = ""
l_sstate = ""
if  rstTemp.recordcount > 0 then
	l_scity = rstTemp("cityname")
	l_sstate = rstTemp("stateabbreviation")
	l_szip = rstTemp("Postalcode")

	l_bcity = l_scity
	l_bstate = l_sstate
	l_bzip = l_szip
end if

rstTemp.close
set rstTemp = nothing
end function


function getBillPostaldetails()
Dim sqltxt
dim rstTemp
sqltxt = "select postalcode, cityname, stateabbreviation from postalcode where postalcode = " & dbcreateqrystring(Request.form("txtbillZip"))
l_bcity  = ""
l_bstate = ""
set rsttemp = getdisconnectedRecordset(sqltxt)
if  rstTemp.recordcount > 0 then
	l_bcity = rstTemp("cityname")
	l_bstate = rstTemp("stateabbreviation")
	l_bzip = rstTemp("Postalcode")
end if

rstTemp.close
set rstTemp = nothing
end function

Function UpdateDatabase()
dim f_custSource
dim f_birthdate
dim sMainareacode
dim sMainPhone
dim sAareacode
dim sAltPhone
dim sCellPhone
dim rstotalRec
dim rstotal
dim ssql


	sMainareacode = replace(Request.form("txtMainAreacode"),  "(","")

	sMainareacode = trim(replace(sMainareacode, ")",""))

	sMainPhone = replace(Request.form("txtMainPhone"), "-","")

	sAareacode = replace(Request.form("txtAltareaCode"), "(","")

	sAareacode = trim(replace(sAareacode, ")",""))

	sAltPhone = replace(Request.form("txtAltPhone"), "-","")

	sCellPhone = replace(request.Form("txtCellPhoneAreaCode") & Request.form("txtCellPhone"),  "(","")
	sCellPhone = trim(replace(sCellPhone, ")",""))
	sCellPhone = replace(sCellPhone,"-","")

	customerseq = session("customersequencenumber")
	if customerseq = "" then
	    customerseq = Request.QueryString("customerseq")
	end if

	f_custsource = Request.Form("Customersources")

	if f_custsource = "0" then
		f_custsource= "null"
	end if

	l_baddress =0
	l_bdob = 1
	l_bpref = 0

	if Request.Form("baddress") = "1" then
		l_baddress = 1
	end if

	if Request.Form("bdob") = "1" then
		l_bdob = 1
	end if

	if Request.Form("bpref") = "1" then
		l_bpref = 1
	end if

	if customerseq = "" and (l_mode="add" )Then
		if (isnull(l_customerid) or l_customerid="") then
			sqltxt = "select totalrec =count(*), currentRecord= max(Customersequencenumber) from customer"

			set rstotalrec = getdisconnectedrecordset(sqltxt)

			l_totalrec =rstotalrec("totalrec")
			l_currec= rstotalrec("totalrec") +1

			if isnull(rstotalrec("currentRecord")) then
				l_customerid = 1
			else
				l_customerid = getNextCustomerID() 'rstotalrec("currentRecord") + 1
			end if
			rstotalrec.close
			set rstotal=nothing
		end if

		sqltxt = "SET NOCOUNT ON;"
		sqltxt = Sqltxt & "insert Customer (createdEmployeeID, OnDemandQualified, showNotesOnEachAccess, storeid, customerid,firstname,lastname "

		if l_bdob = 1 then ' dob visible
			sqltxt = Sqltxt & ",birthdate"
		end if

		if l_baddress = 1 then ' address visible
			sqltxt  = sqltxt & ",billingaddress1"  _
							& ",billingaddress2,billingaddress3,billingzipcode,billingcity,billingstate"  _
							& ",shippingaddress1,shippingaddress2,shippingaddress3,shippingzipcode,shippingcity,shippingstate"
		end if

		sqltxt = sqltxt & ",mainareacode,mainphone,altareacode,altphone, cellphone,SendTextAlert,email,defaultpricelistid,customersourceid,wantsEmailAlerts,contactPref,billingAddressSameAsShipping"

		sqltxt = sqltxt & " ) values (" & session("employeeid") & ", "

		 if getDefaultOnDemandStatus(l_storeid) then
		    sqltxt = sqltxt & "1, "
		 else
		    sqltxt = sqltxt & "0, "
		 end if

		 sqltxt = sqltxt & "0, " _
					& l_storeid _
					& "," & dbcreateQryString(l_customerid)   _
					& ", " & dbcreateQryString(trim(Request.form("txtfirstname"))) _
					& ", " & dbcreateQryString(trim(Request.form("txtlastname")))

		if l_bdob = 1 then
			sqltxt =  sqltxt & ", " & dbcreateQryString(Request.form("txtbirthdate") )
		end if

		if l_baddress = 1 then

			if evalRequestValue(Request.form("billingAddressSameAsShipping")) then

				sqltxt = sqltxt & ", " & dbcreateQryString(Request.form("txtshipaddr1")) _
						& ", " & dbcreateQryString(Request.form("txtshipaddr2")) _
						& ", " & dbcreateQryString(Request.form("txtshipaddr3")) _
						& ", " & dbcreateQryString(Request.form("txtshipzip")) _
						& ", " & dbcreateQryString(Request.form("txtshipcity"))  _
						& ", " & dbcreateQryString(Request.form("txtshipstate"))
			else

				sqltxt = sqltxt & ", " & dbcreateQryString(Request.form("txtbilladdr1")) _
						& ", " & dbcreateQryString(Request.form("txtbilladdr2")) _
						& ", " & dbcreateQryString(Request.form("txtbilladdr3")) _
						& ", " & dbcreateQryString(Request.form("txtbillzip"))  _
						& ", " & dbcreateQryString(Request.form("txtbillcity") ) _
						& ", " & dbcreateQryString(Request.form("txtbillstate")) _
			end if


			sqltxt = sqltxt & ", " & dbcreateQryString(Request.form("txtshipaddr1")) _
					& ", " & dbcreateQryString(Request.form("txtshipaddr2")) _
					& ", " & dbcreateQryString(Request.form("txtshipaddr3")) _
					& ", " & dbcreateQryString(Request.form("txtshipzip")) _
					& ", " & dbcreateQryString(Request.form("txtshipcity"))  _
					& ", " & dbcreateQryString(Request.form("txtshipstate"))
		end if

		sqltxt = sqltxt & ", " & dbcreateQryString(sMainareacode) _
					& ", " & dbcreateQryString(sMainPhone) _
					& ", " & dbcreateQryString(sAareacode) _
					& ", " & dbcreateQryString(sAltPhone) _
					& ", " & dbcreateQryString(sCellPhone) _
					& ", " & evalRequestValue(Request.Form("chkTextAlert"))_
					& ", " & dbcreateQryString(Request.form("txtEmail"))_
					& ", " & dbcreateQryNumeric(Request.form("pricetable")) _
					& ", " & f_custsource _
					& ", " & evalRequestValue(Request.form("chkEmailAlert")) _
					& ", " & dbcreateQryNumeric(Request.form("contactPref")) _
					& ", " & evalRequestValue(Request.form("billingAddressSameAsShipping"))

		sqltxt = sqltxt & ");"
		sqltxt = sqltxt & "SELECT SCOPE_IDENTITY(); SET NOCOUNT OFF;"

		DbStartTrans()


		session("customersequencenumber") = QryExecuteWithTransAndSelect(sqltxt)
		customerseq = session("customersequencenumber")
		if (trim(Request.form("txtshipzip")) <> "" )  then
				sqltxt = "execute dbo.UpdatePostalcode " _
						 & dbcreateQryString(Request.form("txtshipzip"))_
						 & ", " & dbcreateQryString(Request.form("txtshipcity"))  _
						 & ", " & dbcreateQryString(Request.form("txtshipstate"))

				qryexecutewithtrans(sqltxt)
		end if
		DbEndTrans()

		addCustomerToRoute session("customersequencenumber"), Session("filterRouteNumber")
		setCustomerParent session("customersequencenumber"), Session("filterCommercialAccount")

		if (getPrintChoice(l_storeid)) then

			sqltxt = "delete from newcust"
			qryexecute sqltxt

			datasource = "\DATASOURCES\localhost shahcorp newcust.odc"

			sqltxt = "insert into newcust select * from customer "
			sqltxt = sqltxt & "where customersequencenumber = " & session("customersequencenumber")
			qryexecute sqltxt
			set objWord = Server.CreateObject("ShahCorpComponents.MarketingLetters")
			objWord.mailMergeLetterToPrinter "newcust.doc", datasource
		end if

	Elseif (l_mode="edit") then

		sqltxt = "update Customer set " _
					& "customerid = " & dbcreateQryString(trim(Request.Form("txtcustomerid")))   _
					& ",firstname =" & dbcreateQryString(trim(Request.form("txtfirstname"))) _
					& ",lastname=" & dbcreateQryString(trim(Request.form("txtlastname")))

		if l_bdob then
			sqltxt= sqltxt & ",birthdate=" & dbcreateQryString(Request.form("txtbirthdate") )
		end if

		if l_baddress then
			if evalRequestValue(Request.form("billingAddressSameAsShipping")) then
				sqltxt = sqltxt & ",billingaddress1=" & dbcreateQryString(Request.form("txtshipaddr1")) _
					& ",billingaddress2=" & dbcreateQryString(Request.form("txtshipaddr2")) _
					& ",billingaddress3=" & dbcreateQryString(Request.form("txtshipaddr3")) _
					& ",billingzipcode=" & dbcreateQryString(Request.form("txtshipzip"))  _
					& ",billingcity=" & dbcreateQryString(Request.form("txtshipcity") ) _
					& ",billingstate=" & dbcreateQryString(Request.form("txtshipstate"))
			else
				sqltxt = sqltxt & ",billingaddress1=" & dbcreateQryString(Request.form("txtbilladdr1")) _
					& ",billingaddress2=" & dbcreateQryString(Request.form("txtbilladdr2")) _
					& ",billingaddress3=" & dbcreateQryString(Request.form("txtbilladdr3")) _
					& ",billingzipcode=" & dbcreateQryString(Request.form("txtbillzip"))  _
					& ",billingcity=" & dbcreateQryString(Request.form("txtbillcity") ) _
					& ",billingstate=" & dbcreateQryString(Request.form("txtbillstate"))
			end if
			sqltxt = sqltxt & ",shippingaddress1=" & dbcreateQryString(Request.form("txtshipaddr1")) _
				& ",shippingaddress2=" & dbcreateQryString(Request.form("txtshipaddr2")) _
				& ",shippingaddress3=" & dbcreateQryString(Request.form("txtshipaddr3")) _
				& ",shippingzipcode=" & dbcreateQryString(Request.form("txtshipzip")) _
				& ",shippingcity=" & dbcreateQryString(Request.form("txtshipcity"))  _
				& ",shippingstate=" & dbcreateQryString(Request.form("txtshipstate"))
		end if

		sqltxt = sqltxt & ",mainareacode=" & dbcreateQryString(sMainareacode) _
					& ",mainphone=" & dbcreateQryString(sMainPhone) _
					& ",altareacode=" & dbcreateQryString(sAareacode) _
					& ",altphone=" & dbcreateQryString(sAltPhone) _
					& ",cellphone=" & dbcreateQryString(sCellPhone) _
					& ",SendTextAlert=" & evalRequestValue(Request.Form("chkTextAlert")) _
					& ",email=" & dbcreateQryString(Request.form("txtEmail"))_
					& ",defaultpricelistid =" & dbcreateQryNumeric(Request.form("pricetable")) _
					& ",customersourceid=" & f_custsource _
					& ",wantsEmailAlerts=" & evalRequestValue(Request.form("chkEmailAlert")) _
					& ",contactPref=" & dbcreateQryNumeric(Request.form("contactPref")) _
 			    & ",billingAddressSameAsShipping=" & evalRequestValue(Request.form("billingAddressSameAsShipping"))

			sqltxt = sqltxt & " where customersequencenumber="  & customerseq '" 'and storeid = " & l_storeid

			'Response.Write sqltxt

			DbStartTrans()

			QryExecuteWithTrans(sqltxt)

			if (trim(Request.form("txtshipzip")) <> "" ) then
				sqltxt = "execute dbo.UpdatePostalcode " _
						 & dbcreateQryString(Request.form("txtshipzip"))_
						 & ", " & dbcreateQryString(Request.form("txtshipcity"))  _
						 & ", " & dbcreateQryString(Request.form("txtshipstate"))
				QryExecuteWithTrans(sqltxt)
			end if

			DbEndTrans()

		End if

		if areHeatSealsUsed() then
			if getConveyorType() = "WH" then
				if l_mode = "add" then
					ssql = "exec sendtoWhiteConveyor 'CUSTOMER_CREATE'," & session("customersequencenumber")
					QryExecute ssql
					ssql = "exec sendtoWhiteADC 'CUSTOMER_CREATE'," & session("customersequencenumber")
           			QryExecute ssql
				elseif l_mode = "edit" then
					ssql = "exec sendtoWhiteConveyor 'CUSTOMER_MODIFY'," & session("customersequencenumber")
					QryExecute ssql
					ssql = "exec sendtoWhiteADC 'CUSTOMER_MODIFY'," & session("customersequencenumber")
           			QryExecute ssql
				end if
			end if
		end if

    sendWelcomeMessage()
    if (l_mode="edit") then
        checkTrackedFields()
    end if

	End function

    function sendWelcomeMessage()
    on error resume next
        dim newCell, sql

        if len(trim(Request.QueryString("newCell"))) <> 0 then
            newCell = trim(Request.QueryString("newCell"))
        else
            newCell = 0
        end if

        if newCell = 1 then
            sql = "update customer set twilioBlackList = 0 where customersequencenumber = " & session("customersequencenumber")
            qryexecute sql

            if isMessengerEnabled() then
                on error resume next
                Dim httpRequest, postResponse, data

                data = "customerSeq=" & customerseq

                Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
                httpRequest.Open "POST", getMessengerFullPath("main") & "/cellPhoneUpdated", False
                httpRequest.SetRequestHeader "Content-Type", "application/x-www-form-urlencoded"
                httpRequest.Send data
                postResponse = httpRequest.ResponseText

            end if

        end if

    end function

    function checkTrackedFields
        dim fieldsToCheck, query, currValrs, currVal, oldVal
        fieldsToCheck = getTrackedFields
        query = "select " & fieldsToCheck & " from customer where customerSequenceNumber = " & customerSeq
        set currValrs = getdisconnectedrecordset(query)
        dim fieldArr, i, currField
        fieldArr = Split(queryFields, ", ")
        For i = LBound(fieldArr) To UBound(fieldArr)
            currField = fieldArr(i)
            currVal = trim(currValrs(currField))
            oldVal = trim(Request.Form("old_" & currField))
            if currVal <> oldVal then
            query = "insert into CustFieldChgTracker (CustomerSeqNum, Field, OldValue, NewValue, EmployeeId) values " _
                & "(" & customerSeq & ", '" & currField & "', '" & DBStr(oldVal) & "', '" & DBStr(currVal) & "', " _
                & Session("EmployeeID") & ")"
            qryexecute query
            end if
        Next
    end function

	function isDupCustomerNameAllowed()
		dim query, rs

		query = " select allowDupCustNames from miscsetup where storeid = " & session("storeid")

		set rs = getdisconnectedrecordset(query)

		isDupCustomerNameAllowed = rs("allowDupCustNames")

		set rs = nothing
	end function

	function areHeatSealsUsed()
		dim query, rs
		query = " select useHeatSeal from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		areHeatSealsUsed = rs("useheatseal")
		set rs = nothing
	end function

	function getConveyorType()
		dim query, rs
		query = "select conveyorType from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getConveyorType = rs("conveyorType")
		set rs = nothing
	end function

	function getRouteVersion(storeid)
		dim query, rs

		query = " select routeVersion from miscsetup where storeid = " & session("storeid")

		set rs = getdisconnectedrecordset(query)

		getRouteVersion = rs("routeVersion")

		set rs = nothing
	end function

	function getPrintChoice(storeid)
		dim query, rs

		query = " select printNewCustomerLetter from miscsetup where storeid = " & session("storeid")

		set rs = getdisconnectedrecordset(query)

		getPrintChoice = rs("printNewCustomerLetter")

		set rs = nothing
	end function

	function getDefaultOnDemandStatus(storeid)
		dim query, rs
		query = " select ondQualifiedDefault from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		getDefaultOnDemandStatus = rs("ondQualifiedDefault")
		set rs = nothing
	end function

	function toggleMultiPickup(customerseq)
		dim query

		query = " update customer set multiplePickup = case multiplePickup when 1 then 0 else 1 end "
		query = query & " where customersequencenumber = " & customerseq

		qryexecute query
	end function



	function addCustomerToRoute(customerSequenceNumber, routeNumber)
		dim query
		if routeNumber <> "" then
			query = " update customer set routeNumber = " & routeNumber
			query = query & " where customersequencenumber = " & customerSequenceNumber

			qryexecute query
		end if
	end function

	function setCustomerParent(customerSequenceNumber, parentSequenceNumber)
		dim query
		if parentSequenceNumber <> "" then
			query = " update customer set parentCustomerSeq = " & parentSequenceNumber
			query = query & " where customersequencenumber = " & customerSequenceNumber

			qryexecute query
		end if
	end function

%>



