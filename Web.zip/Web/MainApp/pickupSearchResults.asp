<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim dosearch
	dim objresult  
		
%>

<HTML>
<HEAD>
<TITLE>PickUp Search</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
	<SCRIPT LANGUAGE=javascript>
	var lastFocusControl;
	var previousElement=null;
	var x;
	var vshowNotes;
	<!--
				
		function selectRow(element) {
			var childEl;
			if (previousElement !=null){
				previousElement.className="";
			}
			childEl = element.children[0];
			var rowChildNodes = childEl.children
			for(i=0; i<rowChildNodes.length; i++){
				childEl = rowChildNodes[i];
				if (childEl.name == "selectid") {
					x = childEl.value;
				}
				if (childEl.name == "showNotes") {
					vshowNotes = childEl.value;
				}
				
			/*	if(childEl.tagName == "INPUT") {
					childEl.checked=true;
					break;
				}
			*/
			}
			previousElement =element;
			element.className="selected";
			document.searchResults.selectButton.disabled= false;
		}
		
		
	//-->
	</SCRIPT>

<script language="javascript" type="text/javascript">
	
	
	function selectCustomer(){
	var straction
	
		straction = "?targetpage=" + "pickup" +  "&customerseq=" + x ;
	
		if (vshowNotes == "True") {
				document.searchResults.action = "CustomerNotes.asp" + straction;
				document.searchResults.submit();
		}
		else{
			document.searchResults.action = "customerfunctions.asp?customerseq=" + x;
			document.searchResults.submit();
		}
	}
	
	function cancelForm(){
		document.searchResults.action ="pickupSearch.asp";
		document.searchResults.submit();
	}
	
	function captureKeyUpEvent(element) {
	  	if (event.keyCode == 13){
	  		event.returnValue = true;	
			selectCustomer();
		}
	}
	
</SCRIPT>
</HEAD>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Pickup Search Results</H1><BR><BR>
<CENTER>
<TABLE width="100%" align=center cellspacing="0" cellpadding="0" border="0">
  <FORM id="searchResults" name="searchResults" action="" method="Post">
	
<tr  class="cmdbar">
	<td>
		<div>
			<span style="float:left">
				<button id=selectButton name=selectButton onClick="selectCustomer()" disabled>Select</button>
			</span>
			
			<span style="float:right">
				<button id=cancelButton name=cancelButton onClick="history.back(-1)">Cancel</button>
			</span>
		</div>
	<td>
</tr>

<TR>
   <TD>
		<TABLE class="itable" align=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 style="WIDTH: 100%;">
			<TR>
				<TH style="width=25%">Customer Name</TH>
				<TH style="width=20%">Phone</TH>
				<TH style="width=30%">Address</TH>
				<TH style="width=15%">City</TH>
				<TH style="width=10%">Route</TH>
			</TR>
			<%
				'Response.Write " going to reterived results "
				getSearchResult()
				if objresult.recordcount < 1 then %>
					Search criteria could not find any matching customers
			<%	else
				while not objresult.EOF
							
			%>
			<TR  onDblClick="selectRow(this);selectCustomer();" onClick="selectRow(this)" onKeyPress="captureKeyUpEvent(this)" >
				<TD style="padding-left:10px;text-align:left;font-size=18px"><input type=hidden name="selectid" id="selectid" value="<%=objresult("customersequencenumber")%>">
				<input type="hidden" name="showNotes" id="showNotes" style="Height=25px;Width=25px" value="<%=objresult("showNotesOnEachAccess")%>">
				<%=objresult("customername")%>&nbsp</TD>
				<TD style="padding-left:10px;text-align:left;font-size=18px"><%=formatareacode(objresult("mainareacode")) & formatPhone(objresult("mainphone"))%>&nbsp</TD>
				<TD style="padding-left:10px;text-align:left;font-size=18px"><%= objresult("shippingaddress1")%>&nbsp</TD>
				<TD style="padding-left:10px;text-align:left;font-size=18px"><%=objresult("shippingCity")%>&nbsp</TD>
				<TD style="padding-left:10px;text-align:left;font-size=18px"><%=objresult("RouteName")%>&nbsp</TD>
				
			</TR>
			<%
				objresult.movenext
				wend
				objresult.close
				set objresult = nothing
				end if
			%>
									
		</TABLE>
		</div>
		
		<BR>
	</TD>
</TR>

</FORM>   
</TABLE>
</CENTER>
</BODY>
</HTML>
<% 

	function getSearchResult()
	dim name
	dim customerid
	dim sqltxt
	
		name = Request.QueryString("name")
		customerid=Request.QueryString("id")
		sqltxt = CreateQryString(name, customerid)
		set objresult = getdisconnectedrecordset(sqltxt)
	
	end function
	
	function formatareacode(sareacode) 
		formatareacode= ""
		if not isnull(sareacode) then
			formatareacode= "(" & sareacode & ")"
		end	if
	end function
	
	function formatname(slname, sfname)
		formatname= ""
		if not isnull(slname) then
			formatname= checkfornull(slname) + ", "  + checkfornull(sfname)
		end if
	
	end function

	function formatphone(sPhone) 
		formatphone= ""
		if not isnull(sPhone) and  len(trim(sPhone)) = 7 then
			formatphone=   left(sPhone, 3) & "-" & right(sPhone, 4)
		else
			formatphone = sPhone
		end	if
	end function
	
	function CreateQryString(name, customerid)
	dim strqry
	
	dim sqryPhone
	
	if isNumeric(name) and len(trim(name))  = 10  then
	
		sqryphone = "or ( (mainareacode+mainphone) like " & "'"&  name & "%')"
		
	elseif isNumeric(name) and len(trim(name)) = 7 then
	
		sqryphone = "or ( mainphone  like " & "'"&  name & "%')"
	
	end if	
	
	if trim(name) <>"" then
	
		strqry = "select distinct lastname, firstname, T.customersequencenumber, lastname + ' ' + isnull(firstname, '') + ' ' + "_
			& "isnull(middleinitial, '') as customername, shippingaddress1, shippingcity,  mainareacode, " _
			& "mainphone, r.name as 'routeName', showNotesonEachAccess " _
			& "from route R right outer join customer C inner join ticket T on " _
			& "C.customerSequenceNumber = T.customerSequenceNumber ON R.routeNumber = C.routeNumber " _
			& "where T.ticketStatus = 'AC' and T.invoicetype = 'D' and " _
			& "(lastname like" & "'" & name & "%')" _
			& " and c.isactive = 1"

		strqry = strqry & sqryphone & " order by lastname, firstname"
		
	elseif trim(customerid) <> "" then
	
		strqry = "select distinct lastname, firstname, T.customersequencenumber, lastname + ' ' + isnull(firstname, '') + ' ' + " _
			& "isnull(middleinitial, '') as customername, shippingaddress1, shippingcity,  mainareacode, " _
			& "mainphone, r.name as 'routeName', showNotesonEachAccess " _
			& "from route R right outer join customer C inner join ticket T on " _
			& "C.customerSequenceNumber = T.customerSequenceNumber ON R.routeNumber = C.routeNumber " _
			& "where T.ticketStatus = 'AC'  and T.invoicetype = 'D' and " _
			& "customerid = " & "'" & customerid & "'" _
			& " and c.isactive = 1" _
			& " order by lastname, firstname"
	else
		strqry = "Select distinct lastname, firstname, T.customersequencenumber, lastname + ' ' + isnull(firstname, '') + ' ' + " _
			& "isnull(middleinitial, '') as customername, shippingaddress1, shippingcity,  mainareacode, " _
			& "mainphone, r.name as 'routeName', showNotesonEachAccess " _
			& "from route R right outer join customer C inner join ticket T on " _
			& "C.customerSequenceNumber = T.customerSequenceNumber ON R.routeNumber = C.routeNumber " _
			& "where T.ticketStatus = 'AC' and T.invoicetype = 'D' " _
			& " and c.isactive = 1" _			
			& "order by lastname, firstname"
	end if
	
	createQryString = strqry
	end function
%>
