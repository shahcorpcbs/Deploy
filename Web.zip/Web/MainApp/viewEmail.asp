<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 900 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!-- #include file="../include/form_merge.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim bodyText
	dim messageID

	messageID = request.querystring("messageid")

	function addFieldParameter(fields, name, value)
		if fields.exists(name) then
			fields.remove name
		end if
		fields.add name, value
	end function
	
	function transformMessage(messageID, body)
		dim query, rs
		dim rs_f
		dim param_name
		dim fields
		dim i
		
		query = " select * from messageparam where messageid = " & messageID
		set rs = getdisconnectedrecordset(query)
		
		
		
		if rs.recordcount > 0 then
			set fields = server.createobject("scripting.dictionary")
		
			while not(rs.eof or rs.bof)
				param_name = rs("name")
				if left(param_name, 3) = "@@@" then
					addFieldParameter fields, mid(param_name, 4), rs("value")
				else
					select case lcase(rs("name"))
					case "employeeid"
						query = ""
					case "customerseq"
						query = " select * "
						query = query & " from customerfields where customersequencenumber = " & rs("value")
					case "ticketnumber"
						query = " select invoicenumber as [Invoice_Number], "
						query = query & " convert(varchar, createddate, 101) as [Invoice_Dropoff] "
						query = query & " from ticket where ticketnumber = " & rs("value")
					case else
						query = ""
					end select
					if query <> "" then
						set rs_f = getdisconnectedrecordset(query)
						if rs_f.recordcount > 0 then
						  for i = 0 to rs_f.Fields.Count - 1
						  	if not isnull(rs_f.Fields(i).Value) then
							  	addFieldParameter fields, rs_f.Fields(i).Name, rs_f.Fields(i).Value
						  	end if
						  next					
						end if
					end if
				end if
				
				rs.movenext
			wend
			
			dim form_params
			set form_params = getFormParams(body)
			transformMessage = transformQuery(body, form_params, fields)
		else
			transformMessage = body
		end if
	end function
	
	if messageID <> "" and messageID <> "undefined" then
		query = " select bodyText from emailqueue where messageid = " & messageID
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			bodyText = transformMessage(messageID, rs("bodyText"))
		end if
	end if
	
	
	
%>

<HTML>
<HEAD>
<TITLE>Email Message</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT language="javascript" type="text/javascript">

</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="selectAllMessages()">


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">


	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="window.close()" value="" >Exit</BUTTON>
	</SPAN>
</DIV>	

<PRE>
<%=bodyText%>
</PRE>

</BODY>
</HTML>

