<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%	
	getCriteriaList()
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Marketing Criteria List</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function enableButton(){		
		if (document.criteriaList.critList.size > 0 ) 
			document.criteriaList.select.disabled = false;
		else
			document.criteriaList.select.disabled = true;
	}	
	
	function selectCriteria() {	
		if (document.criteriaList.critList.selectedIndex < 0 ) {
			cbs_alert("Please select a criteria from list");
			return false;
		}
		document.criteriaList.action= "selectCriteria.asp?criteriaID="+document.criteriaList.critList.options[criteriaList.critList.selectedIndex].value;
		document.criteriaList.submit();		
	}
	
	function cancelForm(){
		document.criteriaList.action = "marketingCriteria.asp";
		document.criteriaList.submit();	
	}

	
</script>
<BODY topmargin=0 leftmargin=0 onload ="enableButton()">

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">&nbsp;Marketing Criteria List</B>
<FORM id="criteriaList" name="criteriaList" action="" method="post">
	<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=0 CELLPADDING=2 >
		<tr>
			<td align="center" colspan=2>
				<%GetCriteriaList() %>
				<select id=critList name=critList style="width:400px;font-size=16px" size=10 >
				
				 <%if rstList.recordcount > 0 then
					while not rstlist.eof 
				 %>
				 <% if rstlist("searchName") <> "" then %>
					<option value ="<%=rstList("CriteriaID")%>">
					<% 	Response.Write rstList("searchName")%>
					</option>
				<% end if %>
				<%rstlist.movenext
					wend
					 end if
					 rstList.close
					 set rstlist = nothing
				%>				
				</select>
			</td>
		</tr>
		<tr height=20px></tr>
		<tr>
			<td>
				<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
					<tr>
						<td align="center">
							<INPUT class=touch id=select name=select type=button value="" style="background-image:url(../images/Select.gif)" onClick="selectCriteria()"><br>select
						</td><td align="center">	
							<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)"onClick="cancelForm()">
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</form>
</BODY>
</HTML>
<%
	dim rstList
	function getCriteriaList()
	dim sqltxt
		sqltxt = "select * from marketingLettersCriteria order by criteriaID"
		set rstList = GetDisconnectedRecordset(sqltxt)
	end function
%>