<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim customerseq
	dim dateBegin
	dim dateEnd
	dim previousBalance
	
	previousBalance = 0
	
	customerSeq = getReqVar("customerSeq")
	dateBegin = getReqVar("dateBegin")
	dateEnd = getReqVar("dateEnd")
	if dateBegin = "" then dateBegin = dateadd("m",-3,date())
	if dateEnd = "" then dateEnd = Date()
	
	select case lcase(request.querystring("useraction"))
	case "updatedescription"
		updateLedgerDescription request.querystring("ledgernumber"), request.querystring("description") 
	case "updateamount"
		updateLedgerAmount request.querystring("ledgernumber"), request.querystring("amount") 
	end select 
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	function updateLedgerDescription(ledgerNumber, description)
		dim query, rs
		
		query = " update generalledger set refdescription = '" & description & "'"
		query = query & " where ledgernumber = " & ledgernumber
		
		qryexecute query
	end function
	
	
	function updateLedgerAmount(ledgerNumber, amount)
		dim query, rs
		
		query = " update generalledger set amountdue = " & amount 
		query = query & " where ledgernumber = " & ledgernumber
		
		qryexecute query
	end function


	function getPreviousBalance(customerSeq, dateBegin)
		dim query, rs
		
		query = " select isnull(sum(generalledger.amountdue - isnull(generalledger.routediscount,0)), 0) as previousbalance "
		query = query & " from generalledger where "
		query = query & " generalledger.customersequencenumber = " & customerseq
		query = query & " and datediff(day, generalledger.createddate, '" & dateBegin & "') > 0 "
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getPreviousBalance = rs(0)
		else
			getPreviousBalance = 0
		end if
		
		set rs = nothing
	end function
	

%>
<HTML>
<HEAD>
<TITLE>Account History</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">
	var previousElement = null;
	var selectedLedgerNumber = null;
	var selectedAmount = 0;
	var accountStatementId = null;
	
	function viewCustomerFunctions(customerseq) {
        document.accountHistory.action = "customerfunctions.asp?customerseq=" + customerseq;
        document.accountHistory.submit();
	}
	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}
		if(element.getAttribute('rtype') === "statement") {
			accountStatementId = element.getAttribute('accountstatementid');
			selectedLedgerNumber = null;
			selectedAmount = 0;
			document.accountHistory.btnViewStatement.disabled= false;
		}
		
		else {
			accountStatementId = null;
			selectedLedgerNumber = element.getAttribute('ledgernumber');
			selectedAmount = element.getAttribute('amount');
			document.accountHistory.btnViewStatement.disabled= true;
		}

		
		previousElement =element;
		
		element.className = "selected";
		
		//document.accountHistory.btnEditDescription.disabled= false;
		//document.accountHistory.btnEditAmount.disabled= false;
	}

	function editDescription() {
		cbs_prompt("Enter Description", handleDescChoice);
	}

    function handleDescChoice(description) {
        clearPromptMsg();
        var description = document.getElementById('inputTxtLine').value;
		if (description != null) {
			document.accountHistory.action = "?useraction=updatedescription&ledgernumber=" + selectedLedgerNumber + "&description=" + description;
			document.accountHistory.submit();
		}
    }
	
	function editAmount() {
		cbs_prompt("Enter Amount", handleAmtChoice);
	}


	function handleAmtChoice() {
        clearPromptMsg();
	    var amount = document.getElementById('inputTxtLine').value;
		if (amount != null) {
			document.accountHistory.action = "?useraction=updateamount&ledgernumber=" + selectedLedgerNumber + "&amount=" + amount;
			document.accountHistory.submit();
		}
	}
	
	function update() {
			document.accountHistory.action = "?useraction=update";
			document.accountHistory.submit();
	}
	
	function viewStatement() {
	        var y = window.outerHeight / 2 + window.screenY - (600 / 2)
            var x = window.outerWidth / 2 + window.screenX - (700 / 2)

            window.open("/mainapp/viewstatement.asp?accountStatementId=" + accountStatementId, 'Statement',
            			'center, edge=Sunken, toolbar=off, location=off, status=no, menubar=no, scrollbars=no, resizable=no, ' +
            			'width=600, height=700,top=' + y + ', left=' + x);

	}
	
</script>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Account History</H1>

<FORM id="accountHistory" name="accountHistory" action="" method="post">
<INPUT type="hidden" name="customerseq" value="<%=customerseq%>" />


Date range
<INPUT name="dateBegin" value="<%=dateBegin%>" readonly onclick="javascript:show_calendar('accountHistory.dateBegin');">
to
<INPUT name="dateEnd" value="<%=dateEnd%>" readonly onclick="javascript:show_calendar('accountHistory.dateEnd');">
<BUTTON onclick="update()">Look Up</BUTTON>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
<!--
		<BUTTON id="btnEditDescription" onclick="editDescription()" disabled>Edit<BR>Description</BUTTON>
		<BUTTON id="btnEditAmount" onclick="editAmount()" disabled>Edit<BR>Amount</BUTTON>
-->
		<BUTTON id="btnViewStatement" onclick="viewStatement()" disabled>View<BR>Statement</BUTTON>
	</SPAN>
	<SPAN style="float:right">
        <BUTTON onclick="viewCustomerFunctions(customerseq.value)">Exit</BUTTON>
	</SPAN>
</DIV>	

<%
	dim amountToDate
	
	query = " select generalledger.ledgernumber, "
	query = query & " isnull(generalledger.createddate, '') as createddate, "
	query = query & " isnull(generalledger.refdescription, '') + isnull(' - ' + payment.paymentTypeName + isnull(' #' + payment.checkOrCardNumber, ''), '') as refdescription, "
	query = query & " case generalledger.reftype when 'TI' then isnull(ticket.invoicenumber, '') else isnull(referencetypedomain.reftypedescription, '') end as reftypedescription, "
	query = query & " generalledger.reftype, isnull(isnull(generalledger.amountdue, amountdue), 0) as amountdue, "
	query = query & " isnull(employee.employeename, '') as employeename, isnull(generalledger.routediscount, 0) as routediscount "
	query = query & " from generalledger "
	query = query & " inner join referencetypedomain "
	query = query & " on generalledger.reftype = referencetypedomain.reftype " 
	query = query & " inner join employee "
	query = query & " on generalledger.createdemployeeid = employee.employeeid "
	query = query & " left outer join ticket "
	query = query & " on generalledger.reftype = 'TI' and generalledger.refnumber = ticket.ticketnumber "
	query = query & " left outer join payment "
	query = query & " on generalledger.reftype = 'PA' and generalledger.refnumber = payment.paymentNumber "
	query = query & " where generalledger.customersequencenumber = " & customerseq
	query = query & " and isnull(generalledger.refdescription,'') <> 'Credit due to excess payment' "
	
	if dateBegin <> "" then
		previousBalance = getPreviousBalance(customerSeq, dateBegin)
		query = query & " and datediff(day, generalledger.createddate, '" & dateBegin & "') <= 0 "
	end if
	
	
	if dateEnd <> "" then
		query = query & " and datediff(day, generalledger.createddate, '" & dateEnd & "') >= 0 "
	end if
	
	
	query = query & " union "
	
	query = query & " select accountstatement.accountstatementid as ledgernumber, "
	query = query & " accountstatement.statementrundate as [createddate], "
	query = query & " 'Statement ' + convert(varchar, accountstatement.statementRangeStartDate, 110) + ' to ' + convert(varchar, accountstatement.statementRangeEndDate, 110)  as [refdescription], "
	query = query & " '' as [reftypedescription], "
	query = query & " '@statement' as [reftype], "
	query = query & " 0 as [amountdue], "
	query = query & " '' as [employeename], "
	query = query & " 0 as [routediscount] "
	query = query & " from accountstatement "
	query = query & " where accountstatement.customersequencenumber = " & customerseq
	
	if dateBegin <> "" then
		query = query & " and datediff(day, accountstatement.statementrundate, '" & dateBegin & "') <= 0 "
	end if
	
	
	if dateEnd <> "" then
		query = query & " and datediff(day, accountstatement.statementrundate, '" & dateEnd & "') > 0 "
	end if
	
	
	query = query & " order by 2 "
	
%>

<div style="height: 640px; overflow: scroll">
<table class="itable" width="100%" cellspacing="0">
<tr>
	<th>&nbsp;</th>
	<th>Date</th>
	<th>Employee</th>
	<th>Description</th>
	<th>Referral</th>
	<th>Amount</th>
	<th>Discount</th>
	<th>To Date</th>
</tr>
<tr>
	<td>&nbsp;</td>
	<td colspan="6"><strong>Previous Balance</strong></td>
	<td align="right" style="padding-right:20px;"><%=formatcurrency(previousBalance)%></td>
</tr>

<%

	set rs = getdisconnectedrecordset(query)
	
	amountToDate = previousBalance
	
	while not(rs.eof or rs.bof)
		amountToDate = amountToDate + rs("amountdue") - rs("routediscount")

	if rs("reftype") = "@statement" then 
%>
<tr onClick="selectRow(this)" rtype="statement" accountstatementid="<%=rs("ledgernumber")%>" >
	<td>&nbsp;</td>
	<td><%=rs("createddate")%></td>
	<td colspan="6"><strong><%=server.htmlencode(rs("refdescription"))%></strong></td>
</tr>
<%	else
%>
<tr onClick="selectRow(this)" rtype="activity" ledgernumber="<%=rs("ledgernumber")%>" amount="<%=formatnumber(rs("amountdue"), 2, 0, 0, 0)%>">
	<td>&nbsp;</td>
	<td><%=rs("createddate")%></td>
	<td><%=Server.HTMLEncode(rs("employeename"))%></td>
	<td><%=Server.HTMLEncode(Replace(rs("refdescription"), "Ticket", "Invoice"))%></td>
	<td><%=Server.HTMLEncode(rs("reftypedescription"))%></td>
	<td><%=formatcurrency(rs("amountdue"))%></td>
	<td><%=formatcurrency(rs("routediscount"))%></td>
	<td align="right" style="padding-right:20px;"><%=formatcurrency(amountToDate)%></td>
</tr>
<%
	end if

		rs.movenext
	wend
	set rs = nothing
%>
</table>
</div>

</FORM>
</BODY>
</HTML>

