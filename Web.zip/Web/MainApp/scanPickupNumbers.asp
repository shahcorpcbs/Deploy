<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	'*******************************************************************
	'Name   : scanPickupNumbers.asp
    'Author : James Johnston
    'Created: 02-Oct-2003
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 02-Oct-2003    Johnston		Original version
	'*****************************************************************
	
dim InvoiceList
dim pickupObj
dim invoicesTotal
dim custSeqNumber
dim RackRst,rackStr, rackStr1, noOfRows
dim printRackInfo
dim invoicenumberchange
dim customername

InvoiceList= session("invoicelist")
set pickupObj = Session("pickupObj")
invoicesTotal = pickupObj.invoicesTotal
custSeqNumber = Session("customerSequenceNumber")
printRackInfo = ""
customerName = session("customername")
noOfRows = 0

invoicenumberchange = ""
set RackRst = Session("ticketRack")
noOfRows = RackRst.RecordCount
if RackRst.RecordCount > 0 then
	RackRst.MoveFirst
	while not RackRst.EOF
		rackStr= RackRst.Fields("rackLocationStart").Value
		rackStr1 = RackRst.Fields("rackLocationStart").Value
		if not IsNull(RackRst.Fields("rackLocationEnd").Value) then
			rackStr = rackStr & " - " & RackRst.Fields("rackLocationEnd").Value
			rackStr1 = rackStr1 & " - " & RackRst.Fields("rackLocationEnd").Value
		end if
		if trim(printRackInfo) = "" then
			printRackInfo =    customername & vbcrlf 
		end if						
		if trim(invoicenumberchange) = "" or invoicenumberchange <> trim(RackRst.Fields("invoicenumber").Value)  then
			invoicenumberchange = RackRst.Fields("invoicenumber").Value
			printRackInfo = printRackInfo & vbcrlf & invoicenumberchange & vbTab & vbTab
		else
			printRackInfo =  printRackInfo & ", "
		end if							
		if len(trim(printRackInfo)) = 0 then
			printRackInfo =  printRackInfo &  rackStr
		else
			printRackInfo =  printRackInfo &  rackStr1
		end if							
		RackRst.MoveNext
												
	wend								
end if

%>

<HTML>

<HEAD>

<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">

<TITLE>Scan Invoice Numbers</TITLE>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>

<script language="javascript" type="text/javascript">

	var lastFocusControl;
	var bScanned;	//Boolean: scanned, T or F
	
	bScanned=false;
	
	function submitForm(userAction) 
	{
		CompareLists()
		if (userAction =="ok") 
		{
			if (bScanned == true) 
			{
				document.invNumber.action = "pickup.asp?userAction=pickup&scanned="+bScanned;
				document.invNumber.submit();
			}
			else 
			{
				cbsAlert("Scanned tickets do not match pickup tickets.\nPlease Clear All and scan tickets again.",cbsOKOnly,"Scan Invoices");
			}
		}
	}
	
	
	function checkEnter(event)
	{ 	
		var code = 0;
		
		code = event.keyCode;
		if (code==13)
			submitForm("ok");
	}
	
	
	function validateEnterKey() 
	{
		return false;
	}
	
	
	//set the default focus on Invoice text box after loading the page.
	function setFocusOnFirstControl()
	{		
		{									
			document.invNumber.txtInvNumber.focus();
		}	
	}
	
	
	//Set the focus on Ok button.
	function setFocusOnControl()
	{				
		document.invNumber.okButton.focus();
	}	
	
	
	//Set the focus on ADD button.
	function setFocusOnAddControl()
	{				
		document.invNumber.AddNumber.focus();
		addItemToList();
	}	
	
	
	//Set the focus on OK button when enter key pressed in Invoice Textbox.
	function captureKeyUpEvent()
	{
		
		if (event.keyCode == 13)
		{			
			event.returnValue = true;
			setFocusOnAddControl();
			event.keyCode = 0;
		}
	}
	
	
	function onNumberBlur() 
	{
		lastFocusControl = document.getElementById("txtInvNumber");
	}
	
	
	function CompareLists()
	{
		var arr;
		var arr2;
		var incomingInvItem; 
		var sortedIncomingInvItem;
		var joinedSortedIncomingInvItem;
		var scanInvItem; 
		var sortedScanInvItem;
		var joinedSortedScanInvItem;		
		var i;
		var j;
		
		bScanned == false;
		
		// Split and sort incoming list at each comma character
		arr = document.invNumber.InvoiceList.value;		
		incomingInvItem = arr.split(", ");
		sortedIncomingInvItem = incomingInvItem.sort();
		joinedSortedIncomingInvItem = sortedIncomingInvItem.join(",");
		//cbsAlert("joinedSortedIncomingInvItem = "+joinedSortedIncomingInvItem,cbsOKOnly,"")
		
		// Build and sort scanned list at each comma character
		j = document.invNumber.selectInvoices.options.length;
		//cbsAlert("j = "+j,cbsOKOnly,"SplitInvoiceList()");
		
		if (j > 0 )
		{
			arr2 = document.invNumber.selectInvoices[0].value
			//cbsAlert("arr2 = "+arr2,cbsOKOnly,"SplitInvoiceList()");
			
			for (i=1;i<j;i++)  
			{
				arr2 = arr2 + ", " + document.invNumber.selectInvoices[i].value
				//cbsAlert("scanInvItem = "+scanInvItem,cbsOKOnly,"SplitInvoiceList()");			
			}
		
			scanInvItem = arr2.split(", ");
			sortedScanInvItem = scanInvItem.sort();
			joinedSortedScanInvItem = sortedScanInvItem.join(",");
			//cbsAlert("joinedSortedScanInvItem = "+joinedSortedScanInvItem,cbsOKOnly,"")
		}
		
		//Compare 2 strings
		if(joinedSortedIncomingInvItem == joinedSortedScanInvItem)
		{
			bScanned = true;
		}
	}
	
	
	function addItemToList()
	{
		var newOption
		var i = document.invNumber.selectInvoices.options.length
		
		if (checkForDuplicates())
		{
			newOption = new Option();
			newOption.value = document.invNumber.txtInvNumber.value;
			newOption.text = document.invNumber.txtInvNumber.value; 
			document.invNumber.selectInvoices.options[i] = newOption;
			document.invNumber.txtInvNumber.value = "";
		}
		setFocusOnFirstControl();
	}
	
	
	function checkForDuplicates()
	{
		var i;
		var j;
		var invoiceNumber;
		
		i = 0;
		j = document.invNumber.selectInvoices.options.length;
		invoiceNumber = document.invNumber.txtInvNumber.value; 
		
		if (document.invNumber.selectInvoices.options.length > 0 )
		{
			for (i=0;i<j;i++)  
			{
				if (document.invNumber.selectInvoices[i].value == invoiceNumber)
				{		
					cbsAlert("Duplicate Ticket Number " + invoiceNumber,cbsOKOnly,"Duplicate");
					event.keycode=0;
					document.invNumber.txtInvNumber.value = "";
					return false;				
				}
			}
		}
		return true;
	}	
	
	
	function deleteItems()
	{
		var i;
		i = 0;
		
		if (document.invNumber.selectInvoices.options.length > 0 )
		{
			while (i < document.invNumber.selectInvoices.options.length ) 
			{
				if (document.invNumber.selectInvoices[i].selected )
				{		
					document.invNumber.selectInvoices.options[i]=null;
				}
				else
					i++;
			}
		}
		setFocusOnFirstControl();	
	}	
	
	
	function deleteAllItems()
	{
		var i;
		i = 0;
				
		if (document.invNumber.selectInvoices.options.length > 0 )
		{
			while (i < document.invNumber.selectInvoices.options.length ) 
			{
				document.invNumber.selectInvoices.options[i]=null;
			}
		}
		setFocusOnFirstControl();	
	}
	
	
	function cancelForm() 
	{
		var custSeqNumber;
		custSeqNumber = document.invNumber.custSeqNumber.value;
		//document.invNumber.action = "customerfunctions.asp?customerseq="+custSeqNumber;
		document.invNumber.action = "currentInvoicesForPickup.asp?searchtype=customer&targetpage=pickupSearch&customersequencenumber="+custSeqNumber;
		document.invNumber.submit();		
	}	
	
	
	function printRackLocations() 
	{
		var rackStrForPrint;
		rackStrForPrint = document.invNumber.rackInfoForPrint.value;
		//alert(rackStrForPrint);
		PrintRackLocations(rackStrForPrint);		
	}	
		
</script>

<BODY topmargin=0 leftmargin=0 onload="setFocusOnFirstControl();">
<center>

<!-- #include file="../include/rackscanner.inc" -->
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/localprinter.inc" -->

<%
'Following adds an "S" to page heading if needed
dim tempString
dim searchString
searchString = ","
dim myPos
tempString = CStr(InvoiceList)
myPos = InStr(tempString,searchString)
if myPos>0 then 
	tempString = "s" 
else
	tempString = ""
end if
%>
<B class="pageHeading">&nbsp;Please scan Invoice Number<%=tempString%></B>
</center>

<FORM id="invNumber" name="invNumber" action="scanPickupNumbers.asp" method="post" onSubmit ="return validateEnterKey();" >

	<INPUT type="hidden" name="InvoiceList" value="<%= InvoiceList%>">
	<INPUT type="hidden" name="custSeqNumber" value="<%= custSeqNumber%>">
	<INPUT type="hidden" name="rackInfoForPrint" value="<%= printRackInfo%>">	

	<!-- Invoice Number, Total Due, Buttons -->
	<TABLE ALIGN=center WIDTH=90% BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		
		<!-- Invoice Number -->
		<TR valign=top>
			<TD class="label" align="center"><%=""%>Invoice Number&nbsp;</TD>
			<TD align=left>
				<INPUT id=txtInvNumber name=txtInvNumber maxLength=20 class=text style="WIDTH: 94px; HEIGHT: 25px" onKeyup="captureKeyUpEvent()" 
					onBlur="onNumberBlur()" size=5>
				<INPUT id=AddNumber type=button value="Add -->" name=AddNumber style="WIDTH: 94px; HEIGHT: 25px" onClick="addItemToList()">
			<!--</TD>
			<TD rowspan=2>-->
			<SELECT id=selectInvoices name=selectInvoices align=top size="4" multiple style="width=300;font-size=16px;">
			</SELECT>
			</TD>
		</TR>
		
		<tr height=10><td width=50></td></tr>
		
		<!-- Total Due -->
		<TR>
			<TD align=center class="label" style="font-style:bold; font-weight:bold">Total Due&nbsp;</TD>
				<%dim tempTotalDue
				  if (formatnumber(pickupObj.getTotalAmountDue, 2)-formatnumber(pickupObj.totalAmtPaid, 2))>0 then							  
					tempTotalDue = formatnumber(pickupObj.getTotalAmountDue, 2)-formatnumber(pickupObj.getPaymentByType(""), 2) 'Changed 21 Sep 03
				  else
					tempTotalDue = 0.00
				  end if%>						
			<TD colspan=2 style="color:Red; HEIGHT:100%; WIDTH: 100%; text-align:left; font-size:12pt; font-style:normal; font-weight:normal">
				<%= formatcurrency(tempTotalDue,2)%></TD>
		</TR>		
		
		<tr height=10><td></td></tr>
		
		<!-- Buttons -->
		<tr>	
			<td align="middle" colspan=2>
				<INPUT align=right class=touch id=bttnPrintRackLocations name=bttnPrintRackLocations type=button value="" style="background-image:url(../images/Print-Rack.gif)" onClick = "printRackLocations();" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<INPUT class=touchnoborder id=deleteButton name=deleteButton type=button style="BORDER-RIGHT: deepskyblue thick outset; BORDER-TOP: silver thick ridge; FONT-WEIGHT: bold; FONT-SIZE: larger; BORDER-LEFT: silver thick ridge; BORDER-BOTTOM: deepskyblue thick outset; BACKGROUND-REPEAT: no-repeat; FONT-STYLE: italic; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: deepskyblue" onClick="deleteItems()" value="Remove">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<INPUT class=touchnoborder id=clearButton name=clearButton type=button style="BORDER-RIGHT: thick outset; BORDER-TOP: snow thick ridge; FONT-WEIGHT: bold; FONT-SIZE: larger; BORDER-LEFT: snow thick ridge; BORDER-BOTTOM: thick outset; FONT-STYLE: italic; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: gainsboro; FONT-VARIANT: small-caps" onClick="deleteAllItems()" value="Clear All">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<INPUT class=touchnoborder id=okButton name=okButton type=button style="BACKGROUND-IMAGE: url(../images/ok.gif)" onClick= "submitForm('ok')" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button style="BACKGROUND-IMAGE: url(../images/Cancel.gif)" onClick="cancelForm()" >
			</td>
		</tr>
		
	</TABLE>
	
	<!-- Keyboard -->
	<table ALIGN=center width="100%">
		<tr height=20><td></td></tr>
		<TR height=20 colspan="5"></TR>
		<tr>
			<td><!-- #include file="../include/keyboard.inc" --></td>
		</tr>
				
	</table>
	
</FORM>
</BODY>
</HTML>
