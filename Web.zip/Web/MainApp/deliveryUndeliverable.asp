<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->
<!--#include file="../include/messages.asp" -->

<%
	const DELIVERY_ITEM_INVOICE_ERROR = -10
	const DELIVERY_ITEM_REMOVED = -1
	const DELIVERY_ITEM_READY = 0
	const DELIVERY_ITEM_ADDED = 1
	const DELIVERY_ITEM_STOP_WARNING = 10

	dim query, rs
	dim deliveryID
	dim deliveryDate
	dim routeNumber
	dim useTookan, createCCBatch

	deliveryID = getReqVar("deliveryID")
	deliveryDate = getReqVar("deliveryDate")


	if deliveryID <> "" and deliveryDate <> "" then
		updateDeliveryDate deliveryID, deliveryDate
	end if

	if deliveryDate = "" then deliveryDate = Date()

	select case lcase(request.querystring("useraction"))
	case "collectdeliverydata"
		if deliveryID = "" then deliveryID = createNewDelivery(session("employeeid"), 11)
		collectDeliveryData deliveryID, request.form("deliveryData")
	case "removeselecteditems"
		removeSelectedItems deliveryID, request.form("deliveryItemID")
	case "addselecteditems"
		addSelectedItems deliveryID, request.form("deliveryItemID")
	end select

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function


	function removeSelectedItems(deliveryID, deliveryItemIDs)
		dim deliveryItemID

		for each deliveryItemID in deliveryItemIDs
			removeItemFromDelivery deliveryID, deliveryItemID
		next
	end function

	function addSelectedItems(deliveryID, deliveryItemIDs)
		dim deliveryItemID

		for each deliveryItemID in deliveryItemIDs
			addItemToDelivery deliveryID, deliveryItemID
		next
	end function

	sub collectDeliveryData(deliveryID, deliveryData)
		dim invoicenumbers
		dim invoicenumber

		invoicenumbers = split(deliveryData, "|")

		for each invoicenumber in invoicenumbers
			removeInvoiceFromDelivery deliveryID, invoiceNumber
		next
	end sub

	function removeItemFromDelivery(deliveryID, deliveryItemID)
		dim query, rs

		query = " update deliverywillcall set deliverywillcall.deliveryid = null "
		query = query & " from deliverywillcall inner join deliveryitem on "
		query = query & " deliverywillcall.ticketnumber = deliveryitem.ticketnumber "
		query = query & " where deliveryitem.deliveryitemid = " & deliveryItemID

		qryexecute query


		query = " update ticket set ticket.ticketstatus = 'AC' "
		query = query & " from ticket inner join deliveryitem on "
		query = query & " ticket.ticketnumber = deliveryitem.ticketnumber "
		query = query & " where deliveryitemid IN (" & deliveryItemID & ")"
		query = query & " and status >= 0 "

		qryexecute query

		query = " update deliveryitem set status = " & DELIVERY_ITEM_REMOVED
		query = query & " where deliveryItemID IN (" & deliveryItemID & ")"
		query = query & " and status >= 0 "

		qryexecute query

	end function

	function addItemToDelivery(deliveryID, deliveryItemID)
		dim query, rs

		query = " update deliveryitem set status = " & DELIVERY_ITEM_READY
		query = query & " where deliveryItemID IN (" & deliveryItemID & ")"
		query = query & " and status = " & DELIVERY_ITEM_REMOVED

		qryexecute query


		query = " update ticket set ticket.ticketstatus = 'OD' "
		query = query & " from ticket inner join deliveryitem on "
		query = query & " ticket.ticketnumber = deliveryitem.ticketnumber "
		query = query & " where deliveryitemid IN (" & deliveryItemID & ")"
		query = query & " and status = " & DELIVERY_ITEM_REMOVED

		qryexecute query
	end function


	function removeInvoiceFromDelivery(deliveryID, invoiceNumber)
		dim query, rs

		query = " update deliveryitem set status = " & DELIVERY_ITEM_REMOVED
		query = query & " where invoicenumber = " & invoiceNumber
		query = query & " and deliveryID = " & deliveryID
		query = query & " and status >= 0 "

		qryexecute query

		query = " update ticket set ticket.ticketstatus = 'AC' "
		query = query & " where invoicenumber = " & invoiceNumber
		query = query & " and not (ticket.ticketstatus in ('FI', 'VO')) "

		qryexecute query
	end function


	function getDeliveryItemStatusHTML(status)
		dim result

		select case status
			case DELIVERY_ITEM_INVOICE_ERROR
				result = "<span style=""background:#f00;color:#fff;padding:2px"">"
				result = result & "ERROR"
				result = result & "</span>"
			case DELIVERY_ITEM_REMOVED
				result = "<span style=""background:#f00;color:#fff;padding:2px"">"
				result = result & "REMOVED"
				result = result & "</span>"
			case DELIVERY_ITEM_READY
				result = "<span style=""background:#fff;color:#000;padding:2px"">"
				result = result & "DELIVERED"
				result = result & "</span>"
			case DELIVERY_ITEM_ADDED
				result = "<span style=""background:#0f0;color:#000;padding:2px"">"
				result = result & "ADDED"
				result = result & "</span>"
			case DELIVERY_ITEM_STOP_WARNING
				result = "<span style=""background:#ff0;color:#000;padding:2px"">"
				result = result & "STOP WARNING"
				result = result & "</span>"
		end select

		getDeliveryItemStatusHTML = result
	end function
%>

<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT language="javascript" type="text/javascript">

	function refreshDeliverStateFromTookan() {
		jQuery.ajax(
			{
				url: "http://localhost:8406/cbs_1/update_all_tasks_state/<%=deliveryID%>",
				success: function(result){alert("Success!");},
				error: function(result){alert("Call to tookan failed.");}
			}
		);
	}

	var timer = null;

	function resetTimeout() {
		if(timer != null) {
			clearTimeout(timer);
			timer = setTimeout("submitDeliveryData();", 1000);
		}
	}

	function submitDeliveryData() {
		document.deliveryUndeliverable.action = "?useraction=collectdeliverydata";
		document.deliveryUndeliverable.submit();
	}

	function captureKeyUpEvent(element) {
		if (event.keyCode == 13) {
			event.returnValue = true;

			switch(element.name) {
		        case "InvoiceNumber":
		            newDeliveryItem();
			}
		}
		return true;
	}

	function newDeliveryItem() {
		var InvoiceNumber;
		var tInvoiceNumber;

		InvoiceNumber = document.deliveryUndeliverable.InvoiceNumber.value;


		tInvoiceNumber = translateInvoiceNumber(InvoiceNumber);

		if(tInvoiceNumber != -1) {
		InvoiceNumber = tInvoiceNumber;
		}


	  if(document.deliveryUndeliverable.deliveryData.value != "")
	  	document.deliveryUndeliverable.deliveryData.value += "|";

	  document.deliveryUndeliverable.deliveryData.value += InvoiceNumber;

	  if(timer != null)
	  	clearTimeout(timer);

	  timer = setTimeout("submitDeliveryData();", 1000);

	  resetForm();
	}

	function resetForm() {
		document.deliveryUndeliverable.InvoiceNumber.value = "";
		document.deliveryUndeliverable.InvoiceNumber.focus();
	}

	function continueDelivery() {
        cbs_confirm("Close delivery and post balance for each stop?", gotoCloseDel);
	}

	function gotoCloseDel() {
        clearConfirmMsg();
        document.deliveryUndeliverable.action = "deliveryFunction.asp?useraction=closedelivery&deliveryid=<%=deliveryid%>&destination=" + escape("deliveryManager.asp?deliveryID=<%=deliveryID%>");
        document.deliveryUndeliverable.submit();
	}

	function removeSelectedItems() {
		document.deliveryUndeliverable.action = "?useraction=removeselecteditems";
		document.deliveryUndeliverable.submit();
	}
	function addSelectedItems() {
		document.deliveryUndeliverable.action = "?useraction=addselecteditems";
		document.deliveryUndeliverable.submit();
	}

	function exit() {
		document.deliveryUndeliverable.action = "deliveryManager.asp";
		document.deliveryUndeliverable.submit();
	}

	function SetRowCheckedStatus(row, check, value) {

		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}

	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "deliveryItemID") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "deliveryItemID") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}
</SCRIPT>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="deliveryUndeliverable.InvoiceNumber.focus()">
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->

<H1>Delivery - Undeliverable (5/5)</H1>

<FORM id="deliveryUndeliverable" name="deliveryUndeliverable" method="post" onsubmit="return false">

<INPUT type="hidden" name="deliveryData" value="">
<INPUT type="hidden" name="deliveryID" value="<%=deliveryID%>">



<TABLE>
	<TR>
		<TD>
			Mark Invoice Not Delivered:<BR />
			<INPUT name="InvoiceNumber" onKeyup="return captureKeyUpEvent(this)">
		</TD>
	</TR>
</TABLE>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="removeSelectedItems()">Mark Not<BR/>Delivered</BUTTON>
		<BUTTON onclick="addSelectedItems()">Mark<BR/>Delivered</BUTTON>
	</SPAN>
	<SPAN style="float:left;padding-left:50px;">
			<% if useTookan then %>
			<BUTTON style="width: 100px;" onclick="refreshDeliverStateFromTookan()" >Update Delivery Status<BR/>from CleanRoute and <BR/>Close Delivery</BUTTON>
			<% end if %>
		</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
		<BUTTON style="vertical-align: top" onclick="continueDelivery()">Close<BR />Delivery</BUTTON>
	</SPAN>
</DIV>

<TABLE class="itable" width="100%" cellspacing="0" cellpadding="0">
<TR>
	<TH>&nbsp;</TH>
	<TH>Invoice Number</TH>
	<TH>Status</TH>
</TR>

<%
	if deliveryID <> "" then
		query = " select deliveryitem.deliveryitemid, deliveryitem.invoicenumber, deliveryitem.status "
		query = query & " from deliveryitem where deliveryid = " & deliveryID

		set rs = getdisconnectedrecordset(query)

		while not(rs.eof or rs.bof)
%>

<TR onclick="ToggleRowChecked(this)" >
	<TD><INPUT name="deliveryItemID" type="checkbox" onclick="ToggleRowChecked(this.parentNode.parentNode);" value="<%=rs("deliveryitemid")%>" /></TD>
	<TD><%=rs("invoiceNumber")%></TD>
	<TD><%=getDeliveryItemStatusHTML(rs("status"))%></TD>
</TR>

<%
			rs.movenext
		wend
		set rs = nothing
	end if
%>
</TABLE>

</FORM>
</BODY>
</HTML>
