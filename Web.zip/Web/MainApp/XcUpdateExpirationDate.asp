﻿
<html>
    <head>
        <style type="text/css">
            .labelCell {
                text-align: left;
                width: 160px;
                vertical-align: middle
            }

            .labelText {
                font-size: 9pt;
                font-family: Arial, Sans-Serif, Tahoma;
            }

            .expDateField {
                width: 58px;
            }

            .spacer {
                width: 17px;
            }
        </style>
    </head>

    <body>
        <form id="expirationDateUpdateForm" name="expirationDateUpdateForm" method="POST" action="XWebMethods.asp?Method=updateAliasExpDate" margin="10">
            <table>
                <tr>
                    <td class="labelCell">
                        <span class="labelText">Expiration MM/YY</span>
                    </td>
                    <td class="spacer" />
                    <td align="left">
                        <input id="txtExpirationMonth" name="ExpirationMonth" class="expDateField" maxlength="2" />
                        <input id="txtExpirationYear" name="ExpirationYear" class="expDateField" maxlength="2" />
                    </td>
                </tr>
            </table>
            <table>
                <tr></tr>
                <tr>
                    <td>
                        <input id="btnSubmit" name="btnSubmit" type="submit" value="Submit" />
                    </td>
                    <td>
                        <input id="btnClear" name="btnClear" type="button" value="Clear" />
                    </td>
                </tr>
            </table>
        </form>

        
    </body>

</html>