<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%

	dim query, rs
	dim notificationId
	
	notificationId = getReqVar("notificationId")
	
	select case lcase(request.querystring("useraction"))
	case "save"
		saveNotification
		redirectExit
	end select
	
	sub redirectExit()
	
		response.redirect "/mainapp/notificationList.asp"
	end sub
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function saveNotification()
		dim query, rs
		dim paramName
		
		query = " update notification set active = " & request.form("status")
		query = query & ", cooldown = " & request.form("cooldown")
		query = query & " where notificationid = " & notificationId

		qryexecute query
		
		for each paramName in request.form
			if left(paramName, 2) = "n_" then
				setNotificationParam notificationId, right(paramName, len(paramName) - 2), request.form(paramName)
			end if
		next
	end function
	
	function setNotificationParam(notificationID, paramName, value)
		dim query, rs
		
		query = " delete notificationparam where notificationid = " & notificationID
		query = query & " and [name] = '" & paramName & "'"
		
		qryexecute query
		
		query = " insert into notificationparam (notificationid, name, value) "
		query = query & " values ("
		query = query & notificationID
		query = query & ", '" & dbstr(paramName) & "'"
		query = query & ", '" & dbstr(value) & "'"
		query = query & ")"

		qryexecute query
		
		
		
	end function
	
	function getNotificationParam(notificationID, paramName)
		dim query, rs
		
		if paramName = "active" then
			query = " select active from notification where notificationid = " & notificationID
		elseif paramName = "cooldown" then
			query = " select cooldown from notification where notificationid = " & notificationID
		else
			query = " select value from notificationparam where notificationid = " & notificationID
			query = query & " and [name] = '" & paramName & "'"
		end if
	
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getNotificationParam = trim(rs(0))
		end if
		
		set rs = nothing
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">

	function exit() {
		document.notification.action = "/mainapp/notificationList.asp";
		document.notification.submit();
	}
	function save() {
		document.notification.action = "?useraction=save";
		document.notification.submit();
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<H1>Notification</H1>

<FORM name="notification" ID="notification" METHOD=POST  style="margin:0;padding:0"> 
<INPUT type="hidden" name="notificationId" value="<%=notificationId%>">

<BR>
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		
	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="exit()">Cancel</BUTTON>
		<BUTTON onclick="save()">Save</BUTTON>
	</SPAN>
</DIV>	

<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH>Name</TH>
		<TH>Value</TH>
	</TR>
	<TR>
		<TD>Status</TD>
		<TD>
			<%
				dim nactive
				nactive = getNotificationParam(notificationId, "active")
			
			%>
			<SELECT name="status">
				<OPTION value="1" <%if nactive then%>selected<%end if%>>Active</OPTION>
				<OPTION value="0" <%if not nactive then%>selected<%end if%>>Disabled</OPTION>
			</SELECT>
		</TD>
	</TR>
	<TR>
		<TD>Form</TD>
		<TD>
			<SELECT name="n_formid">
			<%
				dim nformid
				nformid = getNotificationParam(notificationId, "formid")
				
				query = " select formid, name from htmlform "
				set rs = getdisconnectedrecordset(query)
				
				
				while not(rs.eof or rs.bof)
			%>
				<OPTION value="<%=rs("formid")%>" <%if trim(rs("formid")) = nformid then %>selected<%end if%>><%=server.htmlencode(rs("name"))%></OPTION>	
			
			
			<%
					rs.movenext
				wend
				
				set rs = nothing
			
			%>
			</SELECT>
		</TD>
	</TR>
	<TR>
		<TD>Subject</TD>
		<TD><INPUT name="n_subject" value="<%=getNotificationParam(notificationId, "subject")%>"></TD>
	</TR>
	<TR>
		<TD>Message</TD>
		<TD>
			<TEXTAREA name="n_message" style="width: 400px; height: 70px"><%=server.htmlencode(getNotificationParam(notificationId, "message"))%></TEXTAREA>
		</TD>
	</TR>
	<TR>
		<%
			dim cooldown
			cooldown = getNotificationParam(notificationId, "cooldown")
		
		%>
		<TD>Limit Once Every (X) Days</TD>
		<TD>
			<SELECT name="cooldown">
				<OPTION value="1" <%if cooldown = "1" then%>selected<%end if%>>1 Day</OPTION>
				<OPTION value="7" <%if cooldown = "7" then%>selected<%end if%>>7 Days</OPTION>
				<OPTION value="30" <%if cooldown = "30" then%>selected<%end if%>>30 Days</OPTION>
				<OPTION value="90" <%if cooldown = "90" then%>selected<%end if%>>90 Days</OPTION>
				<OPTION value="365" <%if cooldown = "365" then%>selected<%end if%>>365 Days</OPTION>
				<OPTION value="30000" <%if cooldown = "30000" then%>selected<%end if%>>Once Only</OPTION>
				<OPTION value="0" <%if cooldown = "0" then%>selected<%end if%>>No Limit</OPTION>
			</SELECT>
		</TD>
	</TR>

</TABLE>

</FORM>
</BODY>
</HTML>
