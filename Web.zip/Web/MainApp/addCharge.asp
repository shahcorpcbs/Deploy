<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim storeId
	dim addOrEdit
	dim dueDateSet
	dim dueDate
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim targetPage, originatingPage
	dim sInvoiceNumber		
	on error resume next
	storeId = Session("storeId")
	'storeId =1
	curr_LineNo = Request.Form("lineNumber")
	selectedDept = Request.Form("selectedDept")
	itemsStartIndex = Request.Form("ItemPageCount")
	upChargeStartIndex = Request.Form("upChargePageCount")
	colorsStartIndex = Request.Form("colorsPageCount")
	patternStartIndex = Request.Form("PatternPageCount")
	addOrEdit = Request.Form("addOrEdit")
	dueDateSet = Request.Form("isDueDateSet")
	dueDate = Request.Form("txtDueDate")
	deptStartIndex = Request.Form("DeptPageCount")
	selItemId = Request.Form("selItemId")
	selUpchargeValue = Request.Form("selUpcharge")
	selColorValue = Request.Form("selColor")
	selPatternValue = Request.Form("selPattern")
	targetPage = Request.QueryString("targetPage")
	originatingPage = Request.Form("originPage")
	sInvoiceNumber = session("invoicelist")
	function getTaxCodes()
		dim objResultSet
		dim ssql
		if not IsObject(Session("taxCodes")) then
			ssql = "Select taxCode, description, taxPercent FROM Tax Where storeID=" & clng(storeId)
			set objResultSet = getDisconnectedRecordset(ssql)
			Set Session("taxCodes") = objResultSet
		end if
		Set getTaxCodes = Session("taxCodes")
	end function
%>
<HTML>
<HEAD>
<TITLE>Add Charge</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript" src="/Script/validation.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<script language="javascript" type="text/javascript">
	
	function submitForm(){
		var chgDesc;
		var temp;
		var targetPage;
		
		targetPage = document.addchargeform.tPage.value;
		chgDesc = document.addchargeform.txtchargedesc.value;
		chgDesc = trim(chgDesc);
		if (chgDesc.length == 0){
			show_focus("Please enter a charge description.","CBS Error", document.addchargeform.txtchargedesc);
			return;
		}
		
		temp = cleanNumeric(document.addchargeform.txtcharge.value);
		if(temp == "")	{
				show_focus("Please enter a valid amount.","CBS Error", document.addchargeform.txtcharge);
				return;
		}
		if (temp < 0) {
				show_focus("Amount cannot be negative, please re-enter.","CBS Error", document.addchargeform.txtcharge);
				return;
		}	
		switch (targetPage) {
			case "detail":
				document.addchargeform.action= "detailedInvoice.asp?userAction=addCharge";
				break;
			case "counterSale":
				document.addchargeform.action= "counterSale.asp?userAction=addCharge";
				break;
		}
		document.addchargeform.submit();
	}
	
	
	function cancelForm(){
		var targetPage;
		
		targetPage = document.addchargeform.tPage.value;
		switch (targetPage) {
			case "detail":
				document.addchargeform.action= "detailedInvoice.asp?userAction=addCharge";
				break;
			case "counterSale":
				document.addchargeform.action= "counterSale.asp?userAction=addCharge";
				break;
		}
		document.addchargeform.submit();
	}
	
	
	function decimalFormat() {
		var price;
		
		price = document.addchargeform.txtcharge.value;
		price = trim(price);
		if(price.length > 0) {
			price = cleanNumeric(price);
			if(price == "")	{
				show_focus("Please enter a valid amount.","CBS Error", document.addchargeform.txtcharge);
				return;
			}
		}
		document.addchargeform.txtcharge.value = autoFormatCurrency(document.addchargeform.txtcharge.value);		
		captureKeyUpEvent("txtCharge");
	}
	

	//Function added by vivek on 02 Feb 2003 to set the focus on the controls.
	function setFocusOnControl(element){
		if (element == "txtchargedesc"){
			document.addchargeform.txtcharge.focus();			
			document.addchargeform.txtcharge.select();
		}
		
		else if (element == "txtcharge") 
			document.addchargeform.countas.focus()
			
		
//		else if (element == "taxrates") 
//			document.addchargeform.countas.focus()
		
			
		else if (element == "countas") 
			document.addchargeform.okButton.focus()
	}
	
	//Function added by vivek on 02 Feb 2003 to set the focus on the controls when pressing the enter key.
	function captureKeyUpEvent(element){		
		if (event.keyCode == 13){
			event.returnValue = true;	
			
			if (element.name == "txtChargeDesc" && trim(element.value).length != 0 )			
				setFocusOnControl("txtchargedesc");
			
			else if (element == "txtCharge")
				setFocusOnControl("txtcharge")	
			
//			else if (element.name == "taxrates")
//				setFocusOnControl("taxrates")
			
			else if (element.name == "countas")
				setFocusOnControl("countas")
			
		}
	}
	
	function updateRemainingLength(src, dest, max) {
		dest.value = max - src.length;
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0 onLoad="document.addchargeform.txtChargeDesc.focus();">

<!-- #include file="../include/banner.inc" -->
<H1>Add Charge&nbsp; <%=sinvoicenumber%>&nbsp;</H1>
<FORM id="addchargeform" name="addchargeform" action="addCharge.asp" method="post">
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<INPUT type="hidden" name="txtDueDate" value="<%= dueDate %>">
	<INPUT type="hidden" name="isDueDateSet" value="<%= dueDateSet %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px><td></td></tr>
		<TR>
			<TD class="label" align="right">Charge Description</TD>
			<TD align=left>
				<INPUT id=txtchargedesc name=txtChargeDesc class=text style="HEIGHT: 25px; WIDTH: 254px" maxlength="50" onkeyup="captureKeyUpEvent(this);updateRemainingLength(this.value, remainingLength, 50)" >
				<INPUT disabled name="remainingLength" style="width:20px;border:none;background:none;text-align:right" value="50" /> Characters remaining
			</TD>
		</TR>
		<tr height=10px><td></td></tr>
		<TR>
			<TD class="label" align="right">Amount</TD>
			<TD align=left>
				<INPUT id=txtcharge name=txtCharge class=text style="HEIGHT: 25px; WIDTH: 100px" value="" onKeyup="decimalFormat();">
			</TD>
		</TR>
		<!--
		<tr height=10px><td></td></tr>
		<TR>
			<TD  class="label" align="right">Tax Rates</TD>
			<TD align=left>
				<SELECT name=taxrates style="font-size:14px;" onKeyup="captureKeyUpEvent(this)">
				<OPTION VALUE= "0">None</option>
					<%
						dim taxCodeResults
						Set taxCodeResults = getTaxCodes()
						if taxCodeResults.Recordcount > 0 then
							taxCodeResults.MoveFirst
							while not taxCodeResults.EOF
					%>	
								<OPTION VALUE= "<%= taxCodeResults.Fields("taxCode") %>"> <%= taxCodeResults.Fields("description") %>
					<%
							taxCodeResults.moveNext
							wend
						end if	
					%>
				</SELECT>
			</TD>
		</TR>
		-->
		<tr height=10px><td></td></tr>
		<TR>
			<TD class="label" align="right">Count as</TD>
			<TD align=left>
				<SELECT name=countas style="font-size:14px; width:50px" onKeyup="captureKeyUpEvent(this)">
					<%
						dim i
						for i = 0 to 31
							if i=1 then
					%>	
								<OPTION VALUE= "<%= i %>" selected> <%= i %>
					<%
							else
					%>
								<OPTION VALUE= "<%= i %>"> <%= i %>
					<%
							end if
						next
					%>
				</SELECT>
			</TD>
		</TR>
		<TR height=20px></TR>
		<TR>
			<td></td>
			<TD>
				<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align="center" width="80px">
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick= "submitForm()">
						</td>
						<td align="center" width="80px">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm();">
						</td>
						<td></td>
					</tr>
				</table>
			</TD>
		</TR>								
	</TABLE>
</FORM>   

</BODY>
</HTML>
