<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	'******************************************************************************
	'Name	: activeInactiveCustomers.asp
	'==============================================================================
	' Date			Changed By		Change Log
    ' -----------------------------------------------------------------------------
	' 26-Sep-2003	MWiemann		Created 	
	'******************************************************************************
	dim l_storeid
	dim l_errormsg
	dim isSubmitted 
	dim actionString
	dim l_status
	dim objresult  
	dim name
	dim savedname
	dim l_lastname
	dim customerid
	dim message
	dim inactiveDays
	
	actionString = trim(Request.QueryString("userAction"))
	l_storeid = Session("storeid")
	isSubmitted = Request.QueryString("submitted")
	savedname = Request.QueryString("name")
	
	if actionString="results" then
		getSearchResults()
	end if
		
	if isSubmitted then
		UpdateDatabase()
		getSearchResults()
	end if

%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Activate Inactivate Customers</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(element) {
	
		switch (element){
			case "ok":
				document.activateInactivateCust.action="managerMenu.asp";
			case "cancel":
				document.activateInactivateCust.action="managerMenu.asp";
				break;
			case "makeActive":
				savedname = document.activateInactivateCust.searchName.value;
				document.activateInactivateCust.action="?Submitted=true&name="+ savedname +"&status=active";
				break;
			case "makeInActive":
				savedname = document.activateInactivateCust.searchName.value;
				document.activateInactivateCust.action="?Submitted=true&name="+ savedname +"&status=inactive";
				break;
			
		}
		
		document.activateInactivateCust.submit();
	}
	
	function selectAll(){
	var i;
	i = 0
		if ( document.activateInactivateCust.select != null){
			    var items = document.getElementsByName("select")
			if (items.length > 0 ) {
				while (i <= items.length) {
					if (! items[i].disabled) {
						items[i].checked=!items[i].checked;
					}
					i++;
				}
			}
		}
	}
	
	function selectRow(element) {
		var childEl;
		childEl = element.children[0];
		var rowChildNodes = childEl.children;
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if (childEl.name == "select") {
				childEl.checked = !childEl.checked;
			}
			else if (childEl.name == "select") {
				childEl.checked = !childEl.checked;
			}
		}
	}
</script>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Make Customer Active or Inactive</H1>
<FORM id="activateInactivateCust" name="activateInactivateCust" action="" method="post" onsubmit="return false">
	<INPUT type=hidden name=searchName value=<%=savedname%>>
	<TABLE ALIGN=center WIDTH="900px" BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<tr height=40px></tr>
		<!-- header row -->
		<% if message <> "" then %>
		<tr >
			<td align="center">
				<div style="background:red;color:white;padding:5px;font-size:16">
				<%=message%>
				</div>
			</td>
		</tr>
		<% end if %>
		<tr>

			<td align=center>
				<TABLE WIDTH="930px" BORDER=0 CELLSPACING=0 CELLPADDING=0>
					<tr class=head>
						<td width=35px></td>					
						<TD  style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:230px">Customer Name</TD>
						<TD  style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:145px">Phone</TD>
						<TD  style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:235px">Address</TD>
						<TD  style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:160px">City</TD>
						<TD  style="padding-left:10px;text-align:left;FONT-SIZE: 18px;">Status</TD>
					</tr>
				</TABLE>
				<DIV STYLE="overflow-y:auto;height:400px; overflow-x:auto; width=930px">
				<TABLE WIDTH="900px" BORDER=0 CELLSPACING=0 CELLPADDING=0>

					<%
						'Response.Write " going to retrieved results "
				
						if objresult.recordcount <=0 then %>
							Search criteria could not find any matching customers
					<%	else
			
						while not objresult.EOF
																				
					%>
					
					<TR class=data onclick="selectRow(this)" >
						<td width=35px><input type="checkbox" name="select" id="select" STYLE="height=28px;width=28px;" value ="<%=objresult("customersequencenumber")%>" onclick="this.checked = !this.checked"></td>					
						<TD style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:220px"><%=Server.HTMLEncode(objresult("customername"))%>&nbsp</TD>
						<TD style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:145px"><%=formatareacode(objresult("mainareacode")) & formatphone(objresult("mainphone"))%>&nbsp</TD>
						<TD style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:235px"><%=objresult("shippingaddress1")%>&nbsp</TD>
						<TD style="padding-left:10px;text-align:left;FONT-SIZE: 18px;width:160px"><%=objresult("shippingCity")%>&nbsp</TD>
						<TD style="padding-left:10px;text-align:left;FONT-SIZE: 18px;"><%=objresult("isActive")%>&nbsp</TD>
					</TR>	
					<%
							objresult.movenext
						wend
						objresult.close
						set objresult = nothing
					end if
					%>
					
				</table>
				</div>	
			</td>
		</tr>
		<TR HEIGHT=50px><TD></TD></TR>
		<TR>
			<td align="center">
				<BUTTON class=std id=makeActive name=makeActive onClick="submitForm(this.name)"
					<%if totalcount = 0 then %>
						disabled
					<%end if%>><img src="../images/Select.gif"><br>Make Active</button>
					&nbsp;&nbsp&nbsp&nbsp&nbsp
				<BUTTON class=std id=makeInActive name=makeInActive onClick="submitForm(this.name)"
					<%if totalcount = 0 then %>
						disabled
					<%end if%>
					><img src="../images/Un-Select-All-2.gif"><br>Make Inactive</button>
					&nbsp;&nbsp&nbsp&nbsp&nbsp
				<BUTTON class=std id=showAllEmp name=showAllEmp onClick="selectAll()"><img src="../images/Employee-Management.gif"><br>Toggle Selection All</button>
			</td>
		</tr>
		<tr height=20px></tr>
		<tr height=100px>
			<td align="center" colspan=3>
				<TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=2>
					<tr>
						<td align="center">
							<INPUT class=touchnoborder id=ok name=ok type=button  style="background-image:url(../images/Ok.gif)" value="" onClick="submitForm(this.name)">&nbsp&nbsp&nbsp&nbsp&nbsp
							<INPUT class=touchnoborder id=cancel name=cancel type=button  style="background-image:url(../images/Cancel.gif)" value="" onClick="submitForm(this.name)">
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</form>
</BODY>
</HTML>
<%
	dim rstList
	dim totalcount
	totalcount = 0
	
	function getSearchResults()
	dim sqltxt
	
		name = replace(Request.QueryString("name"), "|||", "&")
		name = replace(name, "(", "")
		name = replace(name, ")", "")
		name = replace(name, "-", "")
		customerid=replace(Request.QueryString("customerid"), "|||", "&")
		sqltxt = CreateQryString(name, customerid)
		sqltxt   = sqltxt & ", isnull(firstname, '')"
		
		set objresult = getdisconnectedrecordset(sqltxt)
		if objresult.recordcount > 0 then 
			totalcount = objresult.recordcount
			if trim(inactiveDays) <> "" and totalcount >= 5000 then
			    message = "Not all results shown due to size, please adjust request to limit results"
			end if
		end if
	
	end function
	
	function formatareacode(sareacode) 
		formatareacode= ""
		if not isnull(sareacode) then
			formatareacode= "(" & sareacode & ")"
		end	if
	end function
	
	function formatphone(sPhone) 
		formatphone= ""
		if not isnull(sPhone) and  len(trim(sPhone)) = 7 then
			formatphone=   left(sPhone, 3) & "-" & right(sPhone, 4)
		else
			formatphone = sPhone
		end	if
	end function
	
	function formatname(slname, sfname)
		formatname= ""
		if not isnull(slname) then
			formatname= checkfornull(slname) + ", "  + checkfornull(sfname)
		end if
	
	end function

	function CreateQryString(name, customerid)
	dim strqry
	dim sqryPhone

	inactiveDays = Request.QueryString("inactiveDays")
	if isNumeric(name) and len(trim(name))  = 10  then
	
		sqryphone = "or ( (mainareacode+mainphone) like " & "'"&  name & "%')"
		
	elseif isNumeric(name) and len(trim(name)) = 7 then
	
		sqryphone = "or ( mainphone  like " & "'"&  name & "%')"
	
	end if	
	
	if trim(name) <>"" then
	
		strqry = "select customersequencenumber, isnull(lastname + ' ', '') + isnull(firstname, '') + ' ' + isnull(middleinitial, '') as customername, isnull(shippingaddress1, '') as shippingaddress1, isnull(shippingcity, '') as shippingcity,  isnull(mainareacode, '') as mainareacode, isnull(mainphone, '') as mainphone, case isActive when 1 then 'ACTIVE' when 0 then 'INACTIVE' end  AS isActive from customer C where  (lastname like" & "'" & name & "%') "
		if trim(inactiveDays) <> "" then
		    strqry = strqry & " and datediff(day, lastVisited, getdate()) >= " & inactiveDays & " "
		end if
		strqry = strqry & sqryphone & " order by lastname"
		
	elseif trim(customerid) <> "" then
		strqry = "select customersequencenumber, isnull(lastname + ' ', '') + isnull(firstname, '') + ' ' + isnull(middleinitial, '') as customername , isnull(shippingaddress1, '') as shippingaddress1, isnull(shippingcity, '') as shippingcity,  isnull(mainareacode, '') as mainareacode, isnull(mainphone, '') as mainphone, case isActive when 1 then 'ACTIVE' when 0 then 'INACTIVE'end  AS isActive from customer C where customerid = " & "'" & customerid & "'"
		if trim(inactiveDays) <> "" then
		    strqry = strqry & " and datediff(day, lastVisited, getdate()) >= " & inactiveDays & " "
		end if
		strqry = strqry & " order by lastname"
	elseif trim(inactiveDays) <> "" then
		strqry = "select top 5000 customersequencenumber, isnull(lastname + ' ', '') + isnull(firstname, '') + ' ' + isnull(middleinitial, '') as customername , isnull(shippingaddress1, '') as shippingaddress1, isnull(shippingcity, '') as shippingcity,  isnull(mainareacode, '') as mainareacode, isnull(mainphone, '') as mainphone, case isActive when 1 then 'ACTIVE' when 0 then 'INACTIVE'end  AS isActive from customer C where datediff(day, lastVisited, getdate()) >= " _
		    & inactiveDays & " order by lastname"
	else
		strqry = " Select customersequencenumber, isnull(lastname + ' ', '') + isnull(firstname, '') + ' ' + isnull(middleinitial, '') as customername, isnull(shippingaddress1, '') as shippingaddress1, isnull(shippingcity, '') as shippingcity,  isnull(mainareacode, '') as mainareacode, isnull(mainphone, '') as mainphone, case isActive when 1 then 'ACTIVE' when 0 then 'INACTIVE' end AS isActive from customer order by lastname"
	end if
	
	if len(trim(sqryphone)) = 0 then
			l_lastname = name
	end if
		
	createQryString = strqry
	end function

	
	function UpdateDatabase()
	dim sqltxt
	dim dataRst, dataRst2
	dim accountBalanceRst
	dim actTicketCnt
	dim actTicketCust
	dim totalcount
	dim okToInactivate
	Dim i	
	Dim accountBalance
	
		totalcount = Request.Form("select").count
		if totalcount <=0 then
			exit function
		end if 
		l_status = Request.queryString("status")
		
			if l_status = "active" then
			
				dbstartTrans()	
				for i =  1 to totalcount 
					sqltxt  = "Update customer set isActive = 1 where customersequencenumber = " & Request.Form("select")(i)
					QryExecuteWithTrans(sqltxt)
				next
				DbEndTrans()
			
		elseif l_status = "inactive" then
				for i =  1 to totalcount 
					okToInactivate = 1				
				
					sqltxt = "select count(t.ticketnumber) as cnt, c.customername from ticket t, ticketcustomer tc, customer c " & _
							 " where tc.ticketnumber = t.ticketnumber and tc.customerid = c.customerid and " & _
							 " c.customersequencenumber = " & Request.Form("select")(i) & _
							 " and t.ticketstatus IN ('AC', 'OD')" & _
							 " group by c.customername "

					set dataRst = getDisconnectedRecordset(sqltxt)
					
					sqltxt = " select dbo.getAccountBalance(" & Request.Form("select")(i) & ", null) as accountbalance "
					
					set accountBalanceRst = getDisconnectedRecordset(sqltxt)
					
					if accountBalanceRst.recordcount > 0 then
						accountBalance = accountBalanceRst("accountbalance")
					else
						accountBalance = 0
					end if
					
					if dataRst.recordcount > 0 then
						okToInactivate = 0
					end if
					
					sqltxt = "select customername, dbo.getaccountbalance(" & Request.Form("select")(i) & ",getdate()) as balance from customer"
					sqltxt = sqltxt & " where customersequencenumber = " & Request.Form("select")(i)
					set dataRst2 = getDisconnectedRecordset(sqltxt)
					
					if dataRst2("balance") > 0 then
						okToInactivate = 0
					end if	
					
					if okToInactivate = 0 then
						message = "Could not inactivate " & dataRst2("customername") & " because they have active invoices and/or an account balance. <br />"
					elseif accountBalance <> 0 then
						message = message & "Could not inactivate customer because they have an account balance of " & formatcurrency(accountBalance) & ". <br />"
					else
						dbstartTrans()						 
							sqltxt  = "Update customer set isActive = 0 where customersequencenumber = " & Request.Form("select")(i)
							QryExecuteWithTrans(sqltxt)
						dbendTrans()
					end if
				next
		end if
	end function
%>

