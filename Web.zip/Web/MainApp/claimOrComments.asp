<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<% 
	Dim l_customerseq
	dim l_storeid
	
	l_Customerseq = session("Customersequencenumber")
	l_storeid = session("Storeid")
	
	session("ClaimID") = ""
	
	GetCustomerClaimInfo()
	
%>
<HTML>
<HEAD>
<TITLE>Claim Or Comments</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	var previousElement=null;
	function addNewClaim() {
		document.claimOrComments.action = "/MainApp/newClaim.asp?claimtype=claim";
		document.claimOrComments.submit();
	}
	function addNewComment() {

		window.document.claimOrComments.action = "newClaim.asp?claimtype=comment";
		document.claimOrComments.submit();
	}
	
	function editViewClaim() {
		var childE1;
		var x;
		childE1 = previousElement.children[0];
		var rowChildNodes = childE1.children;
		for(i=0; i<rowChildNodes.length; i++){
			childE1 = rowChildNodes[i];
			if(childE1.tagName == "INPUT") {
				x = childE1.value;
				break;
			}
		}
		document.claimOrComments.action = "editClaim.asp?claimid=" + x;
		document.claimOrComments.submit();
	}
	
	function selectRow(element) {
		var childEl;
		document.claimOrComments.editView.disabled  = false;
		if (previousElement !=null){
			previousElement.className = "";
		}
		childEl = element.children[0];
		var rowChildNodes = childEl.children
		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];
			if(childEl.tagName == "INPUT") {
				childEl.checked=true;
				break;
			}
		}
		previousElement =element;

		element.className = "selected";
		 
	}
	
	function cancelForm() {
		document.claimOrComments.action = "customerManagement.asp";
		document.claimOrComments.submit();
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<H1>Claim Or Comments</H1>
<FORM id="claimOrComments" name="claimOrComments" action="" method="Post">


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="addNewClaim()">New</BUTTON>
		<BUTTON name="editView" onclick="editViewClaim(claimOrComments.selectid.value)">Edit</BUTTON>
	</SPAN>
	<SPAN style="float:right">
        <BUTTON onclick="cancelForm()">Exit</BUTTON>
	</SPAN>
</DIV>	

		
<TABLE class="itable"  BORDER=0 CELLSPACING=0 CELLPADDING=5>
	<!-- heading -->
	<tr>
		<th>&nbsp;</th>
		<th align=left class="label">Status</th>
		<th align=left class="label">Claim Date</th>
		<th align=left class="label">Invoice</th>
		<th align=left class="label">Information</th>
		<th align=left class="label">Date Occurred</th>
		<th align=left class="label">Action</th>
	</tr>

<%while not rstTemp.bof and not rstTemp.eof 
	'Response.Write rstTemp("claimid")
%>
	<tr onClick="selectRow(this)">
		<td>
		<input type="radio" name="selectid" id="selectid" value="<%=rsttemp("claimid")%>"></td>		
		<td><% if rsttemp("ClaimStatus") = "O" then %>
		Open
		<% elseif rsttemp("ClaimStatus") = "C" then %>
		Closed
		<%end if %>
		</td>
		<td><%=formatDate1(rstTemp("CreatedDate"))%></td>
		
		<td>
		<% if isnull(rsttemp("invoicenumber")) then %>
			&nbsp;
		<% else %>
			<%=rsttemp("invoicenumber")%>
		<% end if	%>
		</td>
		<td>
		<%
			= rstTemp("Description")

		%>
		</td>
		<td><%=formatDate1(rstTemp("OccurredDate"))%></td>
		<td>
		<%
			Response.write rstTemp("ClaimAction")
			if trim(rsttemp("claimAmount")) <> "" then
				Response.Write " " & formatcurrency(rsttemp("claimAmount"))
			end if
		%></td>
	</tr>
<%
	rsttemp.movenext
	wend
	rsttemp.close
	set rsttemp = nothing
%>

</TABLE> 


</form>
</BODY>
</HTML>
<%
	dim rstTemp
	
	function GetCustomerClaimInfo()
		dim sqltxt 
		sqltxt = "Select * from claim c ,claimcomment p where c.claimid = p.claimid and c.storeid = " & l_storeid & " and c.CustomerSequencenumber= " & l_customerseq & " and p.createddate = ( select min(b.createddate) from  claimcomment b where c.claimid = b.claimid)  "
		'Response.Write sqltxt
		set rstTemp = GetDisconnectedRecordset(sqltxt)
	end function

%>
