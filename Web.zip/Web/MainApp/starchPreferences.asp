<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	
	dim storeId
	dim custStarchPref
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim dueDateSet
	dim dueDate
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim targetPage
	dim invoicePref
	dim invoice
	on error resume next
	custStarchPref = Session("starchPref")
	set invoice = Session("invoice")
	invoicePref = invoice.starchPref
	storeId = Session("storeID")
	
	curr_LineNo = Request.Form("lineNumber")
	selectedDept = Request.Form("selectedDept")
	itemsStartIndex = Request.Form("ItemPageCount")
	upChargeStartIndex = Request.Form("upChargePageCount")
	colorsStartIndex = Request.Form("colorsPageCount")
	patternStartIndex = Request.Form("PatternPageCount")
	addOrEdit = Request.Form("addOrEdit")
	dueDateSet = Request.Form("isDueDateSet")
	dueDate = Request.Form("txtDueDate")
	deptStartIndex = Request.Form("DeptPageCount")
	selItemId = Request.Form("selItemId")
	selUpchargeValue = Request.Form("selUpcharge")
	selColorValue = Request.Form("selColor")
	selPatternValue = Request.Form("selPattern")
	targetPage = Request.QueryString("targetPage")
	
	sub getAllStarchPref()
		dim ssql
		dim objResultSet
		ssql ="SELECT starchPreferenceName, imageFileName FROM StoreStarchPreference where storeid=" & clng(storeId) _
				& " AND enabled=1 Order by displaySequence" 
		Set objResultSet = getDisconnectedRecordset(ssql)
		set Session("starchPrefMaster") = objResultSet
	end sub
%>

<HTML>
<HEAD>
<TITLE>Invoice Number</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript">
	function setStarchPref(element){
		var starchPrefName;
		var custPref;
		var changeCustPref;
		var changeStatus;
		var targetPage;
		
		changeStatus = "no";
		custPref = document.starchPref.CustStarchPref.value;
		targetPage = document.starchPref.tPage.value;
		starchPrefName = element.name;
		if (starchPrefName != custPref) {
			changeCustPref = cbsQuestion + cbsYesNo, ("Would you like to change " + custPref + " preference to " + starchPrefName, "Starch Preferences");
			if (changeCustPref == cbsYes) {
				changeStatus = "yes";
			}
		}
		if (targetPage == "detail"){
			document.starchPref.action = "detailedInvoice.asp?userAction=changeStarchPref&pref=" + starchPrefName + "&changeStatus=" +  changeStatus;
		}else{
			if (targetPage =="quick") {
				document.starchPref.action = "quickinvoice.asp?userAction=changeStarchPref&pref=" + starchPrefName + "&changeStatus=" +  changeStatus;
			}
		}
		document.starchPref.submit();
	}
</script>

<BODY topmargin=0 leftmargin=0>
	<!-- #include file="../include/banner.inc" -->
<H1>Select Starch Preference</H1>
	<FORM id="starchPref" name="starchPref" action="starchPreferences.asp" method="post">
		<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
		<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
		<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
		<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
		<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
		<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
		<INPUT type="hidden" name="couponPageCount" value="<%= couponStartIndex %>">
		<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
		<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
		<INPUT type="hidden" name="CustStarchPref" value="<%= custStarchPref %>">
		<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
		<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
		<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
		<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
		<INPUT type="hidden" name="tPage" value="<%= targetPage%>">
		<TABLE ALIGN=center WIDTH="150px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
			<%
				dim rst
				set rst = Session("starchPrefMaster")
				if rst.Recordcount > 0 then
					rst.MoveFirst
					while not rst.Eof
			%>
						<tr>
							<td align=center>
								<button style="width:90px;height:40px;" style="background:white" id="<%= rst.Fields("starchPreferenceName") %>" name="<%= rst.Fields("starchPreferenceName") %>" onClick="setStarchPref(this);" 
								<%
									 if invoicePref = rst.Fields("starchPreferenceName") then
								%>
									style="background:gold"
								<%
									end if
								%>
								>
								<%= rst.Fields("starchPreferenceName") %>
								</button>
							</td>
						</tr>
			<%
						rst.MoveNext
					wend
				end if
			%>
			<tr>
				<td align=center>
					<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="history.back(-1);">
				</td>
			</tr>
		</table>
	</FORM>
</body>
</HTML>
