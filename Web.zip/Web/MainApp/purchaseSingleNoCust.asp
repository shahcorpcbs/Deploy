<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim storeId, pricelistId, deptId, employeeID, empName, terminalID, storeName
	dim customerSeq, customerName, custPhone, areaCode, custVisitCount, routeNumber
	dim cardNo, expDate, effDate, validDays
	dim giftValue, taxCode, discountId, noOfUses, taxDesc
	dim ssql
	dim rst
	dim v_custName
	dim actionString
	dim ticketNo, invoiceNo
	dim invoiceTotal, taxAmount
	dim LI
	dim taxPercent
	dim pickupInvoices,pickupInvoicesRst

	storeId = Session("storeId")
	storeName = Session("storeName")
	set session("pickupInvoices")= nothing
	set session("pickupobj") = nothing
	employeeId = session("employeeId")
	empName = Session("employeeName")
	terminalID = session("terminalId")
	
	actionString = Request.QueryString("userAction")

	select case actionString
		case "initialize"
			initialize()
		case "submit"
			addGift()
			addLineItems()
			addTicket()
			addTicketItems()
			gotoPickupScreen
	end select		
	
	function initialize()
		ssql = "select customerid, customerName from customer where customerSequenceNumber =" + Request.QueryString("customerSequenceNumber")
		set rst = getDisconnectedRecordSet(ssql)
		v_custName = rst.fields("customerName")  + " (" + trim(rst.fields("customerId")) + ")"
		customerName = rst.Fields("customerName")
		session("customerName") = customerName
		session("customersequencenumber") = Request.QueryString("customerSequenceNumber")
		customerSeq = Session("customerSequenceNumber")
	
		getcustomerdetails
	end function	
	
	
	sub getCustomerDetails()
		dim ssql
		dim objResultSet
		dim areaCode
		ssql = "Select IsNull(starchPreferenceName, '') as starchPreferenceName, IsNull(finishPreferenceName, '') as finishPreferenceName, defaultPriceListId, " _
				& " IsNull(firstName, '') as firstName, IsNull(middleInitial,'') as middleInitial, " _
				& " IsNull(lastName, '') as lastName, Isnull(mainAreaCode, '') as mainAreaCode, " _
				& " isnull(mainPhone, '') as mainPhone, vipExpiryDate, vipQualAmount, " _
				& " vipEligible, vipQualified, referralQualified, routeNumber, dbo.getCustomerVisits(customer.customersequencenumber, null, null) as visitCount, " _
				& " IsNull(screenNotes,'') as screenNotes from customer where customerSequenceNumber=" _
				& clng(customerseq)
		Set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Recordcount > 0 then	
			objResultSet.MoveFirst
			areaCode = objResultSet.fields("mainAreaCode")
			custPhone = objResultSet.fields("mainPhone")
			if len(Trim(custPhone)) > 0 then
				if len(Trim(areaCode)) > 0 then
					custPhone = areaCode & "-"  & Mid(custPhone,1,3) & "-" & Mid(custPhone,4,len(custPhone))
				end if
			end if
			session("customermainphone") = custPhone
			custVisitCount = objResultSet.Fields("visitCount").Value
			pricelistID = objResultSet.Fields("defaultPriceListId").Value
			routeNumber = objResultSet.Fields("routeNumber").Value
		end if
	end sub


	function addGift()
		dim ssql
		dim objRst
		dim giftProgramId 
		
		giftProgramId = 1
		collectDataFromForm
		ssql = "select *, validDays + getDate() as expDate, getDate() as effDate from giftProgram where giftprogramid = " & giftProgramId
		set objRst = getDisconnectedRecordSet(ssql)
		if objRst.Recordcount > 0 then	
			validDays = objRst.fields("validDays")
			expDate = objRst.fields("expDate")
			effDate = objRst.fields("effDate")
			taxCode = objRst.fields("taxCode")
		else 
			Session("errorMessage") = "Gift Card Program has not been set up.  Please go back and set up gift card program from setup menu."
			Response.Redirect "ErrorMessages.asp"
		end if	
	
		
		ssql = "select * from giftCard where customersequencenumber = " & customerseq & " and giftCardNumber = " & dbcreateqrystring(cardNo)
		set objRst = getDisconnectedRecordSet(ssql)
		if objRst.recordCount > 0 then
			Session("errorMessage") = "Card Number already in use by this customer. Please go back and choose another card."
			Response.Redirect "ErrorMessages.asp"
		end if
		
		ssql = "INSERT into GIFTCARD(giftprogramid, giftcardnumber, giftValue, customersequencenumber, effectivedate, expirationdate, lastUsedDate)" _
			& " VALUES(" & giftProgramId & "," & dbcreateqrystring(cardNo) & "," & giftValue & "," & customerseq _
			& ",'" & formatDate1(effDate) & "','" & formatDate1(expDate) & "','"  & formatDate1(effDate)& "')"
		QryExecute(ssql)
			
		taxPercent = 0
		taxDesc = "" 
			
		if not (isEmpty(taxCode) or isnull(taxCode)) then
			ssql = "select * from tax where taxCode = " & taxCode & " and storeid = " & storeid
			set objRst = getDisconnectedRecordSet(ssql)
			if not(objRst.eof or objRst.bof) then
				taxPercent = objRst.Fields("taxPercent").value
				taxDesc = objRst.Fields("description").value
			end if
			set objRst = nothing
		end if		
	end function	

	function collectDataFromForm()
		cardNo = Request.Form("giftCardNum")
		giftValue = Request.Form("giftValue")
		customerSeq = Request.Form("customerSeq")
		pricelistId = Request.Form("pricelistId")
		routeNumber = Request.Form("routeNumber")
		custVisitCount = Request.Form("custVisitCount")
	end function		
		
	function addLineItems()
		'calculate tax
		taxAmount = Round(giftValue*(CDbl(taxPercent)/100),2)
		invoiceTotal = giftValue + taxAmount
		
		set LI = server.CreateObject("ADODB.recordset")
	    LI.Fields.Append "lineNumber", adInteger
		LI.Fields.Append "parentLineNumber", adInteger
		LI.Fields.Append "deptId", adInteger, , adFldIsNullable
		LI.Fields.Append "deptName", adVarChar, 64, adFldIsNullable
		LI.Fields.Append "itemType", adVarChar, 20
		LI.Fields.Append "lineItemId", adInteger, , adFldIsNullable
		LI.Fields.Append "itemName", adVarChar, 64, adFldIsNullable
		LI.Fields.Append "originalUnitPrice", adDouble
		LI.Fields.Append "unitPrice", adDouble
		LI.Fields.Append "quantity", adInteger, , adFldIsNullable
		LI.Fields.Append "lineItemTotal", adDouble
		LI.Fields.Append "totalTax", adDouble
	    LI.Fields.Append "totalSurcharge", adDouble
		LI.Fields.Append "prepay", adDouble
		LI.Fields.Append "taxableAmt", adDouble
		LI.Fields.Append "daysToProcess", adInteger, , adFldIsNullable
		LI.Fields.Append "notes", adVarChar, 255, adFldIsNullable
		LI.Fields.Append "balance", adDouble
		LI.Fields.Append "upchargeTotal", adDouble, , adFldIsNullable
		LI.Fields.Append "colorTotal", adDouble, , adFldIsNullable
		LI.Fields.Append "patternTotal", adDouble, , adFldIsNullable
		LI.Fields.Append "discountable", adBoolean, , adFldIsNullable
		LI.Fields.Append "couponable", adBoolean, , adFldIsNullable
		LI.Fields.Append "VIPDiscountable", adBoolean, , adFldIsNullable
		LI.Fields.Append "VIPQualified", adBoolean, , adFldIsNullable
		LI.Fields.Append "parentId", adInteger, , adFldIsNullable
		LI.Fields.Append "saleOnly", adBoolean, , adFldIsNullable
		LI.Fields.Append "chargeTaxCode", adInteger, , adFldIsNullable
		LI.Fields.Append "pkgQuantity", adInteger, , adFldIsNullable
		LI.Fields.Append "peNotes", adVarChar, 255, adFldIsNullable
		LI.CursorLocation = adUseClient
		LI.Open
		Set LI.ActiveConnection = Nothing
		'Add line for Gift Card
		LI.AddNew Array("lineNumber", "parentLineNumber", "deptId", _
                "deptName", "itemType", "lineItemId", "itemName", _
                "originalUnitPrice", "unitPrice", "quantity", "lineItemTotal", _
                "totalTax", "totalSurcharge", "prepay", _
                "taxableAmt", "daysToProcess", "notes", "balance", _
                "upchargeTotal", "colorTotal", "patternTotal", _
                "discountable", "couponable", "VIPDiscountable", _
                "saleOnly", "VIPQualified", "pkgQuantity", "peNotes"), _
				Array(1, -1, deptId, "SpecialOffers", "SO", 1, "Gift Card", _
				giftValue, giftValue, 1, giftValue, taxAmount, 0, 0, _
				giftValue, Null, Null, invoiceTotal, 0, 0, 0, _
				Null, Null, Null, Null, Null, 1, Null)
		'Add line for Tax
		if not (isempty(taxCode) or isnull(taxCode)) then
			LI.AddNew Array("lineNumber", "parentLineNumber", "deptId", _
                "deptName", "itemType", "lineItemId", "itemName", _
                "originalUnitPrice", "unitPrice", "quantity", "lineItemTotal", _
                "totalTax", "totalSurcharge", "prepay", _
                "taxableAmt", "daysToProcess", "notes", "balance"), _
                Array(2, -1, deptId, "SpecialOffers", "TA", taxCode, rtrim(taxDesc), 0, 0, 1, taxAmount, 0, 0, 0, 0, 0, Null, 0)
        end if         
	end function              
	
	function addTicket()
		dim firstVisit
		dim ssql
		dim objResultSet
		dim thisday
		
		if custVisitCount = 0 then
			firstVisit = 1
		else
			firstVisit = 0
		end if		
		
		ssql = "exec InsertTicket " _
			& storeid _
			& "," & dbcreateqrystring(NULL) _
			& "," & dbcreateqrystring("D") _
			& "," & dbcreateqrystring("AC") _
			& "," & priceListId _
			& "," & routeNumber _ 
			& "," & employeeId _
			& "," & dbcreateqrystring(now)  _
			& "," & customerSeq _
			& "," & dbcreateqrystring(NULL) _
			& "," & dbcreateqrystring(NULL) _
			& "," & 0 _
			& "," & terminalId _
			& "," & 0 _
			& "," & invoiceTotal _
			& "," & dbcreateqrystring(NULL) _
			& "," & dbcreateqrystring(NULL) _
			& "," & firstVisit _
			& "," & 0 _
            & "," & 0 _
            & "," & 0 _
            & "," & 0 _ 
            & "," & invoiceTotal _
            & "," & 0 _
            & "," & 0 _
            & "," & 0 _
            & "," & 0 _
            & "," & dbcreateqrystring(empName) _
            & "," & dbcreateqrystring(storeName) _
            & "," & 0 _
            & "," & dbcreateqrystring(Null)
        Response.Write ssql    
		Set objResultSet = getDisconnectedRecordSet(ssql)
		ticketNo = objResultSet.Fields("TicketNumber").Value
		invoiceNo = objResultSet.Fields("InvoiceNumber").Value
	end function	
	
	function addTicketItems()
		Dim ssql
		
		LI.MoveFirst
		While Not LI.EOF 
			ssql = "INSERT INTO TicketLineItem(ticketNumber, lineItemNumber, " _
                & " createdByEmployeeID, lastModifiedByEmployeeID, " _
                & " parentLineNumber, displaySequence, departmentID, " _
                & " departmentName, ticketLineType, lineItemID, saleOnly, " _
                & " lineItemName, originalUnitPrice, unitPrice, quantity, " _
                & " lineItemTotal, totalTaxPercent, totalSurchargePercent, " _
                & " lineItemTaxableAmount, itemNotes, " _
                & " outsideService, totalUpchargeAmount, chargeTaxCode, packagedQuantity) VALUES(" _
                & ticketNo & "," & LI.Fields("lineNumber").Value _
                & "," & employeeId & "," & employeeId & "," & LI.Fields("parentLineNumber").Value & "," _
                & LI.Fields("lineNumber").Value & "," & LI.Fields("deptId").Value & ",'" _
                & LI.Fields("deptName").Value & "','" & LI.Fields("itemType").Value & "'," _
                & LI.Fields("lineItemId").Value & "," _
                & 0 & ",'" & LI.Fields("itemName").Value & "'," _
                & LI.Fields("originalUnitPrice").Value & "," _
                & LI.Fields("unitPrice").Value & "," & LI.Fields("quantity").Value & "," _
                & LI.Fields("lineItemTotal").Value & "," _
                & LI.Fields("totalTax").Value & "," & LI.Fields("totalSurcharge").Value & "," _
                & LI.Fields("taxableAmt").Value & "," _
                & "NULL, 0, 0, NULL, 1)"
			QryExecute(ssql)
			LI.MoveNext
		Wend
	end function	
	
	sub goToPickUpScreen()
		dim pickupObj
		dim invoicesTotalInfo
		dim invTotal
		dim totalAmtPaid
		dim amountDue
		dim totalcredits
		dim totalearlyPay
		dim ssql
		dim rackStr
		dim aInvoice
		
		customerseq=Request.Form("customerSeq")
		
		ssql = "Select distinct ticket.ticketNumber, customer.customername, ticket.customersequencenumber as customersequencenumber, " _
		& " tc.multiplepickup, tc.multiPickupCustomerName, tc.multiPickupLocation, " _
		& " invoiceNumber, convert(varchar, ticket.createdDate, 101) as 'DateIn', " _
		& " convert(varchar,dueDate,101) as 'DateDue',  invoiceTotal, IsNull(netTotal, 0) as netTotal, " _
		& " amountPaid From Ticket, Customer, ticketCustomer tc Where invoiceNumber='" & invoiceNo _
		& " ' AND ticketStatus='AC' AND invoiceType='D' AND onHold=0  " _
		& " and ticket.ticketnumber = tc.ticketnumber AND Ticket.customersequencenumber = Customer.customersequencenumber " _
		& " Order By DateIn ASC"
		set pickupInvoicesRst = getDisconnectedRecordset(ssql)
		
		invTotal = pickupInvoicesRst.Fields("invoiceTotal").value
		
		set Session("pickupInvoices") = pickupInvoicesRst
		set pickupInvoices = Server.CreateObject("Scripting.Dictionary")
		Set aInvoice = Server.CreateObject("ShahCorpComponents.pickupInvoice")
		aInvoice.DBConnectionString = Session("shahcorpDSN")
		aInvoice.ticketNumber = ticketNo
		aInvoice.invoiceNumber = pickupInvoicesRst.Fields("invoiceNumber").Value
		aInvoice.amountPaid = pickupInvoicesRst.Fields("amountPaid").Value
		aInvoice.invoiceTotal = pickupInvoicesRst.Fields("netTotal").Value
		pickupInvoices.Add ticketNo, aInvoice

		set pickupObj =Server.CreateObject("ShahCorpComponents.pickup")
		pickupObj.DBConnectionString = Session("shahcorpDSN")
		pickupObj.storeId = storeId
		pickupObj.initStorePaymentTypeInfo()
		Set pickupObj.pickupInvoices = pickupInvoices
		pickupObj.userAction = "pickup"
		pickupObj.custSeqNumber = customerSeq
		pickupObj.invoicesTotal = invTotal
		pickupObj.amountDue = invTotal
		pickupObj.populateLineItemsToDisplay
		set Session("pickupObj") = pickupObj
		Set Session("pickupInvoices") = Nothing
		Set Session("ticketDepartment") = Nothing
		Set Session("ticketRack") = Nothing
		session("invoicelist") = pickupObj.getInvoiceNosForPrinting()
		Response.Redirect "pickup.asp?target=pickup&userAction=pickup&targetPage=issueGiftCard.asp"
	end sub
	
	   
	
	
	
%>	
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Purchase Single Gift Card</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		if (validateFormData()){
			document.purchaseSingleNoCust.action= document.purchaseSingleNoCust.action + "?userAction=submit";
			document.purchaseSingleNoCust.submit();
		}	
	}
	
	function cancelForm() {
		document.purchaseSingleNoCust.action="issueGiftCard.asp";
		document.purchaseSingleNoCust.submit()
	}	

	function validateFormData() {
		var cardNo
		var cardValue
		returnValue = true;
		cardNo = document.purchaseSingleNoCust.giftCardNum.value;
		if (!checkFieldMissing(cardNo)) {
			returnValue = false;
			show_focus("Card Number is required", "Card Number", document.purchaseSingleNoCust.giftCardNum)
			return returnValue;
		}
		cardValue = document.purchaseSingleNoCust.giftValue.value;
		if (!checkFieldMissing(cardValue)) {
			returnValue = false;
			show_focus("Card Value is required", "Card Value", document.purchaseSingleNoCust.giftValue)
			return returnValue;
		}
		if (isNaN(cardValue)) {
			returnValue = false;
			show_focus("Card Value must be numeric", "Card Value", document.purchaseSingleNoCust.giftValue)
			return returnValue;
		}
		return returnValue;
	}
		function decimalFormat() {
		var price;
		
		price = document.purchaseSingleNoCust.giftValue.value;
		price = trim(price);
		if(price.length > 0) {
			price = cleanNumeric(price);
			if(price == "")	{
				show_focus("Enter valid amount.", "Invalid Amount",document.purchaseSingleNoCust.giftValue);
				return;
			}
		}
		document.purchaseSingleNoCust.giftValue.value = autoFormatCurrency(document.purchaseSingleNoCust.giftValue.value);
	//	captureKeyUpEvent("giftValue"); //added by vivek on 02 Feb 2003
		
	}

	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">Purchase Gift Card</B>
<FORM id="purchaseSingleNoCust" name="purchaseSingleNoCust" action="purchaseSingleNoCust.asp" method="Post">
<INPUT type="hidden" name="customerSeq" value="<%=customerSeq%>">
<INPUT type="hidden" name="pricelistId" value="<%=pricelistID%>">
<INPUT type="hidden" name="routeNumber" value="<%=routeNumber%>">
<INPUT type="hidden" name="custVisitCount" value="<%=custVisitCount%>">

<TABLE ALIGN=center WIDTH=450px BORDER=1 CELLSPACING=1 CELLPADDING=10>
	<TR><TD>
	<TABLE ALIGN=center WIDTH=100% BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<TR height=20px><TD align=right width=30%>
			</TD>
			<TD width=50% valign=bottom>
			<b><%=v_custName%></b>
			</TD></TR>
		<TR height=40px valign=top><TD></TD><TD><b><%=custPhone%></b></td></tr>
		<TR height=40px><TD align=right>
			<LABEL for=giftCardNum>Gift Card Number&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=giftCardNum style= width:140px value="<%=cardNo%>">
		</TD></TR>
		<TR height=40px><TD align=right>
			<LABEL for=giftValue>Gift Card Amount&nbsp</LABEL>
			</TD>
			<TD>
			<INPUT CLASS=text name=giftValue style= width:60px value="<%=giftValue%>" onKeyup="decimalFormat();">
		</TD></TR>
		<TR height=80px><TD ALIGN=CENTER COLSPAN=3 valign=bottom>
			<INPUT class=touchnoBorder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)"onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
			<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
		</TD></TR>
	</TABLE>
	</TD></TR>
</TABLE>	
</FORM>   

</BODY>
</HTML>