<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../include/SystemStartup.asp"-->
<% selectDatabase "default" %>

<!--#include file="../include/querydatabase.asp" -->

<%
	dim teststring
	dim formstring
	const varprefix = "##"
	const varsuffix = "##"
	
	class Callback
		dim func
		dim iscached
		dim cache
	end class


	dim callbacks
	set callbacks = CreateObject("Scripting.Dictionary")

	dim query, rs

	InitCallbacks

	formstring = ReadForm()
	
	function ReadForm()
		dim query, rs
		
		query = " select isnull(html, '') as html from htmlform where formtype = 'BANR' "
		set rs = getdisconnectedrecordset(query)
		
		ReadForm = rs("html")
		
		set rs = nothing
	end function

	function GetTestString()
		dim item
		dim teststring
		
		teststring = "<table border=""0"" cellspacing=""0"" cellpadding=""0"">" & vbcrlf
		
		for each item in callbacks.Keys()
			teststring = teststring & "    <tr><td>" & item & "</td><td align=""right"">" & varprefix & item & varsuffix & "</td></tr>" & vbcrlf
		next
	
		teststring = teststring & "</table>"
		GetTestString = teststring
	end function
	

	function GetStoreName()
		dim query, rs
		
		query = " SELECT Store.name "
		query = query & " FROM Store "
		query = query & " WHERE Store.storeID = (SELECT MIN(storeID) From Store) "
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			GetStoreName = rs("name").Value
		end if
	end function

	function GetEmployeeName()
		GetEmployeeName = session("employeename")
	end function
	

	function GetPiecesDue()
		dim query, rs
		
		query = " SELECT isnull(SUM(dbo.getTotalPieces(Ticket.ticketNumber, null)), 0) as pcs_past_due "
		query = query & " FROM Ticket "
		query = query & " WHERE Ticket.ticketStatus = 'AC' "
		query = query & " AND DATEDIFF(day, Ticket.dueDate, getdate()) >= 0 "
		query = query & " AND dbo.pivotTicketRackLocationBrief(Ticket.ticketNumber, ',') = '' "
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			GetPiecesDue = rs("pcs_past_due")
		end if
	end function

	sub InitCallbacks()
		addCallback "StoreName", getref("GetStoreName")
		addCallback "EmployeeName", getref("GetEmployeeName")
		addCallback "PiecesDue", getref("GetPiecesDue")
	end sub

	function TranslateString(str)
		dim lhs, rhs
		dim result
		dim callback
		
		lhs = instr(1, str, varprefix, 1)

		if lhs > 0 then
			rhs = instr(lhs + len(varprefix), str, varsuffix, 1)

			callback = mid(str, lhs + len(varprefix), rhs - lhs - len(varprefix))

			TranslateString = left(str, lhs - 1) & executeCallback(callback) &  TranslateString(right(str, len(str) - rhs - 1))
		else
			TranslateString = str
		end if

	end function
	
	
	sub addCallback(name, func)
		dim newCallback
		set newCallback = new Callback

		set newCallback.func = func
		newCallback.cache = ""

		callbacks.Add name, newCallback
	end sub


	function executeCallback(name)
		dim callback

		if callbacks.exists(name) then
			set callback = callbacks.Item(name)

			if not callback.iscached then
				callback.cache = callback.func()
				callback.iscached = true
			end if
			
			executeCallback = callback.cache
			callbacks.Remove name
			callbacks.Add name, callback
		end if

	end function



%>
<%Response.Write TranslateString(formstring)%>

