<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>


<%
	'***********************************************************************
	'Name   :OverRide Price
    'Author : Poonam Gupta
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 26-Jun-2002    Poonam			Added Current Price Field
    '***********************************************************************
	
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim dueDateSet
	dim dueDate
	dim colorSet, upchargeSet, patternSet
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim itemIdToChange
	dim currentPrice
	dim invoice
	dim targetPage, originatingPage
	dim sInvoicenumber
	dim priceLater
	
	on error resume next
	itemIdToChange = Request.QueryString("selectedItemId")
	curr_LineNo = Request.Form("lineNumber")
	selectedDept = Request.Form("selectedDept")
	itemsStartIndex = Request.Form("ItemPageCount")
	upChargeStartIndex = Request.Form("upChargePageCount")
	colorsStartIndex = Request.Form("colorsPageCount")
	patternStartIndex = Request.Form("PatternPageCount")
	deptStartIndex = Request.Form("DeptPageCount")
	addOrEdit = Request.Form("addOrEdit")
	dueDateSet = Request.Form("isDueDateSet")
	dueDate = Request.Form("txtDueDate")
	upchargeSet = Request.Form("upchargeSet")
	colorSet = Request.Form("colorSet")
	patternSet = Request.Form("patternSet")
	selItemId = Request.Form("selItemId")
	selUpchargeValue = Request.Form("selUpcharge")
	selColorValue = Request.Form("selColor")
	selPatternValue = Request.Form("selPattern")
	targetPage = Request.QueryString("targetPage")
	originatingPage = Request.Form("originPage")
	sInvoicenumber = session("invoicelist")
	set invoice = Session("invoice")
	
	currentPrice = invoice.getUnitPriceForLineItem(itemIdToChange)
	priceLater = invoice.getPriceLaterForLineItem(itemIdToChange)
	
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number,err.description & " Edit Invoice"
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if
%>
<HTML>
<HEAD>
<TITLE>Override Price</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
	var lastFocusControl;
function txtPrice_onblur() {
	lastFocusControl = event.srcElement;
}
	
//-->
</SCRIPT>
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm() {
		var price;
		var temp;
		var targetPage;
		
		targetPage = document.overrideForm.tPage.value;
		price = document.overrideForm.txtPrice.value;
		price = trim(price);
		if (price.length > 0){
			price = cleanNumeric(document.overrideForm.txtPrice.value);
			if(price == "")	{
				show_focus("Enter valid amount.", "Amount", document.overrideForm.txtPrice);
				return;
			}
		}
		switch (targetPage) {
			case "detail":
					document.overrideForm.action = "detailedInvoice.asp?userAction=overridePrice";
					break;
			case "counterSale":
					document.overrideForm.action = "counterSale.asp?userAction=overridePrice";
					break;
		}
		document.overrideForm.submit();
	}
	function cancelForm() {

		var targetPage;
		targetPage = document.overrideForm.tPage.value;
		switch (targetPage) {
			case "detail":
					document.overrideForm.action = "detailedInvoice.asp";
					break;
			case "counterSale":
					document.overrideForm.action = "counterSale.asp";
					break;
		}
		document.overrideForm.submit();
	}
	
	function decimalFormat() {
		var price;
		
		price = document.overrideForm.txtPrice.value;
		price = trim(price);
		if(price.length > 0) {
			price = cleanNumeric(price);
			if(price == "")	{
				show_focus("Enter valid amount.", "Amount", document.overrideForm.txtPrice);
				return;
			}
		}
		document.overrideForm.txtPrice.value = autoFormatCurrency(document.overrideForm.txtPrice.value);
		captureKeyUpEvent("txtPrice"); //added by vivek on 02 Feb 2003
		
	}
	
	
	//Function added by vivek on 02 Feb 2003 to set the focus on the controls.
	function setFocusOnControl(element){
		if (element == "txtPrice"){
			document.overrideForm.okButton.focus();						
		}
	}
	
	//Function added by vivek on 02 Feb 2003 to set the focus on the controls when pressing the enter key.
	function captureKeyUpEvent(element){		
		if (event.keyCode == 13){
			event.returnValue = true;	
			
			if (element == "txtPrice")
				submitForm();
		}
	}	
</script>

<BODY topmargin=0 leftmargin=0 onLoad = "lastFocusControl = eval(document.overrideForm.txtPrice); document.overrideForm.txtPrice.focus();">

<!-- #include file="../include/banner.inc" -->
<H1>Enter New Price &nbsp;<%=sInvoicenumber%>&nbsp;</H1>
<FORM id="overrideForm" name="overrideForm" action="" method="post">
	<input type="hidden" name="itemIdToChange" id="itemIdToChange" value="<%= itemIdToChange%>">
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="upchargeSet" value="<%= upchargeSet %>">
	<INPUT type="hidden" name="colorSet" value="<%= colorSet %>">
	<INPUT type="hidden" name="patternSet" value="<%= patternSet %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<INPUT type="hidden" name="txtDueDate" value="<%= dueDate %>">
	<INPUT type="hidden" name="isDueDateSet" value="<%= dueDateSet %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	<TABLE ALIGN=center WIDTH=550 BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<TR>
			<TD width=100px class="label" align="right">Current Price</TD>
			<TD align=left width=100px>
				<INPUT id=txtCurrPrice name=txtCurrPrice class=text value="<%= FormatCurrency(currentPrice,,-1,0)%>" readonly>
			</TD>
			<td rowspan=4 width=250 align=center>
				<!-- #include file="../include/calculator.inc" -->
			</td>			
		</tr>	
		<TR>
			<TD class="label" align="right">New Price</TD>
			<TD align=left width=100px>
				<INPUT id=txtPrice name=txtPrice class=text onblur="txtPrice_onblur()" onKeyup="decimalFormat();">
			</TD>
		</tr>	
		<% if priceLater then %>
		<TR>
			<TD class="label" align="right">Set Due Date</TD>
			<TD align=left width=100px>
				<INPUT type="checkbox" style="height: 30px; width: 30px;" checked name="resetDueDate" value="1" />
			</TD>
		</tr>	
		<% end if %>
	</table>
	<TABLE ALIGN=center WIDTH=600 BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<TR height=20px></TR>
		<TR>
			<TD colspan=3>
				<TABLE ALIGN=center BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align="center" >
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick= "submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm();">
						</td>
					</tr>
				</table>
			</TD>
		</TR>			
	</table>
</form>
</BODY>
</HTML>
	