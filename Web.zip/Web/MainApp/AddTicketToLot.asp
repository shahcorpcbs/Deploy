<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim isSubmitted
	dim userAction
	
	
	isSubmitted = Request.QueryString("submitted")
	userAction = Request.QueryString("userAction")
	invoiceNo = Request.QueryString("txtInvoiceNo")
	custSeqNumber = session("customersequencenumber")	
	session("s_errmessage") = ""
		
	if (isSubmitted) then
		if (userAction = "done") then
			updateDatabase()
			Response.Redirect "customerfunctions.asp?customerseq=" & custSeqNumber
		else
			getTicketDepts()	
		end if
	end if 
		
		
	function getTicketDepts()
	
	dim sqltxt
				
	sqltxt = "select * from ticketlineitem where ticketlinetype in ('IT','AC') and ticketnumber = " & ticketno
	set detRst = getdisconnectedRecordSet(sqltxt)
	detRst.Sort = "departmentName ASC"
		
	if detRst.Recordcount > 0 then
		detRst.MoveFirst
		dept=detRst.Fields("departmentName").Value
		pkgqty = 0
		While Not detRst.eof
		If detRst.Fields("departmentName").Value = dept then
			if not isnull(detRst.Fields("packagedQuantity").value) then
				pkgqty = pkgqty + clng(detRst.Fields("packagedQuantity").value)*clng(detRst.Fields("quantity").value)
			end if	
		else
			dept=detRst.Fields("deptName").Value
			pkgqty = clng(detRst.Fields("packagedQuantity").value)*clng(detRst.Fields("quantity").value)
		end if
		detRst.moveNext
		wend
	end if	
	end function
	
	function updateDatabase()
	dim sqltxt
	dim Tagarr
	dim sTicket
	dim sTag
	dim sColor
	dim counter
	dim taginfo
	dim lotNumber
	
	'added by steve gagnon
	'need to get all the line items with the ticketnumber as in stored procedure
	dim sqllinequery
	dim sqllineresult

  ' this sucks, fix later.  better ways to delete and add
	if invoiceno <> "" then
    sqltxt = " delete tickettag from tickettag inner join ticket on tickettag.ticketnumber = ticket.ticketnumber where ticket.invoicenumber = " & invoiceno
		qryexecute sqltxt
	end if


	for counter =1 to Request.Form("tagNumbersList").Count
		tagInfo = Request.Form("tagNumbersList")(counter)
		tagArr = Split(tagInfo,"|||")
		sTicket = tagArr(0)
		sTag = tagArr(1)
		sColor   = tagarr(2)
		lotNumber = tagarr(3)

		sqllinequery = "SELECT TicketLineItem.ticketnumber, TicketLineItem.lineItemNumber, TicketLineItem.quantity, TicketLineItem.packagedQuantity " _
					& "FROM TicketLineItem INNER JOIN Ticket ON " _
					& "TicketLineItem.ticketNumber = Ticket.ticketNumber " _
					& "WHERE Ticket.invoiceNumber = '" & sTicket & "'"
						
		set sqllineresult = getDisconnectedRecordset(sqllinequery)

    if sqllineresult.recordcount > 0 then

      
      
  		sqltxt = " INSERT INTO [dbo].[TicketTag]([ticketNumber], [tagNumber], [tagNumberType], [tagColor], [ticketlineItemNumber], [lotNumber]) " _
  					& " VALUES (" &sqllineresult("ticketnumber")& " , " _
  					& "'" & sTag & "'" _
  					& "," & dbcreateqrystring("T") _
  					& "," & dbcreateqrystring(sColor) _
  					& "," & sqllineresult("lineItemNumber") _
						& "," & lotNumber &")"
  
      qryexecute sqltxt
    end if
	next

	end function

			
	function getExistingTagsForTicket(ticketNumber)
    dim query
    query = "SELECT tagNumber, tagColor, lotNumber, ticket.invoicenumber FROM TicketTag inner join ticket on tickettag.ticketnumber = ticket.ticketnumber where tickettag.ticketNumber=" & ticketNumber
    set getExistingTagsForTicket = getDisconnectedRecordset(query)
	end function
%>	
<HTML>
<HEAD>
<TITLE>Tag Number</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function addTagNoToList(tagColor){

	<% if enableLotTags then %>
		document.toolsTagNumber.txtTagNumber.focus();
		document.toolsTagNumber.txtTagNumber.select();

		var ticketNo = trim(document.toolsTagNumber.txtInvoiceNo.value);
		
		var lotNo = parseInt(document.toolsTagNumber.txtLotNumber.value);
		var tagNo = parseInt(document.toolsTagNumber.txtTagNumber.value);
		var tagNoEnd = parseInt(document.toolsTagNumber.txtTagNumberEnd.value);
		
		if(tagNoEnd < tagNo) {
			cbs_alert("Tag range not valid " + tagNoEnd + "<" + tagNo);
			return false;
		}

			for(var idx = tagNo; idx <= tagNoEnd; ++idx) {
				var oOption = document.createElement("OPTION");
				oOption.text= ticketNo + "--" + lotNo + "-" + idx + "(" + tagColor + ")";
				oOption.value=ticketNo + "|||" + idx + "|||" + tagColor + "|||" + lotNo;
				document.all.item("tagNumbersList").add(oOption);
			}
			document.toolsTagNumber.txtTagNumber.value="";
			document.toolsTagNumber.txtTagNumberEnd.value="";
			document.toolsTagNumber.txtTagNumber.focus();

	<% else %>
		var tagNo = document.toolsTagNumber.txtTagNumber.value;
		var ticketNo = trim(document.toolsTagNumber.txtInvoiceNo.value);
		tagNo = trim(tagNo);
		if(tagNo.length >0 && ticketNo.length > 0 ){
			var oOption = document.createElement("OPTION");
			oOption.text= ticketNo + "--" + tagNo + "(" + tagColor + ")";
			oOption.value=ticketNo + "|||" + tagNo + "|||" + tagColor + "|||" + 0;
			document.all.item("tagNumbersList").add(oOption);
			document.toolsTagNumber.txtTagNumber.value="";
			document.toolsTagNumber.txtTagNumber.focus();
		}
	<% end if %>
	}

	function deleteSelectedTagNo(){
		if(document.toolsTagNumber.tagNumbersList.length >0){
			var index = document.toolsTagNumber.tagNumbersList.selectedIndex;
			if(index >=0) {
				document.toolsTagNumber.tagNumbersList.options[index]=null;
			}
		}

	}
	
	function submitForm(element) {
		var counter;
		counter = document.toolsTagNumber.tagNumbersList.length;
		for(var i=0; i<counter; i++) {
			document.toolsTagNumber.tagNumbersList.options[i].selected =true;
		}
		if (element == "validate"){
			document.toolsTagNumber.action = "?submitted=true&userAction=validate&invoiceNumber=" + document.toolsTagNumber.txtInvoiceNo.value;
			document.toolsTagNumber.submit();
		}
		else{	
			document.toolsTagNumber.action = "?submitted=true&userAction=done";
			document.toolsTagNumber.submit();
		}	
	}
	
	function cancelForm() {
		document.toolsTagNumber.action = "toolsMenu.asp";
		document.toolsTagNumber.submit();	
	}
	
	function onTagNumberClick() {
		var invoiceNumber = trim(document.toolsTagNumber.txtInvoiceNo.value);
		var tagNumber = trim(document.toolsTagNumber.txtTagNumber.value);

		
		if (invoiceNumber != "" && tagNumber == ""){
			storeItemsOnForm(trim(invoiceNumber)) ;
			submitForm("validate");
		}
	}

	function captureKeyDownEvent(element){
		if (event.keyCode == 9){
			if (element.name == "txtInvoiceNo" && trim(element.value).length != 0){
				if(storeItemsOnForm(trim(document.toolsTagNumber.txtInvoiceNo.value)))
					submitForm("validate");
			}
		}
	}			
	
	function captureKeyUpEvent(element){
		if (event.keyCode == 13){
			if (element.name == "txtInvoiceNo" && trim(element.value).length != 0){
				if(storeItemsOnForm(trim(document.toolsTagNumber.txtInvoiceNo.value)))
					submitForm("validate");
			}
		}
	}			
	
	function setFocusOnControl(element){
		if (element == "tagNumber"){
		<% if enableLotTags then %>
			document.toolsTagNumber.txtLotNumber.focus();
		<% else %>
			document.toolsTagNumber.txtTagNumber.focus();
		<% end if %>
		}	
		else if (element == "invoiceNumber"){
			document.toolsTagNumber.txtInvoiceNo.focus();
		}
	}	
	
	function storeItemsOnForm(sInvoice){
		if (sInvoice == "") 
			return false;
			
		sInvoice = translateInvoiceNumber(sInvoice);
		
		if(sInvoice == -1) {
			cbs_alert("Invalid invoice number.");
			return false;
		}
		
		document.toolsTagNumber.txtInvoiceNo.value = sInvoice;
		return true;	
	}
	function moveFocus(obj) {
	<% if enableLotTags then %>
		if (event.keyCode == 13){
			if(obj.name == "txtLotNumber") {
				document.toolsTagNumber.txtTagNumber.focus();
				document.toolsTagNumber.txtTagNumber.select();
			}
			else if(obj.name == "txtTagNumber") {
				document.toolsTagNumber.txtTagNumberEnd.focus();
				document.toolsTagNumber.txtTagNumberEnd.select();
			}
		}
	<% end if %>
	}
//	function captureKeyUpEvent(element){
//		if (event.keyCode == 13){
			//event.returnValue = true;
//			if (element.name == "txtInvoiceNo"){
//				if (trim(element.value).length > 0)
//					document.toolsTagNumber.txtTagNumber.focus()
//				}
//			else if (element.name == "txtTagNumber" ){
//				if (trim(element.value).length > 0)
//					document.toolsTagNumber.red.focus()
//			}
//		} 	
//	}
	

</script>
<BODY topmargin=0 leftmargin=0 

<% if (isValid) then %>
	onLoad= "setFocusOnControl('tagNumber')"
<% else %>
	onLoad= "setFocusOnControl('invoiceNumber')"
<% end if %>

>
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->
<H1>Enter Tag Number</H1>
<FORM id="toolsTagNumber" name="toolsTagNumber" action="" method="post" >
	<TABLE ALIGN=center width=800px BORDER=0 CELLSPACING=0 CELLPADDING=2 >
		<% if len(trim(session("s_errMessage")) ) > 0 then %>
		<tr>
			<td width = 40px></td>
			<td colspan=5><font color = red size =2 ><b><%= session("s_errMessage")%></b></font></td>
		<td></td>		
	</tr>
		<% end if %>
		
		

		<tr valign=top>
			<td rowspan = 12>
				<table name="invoiceDetails" id=invoiceDetails width=300px>
				<tr>
					<td colspan=2 class=label align=left style=font-size=16><U>Invoice Details</u></td>
				</tr>	
				<tr><td></td>
				</tr>
				<tr>
					<td colspan=2 style=font-size=16>Due Date:&nbsp<%=duedateDay%>, <%=dueDate%>
					</td>
				</tr>	
				<tr>
					<td style=font-size=16>Finish: <%=finishpref%></td>
				</tr>
				<tr>	
					<td style=font-size=16>Starch: <%=starchpref%></td>
				</tr>
				<tr rowspan=3><td></td>
				</tr>
				<tr>
					<td style=font-size=16><u>Department</u></td>
					<td style=font-size=16><u>Pieces</u></td>
				</tr>	
				<tr>		
					<td style=font-size=16><%=dept%></td>
					<td style=font-size=16><%=pkgqty%></td>
				</tr>		
				</table>
			</td>		
		</tr>
		<tr>
			<td colspan=2 class="label" align="center" style=font-size=16>Invoice</td>
		</tr>
		<tr>
			<td colspan=2 align="center" >
				<INPUT id=txtInvoiceNo name=txtInvoiceNo class=text style="HEIGHT: 25px; WIDTH: 200px" value="<%=invoiceno%>" 
					  onKeyUp="captureKeyUpEvent(this)" onKeyDown="captureKeyDownEvent(this)">
			</td>
			<td rowspan=12 valign=top>
				<Table ALIGN=center BORDER=0 CELLSPACING=0 CELLPADDING=0 >
					<tr>
						<td >		
							<select id=tagNumbersList name=tagNumbersList size=10 style="width:250px;font-size=16px" multiple >
								<%
								  if ticketno <> "" then
  									dim existingTags
  									set existingTags = getExistingTagsForTicket(ticketno)
  									if existingTags.Recordcount > 0 then
  										existingTags.MoveFirst
  										while not existingTags.eof
  							%>
  											<option value="<%= existingTags.Fields("invoicenumber").Value & "|||" & existingTags.Fields("tagNumber").Value & "|||" & existingTags.Fields("tagColor").Value & "|||" & existingTags.Fields("lotNumber").Value%>">
  											<% if existingTags.Fields("lotNumber").Value > 0 then %>
  											<%= existingTags.Fields("invoicenumber").Value & "-" & existingTags.Fields("lotNumber").Value & "-" & existingTags.Fields("tagNumber").Value & " (" & existingTags.Fields("tagColor").Value & ")"%>
  											<% else %>
  											<%= existingTags.Fields("invoicenumber").Value & "--" & existingTags.Fields("tagNumber").Value & " (" & existingTags.Fields("tagColor").Value & ")"%>
  											<% end if %>
  											</option>
  							<%				
  											existingTags.MoveNext
  										wend
  									end if
									end if
								%>
							</select>
						<td>
					</tr>
					<tr height=20px><td></td></tr>
					<tr>
						<td align=center>
							<INPUT class=touch id=delete name=delete type=button value="" style="background-image:url(../images/Cancel-2.gif);background-position=center" onClick="deleteSelectedTagNo()" ><br>Delete<br>
						</td>
					</tr>
					<tr height=20px><td></td></tr>
					<tr>
						<td align=center>
							<INPUT class=touchnoborder id=ok name=ok type=button value="" style="background-image:url(../images/OK.gif)" onClick="submitForm()">&nbsp&nbsp&nbsp&nbsp&nbsp
							<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
		<td colspan="2">
		<table>
		<% if enableLotTags then %>
		<tr>
			<td colspan=1 class="label" align="center" style=font-size=16 width="85px">Lot</td>
			<td colspan=1 class="label" align="center" style=font-size=16>Tag Range</td>
		</tr>
		<tr>
			<td colspan=1 align=center width="85px">
				<INPUT id=txtLotNumber name=txtLotNumber class=text style="WIDTH: 50px;" onkeyup="moveFocus(this)">
			</td>
			<td colspan=1 align=center>
				<INPUT id=txtTagNumber name=txtTagNumber class=text style="WIDTH: 50px;" onkeyup="moveFocus(this)">
				<INPUT id=txtTagNumberEnd name=txtTagNumberEnd class=text style="WIDTH: 50px;" onkeyup="moveFocus(this)">
			</td>
		</tr>
		<% else %>
		<tr>
			<td colspan=2 class="label" align="center" style=font-size=16 >Tag</td>
		</tr>
		<tr>
			<td colspan=2 align=center>
				<INPUT id=txtTagNumber name=txtTagNumber class=text style="WIDTH: 190px;">
			</td>
		</tr>
		<% end if %>
		</table>
		</td>
		</tr>
		
		<tr height=10px><td></td></tr>
		<tr>
			<TD align=right width=150><INPUT class=touch id=red name=red type=button value="" style=background-color:FF0000 onClick="addTagNoToList(this.name);">&nbsp</TD>
			<Td align=left width=150><INPUT class=touch id=green name=green type=button value="" style=background-color:green onClick="addTagNoToList(this.name);"><br></TD>
		</tr>
		<tr>
			<TD align="right" ><INPUT class=touch id=blue name=blue type=button value="" style=background-color:blue onClick="addTagNoToList(this.name);">&nbsp</TD>
			<TD align="left" ><INPUT class=touch id=pink name=pink type=button value="" style=background-color:pink onClick="addTagNoToList(this.name);"><br></TD>
		</tr>
		<tr>
			<TD align="right" ><INPUT class=touch id=Lavender name=Lavender type=button value="" style=background-color:9966CC onClick="addTagNoToList(this.name);">&nbsp</TD>
			<TD align="left" ><INPUT class=touch id=yellow name=yellow type=button value="" style=background-color:yellow onClick="addTagNoToList(this.name);"><br></TD>
		</tr>
		<tr >
			<TD align="right" ><INPUT class=touch id=white name=white type=button value="" style=background-color:white onClick="addTagNoToList(this.name);">&nbsp</TD>
			<TD align="left" ><INPUT class=touch id=orange name=orange type=button value="" style=background-color:FF9933 onClick="addTagNoToList(this.name);"><br></TD>
		</tr>
		<tr>
			<TD align="right" ><INPUT class=touch id=brown name=brown type=button value="" style=background-color:663300 onClick="addTagNoToList(this.name);">&nbsp</TD>
			<TD align="left" ><INPUT class=touch id=gray name=gray type=button value="" style=background-color:gray onClick="addTagNoToList(this.name);"><br></TD>
		</tr>
	</TABLE>
</FORM>   

</BODY>
</HTML>
