<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<%

%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<SCRIPT language="javascript" type="text/javascript">

</SCRIPT>
</HEAD>

<BODY STYLE="margin:0;padding:0;background:#FFF">

<TABLE width="100%" height="100%" cellspacing=10>

<TR><TD align="center" valign="bottom">
	<SPAN style="font-size:16">
	<%if request.querystring("message") <> "" then%>
	<%=request.querystring("message")%>
	<%else%>
	Done
	<%end if%>
	</SPAN>
</TD></TR>
<TR><TD align="center" valign="top">
	<INPUT type="button" value="Close Window" onclick="window.close()">
</TD></TR>

</TABLE>

</BODY>
</HTML>
