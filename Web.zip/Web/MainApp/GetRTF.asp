<%@ Language=VBScript %>
<% option explicit %>
<!--#include file="../include/SystemStartup.asp"-->
<% if request.querystring("dbname") <> "" then
	selectDatabase request.querystring("dbname")
	end if
%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!-- #include file="../include/codecs.inc" -->
<!--#include file="../external/include.asp" -->
<!--#include file="../include/services.asp" -->
<%
	dim storeId
	storeId = clng(Request.QueryString("store"))
	include getBarcodeEncoderFilename()
	function getBarcodeEncoderFilename()
		on error resume next
		getBarcodeEncoderFilename = "/include/barcode.asp"
		getBarcodeEncoderFilename = getMSVar("BarcodeEncoderFile")
	end function
%>

<%
	Public Const PickupInvoice = 0
	Public Const EditInvoice = 1
	Public Const QuickInvoice = 2
	Public Const DetailedInvoice = 3
	Public Const CounterSales = 4
	Public Const Tag1 = 5
	Public Const Tag2 = 6
	Public Const HeatSeal = 7
	'Following added by J.Johnston, 6Nov03
	Public Const CreditReceipt = 8
	'End addition, 6Nov03
	public const CouponList = 9
	public const BagTag = 10
	public const ReleaseForm = 11
	public const RackSlip = 12

	Public Const EDIT_INVOICE_QUICK = 0
	Public Const EDIT_INVOICE_DETAILED = 1

	'''     Constants used by StrConv fuunction
    const vbUpperCase = 1
    const vbLowerCase = 2
    const vbProperCase = 3
    const vbWide = 4
    const vbNarrow = 8
    const vbKatakana = 16
    const vbHiragana = 32
    const vbUnicode = 64
    const vbFromUnicode = 128

    ''' Constant to set the Line Item length
    Dim lineItemWTLength
    Dim lineItemWOTLength
    Dim priceStringLength
    Dim scStringLength

    lineItemWTLength = 21
    lineItemWOTLength = 30
    priceStringLength = 9
    scStringLength = 21

    '''Constants to set the Initial String for Line Item Printing
	Dim lineItemStrWT
	Dim lineItemStrWOT
	Dim lineItemStrZWT
	Dim totalsTab
	Dim lineDelimeter
	dim rackDetailStrWT
	dim odcTabTwips

	''' changed by stevegagnon
	''' old: lineItemStrWT = "\viewkind4\uc1\pard\tx540\tx3000\tx3900\fs18 "
	lineItemStrWT = "\viewkind4\uc1\pard\tx540\tx2800\tx6120\tx6660\tx9180 "
	lineItemStrZWT = "\viewkind4\uc1\pard\tx540\tx4550\tx7670\tx8210\tx10730 "

	''' old: lineItemStrWOT = "\viewkind4\uc1\pard\tx540\tx3900\fs18 "
	lineItemStrWOT = "\viewkind4\uc1\pard\tx540\tx6120\tx6660 "

	''' old: totalsTab = "\viewkind4\uc1\pard\tx3000\fs18 "
	totalsTab = "\viewkind4\uc1\pard\tx3000 "

	lineDelimeter = "\par \tab "

	rackDetailStrWT = "\viewkind4\uc1\pard\tx777\tx3000\tx6120\tx6660\tx9180 "

	odcTabTwips = "\viewkind4\uc1\pard\tx2500 "

	dim nl
	nl = chr(13) & chr(10)

	Dim terminalId, employeeId, ticketNo, custSeqNo
	Dim tagNo, hSeal, allTags, allheatseals
	Dim pickupTickets
	Dim prePayDiscount
	Dim isOnAccountCustomer
	isOnAccountCustomer = false

	allTags = Request.QueryString("alltags")
	Dim PrType,EdInvType
	PrType = clng(Request.QueryString("pt"))

	hSeal = Request.QueryString("heatseal")
	'MWiemann 11-13-2003 changed from clng to CLng
	ticketNo = CLng(Request.QueryString("key"))

	EdInvType = isTicketDetailed(ticketNo)

	pickupTickets = Request.QueryString("pickup")

	allheatseals = Request.QueryString("allheatseals")


	function isPrintGroupOnTicket(ticketNumber, printGroup)
		dim query, rs

		query = " select 1 from ticketlineitem "
		query = query & " inner join department on ticketlineitem.departmentid = department.departmentid "
		query = query & " where ticketlineitem.ticketnumber in (" & ticketNumber & ")"
		query = query & " and department.printgroup = '" & dbstr(printgroup) & "'"

		set rs = getdisconnectedrecordset(query)

		isPrintGroupOnTicket = rs.recordcount > 0

		set rs = nothing
	end function


	if	(PrType = QuickInvoice or _
		PrType = DetailedInvoice) _
		and Request.QueryString("type") <> "pdf" _
		and Request.QueryString("mpPrinter") = "" _
	then
		dim printGroup
		printGroup = getPrinterPrintGroup(request.querystring("pid"))

		if printGroup <> "" then
			if not isPrintGroupOnTicket(ticketNo, printGroup) then
				response.flush
				response.end
			end if
		end if
	end if


	function getPrinterPrintGroup(printerID)
		dim query, rs

		query = " select printGroup from printer where printerid = " & printerID
		set rs = getdisconnectedrecordset(query)

		getPrinterPrintGroup = null

		if rs.recordcount > 0 then
			getPrinterPrintGroup = rs("printGroup")
		end if

		set rs = nothing

	end function

	function getAllTagNumbers(ticketNumber, tagPrinter)
		dim query, rs
		dim exclusiveDepartment
		dim result
		dim terminalID
		dim printGroup

		terminalID = request.querystring("terminal")

		printGroup = getPrinterPrintGroup(tagPrinter)

		query = " select tickettag.tagnumber "
		query = query & " from tickettag "
		query = query & " left outer join department on tickettag.departmentid = department.departmentid "
		query = query & " where tickettag.ticketnumber = " & ticketNumber

		if not isnull(printGroup) then
			query = query & " and department.printgroup = '" & printGroup & "'"
		end if

    query = query & " ORDER BY CASE dbo.isInt(TicketTag.tagNumber) WHEN 1 THEN CONVERT(int, TicketTag.tagNumber) ELSE -1 END "

		set rs = getdisconnectedrecordset(query)

		result = ""

		while not (rs.eof or rs.bof)
			if result <> "" then result = result & ", "
			result = result & rs("tagNumber")
			rs.movenext
		wend

		set rs = nothing

		getAllTagNumbers = result
	end function


	if allTags = "Y" or alltags = "y" then
		'This request is for getting all tag numbers for a given invoice
		' represented by ticketNo
		'Get all tag numbers for the ticketNo and return back as CSV (one line):
		'Tag No 1,Tag No 2,Tag No 3,..Tag No n
		Dim allTagNumbers

		allTagNumbers = getAllTagNumbers(ticketNo, request.querystring("pid"))

		'if allTagNumbers <> "" Then
		'	Response.Write(allTagNumbers)
		'else
		'	Response.Write("NOTAGS")
		'End if

		'Response.Flush

        Dim data, httpRequest, postResponse, notificationIP
        notificationIP = getPrinterShortPath()

        if notificationIP <> "" then
             dim params, userIPAddress, printerName
             query = "select printerName, u200, u200Type from Printer where printerId = " & Request.QueryString("pid")
             set rs = getdisconnectedrecordset(query)

             if Request.QueryString("overwritePrinter") <> "" then
                printerName = Request.QueryString("overwritePrinter")
             elseif Request.QueryString("mpPrinter") = "" then
                printerName = rs("printerName")
             else
                printerName = replace(Server.HTMLEncode(Request.QueryString("mpPrinter")), "&quot;", "")
            end if

            userIPAddress = getLocalPrinterAddress(terminalId)
		    params = "/text?requestPrinterName=" & replace(Server.HTMLEncode(printerName), "\", "%5C") & "&textType=rtf&driver=" _
		        & Server.HTMLEncode(Request.QueryString("driver")) & "&isU200=" & Server.HTMLEncode(rs("u200")) _
                & "&u200Type=" & Server.HTMLEncode(rs("u200Type"))

           if Request.QueryString("UID") <> "" then
                params = params & "&UID=" & Request.QueryString("UID")
           end if
           if Request.QueryString("last") <> "" then
                params = params & "&last=1"
           end if


            Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
            httpRequest.Open "POST", "http://" & userIPAddress & notificationIP & params, False
            httpRequest.SetRequestHeader "Content-Type", "text/plain"
            httpRequest.Send Server.HTMLEncode(allTagNumbers)
            postResponse = httpRequest.ResponseText

        end if


		Response.End
	end if
	if allheatseals = "Y" or allheatseals = "y" then
			Response.Write("NOHEATSEALS")
			Response.Flush
			Response.End
	end if

	terminalId = clng(Request.QueryString("terminal"))
	employeeId = clng(Request.QueryString("emp"))
	if Request.QueryString("cust") <> "" then
		custSeqNo = clng(Request.QueryString("cust"))
	else
		custSeqNo = 0
	end if
	tagNo = Request.QueryString("tag")

	getStoreInfo storeId



	if custSeqNo <= 0 and ticketNo > 0  then
		dim query, rs
		query = "select customersequencenumber from ticket where ticketnumber = '" & trim(ticketNo) & "'"
		set rs = getdisconnectedrecordset(query)
		if not(rs.eof or rs.bof) then
			custSeqNo = rs("customersequencenumber")
		end if
		set rs = nothing
	end if

	'added by steve gagnon
	'contains the wide two column version of each
	Dim gdwcp80    'Group Detail /w Colors And Patterns
	Dim gdwocp80    'Group Detail W/o Colors And Patterns
	Dim gdwu80    'Group Detail /w Upcharges
	Dim gdwou80    'Group Detail W/o Upcharges
	Dim lidwot80    'Line Item Detail W/o Total
	Dim lidwt80    'Line Item Detail /w Total

	Dim cemail

	Dim currentinvoices

	'added by steve gagnon
	'for two new fields for labels
	Dim itemname
	Dim itemnumber

	'added by steve gagnon
	'for subtotal with surcharges
	dim totptsc
	dim discountamt
	Dim subtotws
	dim rackdetails
	dim racksummary
	dim lotdetails
	dim signature
	Dim totpts
	dim totps
	dim totpt
	dim rackinfo
	dim gdwung
	dim gdwung80
	dim ticrddowa
	dim totalsales
	dim lastvisit
	dim gdwuwot
	dim customersource
	dim zgdwu
	dim wgdwu
	dim cname
	dim caddress
	dim ename
	dim tnum1
	dim odc
	dim creempln
	dim creempfn
	dim sctot
	dim willcall
	dim lotnum
	dim lotname
	dim tagcolor
	dim barcode
	dim gdwund
	dim duedates
	dim routename
	dim tnum128
	dim gddo
	dim rstatus
	dim visitcount
	dim newcustomer
	dim raccount

	dim storename
	dim storeaddress1
	dim storeaddress2
	dim storecity
	dim storestate
	dim storezip
	dim storephone
	dim storeareacode
	dim storewebsite
	dim storeemail
	dim storenumber



	Dim coup    'Coupons
	Dim lidwot    'Line Item Detail W/o Total
	Dim lidwt    'Line Item Detail /w Total
	Dim slidwot    'Single Line Detail W/o Total
	Dim slidwt    'Single Line Detail /w Total
	Dim gdwcp    'Group Detail /w Colors And Patterns
	Dim gdwocp    'Group Detail W/o Colors And Patterns
	Dim gdwu    'Group Detail /w Upcharges
	Dim gdwou    'Group Detail W/o Upcharges
	Dim cfn    'Customer First Name
	Dim cln    'Customer Last Name
	Dim cid    'Customer ID
	Dim cfi    'Customer First Initial
	Dim cli    'Customer Last Initial
	Dim mpn    'Multiple Pickup Name
	Dim mpl    'Multiple Pickup Location
	Dim cphone    'Customer Phone #
	Dim mainphone 'Customer Main Phone, No Area Code
	Dim altphone  'Customer Alt Phone, No Area Code
	Dim cba1    'Customer Billing Address 1
	Dim cba2    'Customer Billing Address 2
	Dim cba3    'Customer Billing Address 3
	Dim bcity    'Billing City
	Dim bzip    'Billing Zip
	Dim bstate    'Billing State
	Dim sphone		'Ship Phone
	Dim sa1			'Ship Address 1
	Dim sa2			'Ship Address 2
	Dim sa3			'Ship Address 3
	Dim scity		'Ship City
	Dim sstate		'Ship State
	Dim szip		'Ship Zip
	Dim tnotes		'Ticket Notes
	Dim spref		'Starch Preference
	Dim fpref		'Finish Preference
	Dim rnum		'Route Number
	Dim rname		'Route Name
	Dim snum		'Stop Number
	Dim dday		'Delivery Day
	Dim abal		'Account Balance
	Dim ppref		'Payment Preference
	Dim ptable		'Pricing Table
	Dim tnum		'Ticket Number
	Dim barco		'Barcode
	Dim storebarco	'Barcode
	Dim tagnum		'Tag Number
	Dim subtot		'Subtotal
	Dim tax1, tax2, tax3, tax4, tax5, tax6, tax7, tax8, tax9, tax10
	dim taxTot
	Dim total		'Total
	Dim paymentDetails    'paymentDetails
	'Dim tax		'Tax
	'Fields added by MWiemann 10-14-03
	Dim baldue		'Balance Due
	Dim paytyp		'Payment Types
	Dim totpay		'Total payments

	'Dim chgdue		'Change Due
	Dim aonacc		'Amount On Account
	Dim apaid		'Amount Paid
	Dim credate		'Creation Date
	Dim tratime		'Transaction Time
	Dim tradate		'Transaction Date
	Dim tradow		'Transaction DOW
	Dim ticrdtime    'Ticket Ready Time
	Dim ticrddate    'Ticket Ready Date
	Dim ticrddow    'Ticket Ready DOW
	Dim itemcoun    'Item Count
	Dim efn			'Employee First Name
	Dim efi			'Employee First Initial
	Dim eln			'Employee Last Name
	Dim eli			'Employee Last Initial
	Dim creemp		'Creation Employee
	Dim deptname	' Department Name
	dim deptinitals 'Department Initals
	Dim sc1			' Surcharge 1
	Dim sc2			' Surcharge 2

	'Following added by J.Johnston, 6Nov03
	dim ccAuthCode
	dim ccExpDate
	dim ccType
	dim ccCardType
	dim ccAcctNum
	dim ccCardHolder
	dim ccTotal
	'End addition, 6Nov03

	dim employeeTip : employeeTip = 0

	'added by steve gagnon
	gdwcp80 = ""
	gdwocp80 = ""
	gdwu80 = ""
	gdwou80 = ""
	lidwot80 = ""
	lidwt80 = ""
	itemname = ""
	itemnumber = ""
	subtotws = ""
	totpts = "0.00"
	totpt = "0.00"
	totps = "0.00"
	rackinfo = ""
	gdwung = ""
	rackdetails = ""
	racksummary = ""
	discountamt = "0.00"
	totptsc = "0.00"
	ticrddowa = ""
	currentinvoices = ""
	totalsales = "0.00"
	lastvisit = ""
	prepaydiscount = "0.00"
	gdwuwot = ""
	customersource = "None"
	zgdwu = ""
	wgdwu = ""
	cname = ""
	caddress = ""
	ename = ""
	tnum1 = ""
	odc = ""
	creempln = ""
	creempfn = ""
	sctot = "0.00"
	willcall = ""
	lotnum = ""
	lotname = ""
	tagcolor = ""
	barcode = ""
	gdwund = ""
	duedates = ""
	routename = ""
	tnum128 = ""
	gddo = ""
	rstatus = ""
	newcustomer = ""
	raccount = ""

	storenumber = ""
	storename = ""
	storeaddress1 = ""
	storeaddress2 = ""
	storecity = ""
	storestate = ""
	storezip = ""
	storephone = ""
	storeareacode = ""
	storewebsite = ""
	storeemail = ""


	coup = ""
	lidwot = ""
	lidwt = ""
	slidwot = ""
	slidwt = ""
	gdwcp = ""
	gdwocp = ""
	gdwu = ""
	gdwou = ""
	cfn = ""
	cln = ""
	cid = custSeqNo
	cfi = ""
	cli = ""
	mpn = ""
	mpl = ""
	cphone = ""
	mainphone = ""
	altphone = ""
	cba1 = ""
	cba2 = ""
	cba3 = ""
	bcity = ""
	bzip = ""
	bstate = ""
	sphone = ""
	sa1 = ""
	sa2 = ""
	sa3 = ""
	scity = ""
	sstate = ""
	szip = ""
	tnotes = ""
	spref = ""
	fpref = ""
	rnum = ""
	rname = ""
	snum = ""
	dday = ""
	abal = "0.00"
	ppref = ""
	ptable = ""
	tnum = ""
	barco = ""
	storebarco = ""
	tagnum = ""
	subtot = ""
	tax1 = "0.00"
	tax2 = "0.00"
	tax3 = "0.00"
	tax4 = "0.00"
	tax5 = "0.00"
	tax6 = "0.00"
	tax7 = "0.00"
	tax8 = "0.00"
	tax9 = "0.00"
	tax10 = "0.00"
	taxTot = "0.00"
	total = "0.00"
	paymentDetails = ""
	'tax = ""
	baldue = ""
	paytyp = ""
	totpay = ""
	'chgdue = ""
	aonacc = ""
	apaid = ""
	credate = ""
	ticrdtime = ""
	ticrddate = ""
	ticrddow = ""
	itemcoun = ""
	efn = ""
	efi = ""
	eln = ""
	eli = ""
	creemp = ""
	deptname = ""
	deptinitals = ""
	sc1 = "0.00"
	sc2 = "0.00"
	signature = ""


	'Following added by J.Johnston, 6Nov03
	ccAuthCode = Request.QueryString("ccAuthCode")
	ccExpDate = Request.QueryString("ccExpDate")
	ccType = Request.QueryString("ccType")
	ccAcctNum = "XXXX XXXX XXXX " & right(Request.QueryString("ccAcctNum"), 4)
	ccCardHolder = Request.QueryString("ccCardHolder")
	ccTotal = Request.QueryString("ccTotal")
	if ccTotal = "" then ccTotal = 0
	ccTotal = formatnumber(ccTotal,2,true)
	'End addition, 6Nov03

	tratime = FormatDateTime(Now, 3)
	tradate = FormatDateTime(Now, 2)
	dim ardow
	ardow = Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
	tradow = ardow(DatePart("w", Now())-1)


  selectEmployee employeeId


	Dim  InvoiceObject, PickupObject
	Dim custsql, custrs
	Dim rtfsql, rtfrs


	'Following modified by J.Johnston, 18Dec03 -- modified CreditReceipt logic
	If PrType = PickupInvoice Or PrType = RackSlip Or (PrType = CreditReceipt AND pickupTickets <> "") then
		InitializePickupObject

	elseif PrType = DetailedInvoice or PrType = ReleaseForm Or (PrType = EditInvoice And EdInvType = EDIT_INVOICE_DETAILED)_
	 Or (PrType = CounterSales) OR (PrType = CreditReceipt AND pickupTickets = "") Then
	'End modification, 18Dec03

		Set InvoiceObject = Server.CreateObject("ShahCorpComponents.invoice")
		InvoiceObject.DBConnectionString = Session("shahcorpDSN")
		On Error Resume Next
		InvoiceObject.getInvoiceDetailsForPrinting ticketNo
		If Err.number <> 0 Then
			Response.Write "ERROR 03:" & Err.Description & ", " & Err.number & ", " & err.Source
			Response.End
			Err.Clear
		End if
		if Not IsObject(InvoiceObject) or InvoiceObject Is Nothing Then
			Response.Write ("ERROR 04:Failed to retrieve the ticket information")
			Response.Flush
			Response.End
		End If

		if InvoiceObject.custSeqNumber > 0 then
			custSeqNo = InvoiceObject.custSeqNumber
		end if

	elseif PrType = QuickInvoice  Or (PrType = EditInvoice And EdInvType = EDIT_INVOICE_QUICK) Then

		Set InvoiceObject = Server.CreateObject("ShahCorpComponents.quickInvoice")
		InvoiceObject.DBConnectionString = Session("shahcorpDSN")
		On Error Resume Next
		InvoiceObject.getExistingDetails ticketNo
		If Err.number <> 0 Then
			Response.Write "ERROR 05:" & Err.Description & ", " & Err.number & ", " & err.Source
			Response.End
			Err.Clear
		End if
		if Not IsObject(InvoiceObject) or InvoiceObject Is Nothing Then
			Response.Write ("ERROR 06:Failed to retrieve the ticket information")
			Response.Flush
			Response.End
		End If

		custSeqNo = InvoiceObject.custSeqNumber

	elseif PrType = EditInvoice Then
		Set InvoiceObject = Server.CreateObject("ShahCorpComponents.invoice")
		InvoiceObject.DBConnectionString = Session("shahcorpDSN")
		On Error Resume Next
		InvoiceObject.getInvoiceDetailsForPrinting ticketNo

		if Not IsObject(InvoiceObject) or InvoiceObject Is Nothing Then
			Response.Write ("ERROR 07:Failed to retrieve the ticket information")
			Response.Flush
			Response.End
		End If

		custSeqNo = InvoiceObject.custSeqNumber

	elseif PrType = CounterSales then
		'
		'Same as Detailed Invoice
		'
	elseif PrType = Tag1 or PrType = Tag2 or PrType = HeatSeal then
		' Nothing to do
	end if


		custsql = "SELECT IsNull(TC.ticketNumber, ' ') ticketNumber, IsNull(TC.customerID, C.customerID)customerID, "
		custsql = custsql & " IsNull(TC.multiplePickup, ' ')multiplePickup, "
		custsql = custsql & " IsNull(TC.multiPickupCustomerName, ' ')multiPickupCustomerName, "
		custsql = custsql & " IsNull(TC.multiPickupLocation, ' ')multiPickupLocation, "
		custsql = custsql & " isnull(IsNull(TC.firstName, C.firstName), '')firstName, "
		custsql = custsql & " isnull(IsNull(TC.middleInitial, C.middleInitial), '')middleInitial, "
		custsql = custsql & " isnull(IsNull(TC.lastName, C.lastName), '')lastName, "
		custsql = custsql & " isnull(IsNull(TC.employer, C.employer), '')employer, "
		custsql = custsql & " isnull(IsNull(TC.billingAddress1, C.billingAddress1), '')billingAddress1, "
		custsql = custsql & " isnull(IsNull(TC.billingAddress2, C.billingAddress2), '')billingAddress2, "
		custsql = custsql & " isnull(IsNull(TC.billingAddress3, C.billingAddress3), '')billingAddress3, "
		custsql = custsql & " isnull(IsNull(TC.billingCity, C.billingCity), '')billingCity, "
		custsql = custsql & " isnull(IsNull(TC.billingState, C.billingState), '')billingState, "
		custsql = custsql & " isnull(IsNull(TC.billingZipCode, C.billingZipCode), '')billingZipCode, "
		custsql = custsql & " isnull(IsNull(TC.MainAreaCode, C.MainAreaCode), '')MainAreaCode, "
		custsql = custsql & " isnull(IsNull(TC.MainPhone, C.MainPhone), '')MainPhone, "
		custsql = custsql & " isnull(IsNull(TC.shippingAddress1, C.shippingAddress1), '')shippingAddress1, "
		custsql = custsql & " isnull(IsNull(TC.shippingAddress2, C.shippingAddress2), '')shippingAddress2, "
		custsql = custsql & " isnull(IsNull(TC.shippingAddress3, C.shippingAddress3), '')shippingAddress3, "
		custsql = custsql & " isnull(IsNull(TC.shippingCity, C.shippingCity), '')shippingCity, "
		custsql = custsql & " isnull(IsNull(TC.shippingState, C.shippingState), '')shippingState, "
		custsql = custsql & " isnull(IsNull(TC.shippingZipCode, C.shippingZipCode), '')shippingZipCode, "
		custsql = custsql & " isnull(IsNull(TC.AltAreaCode, C.AltAreaCode), '')AltAreaCode, "
		custsql = custsql & " isnull(IsNull(TC.AltPhone, C.AltPhone), '')AltPhone, "
		custsql = custsql & " isnull(IsNull(TC.stopNumber, dbo.getCustomerStopNumber(C.customerSequenceNumber, NULL)), 0) stopNumber, "

		custsql = custsql & " IsNull(C.permanentAccount, ' ')permanentAccount, "
		custsql = custsql & " IsNull(C.temporaryAccount, ' ')temporaryAccount, "
		custsql = custsql & " IsNull(C.routeNumber, ' ')routeNumber, "
		custsql = custsql & " IsNull(C.invoiceNotes, ' ')invoiceNotes, "
		custsql = custsql & " IsNull(C.accountBalance, 0.00)accountBalance, "
		custsql = custsql & " IsNull(C.email, ' ')email, "
		custsql = custsql & " IsNull(C.paymentTypeName, ' ')paymentTypeName, "
		custsql = custsql & " IsNull(C.totalSales, 0.00)totalSales, "
		custsql = custsql & " IsNull(C.lastVisited, '')lastVisited, "
		custsql = custsql & " IsNull(C.starchPreferenceName, 'None')starchPreferenceName, "
		custsql = custsql & " IsNull(C.finishPreferenceName, 'None')finishPreferenceName, "

		custsql = custsql & " IsNull(CS.name, 'None') customerSourceName, "

		custsql = custsql & " IsNull(R.name, ' ')routeName, "
		custsql = custsql & " IsNull(R.deliveryMon, 0)deliveryMon, "
		custsql = custsql & " IsNull(R.deliveryTue, 0)deliveryTue, "
		custsql = custsql & " IsNull(R.deliveryWed, 0)deliveryWed, "
		custsql = custsql & " IsNull(R.deliveryThu, 0)deliveryThu, "
		custsql = custsql & " IsNull(R.deliveryFri, 0)deliveryFri, "
		custsql = custsql & " IsNull(R.deliverySat, 0)deliverySat, "
		custsql = custsql & " IsNull(R.deliverySun, 0)deliverySun, "
		custsql = custsql & " isnull(T.InvoiceNumber, 0)InvoiceNumber, "
     custsql = custsql & " isnull(T.lastModifiedByEmployeeID, 0)lastModifiedByEmployeeID, "
		custsql = custsql & " T.dateOut "


		custsql = custsql & " FROM TicketCustomer TC RIGHT OUTER JOIN "
		custsql = custsql & " Route R INNER JOIN "
		custsql = custsql & " Customer C ON R.routeNumber = C.routeNumber LEFT OUTER JOIN "
		custsql = custsql & " CustomerSourceDomain CS ON C.customerSourceID = CS.customerSourceID LEFT OUTER JOIN "
		custsql = custsql & " Ticket T ON T.ticketNumber = '" & ticketNo & "' ON TC.ticketNumber = '" & ticketNo & "'"
		custsql = custsql & " WHERE (C.customerSequenceNumber = '" & custSeqNo & "') "

		Set custrs = getDisconnectedRecordset(custsql)

		if custrs is nothing or custrs.EOF then
			' nothing
		else
			custrs.MoveFirst

			visitcount = getVisitCount(custSeqNo)

			if clng(visitcount) <= 3 then
				newcustomer = "New Customer - " & visitcount
			end if


			odc = getOnDemandCouponLines(custSeqNo)

			rackinfo = getPickupRackInfoAsCVS(pickupTickets)
			baldue = getBalanceDueForAllInvoices(pickupTickets)

			'custSeqNo = custrs("customerID").Value
			cid = custrs("customerID").Value
			cfn = ucase(trim(custrs("firstName").Value))
			cln = ucase(trim(custrs("lastName").Value))

			if request.querystring("invoicenumber") <> "" then
				tnum = request.querystring("invoicenumber")
			else
				tnum = custrs("InvoiceNumber").Value
			end if

			totalsales = formatnumber(custrs("totalSales").Value, 2)
			lastvisit = custrs("lastVisited").Value

			barco = convertTNumToBarco("", custrs("InvoiceNumber").Value)
			storebarco = convertTNumToBarco(storeId & ".", custrs("InvoiceNumber").Value)
			barcode = getBarcode(ticketNo, custrs("InvoiceNumber").Value,  PrType = PickupInvoice)

			mpn = custrs("multiPickupCustomerName").Value
			mpl = custrs("multiPickupLocation").Value

			cli = left(cln, 1)
			cfi = left(cfn, 1)

			cname = cln
			cname = AppendWD(", ", cname, cfn)

			cname = pleft(cname, 22, ", ")

			if spref = "" then
				spref = custrs("starchPreferenceName").Value
			end if

			if fpref = "" then
				fpref = custrs("finishPreferenceName").Value
			end if

			cba1 = custrs("billingAddress1").Value
			cba2 = custrs("billingAddress2").Value
			cba3 = custrs("billingAddress3").Value
			bcity = custrs("billingCity").Value
			bstate = custrs("billingState").Value
			bzip = custrs("billingZipCode").Value

			caddress = trim(cba1)
			if caddress <> "" then caddress = caddress & ", "
			caddress = caddress & trim(bcity)
			if caddress <> "" then caddress = caddress & ", "
			caddress = caddress & trim(bstate)
			if caddress <> "" then caddress = caddress & " "
			caddress = caddress & trim(bzip)

			cphone = "(" & custrs("MainAreaCode").Value & ")"
			if len(trim(custrs("MainPhone").Value)) >= 4 then
				cphone = cphone & left(trim(custrs("MainPhone").Value),3) & "-" & right(trim(custrs("MainPhone").Value),len(trim(custrs("MainPhone").Value))-3)
			else
				cphone = cphone & trim(custrs("MainPhone").Value)
			end if

			mainphone = trim(custrs("MainPhone").Value)

			sphone = "(" & custrs("AltAreaCode").Value & ")"
			if len(trim(custrs("AltPhone").Value)) >= 4 then
				sphone = sphone & left(trim(custrs("AltPhone").Value),3) & "-" & right(trim(custrs("AltPhone").Value),len(trim(custrs("AltPhone").Value))-3)
			else
				sphone = sphone & trim(custrs("AltPhone").Value)
			end if

			altphone = trim(custrs("AltPhone").Value)

			sa1 = custrs("shippingAddress1").Value
			sa2 = custrs("shippingAddress2").Value
			sa3	= custrs("shippingAddress3").Value
			scity = custrs("shippingCity").Value
			sstate = custrs("shippingState").Value
			szip = custrs("shippingZipCode").Value



			rnum = custrs("routeNumber").Value 'Route number
			snum = custrs("stopNumber").Value 'Stop number
			tnotes = custrs("invoiceNotes").Value 'Ticket notes

			if clng(rnum) > 0 or lcase(custrs("routeName").Value) <> "none"  then
				rname = custrs("routeName").Value 'Route name
				routename = rname
				rstatus = "Delivery"
				raccount = "ACCOUNT: " & cln
			end if

			cemail = custrs("email").Value

			customersource = custrs("customerSourceName").Value 'Customer source name

			ppref = custrs("paymentTypeName").Value 'Payment Preference
			'abal = FormatNumber(custrs("accountBalance").Value,2,true) ' Account balance
			abal = FormatNumber(getAccountBalance(ticketNo),2,true) ' Account balance

			aonacc = abal 'Amount on Account

			if custrs("permanentAccount").Value = true or custrs("temporaryAccount").Value = true then
				isOnAccountCustomer = true
			end if

			if custrs("deliveryMon").Value = true then
				dday = "Monday, "
			end if
			if custrs("deliveryTue").Value = true then
				dday = dday & "Tuesday, "
			end if
			if custrs("deliveryWed").Value = true then
				dday = dday & "Wednesday, "
			end if
			if custrs("deliveryThu").Value = true then
				dday = dday & "Thursday, "
			end if
			if custrs("deliveryFri").Value = true then
				dday = dday & "Friday, "
			end if
			if custrs("deliverySat").Value = true then
				dday = dday & "Saturday, "
			end if
			if custrs("deliverySun").Value = true then
				dday = dday & "Sunday, "
			end if

      if not isnull(custrs("dateout")) then
      	tratime = FormatDateTime(custrs("dateout"), 3)
      	tradate = FormatDateTime(custrs("dateout"), 2)
      	tradow = ardow(DatePart("w", custrs("dateout"))-1)
      end if

      dim useModifiedEmployeeID
      useModifiedEmployeeID = false

      if employeeId = "" then
      	useModifiedEmployeeID = true
      elseif employeeid <= 0 then
      	useModifiedEmployeeID = true
      end if

      if useModifiedEmployeeID and not isnull(custrs("lastModifiedByEmployeeID")) then
        if custrs("lastModifiedByEmployeeID") > 0 then
          selectEmployee custrs("lastModifiedByEmployeeID")
        end if
      end if

			custrs.Close
			set custrs = nothing
		End If


	'Prepare the variables required
	'Response.Write("Calling Prepare Variables" & nl)
	'Response.End




	if Request.QueryString("FormName") <> "" then
		rtfsql = "SELECT formLayout, type "
		rtfsql = rtfsql & " FROM Form "
		rtfsql = rtfsql & " WHERE formName = '" & Request.QueryString("FormName") & "'"
		rtfsql = rtfsql & " AND storeID = " & storeId
	elseif clng(Request.QueryString("pt")) = CouponList then
		rtfsql = "getprobableondemandcoupons " & custSeqNo
	elseif clng(Request.QueryString("pt")) = ReleaseForm then
		rtfsql = "GetReleaseForTicket " & ticketNo
	else
		rtfsql = "SELECT formLayout, type "
		rtfsql = rtfsql & " FROM Form "
		rtfsql = rtfsql & " WHERE formName = '" & findFormName(Request.QueryString("pid"))
		rtfsql = rtfsql & "' AND storeID = " & storeId
	end if



	'Response.Write( rtfsql & chr(13) & chr(10))
	Dim rtfData, transformedData, formType
	dim rtfResponse
	Dim oVB6
	dim idx
	dim idxx

	set oVB6 = Server.CreateObject("ShahCorpComponents.HelperFunctions")
	Set rtfrs = getDisconnectedRecordset(rtfsql)

    formType = rtfrs("type")



	PrepareVariables clng(Request.QueryString("pt")), formType

	rtfResponse = ""

	if not rtfrs is nothing then
		if rtfrs.recordcount > 0 then

			rtfrs.MoveFirst

			while not rtfrs.EOF

				rtfData = oVB6.ASPStrConv(rtfrs("formLayout").Value, vbUnicode)

				transformedData = TransformRTF(Replace(rtfData, "%40", "@"))

				if len(rtfResponse) > 0 then
					rtfResponse = Left(rtfResponse, len(rtfResponse) - 1) & transformedData
				else
					rtfResponse = transformedData
				end if

				rtfrs.MoveNext
			wend


			idxx = instr(1, rtfresponse, "}")
			idx = idxx

			while idxx > 0
				idx = idxx
				idxx = instr(idxx + 1, rtfresponse, "}")
			wend

			if idx > 0 then
				rtfResponse = left(rtfResponse, idx)

				for idx = 2 to rtfrs.recordcount
					rtfResponse =  rtfResponse & "}"
				next
			end if

		end if
	End If

	if request.querystring("appendcoupons") <> "" then
		rtfsql = "getprobableondemandcoupons " & custSeqNo
		Set rtfrs = getDisconnectedRecordset(rtfsql)
		if rtfrs.recordcount > 0 then
			rtfsql = "AwardCurrentOnDemandCoupons " & custSeqNo
			QryExecute(rtfsql)

			rtfrs.MoveFirst
			dim rtfData2

			while not rtfrs.EOF
				dim f_line_stop

				rtfData2 = oVB6.ASPStrConv(rtfrs("formLayout").Value, vbUnicode)

				transformedData = TransformRTF(Replace(rtfData2, "%40", "@"))

				'f_line_stop = instr(1, transformedData, "\rtf1")
				'if f_line_stop > 0 then
				'	transformedData = mid(transformedData, f_line_stop)
				'end if

                sendPrintRequest transformedData
				rtfrs.MoveNext
			wend
		end if

	end if

	if clng(Request.QueryString("pt")) = CouponList then
		rtfsql = "AwardCurrentOnDemandCoupons " & custSeqNo
		QryExecute(rtfsql)
	end if


    postResponse = sendPrintRequest(rtfData)
    if Request.QueryString("type") = "pdf" then
        Response.Write(postResponse)
    end if

	set rtfrs = nothing
	Response.End



function sendPrintRequest(rtfData)
    Dim data, httpRequest, postResponse, notificationIP, userIPAddress, transformedData, params
	notificationIP = getPrinterShortPath()

    if notificationIP <> "" then
        userIPAddress = getLocalPrinterAddress(terminalId)

        Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")


        if Request.QueryString("type") <> "pdf" then
             dim printerName
             query = "select printerName, u200, u200Type from Printer where printerId = " & Request.QueryString("pid")
             set rs = getdisconnectedrecordset(query)

             if Request.QueryString("overwritePrinter") <> "" then
                printerName = Request.QueryString("overwritePrinter")
             elseif Request.QueryString("mpPrinter") = "" then
                printerName = rs("printerName")
             else
                printerName = replace(Server.HTMLEncode(Request.QueryString("mpPrinter")), "&quot;", "")
            end if

            params = "/text?requestPrinterName=" & replace(Server.HTMLEncode(printerName), "\", "%5C") & "&textType=" & Server.HTMLEncode(formType) _
                & "&driver=" & Server.HTMLEncode(Request.QueryString("driver")) & "&isU200=" & Server.HTMLEncode(rs("u200")) _
                & "&u200Type=" & Server.HTMLEncode(rs("u200Type"))
            transformedData = TransformRTF(Replace(rtfData, "%40", "@"))
            'Need space below because otherwise it breaks other html code characters that use an '&'
            if InStr(formType, "html") <> 0 then
		        transformedData = Replace(transformedData, "& ", "&amp; ")
		    end if
        else
            params = "/pdf?invoiceNum=" & getInvoiceNumber(ticketNo)
            transformedData = TransformRTF(rtfData)
            'Need space below because otherwise it breaks other html code characters that use an '&'
		    transformedData = Replace(transformedData, "& ", "&amp; ")
            userIPAddress = Replace(getAddressPath("mainapp"), "http://", "")
        end if

           if Request.QueryString("UID") <> "" then
                params = params & "&UID=" & Request.QueryString("UID")
           end if
           if Request.QueryString("last") <> "" then
                params = params & "&last=1"
           end if

        httpRequest.Open "POST", "http://" & userIPAddress & notificationIP & params, false
        httpRequest.SetRequestHeader "Content-Type", "text/plain"
        httpRequest.Send transformedData
        postResponse = httpRequest.ResponseText


    end if

    sendPrintRequest = postResponse

end function


	function pleft(cname, maxLen, preferedCut)
		dim cutLoc
		if clng(len(cname)) > clng(maxLen) then
			cutLoc = instr(cname, preferedCut) - 1
			if cutLoc < 0 or clng(maxLen) < clng(cutLoc) then cutLoc = maxLen
			cname = left(cname, cutLoc)
		end if
		pleft = cname
	end function

	Const ALIGN_LEFT = 0
	Const ALIGN_CENTER = 1
	Const ALIGN_RIGHT = 2

	Function Pad(arg, length, align)
		dim ret
		dim cntSpace

		if arg = "" then
			ret = ""

		elseif len(arg) > length then
			ret = left(arg, length)
		else
			select case align
				case ALIGN_LEFT
					ret = arg & space(length-len(arg))
				case ALIGN_CENTER
					cntSpace = length-len(arg)
					ret = space(clng(cntSpace / 2)) & arg & space(clng(cntSpace / 2) + cntSpace mod 2)
				case ALIGN_RIGHT
					ret = space(length- len(arg)) & arg
			end select
		end if

		Pad = ret
	End Function

	function getVisitCount(custSeqNo)
		dim query, rs

		getVisitCount = 0

		if custSeqNo <> "" then
			query = " select dbo.getCustomerVisits(" & custSeqNo & ", null, null) as visitCount "
			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				getVisitCount = rs("visitCount")
			end if

			set rs = nothing
		end if
	end function

	Function PrepareVariables(ptype, formType)

		Select Case ptype
			Case QuickInvoice
				PrepareVariablesForQuickInvoice formType
				'CreateLotDetails
			Case DetailedInvoice
				PrepareVariablesForDetailedInvoice formType
				'CreateLotDetails
			Case ReleaseForm
				PrepareVariablesForDetailedInvoice formType
			Case EditInvoice
				PrepareVariablesForEditInvoice EdInvType, formType
				'CreateLotDetails
			Case PickupInvoice
				PrepareVariablesForPickupInvoice formType
				'CreateLotDetails
				CreateSignatureForTicket pickupTickets
			Case RackSlip
				PrepareVariablesForPickupInvoice formType
				CreateRackDetails
			Case Tag1, Tag2
				PrepareVariablesForTag
			Case HeatSeal
				PrepareVariablesForHeatSeal
			Case CounterSales
				PrepareVariablesForCounterSales formType
			Case CreditReceipt
				PrepareVariablesForCreditReceipt formType
			Case CouponList
				PrepareVariablesForCouponList
		End Select
		createCurrentInvoices
	End Function

	Function PrepareVariablesForQuickInvoice(formType)
		dim deptLine
		'Use InvoiceObject to get the information required.
		If Not IsEmpty(InvoiceObject) And Not InvoiceObject Is Nothing then

			if request.querystring("invoicenumber") <> "" then
				tnum = request.querystring("invoicenumber")
			else
				tnum = InvoiceObject.invoiceNo
			end if

			barco = convertTNumToBarco("", InvoiceObject.invoiceNo)
			storebarco = convertTNumToBarco(storeId & ".", InvoiceObject.invoiceNo)
			'Mwiemann 9-18-2003 removed comment on following line to allow to be printed for quick
			ptable = getPriceListName(InvoiceObject.priceListId)
			deptname = getDeparmentNamesAsCSV(ticketNo)
			deptinitals = convertDeptNameToInitial(deptname)
			spref = InvoiceObject.starchPref
			fpref = InvoiceObject.finishPref
			itemcoun = InvoiceObject.getTotalItemCount()
			credate = InvoiceObject.createdDate
			creemp = getEmployeeNameByID(InvoiceObject.createdByEmployeeId)
			creempln = getEmployeeLastnameByID(InvoiceObject.createdByEmployeeId)
			creempfn = getEmployeeFirstnameByID(InvoiceObject.createdByEmployeeId)

			'mpn = InvoiceObject.multiPickUpCustName
			'mpl = InvoiceObject.multiPickUpLoc

			ticrdtime = InvoiceObject.ticketReadyTime
			ticrddate = ExtractDate(InvoiceObject.InvDueDate)
			ticrddow = ardow(DatePart("w", cdate(InvoiceObject.InvDueDate))-1)
			ticrddowa = left(ticrddow, 3)

			if isnull(ticrdtime) then ticrdtime = ""

			subtot = "0.00"
			total = "0.00"

			dim lines
			set lines = InvoiceObject.lineItems 'Recordset

            if InStr(formType, "html") > 0 then
                htmlFormatLineDetails lines, lines.clone()

                'get Single Line Item Details
                htmlFormatSingleLineDetails lines

                htmlFormatGroupDetails InvoiceObject, lines, lines.clone()
            else
                rtfFormatLineDetails lines, lines.clone()

                'get Single Line Item Details
                rtfFormatSingleLineDetails lines

                rtfFormatGroupDetails2 InvoiceObject, lines, lines.clone()
            end if
			rtfFormatDueDates lines
		End If
		'lidwt = slidwt
		'lidwot = slidwot

	End Function

	Sub PrepareVariablesForDetailedInvoice(formType)
		on error resume next


		if request.querystring("invoicenumber") <> "" then
			tnum = request.querystring("invoicenumber")
		else
			tnum = InvoiceObject.invoiceNo
		end if

		barco = convertTNumToBarco("", InvoiceObject.invoiceNo)
		storebarco = convertTNumToBarco(storeId & ".", InvoiceObject.invoiceNo)
		tagnum = getTagsAndHeatSealsAsCSV(ticketNo)
		ptable = getPriceListName(InvoiceObject.priceListId)
		deptname = getDeparmentNamesAsCSV(ticketNo)
		deptinitals = convertDeptNameToInitial(deptname)


    if InvoiceObject.starchPref <> "" then spref = InvoiceObject.starchPref
		if InvoiceObject.finishPref <> "" then fpref = InvoiceObject.finishPref

		itemcoun = getItemCount(ticketNo)
		credate = InvoiceObject.createdDate
		creemp = getEmployeeNameByID(InvoiceObject.createdByEmployeeId)
		creempln = getEmployeeLastnameByID(InvoiceObject.createdByEmployeeId)
		creempfn = getEmployeeFirstnameByID(InvoiceObject.createdByEmployeeId)

		ticrdtime = InvoiceObject.ticketReadyTime
		ticrddate = ExtractDate(InvoiceObject.InvDueDate)
		ticrddow = ardow(DatePart("w", cdate(InvoiceObject.InvDueDate))-1)
        ticrddowa = left(ticrddow, 3)

		mpn = InvoiceObject.multiPickUpCustName
        mpl = InvoiceObject.multiPickUpLoc

		subtot = FormatNumber(InvoiceObject.getInvoiceSubTotal(),2,true)
		total = FormatNumber(InvoiceObject.invoiceTotal,2,true)
		prepaydiscount = FormatNumber(invoiceobject.totalPrepayAmount, 2, true)

		if InvoiceObject.netTotal < 0.0 then
			InvoiceObject.netTotal = 0.0
		end if
		prePayDiscount = InvoiceObject.invoiceTotal - InvoiceObject.netTotal

		getPaymentDetails ticketNo, "pr", InvoiceObject.invoiceTotal, InvoiceObject

		getWillCall ticketNo

		'Lineitem details in an invoice object
		'    lineNumber					'    prepay
		'    parentLineNumber			'    taxableAmt
		'    deptId						'    daysToProcess
		'    deptName					'    notes
		'    itemType					'    balance
		'    lineItemId					'    upchargeTotal
		'    itemName					'    colorTotal
		'    originalUnitPrice			'    patternTotal
		'    unitPrice					'    discountable
		'    quantity					'    couponable
		'    lineItemTotal				'    VIPDiscountable
		'    totalTax					'    VIPQualified
		'    totalSurcharge				'    parentId
										'    saleOnly
										'    chargeTaxCode

	'	rtfFormatGroupDetails InvoiceObject


		dim lines, cloneRst
		set cloneRst = Server.CreateObject("ADODB.Recordset")
		cloneRst.CursorLocation = adUseClient
		set lines = InvoiceObject.lineItems 'Recordset
		set cloneRst = lines.Clone()

		if not lines is nothing then
			'First get the coupons
			rtfFormatCouponDetails lines

			'get the tax
			rtfFormatTaxDetails lines

			'get the Surcharge
			rtfFormatSurchargeDetails lines

			lines.Filter = ""
		end if

		'Response.Write("InvoiceObject.lineItems is type of " & typename(lines) & nl)


		if not lines is nothing then
			'get Line Item Details


			if InStr(formType, "html") > 0 then
                htmlFormatLineDetails lines, cloneRst

                'get Single Line Item Details
                htmlFormatSingleLineDetails lines

                htmlFormatGroupDetails InvoiceObject, lines, cloneRst
            else
                rtfFormatLineDetails lines, cloneRst

                'get Single Line Item Details
                rtfFormatSingleLineDetails lines

                rtfFormatGroupDetails2 InvoiceObject, lines, cloneRst
            end if


			rtfFormatDueDates lines
		else
			'Response.Write("ERROR:LineItems are empty")
		end if


		totpts = CDbl(total) - CDbl(sc1) - CDbl(sc2) - CDbl(taxTot)
		totptsc = FormatNumber(Cdbl(totpts) + Cdbl(getDiscountTotal(lines)), 2, true)
		totpts = FormatNumber(totpts, 2, true)


		totpt = CDbl(total) - CDbl(taxTot)
		totpt = FormatNumber(totpt, 2, true)

		totps = CDbl(total) - CDbl(sc1) - CDbl(sc2)
		totps = FormatNumber(totps, 2, true)

		set cloneRst = nothing
		set lines=nothing
	End Sub

	Function PrepareVariablesForEditInvoice(eit, formType)
		'Use InvoiceObject to get the information required.
		if eit = EDIT_INVOICE_DETAILED then
			PrepareVariablesForDetailedInvoice formType
		elseif eit = EDIT_INVOICE_QUICK then
			PrepareVariablesForQuickInvoice formType
		end if
	End Function

	Function PrepareVariablesForCounterSales(formType)
		'Counter sales invoice is treated as detaile invoice
		PrepareVariablesForDetailedInvoice formType
	End Function


	Function PrepareVariablesForPickupInvoice(formType)
		'Use PickupObject to get the information required.

		if request.querystring("invoicenumber") <> "" then
			tnum = request.querystring("invoicenumber")
		else
			tnum = getPickupInvoicesAsCSV(pickupTickets)
		end if


		barco = convertTNumToBarco("", getPickupInvoicesAsCSV(pickupTickets))
		storebarco = convertTNumToBarco(storeId & ".", getPickupInvoicesAsCSV(pickupTickets))
		tagnum = getTagsAndHeatSealsAsCSV(pickupTickets)
		ptable = getPickupPriceListNamesAsCSV(pickupTickets)
		deptname = getPickupDeparmentNamesAsCSV(pickupTickets)
		deptinitals = convertDeptNameToInitial(deptname)
		spref = getPickupStarchPrefAsCSV(pickupTickets)
		fpref = getPickupFinishPrefAsCSV(pickupTickets)
		itemcoun = PickupObject.getTotalItemCount()
		creemp = getEmployeeNameByID(getPickupCreEmpAsCSV(pickupTickets))
		creempln = getEmployeeLastnameByID(getPickupCreEmpAsCSV(pickupTickets))
		creempfn = getEmployeeFirstnameByID(getPickupCreEmpAsCSV(pickupTickets))

		credate = getPickupCreDate(pickupTickets)
		ticrddate = ExtractDate(getPickupDueDate(pickupTickets))
		ticrdtime = getPickupPickupTime(pickupTickets)
		ticrddow = ardow(DatePart("w", cdate(ticrddate))-1)
        ticrddowa = left(ticrddow, 3)


		subtot = FormatNumber(PickupObject.getSubtotal(),2,true)
		total = FormatNumber(PickupObject.getTotal(),2,true)
		prePayDiscount = 0

		dim ticketNumber
		for each ticketNumber in split(pickupTickets, ",")
			getPaymentDetails ticketNumber, "pi", PickupObject.getTotal(), PickupObject
		next

		getWillCall pickupTickets

	'	rtfFormatGroupDetails PickupObject

		dim lines, cloneRst
		set lines = Server.CreateObject("ADODB.Recordset")
		set cloneRst = Server.CreateObject("ADODB.Recordset")
		cloneRst.CursorLocation = adUseClient
		set lines = PickupObject.displayRst 'Recordset
		set cloneRst = lines.Clone()
		'Response.Write("PickupObject.lineItems is type of " & typename(lines) & nl)

		if not lines is nothing then
			'First get the coupons
			rtfFormatCouponDetails lines

			'get the tax
			rtfFormatTaxDetails lines

			'get the Surcharge
			rtfFormatSurchargeDetails lines

			lines.Filter = ""
		end if

		if not lines is nothing then
			'get Line Item Details
            if InStr(formType, "html") > 0 then
                htmlFormatLineDetails lines, cloneRst

                'get Single Line Item Details
                htmlFormatSingleLineDetails lines

                htmlFormatGroupDetails PickupObject, lines, cloneRst
            else
                rtfFormatLineDetails lines, cloneRst

                'get Single Line Item Details
                rtfFormatSingleLineDetails lines

                rtfFormatGroupDetails2 PickupObject, lines, cloneRst
            end if
			rtfFormatDueDates lines
		else
			'Response.Write("ERROR:LineItems are empty")
		end if

		totpts = CDbl(total) - CDbl(sc1) - CDbl(sc2) - CDbl(taxTot)
		totptsc = FormatNumber(Cdbl(totpts) + Cdbl(getDiscountTotal(lines)), 2, true)
		totpts = FormatNumber(totpts, 2, true)


		totpt = CDbl(total) - CDbl(taxTot)
		totpt = FormatNumber(totpt, 2, true)

		totps = CDbl(total) - CDbl(sc1) - CDbl(sc2)
		totps = FormatNumber(totps, 2, true)

		set cloneRst = nothing
		set lines=nothing

	End Function

	function getStorePrefix(storeID)
		dim query, rs

		query = " select ticketprefix from store where ticketprefix is not null and ticketprefix <> '' and storeid = " & storeID
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getStorePrefix = rs("ticketprefix")
		end if

		set rs = nothing
	end function

	function getBarcode(ticketNumber, invoiceNumber, isCustomerCopy)
		dim encoder
		dim cstart
		dim cend
    dim csects
    dim i

		set encoder = new BarcodeEncoder

		encoder.TicketNumber = ticketNumber
		encoder.InvoiceNumber = invoiceNumber
		encoder.Store = getStorePrefix(storeID)
    encoder.IsCustomerCopy = isCustomerCopy

		cstart = "{\info {\comment barcode}}"
		cend = "{\info {\comment barcode}}"

		csects = split(ticketNumber, ",")
		for i = lbound(csects) to ubound(csects)
		  if getBarcode <> "" then getBarcode = getBarcode & " \par" & nl
		  getBarcode = getBarcode & cstart & encode_code128_rtf(encoder.GetBarcodeText()) & cend
		next

	end function

	function getMSVar(id)
		dim query, rs
		on error resume next

		query = "select " & id & " from miscsetup where storeid = " & storeId
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

	'Following modified by J.Johnston, 18Dec03
	Function PrepareVariablesForCreditReceipt(formType)
		'Use PickupObject to get the information required.
		dim sqltxt
		dim rsCreditTypes
		dim creditCardTypes

		ccCardType = cctype

		if request.querystring("invoicenumber") <> "" then
			tnum = request.querystring("invoicenumber")
		else
			tnum = getPickupInvoicesAsCSV(pickupTickets)
		end if


		barco = convertTNumToBarco("", getPickupInvoicesAsCSV(pickupTickets))
		storebarco = convertTNumToBarco(storeId & ".", getPickupInvoicesAsCSV(pickupTickets))
		tagnum = getTagsAndHeatSealsAsCSV(pickupTickets)
		ptable = getPickupPriceListNamesAsCSV(pickupTickets)
		deptname = getPickupDeparmentNamesAsCSV(pickupTickets)
		deptinitals = convertDeptNameToInitial(deptname)
		spref = getPickupStarchPrefAsCSV(pickupTickets)
		fpref = getPickupFinishPrefAsCSV(pickupTickets)
		itemcoun = PickupObject.getTotalItemCount()
		creemp = getEmployeeNameByID(getPickupCreEmpAsCSV(pickupTickets))
		creempln = getEmployeeLastnameByID(getPickupCreEmpAsCSV(pickupTickets))
		creempfn = getEmployeeFirstnameByID(getPickupCreEmpAsCSV(pickupTickets))

		subtot = FormatNumber(PickupObject.getSubtotal(),2,true)
		total = FormatNumber(PickupObject.getTotal,2,true)
		prePayDiscount = 0

		ccCardType = cctype

		'getPaymentDetails ticketNo, "pi", PickupObject.invoicesTotal, PickupObject

		'rtfFormatGroupDetails PickupObject

		dim lines, cloneRst
		set lines = Server.CreateObject("ADODB.Recordset")
		set cloneRst = Server.CreateObject("ADODB.Recordset")

		set lines = PickupObject.displayRst 'Recordset

		set cloneRst = lines.Clone()
		'Response.Write("PickupObject.lineItems is type of " & typename(lines) & nl)

		if not lines is nothing then
			'First get the coupons
			rtfFormatCouponDetails lines

			'get the tax
			rtfFormatTaxDetails lines

			'get the Surcharge
			rtfFormatSurchargeDetails lines

			lines.Filter = ""
		end if

		if not lines is nothing then

            if InStr(formType, "html") > 0 then
                'get Line Item Details
                htmlFormatLineDetails lines, cloneRst

                'get Single Line Item Details
                htmlFormatSingleLineDetails lines

                htmlFormatGroupDetails PickupObject, lines, cloneRst
            else
                'get Line Item Details
                rtfFormatLineDetails lines, cloneRst

                'get Single Line Item Details
                rtfFormatSingleLineDetails lines

                rtfFormatGroupDetails2 PickupObject, lines, cloneRst
            end if
			rtfFormatDueDates lines
		else
			'Response.Write("ERROR:LineItems are empty")
		end if
		set cloneRst = nothing
		set lines=nothing

	End Function
	'End modification, 18Dec03


	function PrepareVariablesForCouponList()


	end function


	Function PrepareVariablesForHeatSeal()
		'Heat seal is treated as Tag
		PrepareVariablesForTag
		tagNum = hSeal
	End Function

	Function PrepareVariablesForTag()
		on error resume next
		getDetailsForTagPrinting
		tagnum = tagNo
		tagcolor = getColorForTag(ticketNo, tagNo)
		lotnum = getLotForTag(ticketNo, tagNo)
		lotname = getLotNameForTag(ticketNo, tagNo)
		itemcoun = getItemCount(ticketNo)
		deptname = getDeparmentNamesAsCSV(ticketNo)
		deptinitals = convertDeptNameToInitial(deptname)

		getStoreInfo storeId

		'Use this function after implementing Tag-Department relationship
		'deptname = getDeparmentNameForTag(ticketNo, tagNo)


		'itemnumber = ???
		'itemname = ???

	End Function

	function getLotForTag(ticket, tag)
		dim query, rs

		query = "select lotnumber from tickettag where tagcolor is not null and ticketnumber = " & ticket & " and tagnumber = " & tag
		set rs = getdisconnectedrecordset(query)

		getLotForTag = ""

		if rs.recordcount > 0 then
			getLotForTag = trim(rs("lotnumber"))
		end if

		set rs = nothing
	end function

	function getColorForTag(ticket, tag)
		dim query, rs

		query = "select tagcolor from tickettag where tagcolor is not null and ticketnumber = " & ticket & " and tagnumber = " & tag
		set rs = getdisconnectedrecordset(query)

		getColorForTag = ""

		if rs.recordcount > 0 then
			getColorForTag = trim(rs("tagcolor"))
		end if

		set rs = nothing
	end function

	function getLotNameForTag(ticket, tag)
		dim query, rs

		query = "select isnull(name, 'Unknown') as lotname from tickettag left outer join lot on tickettag.lotid = lot.id "
		query = query & " where tagcolor is not null and ticketnumber = " & ticket & " and tagnumber = " & tag

		set rs = getdisconnectedrecordset(query)

		getLotNameForTag = ""

		if rs.recordcount > 0 then
			getLotNameForTag = trim(rs("lotname"))
		end if

		set rs = nothing
	end function

	function getTagsWithColorsAsCSV(pickupTickets)
		'Function to get Tags CSV List of  Pickup given the TicketNumber CSV
		Dim pickupTagsSql
		Dim pickupTagsRst
		Dim pickupTagsCSV

		pickupTagsSql = "SELECT tagNumber, isnull(tagcolor, '') as tagcolor FROM TicketTag WHERE ticketNumber IN (" & pickupTickets & ") "

		set pickupTagsRst = getDisconnectedRecordset(pickupTagsSql)

		if pickupTagsRst.RecordCount > 0 then

			pickupTagsRst.MoveFirst
			pickupTagsCSV = pickupTagsRst.Fields("tagNumber").Value
			if trim(pickupTagsRst.Fields("tagcolor").Value) <> "" then
				pickupTagsCSV = pickupTagsCSV & " (" & trim(pickupTagsRst.Fields("tagcolor").Value) & ")"
			end if
			pickupTagsRst.MoveNext

			while Not pickupTagsRst.EOF
				pickupTagsCSV = pickupTagsCSV & ", " & pickupTagsRst.Fields("tagNumber").Value
				if trim(pickupTagsRst.Fields("tagcolor").Value) <> "" then
					pickupTagsCSV = pickupTagsCSV & " (" & trim(pickupTagsRst.Fields("tagcolor").Value) & ")"
				end if
				pickupTagsRst.MoveNext
			Wend
		end if
		getPickupTagsAndHeatSealsAsCSV = pickupTagsCSV

	end function

	private function rtf_encode_ch(n)
		dim alphabit
		dim result
		const base = 16

		if n = "" then
			exit function
		end if

		alphabit = "0123456789abcdef"

		while n > 0
			result = mid(alphabit, (n mod base) + 1, 1) & result
			n = n \ base
		wend

		if len(result) = 1 then result = "0" + result

		rtf_encode_ch = "\'" & result
	end function

	function encode_code128(dest, text)
		dim i
		dim ch
		dim check
		const offset = 32
		const offset_high = 18

		redim dest(len(text) + 2)

		dest(0) = 154

		check = 104

		for i = 1 to len(text)
			ch = asc(mid(text, i, 1))
			check = check + (ch - offset) * i
			if ch = 32 then ch = 128
			dest(i) = ch
		next

		check = check mod 103

		if check + offset >= 127 then
			check = check + offset + offset_high
		else
			check = check + offset
		end if

		if check = 32 then check = 128

		dest(i) = check
		dest(i + 1) = 156
	end function


	function encode_code128_rtf(txt)
		dim i
		dim encoded()
		dim result

		encode_code128 encoded, txt

		result = ""

		for i = lbound(encoded) to ubound(encoded)
			result = result & rtf_encode_ch(encoded(i))
		next

		encode_code128_rtf = result

	end function

	function stripDepartmentBlocks(ticketNumbers, rtf)
		dim pos
		dim bstart
		dim bend
		dim deptName
		dim endTag
		dim startTag
		dim result
		dim stringAltered

		result = rtf
		pos = 1

		while pos > 0
			stringAltered = false
			bstart = instr(pos, result, "[")


			if bstart > 0 then
				bend = instr(bstart, result, "]")

				if bend > 0 then
					deptName = mid(result, bstart + 1, bend - bstart - 1)

					startTag = "[" & deptName & "]"
					endTag = "[/" + deptName + "]"

					bend = instr(bend + 1, result, endTag)



					if bend > 0 then
						if isDepartmentInTickets(ticketNumbers, deptName) or (deptName = "@AccountCredit" and abal < 0) _
						   or (left(deptName, 1) = "!" and not isDepartmentInTickets(ticketNumbers, right(deptName, len(deptName) - 1))) _
						then
							result = left(result, bstart - 1) & mid(result, bstart + len(startTag), bend - (bstart + len(startTag))) & right(result, len(result) - bend - len(endTag) + 1)

						else
							result = left(result, bstart - 1)  & right(result, len(result) - bend - len(endTag) + 1)
						end if

						pos = bstart
					else
						pos = pos + 1
					end if
				else
					pos = pos + 1
				end if
			else
				pos = 0
			end if

		wend

		stripDepartmentBlocks = result
	end function

	function replaceCustomerPreferences(custSeqNo, ticketNumber, rtf)
		dim query, rs
		dim result

		result = rtf

		if custSeqNo <> "" then

			query = " select customerpreferencetype.formlabel, isnull(case customerpreference.value when '' then null else customerpreference.value end, isnull(customerpreferencetype.[default], '')) as value "
			query = query & " from customerpreferencetype left outer join customerpreference "
			query = query & " on customerpreferencetype.customerpreferencetypeid = customerpreference.customerpreferencetypeid "
			query = query & " and customerpreference.customersequencenumber = " & custSeqNo

			if clng(ticketNumber) > 0 then
				query = query & " and ticketnumber = " & ticketNumber
			else
				query = query & " and ticketnumber is null "
			end if

			query = query & " where len(customerpreferencetype.formlabel) > 0 "


			set rs = getdisconnectedrecordset(query)

			while not(rs.eof or rs.bof)
				result = replace(result, "@@@" & ucase(rs("formlabel")), rs("value"))
				rs.movenext
			wend

			set rs = nothing
		end if

		replaceCustomerPreferences = result
	end function

	Function TransformRTF(rtf)
		dim returnRTF
		'Response.Write("Original RTF is " & nl)
		'Response.Write(rtf)
		'Response.Write(nl & nl & nl)

		returnRTF = rtf


		returnRTF = Replace(returnRTF, "[barcode]", barcode)
        returnRTF = Replace(returnRTF, "@@@BARCODE128", barcode)

		if Request.QueryString("pickup") <> "" then
			returnRTF = stripDepartmentBlocks(Request.QueryString("pickup"), returnRTF)
		elseif Request.QueryString("key") <> "" then
			returnRTF = stripDepartmentBlocks(Request.QueryString("key"), returnRTF)
		end if

		returnRTF = replaceCustomerPreferences(custSeqNo, Request.QueryString("key"), returnRTF)


		returnRTF = Replace(returnRTF, "@@@RACCOUNT", raccount)

		if isOnAccountCustomer then
			returnRTF = Replace(returnRTF, "@@@CHARGE", "CHARGE")
			returnRTF = Replace(returnRTF, "@@@ACCOUNT", "ACCOUNT: " & cln)
		else
			returnRTF = Replace(returnRTF, "@@@CHARGE", "")
			returnRTF = Replace(returnRTF, "@@@ACCOUNT", "")
		end if

		returnRTF = Replace(returnRTF, "@@@LOTHS", left(lotname, 1) & right(storenumber, 1) & right("00" & lotnum, 2) & right("00" & tagnum, 2))

		returnRTF = Replace(returnRTF, "@@@STORENAME", storename)
		returnRTF = Replace(returnRTF, "@@@STOREADDRESS1", storeaddress1)
		returnRTF = Replace(returnRTF, "@@@STOREADDRESS2", storeaddress2)
		returnRTF = Replace(returnRTF, "@@@STORECITY", storecity)
		returnRTF = Replace(returnRTF, "@@@STORESTATE", storestate)
		returnRTF = Replace(returnRTF, "@@@STOREZIP", storezip)
		returnRTF = Replace(returnRTF, "@@@STOREPHONE", storephone)
		returnRTF = Replace(returnRTF, "@@@STOREAREACODE", storeareacode)
		returnRTF = Replace(returnRTF, "@@@STOREWEBSITE", storewebsite)
		returnRTF = Replace(returnRTF, "@@@STOREEMAIL", storeemail)





		returnRTF = Replace(returnRTF, "@@@TNUM128", encode_code128_rtf(tnum))

		returnRTF = Replace(returnRTF, "@@@MAINPHONE128", encode_code128_rtf(mainphone))

		returnRTF = Replace(returnRTF, "@@@ITEMCOUNT~L4", Pad(trim(itemcoun), 4, ALIGN_LEFT))
		returnRTF = Replace(returnRTF, "@@@TNUM~C14",  Pad(trim(tnum), 14, ALIGN_CENTER))
		returnRTF = Replace(returnRTF, "@@@TNUM~L8",  Pad(trim(tnum), 8, ALIGN_LEFT))
		returnRTF = Replace(returnRTF, "@@@CNAME", cname)
		returnRTF = Replace(returnRTF, "@@@CADDRESS", caddress)
		returnRTF = Replace(returnRTF, "@@@CPHONE~L16", Pad(trim(cphone), 16, ALIGN_LEFT))
		returnRTF = Replace(returnRTF, "@@@PAYTYP~L12", Pad(trim(paytyp), 12, ALIGN_LEFT))
		returnRTF = Replace(returnRTF, "@@@DATETIME", Now())
		returnRTF = Replace(returnRTF, "@@@ENAME", efn)
		returnRTF = Replace(returnRTF, "@@@ITEMCOUNT~R3",  Pad(trim(itemcoun), 3, ALIGN_RIGHT))
		returnRTF = Replace(returnRTF, "@@@TOTAL~R8", Pad(trim(total), 8, ALIGN_RIGHT))
		returnRTF = Replace(returnRTF, "@@@TOTPAY~R8", Pad(trim(totpay), 8, ALIGN_RIGHT))
		returnRTF = Replace(returnRTF, "@@@TNUM1", tnum1)
		returnRTF = Replace(returnRTF, "@@@MAINPHONE~R2", Pad(right(trim(mainphone), 2), 2, ALIGN_RIGHT))
		returnRTF = Replace(returnRTF, "@@@CLN~15", left(cln, 15))

		returnRTF = Replace(returnRTF, "@@@COUP", coup)

		returnRTF = Replace(returnRTF, "@@@DISCOUNTAMT", discountamt)

		returnRTF = Replace(returnRTF, "@@@RACKDETAILS", rackdetails)
		returnRTF = Replace(returnRTF, "@@@RACKSUMMARY", racksummary)
		returnRTF = Replace(returnRTF, "@@@LOTDETAILS", lotdetails)

		'added by steve gagnon
		returnRTF = Replace(returnRTF, "@@@GDWUWOT", gdwuwot)
		returnRTF = Replace(returnRTF, "@@@GDWCP80", gdwcp80)
		returnRTF = Replace(returnRTF, "@@@GDWOCP80", gdwocp80)
		returnRTF = Replace(returnRTF, "@@@GDWU80", gdwu80)
		returnRTF = Replace(returnRTF, "@@@GDWOU80", gdwou80)
		returnRTF = Replace(returnRTF, "@@@LIDWOT80", lidwot80)
		returnRTF = Replace(returnRTF, "@@@LIDWT80", lidwt80)

		returnRTF = Replace(returnRTF, "@@@EMAIL", cemail)

		returnRTF = Replace(returnRTF, "@@@CURRENTINVOICES", currentinvoices)

		returnRTF = Replace(returnRTF, "@@@SIGNATURE", signature)

		'added by steve gagnon
		returnRTF = Replace(returnRTF, "@@@ITEMNAME", itemname)
		returnRTF = Replace(returnRTF, "@@@ITEMNUMBER", itemnumber)

		'added by steve gagnon
		returnRTF = Replace(returnRTF, "@@@SUBTOTWS", subtotws)

		returnRTF = Replace(returnRTF, "@@@TOTMTSC", totptsc)
		returnRTF = Replace(returnRTF, "@@@TOTPTSC", totptsc)
		returnRTF = Replace(returnRTF, "@@@TOTPTS", totpts)
		returnRTF = Replace(returnRTF, "@@@TOTPS", totps)
		returnRTF = Replace(returnRTF, "@@@TOTPT", totpt)
		returnRTF = Replace(returnRTF, "@@@TOTMTS", totpts)
		returnRTF = Replace(returnRTF, "@@@TOTMS", totps)
		returnRTF = Replace(returnRTF, "@@@TOTMT", totpt)

		returnRTF = Replace(returnRTF, "@@@TICRDDOWA", ticrddowa)

		returnRTF = Replace(returnRTF, "@@@CUSTOMERSOURCE", customersource)

		returnRTF = Replace(returnRTF, "@@@RACKINFO", rackinfo)

		returnRTF = Replace(returnRTF, "@@@GDWUNG80", gdwung80)
		returnRTF = Replace(returnRTF, "@@@GDWUNG", gdwung)

		returnRTF = Replace(returnRTF, "@@@TOTALSALES", totalsales)


		returnRTF = Replace(returnRTF, "@@@VISITCOUNT", visitcount)
		returnRTF = Replace(returnRTF, "@@@LASTVISIT", lastVisit)
		returnRTF = Replace(returnRTF, "@@@NEWCUSTOMER", newcustomer)


		returnRTF = Replace(returnRTF, "@@@PREPAYDISCOUNT", formatnumber(prepaydiscount, 2))

		returnRTF = Replace(returnRTF, "@@@ZGDWU", zgdwu)
		returnRTF = Replace(returnRTF, "@@@WGDWU", wgdwu)

		returnRTF = Replace(returnRTF, "@@@USPREF", ucase(spref))
		returnRTF = Replace(returnRTF, "@@@UFPREF", ucase(fpref))

		returnRTF = Replace(returnRTF, "@@@ODC", odc)
		returnRTF = Replace(returnRTF, "@@@CREEMPLN", creempln)
		returnRTF = Replace(returnRTF, "@@@CREEMPFN", creempfn)

		returnRTF = Replace(returnRTF, "@@@LOTNUM", lotnum)
		returnRTF = Replace(returnRTF, "@@@TAGCOLOR", tagcolor)

		returnRTF = Replace(returnRTF, "@@@GDWUND", gdwund)
		returnRTF = Replace(returnRTF, "@@@DUEDATES", duedates)

		returnRTF = Replace(returnRTF, "@@@ROUTENAME", routename)

		returnRTF = Replace(returnRTF, "@@@GDDO", gddo)



		returnRTF = Replace(returnRTF, "@@@LIDWOT", lidwot)
		returnRTF = Replace(returnRTF, "@@@LIDWT", lidwt)
		returnRTF = Replace(returnRTF, "@@@SLIDWOT", slidwot)
		returnRTF = Replace(returnRTF, "@@@SLIDWT", slidwt)
		returnRTF = Replace(returnRTF, "@@@GDWCP", gdwcp)
		returnRTF = Replace(returnRTF, "@@@GDWOCP", gdwocp)
		returnRTF = Replace(returnRTF, "@@@GDWU", gdwu)
		returnRTF = Replace(returnRTF, "@@@GDWOU", gdwou)
		returnRTF = Replace(returnRTF, "@@@CFN", cfn)
		returnRTF = Replace(returnRTF, "@@@CLN", cln)
		returnRTF = Replace(returnRTF, "@@@CID", cid)
		returnRTF = Replace(returnRTF, "@@@CFI", cfi)
		returnRTF = Replace(returnRTF, "@@@CLI", cli)
		returnRTF = Replace(returnRTF, "@@@MPN", mpn)
		returnRTF = Replace(returnRTF, "@@@MPL", mpl)
		returnRTF = Replace(returnRTF, "@@@CPHONE", cphone)
		returnRTF = Replace(returnRTF, "@@@MAINPHONE", mainphone)
		returnRTF = Replace(returnRTF, "@@@ALTPHONE", altphone)
		returnRTF = Replace(returnRTF, "@@@CBA1", cba1)
		returnRTF = Replace(returnRTF, "@@@CBA2", cba2)
		returnRTF = Replace(returnRTF, "@@@CBA3", cba3)
		returnRTF = Replace(returnRTF, "@@@BCITY", bcity)
		returnRTF = Replace(returnRTF, "@@@BZIP", bzip)
		returnRTF = Replace(returnRTF, "@@@BSTATE", bstate)
		returnRTF = Replace(returnRTF, "@@@SPHONE", sphone)
		returnRTF = Replace(returnRTF, "@@@SA1", sa1)
		returnRTF = Replace(returnRTF, "@@@SA2", sa2)
		returnRTF = Replace(returnRTF, "@@@SA3", sa3)
		returnRTF = Replace(returnRTF, "@@@SCITY", scity)
		returnRTF = Replace(returnRTF, "@@@SSTATE", sstate)
		returnRTF = Replace(returnRTF, "@@@SZIP", szip)
		returnRTF = Replace(returnRTF, "@@@TNOTES", tnotes)
		returnRTF = Replace(returnRTF, "@@@SPREF", spref)
		returnRTF = Replace(returnRTF, "@@@FPREF", fpref)
		returnRTF = Replace(returnRTF, "@@@RNUM", rnum)
		returnRTF = Replace(returnRTF, "@@@RNAME", rname)
		returnRTF = Replace(returnRTF, "@@@RSTATUS", rstatus)

		returnRTF = Replace(returnRTF, "@@@SNUM", snum)
		returnRTF = Replace(returnRTF, "@@@DDAY", dday)
		returnRTF = Replace(returnRTF, "@@@ABAL", abal)
		returnRTF = Replace(returnRTF, "@@@PPREF", ppref)
		returnRTF = Replace(returnRTF, "@@@PTABLE", ptable)
		if len(tnum) > 3 then
			returnRTF = Replace(returnRTF, "@@@TNUM3L", left(tnum, len(tnum) - 3))
			if len(tnum) > 4 then
				returnRTF = Replace(returnRTF, "@@@TNUM4L", left(tnum, len(tnum) - 4))
			else
				returnRTF = Replace(returnRTF, "@@@TNUM4L", "")
			end if
		else
			returnRTF = Replace(returnRTF, "@@@TNUM4L", "")
			returnRTF = Replace(returnRTF, "@@@TNUM3L", "")
		end if
		returnRTF = Replace(returnRTF, "@@@TNUM3", rtnum(tnum, 3))
		returnRTF = Replace(returnRTF, "@@@TNUM4", rtnum(tnum, 4))
		returnRTF = Replace(returnRTF, "@@@TNUM5", rtnum(tnum, 5))
		returnRTF = Replace(returnRTF, "@@@TNUM", tnum)
		returnRTF = Replace(returnRTF, "@@@STOREBARCO", storebarco)
		returnRTF = Replace(returnRTF, "@@@BARCO", barco)
		returnRTF = Replace(returnRTF, "@@@TAGNUM", tagnum)
		returnRTF = Replace(returnRTF, "@@@SUBTOT", subtot)
		returnRTF = Replace(returnRTF, "@@@TAX10", tax10)
		returnRTF = Replace(returnRTF, "@@@TAX1", tax1)
		returnRTF = Replace(returnRTF, "@@@TAX2", tax2)
		returnRTF = Replace(returnRTF, "@@@TAX3", tax3)
		returnRTF = Replace(returnRTF, "@@@TAX4", tax4)
		returnRTF = Replace(returnRTF, "@@@TAX5", tax5)
		returnRTF = Replace(returnRTF, "@@@TAX6", tax6)
		returnRTF = Replace(returnRTF, "@@@TAX7", tax7)
		returnRTF = Replace(returnRTF, "@@@TAX8", tax8)
		returnRTF = Replace(returnRTF, "@@@TAX9", tax9)

		returnRTF = Replace(returnRTF, "@@@TAXTOT", taxTot)
		returnRTF = Replace(returnRTF, "@@@TIP", employeeTip)

		returnRTF = Replace(returnRTF, "@@@TOTAL", total)
		returnRTF = Replace(returnRTF, "@@@PAD", paymentDetails)
		returnRTF = Replace(returnRTF, "@@@BALDUE", baldue)

		if baldue < 0.01 then
		  returnRTF = Replace(returnRTF, "@@@ISPAID", "PAID")
		else
		  returnRTF = Replace(returnRTF, "@@@ISPAID", "")
		end if

		returnRTF = Replace(returnRTF, "@@@PAYTYP", paytyp)
		returnRTF = Replace(returnRTF, "@@@TOTPAY", totpay)
		'returnRTF = Replace(returnRTF, "@@@CHGDUE", chgdue)
		returnRTF = Replace(returnRTF, "@@@AONACC", aonacc)
		returnRTF = Replace(returnRTF, "@@@APAID", apaid)
		returnRTF = Replace(returnRTF, "@@@CREDATE", credate)
		returnRTF = Replace(returnRTF, "@@@TRATIME", tratime)
		returnRTF = Replace(returnRTF, "@@@TRADATE", tradate)
		returnRTF = Replace(returnRTF, "@@@TRADOW", tradow)
		returnRTF = Replace(returnRTF, "@@@TICRDTIME", ticrdtime)
		returnRTF = Replace(returnRTF, "@@@TICRDDATE", ticrddate)
		returnRTF = Replace(returnRTF, "@@@TICRDDOW", ticrddow)
		returnRTF = Replace(returnRTF, "@@@ITEMCOUNT", itemcoun)
		returnRTF = Replace(returnRTF, "@@@EFN", efn)
		returnRTF = Replace(returnRTF, "@@@EFI", efi)
		returnRTF = Replace(returnRTF, "@@@ELN", eln)
		returnRTF = Replace(returnRTF, "@@@ELI", eli)
		returnRTF = Replace(returnRTF, "@@@CREEMP", creemp)
		returnRTF = Replace(returnRTF, "@@@DEPTNAME", deptname)
		returnRTF = Replace(returnRTF, "@@@DEPTINITAL", deptinitals)
		returnRTF = Replace(returnRTF, "@@@DEPTINITIAL", deptinitals)
		returnRTF = Replace(returnRTF, "@@@SC1", sc1)
		returnRTF = Replace(returnRTF, "@@@SC2", sc2)
		returnRTF = Replace(returnRTF, "@@@SCTOT", sctot)
		returnRTF = Replace(returnRTF, "@@@WILLCALL", willcall)

		'Following added by J.Johnston, 7Nov03
		returnRTF = Replace(returnRTF, "@@@CCAUTHCODE", ccAuthCode)
		returnRTF = Replace(returnRTF, "@@@CCEXPDATE", ccExpDate)
		returnRTF = Replace(returnRTF, "@@@CCTYPE", ccCardType)
		returnRTF = Replace(returnRTF, "@@@CCACCTNUM", ccAcctNum)
		returnRTF = Replace(returnRTF, "@@@CCCARDHOLDER", ccCardHolder)
		returnRTF = Replace(returnRTF, "@@@CCTOTAL", ccTotal)
		'End addition 7Nov03

		returnRTF = Replace(returnRTF, "@@@TIME", FormatDateTime(Now, 4))


		returnRTF = Replace(returnRTF, "@@@LT", lineItemStrWT)

		returnRTF = TransformDates(returnRTF)

		TransformRTF = returnRTF

	End Function

    Function TransformDates(rtf)
        Dim place
        Dim ns
        Dim nl
        Dim replaceWith
        Dim dd


        If InStr(rtf, "@@@DP") Then
            Do While InStr(rtf, "@@@DP")
                place = InStr(rtf, "@@@DP")
                ns = place + Len("@@@DP")
                nl = 0

                While IsNumeric(Mid(rtf, ns, nl + 1)) And (ns + nl) <= Len(rtf)
                    nl = nl + 1
                Wend

                dd = clng(Mid(rtf, ns, nl))

                replaceWith = FormatDateTime(DateAdd("d", dd, Date), 0)

                rtf = Mid(rtf, 1, place - 1) & replaceWith & Mid(rtf, place + Len("@@@DP") + nl, Len(rtf))

                TransformDates = rtf

            Loop
        Else
            TransformDates = rtf
        End If

    End Function

    sub getStoreInfo(storeID)
    	dim query, rs

    	if storeID <> "" then

    		query = " select "
    		query = query & " isnull(storenumber, '') as storenumber, "
    		query = query & " isnull(name, '') as storename, "
    		query = query & " isnull(streetaddress1, '') as storeaddress1, "
    		query = query & " isnull(streetaddress2, '') as storeaddress2, "
    		query = query & " isnull(city, '') as storecity, "
    		query = query & " isnull(state, '') as storestate, "
    		query = query & " isnull(zipcode, '') as storezip, "
    		query = query & " isnull(phonenumber, '') as storephone, "
    		query = query & " isnull(areacode, '') as storeareacode, "
    		query = query & " isnull(websiteurl, '') as storewebsite, "
    		query = query & " isnull(email, '') as storeemail "


    		query = query & " from store where storeid = " & storeID
    		set rs = getdisconnectedrecordset(query)

    		if rs.recordcount > 0 then
    				storenumber = rs("storenumber")
					storename = rs("storename")
					storeaddress1 = rs("storeaddress1")
					storeaddress2 = rs("storeaddress2")
					storecity = rs("storecity")
					storestate = rs("storestate")
					storezip = rs("storezip")
					storephone = rs("storephone")
					storeareacode = rs("storeareacode")
					storewebsite = rs("storewebsite")
					storeemail = rs("storeemail")
				end if

				set rs = nothing
    	end if



    end sub

	'The following section is for pickup object initialization
	Sub InitializePickupObject()
		Dim pickupInvoicesDictionary
		Dim invoicesTotalInfo
		Dim invoiceTotal
		Dim totalAmtPaid
		Dim amountDue
		Dim invoicesNetTotal

		Set pickupInvoicesDictionary = getInvoicesForPickup()

		if pickupInvoicesDictionary.Count > 0 then
			Set PickupObject = Server.CreateObject("ShahCorpComponents.pickup")
			PickupObject.DBConnectionString = Session("shahcorpDSN")
			PickupObject.storeId = storeId
			Set PickupObject.pickupInvoices = pickupInvoicesDictionary
			PickupObject.userAction = "pickup"
			invoicesTotalInfo= getTotalOfAllInvoices(pickupInvoicesDictionary)
			invoiceTotal = invoicesTotalInfo(0)
			totalAmtPaid = invoicesTotalInfo(1)
			invoicesNetTotal = invoicesTotalInfo(2)
			PickupObject.populateHeatSealInfo
			PickupObject.populateLineItemsToDisplay
			'Response.Write("DisplayRST Count = " & PickupObject.displayRst.RecordCount & nl)
		end if

	End Sub

	function getInvoicesForPickUp()
		Dim pickupSql
		Dim pickupInvoicesRst
		Dim pickupInvoicesDictionary
		Dim aInvoice

		Set pickupInvoicesDictionary = Server.CreateObject("Scripting.Dictionary")

		'Following "if" added by J.Johnston, 18Dec03
		if pickupTickets <> "" then

			pickupSql = "Select invoiceNumber, ticketNumber, convert(varchar, createdDate, 101) as 'DateIn', " _
					& " convert(varchar,dueDate,101) as 'DateDue',  invoiceTotal, netTotal, " _
					& " amountPaid From Ticket Where ticketNumber IN (" & pickupTickets & ") " _
					& " Order By createdDate ASC"

			set pickupInvoicesRst = getDisconnectedRecordset(pickupSql)

			if pickupInvoicesRst.RecordCount > 0 then


				pickupInvoicesRst.MoveFirst
				while Not pickupInvoicesRst.EOF
					Set aInvoice = Server.CreateObject("ShahCorpComponents.pickupInvoice")
					aInvoice.ticketNumber = pickupInvoicesRst.Fields("ticketNumber").Value
					aInvoice.invoiceNumber = pickupInvoicesRst.Fields("invoiceNumber").Value
					aInvoice.amountPaid = pickupInvoicesRst.Fields("amountPaid").Value
					aInvoice.invoiceTotal = pickupInvoicesRst.Fields("invoiceTotal").Value
					aInvoice.netTotal = pickupInvoicesRst.Fields("netTotal").Value
					pickupInvoicesDictionary.Add aInvoice.ticketNumber, aInvoice

					pickupInvoicesRst.MoveNext
				Wend
			end if
		end if
		Set getInvoicesForPickUp = pickupInvoicesDictionary
	End Function


	function getTotalOfAllInvoices(pickupInvoices)
		dim invoicesTotal
		dim aInvoice
		dim counter
		dim invoicesArray
		dim totalAmtPaid
		dim invoicesNetTotal

		invoicesTotal =0
		totalAmtPaid =0
		invoicesArray = pickupInvoices.Items
		for counter =0 to pickupInvoices.Count -1
			set aInvoice = invoicesArray(counter)
			invoicesTotal = invoicesTotal +  Round(aInvoice.invoiceTotal, 2)
			totalAmtPaid = totalAmtPaid + Round(aInvoice.amountPaid,2)
			if aInvoice.netTotal < 0.0 then
				aInvoice.netTotal = 0.0
			end if
			invoicesNetTotal = invoicesNetTotal + Round(aInvoice.netTotal,2)
		next
		getTotalOfAllInvoices = Array(invoicesTotal, totalAmtPaid, invoicesNetTotal)
	end function

	function isInt(input)
		dim i, d

		isInt = true

		for i=1 to len(input)
			d = Mid(input,i,1)
			if Asc(d) < 48 OR Asc(d) > 57 then
				isInt = false
				exit for
			end if
		next

	end function

	function getTagsAsCSV(tNum)
		Dim tagsql, tagrs, retcsv
		Dim lastTagNumber
		Dim lastTagColor
		Dim groupFirstTagNumber
		Dim lastLotNumber

		lastTagNumber = ""
		lastTagColor = ""
		lastLotNumber = ""
		groupFirstTagNumber = ""


		tagsql = "SELECT  lotID, lotNumber, ticketNumber, tagNumber AS TagNumber, isnull(tagColor, '') as tagColor FROM TicketTag "
		tagsql = tagsql & " WHERE ticketNumber IN (" & tNum & ") "
		tagsql = tagsql & " ORDER BY lotNumber, tagColor, "
		tagsql = tagsql & " CASE dbo.isInt(tagNumber) "
		tagsql = tagsql & " WHEN 0 THEN -1 "
		tagsql = tagsql & " ELSE cast(tagNumber as integer) "
		tagsql = tagsql & " END "

		Set tagrs = getDisconnectedRecordset(tagsql)

		if tagrs.RecordCount > 0 then
			lastTagNumber = tagrs.Fields("tagNumber").Value
			lastTagColor = tagrs.Fields("tagcolor").Value
			lastLotNumber = tagrs.Fields("lotNumber").Value

			if isInt(lastTagNumber)	then groupFirstTagNumber = lastTagNumber

			tagrs.MoveNext

			while Not tagrs.EOF

				if isInt(lastTagNumber) then
					if trim(lastLotNumber) = trim(tagrs.Fields("lotNumber").Value) _
					and trim(lastTagColor) = trim(tagrs.Fields("tagcolor").Value) _
					and trim(lastTagNumber + 1) = trim(tagrs.Fields("tagNumber").Value) then

					else

						if retcsv <> "" then	retcsv = retcsv & ", "

						if lastLotNumber >= 0 then
							retcsv = retcsv & lastLotNumber & "/"
						end if

						if groupFirstTagNumber <> "" then
							if groupFirstTagNumber <> lastTagNumber then
								retcsv = retcsv & groupFirstTagNumber & "-" & lastTagNumber
							else
								retcsv = retcsv & groupFirstTagNumber
							end if
						else
							retcsv = retcsv & lastTagNumber
						end if

						if trim(lastTagColor) <> "" then
							retcsv = retcsv & " (" & trim(lastTagColor) & ")"
						end if

						lastTagNumber = tagrs.Fields("tagNumber").Value
						lastTagColor = tagrs.Fields("tagcolor").Value

						if isInt(lastTagNumber)	then
							groupFirstTagNumber = lastTagNumber
						else
							groupFirstTagNumber = ""
						end if
					end if
					lastTagNumber = tagrs.Fields("tagNumber").Value
					lastTagColor = tagrs.Fields("tagcolor").Value
					lastLotNumber = tagrs.Fields("lotNumber").Value
				else

					if retcsv <> "" then	retcsv = retcsv & ", "

					if lastLotNumber >= 0 then
						retcsv = retcsv & lastLotNumber & "/"
					end if

					if groupFirstTagNumber <> "" then
						if groupFirstTagNumber <> lastTagNumber then
							retcsv = retcsv & groupFirstTagNumber & "-" & lastTagNumber
						else
							retcsv = retcsv & groupFirstTagNumber
						end if
					else
						retcsv = retcsv & lastTagNumber
					end if

					if trim(lastTagColor) <> "" then
						retcsv = retcsv & " (" & trim(lastTagColor) & ")"
					end if

					lastTagNumber = tagrs.Fields("tagNumber").Value
					lastTagColor = tagrs.Fields("tagcolor").Value
					lastLotNumber = tagrs.Fields("lotNumber").Value

					if isInt(lastTagNumber)	then
						groupFirstTagNumber = lastTagNumber
					else
						groupFirstTagNumber = ""
					end if
				end if

				tagrs.MoveNext
			wend

			if retcsv <> "" then	retcsv = retcsv & ", "

			if lastLotNumber >= 0 and getMSVar("enableLotTags") then
				retcsv = retcsv & lastLotNumber & "/"
			end if

			if groupFirstTagNumber <> "" then
				if groupFirstTagNumber <> lastTagNumber then
					retcsv = retcsv & groupFirstTagNumber & "-" & lastTagNumber
				else
					retcsv = retcsv & groupFirstTagNumber
				end if
			else
				retcsv = retcsv & lastTagNumber
			end if

			if trim(lastTagColor) <> "" then
				retcsv = retcsv & " (" & trim(lastTagColor) & ")"
			end if

		end if

		getTagsAsCSV = retcsv

	end function

	function getHeatSealsAsCSV(tNum)

	end function

	function getTagsAndHeatSealsAsCSV(tNum)
		Dim tagcsv, hscsv
		tagcsv = getTagsAsCSV(tNum)
		if left(tagcsv, len("ERROR")) = "ERROR" then
			getTagsAndHeatSealsAsCSV = tagcsv
			exit function
		end if

		hscsv = getHeatSealsAsCSV(tNum)
		if left(hscsv, len("ERROR")) = "ERROR" then
			getTagsAndHeatSealsAsCSV = hscsv
			exit function
		end if
		if tagcsv = "" then
			getTagsAndHeatSealsAsCSV = hscsv
			exit function
		else
			if hscsv = "" then
				getTagsAndHeatSealsAsCSV = tagcsv
				exit function
			else
				getTagsAndHeatSealsAsCSV = tagcsv & ", " & hscsv
				exit function
			end if
		end if

	end function


	sub getDetailsForTagPrinting()

		'Function to get Invoice details for Tag Printing
		Dim pTagSql, pTagRs

		pTagSql = "SELECT ISNULL(t.invoiceNumber, '') AS invoiceNumber, " _
				& " ISNULL(t.starchPreferenceName, '') AS starchPreferenceName, " _
				& " ISNULL(t.finishPreferenceName, '') AS finishPreferenceName, " _
				& " ISNULL(t.createdDate, '') AS createdDate, " _
				& " ISNULL(t.createdByEmployeeID, '') AS createdByEmployeeID, " _
				& " ISNULL(t.dueDate, '') AS dueDate, " _
				& " ISNULL(t.pickupTime, '') AS pickupTime, " _
				& " ISNULL(t.priceListID, '') AS priceListID, " _
				& " ISNULL(TC.multiPickupCustomerName, '') AS multiPickupCustomerName, " _
				& " ISNULL(TC.multiPickupLocation, '') AS multiPickupLocation " _
				& " FROM Ticket t, TicketCustomer TC " _
				& " WHERE t.ticketNumber = " & ticketNo & " AND t.ticketNumber = TC.ticketNumber "

		On Error Resume Next
		Set pTagRs = getDisconnectedRecordset(pTagSql)

		if Not pTagRs Is Nothing And Not pTagRs.EOF Then
			pTagRs.MoveFirst

			if request.querystring("invoicenumber") <> "" then
				tnum = request.querystring("invoicenumber")
			else
				tNum = pTagRs("invoiceNumber").Value
			end if


			spref = pTagRs("starchPreferenceName").Value
			fpref = pTagRs("finishPreferenceName").Value
			credate = pTagRs("createdDate").Value
			creemp = getEmployeeNameByID(pTagRs("createdByEmployeeID").Value)
			creempln = getEmployeeLastnameByID(pTagRs("createdByEmployeeID").Value)
			creempfn = getEmployeeFirstnameByID(pTagRs("createdByEmployeeID").Value)

			ticrdtime = pTagRs("pickupTime").Value
			ticrddate = ExtractDate(pTagRs("dueDate").Value)
			ticrddow = ardow(DatePart("w", cdate(ticrddate))-1)
			ticrddowa = left(ticrddow, 3)

			mpn = pTagRs("multiPickupCustomerName").Value
			mpl = pTagRs("multiPickupLocation").Value
			if pTagRs("priceListID").Value <> "" then
				ptable = getPriceListName(pTagRs("priceListID").Value)
			end if

			pTagRs.Close

		End if

	end sub


	function getItemCount(tNum)

		'Function to get Item Count for List of Comma Seperated Invoices
		'(This method can be used for Detail or Pickup and NOT for Quick)
		Dim pItemCountSql, pItemCountRs

'  If pkgQuantity is zero then count as 0
		pItemCountSql = "SELECT SUM(quantity * ISNULL(packagedQuantity, 1)) AS itemCount " _
						& " FROM TicketLineItem WHERE ticketNumber IN ( " & tNum & " )" _
						& " AND (ticketLineType = 'IT' OR ticketLineType = 'AC')"
														'Modified by vivek because it was not printing the invoice
														'if invoice is for additional charges only

'  Uncomment the code below, if pkgQuantity is zero then count as 1.
'		pItemCountSql = "SELECT SUM(quantity * (CASE packagedQuantity WHEN NULL THEN 1 WHEN 0 THEN 1 ELSE packagedQuantity END)) AS itemCount " _
'						& " FROM TicketLineItem WHERE ticketNumber IN ( " & tNum & " )" _
'						& " AND ticketLineType = 'IT'"

		On Error Resume Next
		Set pItemCountRs = getDisconnectedRecordset(pItemCountSql)
		if Err.number <> 0 Then
			getItemCount = "ERROR 10:" & err.Description & nl & pItemCountSql & nl
			exit function
		end if
		if Not pItemCountRs Is Nothing And Not pItemCountRs.EOF Then
			pItemCountRs.MoveFirst
			getItemCount = pItemCountRs("itemCount").Value
			pItemCountRs.Close
		else
			getItemCount = ""
		End if

	end function

function isDepartmentInTickets(ticketNumbers, departmentName)
		dim query, rs

		query = " select distinct departmentname from ticketlineitem "
        query = query & " where ticketNumber in (" & ticketNumbers & ")"


		set rs = getDisconnectedRecordset(query)

		isDepartmentInTickets = false

		while not(rs.eof or rs.bof)
			if trim(rs("departmentname")) = trim(departmentName) then
				isDepartmentInTickets = true
			end if
			rs.movenext
		wend

		set rs = nothing
end function


function getDeparmentNameForTag(ticketNo, tagNo)
		'Function to get Department Name for Tag Printing
		Dim tagsql, tagRs

		tagsql = "SELECT d.name FROM TicketTag t, Department d" _
				 & " WHERE t.departmentID = d.departmetID " _
				 & " AND ticketNumber = " & ticketNo & " AND tagNumber = " & tagNo

		On Error Resume Next
		Set tagRs = getDisconnectedRecordset(tagsql)
		if Err.number <> 0 Then
			getDeparmentNameForTag = "ERROR 11:" & err.Description & nl & tagsql & nl
			exit function
		end if
		if Not tagRs Is Nothing And Not tagRs.EOF Then
			tagRs.MoveFirst
			getDeparmentNameForTag = tagRs("name").Value
			tagRs.Close
		else
			getDeparmentNameForTag = ""
		End if

end function


	function getDeparmentNamesAsCSV(tNum)
		Dim depsql, deprs, depcsv
		depsql = "SELECT  dbo.pivotTicketDepartments(" & tNum & ", ',') AS depCSV"
		'Response.Write depsql
		On Error Resume Next
		Set deprs = getDisconnectedRecordset(depsql)
		if Err.number <> 0 Then
			getDeparmentNamesAsCSV = "ERROR :" & err.Description & nl & depsql & nl
			exit function
		end if
		if Not deprs Is Nothing And Not deprs.EOF Then
			deprs.MoveFirst
			getDeparmentNamesAsCSV = deprs("depCSV").Value
		else
			getDeparmentNamesAsCSV = ""
		End if
		on error resume next
		deprs.Close
	end function

	function getDeparmentInitialsAsCSV(tNum)
		Dim result
		dim deptArr
		dim index

		deptArr = split(getDeparmentNamesAsCSV(tnum), ",")

		for index = 0 to UBound(deptArr)
			result = result & Left(trim(deptArr(index)), 1)
			if index <> UBound(deptArr) then
				result = result & ","
			end if
		next

		getDeparmentInitialsAsCSV = result
	end function

	function getPickupDeparmentNamesAsCSV(pickupTickets)
		'Function to get Department Names of  Pickup given the TicketNumber CSV
		Dim pickupDeptNamesCSVSql
		Dim pickupDeptNamesCSVRst
		Dim pickupDeptNamesCSV

		pickupDeptNamesCSVSql = "SELECT  distinct(departmentName) FROM TicketLineItem WHERE TicketNumber IN (" & pickupTickets & ") "

		set pickupDeptNamesCSVRst = getDisconnectedRecordset(pickupDeptNamesCSVSql)

		if pickupDeptNamesCSVRst.RecordCount > 0 then

			pickupDeptNamesCSVRst.MoveFirst
			pickupDeptNamesCSV = pickupDeptNamesCSVRst.Fields("departmentName").Value
			pickupDeptNamesCSVRst.MoveNext

			while Not pickupDeptNamesCSVRst.EOF
				pickupDeptNamesCSV = pickupDeptNamesCSV & ", " & pickupDeptNamesCSVRst.Fields("departmentName").Value
				pickupDeptNamesCSVRst.MoveNext
			Wend
		end if
		getPickupDeparmentNamesAsCSV = pickupDeptNamesCSV

	end function

	function getPickupDeparmentInitialsAsCSV(pickupTickets)
		'Function to get Department Names of  Pickup given the TicketNumber CSV
		Dim pickupDeptInitialsCSVSql
		Dim pickupDeptInitialsCSVRst
		Dim pickupDeptInitialsCSV

		pickupDeptInitialsCSVSql = "SELECT  distinct(departmentName) FROM TicketLineItem WHERE TicketNumber IN (" & pickupTickets & ") "

		set pickupDeptInitialsCSVRst = getDisconnectedRecordset(pickupDeptInitialsCSVSql)

		if pickupDeptInitialsCSVRst.RecordCount > 0 then

			pickupDeptInitialsCSVRst.MoveFirst
			pickupDeptInitialsCSV = Left(pickupDeptInitialsCSVRst.Fields("departmentName").Value, 1)
			pickupDeptInitialsCSVRst.MoveNext

			while Not pickupDeptInitialsCSVRst.EOF
				pickupDeptInitialsCSV = pickupDeptInitialsCSV & "," & Left(pickupDeptInitialsCSVRst.Fields("departmentName").Value, 1)
				pickupDeptInitialsCSVRst.MoveNext
			Wend
		end if
		getPickupDeparmentInitialsAsCSV = pickupDeptInitialsCSV

	end function

	function getPriceListName(pListNum)
		'Function to get PriceList Name given the priceListNumber
		Dim pListSql, pListRs

		pListSql = "SELECT name FROM PriceList WHERE priceListID = " & pListNum

		On Error Resume Next
		Set pListRs = getDisconnectedRecordset(pListSql)
		if Err.number <> 0 Then
			getPriceListName = "ERROR 12:" & err.Description & nl & pListSql & nl
			exit function
		end if
		if Not pListRs Is Nothing And Not pListRs.EOF Then
			pListRs.MoveFirst
			getPriceListName = pListRs("name").Value
			pListRs.Close
		else
			getPriceListName = ""
		End if

	end function


	function getPickupPriceListNamesAsCSV(pickupTickets)
		'Function to get Invoices CSV List of  Pickup, given the TicketNumber CSV
		Dim pickupPriceListsCSVSql
		Dim pickupPriceListsCSVRst
		Dim pickupPriceListsCSV

		pickupPriceListsCSVSql = "SELECT distinct(PL.name) FROM PriceList PL, Ticket TC " _
				& " WHERE PL.priceListID = TC.priceListID " _
				& " AND ticketNumber IN (" & pickupTickets & ") "

		set pickupPriceListsCSVRst = getDisconnectedRecordset(pickupPriceListsCSVSql)

		if pickupPriceListsCSVRst.RecordCount > 0 then

			pickupPriceListsCSVRst.MoveFirst
			pickupPriceListsCSV = pickupPriceListsCSVRst.Fields("name").Value
			pickupPriceListsCSVRst.MoveNext

			while Not pickupPriceListsCSVRst.EOF
				pickupPriceListsCSV = pickupPriceListsCSV & ", " & pickupPriceListsCSVRst.Fields("name").Value
				pickupPriceListsCSVRst.MoveNext
			Wend
		end if
		getPickupPriceListNamesAsCSV = pickupPriceListsCSV

	end function



	function getPickupInvoicesAsCSV(pickupTickets)
		'Function to get Invoices CSV List of  Pickup, given the TicketNumber CSV
		Dim pickupInvoicesCSVSql
		Dim pickupInvoicesCSVRst
		Dim pickupInvoicesCSV

		pickupInvoicesCSVSql = "SELECT invoiceNumber FROM Ticket WHERE ticketNumber IN (" & pickupTickets & ") " _
				& " Order By createdDate ASC"

		set pickupInvoicesCSVRst = getDisconnectedRecordset(pickupInvoicesCSVSql)

		if pickupInvoicesCSVRst.RecordCount > 0 then

			pickupInvoicesCSVRst.MoveFirst
			pickupInvoicesCSV = pickupInvoicesCSVRst.Fields("invoiceNumber").Value
			pickupInvoicesCSVRst.MoveNext

			while Not pickupInvoicesCSVRst.EOF
				pickupInvoicesCSV = pickupInvoicesCSV & ", " & pickupInvoicesCSVRst.Fields("invoiceNumber").Value
				pickupInvoicesCSVRst.MoveNext
			Wend
		end if
		getPickupInvoicesAsCSV = pickupInvoicesCSV

	end function


	function rtnum(tnum, n)
		dim tarr
		dim index
		dim result

		tarr = split(tnum, ",")

		for index = 0 to UBound(tarr)
			if result <> "" then result = result & ", "
			result = result & right(trim(tarr(index)), n)
		next

		rtnum = result
	end function

	function convertTNumToBarco(prefix, tnum)
		dim tarr
		dim index
		dim result

		tarr = split(tnum, ",")

		for index = 0 to UBound(tarr)
			result = result & "*" & trim(prefix) & trim(tarr(index)) & "*"
			if index <> UBound(tarr) then
				result = result & " \par \par"
			end if
			select case index
			case 0
				tnum1 = trim(tarr(index))
			end select
		next

		convertTNumToBarco = result
	end function


	function AppendWD(dlm, base, item)
		if item = "" then
			AppendWD = base
		elseif base <> "" then
			AppendWD = base & dlm & item
		else
			AppendWD = item
		end if
	end function

	function isTicketDetailed(ticketnumber)
		dim query, rs

		query = " select 1 from ticket where invoicetype = 'D' and ticketnumber = " & ticketnumber

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			isTicketDetailed = 1
		else
			isTicketDetailed = 0
		end if

		set rs = nothing

	end function

	function createCurrentInvoices()
		dim query, rs
		dim customerline


		query = "select invoicenumber, dbo.pivotTicketRackLocationBrief(ticketnumber, '; ') as racklocations, (invoicetotal - amountpaid) as amountdue from ticket "
		query = query & " where ticketstatus = 'AC' and invoicetype = 'D' and customersequencenumber = " & custseqno

		set rs = getdisconnectedrecordset(query)

		currentinvoices = ""

		while not(rs.eof or rs.bof)
			customerline = pad(trim(rs("invoicenumber")), 7, ALIGN_LEFT)
			customerline = customerline & pad(trim(rs("racklocations")), 50, ALIGN_RIGHT)
			customerline = customerline & pad(formatcurrency(rs("amountdue")), 10, ALIGN_RIGHT)

			currentinvoices = AppendWD(", ", currentinvoices, customerline)

			rs.movenext
		wend

		set rs = nothing
	end function

	function convertDeptNameToInitial(deptName)
		Dim result
		dim deptArr
		dim index

		deptArr = split(deptName, ",")

		for index = 0 to UBound(deptArr)
			result = result & Left(trim(deptArr(index)), 1)
		next

		convertDeptNameToInitial = result

	end function

	function getPickupTagsAndHeatSealsAsCSV(pickupTickets)
		'Function to get Tags CSV List of  Pickup given the TicketNumber CSV
		Dim pickupTagsSql
		Dim pickupTagsRst
		Dim pickupTagsCSV

		pickupTagsSql = "SELECT tagNumber FROM TicketTag WHERE ticketNumber IN (" & pickupTickets & ") "

		set pickupTagsRst = getDisconnectedRecordset(pickupTagsSql)

		if pickupTagsRst.RecordCount > 0 then

			pickupTagsRst.MoveFirst
			pickupTagsCSV = pickupTagsRst.Fields("tagNumber").Value
			pickupTagsRst.MoveNext

			while Not pickupTagsRst.EOF
				pickupTagsCSV = pickupTagsCSV & ", " & pickupTagsRst.Fields("tagNumber").Value
				pickupTagsRst.MoveNext
			Wend
		end if
		getPickupTagsAndHeatSealsAsCSV = pickupTagsCSV

	end function

	function getPickupStarchPrefAsCSV(pickupTickets)
		'Function to get Starch Preference CSV List of  Pickup, given the TicketNumber CSV
		Dim pickupStarchCSVSql
		Dim pickupStarchCSVRst
		Dim pickupStarchCSV

		pickupStarchCSVSql = "SELECT distinct(starchPreferenceName) FROM Ticket " _
				& " WHERE ticketNumber IN (" & pickupTickets & ") "

		set pickupStarchCSVRst = getDisconnectedRecordset(pickupStarchCSVSql)

		if pickupStarchCSVRst.RecordCount > 0 then

			pickupStarchCSVRst.MoveFirst
			if pickupStarchCSVRst.Fields("starchPreferenceName").Value <> "" then
				pickupStarchCSV = pickupStarchCSVRst.Fields("starchPreferenceName").Value
			end if
			pickupStarchCSVRst.MoveNext

			while Not pickupStarchCSVRst.EOF
				if pickupStarchCSVRst.Fields("starchPreferenceName").Value <> "" then
					pickupStarchCSV = pickupStarchCSV & ", " & pickupStarchCSVRst.Fields("starchPreferenceName").Value
				end if
				pickupStarchCSVRst.MoveNext
			Wend
		end if
		getPickupStarchPrefAsCSV = pickupStarchCSV
	end function

	function getPickupFinishPrefAsCSV(pickupTickets)
		'Function to get Finish Preference CSV List of  Pickup, given the TicketNumber CSV
		Dim pickupFinishCSVSql
		Dim pickupFinishCSVRst
		Dim pickupFinishCSV

		pickupFinishCSVSql = "SELECT distinct(finishPreferenceName) FROM Ticket " _
				& " WHERE ticketNumber IN (" & pickupTickets & ") "

		set pickupFinishCSVRst = getDisconnectedRecordset(pickupFinishCSVSql)

		if pickupFinishCSVRst.RecordCount > 0 then

			pickupFinishCSVRst.MoveFirst
			if pickupFinishCSVRst.Fields("finishPreferenceName").Value <> "" then
				pickupFinishCSV = pickupFinishCSVRst.Fields("finishPreferenceName").Value
			end if
			pickupFinishCSVRst.MoveNext

			while Not pickupFinishCSVRst.EOF
			if pickupFinishCSVRst.Fields("finishPreferenceName").Value <> "" then
				pickupFinishCSV = pickupFinishCSV & ", " & pickupFinishCSVRst.Fields("finishPreferenceName").Value
			end if
				pickupFinishCSVRst.MoveNext
			Wend
		end if
		getPickupFinishPrefAsCSV = pickupFinishCSV
	end function

	function getEmployeeNameByID(ID)
		dim query, rs
		dim result

		ID = trim(ID)
		if ID = "" then
			getEmployeeNameByID = "UNKNOWN EMPLOYEE"
		else
			query = "select employeeName from Employee where employeeID in (" & ID & ")"
			set rs = getdisconnectedrecordset(query)
			if not (rs.eof or rs.bof) then

				result = ""
				while not (rs.eof or rs.bof)
					result = result + trim(rs("employeeName"))
					rs.movenext
					if not (rs.eof or rs.bof) then
						result = result + " and "
					end if
				wend
				getEmployeeNameByID = result
			else
				getEmployeeNameByID = "UNKNOWN EMPLOYEE"
			end if
			set rs = nothing
		end if
	end function

	function getEmployeeLastnameByID(ID)
		dim query, rs
		dim result

		ID = trim(ID)
		if ID = "" then
			getEmployeeLastnameByID = "UNKNOWN EMPLOYEE"
		else
			query = "select lastName from Employee where employeeID in (" & ID & ")"
			set rs = getdisconnectedrecordset(query)
			if not (rs.eof or rs.bof) then

				result = ""
				while not (rs.eof or rs.bof)
					result = result + trim(rs("lastName"))
					rs.movenext
					if not (rs.eof or rs.bof) then
						result = result + " and "
					end if
				wend
				getEmployeeLastnameByID = result
			else
				getEmployeeLastnameByID = "UNKNOWN EMPLOYEE"
			end if
			set rs = nothing
		end if
	end function

	function getEmployeeFirstnameByID(ID)
		dim query, rs
		dim result

		ID = trim(ID)
		if ID = "" then
			getEmployeeFirstnameByID = "UNKNOWN EMPLOYEE"
		else
			query = "select firstName from Employee where employeeID in (" & ID & ")"
			set rs = getdisconnectedrecordset(query)
			if not (rs.eof or rs.bof) then

				result = ""
				while not (rs.eof or rs.bof)
					result = result + trim(rs("firstName"))
					rs.movenext
					if not (rs.eof or rs.bof) then
						result = result + " and "
					end if
				wend
				getEmployeeFirstnameByID = result
			else
				getEmployeeFirstnameByID = "UNKNOWN EMPLOYEE"
			end if
			set rs = nothing
		end if
	end function

	function getPickupCreEmpAsCSV(pickupTickets)
		'Function to get Created by Employee CSV List of  Pickup, given the TicketNumber CSV
		Dim pickupCreEmpCSVSql
		Dim pickupCreEmpCSVRst
		Dim pickupCreEmpCSV

		pickupCreEmpCSVSql = "SELECT distinct(createdByEmployeeID) FROM Ticket " _
				& " WHERE ticketNumber IN (" & pickupTickets & ") "

		set pickupCreEmpCSVRst = getDisconnectedRecordset(pickupCreEmpCSVSql)

		if pickupCreEmpCSVRst.RecordCount > 0 then

			pickupCreEmpCSVRst.MoveFirst
			pickupCreEmpCSV = pickupCreEmpCSVRst.Fields("createdByEmployeeID").Value
			pickupCreEmpCSVRst.MoveNext

			while Not pickupCreEmpCSVRst.EOF
				pickupCreEmpCSV = pickupCreEmpCSV & ", " & pickupCreEmpCSVRst.Fields("createdByEmployeeID").Value
				pickupCreEmpCSVRst.MoveNext
			Wend
		end if
		getPickupCreEmpAsCSV = pickupCreEmpCSV
	end function

	function getPickupCreDate(pickupTickets)
		dim query, rs

		query = "select min(createdDate) as credate from ticket where ticketnumber in (" & pickupTickets & ")"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getPickupCreDate = rs("credate")
		end if

		set rs = nothing
	end function

	function getPickupDueDate(pickupTickets)
		dim query, rs

		query = "select max(dueDate) as duedate from ticket where ticketnumber in (" & pickupTickets & ")"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getPickupDueDate = rs("duedate")
		end if

		set rs = nothing
	end function

	function getPickupPickupTime(pickupTickets)
		dim query, rs

		query = "select max(pickupTime) as pickuptime from ticket where ticketnumber in (" & pickupTickets & ")"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getPickupPickupTime = rs("pickuptime")
		end if

		set rs = nothing
	end function


	function getOpenInvoicesAsCVS(customerSeq)
		dim query, rs

		query = "select ticketnumber from ticket where ticketstatus = 'AC' and invoiceType = 'D' and customersequencenumber = " & customerseq
		set rs = getdisconnectedrecordset(query)

		getOpenInvoicesAsCVS = ""

		while not(rs.eof or rs.bof)
			if getOpenInvoicesAsCVS <> "" then
				getOpenInvoicesAsCVS = getOpenInvoicesAsCVS & ","
			end if
			getOpenInvoicesAsCVS = getOpenInvoicesAsCVS & trim(rs("ticketnumber"))
			rs.movenext
		wend

		set rs = nothing
	end function


	function getPickupRackInfoAsCVS(pickupTickets)
		dim ticketArr
		dim result
		dim ticketRackInfo
		dim index
		dim query, rs

		result = ""

		if pickupTickets = "" then
			pickupTickets = getOpenInvoicesAsCVS(custSeqNo)
		end if

		ticketArr = split(pickupTickets, ",")

		for index = 0 to ubound(ticketArr)
			query = "select dbo.pivotTicketRackLocation ('" & trim(ticketArr(index)) & "', ', ') as ticketRacks"
			set rs = getdisconnectedrecordset(query)
			while not (rs.eof or rs.bof)
				if trim(rs("ticketRacks")) <> "" then
					if result <> "" then
						result = result & ", "
					end if

					result = result & rs("ticketRacks")
				end if
				rs.movenext
			wend
			set rs = nothing
		next

		getPickupRackInfoAsCVS = result

	end function

	function getBalanceDueForAllInvoices(pickupTickets)
		dim ticketArr
		dim result
		dim index
		dim query, rs

		result = 0

		if pickupTickets = "" then
			pickupTickets = getOpenInvoicesAsCVS(custSeqNo)
		end if

		ticketArr = split(pickupTickets, ",")

		for index = 0 to ubound(ticketArr)
			query = "select invoiceTotal - amountPaid + prePayDiscount as amountDue from ticket where ticketnumber = " & trim(ticketArr(index))
			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				result = result + formatnumber(rs("amountDue"), 2)
			end if

			set rs = nothing
		next

		getBalanceDueForAllInvoices = formatnumber(result, 2)

	end function

	function getPickupPaymentDetails(tNum)

	end function


	'added by steve gagno
	'to make creating the name fields easier
	function CombineWithCommas(a, b, c)
		Dim result
		Dim tb
		Dim tc

		tb = Trim(b)
		tc = Trim(c)

		result = Trim(a)

		if Len(tb) > 0 then
			result = result & ", " & tb
		end if

		if Len(tc) > 0 then
			result = result & ", " & tc
		end if

		CombineWithCommas = result
	end function


	function getDeptDueDate(lines, deptName)
		dim linesClone
		dim max
		dim datedue

		set linesClone = lines.clone()

		max = "1/1/1980"

		linesClone.filter = "deptName='" & deptName & "'"

		if linesClone.recordcount > 0 then
			linesClone.movefirst
			while not (linesClone.eof or linesClone.bof)
				datedue = linesClone("duedate").value
				if datediff("d", max, datedue) > 0 then
					max = datedue
				end if
				linesClone.moveNext
			wend
		end if
		set linesClone = nothing

		datedue = max

		getDeptDueDate = datepart("m", datedue) & "/" & datepart("d", datedue) & "/" & datepart("yyyy", datedue)
	end function

	function formatItemQty(qty)
		formatItemQty = qty

		if qty <> "" then
			if qty <= 1 then
				formatItemQty = ""
			end if
		end if
	end function

	'edited by steve gagnon
	'to support lidwot80 and lidwt80

	Sub htmlFormatLineDetails(lines, cloneRst)

		Dim lidwotLine
		Dim lidwtLine
		Dim prevDeptName

		' lidwot    'Line Item Detail W/o Total
		' lidwt    'Line Item Detail /w Total

		prevDeptName = ""

		lines.sort = "deptName, lineNumber"

		if lines.RecordCount > 0 then
			lines.MoveFirst

			while not lines.EOF

				if prevDeptName <> lines("deptName") then
					dim deptLine
					dim deptQty

					if lines("itemType") = "DE" then
						deptQty = lines("quantity") & " "
					else
						deptQty = ""
					end if

					deptLine = "<b>" & Pad(deptQty & lines("deptName"), 23, ALIGN_LEFT) _
                         & "<div style='float: right'>" & Pad(getDeptDueDate(lines, lines("deptName")), 10, ALIGN_RIGHT) & "</div></b><br />"


					lidwt = lidwt & deptLine
					lidwot = lidwot & deptLine

					lidwt80 = lidwt80 & deptLine & "&#160;&#160;&#160;" & deptLine & "<br />"
					lidwot80 = lidwot80 & deptLine & "&#160;&#160;&#160;" & deptLine & "<br />"

					if lines("notes") <> "" and lines("itemType") = "DE" then
						lidwt = lidwt &  "&#160;&#160;&#160;" & WordWrap(lines("notes"), lineItemWTLength, "&#160;&#160;&#160;") & "<br />"
						lidwot = lidwot &  "&#160;&#160;&#160;" & WordWrap(lines("notes"), lineItemWTLength, "&#160;&#160;&#160;") & "<br />"
						lidwt80 = lidwt80 &  "&#160;&#160;&#160;" & WordWrap(lines("notes"), lineItemWTLength, "&#160;&#160;&#160;") & "<br />"
						lidwot80 = lidwot80 &  "&#160;&#160;&#160;" & WordWrap(lines("notes"), lineItemWTLength, "&#160;&#160;&#160;") & "<br />"
					end if

					prevDeptName = lines("deptName")
				else

					if lines("itemType") = "IT" then
						lidwtLine = htmlFormatLineItems(lines("quantity"), lines("itemName"), (lines("notes")) & " " & lines("promptResponse"), lines("penotes"), lines("lineItemTotal"), lineItemWTLength)
						lidwotLine = htmlFormatLineItems(lines("quantity"), lines("itemName"), (lines("notes")) & " " & lines("promptResponse"), lines("penotes"), "", lineItemWOTLength)

						lidwt = lidwt & lidwtLine
						lidwot = lidwot & lidwotLine

						lidwt80 = lidwt80 & lidwtLine & "&#160;&#160;&#160;" & lidwtLine & "<br />"
						lidwot80 = lidwot80 & lidwotLine & "&#160;&#160;&#160;" & lidwotLine & "<br />"

						cloneRst.filter = "parentLineNumber = " & lines("lineNumber").Value

						if cloneRst.RecordCount > 0 then
							cloneRst.sort = "lineNumber"
							cloneRst.MoveFirst
							while not cloneRst.EOF
								if cloneRst("itemType") = "CO" or cloneRst("itemType") = "PA" or cloneRst("itemType") = "UP" then
									lidwtLine = htmlFormatLineItems("  " & formatItemQty(cloneRst("quantity")), cloneRst("itemName"), cloneRst("notes"), cloneRst("penotes"), cloneRst("lineItemTotal"), lineItemWTLength)
									lidwotLine = htmlFormatLineItems("  " & formatItemQty(cloneRst("quantity")), cloneRst("itemName"), cloneRst("notes"), cloneRst("penotes"), "", lineItemWOTLength)

									lidwt = lidwt & lidwtLine
									lidwot = lidwot & lidwotLine

									lidwt80 = lidwt80 & lidwtLine & "&#160;&#160;&#160;" & lidwtLine & "<br />"
									lidwot80 = lidwot80 & lidwotLine & "&#160;&#160;&#160;" & lidwotLine & "<br />"
								end if
								cloneRst.MoveNext
							wend
							cloneRst.Filter = ""
						end if
					'Display Add Charge line item
					elseif lines("itemType") = "AC" or lines("itemType") = "CU" or lines("itemType") = "PR" or lines("itemType") = "VI"  then

						dim lineTotal
						dim quantity

						lineTotal = lines("lineItemTotal")
						quantity = lines("quantity")

						if lines("itemType") = "CU" or lines("itemType") = "PR" or lines("itemType") = "VI" then
							lineTotal = -lineTotal
							quantity = ""
						end if

						lidwtLine = htmlFormatLineItems(quantity, lines("itemName"), lines("notes"), "", lineTotal, lineItemWTLength)
						lidwotLine = htmlFormatLineItems(quantity, lines("itemName"), lines("notes"), "", "", lineItemWOTLength)

						lidwt = lidwt & lidwtLine
						lidwot = lidwot & lidwotLine

						lidwt80 = lidwt80 & lidwtLine & "&#160;&#160;&#160;" & lidwtLine & "<br />"
						lidwot80 = lidwot80 & lidwotLine & "&#160;&#160;&#160;" & lidwotLine & "<br />"

					end if


					lines.MoveNext
				end if

			wend

		end if
	end Sub





	Sub rtfFormatLineDetails(lines, cloneRst)

		Dim lidwotLine
		Dim lidwtLine
		Dim prevDeptName

		' lidwot    'Line Item Detail W/o Total
		' lidwt    'Line Item Detail /w Total

		prevDeptName = ""

		lines.sort = "deptName, lineNumber"

		if lines.RecordCount > 0 then
			lines.MoveFirst
			'Sample RTF format is like this.
			'\viewkind4\uc1\trowd\trgaph108\trleft-108\cellx720\cellx3600\cellx4464\pard\intbl \fs18
			'1\cell Shirt\cell 2.95\cell\row\pard\par
			lidwt = lineItemStrWT
			lidwot = lineItemStrWOT

			lidwt80 = lineItemStrWT
			lidwot80 = lineItemStrWOT

			while not lines.EOF

				if prevDeptName <> lines("deptName") then
					dim deptLine
					dim deptQty

					if lines("itemType") = "DE" then
						deptQty = lines("quantity") & " "
					else
						deptQty = ""
					end if

					deptLine = rtfFormatLineItems("\b " & Pad(deptQty & lines("deptName"), 23, ALIGN_LEFT) & Pad(getDeptDueDate(lines, lines("deptName")), 10, ALIGN_RIGHT) & "\b0 " , "", "", "", "", lineItemWTLength)

					lidwt = lidwt & deptLine
					lidwot = lidwot & deptLine

					'trim off the nl AND \par
					'this is VERY dependant on the return of rtfFormatLineItems
					deptLine= Left(deptLine, Len(deptLine) - Len("\par" & nl))

					lidwt80 = lidwt80 & deptLine & "\tab " & deptLine & "\par" & nl
					lidwot80 = lidwot80 & deptLine & "\tab " & deptLine & "\par" & nl

					if lines("notes") <> "" and lines("itemType") = "DE" then
						lidwt = lidwt &  "\tab " & WordWrap(lines("notes"), lineItemWTLength, "\par \tab ") & "\par" & nl
						lidwot = lidwot &  "\tab " & WordWrap(lines("notes"), lineItemWTLength, "\par \tab ") & "\par" & nl
						lidwt80 = lidwt80 &  "\tab " & WordWrap(lines("notes"), lineItemWTLength, "\par \tab ") & "\par" & nl
						lidwot80 = lidwot80 &  "\tab " & WordWrap(lines("notes"), lineItemWTLength, "\par \tab ") & "\par" & nl
					end if

					prevDeptName = lines("deptName")
				else

					if lines("itemType") = "IT" then
						lidwtLine = rtfFormatLineItems(lines("quantity"), lines("itemName"), (lines("notes")) & " " & lines("promptResponse"), lines("penotes"), lines("lineItemTotal"), lineItemWTLength)
						lidwotLine = rtfFormatLineItems(lines("quantity"), lines("itemName"), (lines("notes")) & " " & lines("promptResponse"), lines("penotes"), "", lineItemWOTLength)

						lidwt = lidwt & lidwtLine
						lidwot = lidwot & lidwotLine

						'trim off the nl AND \par
						'this is VERY dependant on the return of rtfFormatLineItems
						lidwtLine= Left(lidwtLine, Len(lidwtLine) - Len("\par" & nl))
						lidwotLine = Left(lidwotLine, Len(lidwotLine) - Len("\par" & nl))

						lidwt80 = lidwt80 & lidwtLine & "\tab " & lidwtLine & "\par" & nl
						lidwot80 = lidwot80 & lidwotLine & "\tab " & lidwotLine & "\par" & nl

						cloneRst.filter = "parentLineNumber = " & lines("lineNumber").Value

						if cloneRst.RecordCount > 0 then
							cloneRst.sort = "lineNumber"
							cloneRst.MoveFirst
							while not cloneRst.EOF
								if cloneRst("itemType") = "CO" or cloneRst("itemType") = "PA" or cloneRst("itemType") = "UP" then
									lidwtLine = rtfFormatLineItems("  " & formatItemQty(cloneRst("quantity")), cloneRst("itemName"), cloneRst("notes"), cloneRst("penotes"), cloneRst("lineItemTotal"), lineItemWTLength)
									lidwotLine = rtfFormatLineItems("  " & formatItemQty(cloneRst("quantity")), cloneRst("itemName"), cloneRst("notes"), cloneRst("penotes"), "", lineItemWOTLength)

									lidwt = lidwt & lidwtLine
									lidwot = lidwot & lidwotLine

									lidwtLine= Left(lidwtLine, Len(lidwtLine) - Len("\par" & nl))
									lidwotLine = Left(lidwotLine, Len(lidwotLine) - Len("\par" & nl))

									lidwt80 = lidwt80 & lidwtLine & "\tab " & lidwtLine & "\par" & nl
									lidwot80 = lidwot80 & lidwotLine & "\tab " & lidwotLine & "\par" & nl
								end if
								cloneRst.MoveNext
							wend
							cloneRst.Filter = ""
						end if
					'Display Add Charge line item
					elseif lines("itemType") = "AC" or lines("itemType") = "CU" or lines("itemType") = "PR" or lines("itemType") = "VI"  then

						dim lineTotal
						dim quantity

						lineTotal = lines("lineItemTotal")
						quantity = lines("quantity")

						if lines("itemType") = "CU" or lines("itemType") = "PR" or lines("itemType") = "VI" then
							lineTotal = -lineTotal
							quantity = ""
						end if

						lidwtLine = rtfFormatLineItems(quantity, lines("itemName"), lines("notes"), "", lineTotal, lineItemWTLength)
						lidwotLine = rtfFormatLineItems(quantity, lines("itemName"), lines("notes"), "", "", lineItemWOTLength)

						lidwt = lidwt & lidwtLine
						lidwot = lidwot & lidwotLine

						lidwtLine= Left(lidwtLine, Len(lidwtLine) - Len("\par" & nl))
						lidwotLine = Left(lidwotLine, Len(lidwotLine) - Len("\par" & nl))

						lidwt80 = lidwt80 & lidwtLine & "\tab " & lidwtLine & "\par" & nl
						lidwot80 = lidwot80 & lidwotLine & "\tab " & lidwotLine & "\par" & nl

					end if


					lines.MoveNext
				end if

			wend




			lidwt = lidwt & "\pard"
			lidwot = lidwot & "\pard"

			lidwt80 = lidwt80 & "\pard"
			lidwot80 = lidwot80 & "\pard"

			'Response.Write(lidwt & nl & nl & nl)
			'Response.Write(lidwot & nl & nl & nl)
		end if
	end Sub

	Sub htmlFormatSingleLineDetails(lines)

		' slidwot    'Single Line Detail W/o Total
		' slidwt    'Single Line Detail /w Total

		if lines.RecordCount > 0 then
			lines.MoveFirst

			while not lines.EOF
				if lines("itemType") = "IT" then
					slidwt = slidwt & htmlFormatLineItems(lines("quantity"), lines("itemName"), (lines("notes")) & " " & lines("promptResponse"), lines("penotes"), lines("lineItemTotal"), lineItemWTLength)
					slidwot = slidwot & htmlFormatLineItems(lines("quantity"), lines("itemName"), (lines("notes")) & " " & lines("promptResponse"), lines("penotes"), "", lineItemWOTLength)

				'Display Add Charge line item
				elseif lines("itemType") = "AC" then
					slidwt = slidwt & htmlFormatLineItems(lines("quantity"), lines("itemName"), lines("notes"), "", lines("lineItemTotal"), lineItemWTLength)
					slidwot = slidwot & htmlFormatLineItems(lines("quantity"), lines("itemName"), lines("notes"), "", "", lineItemWOTLength)
				end if
				lines.MoveNext
			wend
			slidwt = slidwt & "<br />"
			slidwot = slidwot & "<br />"
		end if
	end Sub




	Sub rtfFormatSingleLineDetails(lines)

		' slidwot    'Single Line Detail W/o Total
		' slidwt    'Single Line Detail /w Total

		if lines.RecordCount > 0 then
			lines.MoveFirst
			'Sample RTF format is like this.
			'\viewkind4\uc1\trowd\trgaph108\trleft-108\cellx720\cellx3600\cellx4464\pard\intbl \fs18
			'1\cell Shirt\cell 2.95\cell\row\pard\par
			slidwt = lineItemStrWT
			slidwot = lineItemStrWOT
			while not lines.EOF
				if lines("itemType") = "IT" then
					slidwt = slidwt & rtfFormatLineItems(lines("quantity"), lines("itemName"), (lines("notes")) & " " & lines("promptResponse"), lines("penotes"), lines("lineItemTotal"), lineItemWTLength)
					slidwot = slidwot & rtfFormatLineItems(lines("quantity"), lines("itemName"), (lines("notes")) & " " & lines("promptResponse"), lines("penotes"), "", lineItemWOTLength)

'					cloneRst.filter = "parentLineNumber = " & lines("lineNumber").Value
'					if cloneRst.RecordCount > 0 then
'						cloneRst.MoveFirst
'						while not cloneRst.EOF
'							if cloneRst("itemType") = "CO" or cloneRst("itemType") = "PA" or cloneRst("itemType") = "UP" then
'								slidwt = slidwt & rtfFormatLineItems("  " & cloneRst("quantity"), cloneRst("itemName"), cloneRst("notes"), cloneRst("penotes"), cloneRst("lineItemTotal"), lineItemWTLength)
'								slidwot = slidwot & rtfFormatLineItems("  " & cloneRst("quantity"), cloneRst("itemName"), cloneRst("notes"), cloneRst("penotes"), "", lineItemWOTLength)
'							end if
'							cloneRst.MoveNext
'						wend
'						cloneRst.Filter = ""
'					end if
				'Display Add Charge line item
				elseif lines("itemType") = "AC" then
					slidwt = slidwt & rtfFormatLineItems(lines("quantity"), lines("itemName"), lines("notes"), "", lines("lineItemTotal"), lineItemWTLength)
					slidwot = slidwot & rtfFormatLineItems(lines("quantity"), lines("itemName"), lines("notes"), "", "", lineItemWOTLength)
				end if
				lines.MoveNext
			wend
			slidwt = slidwt & "\pard\par"
			slidwot = slidwot & "\pard\par"

			'Response.Write(lidwt & nl & nl & nl)
			'Response.Write(lidwot & nl & nl & nl)
		end if
	end Sub



	Sub rtfFormatCouponDetails(lines)
		'Function to Format the Coupons

		lines.Filter = "itemType = 'CU' OR itemType = 'PR'"
		if lines.RecordCount > 0 then
			coup = lineItemStrWT
			lines.MoveFirst
			while not lines.EOF
				coup = coup & rtfFormatLineItems(" ", lines("itemName"), lines("notes"), "", -CDbl(lines("lineItemTotal")), lineItemWTLength)
				lines.MoveNext
			wend
			coup = coup & "\pard\par"
		end if
	end Sub

	function getDiscountTotal(lines)
		dim result
		result = 0
		lines.Filter = "itemType = 'CU' OR itemType = 'PR'"
		if lines.RecordCount > 0 then
			lines.MoveFirst
			while not lines.EOF
				result = result + CDbl(lines("lineItemTotal"))
				lines.MoveNext
			wend
		end if
		getDiscountTotal = CDbl(result)
	end function





	Sub rtfFormatDueDates(lines)
		dim prevDeptName

		prevDeptName = ""

		lines.sort = "deptName, lineNumber"

		if lines.RecordCount > 0 then
			lines.MoveFirst

			while not lines.EOF

				if prevDeptName <> lines("deptName") then
					dim deptLine


					deptLine = rtfFormatLineItems("\b " & Pad(lines("deptName"), 23, ALIGN_LEFT) & Pad(getDeptDueDate(lines, lines("deptName")), 10, ALIGN_RIGHT) & "\b0 ", "", "", "", "", lineItemWTLength)
					duedates = duedates & deptLine
					prevDeptName = lines("deptName")
				end if

				lines.MoveNext
			wend

			duedates = duedates & " \pard "
		end if
	end Sub

	function getDeptNotes(departmentID)
		dim query, rs


		if departmentID <> "" then
			query = " select notes from department where departmentid = " & departmentID & " and notes is not null "

			set rs = getdisconnectedrecordset(query)

			if rs.recordcount > 0 then
				getDeptNotes = rs("notes")
			end if

			set rs = nothing
		end if
	end function


	Sub htmlFormatGroupDetails(InvoiceObject, lines, cloneRst)
		Dim gdwcpLine
		Dim gdwocpLine
		Dim gdwuLine
		Dim gdwuwotLine

		dim deparmentNotes
		Dim prevDeptName
		dim colors, patterns, upcharges, brands
		dim lineDesc
		dim price
		dim alldescriptors

		on error resume next

		prevDeptName = ""

		lines.sort = "deptName, lineNumber"

		if lines.RecordCount > 0 then
			lines.MoveFirst


			while not lines.EOF

				if prevDeptName <> lines("deptName") then
					dim deptLine
					dim deptLineND

					dim deptQty

					if lines("itemType") = "DE" then
						deptQty = lines("quantity") & " "
					else
						deptQty = ""
					end if

					deptLine = "<b>" & Pad(deptQty & lines("deptName"), 23, ALIGN_LEFT) & _
					    "<div style='float: right'>" & Pad(getDeptDueDate(lines, lines("deptName")), 10, ALIGN_RIGHT) & "</div></b><br />"

					deptLineND = Pad(deptQty & lines("deptName"), 23, ALIGN_LEFT)

					departmentNotes = getDeptNotes(lines("deptId"))

					if departmentNotes <> "" then
						deptLine = deptLine & "\b " & replace(departmentNotes, vbcrlf, " <br /> ") & "<br /> "
						deptLineND = deptLine & "\b " & replace(departmentNotes, vbcrlf, " <br /> ") & "<br />"
					end if

					gdwocp = gdwocp & deptLine
					gdwcp = gdwcp & deptLine
					gdwu = gdwu & deptLine
					gdwuwot = gdwuwot & deptLine
					gdwund = gdwund & deptLineND
					gddo = gddo & deptLine

					gdwocp80 = gdwocp80 & deptLine & "<br /> " & deptLine & "<br /> "
					gdwcp80 = gdwcp80 & deptLine & "&#160;&#160;&#160;&#160;&#160;&#160;" & deptLine & "<br /> "
					gdwu80 = gdwu80 & deptLine & "&#160;&#160;&#160;&#160;&#160;&#160;" & deptLine & "<br /> "

					if lines("notes") <> "" and lines("itemType") = "DE" then
						gdwocp = gdwocp &  "&#160;&#160;&#160;&#160;&#160;&#160;" & WordWrap(lines("notes"), lineItemWTLength, "\par &#160;&#160;&#160; ")& "<br /> "
						gdwcp = gdwcp &  "&#160;&#160;&#160;&#160;&#160;&#160;" & WordWrap(lines("notes"), lineItemWTLength, "\par &#160;&#160;&#160; ")& "<br /> "
						gdwu = gdwu &  "&#160;&#160;&#160;&#160;&#160;&#160;" & WordWrap(lines("notes"), lineItemWTLength, "\par &#160;&#160;&#160; ")& "<br /> "
						gdwund = gdwund &  "&#160;&#160;&#160;&#160;&#160;&#160;" & WordWrap(lines("notes"), lineItemWTLength, "\par &#160;&#160;&#160; ")& "<br /> "
						gdwuwot = gdwuwot & "&#160;&#160;&#160;&#160;&#160;&#160;" & WordWrap(lines("notes"), lineItemWOTLength, "\par &#160;&#160;&#160; ")& "<br /> "
						gdwocp80 = gdwocp80 &  "&#160;&#160;&#160;&#160;&#160;&#160;" & WordWrap(lines("notes"), lineItemWTLength, "\par &#160;&#160;&#160; ")& "<br /> "
						gdwcp80 = gdwcp80 &  "&#160;&#160;&#160;&#160;&#160;&#160;" & WordWrap(lines("notes"), lineItemWTLength, "\par &#160;&#160;&#160; ")& "<br /> "
						gdwu80 = gdwu80 &  "&#160;&#160;&#160;&#160;&#160;&#160;" & WordWrap(lines("notes"), lineItemWTLength, "\par &#160;&#160;&#160; ")& "<br /> "
					end if

					prevDeptName = lines("deptName")
				else

					if lines("itemType") = "IT" then

						colors = ""
						patterns = ""
						upcharges = ""
						brands = ""
						price = lines("lineItemTotal")

						cloneRst.filter = "parentLineNumber = " & lines("lineNumber").Value

						if cloneRst.RecordCount > 0 then
							cloneRst.sort = "lineNumber"
							cloneRst.MoveFirst
							while not cloneRst.EOF
								if cloneRst("itemType") = "CO" then
									colors = AppendWD(", ", colors, formatItemQty(cloneRst("quantity")) & " " & cloneRst("itemName"))
									if cloneRst("notes") <> "" then colors = colors & " (" & cloneRst("notes") & ")"
								elseif cloneRst("itemType") = "PA" then
									patterns = AppendWD(", ", patterns, formatItemQty(cloneRst("quantity")) & " " & cloneRst("itemName"))
									if cloneRst("notes") <> "" then patterns = patterns & " (" & cloneRst("notes") & ")"
								elseif cloneRst("itemType") = "UP" then
									upcharges = AppendWD(", ", upcharges, formatItemQty(cloneRst("quantity")) & " " & cloneRst("itemName"))
									if cloneRst("notes") <> "" then upcharges = upcharges & " (" & cloneRst("notes") & ")"
								elseif cloneRst("itemType") = "BR" then
									brands = AppendWD(", ", brands, formatItemQty(cloneRst("quantity")) & " " & cloneRst("itemName"))
									if cloneRst("notes") <> "" then brands = brands & " (" & cloneRst("notes") & ")"
								end if

								alldescriptors = AppendWD(", ", alldescriptors, formatItemQty(cloneRst("quantity")) & " " & cloneRst("itemName"))
								if cloneRst("notes") <> "" then alldescriptors = alldescriptors & " (" & cloneRst("notes") & ")"

								price = price + cloneRst("lineItemTotal")

								cloneRst.MoveNext
							wend
							cloneRst.Filter = ""
						end if

						price = formatnumber(price, 2)

						lineDesc = lines("itemName")

						gdwocpLine = htmlFormatLineItems(lines("quantity"), _
						lineDesc, _
						(lines("notes")) & " " & lines("promptResponse"), lines("penotes"), price, lineItemWTLength)

						lineDesc = AppendWD(", ", lineDesc, colors)
						lineDesc = AppendWD(", ", lineDesc, patterns)
						lineDesc = AppendWD(", ", lineDesc, brands)

						gdwcpLine = htmlFormatLineItems(lines("quantity"), _
						lineDesc, _
						(lines("notes")) & " " & lines("promptResponse"), lines("penotes"), price, lineItemWTLength)

						lineDesc = AppendWD(", ", lineDesc, upcharges)

						gdwuLine = htmlFormatLineItems(lines("quantity"), _
						AppendWD(", ", trim(lines("itemName") & " " & InvoiceObject.getHeatSealId(lines("lineNumber"))), alldescriptors), _
						(lines("notes")) & " " & lines("promptResponse"), lines("penotes"), price, lineItemWTLength)

						gdwuwotLine = htmlFormatLineItems(lines("quantity"), _
						AppendWD(", ", lines("itemName"), alldescriptors), _
						(lines("notes")) & " " & lines("promptResponse"), lines("penotes"), "", lineItemWOTLength)

						alldescriptors = ""

						gdwcp = gdwcp & gdwcpLine
						gdwocp = gdwocp & gdwocpLine
						gdwu = gdwu & gdwuLine
						gdwuwot = gdwuwot & gdwuwotLine
						gdwund = gdwund & gdwuLine
						gdwung = gdwung & gdwcpLine

						gdwcp80 = gdwcp80 & gdwcpLine & "&#160;&#160;&#160;&#160;&#160;&#160;" & gdwcpLine & "<br /> "
						gdwocp80 = gdwocp80 & gdwocpLine & "&#160;&#160;&#160;&#160;&#160;&#160;" & gdwocpLine & "<br /> "
						gdwu80 = gdwu80 & gdwuLine & "&#160;&#160;&#160;&#160;&#160;&#160;" & gdwuLine & "<br /> "

						gdwung80 = gdwung80 & gdwuLine & "&#160;&#160;&#160;&#160;&#160;&#160;" & gdwuLine & "<br /> "

					elseif lines("itemType") = "AC" or lines("itemType") = "CU" or lines("itemType") = "PR" or lines("itemType") = "VI"  then

						dim lineTotal
						dim quantity
						dim thisLine

						lineTotal = lines("lineItemTotal")
						quantity = lines("quantity")

						if lines("itemType") <> "AC" then
							lineTotal = -lineTotal
							quantity = ""
						end if

						thisLine = htmlFormatLineItems(quantity, lines("itemName"), lines("notes"), "", lineTotal, lineItemWTLength)

						gdwcp = gdwcp & thisLine
						gdwocp = gdwocp & thisLine
						gdwu = gdwu & thisLine
						gdwuwot = gdwuwot & thisLine
						gdwund = gdwund & gdwuLine

						thisLine= Left(thisLine, Len(thisLine) - Len("\par" & nl))

						gdwcp80 = gdwcp80 & thisLine & "&#160;&#160;&#160;&#160;&#160;&#160;" & thisLine & "<br /> "
						gdwocp80 = gdwocp80 & thisLine & "&#160;&#160;&#160;&#160;&#160;&#160;" & thisLine & "<br /> "
						gdwu80 = gdwu80 & thisLine & "&#160;&#160;&#160;&#160;&#160;&#160;" & thisLine & "<br /> "

					end if


					lines.MoveNext
				end if

			wend

		end if
	end Sub



	Sub rtfFormatGroupDetails2(InvoiceObject, lines, cloneRst)
		Dim gdwcpLine
		Dim gdwocpLine
		Dim gdwuLine
		Dim gdwuwotLine

		dim deparmentNotes
		Dim prevDeptName
		dim colors, patterns, upcharges, brands
		dim lineDesc
		dim price
		dim alldescriptors

		on error resume next

		prevDeptName = ""

		lines.sort = "deptName, lineNumber"

		if lines.RecordCount > 0 then
			lines.MoveFirst


			while not lines.EOF

				if prevDeptName <> lines("deptName") then
					dim deptLine
					dim deptLineND

					dim deptQty

					if lines("itemType") = "DE" then
						deptQty = lines("quantity") & " "
					else
						deptQty = ""
					end if

					deptLine = rtfFormatLineItems("\b " & Pad(deptQty & lines("deptName"), 23, ALIGN_LEFT) & Pad(getDeptDueDate(lines, lines("deptName")), 10, ALIGN_RIGHT) & "\b0 ", "", "", "", "", lineItemWTLength)
					deptLineND = rtfFormatLineItems("\b " & Pad(deptQty & lines("deptName"), 23, ALIGN_LEFT) & "\b0 ", "", "", "", "", lineItemWTLength)

					deparmentNotes = getDeptNotes(lines("deptId"))

					if deparmentNotes <> "" then
						deptLine = deptLine & "\b " & replace(deparmentNotes, vbcrlf, " \par ") & "\par \b0 " & nl
						deptLineND = deptLine & "\b " & replace(deparmentNotes, vbcrlf, " \par ") & "\par \b0 " & nl
					end if

					gdwocp = gdwocp & deptLine
					gdwcp = gdwcp & deptLine
					gdwu = gdwu & deptLine
					gdwuwot = gdwuwot & deptLine
					gdwund = gdwund & deptLineND
					gddo = gddo & deptLine

					'trim off the nl AND \par
					'this is VERY dependant on the return of rtfFormatLineItems
					deptLine = Left(deptLine, Len(deptLine) - Len("\par" & nl))

					gdwocp80 = gdwocp80 & deptLine & "\tab " & deptLine & "\par" & nl
					gdwcp80 = gdwcp80 & deptLine & "\tab " & deptLine & "\par" & nl
					gdwu80 = gdwu80 & deptLine & "\tab " & deptLine & "\par" & nl

					if lines("notes") <> "" and lines("itemType") = "DE" then
						gdwocp = gdwocp &  "\tab " & WordWrap(lines("notes"), lineItemWTLength, "\par \tab ") & "\par" & nl
						gdwcp = gdwcp &  "\tab " & WordWrap(lines("notes"), lineItemWTLength, "\par \tab ") & "\par" & nl
						gdwu = gdwu &  "\tab " & WordWrap(lines("notes"), lineItemWTLength, "\par \tab ") & "\par" & nl
						gdwund = gdwund &  "\tab " & WordWrap(lines("notes"), lineItemWTLength, "\par \tab ") & "\par" & nl
						gdwuwot = gdwuwot & "\tab " & WordWrap(lines("notes"), lineItemWOTLength, "\par \tab ") & "\par" & nl
						gdwocp80 = gdwocp80 &  "\tab " & WordWrap(lines("notes"), lineItemWTLength, "\par \tab ") & "\par" & nl
						gdwcp80 = gdwcp80 &  "\tab " & WordWrap(lines("notes"), lineItemWTLength, "\par \tab ") & "\par" & nl
						gdwu80 = gdwu80 &  "\tab " & WordWrap(lines("notes"), lineItemWTLength, "\par \tab ") & "\par" & nl
					end if

					prevDeptName = lines("deptName")
				else

					if lines("itemType") = "IT" then

						colors = ""
						patterns = ""
						upcharges = ""
						brands = ""
						price = lines("lineItemTotal")

						cloneRst.filter = "parentLineNumber = " & lines("lineNumber").Value

						if cloneRst.RecordCount > 0 then
							cloneRst.sort = "lineNumber"
							cloneRst.MoveFirst
							while not cloneRst.EOF
								if cloneRst("itemType") = "CO" then
									colors = AppendWD(", ", colors, formatItemQty(cloneRst("quantity")) & " " & cloneRst("itemName"))
									if cloneRst("notes") <> "" then colors = colors & " (" & cloneRst("notes") & ")"
								elseif cloneRst("itemType") = "PA" then
									patterns = AppendWD(", ", patterns, formatItemQty(cloneRst("quantity")) & " " & cloneRst("itemName"))
									if cloneRst("notes") <> "" then patterns = patterns & " (" & cloneRst("notes") & ")"
								elseif cloneRst("itemType") = "UP" then
									upcharges = AppendWD(", ", upcharges, formatItemQty(cloneRst("quantity")) & " " & cloneRst("itemName"))
									if cloneRst("notes") <> "" then upcharges = upcharges & " (" & cloneRst("notes") & ")"
								elseif cloneRst("itemType") = "BR" then
									brands = AppendWD(", ", brands, formatItemQty(cloneRst("quantity")) & " " & cloneRst("itemName"))
									if cloneRst("notes") <> "" then brands = brands & " (" & cloneRst("notes") & ")"
								end if

								alldescriptors = AppendWD(", ", alldescriptors, formatItemQty(cloneRst("quantity")) & " " & cloneRst("itemName"))
								if cloneRst("notes") <> "" then alldescriptors = alldescriptors & " (" & cloneRst("notes") & ")"

								price = price + cloneRst("lineItemTotal")

								cloneRst.MoveNext
							wend
							cloneRst.Filter = ""
						end if

						price = formatnumber(price, 2)

						lineDesc = lines("itemName")

						gdwocpLine = rtfFormatLineItems(lines("quantity"), _
						lineDesc, _
						(lines("notes")) & " " & lines("promptResponse"), lines("penotes"), price, lineItemWTLength)

						lineDesc = AppendWD(", ", lineDesc, colors)
						lineDesc = AppendWD(", ", lineDesc, patterns)
						lineDesc = AppendWD(", ", lineDesc, brands)

						gdwcpLine = rtfFormatLineItems(lines("quantity"), _
						lineDesc, _
						(lines("notes")) & " " & lines("promptResponse"), lines("penotes"), price, lineItemWTLength)

						lineDesc = AppendWD(", ", lineDesc, upcharges)

						gdwuLine = rtfFormatLineItems(lines("quantity"), _
						AppendWD(", ", trim(lines("itemName") & " " & InvoiceObject.getHeatSealId(lines("lineNumber"))), alldescriptors), _
						(lines("notes")) & " " & lines("promptResponse"), lines("penotes"), price, lineItemWTLength)

						gdwuwotLine = rtfFormatLineItems(lines("quantity"), _
						AppendWD(", ", lines("itemName"), alldescriptors), _
						(lines("notes")) & " " & lines("promptResponse"), lines("penotes"), "", lineItemWOTLength)

						alldescriptors = ""

						gdwcp = gdwcp & gdwcpLine
						gdwocp = gdwocp & gdwocpLine
						gdwu = gdwu & gdwuLine
						gdwuwot = gdwuwot & gdwuwotLine
						gdwund = gdwund & gdwuLine
						gdwung = gdwung & gdwcpLine

						'trim off the nl AND \par
						'this is VERY dependant on the return of rtfFormatLineItems
						gdwcpLine = Left(gdwcpLine, Len(gdwcpLine) - Len("\par" & nl))
						gdwocpLine = Left(gdwocpLine, Len(gdwocpLine) - Len("\par" & nl))
						gdwuLine = Left(gdwuLine, Len(gdwuLine) - Len("\par" & nl))
						gdwuwotLine = Left(gdwuwotLine, Len(gdwuwotLine) - Len("\par" & nl))

						gdwcp80 = gdwcp80 & gdwcpLine & "\tab " & gdwcpLine & "\par" & nl
						gdwocp80 = gdwocp80 & gdwocpLine & "\tab " & gdwocpLine & "\par" & nl
						gdwu80 = gdwu80 & gdwuLine & "\tab " & gdwuLine & "\par" & nl

						gdwung80 = gdwung80 & gdwuLine & "\tab " & gdwuLine & "\par" & nl

					elseif lines("itemType") = "AC" or lines("itemType") = "CU" or lines("itemType") = "PR" or lines("itemType") = "VI"  then

						dim lineTotal
						dim quantity
						dim thisLine

						lineTotal = lines("lineItemTotal")
						quantity = lines("quantity")

						if lines("itemType") <> "AC" then
							lineTotal = -lineTotal
							quantity = ""
						end if

						thisLine = rtfFormatLineItems(quantity, lines("itemName"), lines("notes"), "", lineTotal, lineItemWTLength)

						gdwcp = gdwcp & thisLine
						gdwocp = gdwocp & thisLine
						gdwu = gdwu & thisLine
						gdwuwot = gdwuwot & thisLine
						gdwund = gdwund & gdwuLine

						thisLine= Left(thisLine, Len(thisLine) - Len("\par" & nl))

						gdwcp80 = gdwcp80 & thisLine & "\tab " & thisLine & "\par" & nl
						gdwocp80 = gdwocp80 & thisLine & "\tab " & thisLine & "\par" & nl
						gdwu80 = gdwu80 & thisLine & "\tab " & thisLine & "\par" & nl

					end if


					lines.MoveNext
				end if

			wend


			zgdwu = lineItemStrZWT & GDWU2ZGDWU(gdwu) & "\pard"
			wgdwu = lineItemStrZWT & gdwu & "\pard"

			gdwcp = lineItemStrWT & gdwcp & "\pard"
			gdwocp = lineItemStrWT & gdwocp & "\pard"
			gdwu = lineItemStrWT & gdwu & "\pard"
			gdwou = lineItemStrWT & gdwocp
			gdwung = lineItemStrWT & gdwung & "\pard"
			gdwuwot = lineItemStrWOT & gdwuwot & "\pard"

			gddo = lineItemStrWT & gddo & "\pard"

			gdwund = lineItemStrWT & gdwund & "\pard"

			gdwcp80 = lineItemStrWT & gdwcp80 & "\pard"
			gdwocp80 = lineItemStrWT & gdwocp80 & "\pard"
			gdwu80 = lineItemStrWT & gdwu80 & "\pard"
			gdwou80 = lineItemStrWT & gdwocp80
			gdwung80 = lineItemStrWT & gdwung80 & "\pard"

		end if
	end Sub


	' tables and page breaks dont seem to work in richtx32.ocx
	function GDWU2ZGDWU(gdwu)
		dim result
		dim lines
		dim idx
		dim linesToBreak
		dim linesRemaining
		dim footerSpaced


		lines = split(gdwu, "\par")

		linesToBreak = 0

		for idx = lbound(lines) to ubound(lines)
			linesRemaining = ubound(lines) - idx + 1

			if linesToBreak <= 0 then

				if idx > lbound(lines) then
					result = result & "\par\par\par"

					if linesRemaining > 29 then
						linesToBreak = 48
						footerSpaced = false
					else
						linesToBreak = 29
						footerSpaced = true
					end if
				else

					if linesRemaining > 13 then
						linesToBreak = 32
						footerSpaced = false
					else
						linesToBreak = 13
						footerSpaced = true
					end if
				end if

			end if



			result = result & lines(idx)
			if idx <> ubound(lines) then result = result & "\par "

			linesToBreak = linesToBreak - 1
		next

		if not footerSpaced then
			result = result & "\par\par\par"
			linesToBreak = 44
		end if

		while linesToBreak > 0

			result = result & " \par"
			linesToBreak = linesToBreak - 1
		wend

		GDWU2ZGDWU = result
	end function




	sub CreateRackDetails()
		dim query, rs
		rackdetails = "\viewkind4\uc1\pard\tx600\tx800\tx1200\tx1850\tx2550 "
		racksummary = "\viewkind4\uc1\pard\tx1000\tx2000 "

		query = "select left(convert(varchar, t.createddate, 10), 5) as dateIn, dbo.getTotalPieces(t.ticketNumber, null) as pcnt, dbo.pivotTicketDepartments(t.ticketnumber, ',') as depts, t.invoicenumber, dbo.pivotTicketRackLocationBrief(t.ticketnumber, ', ') as racks, (t.invoicetotal - t.amountpaid) as amt "
		query = query & " from ticket t "
		query = query & " where t.ticketnumber in (" & pickupTickets & ")"
		query = query & " order by case dbo.isint(dbo.pivotTicketRackLocationBrief(t.ticketnumber, ', ')) when 0 then 0 else cast(dbo.pivotTicketRackLocationBrief(t.ticketnumber, ', ') as int) end "

		rackdetails = rackdetails & "DATE" & "\tab "
		rackdetails = rackdetails & "C" & "\tab  "
		rackdetails = rackdetails & "DE" & "\tab  "
		rackdetails = rackdetails & "AMT" & "\tab  "
		rackdetails = rackdetails & "INV" & "\tab  "
		rackdetails = rackdetails & "RACK" & "\par  "

		racksummary = racksummary & "INVOICE" & "\tab "
		racksummary = racksummary & "PIECES" & "\tab "
		racksummary = racksummary & "RACK" & "\par  "

		set rs = getdisconnectedrecordset(query)

		while not (rs.eof or rs.bof)
			'rackdetails = rackdetails & rtfFormatLineItems(rs("invoicenumber"), rs("racks"), "", "", rs("invoicetotal"), lineItemWTLength)

			rackdetails = rackdetails & trim(rs("dateIn")) & "\tab "
			rackdetails = rackdetails & trim(rs("pcnt")) & "\tab  "
			rackdetails = rackdetails & trim(convertDeptNameToInitial(rs("depts"))) & "\tab  "
			rackdetails = rackdetails & trim(formatnumber(rs("amt"), 2)) & "\tab  "
			rackdetails = rackdetails & trim(rs("invoicenumber")) & "\tab  "
			rackdetails = rackdetails & trim(rs("racks")) & "\par  "

			racksummary = racksummary & trim(rs("invoicenumber")) & "\tab  "
			racksummary = racksummary & trim(rs("pcnt")) & "\tab  "
			racksummary = racksummary & trim(rs("racks")) & "\par  "

			rs.movenext
		wend

		rackdetails = rackdetails & "\pard"
		racksummary = racksummary & "\pard"

		set rs = nothing
	end sub







	Sub rtfFormatTaxDetails(lines)
		'Function to Format the tax
		lines.Filter = ""
		lines.Filter = "itemType = 'TA'"
		if lines.RecordCount > 0 then
			Dim taxCode
			Dim numericTax1
			Dim numericTax2
			Dim numericTax3
			Dim numericTax4
			Dim numericTax5
			Dim numericTax6
			Dim numericTax7
			Dim numericTax8
			Dim numericTax9
			Dim numericTax10
			Dim numericTaxTotal

			numericTax1 = 0.0
			numericTax2 = 0.0
			numericTax3 = 0.0
			numericTax4 = 0.0
			numericTax5 = 0.0
			numericTax6 = 0.0
			numericTax7 = 0.0
			numericTax8 = 0.0
			numericTax9 = 0.0
			numericTax10 = 0.0
			numericTaxTotal = 0

			lines.MoveFirst

			while not lines.EOF
				taxCode = lines("lineItemID")
				if lines("lineItemTotal") <> "" then
					numericTaxTotal = csng(lines("lineItemTotal"))
				else
					numericTaxTotal = 0.0
				end if

				select case taxCode
					case "1"
						numericTax1 = numericTax1 + numericTaxTotal
					case "2"
						numericTax2 = numericTax2 + numericTaxTotal
					case "3"
						numericTax3 = numericTax3 + numericTaxTotal
					case "4"
						numericTax4 = numericTax4 + numericTaxTotal
					case "5"
						numericTax5 = numericTax5 + numericTaxTotal
					case "6"
						numericTax6 = numericTax6 + numericTaxTotal
					case "7"
						numericTax7 = numericTax7 + numericTaxTotal
					case "8"
						numericTax8 = numericTax8 + numericTaxTotal
					case "9"
						numericTax9 = numericTax9 + numericTaxTotal
					case "10"
						numericTax10 = numericTax10 + numericTaxTotal
				end select

				taxTot = taxTot + numericTaxTotal
				lines.MoveNext
			wend
				tax1 = FormatNumber(numericTax1,2,true)
				tax2 = FormatNumber(numericTax2,2,true)
				tax3 = FormatNumber(numericTax3,2,true)
				tax4 = FormatNumber(numericTax4,2,true)
				tax5 = FormatNumber(numericTax5,2,true)
				tax6 = FormatNumber(numericTax6,2,true)
				tax7 = FormatNumber(numericTax7,2,true)
				tax8 = FormatNumber(numericTax8,2,true)
				tax9 = FormatNumber(numericTax9,2,true)
				tax10 = FormatNumber(numericTax10,2,true)
				taxTot = FormatNumber(taxTot,2,true)
		end if
	end Sub


	Sub rtfFormatSurchargeDetails(lines)
		'Function to Format the Surcharge
		lines.Filter = ""
		lines.Filter = "itemType = 'SU'"

		sc1 = "0.00"
		sc2 = "0.00"
		subtotws = subtot

		if lines.RecordCount > 0 then
			Dim scCode
			Dim numericSc1
			Dim numericSc2
			Dim sc1Desc
			Dim sc2Desc
			Dim numericScTotal

			numericSc1 = 0.0
			numericSc2 = 0.0

			lines.MoveFirst

			while not lines.EOF
				scCode = lines("lineItemID")
				if lines("lineItemTotal") <> "" then
					numericScTotal = csng(lines("lineItemTotal"))
				else
					numericScTotal = 0.0
				end if
				select case ScCode
					case "1"
						numericSc1 = numericSc1 + numericScTotal
						sc1Desc = lines("itemName")
					case "2"
						numericSc2 = numericSc2 + numericScTotal
						sc2Desc = lines("itemName")
				end select
				lines.MoveNext
			wend
				sc1 = FormatNumber(numericSc1,2,true)
				sc2 = FormatNumber(numericSc2,2,true)
				sctot = FormatNumber(numericSc1 + numericSc2,2,true)
				subtotws = FormatNumber(subtot + numericSc1 + numericSc2,2,true)
		end if
	end Sub


	function getTicketPaymentName(ticketNumber)
		dim query, rs

		if ticketNumber <> "" then
			query = " select distinct payment.paymenttypename "
			query = query & " from payment "
			query = query & " inner join paymenttracking on "
			query = query & " payment.paymentnumber = paymenttracking.sourcerefnumber "
			query = query & " and paymenttracking.sourcereftype = 'PA' "
			query = query & " where "
			query = query & " paymenttracking.targetreftype = 'TI' "
			query = query & " and paymenttracking.targetrefnumber = " & ticketNumber

			set rs = getdisconnectedrecordset(query)

			if rs.recordcount = 1 then
				getTicketPaymentName = ucase(rs("paymenttypename"))
			elseif rs.recordcount > 1 then
				getTicketPaymentName = "MIX"
			else
				getTicketPaymentName = "NONE"
			end if

			set rs = nothing
		end if
	end function

	function getInvoiceNumber(ticketNumber)
		dim query, rs
		dim result

		query = " select invoicenumber from ticket where ticketnumber = " & ticketNumber

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getInvoiceNumber = rs("invoicenumber")
			rs.movenext
		end if


		set rs = nothing
	end function

	Sub getPaymentDetails(tNum, prePayOrPickup, invoiceTotalAmount, TypeOfObject)
		'Function to get payment details, given the TicketNumber
		Dim paySql
		Dim payRst
		Dim pmtTypeName
		Dim amountTendered
		Dim amountPaid
		Dim changeDue
		Dim totalAmountPaid
		Dim onAccountAmount
		Dim earlyPayDiscount
		Dim creditsApplied




		amountTendered = 0.0
		totalAmountPaid = 0.0
		onAccountAmount = 0.0
		earlyPayDiscount = 0.0
		creditsApplied = 0.0

		totalAmountPaid = TypeOfObject.getAmountPaid()

		baldue = FormatNumber(invoiceTotalAmount - totalAmountPaid - prePayDiscount,2,True)

		apaid = FormatNumber(totalAmountPaid,2,true)
		totpay = apaid

		paytyp = AppendWD(", ", paytyp, getTicketPaymentName(tNum))

		paymentDetails = paymentDetails & getPaymentDetailsRTF(tNum)


		dim tipQuery, tipRs, tipAmt
		tipQuery = "select sum(tipAmt) totalTip from EmployeeTip where Added = 1 and ticketNumber in (" & ticketNo & ")"
		Set tipRs = getDisconnectedRecordset(tipQuery)
		tipAmt = tipRs("totalTip")
		if tipAmt > 0 then
		    employeeTip = FormatNumber(tipAmt, 2, true)
            totpay = FormatNumber((CDbl(totpay) + CDbl(tipAmt)), 2, true)
        end if

	end Sub


	function getPaymentDetailsRTF(ticketNumber)
		dim query, rs
		dim result
		dim invoiceNumber

		invoiceNumber = getInvoiceNumber(ticketNumber)

		query = " select paymenttracking.amountapplied, "
		query = query & " payment.paymenttypename "
		query = query & " from paymenttracking "
		query = query & " inner join payment on paymenttracking.sourcerefnumber = payment.paymentnumber "
		query = query & " where paymenttracking.sourcereftype = 'PA' and targetreftype = 'TI' "
		query = query & " and paymenttracking.targetrefnumber = " & ticketNumber
		query = query & " order by paymenttracking.createddate asc "

		set rs = getdisconnectedrecordset(query)

		while not (rs.eof or rs.bof)
			result = result	& rtfFormatTotals(totalsTab, invoiceNumber & " " & rs("paymenttypename"), formatcurrency(rs("amountapplied")))
			rs.movenext
		wend

		getPaymentDetailsRTF = result

		set rs = nothing
	end function

	Function getAccountBalance(ticketNo)
		'Function to get Customer Account Balance, given Customer Sequence Number
		Dim balSql
		Dim balRst
		Dim custBalance
		Dim customerSeqNumber

		custBalance = 0.0
		customerSeqNumber = getCustomerSeqNumber(ticketNo)

		balSql = "exec dbo.getcustomeraccountbalance " & customerSeqNumber
		set balRst = getDisconnectedRecordset(balSql)

		if not balRst is nothing and not balRst.EOF then
			balRst.MoveFirst
			if balRst.Fields("accountBalance").Value <> "" then
				custBalance = csng(balRst.Fields("accountBalance").Value)
			end if

			balRst.Close
		end if
		getAccountBalance = custBalance
	end Function


	Function getCustomerSeqNumber(ticketNo)
		'Function to get Customer Account Balance, given Customer Sequence Number
		Dim custSql
		Dim custRst
		Dim customerSeqNumber

		customerSeqNumber = 0

		custSql = "SELECT customerSequenceNumber from Customer C, TicketCustomer TC  " _
				& " WHERE TC.ticketNumber = " & ticketNo & " AND C.customerID = TC.customerID "
		set custRst = getDisconnectedRecordset(custSql)

		if not custRst is nothing and not custRst.EOF then
			custRst.MoveFirst
			if custRst.Fields("customerSequenceNumber").Value <> "" then
				customerSeqNumber = clng(custRst.Fields("customerSequenceNumber").Value)
			end if

			custRst.Close
		end if
		getCustomerSeqNumber = customerSeqNumber
	end Function

	Function RemoveHTMLLinks(byval a_str)
	    Dim s_begin, s_end
	    Dim s_len

	    s_len = Len(a_str)

	    s_begin = InStr(1, a_str, "<a")

	    Do While s_begin > 0
	        s_end = InStr(s_begin, a_str, "</a>")

	        If s_end > 0 Then
	            a_str = Left(a_str, s_begin - 1) & Right(a_str, s_len - s_end - 3)
	            s_len = Len(a_str)
	            s_end = s_begin
	            s_begin = InStr(s_end, a_str, "<a")
	        Else
	            s_begin = 0
	        End If
	    Loop

	    a_str = Replace(a_str, "&nbsp", " ")

	    RemoveHTMLLinks = a_str
	End Function




Function htmlFormatLineItems(itemQuantity, itemName, itemNotes, priceEditorNotes, itemTotal, itemWrapLength)
	itemQuantity = trim(itemQuantity)
	itemName = trim(itemName)
	itemNotes = trim(itemNotes)
	priceEditorNotes = trim(priceEditorNotes)
	itemTotal = trim(itemTotal)
	itemWrapLength = clng(itemWrapLength)

	if itemNotes <> "" then
		itemNotes = RemoveHTMLLinks(itemNotes)
		itemNotes = "<br />" & WordWrap(itemNotes, itemWrapLength, "")
	end if


	if priceEditorNotes <> "" then
		itemNotes = itemNotes &  "<br />" & WordWrap(priceEditorNotes, itemWrapLength, "")
	end if

	if itemTotal <> "" then
		htmlFormatLineItems = itemQuantity & "&#160;&#160;&#160;&#160;&#160;&#160;" _
		& WordWrap(itemName, itemWrapLength, "") & itemNotes _
		& "<div style='float: right'>" & Pad(FormatNumber(itemTotal,2, true), priceStringLength, ALIGN_RIGHT) _
		& "</div><br />"
	else
		htmlFormatLineItems = itemQuantity & "&#160;&#160;&#160;&#160;&#160;&#160;" _
		& WordWrap(itemName, itemWrapLength, "") & itemNotes _
		& "<br />"
	end if

End Function



Function rtfFormatLineItems(itemQuantity, itemName, itemNotes, priceEditorNotes, itemTotal, itemWrapLength)
	itemQuantity = trim(itemQuantity)
	itemName = trim(itemName)
	itemNotes = trim(itemNotes)
	priceEditorNotes = trim(priceEditorNotes)
	itemTotal = trim(itemTotal)
	itemWrapLength = clng(itemWrapLength)

	if itemNotes <> "" then
		itemNotes = RemoveHTMLLinks(itemNotes)
		itemNotes = lineDelimeter & WordWrap(itemNotes, itemWrapLength, "\par \tab ")
	end if
	

	if priceEditorNotes <> "" then
		itemNotes = itemNotes & lineDelimeter & WordWrap(priceEditorNotes, itemWrapLength, "\par \tab ")
	end if

	if itemTotal <> "" then
		rtfFormatLineItems = itemQuantity & "\tab " _
		& WordWrap(itemName, itemWrapLength, "\par \tab ") & itemNotes & "\tab " _
		& Pad(FormatNumber(itemTotal,2, true), priceStringLength, ALIGN_RIGHT) _
		& "\par" & nl
	else
		rtfFormatLineItems = itemQuantity & "\tab " _
		& WordWrap(itemName, itemWrapLength, "\par \tab ") & itemNotes _
		& "\par" & nl
	end if

End Function


Function rtfFormatTotals(rtfStartLineString, labelString, amount)
	dim tempStr
	tempStr = rtfStartLineString 
	if labelString <> "" then
		tempStr = tempStr & WordWrap(labelString, scStringLength, "\par ") 
	end if
	tempStr = tempStr & "\tab " & Pad(FormatNumber(amount,2,true), priceStringLength, ALIGN_RIGHT) _
			& "\par" & nl & "\pard "
	rtfFormatTotals = tempStr
End Function

function ExtractDate(iDate)
	ExtractDate = datepart("m", iDate) & "/" & datepart("d", iDate) & "/" & datepart("yyyy", iDate)
end function

sub CreateSignatureForTicket(ticketNumbers)
	dim query, rs
	dim rtf_imgheader, rtf_imgfooter
	
	if trim(ticketNumbers) <> "" then
	
		rtf_imgheader = "{\object\objemb{\*\objclass Paint.Picture}\objw3600\objh855{\*\objdata 01050000020000000700000050427275736800000000000000000000100000" & nl
		rtf_imgfooter =  "00000105000000000000}}" & nl

		query = "select distinct SigBMP, Reason, SignatureDate from signature where ticketnumber in (" & ticketNumbers & ")"
		set rs = getdisconnectedrecordset(query)
			
		signature = ""
			
		while not(rs.eof or rs.bof)
			signature = signature & rtf_imgheader & DecompressString(rs("SigBMP")) & rtf_imgfooter & "\par " & rs("SignatureDate") & " " & rs("Reason")
			rs.movenext
		wend
			
		set rs = nothing
	
	end if

end sub

function selectEmployee(employeeID)
  dim emplsql, emplrs
  
  if employeeId <> "" then
  	emplsql = "SELECT IsNull(firstName, '')firstName, IsNull(middleInitial, '')middleInitial, IsNull(lastName, '')lastName "
  	emplsql = emplsql & " FROM Employee "
  	emplsql = emplsql & " WHERE employeeID = " & employeeId

  	set emplrs = getDisconnectedRecordset(emplsql)
  
  	if not emplrs is nothing and not emplrs.EOF then
  		efn = emplrs("firstName").Value
  		eln = emplrs("lastName").Value
  		efi = emplrs("middleInitial").Value
  		eli = emplrs("middleInitial").Value
  		
  		if len(trim(eln)) > 0 then
  			eli = left(trim(eln), 1)
  			ename = trim(eln)
  		end if
  		
  		if len(trim(efn)) > 0 then
  			efi = left(trim(efn), 1)
  			ename = ename & ", " & trim(efn)
  		end if
			  
  		emplrs.Close
  		set emplrs = nothing
  	end if
	end if
end function


function getWillCall(ticketNumbers)
	dim query, rs
	
	query = " select * from deliverywillcall where ticketnumber in (" & ticketNumbers & ")"
	set rs = getdisconnectedrecordset(query)
	
	if rs.recordcount > 0 then
		willcall = "DELIVERY SCHEDULED"
	end if
	
	set rs = nothing
end function


function isCustomerODCQualified(customerSeq)
	dim query, rs

	query = " select ondemandqualified from customer where customersequencenumber = " & customerSeq & " and ondemandqualified = 1 "

	set rs = getdisconnectedrecordset(query)

	isCustomerODCQualified = rs.recordcount > 0

	set rs = nothing


end function


function getOnDemandCouponLines(customerSeq)
	dim query, rs
	dim odcList
	dim odcAwarded
	dim result
	dim visitCount
	dim totalSales
	dim targetValue
	dim targetPrefix
	
	if not isCustomerODCQualified(customerSeq) then
		exit function
	end if

	query = " select ondemandcoupon.id as odcid, "
	query = query & " discount.discountname, "
	query = query & " cri_condition, cri_required, "
	query = query & " cri_target "
	query = query & " from ondemandcoupon inner join discount on "
	query = query & " ondemandcoupon.cid = discount.discountid "
	query = query & " where ondemandcoupon.enabled = 1 and ondemandcoupon.type = 1"
	
	set odcList = getdisconnectedrecordset(query)
	
	
	query = " select odcid, isnull(max(cri_value), 0) as maxValue "
	query = query & " from ondemandcouponsawarded "
	query = query & " where customersequencenumber = " & customerSeq
	query = query & " group by odcid "
			
	set odcAwarded = getdisconnectedrecordset(query)
	
	query = " select dbo.getCustomerVisits(customersequencenumber, null, null) as visitCount, dbo.getCustomerSales(customersequencenumber, null, null) as totalSales from customer "
	query = query & " where customersequencenumber = " & customerSeq 
			
	set rs = getdisconnectedrecordset(query)
	
	if rs.recordcount > 0 then
		visitCount = rs("visitCount")
		totalSales = rs("totalSales")
	else
		visitCount = 0
		totalSales = 0
	end if
	
	result = odcTabTwips
	
	while not(odcList.eof or odcList.bof)
		odcAwarded.filter = " odcid = " & odcList("odcid")


		
		result = result & odcList("discountname") & "\tab "

		
		if odcAwarded.recordcount > 0 then
			select case trim(odcList("cri_target"))
			case "VISITS"
				result = result & trim(clng(visitCount) - clng(odcAwarded("maxValue")) & "/" & odcList("cri_required"))
			case "DOLLARSSPENT"
				result = result & trim((formatcurrency(cdbl(totalSales) - cdbl(odcAwarded("maxValue"))) & "/" & formatcurrency(odcList("cri_required"))))
			end select

			result = result & "\tab "
		else
			select case trim(odcList("cri_target"))
			case "VISITS"
				result = result & trim(visitCount & "/" & odcList("cri_required"))
			case "DOLLARSSPENT"
				result = result & trim(formatcurrency(totalSales) & "/" & formatcurrency(odcList("cri_required")))
			end select

			result = result & "\tab "
		end if
		
		result = result & "\par " & nl
		
		odcList.movenext
	wend
	
	set odcList = nothing
	set odcAwarded = nothing
	
	getOnDemandCouponLines = result
end function

function findFormName(printerId)
    dim query, rs, answer
    query = "SELECT TOP 1 formName FROM Printer WHERE printerID = " & printerId
    set rs = getdisconnectedrecordset(query)
    answer = rs("formName")

    query = "select triggerValue, TargetValue from PrinterModifier where printerId = " & printerId & " and TriggerSource = 'printgroup'" _
        & " and triggerCriteria = 'ct' and TargetField = 'form'"
    set rs = getdisconnectedrecordset(query)
    if rs.recordcount > 0 then
        dim modifiedGroup, modifiedForm
        modifiedGroup = rs("triggerValue")
        modifiedForm = rs("TargetValue")
        query = "select printgroup from department where departmentId = (select top 1 departmentid from " _
            & "ticketlineItem where ticketNumber = " &  CLng(Request.QueryString("key")) & ")"
        set rs = getdisconnectedrecordset(query)
        if rs.recordcount > 0 then
            if rs("printgroup") = modifiedGroup then
                answer = modifiedForm
            end if
        end if
    end if
    findFormName = answer
end function


%>
