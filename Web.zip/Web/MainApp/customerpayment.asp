<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim isSubmitted 
	dim customerseq
	dim sqltxt
	dim paymentId
	dim paymentTermId
	Dim Accbalance
	dim CreditLimit
	dim paymenttype 
	dim l_storeid
	dim l_temporaryaccount
	dim l_permanentaccount
	dim l_excludeFromAR
	dim l_allowCCBatch
	dim billingCustomerName
	dim parentCustomerName
	dim statementNotes
	dim allowance, useAllowance
	dim l_pickupOnlyOnAccount
	
	dim cc_maskednumber
	dim cc_xcid
	dim cc_expiration
	dim cc_type
	dim cc_zip
	dim cc_allowbatch
	dim use_clearent
	dim cc_url
    dim cc_key
    dim clearentServiceLoc
    dim prompt_batch
	

	l_storeid = session("Storeid")

	if request.querystring("customerseq") <> "" then
		customerseq = request.querystring("customerseq")
	else
		customerseq = session("customersequencenumber")
	end if
	
	session("customersequencenumber") = customerseq
	session("prevcustomersequencenumber") = customerseq
	prompt_batch = getMSVar("promptAfterCCUpdate")
	useAllowance = getMSVar("useAllowance")

	getCustomerPaymentInfo()

	determineProcessor()

	isSubmitted = Request.QueryString("submitted")
	
	if Request.QueryString("useraction") = "clearcommonbilling" then
		clearCommonBillingInfo(customerseq)
	elseif Request.QueryString("useraction") = "clearparentcustomer" then
		clearParentCustomerInfo(customerseq)
	elseif request.querystring("useraction") = "add-card" then
		AddCardOnFile
	elseif request.querystring("useraction") = "update-card" then
		UpdateCardOnFile
	elseif request.querystring("useraction") = "delete-card" then
		DeleteCardOnFile
	elseif request.querystring("useraction") = "enable-batch" then
		SetBatchEnable
	end if
	
	if (isSubmitted ) then
		UpdateDatabase()
	end if
	if Request.QueryString("targetpage") = "customerentry" and Request.QueryString("billingcustomerseq") <> "" then
		UpdateCommonBilling customerseq, Request.QueryString("billingcustomerseq")
	elseif Request.QueryString("targetpage") = "customerentry" and Request.QueryString("parentcustomerseq") <> "" then
		UpdateParentCustomer customerseq, Request.QueryString("parentcustomerseq")
	end if
	paymenttype = "none"

	getCustomerPaymentInfo()


	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function
%>
<HTML>
<HEAD>
<TITLE>Customer Payments</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script type="text/javascript" src="/script/webui.js"></script>
<script type="text/javascript" src="/script/ccp-expresslink.js"></script>
<script type="text/javascript" src="../Script/clearent.js"></script>
<script type="text/javascript" src="../Script/json2.js"></script>
<link href="../style/overlay.css" rel="stylesheet" type="text/css">
<script type="text/javascript">

	function validateField( element){
		if ( !checkInt(element.value)){
			cbs_alert("Please enter ony numeric values");
			//element.value = "";
			element.focus();
			//return false;
			}
		else
		return true;
	
	}
	function submitForm(){

		if(document.customerpaymentform.txtCreditLimit.value == "")
			document.customerpaymentform.txtCreditLimit.value = "0";
			
		if(document.customerpaymentform.txtCreditLimit.value > 0 &&
			document.customerpaymentform.paymentTerms.value == 0)
		{
			if(!confirm("Continue with no terms defined?"))
				return;
		}
		document.customerpaymentform.action="?submitted=true&customerseq=<%=customerseq%>";
		document.customerpaymentform.submit();
	}

	
	function showCommonBillingInfo() {
		if(document.customerpaymentform.txtCreditLimit.value > 0 &&
			document.customerpaymentform.paymentTerms.value == 0)
		{
			if(!confirm("Continue with no terms defined?"))
				return;
		}
		document.customerpaymentform.action="?action=commonbilling&submitted=true&customerseq=<%=customerseq%>";
		document.customerpaymentform.submit();
	}
	function showParentCustomerInfo() {
		if(document.customerpaymentform.txtCreditLimit.value > 0 &&
			document.customerpaymentform.paymentTerms.value == 0)
		{
			if(!confirm("Continue with no terms defined?"))
				return;
		}
		document.customerpaymentform.action="?action=parentcustomer&submitted=true&customerseq=<%=customerseq%>";
		document.customerpaymentform.submit();
	}
	function clearCommonBillingInfo() {
        cbs_confirm("Clear common billing?", gotoClearCommonBilling);
	}

	function gotoClearCommonBilling() {
        clearConfirmMsg();
        document.customerpaymentform.action="?useraction=clearcommonbilling&customerseq=<%=customerseq%>";
        document.customerpaymentform.submit();
	}
	
	function clearParentCustomerInfo() {
        cbs_confirm("Clear commercial billing?", gotoClearParent);
	}

	function gotoClearParent() {
        clearConfirmMsg();
		document.customerpaymentform.action="?useraction=clearparentcustomer&customerseq=<%=customerseq%>";
        document.customerpaymentform.submit();
	}

	function evalPaymentType(){
		i = document.customerpaymentform.paymentType.selectedIndex;
		if (document.customerpaymentform.h_paymenttype.value == "ON ACCOUNT" 
			&& document.customerpaymentform.txtAccountBalance.value != 0 ) {
			cbs_alert("Customer has an outstanding balance. Cannot change payment type")
			totalcount = document.customerpaymentform.paymentType.length 
			j = 0;
	
			while (j < totalcount){
				if (document.customerpaymentform.paymentType(j).value == "ON ACCOUNT"){
					document.customerpaymentform.paymentType.selectedIndex = j
					break;
				}
				j++;
	
			}
		}
		
	}	
	
	function validateDecimal(element){
		if ( ! isNum1(element.value, 0)){
			cbs_alert("Please enter a decimal value");
			element.focus();
		}
	}
	function cancelForm(){
		document.customerpaymentform.action = "\CustomerEntry.asp?mode=edit&customerseq=<%=customerseq%>";
		document.customerpaymentform.submit();
	}

	function clearentTokenFailed(errMsg) {
	    $(':button').attr('disabled', false);
        document.getElementById('cardReader').style.display = 'none';
        if (errMsg)
            cbs_alert(errMsg);
	}

	function askUpdateMethod() {
		    <%if use_clearent then %>
                document.getElementById('updateMethod').style.display = 'block';
    	   <% else %>
    	       beginAddCard();
    	   <% end if %>
	}
	
	function beginAddCard() {
	    <%if use_clearent then %>
            $(':button').attr('disabled', true);
            document.getElementById('cardReader').style.display = 'block';
            createToken('<%=clearentServiceLoc%>', '<%=cc_key%>', '<%=cc_zip%>');
	   <% else %>

		var processor;

		processor = new CreditCardProcessor();

		processor.AddCard({
			success: function(result_obj, params, result) {
				if(result_obj.xcaccountid) {
	                <% if prompt_batch then %>
                        document.getElementById('enableBatch').style.display = 'block';
                        vTokenId = encodeURIComponent(result_obj.xcaccountid);
                        vExpDate = encodeURIComponent(result_obj.account);
                        vAccount = encodeURIComponent(result_obj.expiration);
                        vCardType = encodeURIComponent(result_obj.accounttype);
                    <% else %>
                        document.customerpaymentform.action = "/mainapp/customerpayment.asp?useraction=add-card&customerseq=<%=customerseq%>" +
                            "&xcaccountid=" + encodeURIComponent(result_obj.xcaccountid) +
                            "&account=" + encodeURIComponent(result_obj.account) +
                            "&expiration=" + encodeURIComponent(result_obj.expiration) +
                            "&accounttype=" + encodeURIComponent(result_obj.accounttype);
                        document.customerpaymentform.submit();
                    <% end if %>
				}
				else {
					cbs_alert("Error generating X-Charge Account ID.");
				}
			},
			failure: function(result_obj, params, result) {
				cbs_alert("Error adding card to customer.");
			}
		});
		<% end if %>
	}
	

	
	function beginUpdateCard() {
	    <%if use_clearent then %>
            askUpdateMethod();
	   <% else %>

		var processor;

		processor = new CreditCardProcessor();

		processor.UpdateCard({
			xc_account_id: '<%=cc_xcid%>',
			success: function(result_obj, params, result) {
                document.customerpaymentform.action = "/mainapp/customerpayment.asp?useraction=update-card&customerseq=<%=customerseq%>" +
                    "&expiration=" + encodeURIComponent(result_obj.expiration);
                document.customerpaymentform.submit();
			},
			failure: function(result_obj, params, result) {
				cbs_alert("Error updating customer's card.");
			}
		});
		<% end if %>
	}

    var vTokenId;
    var vExpDate;
    var vAccount;
    var vCardType;
    var deleteFailed = 0;

	function beginUpdateClearentCard(tokenId, expDate, lastFour, cardType) {
	    $(':button').attr('disabled', false);
	    document.getElementById('cardReader').style.display = 'none';
	    <% if prompt_batch then %>
	        document.getElementById('enableBatch').style.display = 'block';
	        vTokenId = tokenId;
	        vExpDate = expDate;
	        vAccount = "XXXXXXXXXXXX" + lastFour;
	        vCardType = cardType;
	    <% else %>
            document.customerpaymentform.action = "?useraction=add-card&customerseq=<%=customerseq%>" +
                "&xcaccountid=" + encodeURIComponent(tokenId) +
                "&account=XXXXXXXXXXXX" + encodeURIComponent(lastFour) +    //We're assuming a 16 digit card for the mask
                "&expiration=" + encodeURIComponent(expDate) +
                "&accounttype=" + encodeURIComponent(cardType);

            document.customerpaymentform.submit();
        <% end if %>
	}

	function endUpdateClearentCard(allowccBatch) {
            document.customerpaymentform.action = "?useraction=add-card&customerseq=<%=customerseq%>" +
                "&xcaccountid=" + encodeURIComponent(vTokenId) +
                "&account=" + encodeURIComponent(vAccount) +
                "&expiration=" + encodeURIComponent(vExpDate) +
                "&accounttype=" + encodeURIComponent(vCardType) +
                 "&allowccbatch=" + encodeURIComponent(allowccBatch);

            document.customerpaymentform.submit();
	}

	function endUpdateCard(allowccbatch) {
        document.customerpaymentform.action = "?useraction=add-card&customerseq=<%=customerseq%>" +
            "&xcaccountid=" + encodeURIComponent(tokenId) +
            "&account=" + encodeURIComponent(vAccount) +    //We're assuming a 16 digit card for the mask
            "&expiration=" + encodeURIComponent(expDate) +
            "&accounttype=" + encodeURIComponent(cardType) +
            "&allowccbatch=" + encodeURIComponent(allowccbatch);

        document.customerpaymentform.submit();
	}
	
	function beginDeleteCard() {
	    <%if use_clearent then %>
            deleteToken('<%=cc_xcid%>', '<%=clearentServiceLoc%>', '<%=cc_key%>');
	    <% else %>
		var processor  = new CreditCardProcessor();

		processor.DeleteCard({
			xc_account_id: '<%=cc_xcid%>',
			success: function(result_obj, params, result) {
                document.customerpaymentform.action = "/mainapp/customerpayment.asp?useraction=delete-card&customerseq=<%=customerseq%>";
                document.customerpaymentform.submit();

			},
			failure: function(result_obj, params, result) {
                cbs_confirm("Error deleting customer's card in X-Charge. Delete in CBS?", gotoClearCard);
			}
		});

		<% end if %>
	}

	function handleClearentDeleteFailure() {
	    deleteFailed = 1;
	    cbs_confirm("Error deleting customer's card in Clearent. Delete in CBS?", gotoClearCard)
	}

	function gotoClearCard() {
        clearConfirmMsg();
        document.customerpaymentform.action = "/mainapp/customerpayment.asp?useraction=delete-card&customerseq=<%=customerseq%>" +
            (deleteFailed == 1 ? "&failedDeleted=1" : "");
            console.log(document.customerpaymentform.action);
        document.customerpaymentform.submit();
	}
	
	function setBatchEnabled(v) {
        document.customerpaymentform.action = "/mainapp/customerpayment.asp?useraction=enable-batch&customerseq=<%=customerseq%>&allowccbatch=" + (v ? 1 : 0);
        document.customerpaymentform.submit();
	}

    var yearSet = false;
	function manualUpdateCard() {
        if (!yearSet) {
            select = document.getElementById('newExpYear');
            var curYear = new Date().getFullYear().toString().substring(2, 4);
            for (var i = 0; i<=7; i++){
                var opt = document.createElement('option');
                opt.value = curYear;
                opt.innerHTML = curYear;
                select.appendChild(opt);
                curYear++;
            }
            yearSet = true;
        }

        document.getElementById('updatedCardInfo').style.display = 'block';
	}

	function createTokenFromData() {
        document.getElementById('updatedCardInfo').style.display = 'none';
	    var cardNumber = document.getElementById("newCardNum").value
	    var expDate = document.getElementById("newExpMonth").value + "" + document.getElementById("newExpYear").value;

	    createTokenWithCardInfo('<%=clearentServiceLoc%>', '<%=cc_key%>', cardNumber, expDate);
	}

	function clearUpdCard() {
        document.getElementById('updatedCardInfo').style.display = 'none';
	}

    function clearMsg() {
        document.getElementById('updateMethod').style.display = 'none';
        document.getElementById('enableBatch').style.display = 'none';
    }

	function goToApplyPayment(){
		document.customerpaymentform.action = "/mainapp/applyPayments.asp?customerseq=<%=customerseq%>&from=cpi";
		document.customerpaymentform.submit();
	}
</SCRIPT>


<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->

<H1>Payment Info</H1>
<div id="cardReader" class="overlay hidden">
  <h1 class="overlayHeader" style="text-align: center">Waiting on Card Reader</h1>
</div>

<div id="updateMethod" class="overlay" style="display: none; text-align: center">
  <h1 style="color: white">Do you wish to update the credit card using the card reader or manually typing in credit card info?</h1>
  <BUTTON style="width: 100px; height: 45px; color: black" onclick="clearMsg();beginAddCard()">Card Reader</BUTTON>
  <BUTTON style="width: 100px; height: 45px; color: black" onclick="clearMsg();manualUpdateCard()">Manual</BUTTON>
</div>

<div id="enableBatch" class="overlay" style="display: none; text-align: center">
  <h1 style="color: white">Enable credit card batch for this customer?</h1>
  <BUTTON style="width: 100px; height: 45px; color: black" onclick="clearMsg();endUpdateClearentCard(1)">Yes</BUTTON>
  <BUTTON style="width: 100px; height: 45px; color: black" onclick="clearMsg();endUpdateClearentCard(0)">No</BUTTON>
</div>



<div id="updatedCardInfo" class="overlay" style="display: none; text-align: center">
  <h1 style="color: white">Enter New Card Info</h1>
  <table style="width: 60%">
  <tr>
     <td style="color: white">Card Number</td>
    <td colspan=3>
    <input style="width: 70%" type="text" id="newCardNum" maxlength=19 onkeyup="this.value=this.value.replace(/[^\d]/,'')"></input>
    </td>
  </tr>
  <tr>
    <td style="color: white">Expiration Month</td>
    <td>
        <select id='newExpMonth'>
            <option value = "01">Jan</option>
            <option value = "02">Feb</option>
            <option value = "03">Mar</option>
            <option value = "04">Apr</option>
            <option value = "05">May</option>
            <option value = "06">Jun</option>
            <option value = "07">Jul</option>
            <option value = "08">Aug</option>
            <option value = "09">Sept</option>
            <option value = "10">Oct</option>
            <option value = "11">Nov</option>
            <option value = "12">Dec</option>
        </select>
    </td>
    <td style="color: white">Expiration Year</td>
    <td>
        <select id='newExpYear'>
        </select>
    </td>
    </table></br>

  <BUTTON style="width: 100px; height: 45px; color: black" onclick="createTokenFromData()">Update</BUTTON>
  <BUTTON style="width: 100px; height: 45px; color: black" onclick="clearUpdCard()">Cancel</BUTTON>
</div>


<FORM id="customerpaymentform" name="customerpaymentform" action="" method="post">
<input type = hidden name=h_paymenttype value = "<%=paymentid%>" >
<input type = hidden name=h_permanentaccount value= "<%=l_permanentAccount%>">
<input type = hidden name=h_temporaryaccount value= "<%=l_temporaryAccount%>">

	<TABLE ALIGN=center BORDER=0 CELLSPACING=10 CELLPADDING=5 style="border:2px ridge" >
		<TR>
			<TD class="label" align="right">Credit Card</TD>
			<TD align=left>

				<table class="card-details">
					<tr>
						<td><%=cc_maskednumber%></td>
						<td>
							<input type="button" value="Update" class="btn" onclick="askUpdateMethod();">
							<% if cc_xcid <> "" then %><input type="button" value="Clear" class="btn" onclick="beginDeleteCard();"><% end if %>
						</td>
					</tr>
					<% if cc_xcid <> "" then %>
					<tr>
						<td><%=cc_expiration%></td>
						<td><input type="button" value="Update" class="btn" onclick="beginUpdateCard();"></td>
					</tr>
					<% if cc_allowbatch then %>
					<tr>
						<td>Batch enabled</td>
						<td><input type="button" value="Disable" class="btn" onclick="setBatchEnabled(false);"></td>
					</tr>
					<% else %>
					<tr>
						<td>Batch disabled</td>
						<td><input type="button" value="Enable" class="btn" onclick="setBatchEnabled(true);"></td>
					</tr>
					<% end if %>
					<% end if %>
				</table>

			</TD>
		</TR>
		<TR>

			<TD style="width:50%" class="label" align="right">Default Payment Method
			</TD>
			<TD align=left>
				<SELECT name=paymentType STYLE="font-size:16px;" onChange="evalPaymentType()">
					<option selected value = "0">None</option>
					<%
						dim rspaymentType
						sqltxt = "select * from StorePaymentType where enabled = 1 and storeid = " & session("storeid")
						Set rspaymentType = getdisconnectedrecordset(sqltxt)
						'Response.write rspaymentType.recordcount
						while not rspaymentType.eof
					%>	
						<OPTION 
						<% if (rspaymentType("defaultPaymentType")) then	
								paymenttype = Ucase(rspaymentType("paymenttypename"))
							
						%>
							Selected					
						
						<%	elseif (ucase(paymentid)  = ucase(rspaymentType("paymenttypename")) ) then	
								paymenttype = ucase(rspaymentType("paymenttypename"))
							
						%>
							Selected					
							
						<%end if%>
							VALUE= "<%=ucase( rspaymentType("PaymentTypeName")) %>" ><%=rsPaymentType("paymenttypename") %>
						
						<%	rspaymentType.MoveNext
							wend
							rspaymentType.close
							set rspaymentType = nothing
						 %>
				</SELECT>

		</TR>

		<TR>
			<TD class="label" align="right">
				Billing Responsibility
			</TD>
			<TD align=left>
				<INPUT readonly value="<%=billingCustomerName%>" />
				<INPUT type="button" value="Update" onclick="showCommonBillingInfo()" />
				<INPUT type="button" value="Clear" onclick="clearCommonBillingInfo()" />
			</TD>
		</TR>
		<TR>
			<TD class="label" align="right">
				Commercial Account
			</TD>
			<TD align=left>
				<INPUT readonly value="<%=parentCustomerName%>" />
				<INPUT type="button" value="Update" onclick="showParentCustomerInfo()" />
				<INPUT type="button" value="Clear" onclick="clearParentCustomerInfo()" />
			</TD>
		</TR>
		<TR>
			<TD class="label" align="right">Account Terms</TD>
			<TD align=left>
				<SELECT name=paymentTerms STYLE="font-size:16px;">
				<option selected value = "0">None</option>
					<%
						dim rsPaymentTerm
						
						sqltxt = "select * from PaymentTermsDomain where storeid =" & l_storeid
						
						set rsPaymentTerm= getDisconnectedRecordset(sqltxt)
						
						while not rsPaymentTerm.eof
					%>	
					<OPTION 
					<%  if (paymenttermid =rsPaymentTerm("PaymentTermsID")) then	%>
						Selected					
					<%end if%>
					VALUE= "<%=rsPaymentTerm("PaymentTermsID")%>"><%= rsPaymentTerm("PaymentName") %>
					<%
						rsPaymentTerm.MoveNext()
						wend
						rsPaymentTerm.close
						set rsPaymentTerm = nothing
						
					%>
				</SELECT>
			</TD>
		</TR>
		
		<TR>
			<TD class="label" align="right">Account Balance</TD>
			<TD align=left>
				<INPUT id=txtAccountBalance name=txtAccountBalance class=text onblur = "validateDecimal(this)" style="text-align:right; HEIGHT: 25px; WIDTH: 100px" disabled value="<%=accbalance%>"
				<% 'if (ucase(paymentType) <> "ON ACCOUNT") Then %>
					
				<% 'END if%>
				ONBLUR = validateField(this)>

				<% if accbalance <> 0 then %>
				    <input type="button" value="Apply Payment" class="btn" onclick="goToApplyPayment();">
				<% end if %>
			</TD>
		</TR>
		
		
		<TR>
			<TD class="label" align="right">Account Limit</TD>
			<TD align=left>
				<INPUT id=txtCreditLimit name=txtCreditLimit onblur = "validateDecimal(this)" class=text style="text-align:right; HEIGHT: 25px; WIDTH: 100px" value="<%=creditlimit%>"
				<% 'if (ucase(paymentType) <> "ON ACCOUNT") Then %>
					
				<% 'END if%>
				ONBLUR  = validateField(this)>
			</TD>
		</TR>

		<TR>
			<TD class="label" align="right">Pickup Only On Account</TD>
			<TD align=left>
				<INPUT id=chkPickupOnlyOnAccount name=chkPickupOnlyOnAccount type=checkbox style="HEIGHT: 28px; WIDTH: 28px"
				<% if l_pickupOnlyOnAccount then %> Checked <%end if%>>
			</TD>
		</TR>
		
		<TR>
			<TD class="label" align="right">Exclude From AR Statement</TD>
			<TD align=left>
				<INPUT id=chkExcludeFromAR name=chkExcludeFromAR type=checkbox style="HEIGHT: 28px; WIDTH: 28px"
				<% if l_excludeFromAR then %> Checked <%end if%>>
			</TD>
		</TR>

		
		<TR>
			<TD class="label" align="right">Statement Note</TD>
			<TD align=left>
				<TEXTAREA id=statementNotes name=statementNotes style="overflow:auto;width:250px" rows="3" ><%=statementNotes%></TEXTAREA>
			</TD>
		</TR>

		<% if useAllowance then %>
		<TR>
			<TD class="label" align="right">Monthly Allowance</TD>
			<TD align=left>
				<INPUT id=txtMonthlyAllowance name=txtMonthlyAllowance onblur = "validateDecimal(this)" class=text style="text-align:right; HEIGHT: 25px; WIDTH: 100px" value="<%=allowance%>"
			</TD>
		</TR>
		<% end if %>
		<!-- buttons -->
		<TR>
			<TD colspan="2" align=center>
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/OK.gif)" onClick= "submitForm()">
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
			</TD>
		</TR>     
		
	</TABLE>


</FORM>   

</BODY>
</HTML>
<%

	function SetBatchEnable()
		dim query, rs
		dim customerseq

		customerseq = request.querystring("customerseq")
        if request.querystring("allowccbatch") <> "" then
            query = " update customer set "
            query = query & " allowccbatch = " & request.querystring("allowccbatch")
            query = query & " where customersequencenumber = " & dbstr(customerseq)

            qryexecute query
		end if
	end function
	
	function DeleteCardOnFile()
		dim query, rs
		dim customerseq

		customerseq = request.querystring("customerseq")

	
		query = " update customer set "
		query = query & " creditcardnumber = '', "
		query = query & " creditcardmaskednumber = '', "
		query = query & " creditcardexpdate = '', "
		query = query & " creditcardtype = '', "
		query = query & " allowccbatch = 0 "
		query = query & " where customersequencenumber = " & dbstr(customerseq)
		qryexecute query


		if request.queryString("failedDeleted") = "1" then
                query = "insert into Unusedtokens (token, apiKey) values ('" & dbstr(cc_xcid) & "', '" & cc_key & "')"
		        qryexecute query
		end if
	end function
	
	function UpdateCardOnFile()
		dim query, rs
		dim customerseq
		dim expiration

		customerseq = request.querystring("customerseq")
		expiration = request.querystring("expiration")
	
		query = " update customer set "
		query = query & " creditcardexpdate = '" & dbstr(expiration) & "' "
		query = query & " where customersequencenumber = " & dbstr(customerseq)

		
		qryexecute query
        SetBatchEnable
		
	end function
	
	
	function AddCardOnFile()
		dim query, rs
		dim customerseq
		dim xcaccountid
		dim account
		dim expiration
		dim accounttype
		
		customerseq = request.querystring("customerseq")
		xcaccountid = request.querystring("xcaccountid")
		account = request.querystring("account")
		expiration = request.querystring("expiration")
		accounttype = request.querystring("accounttype")
		
		query = " update customer set "
		query = query & " creditcardnumber = '" & dbstr(xcaccountid) & "', "
		query = query & " creditcardmaskednumber = '" & dbstr(account) & "', "
		query = query & " creditcardexpdate = '" & dbstr(expiration) & "', "
		query = query & " creditcardtype = '" & dbstr(accounttype) & "' "
		query = query & " where customersequencenumber = " & dbstr(customerseq)
		
		qryexecute query

		SetBatchEnable
	end function
	
	function UpdateCommonBilling(customerseq, billingcustomerseq)
		dim query, rs
		
		query = " update customer set billingcustomerseq = " & billingcustomerseq
		query = query & " where customersequencenumber = " & customerseq
	
		qryexecute query
	end function
	function UpdateParentCustomer(customerseq, billingcustomerseq)
		dim query, rs
		
		query = " update customer set parentcustomerseq = " & billingcustomerseq
		query = query & ", routeNumber = " & getCustomerRouteNumber(billingcustomerseq)
		query = query & " where customersequencenumber = " & customerseq
	
		qryexecute query
	end function
	function UpdateDatabase()
		dim l_paymentname
		dim l_termsId
		dim l_accLimit
		dim l_excludeFromAR
		dim l_accBalance
		
		l_paymentname = Request.form("paymentType")
		l_termsId = Request.form("paymentTerms")
		l_accLimit = cdbl(Request.form("txtCreditLimit"))
		l_excludeFromAR = evalRequestValue(Request.Form("chkExcludeFromAR"))
		l_accBalance = cdbl(Request.form("txtAccountBalance"))
		statementNotes = Request.form("statementNotes")
		l_pickupOnlyOnAccount = evalRequestValue(Request.Form("chkPickupOnlyOnAccount"))
		
		sqltxt = "update customer set " _
            & "paymenttypename = " & DbCreateQryString(l_paymentname) _
            & ", paymenttermsid = "  & DbCreateQryString(l_termsId)  _
            & ", creditlimit= " & l_accLimit _
            & ", excludeFromAr = " & l_excludeFromAR _
            & ", statementNotes = " & DbCreateQryString(statementNotes) _
         		& ", pickupOnlyOnAccount = " & l_pickupOnlyOnAccount

        if useAllowance then
		    allowance = cdbl(Request.form("txtMonthlyAllowance"))
            sqltxt = sqltxt & ", allowance = " & allowance
        end if
         		
		if l_paymentname = "ON ACCOUNT" or (round(l_accLimit, 2) <> 0 or round(l_accBalance, 2) <> 0) then
			sqltxt = sqltxt & ", permanentAccount = 1"
		else
			sqltxt = sqltxt & ", permanentAccount = 0"
		end if    
		  
		sqltxt = sqltxt & " where customersequencenumber = " & session("Customersequencenumber")

		qryexecute sqltxt

		if	request.querystring("action") = "commonbilling" then
			response.redirect "customersearch.asp?userAction=commonbilling"
		elseif	request.querystring("action") = "parentcustomer" then
			response.redirect "customersearch.asp?userAction=parentcustomer&routefilter=" & getCustomerRouteNumber(session("Customersequencenumber"))
		else
			Response.redirect("CustomerEntry.asp?mode=edit")
		end if
		
	end function
	function getCustomerRouteNumber(customerseq)
		dim query, rs
		
		if customerseq <> "" then
			query = "select routenumber from customer where customersequencenumber = " & customerseq
			
			set rs = getdisconnectedrecordset(query)
			
			getCustomerRouteNumber = rs("routenumber")
		end if
	end function
	
	function getCustomerName(customerseq)
		dim query, rs
		
		if customerseq <> "" then
			query = "select customername from customer where customersequencenumber = " & customerseq
			
			set rs = getdisconnectedrecordset(query)
			
			getCustomerName = rs("customername")
		end if
	end function
	
	function GetCustomerPaymentInfo()
	dim rsCustomerInfo
		if not isnull(customerseq) and not customerseq = ""  then
		
				sqltxt = "select pickupOnlyOnAccount, PaymentTypeName, PaymentTermsID,isnull(AccountBalance, 0) as AccountBalance, "
				sqltxt = sqltxt & " isnull(CreditLimit, 0 ) as creditlimit, excludeFromAR, "
				sqltxt = sqltxt & " billingcustomerseq, parentcustomerseq, isnull(statementNotes, '') as statementNotes, "
				sqltxt = sqltxt & " allowance,  "
				sqltxt = sqltxt & " isnull(creditcardnumber, '') as creditcardnumber, "
				sqltxt = sqltxt & " isnull(creditcardexpdate, '') as creditcardexpdate, "
				sqltxt = sqltxt & " isnull(creditcardmaskednumber, '') as creditcardmaskednumber, "
				sqltxt = sqltxt & " isnull(creditcardtype, '') as creditcardtype, "
				sqltxt = sqltxt & " allowccbatch, shippingzipcode "
				sqltxt = sqltxt & " from customer where customersequencenumber = " & customerseq
				
				set rsCustomerinfo= getdisconnectedrecordset(sqltxt)
				paymentid = ucase(rsCustomerInfo("PaymentTypeName"))
				paymenttermid = rsCustomerInfo("PaymentTermsID")	
			
				l_excludeFromAR = rsCustomerinfo("excludeFromAR")
				
				
				cc_maskednumber = rsCustomerinfo("creditcardmaskednumber")
				cc_xcid = rsCustomerinfo("creditcardnumber")
				cc_expiration = rsCustomerinfo("creditcardexpdate")
				cc_type = rsCustomerinfo("creditcardtype")
				cc_allowbatch = rsCustomerinfo("allowccbatch")
				cc_zip = rsCustomerinfo("shippingzipcode")

				CreditLimit = formatNumber(rsCustomerInfo("CreditLimit"), 2, -1, 0, 0)
				
				billingCustomerName = getCustomerName(rsCustomerInfo("billingcustomerseq"))
				parentCustomerName = getCustomerName(rsCustomerInfo("parentcustomerseq"))
				
				statementNotes = rsCustomerinfo("statementNotes")
				allowance = rsCustomerinfo("allowance")

				l_pickupOnlyOnAccount = rsCustomerinfo("pickupOnlyOnAccount")
				
				rsCustomerInfo.Close()
			set rscustomerinfo= nothing
			
		end if
		
		sqltxt = "Execute dbo.GetCustomerAccountBalance " & customerseq
		set rsCustomerinfo= getdisconnectedrecordset(sqltxt)
		
		if rsCustomerinfo.recordcount > 0 then
		
			Accbalance =formatnumber(rsCustomerInfo("AccountBalance"), 2, -1, 0, 0)
			
			l_temporaryaccount = rsCustomerInfo("temporaryaccount")
			
			l_permanentaccount = rsCustomerinfo("PermanentAccount")

		end if
		
		rsCustomerInfo.Close()
		set rscustomerinfo= nothing
	end function
	
	function clearCommonBillingInfo(customerseq)
		dim query
		
		query = "update customer set billingcustomerseq = null where customersequencenumber = " & customerseq
		
		qryexecute query
	end function

	function clearParentCustomerInfo(customerseq)
		dim query
		
		query = "update customer set parentcustomerseq = null where customersequencenumber = " & customerseq
		
		qryexecute query
	end function

		function determineProcessor()
    		dim query, rs, ccProcessorDomainID

    		query = " select CreditCardProcessorDomainID from MiscSetup where storeid = " & l_storeid
    		set rs = getdisconnectedrecordset(query)
    		if rs.recordcount > 0 then
    		    ccProcessorDomainID = rs("CreditCardProcessorDomainID")
                query = " select  Description, URL, API_Key from CreditCardProcessorDomain where CreditCardProcessorDomainID = " & ccProcessorDomainID

                set rs = getdisconnectedrecordset(query)

                if rs.recordcount > 0 then
                    if rs("Description") = "Clearent" then
                        use_clearent = "1"
                        cc_url = trim(rs("URL"))
                        cc_key = trim(rs("API_Key"))

                        query = " select API_Key from Terminal where terminalId = " & Session("terminalID")
                        set rs = getdisconnectedrecordset(query)
                        if rs("API_Key") <> "" then
                            cc_key = trim(rs("API_Key"))
                        end if
                        clearentServiceLoc = getClearentShortPath()
                    else
		                use_clearent = "0"
                    end if
                end if
            else
                use_clearent = "0"
            end if

    	end function
%>
