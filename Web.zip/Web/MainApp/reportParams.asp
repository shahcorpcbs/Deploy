<%@ Language=VBScript %>
<% option explicit %>

<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!-- #include file="CheckSessionExpiry.asp" -->

<!-- #include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("reportID")%>
<%

	dim reportID
	dim rangeStartDate
	dim rangeEndDate
	dim paramStatus
	dim customerSequenceNumber
	dim requesterName
	dim refreshParams
	dim scheduleID
	dim l_storeID
	dim l_deptName
	dim objMiscSetup
	dim strSQL


	' Since multiple pages request Select Parameter page, where to go back?
	dim backOnePage

	if Trim(Request.QueryString("reportID")) <> "" then
		reportID = Clng(Request.QueryString("reportID"))
	else
		reportID = 0
	end if

	If reportID <= 0 Then
		' Coming back from Customer Search
		reportID = Session("objRP").reportNumber
		scheduleID = Session("objRP").scheduleID
		requesterName = Session("objRP").requesterName

	Else
		'	Get requester name
		If Trim(Request.QueryString("requesterName")) = "" Then
			requesterName = "RPT"
		Else
			requesterName = Trim(Request.QueryString("requesterName"))
		End if

		scheduleID = IIf(Trim(Request.QueryString("scheduleID")) = "", 0, Clng(Request.QueryString("scheduleID")))

		If scheduleID = 0 OR requesterName <> RPT_Requester_Name_Schedule Then
			refreshParams = True
		Else
			refreshParams = False
		End if

		If GetReportParams(reportID, refreshParams, requesterName, scheduleID) = "NEW" Then
			' Initialize All Date Values.
			'Session("objRP").rangeStartDate = IIf (Trim(Request.QueryString("rangeStartDate")) = "", CDate(FormatDateTime(Now(), vbShortDate)), CDate(Request.QueryString("rangeStartDate")))
			'Session("objRP").rangeEndDate = IIf (Trim(Request.QueryString("rangeEndDate")) = "", CDate(FormatDateTime(Now(), vbShortDate)), CDate(Request.QueryString("rangeEndDate")))
			'Session("objRP").rangeStartDateCompareTo = CDate(FormatDateTime(Now(), vbShortDate))
			'Session("objRP").rangeEndDateCompareTo = CDate(FormatDateTime(Now(), vbShortDate))

			Session("objRP").reportName = Request.QueryString("reportName")
		End If

		if l_deptName <> "" then
			l_deptName = Session("objRP").departmentName
        end if

		Session("objRP").scheduleID = scheduleID

	End If

	if l_storeID = "" THEN
		l_storeID = session("storeID")
	else
		l_storeID = Session("objRP").storeID
	end if

	If Trim(Request.QueryString("customerSequenceNumber")) <> "" And isNumeric(Request.QueryString("customerSequenceNumber")) Then
		Session("objRP").customerSequenceNumber = CLng(Request.QueryString("customerSequenceNumber"))
	End if

%>


<%

function GetBackOnePageName(requesterName)
	Select Case requesterName
		Case RPT_Requester_Name_Employee
			GetBackOnePageName = "employeeEOSRParams.asp"
		Case RPT_Requester_Name_Statement_Run
			GetBackOnePageName = "runStatements.asp"
		Case RPT_Requester_Name_Statement_History
			GetBackOnePageName = "customerfunctions.asp"
		Case RPT_Requester_Name_Schedule
			GetBackOnePageName = "reportSchedule.asp?reportID=" & Session("objRP").reportNumber & "&reportName=" & Session("objRP").reportName
		Case RPT_Requester_Name_Route
			GetBackOnePageName = "routesMenu.asp"
		Case Else
			GetBackOnePageName = "reportList.asp"
	End Select
end function

' Generic Functions
Const TEXT_FOR_ALL_IN_DROPDOWN = "(All)"
Const CODE_FOR_ALL_IN_DROPDOWN = "0"


function GetMonthNumberDropDown( formVariableName, previousValue )

	dim strDropDownTag
	dim objRSEmployee
	dim strSQL

	if formVariableName = "" then
		formVariableName = "monthNumber"
	end if

	strDropDownTag = "<SELECT style='font-size: 18px' name=" & formVariableName & "> " & _
		"<OPTION VALUE=-1>(All)</OPTION>" & _
		"<OPTION VALUE=0>0</OPTION> " & _
		"<OPTION " & IIf(previousValue = 1, " SELECTED", "") & " VALUE=1>1</OPTION> " & _
		"<OPTION " & IIf(previousValue = 2, " SELECTED", "") & " VALUE=2>2</OPTION> " & _
		"<OPTION " & IIf(previousValue = 3, " SELECTED", "") & " VALUE=3>3</OPTION> " & _
		"<OPTION " & IIf(previousValue = 4, " SELECTED", "") & " VALUE=4>4</OPTION> " & _
		"<OPTION " & IIf(previousValue = 5, " SELECTED", "") & " VALUE=5>5</OPTION> " & _
		"<OPTION " & IIf(previousValue = 6, " SELECTED", "") & " VALUE=6>6</OPTION> " & _
		"<OPTION " & IIf(previousValue = 7, " SELECTED", "") & " VALUE=7>7</OPTION> " & _
		"<OPTION " & IIf(previousValue = 8, " SELECTED", "") & " VALUE=8>8</OPTION> " & _
		"<OPTION " & IIf(previousValue = 9, " SELECTED", "") & " VALUE=9>9</OPTION> " & _
		"<OPTION " & IIf(previousValue = 10, " SELECTED", "") & " VALUE=10>10</OPTION> " & _
		"<OPTION " & IIf(previousValue = 11, " SELECTED", "") & " VALUE=11>11</OPTION> " & _
		"<OPTION " & IIf(previousValue = 12, " SELECTED", "") & " VALUE=12>12</OPTION> " & _
	    "</SELECT>"

	GetMonthNumberDropDown = strDropDownTag

end function
function GetMonthDropDown( formVariableName, previousValue )

	dim strDropDownTag
	dim objRSEmployee
	dim strSQL

	if formVariableName = "" then
		formVariableName = "monthNumber"
	end if

	strDropDownTag = "<SELECT style='font-size: 18px' name=" & formVariableName & "> " & _
		"<OPTION VALUE=0>(All)</OPTION> " & _
		"<OPTION " & IIf(previousValue = 1, " SELECTED", "") & " VALUE=1>January</OPTION> " & _
		"<OPTION " & IIf(previousValue = 2, " SELECTED", "") & " VALUE=2>February</OPTION> " & _
		"<OPTION " & IIf(previousValue = 3, " SELECTED", "") & " VALUE=3>March</OPTION> " & _
		"<OPTION " & IIf(previousValue = 4, " SELECTED", "") & " VALUE=4>April</OPTION> " & _
		"<OPTION " & IIf(previousValue = 5, " SELECTED", "") & " VALUE=5>May</OPTION> " & _
		"<OPTION " & IIf(previousValue = 6, " SELECTED", "") & " VALUE=6>June</OPTION> " & _
		"<OPTION " & IIf(previousValue = 7, " SELECTED", "") & " VALUE=7>July</OPTION> " & _
		"<OPTION " & IIf(previousValue = 8, " SELECTED", "") & " VALUE=8>August</OPTION> " & _
		"<OPTION " & IIf(previousValue = 9, " SELECTED", "") & " VALUE=9>September</OPTION> " & _
		"<OPTION " & IIf(previousValue = 10, " SELECTED", "") & " VALUE=10>October</OPTION> " & _
		"<OPTION " & IIf(previousValue = 11, " SELECTED", "") & " VALUE=11>November</OPTION> " & _
		"<OPTION " & IIf(previousValue = 12, " SELECTED", "") & " VALUE=12>December</OPTION> " & _
	    "</SELECT>"

	GetMonthDropDown = strDropDownTag

end function
function GetDayDropDown( formVariableName, previousValue )

	dim strDropDownTag
	dim strSQL

	if formVariableName = "" then
		formVariableName = "dayOfWeek"
	end if

	strDropDownTag = "<SELECT style='font-size: 18px' name=" & formVariableName & "> " & _
		"<OPTION VALUE=0>(All)</OPTION> " & _
		"<OPTION " & IIf(previousValue = 1, " SELECTED", "") & " VALUE=1>Sunday</OPTION> " & _
		"<OPTION " & IIf(previousValue = 2, " SELECTED", "") & " VALUE=2>Monday</OPTION> " & _
		"<OPTION " & IIf(previousValue = 3, " SELECTED", "") & " VALUE=3>Tuesday</OPTION> " & _
		"<OPTION " & IIf(previousValue = 4, " SELECTED", "") & " VALUE=4>Wednesday</OPTION> " & _
		"<OPTION " & IIf(previousValue = 5, " SELECTED", "") & " VALUE=5>Thursday</OPTION> " & _
		"<OPTION " & IIf(previousValue = 6, " SELECTED", "") & " VALUE=6>Friday</OPTION> " & _
		"<OPTION " & IIf(previousValue = 7, " SELECTED", "") & " VALUE=7>Saturday</OPTION> " & _
	    "</SELECT>"

	GetDayDropDown = strDropDownTag

end function

function GetEmployeeDropDown( storeID )

	dim strDropDownTag
	dim objRSEmployee
	dim strSQL

	strDropDownTag = "<SELECT style='font-size: 18px' name=EmployeeID> " & _
						"<OPTION VALUE =" & CODE_FOR_ALL_IN_DROPDOWN & ">" & TEXT_FOR_ALL_IN_DROPDOWN & "</OPTION>"

	' As long an option to select all is there, we don't care if there is an error.
	on error resume next

	strSQL = "SELECT employeeID, employeeName, storeID FROM Employee"

	if (storeID <> "0") and (storeID <> "") then
		 strSQL = strSQL & " WHERE storeID = " & storeID
	end if

	strSQL = strSQL & " ORDER BY employeeName"

	set objRSEmployee = getDisconnectedRecordset(strSQL)

	While not objRSEmployee.EOF
		strDropDownTag = strDropDownTag & "<OPTION VALUE= " & objRSEmployee("employeeId") & _
  					     IIf(objRSEmployee("employeeId") = Session("objRP").employeeId, " SELECTED", "") & ">" & _
						 objRSEmployee("employeeName") & "</OPTION>"
		objRSEmployee.MoveNext
	Wend

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetEmployeeDropDown = strDropDownTag

end function


function GetCustSourceDropDown(storeID)

	dim strDropDownTag
	dim rs
	dim strSQL

	strDropDownTag = "<SELECT style='font-size: 18px' name=customerSource > " & _
						"<OPTION VALUE =" & CODE_FOR_ALL_IN_DROPDOWN & ">" & TEXT_FOR_ALL_IN_DROPDOWN & "</OPTION>"

	' As long an option to select all is there, we don't care if there is an error.
	on error resume next

	strSQL = "SELECT customersourceid, [name] FROM customersourcedomain where storeid = " & storeID
	
	strSQL = strSQL & " ORDER BY [name]"

	set rs = getDisconnectedRecordset(strSQL)

	While not rs.EOF
		strDropDownTag = strDropDownTag & "<OPTION VALUE= " & rs("customersourceid") & ">" & _
						 Server.HTMLEncode(rs("name")) & "</OPTION>"
		rs.MoveNext
	Wend

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetCustSourceDropDown = strDropDownTag

end function

function GetStoreDropDown()

	dim strDropDownTag
	dim objRSStore
	dim strSQL

	strDropDownTag = "<SELECT style='font-size: 18px' name=storeID > " & _
						"<OPTION VALUE =" & CODE_FOR_ALL_IN_DROPDOWN & ">" & TEXT_FOR_ALL_IN_DROPDOWN & "</OPTION>"

	' As long an option to select all is there, we don't care if there is an error.
	on error resume next

	strSQL = "SELECT storeid, [name] FROM Store"

	strSQL = strSQL & " ORDER BY [name]"

	set objRSStore = getDisconnectedRecordset(strSQL)

	While not objRSStore.EOF
		strDropDownTag = strDropDownTag & "<OPTION VALUE= " & objRSStore("StoreID") & _
  					     IIf(trim(objRSStore("StoreID")) = l_storeid, " SELECTED", "") & ">" & _
						 objRSStore("name") & " (" & CStr(objRSStore("StoreID")) & ")</OPTION>"
		objRSStore.MoveNext
	Wend

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetStoreDropDown = strDropDownTag

end function

function GetPriceListDropDown( storeID )

	dim strDropDownTag
	dim objRSPriceList
	dim strSQL

	strDropDownTag = "<SELECT style='font-size: 18px' name=priceListID> " & _
						"<OPTION VALUE =" & CODE_FOR_ALL_IN_DROPDOWN & ">" & TEXT_FOR_ALL_IN_DROPDOWN & "</OPTION>"

	' As long an option to select all is there, we don't care if there is an error.
	on error resume next

	strSQL = "SELECT priceListID, [name], storeID FROM PriceList where disable = 0  "

	if (storeID <> "0")  and (storeID <> "") then
		 strSQL = strSQL & " and storeID = " & storeID
	end if

	strSQL = strSQL & " ORDER BY [name]"

	set objRSPriceList = getDisconnectedRecordset(strSQL)

	While not objRSPriceList.EOF
		strDropDownTag = strDropDownTag & "<OPTION VALUE= " & objRSPriceList("PriceListId") & _
  					     IIf(objRSPriceList("PriceListId") = Session("objRP").PriceListId, " SELECTED", "") & ">" & _
						 objRSPriceList("name") & " (" & CStr(objRSPriceList("PriceListId")) & ")</OPTION>"
		objRSPriceList.MoveNext
	Wend

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetPriceListDropDown = strDropDownTag

end function

function GetWeekDropDown( storeID )
	dim query, rs
	dim strDropDownTag

	query = " SELECT DATEDIFF(wk, 0, GETDATE()) - val AS weeknumber, DATEADD(wk, DATEDIFF(wk, 0, GETDATE()) - val, 0) AS startdate, DATEADD(wk, DATEDIFF(wk, 0, GETDATE()) - val + 1, 0) AS enddate "
	query = query & " FROM (SELECT     i1.inValue + i2.inValue * 10 AS val "
	query = query & " FROM unPivotInClause('0,1,2,3,4,5,6,7,8,9') i1 CROSS JOIN "
	query = query & " unPivotInClause('0,1,2,3,4,5,6,7,8,9') i2) num "
	query = query & " WHERE (val BETWEEN 0 AND 52) "
	query = query & " ORDER BY weeknumber DESC "

	set rs = getdisconnectedrecordset(query)

	strDropDownTag = "<SELECT style='font-size: 18px' name=weekNumber>"

	while not(rs.eof or rs.bof)

		strDropDownTag = strDropDownTag & "<OPTION value=""" & rs("weeknumber") & """>"
		strDropDownTag = strDropDownTag & rs("startdate") & "  -  " & rs("enddate")
		strDropDownTag = strDropDownTag & "</OPTION>"

		rs.movenext
	wend

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetWeekDropDown = strDropDownTag
end function


function GetRouteDropDown( storeID )

	dim strDropDownTag
	dim objRSRoute
	dim strSQL

	strDropDownTag = "<SELECT style='font-size: 18px' name=routeNumber> " & _
						"<OPTION SELECTED VALUE = -1>" & TEXT_FOR_ALL_IN_DROPDOWN & "</OPTION>"

' Testing to fix route = 0/ all routes problem
'						"<OPTION VALUE =" & CODE_FOR_ALL_IN_DROPDOWN & ">" & TEXT_FOR_ALL_IN_DROPDOWN & "</OPTION>"


	' As long an option to select all is there, we don't care if there is an error.
	on error resume next

	strSQL = "SELECT routeNumber, [name], storeID FROM Route where 1 = 1 "

	if (storeID <> "0")  and (storeID <> "") then
		 strSQL = strSQL & " and storeID = " & storeID
	end if

	strSQL = strSQL & " ORDER BY [name]"

	set objRSRoute = getDisconnectedRecordset(strSQL)

	While not objRSRoute.EOF
		strDropDownTag = strDropDownTag & "<OPTION VALUE= " & objRSRoute("routeNumber") & ">" & _
						 objRSRoute("name") & " (" & CStr(objRSRoute("routeNumber")) & ")</OPTION>"
		objRSRoute.MoveNext
	Wend

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetRouteDropDown = strDropDownTag

end function


function GetGroupRouteDropDown()

	dim strDropDownTag

	strDropDownTag = "<SELECT style='font-size: 18px' name=routeGroup> " & _
						"<OPTION VALUE = 0>" & "No Routes" & "</OPTION>" & _
						"<OPTION VALUE = -1>" & "All Routes" & "</OPTION>"

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetGroupRouteDropDown = strDropDownTag

end function

function GetDeptAndStartTime()

	dim strDropDownTag
	dim objRSStartDate
	dim strSQL

	' As long an option to select all is there, we don't care if there is an error.
	on error resume next

	strSQL = "SELECT deptName +'-'+ cast(runtime as varchar)as runtime from invoiceDetailByTime"

	set objRSStartDate = getDisconnectedRecordset(strSQL)
	
	strDropDownTag = "<SELECT style='font-size: 18px' name=deptStartDate>"

	While not objRSStartDate.EOF
		strDropDownTag = strDropDownTag & "<OPTION VALUE= " & """" & objRSStartDate("runtime") & """" & ">" & objRSStartDate("runtime") & "</OPTION>"
		objRSStartDate.MoveNext
	Wend

	GetDeptAndStartTime = strDropDownTag

end function

function GetTerminalDropDown(storeID)

	dim strDropDownTag
	dim strSQL
	dim objRSTerminal

	strDropDownTag = "<SELECT style='font-size: 18px' name=terminalID> " & _
						"<OPTION VALUE =" & CODE_FOR_ALL_IN_DROPDOWN & ">" & TEXT_FOR_ALL_IN_DROPDOWN & "</OPTION>"

	strSQL = "SELECT terminalID, [name] from terminal"

	if (storeID <> "0") and (storeID <> "") then
		 strSQL = strSQL & " WHERE storeID = " & storeID
	end if

	set objRSTerminal = getDisconnectedRecordset(strSQL)

	While not objRSTerminal.EOF
		strDropDownTag = strDropDownTag & "<OPTION VALUE= " & objRSTerminal("terminalID") & _
  					     IIf(objRSTerminal("terminalID") = Session("objRP").terminalID, " SELECTED", "") & ">" & _
						 objRSTerminal("name") & "</OPTION>"
		objRSTerminal.MoveNext
	Wend

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetTerminalDropDown = strDropDownTag

end function


function GetClaimStatusDropDown(  )

	dim strDropDownTag

	strDropDownTag = "<SELECT style='font-size: 18px' name=claimStatus> " & _
						"<OPTION VALUE ="""">Open and Closed</OPTION>" & _
						"<OPTION VALUE =""O"">Open</OPTION>" & _
						"<OPTION VALUE =""C"">Closed</OPTION>"

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetClaimStatusDropDown = strDropDownTag

end function

function GetStatusDropDown(  )

	dim strDropDownTag

	strDropDownTag = "<SELECT style='font-size: 18px' name=status> " & _
						"<OPTION VALUE ="""">Open and Closed</OPTION>" & _
						"<OPTION VALUE =""O"">Open</OPTION>" & _
						"<OPTION VALUE =""C"">Closed</OPTION>"

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetStatusDropDown = strDropDownTag

end function

function GetCustomerDropDown( storeID )

	dim strDropDownTag
	dim objRSCustomer
	dim strSQL

	strDropDownTag = "<SELECT style='font-size: 18px' NAME=customerSequenceNumber> " & _
						"<OPTION VALUE =" & CODE_FOR_ALL_IN_DROPDOWN & ">" & TEXT_FOR_ALL_IN_DROPDOWN & "</OPTION>"

	' As long an option to select all is there, we don't care if there is an error.
	on error resume next

	strSQL = "SELECT customerSequenceNumber, [customerName], customerID, storeID FROM Customer WHERE customerSequenceNumber = " & Session("objRP").customerSequenceNumber

	if (storeID <> "0") and (storeID <> "") then
		 strSQL = strSQL & " WHERE storeID = " & storeID
	end if

	strSQL = strSQL & " ORDER BY [customerName]"

	set objRSCustomer = getDisconnectedRecordset(strSQL)

	While not objRSCustomer.EOF
		strDropDownTag = strDropDownTag & "<OPTION VALUE= " & objRSCustomer("customerSequenceNumber") & _
  					     IIf(objRSCustomer("customerSequenceNumber") = Session("objRP").customerSequenceNumber, " SELECTED", "") & ">" & _
						 objRSCustomer("customerName") & " (" & CStr(objRSCustomer("customerID")) & ")</OPTION>"
		objRSCustomer.MoveNext
	Wend

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetCustomerDropDown = strDropDownTag

end function


function GetDepartmentDropDown(storeID)

	dim strDropDownTag
	dim strSQL
	dim objRSDepartment

	strDropDownTag = "<SELECT style='font-size: 18px' name=departmentName> " & _
						"<OPTION VALUE ="""">" & TEXT_FOR_ALL_IN_DROPDOWN & "</OPTION>"

	strSQL = "SELECT distinct name from department "

	if (storeID <> "0") and (storeID <> "") then
		 strSQL = strSQL & " WHERE storeID = " & storeID
	end if

	set objRSDepartment = getDisconnectedRecordset(strSQL)

	While not objRSDepartment.EOF
		strDropDownTag = strDropDownTag & "<OPTION VALUE=""" & objRSDepartment("name") & """ >" & objRSDepartment("name") & "</OPTION>"
		objRSDepartment.MoveNext
	Wend

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetDepartmentDropDown = strDropDownTag

end function



function GetDiscountDropdown(storeID)

	dim strDropDownTag
	dim strSQL
	dim rs

	strDropDownTag = "<SELECT style='font-size: 18px' name=discountID><OPTION VALUE ="""">" & TEXT_FOR_ALL_IN_DROPDOWN & "</OPTION>"

	strSQL = "SELECT discount.discountID, discount.discountType, pricelist.name as priceListName, discount.discountName "
	strSQL = strSQL & " from discount inner join pricelist on discount.pricelistid = pricelist.pricelistid "

	if (storeID <> "0") and (storeID <> "") then
		 strSQL = strSQL & " WHERE pricelist.storeid = " & storeID
	end if
	
	strSQL = strSQL & " order by pricelist.pricelistid, discount.discountType, discount.discountName "

	set rs = getDisconnectedRecordset(strSQL)

	While not rs.EOF
		strDropDownTag = strDropDownTag & "<OPTION VALUE=""" & rs("discountID") & """ >" & Server.HTMLEncode(rs("priceListName") & " [" & rs("discountType") & "] " & rs("discountName")) & "</OPTION>"
		rs.MoveNext
	Wend

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetDiscountDropdown = strDropDownTag

end function

function GetHoursDropDown(  )

	dim strDropDownTag
	dim i
	dim numberOfHours

	i = 1

	strDropDownTag = "<SELECT style='font-size: 18px' name=hourValue> "
	for i = 1 to 12
		strDropDownTag = strDropDownTag & "<OPTION VALUE =" & i  & ">" & i & "</OPTION>"
	next

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetHoursDropDown = strDropDownTag

end function

function GetTimeDropDown(which)

	dim strDropDownTag
	dim i,j,k,l
	dim numberOfHours
	dim oldTimeValue
	
	if which = "end" then
		oldTimeValue = FormatDateTime(Time(), vbLongTime)
	else
		oldTimeValue = 	"12:00:00 AM"
	end if	
		

	if len(oldTimeValue) = 10 then
		oldTimeValue = "0" & oldTimeValue
	end if
	oldTimeValue = left(oldTimeValue,5) & right(oldTimeValue,2)

	i = 1
	strDropDownTag = "<SELECT style='font-size: 18px' name=" & which & "hourValue>"
	for i = 1 to 12
		
		strDropDownTag = strDropDownTag & "<OPTION " & IIf(Left(oldTimeValue, 2) = cstr(iif(len(i) = 1, "0"&i, i)), " SELECTED ", "") & "VALUE =" & IIf(len(i) = 1, "0"&i, i)  & ">" & IIf(len(i) = 1, "0"&i, i) & "</OPTION>"
	next
	strDropDownTag = strDropDownTag & "</SELECT>"

	strDropDownTag = strDropDownTag & "&nbsp;&nbsp;<SELECT style='font-size: 18px' name=" & which & "minuteValue> "
	for j = 0 to 59
		strDropDownTag = strDropDownTag & "<OPTION " & IIf(Mid(oldTimeValue, 4, 2) = cstr(iif(len(j) = 1, "0"&j, j)), " SELECTED ", "") & "VALUE =" & IIf(len(j) = 1, "0"&j, j)  & ">" & IIf(len(j) = 1, "0"&j, j) & "</OPTION>"
	next
	strDropDownTag = strDropDownTag & "</SELECT>"

	strDropDownTag = strDropDownTag & "&nbsp;&nbsp;<SELECT style='font-size: 18px' name=" & which & "amPMValue> "
	strDropDownTag = strDropDownTag & "<OPTION " & IIf(Right(oldTimeValue, 2) = "AM", " SELECTED ", "") & "VALUE=AM>AM</OPTION>"
	strDropDownTag = strDropDownTag & "<OPTION " & IIf(Right(oldTimeValue, 2) = "PM", " SELECTED ", "") & "VALUE=PM>PM</OPTION>"
	strDropDownTag = strDropDownTag & "</SELECT>"

	GetTimeDropDown = strDropDownTag

end function


function GetPrepayTypeDropDown()

	dim strDropDownTag

	strDropDownTag = "<SELECT style='font-size: 18px' name=incoming> " & _
						"<OPTION VALUE =0>Outgoing</OPTION>" & _
						"<OPTION VALUE =1>Incoming</OPTION>"

	strDropDownTag = strDropDownTag & "</SELECT>"

	GetPrepayTypeDropDown = strDropDownTag

end function


%>

<HTML>

<HEAD>



<TITLE>Report Parameter Selection</TITLE>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>

<script language="javascript" type="text/javascript">

	function submitForm() {
		if (validateParameters()) {
				document.reportParmsForm.action="report.asp";
				document.reportParmsForm.submit();
		}
	}

	function cancelForm() {
		if(document.reportParmsForm.requesterName.value == "STMT_RUN")
			location.href='runStatements.asp'
		else
			location.href='reportGroup.asp'
	}


	function validateParameters() {

		// Validate only if the form variable is defined.

		if (reportParmsForm.numberOfHours != null) {
				// Validate only if something is entered.
				if (checkInt(reportParmsForm.numberOfHours.value) == false) {
					cbs_alert("Number of hours must be within 0 to 2147483647. Please enter a numeric value without embedded comma or period.");
					reportParmsForm.numberOfHours.focus();
					return (false);
				}
		}
		return (true);
	}

	function searchForCustomer() {
		document.reportParmsForm.action = "Customersearch.asp?userAction=reportParams" +
		                                     "&reportID=<%= Session("objRP").reportNumber %>"
		                                     "&requesterName=<%= Session("objRP").requesterName %>"
		                                     "&scheduleID=<%= Session("objRP").scheduleID %>"
		document.reportParmsForm.submit();

		// alert("As the customer list grow large, the dropdown scrolling will become very difficult. This button is a place holder to show that, if needed, Standard Customer Search page can be displayed.")
	}

	function getStoreID(){
	var x;

	x=document.reportParmsForm.storeList.selectedIndex;
	if (x >=0 ) {
		document.reportParmsForm.storeID.value = document.reportParmsForm.storeList[x].value;
		document.reportParmsForm.submit();
		}
	}

</SCRIPT>

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="JavaScript" src="../script/validation.js"></script>

<script language="javascript" type="text/javascript">

	function setRangeStartDate() {
		var prevValue;
		var newValue;
		prevValue = document.reportParmsForm.rangeStartDate.value;
		show_calendar("reportParmsForm.rangeStartDate");
		newValue = document.reportParmsForm.rangeStartDate.value;
	}

	function setRangeEndDate() {
		show_calendar("reportParmsForm.rangeEndDate");
	}

	function setTranThroughDate() {
		show_calendar("reportParmsForm.tranThroughDate");
	}

	function setRangeStartDateCompareTo() {
		show_calendar("reportParmsForm.rangeStartDateCompareTo");
	}

	function setRangeEndDateCompareTo() {
		show_calendar("reportParmsForm.rangeEndDateCompareTo");
	}

	function setEffectiveDate() {
		show_calendar("reportParmsForm.effectiveDate");
	}

	function datePickerClosed(o) {
		var d;
		switch(o.name) {
		case "rangeStartDate":
			if(document.reportParmsForm.statementDueDate) {

			}
			break;
		case "rangeEndDate":
			if(document.reportParmsForm.statementDueDate) {

				d = new Date(o.value);
				d = new Date(
               d.getFullYear(),
               d.getMonth(),
               d.getDate() + 1,
               d.getHours(),
               d.getMinutes(),
               d.getSeconds());

				document.reportParmsForm.statementDate.value = (d.getMonth() + 1) + "/" + d.getDate() + "/" + d.getFullYear();

				d = new Date(
               d.getFullYear(),
               d.getMonth() + 1,
               d.getDate(),
               d.getHours(),
               d.getMinutes(),
               d.getSeconds());

				document.reportParmsForm.statementDueDate.value = (d.getMonth() + 1) + "/" + d.getDate() + "/" + d.getFullYear();


			}
			break;
		}
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->

<% If requesterName = RPT_Requester_Name_Schedule Then %>
	<% If scheduleID > 0 Then %>
		<H1>Edit Existing Schedule for - <%= Session("objRP").reportName %></H1>
		<FORM id="reportParmsForm" name="reportParmsForm" action="reportFrequency.asp" method="POST">
	<% Else %>
		<H1>Create New Schedule for - <%= Session("objRP").reportName %></H1>
		<FORM id="reportParmsForm" name="reportParmsForm" action="reportFrequency.asp" method="POST">
	<% End if %>
<% Else %>
	<H1>Select Report Parameters - <%= Session("objRP").reportName %></H1>
	<FORM id="reportParmsForm" name="reportParmsForm" method="POST">
<% End if %>


	<input type="hidden" name="requesterName" value="<%= requesterName%>">
	<input type="hidden" name="reportID" value="<%= Session("objRP").reportNumber%>">
	<!--<input type="hidden" name="storeID" value="<%=l_storeID %>">-->

<%
	If requesterName = RPT_Requester_Name_Schedule Then
%>
    <table>
		<tr>
		<td STYLE="color:#3200A4;">
			Please select the report parameters, if any, for this schedule and click OK button.
			You can specify when to run the report (i.e. Daily, Weekly, etc.) and where the output should go (i.e. Print, EMail, etc.) in the next page.<br>
		</td>
		</tr>
   </table>
<%
	End if
%>
	<!--
	<TABLE ALIGN=center WIDTH="400px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
	-->

	<p>

	<TABLE ALIGN=center VALIGN=center BORDER=2 CELLSPACING=1 CELLPADDING=5 >

	<!-- <tr height=35px><td>&nbsp;</td></tr> -->

		<!-- First display the standard selection criteria -->
		<%if reportID <> RPT_NBR_Credit_Card_Batch_Process then %>
		<tr height=35px>
			<td width = 50% class = "label"  align=right Style="Font-weight=normal">Report Format: </td>
			<td  align=left width = 50%>
				<INPUT id=reportFormat style="font-size: 18px" name=reportFormat type=radio checked value="<%= RPT_Report_Format_HTML %>"> HTML
				&nbsp;&nbsp;<INPUT id=reportFormat style="font-size: 18px" name=reportFormat type=radio value="<%= RPT_Report_Format_TEXT %>">&nbsp;Text
			</td>
		</tr>
		<%end if%>

		<%if reportID <> RPT_NBR_Cash_Out or reportID <> RPT_NBR_Cash_Out_Z_Report or reportID <> RPT_NBR_Override_CashOut_Z_Report  or _
			reportID <> RPT_NBR_Tracking_Report or reportID = RPT_NBR_Tickets_Need_to_be_Finished or reportID = RPT_NBR_Daily_Report_Boston or _
			reportID = RPT_NBR_AR_Ageing or reportID = RPT_NBR_Tickets_Need_to_be_Finished_Summary or _
   			reportID =  RPT_NBR_Employee_Audit_Summary or reportID = RPT_NBR_Employee_Detail or reportID = RPT_NBR_Void_Details  or _
			reportID = RPT_NBR_AgeingCR then%>
		<tr height=35px>
			<td width = 50% align=right class = "label"  align=right Style="Font-weight=normal">Store: </td>

			<td  align=left> <%= GetStoreDropDown() %>
			</td>
		</tr>
		<% end if %>
		<%
		'	Allow Price List Selection for the following reports.
		if _
			reportID = RPT_NBR_Incoming_Detail_by_Creation Or _
			reportID = RPT_NBR_Incoming_Detail_by_Due_Date Or _
			reportID = RPT_NBR_Incoming_Summary Or _
			reportID = RPT_NBR_Outgoing_Detail Or _
			reportID = RPT_NBR_Outgoing_Summary Or _
			reportID = RPT_NBR_AR_Statement or _
			reportID = RPT_NBR_AR_MultiPickup_Statement  Or _
			reportID = RPT_NBR_Employee_Sales_incoming Or _
			reportID = RPT_NBR_Hourly_Sales_Report Or _
			reportID = RPT_NBR_Sales_Report Or _
			reportID = RPT_NBR_Sales_Comparison Or _
			reportID = RPT_NBR_Invoices_Racked Or _
			reportID = RPT_NBR_Sales_Summary_By_Payment_Types Or _
			reportID = RPT_NBR_Sales_Detail_by_Payment_Date Or _
			reportID = RPT_NBR_Mailing_Label Or _
			reportID = RPT_NBR_Marketing_List Or _
			reportID = RPT_NBR_Detailed_Report Or _
			reportID = RPT_NBR_Incoming_Summary_Riaz Or _
			reportID = RPT_NBR_Outgoing_Summary_Riaz Or _
			reportID = RPT_NBR_Prepay_Invoices_With_Balance Or _
			reportID = RPT_NBR_Tickets_Need_to_be_Finished Or _
			reportID = RPT_NBR_Void_Details Or _
			reportID = RPT_NBR_New_Customers Or _
			reportID = RPT_NBR_Commercial_Statement Or _
			reportID = RPT_NBR_Hourly_IncomingOutgoing_Sales Or _
			reportID = RPT_NBR_CD_DailyActivity Or _
			reportID = RPT_NBR_CD_DailyActivity2 Or _
			reportID = RPT_NBR_RedoReport Or _
			reportID = RPT_NBR_Invoice_Detail Or _
			reportID = RPT_NBR_Coupon_Analysis_Created Or _
			reportID = RPT_NBR_Coupon_Analysis_DateOut Or _
			reportID = RPT_NBR_MiscCreditsCharges _
			or reportID = RPT_NBR_PickedUpInvoices _
			or reportID = RPT_NBR_TicketsNotOnLot _
			or reportID = RPT_NBR_TaxAndSurcharge _
			or reportID = RPT_NBR_OutgoingParkAve _
			or reportID = RPT_NBR_IncomingDelRey _
			or reportID = RPT_NBR_Galaxie_Daily _
			or reportID = RPT_NBR_AR_HakuyoshaHotel _
		then
		%>

			<tr height=35px>
				<td width = 50% align=right class = "label"  align=right Style="Font-weight=normal">Price List: </td>

				<td  align=left> <%= GetPriceListDropDown(l_storeID) %>
				</td>
			</tr>

		<% end if %>

		<%
		if _
			reportID = RPT_NBR_Incoming_Detail_by_Creation Or _
			reportID = RPT_NBR_Incoming_Detail_by_Due_Date Or _
			reportID = RPT_NBR_Incoming_Summary Or _
			reportID = RPT_NBR_Invoice_Detail Or _
			reportID = RPT_NBR_AR_Ageing Or _
			reportID = RPT_NBR_AgeingCR Or _
			reportID = RPT_NBR_AR_Statement or _
			reportID = RPT_NBR_AR_MultiPickup_Statement  Or _
			reportID = RPT_NBR_Outgoing_Detail Or _
			reportID = RPT_NBR_Outgoing_Summary  Or _
			reportID = RPT_NBR_Employee_Sales_incoming Or _
			reportID = RPT_NBR_Hourly_Sales_Report Or _
			reportID = RPT_NBR_Sales_Report Or _
			reportID = RPT_NBR_Sales_Comparison Or _
			reportID = RPT_NBR_Invoices_Racked  Or _
			reportID = RPT_NBR_Sales_Summary_By_Payment_Types Or _
			reportID = RPT_NBR_Sales_Detail_by_Payment_Date Or _
			reportID = RPT_NBR_Route_Payment_Detail Or _
			reportID = RPT_NBR_Account_Balance Or _
			reportID = RPT_NBR_Delivery_List Or _
			reportID = RPT_NBR_Delivery_Manifest Or _
			reportID = RPT_NBR_Sales_Detail_by_Payment_Date Or _
			reportID = RPT_NBR_Mailing_Label Or _
			reportID = RPT_NBR_Marketing_List Or _
			reportID = RPT_NBR_Tickets_Need_to_be_Finished Or _
			reportID = RPT_NBR_Tickets_Need_to_be_Finished_Summary Or _
			reportID = RPT_NBR_Detailed_Report Or _
			reportID = RPT_NBR_Credit_Card_Batch_Process Or _
			reportID = RPT_NBR_Tracking_Report Or _
			reportID = RPT_NBR_Incoming_Summary_Riaz Or _
			reportID = RPT_NBR_Outgoing_Summary_Riaz Or _
			reportID = RPT_NBR_Void_Details Or _
			reportID = RPT_NBR_Prepay_Invoices_With_Balance Or _
			reportID = RPT_NBR_New_Customers Or _
			reportID = RPT_NBR_Commercial_Statement Or _
			reportID = RPT_NBR_Top_Customers Or _
			reportID = RPT_NBR_Hourly_IncomingOutgoing_Sales Or _
			reportId = RPT_NBR_MiscCreditsCharges _
			or reportID = RPT_NBR_PickedUpInvoices _
			or reportID = RPT_NBR_TaxAndSurcharge _
			or reportID = RPT_NBR_OutgoingParkAve _
			or reportID = RPT_NBR_IncomingDelRey _
			or reportID = RPT_NBR_CustomerCode _
			or reportID = RPT_NBR_HakuyoshaTracer _
			or reportID = RPT_NBR_AR_HakuyoshaHotel _

		then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Route: </td>
				<td  align=left > <%= GetRouteDropDown(l_storeid) %>
				</td>
			</tr>

		<% end if %>


		<%
		if reportID = RPT_NBR_PickedUpInvoices _
		then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Customer Source: </td>
				<td  align=left > <%= GetCustSourceDropDown(l_storeid) %>
				</td>
			</tr>

		<% end if %>


		<%
		' For Daily report for Fox -- choice of all routes or no routes
		if _
			reportID = RPT_NBR_Daily_Report _
		then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Route Selection: </td>
				<td  align=left > <%= GetGroupRouteDropDown() %>
				</td>

			</tr>
		<% end if %>

		<%
		'	Allow Customer Selection for the following reports.
		if _
			reportID = RPT_NBR_Incoming_Detail_by_Creation Or _
			reportID = RPT_NBR_Incoming_Detail_by_Due_Date Or _
			reportID = RPT_NBR_Incoming_Summary Or _
			reportID = RPT_NBR_Invoice_Detail Or _
			reportID = RPT_NBR_Outgoing_Detail Or _
			reportID = RPT_NBR_Outgoing_Summary Or _
			reportID = RPT_NBR_AR_Statement or _
			reportID = RPT_NBR_AR_MultiPickup_Statement  Or _
			reportID = RPT_NBR_Sales_Summary_By_Payment_Types Or _
			reportID = RPT_NBR_Sales_Detail_by_Payment_Date Or _
			reportID = RPT_NBR_Delivery_Manifest Or _
			reportID = RPT_NBR_Claim_Report Or _
			reportID = RPT_NBR_Detailed_Report Or _
			reportID = RPT_NBR_Incoming_Summary_Riaz Or _
			reportID = RPT_NBR_Outgoing_Summary_Riaz Or _
			reportID = RPT_NBR_Prepay_Invoices_With_Balance Or _
			reportID = RPT_NBR_Void_Details Or _
			reportID = RPT_NBR_Management_Tasks Or _
			reportID = RPT_NBR_Tracking_Report Or _
			reportID = RPT_NBR_New_Customers Or _
			reportID = RPT_NBR_Commercial_Statement Or _
			reportID = RPT_NBR_CD_DailyActivity Or _
			reportID = RPT_NBR_CD_DailyActivity2 Or _
			reportID = RPT_NBR_RedoReport Or _
			reportID = RPT_NBR_MiscCreditsCharges _
			or reportID = RPT_NBR_PickedUpInvoices _
			or reportID = RPT_NBR_TicketsNotOnLot _
			or reportID = RPT_NBR_TaxAndSurcharge _
			or reportID = RPT_NBR_OutgoingParkAve _
			or reportID = RPT_NBR_IncomingDelRey _
			or reportID = RPT_NBR_AR_HakuyoshaHotel _

		then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Customer: </td>
				<td width = 40% align=left Style="font-size: 14px;height:35px;vertical-align:middle;"> <%= GetCustomerDropDown("") %>
					&nbsp;&nbsp;<INPUT style="height:30px;width:80px;font-size: 18px" value="Search" id=searchButton name=searchButton type=button value=""  onClick="searchForCustomer()">
				</td>

			</tr>
		<% end if %>

		<% if reportID = RPT_NBR_ARStatementCR then %>

			<tr height=35px>
				<td width = 50% class="label" align=right style="font-weight=normal">Phone: </td>
				<td width = 40% align=left style="font-size: 18px;height:35px;vertical-align:middle;"><INPUT type=text align=left size=11 Maxlength="10" id=phone name=phone value="<%= Session("objRP").phone %>">
				</td>
			</tr>
		<% end if %>

		<%
		'  Allow Terminal Selection for the following reports.
		if _
			reportID = RPT_NBR_Daily_Report_Boston _
		then
		%>

			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Terminal: </td>
				<td  align=left > <%= GetTerminalDropDown(l_storeid) %>
				</td>

			</tr>

		<% end if %>
		<%
		'	Allow Employee Selection for the following reports.
		if _
			reportID = RPT_NBR_Sales_Detail_by_Payment_Date Or _
			reportID = RPT_NBR_Invoice_Detail Or _
			reportID = RPT_NBR_Employee_Sales_incoming Or _
			reportID = RPT_NBR_Employee_Time Or _
			reportID = RPT_NBR_Employee_Detail Or _
			reportID = RPT_NBR_Detailed_Report Or _
			reportID = RPT_NBR_Void_Details Or _
			reportID = RPT_NBR_Tracking_Report Or _
			reportID = RPT_NBR_Employee_Tasks Or _
			reportID = RPT_NBR_Hourly_IncomingOutgoing_Sales Or _
			reportID = RPT_NBR_EmployeeTimeWBreaks Or _
			reportID = RPT_NBR_MiscCreditsCharges _
			or reportID = RPT_NBR_TicketsNotOnLot _
			or reportID = RPT_NBR_TaxAndSurcharge _
			or reportID = RPT_NBR_Sales_Discount_Details _
			or reportID = RPT_NBR_CD_Productivity _
		then
		%>

			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Employee: </td>
				<td align=left > <%= GetEmployeeDropDown(l_storeid) %>
				</td>
			</tr>

		<% end if %>


		<%
		'	Allow Dept Selection for the following reports.
		if _
			reportID = RPT_NBR_Invoice_Detail _
			or reportID = RPT_NBR_Item_Notes _
			or reportID = RPT_NBR_Hourly_IncomingOutgoing_Sales _
			or reportID = RPT_NBR_RedoReport _
			or reportID = RPT_NBR_DetailedRacking _
		then
		%>

			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Department: </td>
				<td align=left > <%= GetDepartmentDropDown(l_storeid) %>
				</td>
			</tr>

		<% end if %>

		<%
		if _
			reportID = RPT_NBR_Detailed_Invoice_byTime _
		then
		%>

			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Dept and Start Date/Time: </td>
				<td align=left > <%= GetDeptAndStartTime() %>
				</td>
			</tr>

		<% end if %>

		<%
		if _
			reportID = RPT_NBR_Weekly_Sales _
		then
		%>

			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Week: </td>
				<td align=left > <%= GetWeekDropDown(l_storeid) %>
				</td>
			</tr>

		<% end if %>

		<%
		'	Allow Start Date selection for the following reports.
		if requesterName <> RPT_Requester_Name_Schedule Then
		if _
			reportID = RPT_NBR_Coupon_Analysis_Created Or _
			reportID = RPT_NBR_Coupon_Analysis_DateOut Or _
			reportID = RPT_NBR_PromotionAnalysis_DateOut Or _
			reportID = RPT_NBR_PromotionAnalysis_DateCreated Or _
			reportID = RPT_NBR_Incoming_Detail_by_Creation Or _
			reportID = RPT_NBR_Incoming_Detail_by_Due_Date Or _
			reportID = RPT_NBR_Incoming_Summary Or _
			reportID = RPT_NBR_Invoice_Detail Or _
			reportID = RPT_NBR_Outgoing_Detail Or _
			reportID = RPT_NBR_Outgoing_Summary  Or _
			reportID = RPT_NBR_AR_Statement or _
			reportID = RPT_NBR_AR_MultiPickup_Statement  Or _
			reportID = RPT_NBR_Employee_Sales_incoming Or _
			reportID = RPT_NBR_Hourly_Sales_Report Or _
			reportID = RPT_NBR_Tickets_Need_to_be_Finished Or _
			reportID = RPT_NBR_Tickets_Need_to_be_Finished_Summary Or _
			reportID = RPT_NBR_Sales_Comparison Or _
			reportID = RPT_NBR_Sales_Report Or _
			reportID = RPT_NBR_Rack_History  Or _
			reportID = RPT_NBR_Sales_Summary_By_Payment_Types Or _
			reportID = RPT_NBR_Sales_Detail_by_Payment_Date Or _
			reportID = RPT_NBR_Route_Payment_Detail  Or _
			reportID = RPT_NBR_Delivery_List Or _
			reportID = RPT_NBR_Employee_Time Or _
			reportID = RPT_NBR_Claim_Report Or _
			reportID = RPT_NBR_Employee_Detail Or _
			reportID = RPT_NBR_Detailed_Report Or _
			reportID = RPT_NBR_Daily_Report Or _
			reportID = RPT_NBR_Daily_Report_Boston Or _
			reportID = RPT_NBR_Tracking_Report Or _
			reportID = RPT_NBR_Incoming_Summary_Riaz Or _
			reportID = RPT_NBR_Outgoing_Summary_Riaz Or _
			reportID = RPT_NBR_Prepay_Invoices_With_Balance Or _
			reportID = RPT_NBR_Sales_Discount_Details Or _
			reportID = RPT_NBR_Void_Details Or _
			reportID = RPT_NBR_Galaxie_Daily Or _
			reportID = RPT_NBR_New_Customers Or _
			reportID = RPT_NBR_Employee_Tasks Or _
			reportID = RPT_NBR_Commercial_Statement Or _
			reportID = RPT_NBR_Suspicious_Activity Or _
			reportID = RPT_NBR_Top_Customers Or _
			reportID = RPT_NBR_Hourly_IncomingOutgoing_Sales Or _
			reportID = RPT_NBR_Item_Notes Or _
			reportID = RPT_NBR_CD_DailyActivity Or _
			reportID = RPT_NBR_CD_DailyActivity2 Or _
			reportID = RPT_NBR_EmployeeTimeWBreaks Or _
			reportID = RPT_NBR_RedoReport Or _
			reportID = RPT_NBR_DetailedRacking Or _
			reportID = RPT_NBR_MiscCreditsCharges _
			or reportID = RPT_NBR_PickedUpInvoices _
			or reportID = RPT_NBR_TaxAndSurcharge _
			or reportID = RPT_NBR_OutgoingParkAve _
			or reportID = RPT_NBR_IncomingDelRey _
			or reportID = RPT_NBR_ARStatementCR _
			or reportID = RPT_NBR_CustomerCode _
			or reportID = RPT_NBR_HakuyoshaTracer _
			or reportID = RPT_NBR_AR_HakuyoshaHotel _
			or reportID = RPT_NBR_CD_Productivity _

		then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Start Date: </td>
				<td align=left >
					<INPUT readonly id=rangeStartDate name=rangeStartDate class=text style="WIDTH: 115px;vertical-align:middle;font-size:18px" value="<%= Date() %>" >
					<INPUT class=touch id=bttnRangeStartDate name=bttnRangeStartDate type=button value="" style="font-size: 18px;width:25px;height:25px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="setRangeStartDate();">
				    <select id="sel_dtRange" style="font-size: 18px" onChange="updateDateRange(this, 'rangeStartDate', 'rangeEndDate')">
				        <option value="0"></option>
				        <option value="1">Yesterday</option>
				        <option value="2">Week To Date</option>
				        <option value="3">Last Week</option>
				        <option value="4">Month To Date</option>
				        <option value="5">Last Month</option>
				        <option value="6">Year To Date</option>
				        <option value="7">Last Year</option>
				    </select>
				</td>

			</tr>
		<%
		end if
		end if
		%>

		<%
		' Allow start time selection for following reports
		if _
			reportID = RPT_NBR_Incoming_Detail_by_Creation Or _
			reportID = RPT_NBR_Incoming_Detail_by_Due_Date Or _
			reportID = RPT_NBR_Invoice_Detail Or _
			reportID = RPT_NBR_Hourly_IncomingOutgoing_Sales _
			or reportID = RPT_NBR_PickedUpInvoices _
			or reportID = RPT_NBR_CD_Productivity _


		then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Start Time: </td>
				<td width = 50%  align=left> <%= GetTimeDropDown("start") %>
				</td>
			</tr>

		<%
		end if
		%>

		<%
		'	Allow End Date Selection for the following reports.
		if requesterName <> RPT_Requester_Name_Schedule Then
		if _
			reportID = RPT_NBR_Coupon_Analysis_Created Or _
			reportID = RPT_NBR_Coupon_Analysis_DateOut Or _
			reportID = RPT_NBR_PromotionAnalysis_DateOut Or _
			reportID = RPT_NBR_PromotionAnalysis_DateCreated Or _
			reportID = RPT_NBR_Incoming_Detail_by_Creation Or _
			reportID = RPT_NBR_Incoming_Detail_by_Due_Date Or _
			reportID = RPT_NBR_Incoming_Summary Or _
			reportID = RPT_NBR_Invoice_Detail Or _
			reportID = RPT_NBR_Detailed_Invoice_byTime Or _
			reportID = RPT_NBR_Outgoing_Detail Or _
			reportID = RPT_NBR_Outgoing_Summary Or _
			reportID = RPT_NBR_AR_Statement or _
			reportID = RPT_NBR_AR_MultiPickup_Statement  Or _
			reportID = RPT_NBR_Employee_Sales_incoming Or _
			reportID = RPT_NBR_Hourly_Sales_Report Or _
			reportID = RPT_NBR_Sales_Comparison Or _
			reportID = RPT_NBR_Sales_Report Or _
			reportID = RPT_NBR_Rack_History  Or _
			reportID = RPT_NBR_Sales_Summary_By_Payment_Types Or _
			reportID = RPT_NBR_Sales_Detail_by_Payment_Date Or _
			reportID = RPT_NBR_Route_Payment_Detail Or _
			reportID = RPT_NBR_Employee_Time Or _
			reportID = RPT_NBR_Claim_Report Or _
			reportID = RPT_NBR_Employee_Detail Or _
			reportID = RPT_NBR_Detailed_Report Or _
			reportID = RPT_NBR_Daily_Report_Boston Or _
			reportID = RPT_NBR_Tracking_Report Or _
			reportID = RPT_NBR_Incoming_Summary_Riaz Or _
			reportID = RPT_NBR_Outgoing_Summary_Riaz Or _
			reportID = RPT_NBR_Prepay_Invoices_With_Balance Or _
			reportID = RPT_NBR_Void_Details Or _
			reportID = RPT_NBR_Sales_Discount_Details Or _
			reportID = RPT_NBR_New_Customers Or _
			reportID = RPT_NBR_Employee_Tasks Or _
			reportID = RPT_NBR_Commercial_Statement Or _
			reportID = RPT_NBR_Suspicious_Activity Or _
			reportID = RPT_NBR_Top_Customers Or _
			reportID = RPT_NBR_AR_Ageing Or _
			reportID = RPT_NBR_Hourly_IncomingOutgoing_Sales Or _
			reportID = RPT_NBR_Item_Notes Or _
			reportID = RPT_NBR_CD_DailyActivity Or _
			reportID = RPT_NBR_CD_DailyActivity2 Or _
			reportID = RPT_NBR_EmployeeTimeWBreaks _
			or reportID = RPT_NBR_RedoReport _
			or reportID = RPT_NBR_DetailedRacking _
			or reportID = RPT_NBR_MiscCreditsCharges _
			or reportID = RPT_NBR_PickedUpInvoices _
			or reportID = RPT_NBR_TicketsNotOnLot _
			or reportID = RPT_NBR_TaxAndSurcharge _
			or reportID = RPT_NBR_OutgoingParkAve _
			or reportID = RPT_NBR_IncomingDelRey _
			or reportID = RPT_NBR_ARStatementCR _
			or reportID = RPT_NBR_AgeingCR _
			or reportID = RPT_NBR_CustomerCode _
			or reportID = RPT_NBR_AR_HakuyoshaHotel _
			or reportID = RPT_NBR_CD_Productivity _

		then
		%>

			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">End Date: </td>
				<td  align=left width = 50%>
					<INPUT readonly id=rangeEndDate name=rangeEndDate class=text style="WIDTH: 115px;vertical-align:middle;font-size:18px" value="<%= Date() %>" >
					<INPUT class=touch id=bttnRangEndDate name=bttnRangeEndDate type=button value="..." style="width:25px;font-size:18px;height:25px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="setRangeEndDate();">
				</td>
			</tr>
		<%
		end if
		end if
		%>

		<%
		' Allow end time selection for following reports
		if _
			reportID = RPT_NBR_Incoming_Detail_by_Creation Or _
			reportID = RPT_NBR_Incoming_Detail_by_Due_Date Or _
			reportID = RPT_NBR_Invoice_Detail Or _
			reportID = RPT_NBR_Hourly_IncomingOutgoing_Sales _
			or reportID = RPT_NBR_Detailed_Invoice_byTime _
			or reportID = RPT_NBR_PickedUpInvoices _
			or reportID = RPT_NBR_TicketsNotOnLot _
			or reportID = RPT_NBR_CD_Productivity _


		then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">End Time: </td>
				<td width = 50%  align=left> <%= GetTimeDropDown("end") %>
				</td>
			</tr>

		<%
		end if
		%>


		<%

		if requesterName <> RPT_Requester_Name_Schedule Then
		if _
			reportID = RPT_NBR_AR_Statement Or _
			reportID = RPT_NBR_AR_MultiPickup_Statement Or _
			reportID = RPT_NBR_ARStatementCR _
			or reportID = RPT_NBR_AR_HakuyoshaHotel _

		then
		%>

			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Statement Date: </td>
				<td  align=left width = 50%>
					<INPUT readonly id=statementDate name=statementDate class=text style="WIDTH: 115px;vertical-align:middle;font-size: 18px" value="<%= Date() %>">
					<INPUT class=touch id=bttnStatementDate name=bttnStatementDate type=button value="..." style="width:25px;font-size: 18px;height:25px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="show_calendar('reportParmsForm.statementDate');;">
				</td>
			</tr>
		<%
		end if
		end if
		%>




		<%

		if requesterName <> RPT_Requester_Name_Schedule Then
		if _
			reportID = RPT_NBR_AR_Statement Or _
			reportID = RPT_NBR_AR_MultiPickup_Statement Or _
			reportID = RPT_NBR_ARStatementCR _
			or reportID = RPT_NBR_AR_HakuyoshaHotel _

		then
		%>

			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Due Date: </td>
				<td  align=left width = 50%>
					<INPUT readonly id=statementDueDate name=statementDueDate class=text style="WIDTH: 115px;vertical-align:middle;font-size: 18px;" value="<%= Date() %>">
					<INPUT class=touch id=bttnStatementDueDate name=bttnStatementDueDate type=button value="..." style="width:25px;height:25px;font-size: 18px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="show_calendar('reportParmsForm.statementDueDate');;">
				</td>
			</tr>
		<%
		end if
		end if
		%>

		<%
		if reportID = RPT_NBR_Sales_Discount_Details _
		then
		%>
			<tr height=35px width=100%>
				<td width = 50% class = "label" align=right Style="Font-weight=normal">Discount</td>
				<td width = 50% >
					<%=GetDiscountDropdown(l_storeID)%>
				</td>
			</tr>
		<%
		end if
		%>


		<%
		' Add filter to invoice detail that shows invoices less than or equal to an amount
		if reportID = RPT_NBR_Invoice_Detail _
			or reportID = RPT_NBR_PickedUpInvoices _

		then

		%>
			<tr height=35px width=100%>
				<td width = 50% class = "label" align=right Style="Font-weight=normal">Invoices Less than or Equal to:<br>(Criteria is ignored for $0)</td>
				<td width = 50% >
					<B>$&nbsp</B><INPUT type=text align=left size=11 Maxlength="9" style="font-size: 18px" id=rangeStartAmount name=rangeStartAmount value="0">
				</td>
			</tr>
		<%
		end if
		%>

		<%
		'	Allow Transactions Through Date Selection for the following
		'	report.
		'	Added by J.Johnston, 02Feb04

		if 	reportID = RPT_NBR_Credit_Card_Batch_Process then
		%>

			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Accounts with Balance Due as of: </td>
				<!--<td  align=left width = 50%>
					<INPUT readonly id=tranThroughDate name=tranThroughDate class=text style="WIDTH: 115px;vertical-align:middle;" value="<%= Date() %>">
					<INPUT class=touch id=bttnTranThroughDate name=bttnTranThroughDate type=button value="..." style="width:25px;height:25px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="setTranThroughDate();">
				</td>-->
				<td align=left >
					<INPUT readonly id=rangeStartDate name=rangeStartDate class=text style="WIDTH: 115px;vertical-align:middle;font-size: 18px" value="<%= Date() %>">
					<INPUT class=touch id=bttnRangeStartDate name=bttnRangeStartDate type=button value="" style="width:25px;height:25px;font-size: 18pxvertical-align:middle;background-image:url(../images/Calender.gif);" onClick="setRangeStartDate();">
				</td>
			</tr>
		<%
		end if

		%>

		<%
		'	Allow Effective On Date Selection for the following
		'	report.
		'	Added by J.Johnston, 02Feb04

		if 	reportID = RPT_NBR_Credit_Card_Batch_Process then
		%>

			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Processed On Date: </td>
				<!--<td  align=left width = 50%>
					<INPUT readonly id=effectiveDate name=effectiveDate class=text style="WIDTH: 115px;vertical-align:middle;" value="<%= Date() %>">
					<INPUT class=touch id=bttnEffectiveDate name=bttnEffectiveDate type=button value="..." style="width:25px;height:25px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="setEffectiveDate();">
				</td>-->
								<td  align=left width = 50%>
					<INPUT readonly id=rangeEndDate name=rangeEndDate class=text style="WIDTH: 115px;vertical-align:middle;font-size: 18px;" value="<%= Date() %>">
					<INPUT class=touch id=bttnRangEndDate name=bttnRangeEndDate type=button value="..." style="width:25px;height:25px;font-size: 18px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="setRangeEndDate();">
				</td>
			</tr>
		<%
		end if

		%>

		<%
		'	Allow Compare To Start Date selection for Sales Comparison Report.
		if reportID = RPT_NBR_Sales_Comparison then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Compare To Range Start: </td>
				<td align=left >
					<INPUT readonly id=rangeStartDateCompareTo name=rangeStartDateCompareTo class=text style="WIDTH: 115px;vertical-align:middle;font-size: 18px" value="<%= Date() %>">
					<INPUT class=touch id=bttnrangeStartDateCompareTo name=bttnrangeStartDateCompareTo type=button value="..." style="width:25px;height:25px;font-size: 18px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="setRangeStartDateCompareTo();">
				    <select id="sel_dtRangeTo" style="font-size: 18px" onChange="updateDateRange(this, 'rangeStartDateCompareTo', 'rangeEndDateCompareTo')">
				        <option value="0"></option>
				        <option value="1">Yesterday</option>
				        <option value="2">Week To Date</option>
				        <option value="3">Last Week</option>
				        <option value="4">Month To Date</option>
				        <option value="5">Last Month</option>
				        <option value="6">Year To Date</option>
				        <option value="7">Last Year</option>
				    </select>
				</td>
			</tr>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Compare To Range End: </td>
				<td align=left >
					<INPUT readonly id=rangeEndDateCompareTo name=rangeEndDateCompareTo class=text style="WIDTH: 115px;vertical-align:middle;font-size: 18px" value="<%= Date() %>">
					<INPUT class=touch id=bttnrangeEndDateCompareTo name=bttnrangeEndDateCompareTo type=button value="..." style="width:25px;height:25px;font-size: 18px;vertical-align:middle;background-image:url(../images/Calender.gif);" onClick="setRangeEndDateCompareTo();">
				</td>
			</tr>
		<% end if %>

		<%
			' Invoices Racked report specific parameters.
			if reportID = RPT_NBR_Invoices_Racked Or _
			   reportID = RPT_NBR_Rack_History _
		    then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Start Rack Number: </td>
				<td width = 50%  align=left ><INPUT type=text style="font-size: 18px" id=rangeStartRackNumber name=rangeStartRackNumber value="">
				</td>
			</tr>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">End Rack Number: </td>
				<td width = 50%  align=left ><INPUT type=text style="font-size: 18px" id=rangEndRackNumber name=rangeEndRackNumber value="">
				</td>
			</tr>
		<% end if %>



		<%
			' Delivery Manifest - show address info.
			if reportID = RPT_NBR_Delivery_Manifest then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Show Address Information: </td>
				<td width = 50%  align=left ><INPUT id=showAddress  style="font-size: 18px" name=showAddress  type=checkbox value="1">
				</td>
			</tr>
		<% end if %>

		<%
			' Invoices Racked report specific parameters.
			if reportID = RPT_NBR_Invoices_Racked then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Show All Active Invoices: </td>
				<td width = 50%  align=left ><INPUT id=showAllActive  style="font-size: 18px" name=showAllActive  type=checkbox value="1">
				</td>
			</tr>
		<% end if %>



		<%
			' Tickets to be finished report specific parameters.
			if reportID = RPT_NBR_Tickets_Need_to_be_Finished then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Pickup Time: </td>
				<td width = 50%  align=left> <%= GetTimeDropDown("") %>
				</td>
			</tr>

			<tr height=35px>
				<td width = 2 class = "label" Style="Font-weight=normal">&nbsp;</td>
				<td width = 50%  style="font-size: 18px"><INPUT id=onlyOutsideService name=onlyOutsideService type=checkbox value="1">Only Display Out Side Services
				</td>
			</tr>
		<% end if %>

		<%
			if reportID = RPT_NBR_Tickets_Need_to_be_Finished  then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Include Outside Services</td>
				<td width = 50%  align=left><INPUT id=includeOutsideService  name=includeOutsideService  checked type=checkbox value="1">
				</td>
			</tr>
		<% end if %>

		<%
			' Item Tracking Related Parameters
			if reportID = RPT_NBR_Item_Tracking then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Elapsed Hours: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" style="font-size: 18px" id=numberOfHours name=numberOfHours value="<%= 0 %>">
				</td>
			</tr>
		<% end if %>

		<%
			' Credit Card Expiration specific parameters.
			if reportID = RPT_NBR_Credit_Card_Expiration_Report then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Expiry Month: </td>
				<td width = 50%  align=left> <%= GetMonthDropDown("monthNumber", 0) %>
				</td>
			</tr>

			<tr height=35px>
				<td width = 2 class = "label" Style="Font-weight=normal">&nbsp;</td>
				<td width = 50%  style="font-size: 18px"><B>OR</B>
				</td>
			</tr>

			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Number of Months to Expiration: </td>
				<td width = 50%  align=left ><%= GetMonthNumberDropDown("numberOfMonths", -1) %>
				</td>
			</tr>
		<% end if %>


		<%
			' Delivery List report specific parameters.
			if 	reportID = RPT_NBR_Delivery_List then
		%>
			<tr height=35px>
				<td width = 2 class = "label" Style="Font-weight=normal">&nbsp;</td>
				<td width = 50%  style="font-size: 18px"><INPUT id=onlyRackedInvoices name=onlyRackedInvoices checked type=checkbox value="1">Include Only Racked Invoices
				</td>
			</tr>
		<% end if %>

		<%
		if reportID = RPT_NBR_Tickets_Need_to_be_Finished_Summary then
		%>
			<tr height=35px>
				<td width = 50% align=right class = "label" Style="Font-weight=normal">&nbsp;</td>
				<td width = 50%  style="font-size: 18px"><INPUT id=includeDeptDetail name=includeDeptDetail type=checkbox value="1">Show Invoice Details
				</td>
			</tr>
		<% end if %>

		<%
			' Account Statement specific parameters
			if 	reportID = RPT_NBR_AR_Statement or _
			    reportID = RPT_NBR_AR_MultiPickup_Statement or _
			    reportID = RPT_NBR_Account_Balance or _
			    reportID = RPT_NBR_AR_Ageing _
			    or reportID = RPT_NBR_ARStatementCR _
			    or reportID = RPT_NBR_AgeingCR _
			then
		%>
			<tr height=35px>
				<td width = 50% align=right class = "label" Style="Font-weight=normal">&nbsp;</td>
				<td width = 50%  style="font-size: 18px"><INPUT id=includeDeptDetail name=includeDeptDetail type=checkbox value="1">Show Invoice Details
				</td>
			</tr>
			<tr height=35px>
				<td width = 50% align=right class = "label" Style="Font-weight=normal">&nbsp;</td>
				<td width = 50%  style="font-size: 18px"><INPUT id=includeActiveInvoices name=includeActiveInvoices type=checkbox value="1"
				<%

					strSQL = "select incActiveInvoices from miscsetup"
					set objMiscSetup = getDisconnectedRecordset(strSQL)

					if objMiscSetup("incActiveInvoices")  then %>
						checked
				<%
					end if
				 %>
				>Include Active Invoices
				</td>
			</tr>

		<% end if %>
		<% if reportID = RPT_NBR_AR_Ageing  or reportID = RPT_NBR_AgeingCR then %>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Sort By:</td>
				<td width = 50%  align=left >
				<select  style="font-size: 18px" name="ageingSortBy">
					<option value="lastname">Customer Last Name</option>
					<option value="amountPastDue">Past Due Amount</option>
				</select>
				</td>
			</tr>
		<% end if %>
		<%
			' Account Statement specific parameters
			if 	reportID = RPT_NBR_AR_Statement or _
			    reportID = RPT_NBR_AR_MultiPickup_Statement _
				or reportID = RPT_NBR_AR_HakuyoshaHotel _

			then
		%>

			<tr height=35px>
				<td width = 50% align=right class = "label" Style="Font-weight=normal">&nbsp;</td>
				<td width = 50%  style="font-size: 18px"><INPUT id=showZeroBalanceStatements name=showZeroBalanceStatements type=checkbox value="1">Show Zero Balance Statements
				</td>


			</tr>
		<% end if %>

		<%
			' Account Statement specific parameters
			if 	reportID = RPT_NBR_AR_Statement or _
			    reportID = RPT_NBR_AR_MultiPickup_Statement _
				or reportID = RPT_NBR_AR_HakuyoshaHotel _
			then
		%>

			<tr height=35px>
				<td width = 50% align=right class = "label" Style="Font-weight=normal">&nbsp;</td>
				<td width = 50%  style="font-size: 18px"><INPUT id=excludeNegativeBalances name=excludeNegativeBalances type=checkbox value="1">Exclude Negative Balance Statements
				</td>


			</tr>
		<% end if %>

		<%
			' Account Statement specific parameters
			if 	reportID = RPT_NBR_AR_Statement or _
			    reportID = RPT_NBR_AR_MultiPickup_Statement _
				or reportID = RPT_NBR_AR_HakuyoshaHotel _

			then
		%>

			<tr height=35px>
				<td width = 50% align=right class = "label" Style="Font-weight=normal">&nbsp;</td>
				<td width = 50%  style="font-size: 18px"><INPUT id=emailStatements name=emailStatements type=checkbox value="1">Email Statements
				</td>


			</tr>
		<% end if %>

		<%
			' Employee Sales Incoming specific parameters.
			if 	reportID = RPT_NBR_Employee_Sales_incoming then
		%>
			<tr height=35px>
				<td width = 2 class = "label" Style="Font-weight=normal">&nbsp;</td>
				<td width = 50%  style="font-size: 18px"><INPUT id=includeDeptDetail name=includeDeptDetail checked type=checkbox value="1">Show Department Level Detail
				</td>
			</tr>
		<% end if %>




		<%
			if 	reportID = RPT_NBR_Invoices_Racked then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">On Rack More Then </td>
				<td width = 50%  align=left style="font-size: 18px" ><INPUT type=text  size=4 Maxlength="4" id=rackingAge name=rackingAge value="">&nbsp;Days
				</td>
			</tr>
		<% end if %>



		<%
			if 	reportID = RPT_NBR_Top_Customers then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Maximum Customers </td>
				<td width = 50%  align=left ><INPUT type=text  style="font-size: 18px" size=4 Maxlength="4" id=maxCustomers name=maxCustomers value="100">
				</td>
			</tr>
		<% end if %>



		<%
			if 	reportID = RPT_NBR_Management_Tasks then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Task Status:</td>
				<td width = 50%  align=left >
				<select style="font-size: 18px">
					<option value="1">Only Open</option>
					<option value="2">Only Closed</option>
					<option value="3">Open and Closed</option>
				</select>
				</td>
			</tr>
		<% end if %>


		<%
			if 	reportID = RPT_NBR_Tickets_Need_to_be_Finished then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Invoice Filter:</td>
				<td width = 50%  align=left >
				<select name="invoiceTypeFilter" style="font-size: 18px">
					<option value="all">All Invoices</option>
					<option value="detailed">Detailed Invoices</option>
					<option value="quick">Quick Invoices</option>
				</select>
				</td>
			</tr>
		<% end if %>


		<%
			if 	reportID = RPT_NBR_Tickets_Need_to_be_Finished then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Sort By:</td>
				<td width = 50%  align=left >
				<select name="ticketSortBy" style="font-size: 18px">
					<option value="invoice">Ticket Number</option>
					<option value="duedate">Due Date</option>
					<option value="customer">Customer Name</option>
				</select>
				</td>
			</tr>
		<% end if %>



		<%
			if 	reportID = RPT_NBR_Invoices_Racked then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Sort By:</td>
				<td width = 50%  align=left >
				<select name="rackSortBy" style="font-size: 18px">
					<option value="invoice">Ticket Number</option>
					<option value="rack">Rack Number</option>
					<option value="customer">Customer Name</option>
					<option value="rackingdate">Racked Date</option>
				</select>
				</td>
			</tr>
		<% end if %>


		<%
			if 	reportID = RPT_NBR_Employee_Time then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Sort By:</td>
				<td width = 50%  align=left >
				<select name="employeeTimeSortBy" style="font-size: 18px">
					<option value="lastname">Employee Last Name</option>
					<option value="firstname">Employee First Name</option>
				</select>
				</td>
			</tr>
		<% end if %>

		<%
			if 	reportID = RPT_NBR_Employee_Time then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Show Updates:</td>
				<td width = 50%  align=left >
				<select name="showEmployeeTimeUpdates" style="font-size: 18px">
					<option value="1">Yes</option>
					<option value="0">No</option>
				</select>
				</td>
			</tr>
		<% end if %>


		<%
			' Marketing List and Label Specific Common Parameters.
			if 	reportID = RPT_NBR_Marketing_List Or _
				reportID = RPT_NBR_Mailing_Label _
			then
		%>

			<tr height=35px width=100%>
				<td width = 50% class = "label" align=right Style="Font-weight=normal">Inactive Days Range: </td>
				<td width = 50% >
					<INPUT type=text  style="font-size: 18px" size=11 Maxlength="9" id=rangeStartInactiveDays name=rangeStartInactiveDays value="0">
					&nbsp;<b>To</b>&nbsp;
					<INPUT type=text  style="font-size: 18px" size=11 Maxlength="9" id=rangeEndInactiveDays name=rangeEndInactiveDays value="0">
				</td>
			</tr>
			<tr height=35px  width=100%>
				<td width = 50% class = "label" align=right Style="Font-weight=normal">Birth Month Range: </td>
				<td width = 50%  align=left  style="font-size: 18px">
					<%= GetMonthDropDown("rangeStartBirthMonth", 0) %>
					&nbsp;<b>To</b>&nbsp;
					<%= GetMonthDropDown("rangeEndBirthMonth", 0) %>
				</td>
			</tr>

			<tr height=35px width=100%>
				<td width = 50% class = "label" align=right Style="Font-weight=normal">Amount Spent Range: </td>
				<td width = 50%  style="font-size: 18px">
					<INPUT type=text align=left size=11 Maxlength="9" style="font-size: 18px" id=rangeStartAmount name=rangeStartAmount value="0">
					&nbsp;<b>To</b>&nbsp;
					<INPUT type=text  align=left size=11 Maxlength="9" style="font-size: 18px" id=rangeEndAmount name=rangeEndAmount value="0">
				</td>
			</tr>

			<tr height=35px width=100%>
				<td width = 50% class = "label" align=right Style="Font-weight=normal">Days Since Sign-up: </td>
				<td width = 50% ><INPUT type=text  size=11 Maxlength="9" style="font-size: 18px" id=elapsedDaysSinceFirstSignUp name=elapsedDaysSinceFirstSignUp value="0">
				</td>
			</tr>

		<% end if %>

		<%
		'	Allow Customer Selection for the following reports.
		if _
			reportID = RPT_NBR_Claim_Report _
		then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Claim Status: </td>
				<td width = 40% align=left > <%= GetClaimStatusDropDown() %>
				</td>
			</tr>
		<% end if %>

		<%

		if _
			reportID = RPT_NBR_Employee_Tasks _
		then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Status: </td>
				<td width = 40% align=left > <%= GetStatusDropDown() %>
				</td>
			</tr>
		<% end if %>

		<%
			if reportID = RPT_NBR_Employee_Tasks then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Overdue Tasks: </td>
				<td width = 50%  align=left ><INPUT id=showOverdue  name=showOverdue  type=checkbox value="1">
				</td>
			</tr>
		<% end if %>

		<% ' Allow to choose whether based on incoming invoices or outgoing
			if reportID = RPT_NBR_TaxAndSurcharge _
			   or reportID = RPT_NBR_CustomerCode _
			then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Based on:</td>
				<td width = 50%  align=left ><% = GetPrepayTypeDropDown() %>
				</td>
			</tr>
		<% end if %>


		<%
		'	Allow Customer Selection for the following reports.
			if reportID = RPT_NBR_Hourly_IncomingOutgoing_Sales then
		%>
			<tr height=35px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Day of Week: </td>
				<td width = 50%  align=left ><% = GetDayDropDown("dayOfWeek", 0) %>
				</td>
			</tr>
		<% end if %>
		

		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>

		<tr>
			<td width = 50% align=right >
				<INPUT class=touchnoborder id=ok name=ok type=button value=""
					onClick="submitForm();"
					style="background-image:url(../images/Ok.gif);">
			</td>
			<td width = 50% align=left >
				<INPUT class=touchnoborder id=close name=close type=button value="" onClick="cancelForm()"
					style="background-image:url(../images/Cancel.gif);">
			</td>
		</tr>

	</table>
</form>
</BODY>
</HTML>
