<%@ Language=VBScript %>
<% option explicit %>

<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->

<!-- #include file="CheckSessionExpiry.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%	
	dim l_reportID
	dim l_StartDate
	dim l_EndDate
	dim paramStatus
	dim userAction 
	dim l_storeID
	dim l_terminalID
	dim l_terminalName
	dim l_employeeID
	dim l_employeeName
	dim isSubmitted
	
	l_storeID = session("storeID")
	l_terminalID = session("objRP").terminalID
	l_employeeID = session("objRP").employeeID
	l_reportID = session("objRP").reportNumber
	l_startDate = session("objRP").rangeStartDate
	l_endDate = session("objRP").rangeEndDate


	initializeForm()

	function initializeForm()
		dim sqltxt
		dim sqlRst
		
		sqltxt = "select employeename from employee where employeeid = " & l_employeeID
		
		set sqlRst = getDisconnectedRecordset(sqltxt)
		if not sqlRst.bof and not sqlRst.eof then
			l_employeeName = sqlRst("employeeName")
		end if 	
		sqltxt = "select [name] from terminal where terminalid = " & l_terminalID
		
		set sqlRst = getDisconnectedRecordset(sqltxt)
		if not sqlRst.bof and not sqlRst.eof then
			l_terminalName = sqlRst("Name")
		end if 	
		sqlRst.close
		set sqlRst = nothing	
	end function	
	
	function updateReportParams()
		Session("objRP").nbrOf1Cents = CLng(Request.Form("nbrOf1Cents"))
		Session("objRP").nbrOf5Cents = CLng(Request.Form("nbrOf5Cents"))
		Session("objRP").nbrOf10Cents = CLng(Request.Form("nbrOf10Cents"))
		Session("objRP").nbrOf25Cents = CLng(Request.Form("nbrOf25Cents"))
		Session("objRP").nbrOf1Dollars = CLng(Request.Form("nbrOf1Dollars"))
		Session("objRP").nbrOf5Dollars = CLng(Request.Form("nbrOf5Dollars"))
		Session("objRP").nbrOf10Dollars = CLng(Request.Form("nbrOf10Dollars"))
		Session("objRP").nbrOf20Dollars = CLng(Request.Form("nbrOf20Dollars"))
		Session("objRP").nbrOf50Dollars = CLng(Request.Form("nbrOf50Dollars"))
		Session("objRP").nbrOf100Dollars = CLng(Request.Form("nbrOf100Dollars"))
		Session("objRP").checkAmount = CCur(Request.Form("checkAmount"))
		Session("objRP").ccAmount = CCur(Request.Form("ccAmount"))
		Session("objRP").tradeAmount = CCur(Request.Form("tradeAmount"))
		Session("objRP").couponAmount = CCur(Request.Form("couponAmount"))
		Session("objRP").endingAmount = CCur(Request.Form("endingAmount"))
		Session("objRP").rangeStartAmount = CCur(Request.Form("rangeStartAmount"))
		Response.Redirect("report.asp")	
	end function
	
%>

<HTML>

<HEAD>

<TITLE>Report Parameter Selection</TITLE>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

</HEAD>

<script language="javascript" type="text/javascript">

	function submitForm() {
		document.orCashOutForm.submit();
	}
	
	function closeForm() {
		document.orCashOutForm.action = "overrideCashOutZ.asp";
		document.orCashOutForm.submit();
	}


</SCRIPT>

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="JavaScript" src="../script/validation.js.js"></script>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->

<H1>Override Report Parameters </H1>

<FORM id="orCashOutForm" name="orCashOutForm" action="report.asp" method="POST" onload="">

	<input type="hidden" name="reportID" value="<%= l_reportID%>">
	<input type="hidden" name="storeID" value="<%= l_storeID %>">
	<input type="hidden" name="terminalID" value="<%= l_terminalID %>">
	<input type="hidden" name="rangeStartDate" value="<% = l_startDate %>">
	<input type="hidden" name="rangeEndDate" value="<% = l_endDate %>">
	<!-- 
	<TABLE ALIGN=center WIDTH="400px" BORDER=1 CELLSPACING=1 CELLPADDING=5 >
	-->

	<TABLE ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=1 CELLPADDING=0 >
		<tr width=100%><td align=center><b><%= Request.QueryString("reportName") %><b></td></tr> 
	</TABLE>
	
	<TABLE ALIGN=center WIDTH="600px" BORDER=0 CELLSPACING=1 CELLPADDING=0 >

	<!-- <tr height=30px><td>&nbsp;</td></tr> -->

		<!-- First display the standard selection criteria -->
			
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Terminal: </td>
				<td align=left ><B> &nbsp;<%= l_terminalName %> </b>
				</td>
				<td rowspan=18>
					<INPUT class=touchnoborder id=ok name=ok type=button value="" onClick="submitForm();" 
						style="background-image:url(../images/Ok.gif);"><br><br>
					<INPUT class=touchnoborder id=close name=close type=button value="" onClick="closeForm();" 
						style="background-image:url(../images/Cancel.gif);">
				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Employee: </td>
				<td align=left > <b>&nbsp;<%= l_employeeName %></b>
				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Start Date: </td>
				<td align=left > <b> &nbsp;<%= l_startDate %> </b>
				</td>

			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">End Date: </td>
				<td  align=left width = 50%> <b> &nbsp;<%= l_endDate %></b>
				</td>
			</tr>

			<tr height=30px width=100%>
				<td width = 50% class = "label" align=right Style="Font-weight=normal">Starting Amount: </td>
				<td width = 50% >
					<INPUT type=text align=left size=11 Maxlength="9" id=rangeStartAmount name=rangeStartAmount value="<%=Session("objRP").rangeStartAmount%>">
				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$0.01: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf1Cents name=nbrOf1Cents value="<%=Session("objRP").nbrOf1Cents%>">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$0.05: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf5Cents name=nbrOf5Cents value="<%=Session("objRP").nbrOf5Cents%>">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$0.10: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf10Cents name=nbrOf10Cents value="<%=Session("objRP").nbrOf10Cents%>">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$0.25: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf25Cents name=nbrOf25Cents value="<%=Session("objRP").nbrOf25Cents%>">
				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$1: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf1Dollars name=nbrOf1Dollars value="<%=Session("objRP").nbrOf1Dollars%>">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$5: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf5Dollars name=nbrOf5Dollars value="<%=Session("objRP").nbrOf5Dollars%>">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$10: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf10Dollars name=nbrOf10Dollars value="<%=Session("objRP").nbrOf10Dollars%>">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$20: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf20Dollars name=nbrOf20Dollars value="<%=Session("objRP").nbrOf20Dollars%>">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$50: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf50Dollars name=nbrOf50Dollars value="<%=Session("objRP").nbrOf50Dollars%>">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">$100: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=nbrOf100Dollars name=nbrOf100Dollars value="<%=Session("objRP").nbrOf100Dollars%>">
				</td>
			</tr>

			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Check Amount: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=checkAmount name=checkAmount value="<%=Session("objRP").checkAmount%>">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Credit Card Amount: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=ccAmount name=ccAmount value="<%=Session("objRP").ccAmount%>">
				</td>
			</tr>
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Trade Amount: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=tradeAmount name=tradeAmount value="<%=Session("objRP").tradeAmount%>">
				</td>
			</tr>
			<!--MWiemann added coupon payment 3.14.04 -->
			<tr height=30px>
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Coupon Amount: </td>
				<td width = 50%  align=left><INPUT type=text size=9 Maxlength="9" id=couponAmount name=couponAmount value="<%=Session("objRP").couponAmount%>">
				</td>
			</tr>
			<tr height=30px>			
				<td width = 50% class = "label"  align=right Style="Font-weight=normal">Ending cash in drawer: </td>
				<td width = 50%  align=left> <INPUT type=text size=9 Maxlength="9" id=endingAmount name=endingAmount value="<%=Session("objRP").endingAmount%>">
				</td>	
			</tr>

			

	</table>
</form>
</BODY>
</HTML>
