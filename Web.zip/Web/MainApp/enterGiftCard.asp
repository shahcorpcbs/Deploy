<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim paymentType
	dim amountpaid
	dim targetPage
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex, deptStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim prepayAmt, isPrePay
	dim forceSigAllTimes, forceSigNoClaims, claimsCount
	dim invPrePayPercent, invoicesTotal
	dim originatingPage
	dim customerSeq
	dim giftCardNumber, giftValue, giftExpDate, giftCustomer, cardID
	dim actionString
	dim cardValid, cardOwner
	
	cardValid = 0
	cardOwner = 0
	
	actionString = Request.QueryString("userAction")	

	select case actionString
		case "getcard"
			giftCardNumber = request.querystring("giftcardnumber")
			getCard Session("customerSequenceNumber"), giftCardNumber
			
	end select
	
	function getCard(customerSeq, giftCardNumber)
		dim query, rs
		
		query = " select isnull(giftcard.customersequencenumber, 1) as cardowner, "
		query = query & " giftcard.giftcardid, giftcard.giftvalue, giftcard.expirationdate, isnull(customer.customername, 'ALL') as customername "
		query = query & " from giftcard left outer join customer on "
		query = query & " giftcard.customersequencenumber = customer.customersequencenumber "
		query = query & " where giftcardnumber = '" & replace(giftCardNumber, "'", "''") & "'"
		

		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			giftValue = rs("giftvalue")
			giftExpDate = rs("expirationdate")
			giftCustomer = rs("customername")
			cardID = rs("giftCardID")
			
			cardValid = IIf((datediff("d", giftExpDate, date()) <= 0), 1, 0)
			cardOwner = IIf((trim(rs("cardowner")) = "1") or (trim(rs("cardowner")) = trim(customerSeq)), 1, 0)

		end if
	
	end function
	
	function getGiftCards(customerseq)
		dim query
		query = "select * from giftCard where customersequencenumber = " & customerseq
		set getGiftCards = getDisconnectedRecordset(query)
	end function

	paymentType = Request.QueryString("type")
	amountpaid = Request.QueryString("amountPaid")
	
	
	if paymentType = "" then paymentType = Request.Form("paymentType")
	if amountpaid = "" then amountpaid = Request.Form("amount")
	
	isPrePay =  Request.Form("isPrePay")
	prepayAmt = Request.Form("prepayAmt")
	forceSigAllTimes = Request.Form("forceSigAllTimes")
	forceSigNoClaims = Request.Form("forceSigNoClaims")
	claimsCount = Request.Form("claimsCount")
	invPrePayPercent = Request.Form("invPrepayPercent")
	invoicesTotal = Request.Form("invoicesTotal")
	customerSeq = Session("customerSequenceNumber")
	
	if isPrePay ="1" then
		collectInvoiceDataFromForm
	end if
	
	sub collectInvoiceDataFromForm()
		targetPage = Request.Form("tPage")
		addOrEdit = Request.Form("addOrEdit")
		curr_LineNo = Request.Form("lineNumber")
		selectedDept = Request.Form("selectedDept")
		itemsStartIndex = Request.Form("ItemPageCount")
		upChargeStartIndex = Request.Form("upChargePageCount")
		colorsStartIndex = Request.Form("colorsPageCount")
		patternStartIndex = Request.Form("PatternPageCount")
		deptStartIndex = Request.Form("DeptPageCount")
		selItemId = Request.Form("selItemId")
		selUpchargeValue = Request.Form("selUpcharge")
		selColorValue = Request.Form("selColor")
		selPatternValue = Request.Form("selPattern")
		originatingPage = Request.Form("originPage")
	end sub
	
%>

<HTML>
<HEAD>
<TITLE>GiftCard Number</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript">
	function submitForm() {
		if (validateForm()) {
			document.giftCardNumber.action = "pickup.asp?userAction=giftCardNumber&submit=ok";
			document.giftCardNumber.submit();
		}
	}
	function cancelForm() {
			document.giftCardNumber.action = "pickup.asp";
			document.giftCardNumber.submit();
	}
	
	
	function validateForm() {

		if (document.giftCardNumber.validCard.value == 0) {
			cbs_alert("No valid GiftCard selected.");
			return false;
		}
		
		if (document.giftCardNumber.cardOwner.value == 0) {
            cbs_confirm("GiftCard does not belong to this customer.  Continue?", gotoContinue);
            return false;
		}
		
		return true;
	}

	function gotoContinue() {
        clearConfirmMsg();
        document.giftCardNumber.action = "pickup.asp?userAction=giftCardNumber&submit=ok";
        document.giftCardNumber.submit();
	}
	

	function updateOnEnter(o){ 	
		if (event.keyCode == 13)
			getGiftCard(o.value);
	}
	
	function getGiftCard(giftCardNumber) {
			document.giftCardNumber.action = "?userAction=getcard&giftCardNumber=" + encodeURIComponent(giftCardNumber);
			document.giftCardNumber.submit();
	}
	
	function setFocusOnControl(){				
		document.giftCardNumber.giftCardNumber.select();
	}	

</script>


<BODY topmargin=0 leftmargin=0 onload="setFocusOnControl()" >


<!-- #include file="../include/banner.inc" -->
<H1>Please choose <%=paymentType%> Number</H1>

<FORM id="giftCardNumber" name="giftCardNumber" action="" method="post">

	<INPUT type="hidden" name="paymentType" value="<%= paymentType%>">
	<INPUT type="hidden" name="amount" value="<%= amountpaid%>">
	<INPUT type="hidden" name="isPrePay" value="<%= isPrePay%>">
	<INPUT type="hidden" name="prepayAmt" value="<%= prepayAmt%>">
	<INPUT type="hidden" name="forceSigAllTimes" value="<%= forceSigAllTimes%>">
	<INPUT type="hidden" name="forceSigNoClaims" value="<%= forceSigNoClaims%>">
	<INPUT type="hidden" name="claimsCount" value="<%= claimsCount%>">
	<INPUT type="hidden" name="invPrepayPercent" value="<%= invPrePayPercent %>">
	<INPUT type="hidden" name="invoicesTotal" value="<%= invoicesTotal %>">
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	
	<INPUT type="hidden" name="validCard" value="<%=cardValid%>">
	<INPUT type="hidden" name="cardOwner" value="<%=cardOwner%>">
	<INPUT type="hidden" name="giftCardList" value="<%=cardID%>">
	
	<TABLE ALIGN=center BORDER=0 CELLSPACING=3 CELLPADDING=0 >
		<tr height=50px><td ></td></tr>
		<TR>
			<TD class="label"  align="right" width="40%"><%=paymentType%> Number</TD>
			<TD align=left width="60%">
				<INPUT type="password" name="giftCardNumber" value="<%=giftCardNumber%>" onkeyup="updateOnEnter(this)" />
				<SELECT name="customerGiftCards" onchange="getGiftCard(this.value)">
					<OPTION value=""></OPTION>
				<%
					dim giftCards
					set giftCards = getGiftCards(customerSeq)
					while not (giftCards.eof or giftCards.bof)
				%>
					<OPTION value="<%=giftCards("giftcardnumber")%>" <%if giftCardNumber = giftCards("giftcardnumber") then%>selected<%end if%>><%=giftCards("giftcardnumber")%></OPTION>
				<%
						giftCards.movenext
					wend
					set giftCards = nothing
				%>
				</SELECT>
			</TD>
		</tr>
		<tr height=20px><td></td></tr>
		<tr height=30px>
			<td class=label align=right>Customer</td>
			<td>
				<input readonly id=value name=value value="<%=giftCustomer%>">
			</td>		
		</tr>	
		<tr height=30px>
			<td class=label align=right>Balance</td>
			<td>
				<input readonly id=value name=value value="<%=formatcurrency(giftValue)%>">
			</td>		
		</tr>	
		<tr height=40px>
			<td class=label align=right>Exp Date</td>
			<td>
				<input readonly id=expDate name=expDate value="<%=giftExpDate%>">
			</td>		
		</tr>	
		<tr height=50px><td></td></tr>
		<tr>	
			<td align="center" colspan=2>
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick= "submitForm()" >
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelForm(-1);" >
			</td>
		</TR>
	</TABLE>	
	
</form>

</BODY>
</HTML>
