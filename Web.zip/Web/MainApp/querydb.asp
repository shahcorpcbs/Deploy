<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 360 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim queryName
	dim queryTransformed
	dim query, rs
	dim userQueryID
	
	userQueryID = getReqVar("userQueryID")
	queryTransformed = getReqVar("query")
	queryName = getReqVar("queryName")
	

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function writeUserQuery(query)
		on error resume next
		dim counter
		dim recordCount
		
		if query <> "" then

			set rs = getdisconnectedrecordset(query)
			
			if err.number <> 0 then
				response.write "<div class=""error"">Error executing query<br>" & query & "</div>"
				exit function
			end if
			
			if rs.state > 0 then
				recordCount = rs.recordcount
				
				if recordCount > 0 then
					response.write "<DIV id=""queryresults"" name=""queryresults"" style=""width:100%;height:625px"">"
					response.write "<TABLE class=""itable"" cellspacing=""0"">"
		
					dim i
					
					
					response.write "<TR>"
					
					for i = 0 to rs.Fields.Count - 1
						if left(rs.Fields(i).Name, 1) <> "_" then
							response.write "<TH style=""text-align:left"">@@@" & Server.HTMLEncode(rs.Fields(i).Name) & "</TH>"
						end if
					next
					
					response.write "</TR>"

					rs.MoveFirst
					
					counter = 1
					while not (rs.eof or rs.bof)
					  response.write "<TR>"
					
					  for i = 0 to rs.Fields.Count - 1
						if left(rs.Fields(i).Name, 1) <> "_" then
						  	if isnull(rs.Fields(i).Value) then
						  		response.write "<TD>&nbsp;</TD>"
						  	else
						   		response.write "<TD>" & Server.HTMLEncode(rs.Fields(i).Value) & "</TD>"
						    end if
						end if
					  next
					
					  response.write "</TR>"
					  
						if counter mod 50 = 0 then response.flush
						counter = counter + 1
						
					  rs.MoveNext
					wend
					response.write "</TABLE>"
					response.write "</DIV>"
				else
					response.write "<div class=""warning"">No records</div>"
				end if
			end if
		else
			response.write "<div class=""error"">No query selected</div>"
		end if

		exit function

	end function
	
%>

<HTML>
<HEAD>
<TITLE>Query Database</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT language="javascript" >


	function editParams(userQueryID) {
		document.querydb.action = "queryParams.asp?useraction=restore&userQueryID=" + userQueryID;
	    document.querydb.submit();
	}
	
	function downloadQueryCVS() {
	  document.querydb.action = "queryDBCVS.asp?query=<%=Server.URLEncode(queryTransformed)%>";
	  document.querydb.submit();
	}

	function exitQuery() {
		document.querydb.action = "querylist.asp";
	    document.querydb.submit();
	}
	

	function mergeWithReprint() {
	  document.querydb.action = "queryMergeReprint.asp?userQueryID=" + <%=Server.URLEncode(userQueryID)%> + "&query=<%=Server.URLEncode(queryTransformed)%>";
	  document.querydb.submit();
	}
	

	
	function emailResult() {
		cbs_select("Email:", 2, "Table to Email Address|Customers in Report", "handleEmailChoice");
	}

	function handleEmailChoice(type) {
        clearOptionMsg();
		if(type == 0) {
			document.querydb.action = "runEmailReport.asp?from=query&userQueryID=" + <%=Server.URLEncode(userQueryID)%> + "&query=<%=Server.URLEncode(queryTransformed)%>";
			document.querydb.submit();
		}
		else if(type == 1) {
			document.querydb.action = "runCustEmailReport.asp?from=query&userQueryID=" + <%=Server.URLEncode(userQueryID)%> + "&query=<%=Server.URLEncode(queryTransformed)%>";
			document.querydb.submit();
		}
	}

	function handlePrintChoice(type) {
        clearOptionMsg();
		if(type == 0) {
			var print_window = window.open('','','width=300,height=300');
			print_window.document.open("text/html");
			print_window.document.write('<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">');
			print_window.document.write('<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">');
			print_window.document.write(document.getElementById('queryresults').innerHTML);
			print_window.document.close();
			print_window.print();
			print_window.close();
		}
		else if(type == 1) {
		  document.querydb.action = "queryMergeEmail.asp?userQueryID=" + <%=Server.URLEncode(userQueryID)%> + "&query=<%=Server.URLEncode(queryTransformed)%>";
		  document.querydb.submit();
		}

	}
	
	function printResults() {
		cbs_select("Print results as:", 2, "Table|Form Merge", "handlePrintChoice");
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->

<FORM name="querydb" ID="querydb" METHOD=POST  style="margin:0;padding:0" onsubmit="return false">
<INPUT type="hidden" name="queryName" value="<%=Server.URLEncode(queryName)%>" />
<INPUT type="hidden" name="query" value="<%=Server.URLEncode(queryTransformed)%>" />
<INPUT type="hidden" name="userQueryID" value="<%=userQueryID%>" />

<H1>Results</H1><BR />
<BR />




<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="printResults()" value="" >Print</BUTTON>
		<BUTTON onclick="emailResult()" value="" >Email</BUTTON>
		<BUTTON style="vertical-align: top" onclick="downloadQueryCVS()" value="" >Download<BR />CSV</BUTTON>
		<BUTTON style="vertical-align: top" onclick="mergeWithReprint()" value="" >Reprint<BR />Merge</BUTTON>
		
	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="editParams(userQueryID.value)" value="" >Back</BUTTON>
		<BUTTON onclick="exitQuery()" value="" >Exit</BUTTON>
	</SPAN>
</DIV>	



<% writeUserQuery queryTransformed %>

</FORM>
</BODY>
</HTML>

