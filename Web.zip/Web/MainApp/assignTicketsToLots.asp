<%@ Language=VBScript %>
<%option explicit%>
<!-- #include file="../include/QueryDatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->

<%
	
	const ERR_TICKET_ON_LOT = -1
	const ERR_NO_ROOM_ON_LOT = -2
	const ERR_MIN_NOT_MET = -3
	
	dim query, rs
	dim ticketNumbers
	dim ticketNumber
	dim origin
	dim employeeID
	dim failedTickets
	dim errorMessage
	dim errorType
	dim returnCode


    employeeID = Request.Form("employeeID")
    if employeeID = "" then
	    employeeID = session("employeeid")
    end if
	
	origin = request.querystring("origin")
	ticketNumbers = split(request.querystring("ticketNumbers"), ",")

	if origin = "" or origin = "detailedinvoice" then
	
	
	elseif origin = "detailedinvoice-done" then
		for each ticketNumber in ticketNumbers
			dim lotDefaultID
			lotDefaultID = request.form("tl" & ticketNumber)
			if lotDefaultID = "" or lotDefaultID > 0 then
				returnCode = assignTicketToLot(ticketNumber, origin, lotDefaultID)
				if returnCode < 0 then
					errorType = returnCode
					if failedTickets <> "" then failedTickets = failedTickets & ", "
					failedTickets = failedTickets & ticketNumber
				end if
			end if
		next
		
		
		Response.Redirect "addLotTags.asp?ticketNumbers=" & request.querystring("ticketNumbers")
	else
		for each ticketNumber in ticketNumbers
			returnCode = assignTicketToLot(ticketNumber, origin, "")
			if returnCode < 0 then
				errorType = returnCode
				if failedTickets <> "" then failedTickets = failedTickets & ", "
				failedTickets = failedTickets & ticketNumber
			end if
		next
		
		
		select case origin
		case "lotticket"
			select case errorType
			case ERR_TICKET_ON_LOT
				Response.Redirect "lotTicket.asp?alert=Invoice is already on a lot"
			case ERR_NO_ROOM_ON_LOT
				Response.Redirect "lotTicket.asp?alert=Current open lot does not have room for invoice " & getInvoiceFromTicket(failedTickets)
			case else
				Response.Redirect "lotTicket.asp?userAction=print&ticketNumbers=" & request.querystring("ticketNumbers") 
			end select
		case else
			Response.Redirect "addLotTags.asp?ticketNumbers=" & request.querystring("ticketNumbers")
		end select
			
	end if

	
	function getInvoiceFromTicket(ticketNumber)
		dim query, rs
		
		query = " select invoicenumber from ticket where ticketnumber in (" & ticketNumber & ")"
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
			if getInvoiceFromTicket <> "" then getInvoiceFromTicket = getInvoiceFromTicket & ", "
			getInvoiceFromTicket = getInvoiceFromTicket & rs("invoicenumber")
			rs.movenext
		wend
		
		set rs = nothing
	end function
	
	function assignTicketToLot(ticketNumber, origin, setLotDefaultID)
		dim pieceCount
		dim lotDefaultID
		dim lotID
		dim returnCode
		dim attemptNumber
		
		pieceCount = getTicketPieceCount(ticketNumber)
		
		if setLotDefaultID = "" then
			lotDefaultID = getTicketLotDefaultID(ticketNumber)
		else
			lotDefaultID = setLotDefaultID
		end if
		
		attemptNumber = 1
		
		if lotDefaultID >= 0 then
			for attemptNumber = 1 to 2
				lotID = clng(getOpenLot(lotDefaultID, pieceCount))
			
				if lotID < 0 then
					lotID = clng(createNewLot(lotDefaultID, "", "", "", ""))
				end if
	
				if lotID >= 0 then
					returnCode = updateDatabase(ticketNumber, lotID, employeeID)

					if returnCode = ERR_NO_ROOM_ON_LOT then
						closeLot lotID, (origin = "detailedinvoice" or origin = "")
					elseif returnCode = ERR_TICKET_ON_LOT then
						assignTicketToLot = ERR_TICKET_ON_LOT
						exit function
					elseif returnCode >= 0 then
						assignTicketToLot = 1
						exit function
					end if
				end if
			next
		end if
		
		assignTicketToLot = ERR_NO_ROOM_ON_LOT
	end function

	function closeLot(lotID, forced)
		dim query, rs, useLotsForAssy, conveyorType
		if forced then
			query = "update lot set status = 'C', dateclosed = getdate() where id = " & lotid
		else
			query = "update lot set status = 'C', dateclosed = getdate() where currentgarments >= mingarments and id = " & lotid
		end if

		qryexecute query

		query = "select useLotsForAssembly, conveyorType from miscsetup"
		set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
			useLotsForAssy = rs("useLotsForAssembly")
			conveyorType = rs("conveyorType")
		end if
		
		set rs=nothing
		if useLotsForAssy then
			if conveyorType = "MP" then
				query = "exec sendLotToMP " & lotid
				qryexecute query
			elseif conveyorType = "IT" then
				query = "exec sendLotToItacs " & lotid
				qryexecute query
			end if
		end if
	end function
	
	function updateDatabase(ticketNumber, lotID, employeeID)
	    dim query, rs
    
	    query = "dbo.AssignTicketToLot " &  ticketNumber & ", " & lotID & ", " & employeeID
	    set rs = getdisconnectedrecordset(query)
    
	    updateDatabase = rs("returnCode")
    
	    set rs = nothing
	end function
	
	function createNewLot(lotDefaultID, lotNumber, currentGarments, minGarments, maxGarments)
		dim query, rs
		dim lotID

		openConnection

		query = "insert into Lot (Number, StoreID, Name, CurrentGarments, MinGarments, MaxGarments, DateOpened, Status, lotDefaultID) "
		query = query & " select "

		if lotNumber <> "" then
			query = query & lotNumber
		else
			query = query & " isnull((select lot.number + 1 from lot where id = (select max(id) from lot where dbo.isint(number) = 1 and lotDefaultID = lotdefault.lotdefaultid) and cast(number as int) < lotdefault.lastlotnumber), lotdefault.firstlotnumber) "
		end if

		query = query & ", " & session("storeid")
		query = query & ", lotdefault.name "

		if currentGarments <> "" then
			query = query & ", " & currentGarments
		else
			query = query & ", 0 "
		end if

		if minGarments <> "" then
			query = query & ", " & minGarments
		else
			query = query & ", lotdefault.minpieces "
		end if

		if maxGarments <> "" then
			query = query & ", " & maxGarments
		else
			query = query & ", lotdefault.pieces "
		end if

		query = query & ", getdate() "
		query = query & ", 'O' "
		query = query & ", lotdefault.lotdefaultid "
		query = query & " from lotdefault "
		query = query & " where lotdefaultid = " & lotDefaultID

		dbInsert query
		set rs = dbSelect("select @@IDENTITY as NewID")
		lotID = rs("NewID")
		set rs = nothing
		closeConnection
	

		query = "select id from lot where number = (select number from lot where id = " & lotID & ") and lotdefaultId = " _
		    & "(select lotdefaultId from Lot where id = " & lotID & ") and Status = 'O' and id < " & lotID
		set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
		    'Bad timing  - two lots got created for the same dept at the same time
			query = "update lot set number = number + 1 where id = " & lotID
			qryexecute query
		end if


		query = " update lot set color = '" & getLotColor(lotDefaultID, getLotNumber(lotID)) & "' where id = " & lotid
		qryexecute query
	
		createNewLot = lotID
	end function



	function getLotNumber(LotID)
		dim query, rs

		query = " select number from lot where id = " & lotid

		set rs = getdisconnectedrecordset(query)

		getLotNumber = 0

		if rs.recordcount > 0 then
			getLotNumber = rs("number")
		end if

		set rs = nothing
	end function




	function getLotColor(lotDefaultID, lotNumber)
		dim query, rs
		dim firstLotNumber
		dim position
		dim colorCount
		dim colorSource

		getLotColor = "undefined"

		query = " select firstlotnumber from lotdefault where lotdefaultid = " & lotDefaultID
		set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
			firstLotNumber = rs("firstlotnumber")
		else
			firstlotnumber = 0
		end if

		colorCount = 0
		query = " select count(*) as cnt from lotcolor where lotdefaultid = " & lotDefaultID
		set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
			colorSource = 1
			colorCount = rs("cnt")
		end if

		if colorCount = 0 then
			query = " select count(*) as cnt from lotcolor where lotdefaultid is null "
			set rs = getdisconnectedrecordset(query)
			if rs.recordcount > 0 then
				colorSource = 2
				colorCount = rs("cnt")
			end if
		end if

		set rs = nothing

		if colorCount = 0 then
			exit function
		end if

		position = (lotNumber - firstlotnumber) mod colorCount

		if colorSource = 1 then
			query = " select * from lotcolor where lotdefaultid = " & lotDefaultID & " and sequenceorder = " & position
		else
			query = " select * from lotcolor where lotdefaultid is null and sequenceorder = " & position
		end if

		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getLotColor = rs("name")
		else
			getLotColor = "no seq"
		end if

		set rs = nothing

	end function

  
	function getOpenLot(lotDefaultID, pieces)
		dim query, rs
		
		query = query & " select lot.id "
		query = query & " from lot  "
		query = query & " where lot.status = 'O' "
		query = query & " and lotDefaultID = " & lotDefaultID
		query = query & " order by currentGarments "
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getOpenLot = rs("id")
		else
			getOpenLot = -1
		end if
		
		set rs = nothing
	end function
	
	
	function getTicketPieceCount(ticketNumber)
		dim query, rs
		
		query = "select sum(quantity*packagedQuantity) as pieces from ticketlineitem "
		query = query & "where ticketlinetype in ('IT','AC') and ticketnumber = " & ticketNumber

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getTicketPieceCount = rs("pieces")
		else
			getTicketPieceCount = 0
		end if
		
		set rs = nothing
	end function

	function getTicketLotDefaultID(ticketNumber)
		dim query, rs

  	query = " select lotdefaultdepartment.lotdefaultid "
  	query = query & " from ticketlineitem inner join lotdefaultdepartment on ticketlineitem.departmentid = lotdefaultdepartment.deptid "
		query = query & " where ticketlineitem.ticketnumber = " & ticketNumber
		query = query & " group by lotdefaultdepartment.lotdefaultid "
		query = query & " order by sum(ticketlineitem.quantity) desc "
		
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getTicketLotDefaultID = rs("lotdefaultid")
		else
			getTicketLotDefaultID = -1
		end if
		
		set rs = nothing
	end function

	
	function div_ticketSummaryHeader(ticketNumber)
		dim query, rs
		dim result
		
		
		query = " select invoiceNumber, dueDate, dbo.pivotTicketDepartments(ticketnumber, ', ') as depts from ticket where ticketNumber = " & ticketNumber
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
		
			result = "<div class=""inv-num"">Invoice Number: <b>" & server.htmlencode(rs("invoicenumber")) & "</b></div>"
			result = result & "<div class=""due-date"">Due Date: " & server.htmlencode(rs("duedate")) & "</div>"
			result = result & "<div class=""depts"">Departments: " & server.htmlencode(rs("depts")) & "</div>"
		end if
		
		div_ticketSummaryHeader = result
	end function
	
	function div_ticketSummaryLineItems(ticketNumber)
		dim query, rs
		dim result
		
		
		query = " select * from ticketlineitem where ticketnumber = " & ticketNumber
		query = query & " and ticketlinetype in ('IT', 'AC') "
		
		set rs = getdisconnectedrecordset(query)
		
		result = result & "<div class=""line-items"">"
		result = result & "<ul>"
		
		while not(rs.eof or rs.bof)
		
			result = result & "<li>" & server.htmlencode(rs("lineitemname")) & "</li>"
			
			rs.movenext
		wend
		
		result = result & "</ul>"
		result = result & "</div>"
		
		div_ticketSummaryLineItems = result
	end function
	
	
	function div_ticketSummary(ticketNumber)
		dim result

		result = "<div class=""ticket-summary"">"
		
		result = result & div_ticketSummaryHeader(ticketNumber)
		result = result & div_ticketSummaryLineItems(ticketNumber)
		
		
		
	
		result = result & "</div>"
		div_ticketSummary = result
	end function
%>


<HTML>
<HEAD>
<TITLE>Lot Assignment</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../external/jquery.js"></script>
<STYLE type="text/css">
.ticket-assignment {
	margin: 15px;
	border-bottom: 3px groove;	
	padding: 10px;
}

.ticket-summary {
	margin: 15px;
	font-weight: bold;
}
.ticket-summary b {
	font-size: 16;
}


.line-items {
	font-weight: normal;
	
}


</STYLE>


<SCRIPT type="text/javascript" >

	
	$(document).ready(function() {
		submit_form();
	});

	function selectTicketLot(ticketNumber, o) {
		$('.tl' + ticketNumber + 'pref').each(function(i) {
			this.style.background = '#fff';
		});

		$('#tl' + ticketNumber).val(o.getAttribute("lotDefaultID"));
		o.style.background = '#f00';
		submit_form();
	}
	
	function submit_form() {
		if($(".tl-item[value='']").length == 0) {
			document.assignTicketsToLots.action = "?origin=detailedinvoice-done&ticketnumbers=<%=request.querystring("ticketNumbers")%>";
			document.assignTicketsToLots.submit();
		}
	}

</SCRIPT>
</HEAD>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<FORM id="assignTicketsToLots" name="assignTicketsToLots" action="multiplePickup.asp" method="post" >
<INPUT type="hidden" name="employeeID" value="<%=employeeID%>" />
<H1>Lot Assignment</H1>
<%

	for each ticketNumber in ticketNumbers
	
%>
	
	
<%
  	query = " select distinct lotdefaultdepartment.lotdefaultid, lotdefault.name "
  	query = query & " from ticketlineitem inner join lotdefaultdepartment on ticketlineitem.departmentid = lotdefaultdepartment.deptid "
  	query = query & " inner join lotdefault on lotdefaultdepartment.lotdefaultid = lotdefault.lotdefaultid "
		query = query & " where ticketlineitem.ticketnumber = " & ticketNumber

		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
%>
	<div class="ticket-assignment">
	<%=div_ticketSummary(ticketNumber)%>
	<INPUT type="hidden" class="tl-item" id="<%="tl" & ticketNumber%>" name="<%="tl" & ticketNumber%>" value="">

	<INPUT type="button" style="width:100px;height:40px; background: #fff; margin-right: 50px;"
		onclick="selectTicketLot(<%=ticketNumber%>, this)"
		lotDefaultID="-1"
		value="NONE"
		class="tl<%=ticketNumber%>pref">
		
		

<%
		while not(rs.eof or rs.bof)
%>

	<INPUT type="button" style="width:100px;height:40px; background: #fff"
		onclick="selectTicketLot(<%=ticketNumber%>, this)"
		lotDefaultID="<%=rs("lotdefaultid")%>"
		value="<%=rs("name")%>"
		class="tl<%=ticketNumber%>pref">
		
	
<%
			rs.movenext
		wend

		end if
%>

	</div>

<%
	next
%>

</FORM>
</BODY>
</HTML>

