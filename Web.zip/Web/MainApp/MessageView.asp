<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<%
	dim accountname
	dim messageid
	
	acccountname = getReqVar("accountname")
	messageid = getReqVar("messageid")
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getMessageAccountID(username)
		dim query, rs

		query = "select id from messageaccount where lower(username) = '" & lcase(username) & "'"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getMessageAccountID = rs("id")
		else
			getMessageAccountID = ""
		end if

		set rs = nothing
	end function
	
	function getTaskStatus(taskid)
		dim query, rs
		
		query = "select dateclosed from task where id = " & taskid
		set rs = getdisconnectedrecordset(query)
		
		if isnull(rs("dateclosed")) then
			getTaskStatus = "Open"
		else
			getTaskStatus = "Closed"
		end if
		
		set rs = nothing
	end function
	
	function jsGotoTask(taskid)
		dim query, rs
		
		query = "select * from customertask where taskid = " & taskid
		set rs = getdisconnectedrecordset(query)
		
		jsGotoTask = "javascript:"
		if rs.recordcount > 0 then
			jsGotoTask = jsGotoTask & "gotoTask('" & rs("storeguid") & "', " & rs("customersequencenumber") & ", " & taskid & ")"
		end if
		jsGotoTask = jsGotoTask & ";"
	end function
	
	
    Function linkTasks(messagetext)
        Dim place
        Dim ns
        Dim nl
        Dim replaceWith
        Dim dd


        If InStr(messagetext, "Task:") Then
            Do While InStr(messagetext, "Task:")
                place = InStr(messagetext, "Task:")
                ns = place + Len("Task:")
                nl = 0
                
                While IsNumeric(Mid(messagetext, ns, nl + 1)) And (ns + nl) <= Len(messagetext)
                    nl = nl + 1
                Wend

                dd = clng(Mid(messagetext, ns, nl))
                
                replaceWith = "<a href=""" & jsGotoTask(dd) & """>Task " & dd & " (" & getTaskStatus(dd) & ")</a>"
                
                messagetext = Mid(messagetext, 1, place - 1) & replaceWith & Mid(messagetext, place + Len("Task:") + nl, Len(messagetext))
                
                linkTasks = messagetext

            Loop
        Else
            linkTasks = messagetext
        End If

    End Function
    
	function getMessageServerURL()
		dim query, rs
		
		query = "select isnull(messageServerURL, '') as messageServerURL from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getMessageServerURL = trim(rs("messageServerURL"))
		
		set rs = nothing
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<SCRIPT language="javascript" type="text/javascript">
	function viewTask(taskid) {
		var w = window.open("<%=getMessageServerURL()%>/MainApp/viewtask.asp?taskid=" + taskid, "ViewTask", "status=no,scrollbars=no,width=530,height=500,modal=no");
	}
	
	function gotoTask(storeguid, customerseq, taskid) {
		window.opener.viewTask(storeguid, customerseq, taskid);
		window.close();
	}
	
	function replyMessage() {
		document.messageview.action = "messagecompose.asp?useraction=reply&messageid=<%=messageid%>";
		document.messageview.submit();
	}
</SCRIPT>


</HEAD>

<BODY STYLE="margin:0;padding:0;background:#F8F8F8">

<FORM id="messageview" name="messageview" method="post" style="margin:0;padding:0;">

<INPUT type="hidden" name="accountname" value="<%=accountname%>">
<INPUT type="hidden" name="messageid" value="<%=messageid%>">
<%
	query = "update messageitem set datereceived = getdate() where id = " & messageid
	qryexecute query

	query = "select messageitem.*, fromaccount.username as fromusername, toaccount.username as tousername "
	query = query & " from messageitem inner join messageaccount as fromaccount on messageitem.fromaccount = fromaccount.id "
	query = query & " inner join messageaccount as toaccount on messageitem.toaccount = toaccount.id "
	query = query & " where messageitem.id = " & messageid
	
	set rs = getdisconnectedrecordset(query)
	

	
	
%>



<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="replyMessage()">Reply</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="window.close()">Close</BUTTON>
	</SPAN>
</DIV>



<table style="background:#F8F8F8;margin:20px">
	<tr>
		<td>From:</td><td><input name="fromaccount" style="width:500px;border:1px inset;background:white" readonly value="<%=rs("fromusername")%>"></td>
	<tr>

	<tr>
		<td>To:</td><td><input readonly name="toaccount" style="width:500px;border:1px inset;background:white" value="<%=rs("tousername")%>"></td>
	<tr>

	<tr>
		<td>Subject:</td><td><input readonly name="subjecttext" style="width:500px;border:1px inset;background:white" value="<%=rs("subjecttext")%>"></td>
	</tr>
	
	<tr>
		<td></td><td>

		<div style="width:500px;height:400px;overflow:auto;border:1px inset;padding:2px;background:white;font-family: monospace">
		
		<%=linkTasks(replace(rs("messagetext"), vbcrlf, "<br>"))%>
		


		</div>
		
		</td>
	</tr>
	
</table>


</FORM>
</BODY>
</HTML>
