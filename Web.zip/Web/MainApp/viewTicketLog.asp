<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim ticketNumber
	
	ticketNumber = getReqVar("ticketNumber")
	
	function getTicketLog(ticketNumber)
		dim query
		
		query = " select ticketlog.*, dbo.getTicketLogTypeDescription(ticketlog.logtype) as ticketlogtype, isnull(logComment, '') as note, "
		query = query & " isnull(coupons, 0) as coupons, "
		query = query & " isnull(discounts, 0) as discounts, "
		query = query & " isnull(overriddenamount, 0) as overrides, "
		query = query & " isnull(onaccountamount, 0) as onaccount, "
		query = query & " isnull(taxadditions, 0) as taxes, "
		query = query & " isnull(surchargeadditions, 0) as surcharges, "
		query = query & " ticketlogitem.ticketlogitemid, "
		query = query & " isnull(paymentgroup.paymentgroupdescription, '') as paymentdescription, "
		query = query & " paymentgroup.paymentGroupNumber "
		query = query & " from ticketlog left outer join ticketlogitem on "
		query = query & " ticketlog.ticketnumber = ticketlogitem.ticketnumber and ticketlog.logdate = ticketlogitem.logdate "
		query = query & " left outer join paymentgroup on "
		query = query & " ticketlog.paymentgroupnumber = paymentgroup.paymentgroupnumber "
		query = query & " where ticketlog.ticketNumber = " & ticketNumber

		set getTicketLog = getdisconnectedrecordset(query)
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getTicketLogEditDetails(ticketLog)
		dim query, rs
		if not isnull(ticketLog("ticketlogitemid")) then
			query = "select * from ticketlogitem where ticketlogitemid = " & ticketLog("ticketlogitemid")

			set rs = getdisconnectedrecordset(query)
			
			while not (rs.eof or rs.bof)
				select case rs("logType")
				case "A"
					getTicketLogEditDetails = getTicketLogEditDetails & "(Add " & rs("quantity") & " " & rs("itemName") & " " & formatcurrency(rs("amount"),,,0) & ")"
				case "D"
					getTicketLogEditDetails = getTicketLogEditDetails & "(Remove " & rs("quantity") & " " & rs("itemName") & " " & formatcurrency(rs("amount"),,,0) & ")"
				case "C"
					getTicketLogEditDetails = getTicketLogEditDetails & "(Change " & rs("quantity") & " " & rs("itemName") & " " & formatcurrency(rs("amount"),,,0) & ")"
				case "O"
					getTicketLogEditDetails = getTicketLogEditDetails & "(Override " & rs("quantity") & " " & rs("itemName") & " " & formatcurrency(rs("amount"),,,0) & ")"

				end select
				rs.movenext
			wend
			set rs = nothing
		end if
	end function
	
	function getPaymentDetails(paymentGroupNumber)
		dim query, rs
		dim result
		
		query = "select * from payment where paymentgroupnumber = " & paymentGroupNumber
		query = query & " and customersequencenumber = " & session("customersequencenumber")
		
		set rs = getdisconnectedrecordset(query)
		
		result = ""
		
		while not(rs.eof or rs.bof)
			if result <> "" then result = result & ", "
			result = result & "(" & formatcurrency(rs("amountpaid"),,,0) & " " & rs("paymenttypename") & ")"
			rs.movenext
		wend
		
		set rs = nothing
		
		getPaymentDetails = result
	end function
	
	
	function getTicketLogType(ticketLog)
		select case ticketLog("logType")
		case "C"
			getTicketLogType = ticketLog("ticketlogtype")

		case "P"
				getTicketLogType = ticketLog("paymentdescription") & " " & getPaymentDetails(ticketLog("paymentGroupNumber"))
		case else
			getTicketLogType = ticketLog("ticketlogtype") & " " & getTicketLogEditDetails(ticketLog)
		end select
	end function

	function getTicketLogAction(ticketLog) 
		getTicketLogAction = getTicketLogType(ticketLog)
		'if ticketLog("coupons") <> 0 then getTicketLogAction = getTicketLogAction & " (Coupon " & formatcurrency(ticketLog("coupons"),,,0) & ")"
		'if ticketLog("discounts") <> 0 then getTicketLogAction = getTicketLogAction & " (Discount " & formatcurrency(ticketLog("discounts"),,,0) & ")"		
		'if ticketLog("overrides") <> 0 then getTicketLogAction = getTicketLogAction & " (Override " & formatcurrency(ticketLog("overrides"),,,0) & ")"
		'if ticketLog("onaccount") <> 0 then getTicketLogAction = getTicketLogAction & " (On Account " & formatcurrency(ticketLog("onaccount"),,,0) & ")"
		'if ticketLog("taxes") <> 0 then getTicketLogAction = getTicketLogAction & " (Tax " & formatcurrency(ticketLog("taxes"),,,0) & ")"
		'if ticketLog("surcharges") <> 0 then getTicketLogAction = getTicketLogAction & " (Surcharge " & formatcurrency(ticketLog("surcharges"),,,0) & ")"
	end function
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>View Ticket Log</TITLE>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

</HEAD>
<script language="javascript" type="text/javascript">
	function exitForm() {
	    document.viewTicketLog.action = "finishedInvoices.asp?userAction=fromDetail&ticketNumber=<%=ticketNumber%>";
	    document.viewTicketLog.submit();
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0 >

<!-- #include file="../include/banner.inc" -->
<FORM id="viewTicketLog" name="viewTicketLog" action="" method=post>
<B class="pageHeading">Ticket Log</B>
<INPUT type="hidden" name="ticketNumber" value="<%=ticketNumber%>" />

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">

	</SPAN>
	
	<SPAN style="float:right">
		<BUTTON onclick="exitForm()">Exit</BUTTON>
	</SPAN>
</DIV>	


<TABLE class="itable" align=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0>
	<TR>
		<TH>Date</TH>
		<TH>Employee</TH>
		<TH>Action</TH>
		<TH>Price</TH>
		<TH>Payment</TH>
		<TH>Note</TH>
	</TR>
<%
	dim ticketLog
	dim totalPrice
	dim totalPayment
	dim currentPayment
	dim ticketLogDate

	totalPrice = 0
	totalPayment = 0
	
	set ticketLog = getTicketLog(ticketNumber)
	ticketLog.sort = "logdate asc"
	
	while not (ticketLog.eof or ticketLog.bof)
	
		if ticketLogDate <> ticketLog("logDate") then
			if not isnull(ticketLog("additions")) then
				totalPrice = totalPrice + ticketLog("additions")
			end if
			
			
			if not isnull(ticketLog("payments")) then
				currentPayment = ticketLog("payments") - totalPayment
				totalPayment = ticketLog("payments")
			else
				currentPayment = 0
			end if
		
%>
		<TR>
			<TD><%=ticketLog("logDate")%></TD>
			<TD><%=ticketLog("employeeName")%></TD>
			<TD><%=getTicketLogAction(ticketLog)%></TD>
			<TD><%=formatcurrency(totalPrice)%></TD>
			<TD><%if currentPayment <> 0 then%><%=formatcurrency(currentPayment)%><%else%>&nbsp;<%end if%></TD>
			<TD><%=ticketLog("note")%>&nbsp;</TD>
		</TR>
<%
		else
%>
		<TR>
			<TD>&nbsp;</TD>
			<TD>&nbsp;</TD>
			<TD><%=getTicketLogAction(ticketLog)%></TD>
			<TD>&nbsp;</TD>
			<TD>&nbsp;</TD>
			<TD><%=ticketLog("note")%>&nbsp;</TD>
		</TR>
<%
		
		
		end if
		ticketLogDate = ticketLog("logDate")
		ticketLog.movenext
	wend
	
	set ticketLog = nothing
%>
</TABLE>

</FORM>
</BODY>
</HTML>

