<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim dateBegin
	
	dateBegin = date()
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
	var previousElement = null;
	var selectedCardPaymentId = null;
	var selectedPaymentNumber = null;
	var selectedPaymentType = null;

	function voidTransaction() {
		if(selectedPaymentNumber) {
			document.voidListForm.action="/mainapp/cardpaymentvoid.asp?cardPaymentId=" + selectedCardPaymentId +
			    "&paymentType=" + selectedPaymentType +
			    "&paymentNumber=" + selectedPaymentNumber;
            document.voidListForm.submit();
		}
	}

	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}
		
		selectedCardPaymentId = element.getAttribute("cardpaymentid");
		selectedPaymentType = element.getAttribute("paymentType");
		selectedPaymentNumber = element.getAttribute("paymentNumber");

		previousElement =element;
		
		element.className = "selected";
	}
	
	function exit() {
		document.voidListForm.action="/mainapp/managermenu.asp";
        document.voidListForm.submit();
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0">
<!-- #include file="../include/banner.inc" -->
<FORM id="voidListForm" name="voidListForm" method="Post">
<H1>Void  Payment</H1>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="voidTransaction()">Void<br>Transaction</BUTTON>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>


<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH>Terminal</TH>
		<TH>Employee</TH>
		<TH>Customer</TH>
		<TH>Payment Type</TH>
		<TH>Date</TH>
		<TH>Amount</TH>
	</TR>
	<%
	
		dim approvalCode, jsonObj
			
		query = " select isnull(rawanswer, '') as rawanswer, daterequested, isnull(amount, 0) as amount, "
		query = query & " isnull(terminal.name, '') as terminalname, "
		query = query & " isnull(employee.employeename, '') as employeename, "
		query = query & " isnull(customer.customername, '') as customername, "
		query = query & " cardpaymentid, cardpayment.reversed, 'Credit Card' as paymentTypeName, payment.paymentNumber "
		query = query & " from cardpayment "
		query = query & " left outer join terminal on cardpayment.terminalid = terminal.terminalid "
		query = query & " left outer join employee on cardpayment.clerk = employee.employeeid "
		query = query & " left outer join customer on cardpayment.customersequencenumber = customer.customersequencenumber "
		query = query & " left outer join payment on cardpayment.transactionId = payment.transactionNumber "
		query = query & " where datediff(day, cardpayment.daterequested, '" & dateBegin & "') <= 0 "
		query = query & " and success = 1 "


		query = query & " union all ("
		query = query & " select '' as rawanswer, paymentDate as daterequested, isnull(amountPaid, 0) as amount, "
		query = query & " isnull(terminal.name, '') as terminalname, "
		query = query & " isnull(employee.employeename, '') as employeename, "
		query = query & " isnull(customer.customername, '') as customername, "
		query = query & " 0 as cardpaymentid, payment.reversed, payment.paymentTypeName, payment.paymentNumber "
		query = query & " from payment "
		query = query & " left outer join terminal on payment.terminalid = terminal.terminalid "
		query = query & " left outer join employee on payment.createdEmployeeId = employee.employeeid "
		query = query & " left outer join customer on payment.customersequencenumber = customer.customersequencenumber "
		query = query & " where datediff(day, payment.paymentDate, '" & dateBegin & "') <= 0 "
		query = query & " and payment.amountPaid > 0 "
		query = query & " and payment.paymentTypeName in ('Check', 'Cash')) "
	
		query = query & " order by daterequested "
		set rs = getdisconnectedrecordset(query)
		while not(rs.eof or rs.bof)

	%>
	<% if rs("reversed") = 0 then %>
	    <TR onclick="selectRow(this)" cardpaymentid="<%=rs("cardpaymentid")%>"
	        paymentType="<%=rs("paymentTypeName")%>" paymentNumber="<%=rs("paymentNumber")%>" >
		<% else %>
	        <TR style="color: red">
		<% end if %>
		<TD><%=server.htmlencode(rs("terminalname"))%></TD>
		<TD><%=server.htmlencode(rs("employeename"))%></TD>
		<TD><%=server.htmlencode(rs("customername"))%></TD>
		<TD><%=server.htmlencode(rs("paymentTypeName"))%></TD>
		<TD><%=server.htmlencode(rs("daterequested"))%></TD>
		<TD><%=formatcurrency(rs("amount"))%></TD>
	</TR>
	<%
			rs.movenext
		wend
		set rs = nothing
	%>
</TABLE>

</FORM>
</BODY>
</HTML>
