<%@ Language=VBScript %>
<%option explicit%>

<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%sec_RequestAccess Request.QueryString("userAction")%>

<%

	dim fromCustSeq, fromCustID, fromCustName
	dim toCustSeq, toCustID, toCustName
	dim fromPage
	dim isSubmitted

	fromPage = Request.QueryString("fromPage")
	isSubmitted = Request.QueryString("Submitted")
	if (isSubmitted) then
		updateDatabase()
	end if	

	if (fromPage <> "") then
		if (fromPage = "searchTo") then
			getToCustomerSeqNos()
		elseif (fromPage = "searchFrom") then
			getFromCustomerSeqNos()
		end if
	end if

	if (fromPage <> "") then
		getFromCustomerSeqNos()
	end if



%>

<HTML>
<HEAD>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>

<!--






function OnSubmitButtonClick() {
	var retVal;
	var fromcust, tocust, fromid, toid;
	
	fromcust = document.MergeCustomerForm.FromCustName.value;
	fromid = document.MergeCustomerForm.FromCustID.value;
	tocust = document.MergeCustomerForm.ToCustName.value;
	toid = document.MergeCustomerForm.ToCustID.value;

    cbs_confirm("Are you sure you want to merge customer " + fromid +  " into customer " + toid + "?\n THIS ACTION IS NOT REVERSIBLE!", gotoMerge)
}

    function gotoMerge() {
        clearConfirmMsg();
        document.MergeCustomerForm.action = "?Submitted=true";
        document.MergeCustomerForm.submit();
    }


function searchForCustomer(whichDirection) {
	if (whichDirection == "from") {
		document.MergeCustomerForm.action = "Customersearch.asp?userAction=mergeCustFrom"
	}
	else if (whichDirection == "to") {
		document.MergeCustomerForm.action = "Customersearch.asp?userAction=mergeCustTo&fromCustSeqNum=" + document.MergeCustomerForm.FromCustSeq.value;
	}
	document.MergeCustomerForm.submit();
}


function cancelMerge() {
	document.MergeCustomerForm.action = "/mainapp/managerMenu.asp";
	document.MergeCustomerForm.submit();
}


//-->
</SCRIPT>
</HEAD>
<BODY onLoad="" topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->


<FORM name="MergeCustomerForm" ID="MergeCustomerForm" method="post" ACTION="/MainApp/MergeCustomers.asp">
<TABLE WIDTH=500 STYLE="" ALIGN=center BORDER=0 CELLSPACING=1 CELLPADDING=5>
	<INPUT type=hidden name=fromPage value=<%=fromPage%>

	<tr height=100px><td>&nbsp</td>
	</tr>

	<tr height=50px>
		<td width = 40% class = "label"  align=right Style="Font-weight=normal">From Customer: </td>
		<td width = 60% align=left Style="font-size: 14px;height:35px;vertical-align:middle;">
			<INPUT type=hidden id=FromCustSeq name=FromCustSeq value=<%=fromCustSeq%>>
			<INPUT type=hidden id=FromCustID name=FromCustID value=<%=fromCustID%>>
			<INPUT type=hidden id=FromCustName name=FromCustName value=<%=fromCustName%>>
			<%=fromCustName%>
			<% if fromPage = "" then %><INPUT style="height:30px;width:80px" value="Search" id=searchButton name=searchButton type=button   onClick="searchForCustomer('from')">
			<%end if%>
		</td>

	</tr>
	<tr height=50px>
		<td width = 40% class = "label"  align=right Style="Font-weight=normal">To Customer: </td>
		<td width = 60% align=left Style="font-size: 14px;height:35px;vertical-align:middle;">
			<INPUT type=hidden id=ToCustSeq name=ToCustSeq value=<%=toCustSeq%>>
			<INPUT type=hidden id=ToCustID name=ToCustID value=<%=toCustID%>>
			<INPUT type=hidden id=ToCustName name=ToCustName value=<%=toCustName%>>
			<%=toCustName%>
			<% if fromCustSeq <> "" and (fromPage = "" or fromPage = "searchFrom") then %><INPUT style="height:30px;width:80px" value="Search" id=searchButton name=searchButton type=button   onClick="searchForCustomer('to')">
			<% end if %>
		</td>

	</tr>

	<TR>
		<TD COLSPAN="2" ALIGN="center">
			<% if fromCustSeq <> "" and toCustSeq <> "" then %>
			<INPUT Style="height:50px;width:100px" type="button" name="SubmitButton" ID="SubmitButton" Value="Merge" onClick="OnSubmitButtonClick();">
			<% end if %>
			<INPUT Style="height:50px;width:100px" type="button" name="CancelButton" ID="CancelButton" Value="Cancel" onClick="cancelMerge();">
			
		</TD>
	</TR>
</TABLE>
</FORM>


</BODY>
</HTML>

<%
	function getToCustomerSeqNos()
		dim sqltxt, rst
		toCustSeq = Request.QueryString("toCustSeqNum")
		fromCustSeq = Request.QueryString("fromCustSeq")
		sqltxt = "select customername, customerid from customer where customersequencenumber = " & toCustSeq
		set rst = getDisconnectedRecordset(sqltxt)
		if rst.recordcount > 0 then
			toCustID = trim(rst("customerid"))
			toCustName = rst("customername") & " (" & toCustID & ")"
		else
			toCustName = "Invalid Name, please start over"
		end if


	end function

	function getFromCustomerSeqNos()
		dim sqltxt, rst
		fromCustSeq = Request.QueryString("fromCustSeqNum")
		sqltxt = "select customername, customerid from customer where customersequencenumber = " & fromCustSeq
		set rst = getDisconnectedRecordset(sqltxt)
		if rst.recordcount > 0 then
			fromCustID = trim(rst("customerid"))
			fromCustName = rst("customername") & " (" & fromCustID & ")"
		else
			fromCustName = "Invalid Name, please start over"
		end if
	end function

	function UpdateDatabase()
	dim sqltxt
	
		dbstartTrans()
			sqltxt  = "exec dbo.MergeCustomers " & Request.Form("fromCustSeq") & "," & Request.Form("toCustSeq")
			QryExecuteWithTrans(sqltxt)
		dbendTrans()

		Response.Redirect("/mainapp/mergeCustomersDone.asp")
	end function

%>