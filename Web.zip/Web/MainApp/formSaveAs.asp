<%@ Language=VBScript %>
<%
	Response.AddHeader "Content-Type", "type=""text"""
	Response.AddHeader "Content-Disposition:", "attachment;filename=""results.txt"""
	Response.Write(Request.Form(Request.QueryString("form")))
%>
