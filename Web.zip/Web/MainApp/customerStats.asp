<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim customerseq
	
	
	customerseq = getReqVar("customerseq")
	
	
	function calculateQtrSales(customerseq, inquarter, inyear)
		dim query, rs
		
		query = "select isnull(sum(invoicetotal), 0) as invoicetotal from ticket where "
		query = query & " storeid = " & session("storeid")
		query = query & " and ticketstatus = 'FI' "
		query = query & " and customersequencenumber = " & customerseq
		query = query & " and datepart(q, dateout) = " & inquarter
		query = query & " and datepart(yyyy, dateout) = " & inyear
	
		set rs = getdisconnectedrecordset(query)
		
		calculateQtrSales = rs("invoicetotal")
		
		set rs = nothing
	end function

	function getCustomerStats(customerseq)
		dim query
		
		query = " select isnull(totalSales, 0) as totalSales "
		query = query & " , dbo.getCustomerVisits(customersequencenumber, null, null) as visitCount "
		query = query & " , isnull(totalDiscountsAmount, 0) as totalDiscountsAmount "
		query = query & " , isnull(totalCreditsAmount, 0) as totalCreditsAmount "
		query = query & " , isnull(totalNbrOfClaims, 0) as totalNbrOfClaims "
		query = query & " , isnull(totalNbrOfComplaints, 0) as totalNbrOfComplaints "
		
		query = query & " from customer "
		query = query & " where customersequencenumber = " & customerseq
		
		set getCustomerStats = getdisconnectedrecordset(query)
	end function


	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">
	function returnToNotes() {
		document.customerStats.action = "customerNotes.asp?customerseq=<%=l_customerseq%>";
		document.customerStats.submit()
	}
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0;background:white" onload="">
<!-- #include file="../include/banner.inc" -->
<FORM id="customerStats" name="customerStats">
<BR />
<INPUT type=hidden name="customerseq" value="<%=customerseq%>" >


<%
	dim customerstats
	set customerstats = getCustomerStats(customerseq)
%>


<TABLE style="width:100%" border="0" cellspacing="5" cellpadding="0">
	<TR>
		<TD align="right">Total Sales</TD><TD><INPUT style="text-align:right" readonly value="<%=formatcurrency(customerstats("totalSales"))%>"></TD>
		<TD align="right">Visit Count</TD><TD><INPUT style="text-align:right" readonly value="<%=customerstats("visitCount")%>"></TD>
	</TR>
	<TR>
		<TD align="right">Total Discounts</TD><TD><INPUT style="text-align:right" readonly value="<%=formatcurrency(customerstats("totalDiscountsAmount"))%>"></TD>
		<TD align="right">Total Credits</TD><TD><INPUT style="text-align:right" readonly value="<%=formatcurrency(customerstats("totalCreditsAmount"))%>"></TD>
	</TR>
	<TR>
		<TD align="right">Total Claims</TD><TD><INPUT style="text-align:right" readonly value="<%=customerstats("totalNbrOfClaims")%>"></TD>
		<TD align="right">Total Complaints</TD><TD><INPUT style="text-align:right" readonly value="<%=customerstats("totalNbrOfComplaints")%>"></TD>
	</TR>
</TABLE>

<%
	set customerstats = nothing
%>


<%
	dim thisyeartotal
	dim lastyeartotal
	dim currentvalue
	
	thisyeartotal = 0
	lastyeartotal = 0
%>

<TABLE class="itable" border="0" cellspacing="0" cellpadding="0">
	<TR>
		<TH>Quarter</TH>
		<TH>Last Year</TH>
		<TH>This Year</TH>
	</TR>

	<TR>
		<TD>First</TD>
		<TD align="right"><%
			currentvalue = calculateQtrSales(customerseq, 1, year(date) - 1)
			response.write formatcurrency(currentvalue)
			lastyeartotal = lastyeartotal + currentvalue
			%></TD>
		<TD align="right"><%
			currentvalue = calculateQtrSales(customerseq, 1, year(date))
			response.write formatcurrency(currentvalue)
			thisyeartotal = thisyeartotal + currentvalue
			%></TD>
	</TR>
	<TR>
		<TD>Second</TD>
		<TD align="right"><%
			currentvalue = calculateQtrSales(customerseq, 2, year(date) - 1)
			response.write formatcurrency(currentvalue)
			lastyeartotal = lastyeartotal + currentvalue
			%></TD>
		<TD align="right"><%
			currentvalue = calculateQtrSales(customerseq, 2, year(date))
			response.write formatcurrency(currentvalue)
			thisyeartotal = thisyeartotal + currentvalue
			%></TD>
	</TR>
	<TR>
		<TD>Third</TD>
		<TD align="right"><%
			currentvalue = calculateQtrSales(customerseq, 3, year(date) - 1)
			response.write formatcurrency(currentvalue)
			lastyeartotal = lastyeartotal + currentvalue
			%></TD>
		<TD align="right"><%
			currentvalue = calculateQtrSales(customerseq, 3, year(date))
			response.write formatcurrency(currentvalue)
			thisyeartotal = thisyeartotal + currentvalue
			%></TD>
	</TR>
	<TR>
		<TD>Fourth</TD>
		<TD align="right"><%
			currentvalue = calculateQtrSales(customerseq, 4, year(date) - 1)
			response.write formatcurrency(currentvalue)
			lastyeartotal = lastyeartotal + currentvalue
			%></TD>
		<TD align="right"><%
			currentvalue = calculateQtrSales(customerseq, 4, year(date))
			response.write formatcurrency(currentvalue)
			thisyeartotal = thisyeartotal + currentvalue
			%></TD>
	</TR>
	<TR>
		<TD style="border-top:1px solid #EEE">Total</TD>
		<TD style="border-top:1px solid #EEE" align="right"><%=formatcurrency(lastyeartotal)%></TD>
		<TD style="border-top:1px solid #EEE" align="right"><%=formatcurrency(thisyeartotal)%></TD>
	</TR>
</TABLE>
<BR><BR>
<CENTER>
<INPUT type="button" style="width:100px;height:50px" value="Exit" onclick="returnToNotes()">
</CENTER>
</BODY>
</HTML>
