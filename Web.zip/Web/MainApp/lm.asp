<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim dayrange
	dim show
	dim showclosed

	dayrange = getReqVar("dayrange")
	show = getReqVar("show")


	if show = "" then show = "open"
	if dayrange = "" then dayrange = 1
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Credit Card Batch List</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function viewSelectedBatch(selectedAccount) {
		document.creditCardBatchList.action = "/mainapp/creditCardBatchStatus.asp?batchid=" + selectedAccount;
		document.creditCardBatchList.submit();
	}
	function createNewBatch() {
		document.creditCardBatchList.action = "/mainapp/creditcardbatchrequest.asp";
		document.creditCardBatchList.submit();
	}
	function exitForm() {
		document.creditCardBatchList.action = "/mainapp/accountMgmt.asp";
		document.creditCardBatchList.submit();
	}
	function updateFilter() {
		document.creditCardBatchList.action = "";
		document.creditCardBatchList.submit();
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="">

<!-- #include file="../include/banner.inc" -->

<B class="pageHeading">Credit Card Batch List</B>
<FORM id="creditCardBatchList" name="creditCardBatchList" action="creditCardBatchList.asp" method="post">


<TABLE style="">

<TR>
	<TD>
		<SELECT name="dayrange" onchange="updateFilter()">
			<OPTION value="0" <%if dayrange = 0 then%>selected<%end if%>>Today</OPTION>
			<OPTION value="1" <%if dayrange = 1 then%>selected<%end if%>>Yesterday</OPTION>
			<OPTION value="7" <%if dayrange = 7 then%>selected<%end if%>>Last Week</OPTION>
			<OPTION value="32" <%if dayrange = 32 then%>selected<%end if%>>Last Month</OPTION>
			<OPTION value="96" <%if dayrange = 96 then%>selected<%end if%>>Last Quarter</OPTION>
			<OPTION value="365" <%if dayrange = 365 then%>selected<%end if%>>Last Year</OPTION>
			<OPTION value="32000" <%if dayrange = 32000 then%>selected<%end if%>>All</OPTION>
		</SELECT>
  </TD>
	<TD style="width:20px"></TD>
	<TD>Show Open</TD>
	<TD><INPUT type="radio"  onclick="updateFilter()" name="show" value="open" <%if show = "open" then%>checked<%end if%>></INPUT></TD>
</TR>

<TR>
	<TD>

	</TD>
	<TD></TD>
	<TD>
		Show Closed
	</TD>
	<TD><INPUT type="radio"  onclick="updateFilter()" name="show" value="closed" <%if show = "closed" then%>checked<%end if%>></INPUT></TD>
</TR>

</TABLE>


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
    <BUTTON onclick="createNewBatch()">New<BR />Batch</BUTTON>
	</SPAN>
	
	<SPAN style="float:right">
		<BUTTON onclick="exitForm()">Exit</BUTTON>
	</SPAN>
</DIV>

<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH style="width:30px">&nbsp;</TH>
		<TH>Creation Date</TH>
		<TH style="width:20%">Accounts</TH>
		<TH style="width:20%">Status</TH>

	</TR>

	
<%
	dim rowColor
	dim isbatchopen
	
	rowColor = "white"
	
	query = "select min(DateInitiated) as dateinitiated, max(batchid) as batchid, count(*) as accountcnt, max(stage) as maxstage from paymentbatch "
	query = query & " where datediff(day, DateInitiated, getdate()) <= " & dayrange & " "

	query = query & " group by batchid order by dateinitiated desc"
	 
	set rs = getdisconnectedrecordset(query)

	while not(rs.eof or rs.bof)
		isbatchopen = rs("maxstage") > 0
		
		if (isbatchopen and show = "open") or (not isbatchopen and show = "closed") then
	%>
		<TR style="height:30px;background:<%=rowColor%>">
			<TD width="100px" align="center"><INPUT type="button" value="View" style="width:70px;height:27px;" onclick="viewSelectedBatch(<%=rs("batchid")%>)"></INPUT></TD>
			<TD><%=rs("dateinitiated")%></TD>
			<TD><%=rs("accountcnt")%></TD>
			<TD><%if isbatchopen then%><b>Open</b><%else%>Closed<%end if%></TD>
		</TR>		
	<%
			if rowColor = "white" then
			    rowColor = "#EEE"
			else
			    rowColor = "white"
			end if
		
		end if
		
		rs.movenext
	wend
	
	set rs = nothing
%>
</TABLE>

</FORM>
</BODY>
</HTML>
