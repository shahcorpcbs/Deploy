<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim l_storeid
	dim isSubmitted 
	dim allTimeRanges
	
	isSubmitted = Request.QueryString("submitted")
	
	if isSubmitted then
		updateDatabase()
	end if
	l_storeid = Session("storeid")
	
	
%>

<%
	dim actionString

	actionString = trim(Request.QueryString("userAction"))

	getAllTimeRanges
				
	select case actionString
		case "edit"
			getCycle()
		case "add"
			getDefaultCycle
		case "delete"
			deleteRecord
	end select

%>
<HTML>
<HEAD>
<TITLE>Edit Cycle</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">
	function submitForm(){
		var retVal
		var sClockindate
		var sClockoutdate
		var sHour
		var sMin
		var speriod
		retVal = true;
		
		if(!verifyTimeRange())
		{
			cbs_alert("Time overlaps with a previous period.");
			retVal = false;
			return;
		}
		
		if (document.editCycleForm.txtClockInDate.value == "" ) {
			cbs_alert("Enter a valid clockin date");
			retVal = false;
			return;
		}
		
		if (document.editCycleForm.txtClockOutDate.value == ""){
			cbs_alert("Enter a valid clockout date");
			retVal = false
			return;
		}
				
		sclockindate = new Date(document.editCycleForm.txtClockInDate.value)
		sHour =document.editCycleForm.clockInHours.value		
		sMin = document.editCycleForm.clockInMin.value
		sPeriod =document.editCycleForm.clockInHoursAM.value
		sclockindate.setHours(calculateHours(sHour,sPeriod), sMin)
		sclockoutdate = new Date(document.editCycleForm.txtClockOutDate.value)
		sHour =document.editCycleForm.clockOutHours.value
		sMin = document.editCycleForm.clockOutMin.value
		sPeriod =document.editCycleForm.clockOutHoursAM.value
		sclockoutdate.setHours(calculateHours(sHour,sPeriod), sMin)

		
		if ( sclockindate > sclockoutdate) {
			cbs_alert("Clockout time cannot be before Clockin time")
			retVal = false
		}
		if (retVal == true){
			document.editCycleForm.action="?Submitted=true";
			document.editCycleForm.submit();	
		}
		
	}
	
	function verifyTimeRange(){
		var ranges
		var begin
		var end
		var clockin
		var clockout
		var i
				
		ranges = document.editCycleForm.allTimeRanges.value.split("|");

		clockin = new Date(document.editCycleForm.txtClockInDate.value);

		clockin.setHours(
			calculateHours(
				document.editCycleForm.clockInHours.value,
				document.editCycleForm.clockInHoursAM.value),
			document.editCycleForm.clockInMin.value);
			
		clockout = new Date(document.editCycleForm.txtClockOutDate.value);
		clockout.setHours(
			calculateHours(
				document.editCycleForm.clockOutHours.value,
				document.editCycleForm.clockOutHoursAM.value),
			document.editCycleForm.clockOutMin.value);
				
		for(i = 0; i < ranges.length; i += 2)
		{
			begin = new Date(ranges[i]);
			end = new Date(ranges[i + 1]);

			if(clockin.getTime() < end.getTime() && clockout.getTime() > begin.getTime())
				return false;
		}

		return true;
	}
	
	function deletePeriod(){
        cbs_confirm("Are you sure you want to delete this cycle?", gotoDelete);
	}

	function gotoDelete() {
        clearConfirmMsg();
        document.editCycleForm.action="?userAction=delete";
        document.editCycleForm.submit();

	}
	
	
	
	function calculateHours(sHours,sPeriod){
		if(sPeriod == "PM" && sHours != 12)
			return parseInt(sHours) + 12;
		if(sPeriod == "AM" && sHours == 12)
			return 0;
			
		return sHours;
	}
	
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0>
<%
	dim formTitle
	if actionString="add" then
		formTitle ="Add"
	else
		formTitle ="Edit"	
	end if	
%>
<!-- #include file="../include/banner.inc" -->
<H1><%= formTitle%> Cycle</H1>

	<FORM id="editCycleForm" name="editCycleForm" action="" method="post">
		<INPUT type="hidden" name="targetPage" value="<%=actionString %>">
		<input type="hidden" name="allTimeRanges" value="<%=allTimeRanges%>">

<TABLE BORDER="2" CELLSPACING="1" CELLPADDING="0">
		<tr>
			<td>
				<INPUT id=txtClockInDate name=txtClockInDate class=text style="width:100px;" readonly value = "<%=l_clockinDate%>"  onClick="javascript:show_calendar('editCycleForm.txtClockInDate');">
			</td>
			<td>
				<select id=clockInHours name=clockInHours>
					<%
						for i=1 to 12
					%>
						<option value="<%= i%>"
					<%  if  i = l_clockinhr then%>
						SELECTED
					<%  end if%>
						><%= i%></option>
					<%
						next
					%>
					
				</select>
				<select id=clockInMin name=clockInMin>
					<%
						for i= 0 to 60
					%>
						<option value="<%= i%>"
					<%  if  i = l_clockinmin then%>
						SELECTED
					<%  end if%>
					
						><%= i%></option>
					<%
						next
					%>
				</select>
				<select id=clockInHoursAM name=clockInHoursAM >
					<option value="AM"
					<%  if  l_clockinhram= "AM" then%>
						SELECTED
					<%  end if%>
					>AM</option>
					<option value="PM"
					<%  if  l_clockinhram = "PM" then%>
						SELECTED
					<%  end if%>
					>PM</option> 
				</select>
			</td>
		</tr>
		<tr>
			<td>
				<INPUT id=txtClockOutDate name=txtClockOutDate class=text style="width:100px;" readonly value = "<%=l_clockOutDate%>" onClick="javascript:show_calendar('editCycleForm.txtClockOutDate');">
			</td>
			<td>
				<select id=clockOutHours name=clockOutHours>
					<%
						for i=  1 to 12
					%>
						<option value="<%=i%>"
					<%  if  i = l_clockouthr then%>
						SELECTED
					<%  end if%>
						><%=i%></option>
					<%
						next
						
					%>
				</select>
				<select id=clockOutMin name=clockOutMin>
					<%
						for i=0to 60
					%>
						<option value="<%= i%>"
					<%  if  i = l_clockoutmin then%>
						SELECTED
					<%  end if%>
						
						><%= i%></option>
					<%
						next
					%>
				</select>
				<select id=clockOutHoursAM name=clockOutHoursAM>
					<option value="AM"
					<%  if  l_clockouthram= "AM" then%>
						SELECTED
					<%  end if%>
					>AM</option>
					<option value="PM"
					<%  if  l_clockouthram = "PM" then%>
						SELECTED
					<%  end if%>
					>PM</option>
				</select>
			</td>

		</tr>
</table>

				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/OK.gif)" onClick= "submitForm()">

				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="history.back(-1);">

			<% if actionString <> "add" then %>

				<INPUT id=delButton name=delButton type=button value="Delete Cycle" style="width:100px;height:50px;" onClick="deletePeriod();">

			<% end if %>

</BODY>
</HTML>
<%
	dim l_clockinDate
	dim l_clockoutDate
	dim l_clockinhr
	dim l_clockinhram
	dim l_clockinmin
	dim l_clockouthr
	dim l_clockouthram
	dim l_clockoutmin
	dim i
	
	sub getDefaultCycle()
		dim dd,mm,yyyy

		dd = right(day(now) + 100, 2)
		mm = right(month(now) + 100, 2)
		yyyy = year(now)

		l_clockinDate = mm  & "/" & dd & "/" & yyyy
		l_clockinhr	= hour(now)
		l_clockinmin = minute(now)

		if  l_clockinhr <= 11 then
			l_clockinhram = "AM"
		elseif l_clockinhr > 11 then
			l_clockinhram = "PM"
			l_clockinhr = l_clockinhr - 12
		end if

		l_clockoutDate = l_clockinDate
		l_clockouthr = l_clockinhr
		l_clockoutmin = l_clockinmin
		l_clockouthram = l_clockinhram
	end sub
	
	sub getAllTimeRanges()
		dim query
		dim rs
		dim employeeid
		dim clockin
		dim myarr
		
		employeeid = session("setupEmployeeid")
		
		if actionString = "edit" then
			myarr = split(session("EmployeeCycle"),"to")
			clockin = trim(myarr(0))
			
			query = "select * from employeetime where employeeid = '" & employeeid  & "' and clockin <> " & dbcreateqrystring(clockin)
		else
			query = "select * from employeetime where employeeid = '" & employeeid  & "'"
		end if
	

		
		
		set rs = getDisconnectedRecordset(query)
		
		allTimeRanges = ""
		
		if rs.recordcount > 0 then
			
			allTimeRanges = rs("clockin") & "|" & rs("clockout")	
			rs.movenext
			
			while not rs.eof
				allTimeRanges = allTimeRanges + "|" & rs("clockin") & "|" & rs("clockout")	
				rs.movenext
			wend
		end if
		
		rs.close
		set rs = nothing	
		
	end sub
	
	
	Function getCycle()
	
	dim sqltxt
	dim s_Cycle
	dim l_employeeid
	dim sTemp 
	dim rstTemp
	dim myarr
	dim s_clockin
	dim s_clockout
	
	'Response.write session("EmployeeCycle")	
	l_employeeid = session("setupEmployeeid")
	myarr = split(session("EmployeeCycle"),"to")
	
	s_clockin = trim(myarr(0))
	
	s_clockout = trim(myarr(1))
	
	if s_clockout = "" then
		sqltxt = "select * from employeetime where employeeid = " & l_employeeid & " and clockin = " & dbcreateqrystring(s_clockin) & " and clockout is null"
	else
		sqltxt = "select * from employeetime where employeeid = " & l_employeeid & " and clockin = "  & dbcreateqrystring(s_clockin) & " and clockout = " & dbcreateqrystring(s_clockout)
	end if
	set rstTemp  = getDisconnectedRecordset(sqltxt)
	if not rstTemp.bof and not rstTemp.eof then 
	
		stemp = rstTemp("Clockin")
		dim syear
		if not isNull(stemp) then
			if len(month(stemp) ) < 2 then
				l_clockinDate = "0" & month(stemp) & "/"
			else
					l_clockinDate =  month(stemp)& "/"
			end if
			
			if len(day(stemp) ) < 2 then
					l_clockinDate = l_clockinDate & "0" & day(stemp) & "/"
			else
					l_clockinDate = l_clockinDate & day(stemp)& "/"
			end if
			l_clockinDate = l_clockinDate & year(stemp)
			
			
			'l_clockinDate =
			l_clockinhr= 0
			l_clockinhr = Hour(stemp)
			if len(l_clockinhr) <> 0 then
				l_clockinmin= minute(stemp)
				
				if  l_clockinhr <= 11 then
					l_clockinhram = "AM"
				elseif l_clockinhr > 11 then
					l_clockinhram = "PM"
				end if 

				if l_clockinhr = 0 then
					l_clockinhr = 12
				elseif l_clockinhr > 12 then
					l_clockinhr = l_clockinhr - 12
				end if
			end if 
		end if
		stemp = rstTemp("Clockout")
		if not isNull(stemp) then
		if len(month(stemp) ) < 2 then
				l_clockoutDate = "0" & month(stemp) & "/"
			else
					l_clockoutDate =  month(stemp)& "/"
			end if
			
			if len(day(stemp) ) < 2 then
					l_clockoutDate = l_clockoutDate & "0" & day(stemp) & "/"
			else
					l_clockoutDate = l_clockoutDate & day(stemp)& "/"
			end if
			l_clockoutDate = l_clockoutDate & year(stemp)
			l_clockouthr = Hour(stemp)
			if len(l_clockouthr) <> 0 then
				l_clockoutmin= minute(stemp)
				if  l_clockouthr <= 11 then
					l_clockouthram = "AM"
				elseif l_clockouthr > 11 then
					l_clockouthram = "PM"
				end if 
				if l_clockouthr = 0 then
					l_clockouthr = 12
				elseif l_clockouthr > 12 then
					l_clockouthr = l_clockouthr - 12
				end if
			end if
		end if
	end if
	rstTemp.close
	set rstTemp = nothing
	end Function
	
	sub deleteRecord()
		dim sqltxt
		dim l_mode 
		dim l_intime
		dim l_outtime
		dim l_employeeid
		
		l_employeeid = session("setupEmployeeid")
	
		l_mode = Request.Form("targetPage")
	
		l_inTime = Request.form("txtClockInDate") & " " &  Request.Form("clockInHours")  & ":" & Request.Form("clockInMin")   & " " & Request.Form("clockInHoursAM")
	
		if Request.form("txtClockOutDate")= "" then
			l_outTime = Request.form("txtClockInDate") & " " & Request.Form("clockOutHours") & ":" &  Request.Form("clockOutMin") & " " & Request.Form("clockOutHoursAM")
		else
			l_outTime = Request.form("txtClockOutDate") & " " & Request.Form("clockOutHours") & ":" &  Request.Form("clockOutMin") & " " & Request.Form("clockOutHoursAM")
		end if
	
		sqltxt = "Delete employeetime where employeeid = " & l_employeeid & " and clockin = " & DbCreateQryString(l_inTime)
		dbstartTrans()
		QryExecuteWithTrans(sqltxt)
		DbendTrans()
		
		Response.Redirect("EditEmployeeHours.asp")
	end sub
	
	
	
	
	Function UpdateDatabase()
	dim sqltxt
	dim l_mode 
	dim l_intime
	dim l_outtime
	dim l_employeeid
	l_employeeid = session("setupEmployeeid")
	
	l_mode = Request.Form("targetPage")
	
	l_inTime = Request.form("txtClockInDate") & " " &  Request.Form("clockInHours")  & ":" & Request.Form("clockInMin")   & " " & Request.Form("clockInHoursAM")
	
	if Request.form("txtClockOutDate")= "" then
		l_outTime = Request.form("txtClockInDate") & " " & Request.Form("clockOutHours") & ":" &  Request.Form("clockOutMin") & " " & Request.Form("clockOutHoursAM")
	else
		l_outTime = Request.form("txtClockOutDate") & " " & Request.Form("clockOutHours") & ":" &  Request.Form("clockOutMin") & " " & Request.Form("clockOutHoursAM")
	end if
	
	 dim myarr 
	 myarr = split(session("Employeecycle"), "to")
	 
	if l_mode = "add" then
		ssql = "Delete employeetime where employeeid = " & l_employeeid & " and clockin = " & DbCreateQryString(l_inTime)
	
		sqltxt = ssql & "; Insert Employeetime (employeeid, clockin , clockout) values( " _
					& L_employeeid _
					& ", convert(varchar, " & DbCreateQryString(l_inTime) _ 
					& " , 100)  , convert(varchar," & DbCreateQryString(l_outTime)  _
					&  " , 100))"
					
		
		dbstartTrans()
		QryExecuteWithTrans(sqltxt)
		DbendTrans()
		 
	elseif l_mode = "edit" then
	

	 
	 dim ssql
	 
		
		
		ssql = "Delete employeetime where employeeid = " & l_employeeid & " and clockin = '" & trim(myarr(0)) & "'"
		
		sqltxt = ssql& "; Insert Employeetime (employeeid, clockin , clockout) values( " _
					& L_employeeid _
					& ", convert(varchar, " & DbCreateQryString(l_inTime) _ 
					& " , 100)  , convert(varchar," & DbCreateQryString(l_outTime)  _
					&  " , 100))"
		dbstartTrans()
		
		QryExecuteWithTrans(sqltxt)
		
		DbendTrans()

	end if
		Response.Redirect("EditEmployeeHours.asp")
	end function
	
%>
