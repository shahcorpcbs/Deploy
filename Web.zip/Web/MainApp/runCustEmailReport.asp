<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!-- #include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->
<!--#include file="../include/queryParamFunctions.asp" -->

<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim queryName, queryTransformed, userQueryID, formTemplate, l_queryName, l_sendGrid
	dim from, params, dateString, reportId, custSchId
	dim schId, l_sendAsAttachment, userAction, l_formId, l_message, l_subject, l_emailField, l_formatType

	from = getReqVar("from")
	l_sendGrid = getMSVar("useSendGrid")

	
	userQueryID = getReqVar("userQueryID")
	queryTransformed = getReqVar("query")
	queryName = getReqVar("queryName")
	schId = getReqVar("schId")
	dateString = trim(Request.QueryString("dateString"))

	if from = "schedule" and queryTransformed = "" then

            query = "select ecs.id, ecs.userQueryId, ecs.subject, ecs.reportId, name, ecs.frequency, ecs.active, ecs.hour, "_
                & "ecs.dayOfWeek, ecs.day, ecs.sendAsAttachment, ecs.query, ecs.emailField, ecs.formatType, ecs.message, ecs.formId " _
                & "from EmailCustomerSchedule ecs "  _
                & " where ecs.id = " & schId
        set rs = getdisconnectedrecordset(query)

        userQueryID = rs("userQueryId")
        reportId = rs("reportId")
        queryName = rs("name")
        queryTransformed = rs("query")
        l_sendAsAttachment = rs("sendAsAttachment")
        l_formId = rs("formId")
        l_message = rs("message")
        l_subject = rs("subject")
        l_emailField = rs("emailField")
        l_formatType = rs("formatType")
        if userQueryId <> "" then
                query = "select name from userQuery where userQueryId = " & userQueryId
                set rs = getdisconnectedrecordset(query)
                l_queryName = rs("name")
                set params = getQueryParams(userQueryID)
                reportId = ""
	            queryName = getQueryName(userQueryID)
        else
                if reportId = 25 then
                    l_queryname = "AR Statement"
                else
                    l_queryname = "AR Multi-Pickup Statement"
                end if

                createReportParams(reportId)
           end if
	end if



    userAction = lcase(request.querystring("useraction"))
	select case userAction
	case "run"
        prepareEmail
	end select


	function prepareEmail
        dim query, rs
        set params = getQueryParams(queryTransformed)
        queryTransformed = transformQuery(queryTransformed, params, request.form, dateString)
        set params = getQueryParams(queryTransformed)
        l_sendAsAttachment = Request.QueryString("useAtt")
        l_subject = Request.QueryString("subject")
        l_message = Request.QueryString("message")
        l_formId =  Request.QueryString("formId")
        l_emailField = Request.QueryString("emailField")
        l_formatType = Request.QueryString("formatType")
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getQueryName(userQueryID)
		dim query, rs
		
		if userQueryID <> "" then
			query = "select name from userquery where userqueryid = " & userqueryid
			
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then getQueryName = rs("name")
		end if
	
	end function

    function createReportParams(reportId)
        dim result, query, rs, queryStart, defPl, defRId, defStartD, defSD, defDD, defSID, defIAI, defSZB, defENB
        if custSchId <> "" then
            queryStart = "select VariableValue vv from EmailReportVariable where CustEmailSchId = " & custSchId & " and VariableName = '"
            query = queryStart & "PriceListId'"
            set rs = getdisconnectedrecordset(query)
            defPl = rs("vv")

            query = queryStart & "RouteId'"
            set rs = getdisconnectedrecordset(query)
            defRId = rs("vv")

            query = queryStart & "StartDate'"
            set rs = getdisconnectedrecordset(query)
            defStartD = rs("vv")

            query = queryStart & "statementDate'"
            set rs = getdisconnectedrecordset(query)
            defSD = rs("vv")

            query = queryStart & "statementDueDate'"
            set rs = getdisconnectedrecordset(query)
            defDD = rs("vv")

            query = queryStart & "ShowDetail'"
            set rs = getdisconnectedrecordset(query)
            defSID = rs("vv")

            query = queryStart & "IncludeActive'"
            set rs = getdisconnectedrecordset(query)
            defIAI = rs("vv")

            query = queryStart & "ShowZeroBal'"
            set rs = getdisconnectedrecordset(query)
            defSZB = rs("vv")

            query = queryStart & "ExcludeNegativeBalances'"
            set rs = getdisconnectedrecordset(query)
            defENB = rs("vv")
        else
            defPl = -1
            defRId = -1
            defStartD = 7
            defSD = ""
            defDD = ""
            defSID = 0
            defIAI = 0
            defSZB = 0
            defENB = 0
        end if

        set result = CreateObject("Scripting.Dictionary")
        addParam result, "Price_List", "pricelist", defPl, 0, 0
        addParam result, "Route", "route", defRId, 0, 0
        addParam result, "Start_Date", "date", defStartD, 0, 0
        addParam result, "Statement_Date", "date", defSD, 0, 0
        addParam result, "Due_Date", "date", defDD, 0, 0
        addParam result, "Show_Invoice_Details", "bit", defSID, 0, 0
        addParam result, "Include_Active_Invoices", "bit", defIAI, 0, 0
        addParam result, "Show_Zero_Balance_Statements", "bit", defSZB, 0, 0
        addParam result, "Exclude_Negative_Balance_Statements", "bit", defENB, 0, 0
        set params = result
    end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function
%>

<HTML>
<HEAD>
<TITLE>Email Report</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<SCRIPT LANGUAGE="javascript" >


	function exit() {
        <% if from = "query" then %>
            document.runOnceCustForm.action = "querydb.asp";
        <% else %>
            document.runOnceCustForm.action = "../setup/custEmailReportSetup.asp";
        <% end if %>
            document.runOnceCustForm.submit();
	}

    function showHideDates() {
        var dateSel = document.getElementById('dateField').value;
        if (dateSel == 5) {
            document.getElementById('start_Date').style.visibility = "visible";
            document.getElementById('end_Date').style.visibility = "visible";
        }
        else {
            document.getElementById('start_Date').style.visibility = "hidden";
            document.getElementById('end_Date').style.visibility = "hidden";
        }
    }

	function run() {
	    if (document.getElementById("subject").value == "") {
	        cbs_alert("Must enter a subject");
	        return;
	    }

	    <% if from = "query" then %>
	        sendEmailRequest(`<%= trim(queryTransformed) %>`, $("#formId").val());
	    <% elseif reportId = "25" or reportId = "27" then %>
	        var dateRange = document.getElementById("dateField").value;
	        if (dateRange == 5) {
	            dateRange = dateRange + "_" + document.getElementById("start_Date").value + "_"
	            + document.getElementById("end_Date").value;
	        }
	        var stmtDate = document.getElementById("Statement_Date_sel").value;
	        if (stmtDate == 5) {
	            stmtDate = stmtDate + "_" + document.getElementById("Statement_Date_custDate").value
	        }
	        var stmtDueDate = document.getElementById("Due_Date_sel").value;
	        if (stmtDueDate == 5) {
	            stmtDueDate = stmtDueDate + "_" + document.getElementById("Due_Date_custDate").value
	        }

            var url = "<%=getMessengerFullPath("setup")%>/sendAREmail?" +
                "&employeeId=<%=session("employeeid")%>" +
                "&reportId=<%=reportId%>" +
                "&subject=" + encodeURIComponent(document.getElementById("subject").value) +
                "&message=" + encodeURIComponent(document.getElementById("message").value) +
                "&plId=" + encodeURIComponent(document.getElementById("Price_List").value) +
                "&routeId=" + encodeURIComponent(document.getElementById("Route").value) +
                "&dateRange=" + encodeURIComponent(dateRange) +
                "&stmtDate=" + encodeURIComponent(stmtDate) +
                "&stmtDueDate=" + encodeURIComponent(stmtDueDate) +
                "&showDetail=" + encodeURIComponent(document.getElementById("Show_Invoice_Details").value) +
                "&includeAct=" + encodeURIComponent(document.getElementById("Include_Active_Invoices").value) +
                "&showZero=" + encodeURIComponent(document.getElementById("Show_Zero_Balance_Statements").value) +
                "&excludeNeg=" + encodeURIComponent(document.getElementById("Exclude_Negative_Balance_Statements").value) +
                <% if l_sendGrid then %>
                "&formatType=" + encodeURIComponent(document.getElementById("formatType").value) +
                "&attachment=" + (document.getElementById('sendAtt').checked ? "1" : "0");
                <% else %>
                 "&formatType=1&attachment=0";
                <% end if %>
            $.ajax({
                type: "POST",
                url: url,
                data : "",
                contentType: "text/plain",
                Accept: "text/plain",
                timeout: "120000",
                success: function(xhr) {
                    cbs_alert("Email request sent to CBS Service", afterEmailSent);
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    console.log(xhr);
                    cbs_alert("Error sending email request to CBS Service, make sure service is running", afterEmailSent);
                }
            });
	    <% else %>
	        <% if l_sendGrid then %>
            var useAtt = document.getElementById('sendAtt').checked ? "1" : "0";
            <% else %>
            var useAtt = "0";
            <% end if %>
            var dateString = ""
            if (document.getElementById('dateField') != null) {
                dateString = document.getElementById('dateField').value;
                if (dateString == 5) {
                    var start = document.getElementById('start_Date').value;
                    var end = document.getElementById('end_Date').value;
                    if (start == "") {
                        cbs_alert("If using custom date, then start date must be entered")
                        return;
                    }
                    else if (end == "") {
                        cbs_alert("If using custom date, then end date must be entered")
                        return;
                    }
                    dateString = dateString + "_" + start + "_" + end;
                }
            }

            document.runOnceCustForm.action = "?useraction=run" +
                "&subject=" + encodeURIComponent(document.getElementById("subject").value) +
                "&message=" + encodeURIComponent(document.getElementById("message").value) +
                <% if l_sendGrid then %>
                "&formatType=" + encodeURIComponent(document.getElementById("formatType").value) +
                <% else %>
                "&formatType=1" +
                <% end if %>
                "&formId=" + encodeURIComponent($("#formId").val()) +
                "&useAtt=" + useAtt +
                "&dateString=" + encodeURIComponent(dateString);
            document.runOnceCustForm.submit();
        <% end if %>
    }


    function sendEmailRequest(body, formId) {
        var url = "<%=getMessengerFullPath("mainapp")%>/sendCustEmail?" +
            "&employeeId=<%=session("employeeid")%>" +
            "&emailField=" + encodeURIComponent(document.getElementById("emailField").value) +
            "&subject=" + encodeURIComponent(document.getElementById("subject").value) +
            "&message=" + encodeURIComponent(document.getElementById("message").value) +
            <% if l_sendGrid then %>
            "&formatType=" + encodeURIComponent(document.getElementById("formatType").value) +
            "&attachment=" + (document.getElementById('sendAtt').checked ? "1" : "0") +
            <% else %>
            "&formatType=1&attachment=0" +
            <% end if %>
            "&formId=" + encodeURIComponent(formId);
        $.ajax({
            type: "POST",
            url: url,
            data :body,
            contentType: "text/plain",
            Accept: "text/plain",
            timeout: "120000",
            success: function(xhr) {
                cbs_alert("Email request sent to CBS Service", afterEmailSent);
            },
            error: function(xhr, ajaxOptions, thrownError) {
                console.log(xhr);
                cbs_alert("Error sending email request to CBS Service, make sure service is running", afterEmailSent);
            }
        });
    }

    function afterEmailSent() {
        clearAlertMsg();
        <% if from = "query" then %>
            cbs_confirm("Would you like to create a schedule for emailing customers?", createSchedule, returnToResult)
        <% else %>
            document.runOnceCustForm.action = "../setup/custEmailReportSetup.asp"
            document.runOnceCustForm.submit();
        <% end if %>
    }

    function createSchedule() {
        document.runOnceCustForm.action = "/setup/editCustReportSch.asp?addoredit=add&userQueryId=<%=userQueryId%>";
        document.runOnceCustForm.submit();
    }

    function returnToResult() {
        document.runOnceCustForm.action = "querydb.asp?userQueryID=<%=userQueryID%>&query=<%=Server.URLEncode(queryTransformed)%>"
        document.runOnceCustForm.submit();
    }

    function showHideOtherDates(dateField) {
        var dateSel = document.getElementById(dateField + "_sel").value;
        if (dateSel == 5) {
            document.getElementById(dateField + '_custDate').style.visibility = "visible";
            document.getElementById(dateField + '_custDate').style.margin = "10px";
        }
        else {
            document.getElementById(dateField + '_custDate').style.visibility = "hidden";
        }
    }

    function init() {
        <% if userAction = "run" then %>
            sendEmailRequest(`<%= trim(queryTransformed) %>`, "<%= l_formId %>");
        <% end if %>
    }
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onLoad="init();">
<!-- #include file="../include/banner.inc" -->

<FORM name="runOnceCustForm" ID="runOnceCustForm" METHOD=POST onsubmit="return false" style="margin:0;padding:0">
<INPUT type="hidden" name="queryName" value="<%=Server.URLEncode(queryName)%>" />
<INPUT type="hidden" name="query" value="<%=queryTransformed%>" />
<INPUT type="hidden" name="userQueryID" value="<%=userQueryID%>" />
<INPUT type="hidden" name="from" value="<%=from%>" />

<H1>Email Report</H1><BR />
<BR />

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">

	</SPAN>

	<SPAN style="float:right">
		<BUTTON onclick="exit()" value="" >Cancel</BUTTON>
		<BUTTON onclick="run()" value="" >Run</BUTTON>
	</SPAN>
</DIV>

<TABLE class="itable" style="width:100%" cellpadding="0" cellspacing="0">
	<TR align="left">
		<TH>Attribute</TH>
		<TH>Value</TH>
	</TR>
    <tr>
        <td>Email Field</td>
        <td>
            <% if userQueryId <> "" then %>
            <SELECT id="emailField">

            <%
                    dim idx, fieldsQuery
                    set params = getQueryParams(queryTransformed)
                    fieldsQuery = forceValueQuery(queryTransformed, params)
                    set rs = getdisconnectedrecordset(fieldsQuery)
                    for idx = 0 to rs.Fields.Count - 1
            %>
            <OPTION
                <%if l_emailField = rs.Fields(idx).Name or (l_emailField = "" and lcase(rs.Fields(idx).Name) = "email") then%>selected<%end if%>>
                <%=Server.HTMLEncode(rs.Fields(idx).Name)%>
            </OPTION>
            <%
                next
            %>
            </SELECT>
            <% else %>
                <%= l_queryname %>
            <% end if %>
        </td>
    </tr>
	<TR>
		<TD>Email Subject</TD>
		<TD><INPUT id="subject" style="width:200px" value="<%=l_subject%>"></TD>
	</TR>
	<TR>
		<TD>Message</TD>
		<TD><textarea id="message" cols="50" rows="10" ><%=l_message%></textarea></TD>
	</TR>
	<% if userQueryId <> "" then %>
	<TR>
		<TD>Form</TD>
		<TD>        
		    <select id="formId">
                        <option value="0">none</option>
            			<%
            				query = " select formid, name from htmlform "
            				set rs = getdisconnectedrecordset(query)
            
            				while not(rs.eof or rs.bof)
            			%>
            			<OPTION value="<%=rs("formid")%>" <% if rs("formId") = l_formId then%>selected<% end if %>><%=server.htmlencode(rs("name"))%></OPTION>
            			<%
            				rs.movenext
            				wend
            				set rs = nothing
            			%>
            </select>
        </TD>
	</TR>
	<% end if %>
	<% if l_sendGrid then %>
	<TR>
		<TD>Send As Attachment</TD>
		<TD>
			<input type="checkbox" id="sendAtt" <% if l_sendAsAttachment then %> checked <%end if %>>
		</TD>
	</TR>
	<TR>
        <TD>Format Type</TD>
		<TD>
		    <SELECT id=formatType STYLE="font-size:16px;">
                <option value="1" <% if l_formatType = 1 then %> selected <% end if %>>HTML</option>
                <% if userQueryId <> "" then %>
                <option value="2" <% if l_formatType = 2 then %> selected <% end if %>>CSV</option>
                <% end if %>
                <option value="3" <% if l_formatType = 3 then %> selected <% end if %>>PDF</option>
            </SELECT>
        </TD>
	</TR>
	<% end if %>

	<% if from = "schedule" and userAction <> "run" then %>
        <tr height="50px"><td></td></tr>
        <tr><td colspan=2><b>Variables:</b></td></tr>
        <%
            dim item
            dim listedParameters

            set listedParameters = Server.CreateObject("Scripting.Dictionary")

            if ubound(params.items) >= 0 then
            for each item in params.items
                if not listedParameters.exists(replace(item.paramName, "@", "")) then
                    listedParameters.add item.paramName, ""
        %>
        <% if item.paramName <> "End_Date" then %>
        <TR>
            <TD>
                 <% if item.paramName = "Start_Date" then %>
                    Date Range
                 <% else %>
                    <%=Server.HTMLEncode(Replace(item.paramName, "_", " ") )%>
                 <% end if %>
            </TD>
            <TD>
                <% if reportId <> "" then %>
                    <%= getParamField(item, request.form(item.paramName), 1)%>
                <% else %>
                    <%= getParamField(item, request.form(item.paramName), 0)%>
                <% end if %>

            </TD>
        </TR>
    <% end if %>
    <%
            end if
        next
        else
    %>
        <TR>
            <TD colspan="2">This query does not have any parameters.</TD>
        </TR>
    <%
        end if
    %>
<% end if %>

</TABLE>

</FORM>
</BODY>
</HTML>

