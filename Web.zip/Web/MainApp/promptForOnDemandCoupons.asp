<%@ Language=VBScript %>
<%option explicit%>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	'***********************************************************************
	'Name   :Prompt for on demand coupon
    'Author : Poonam Gupta
    'Modification History
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 09-Jul-2002    Poonam			Original Version
    '***********************************************************************
	
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex
	dim curr_LineNo
	dim selectedDept
	dim addOrEdit
	dim ObjMiscSetUp
	dim autoInvNos
	dim deptStartIndex
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim originatingPage
	
	curr_LineNo = Request.QueryString("lineNo")
	selectedDept = Request.QueryString("dept")
	itemsStartIndex = Request.QueryString("itIndex")
	upChargeStartIndex = Request.QueryString("upIndex")
	colorsStartIndex = Request.QueryString("cIndex")
	patternStartIndex = Request.QueryString("pIndex")
	addOrEdit = Request.QueryString("addOrEdit")
	deptStartIndex = Request.QueryString("deptIndex")
	selItemId = Request.QueryString("selItemId")
	selUpchargeValue = Request.QueryString("selUp")
	selColorValue = Request.QueryString("selColor")
	selPatternValue = Request.QueryString("selPattern")
	originatingPage = Request.QueryString("originPage")	
%>
<HTML>
<HEAD>
<TITLE>Prompt For On Demand Coupon</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(userAction) {
		document.onDemandCouponPrompt.action = "detailedInvoice.asp?userAction=fromOnDemandCoupons&submit=" + userAction;
		document.onDemandCouponPrompt.submit();
	}
</Script>
<BODY topmargin=0 leftmargin=0>
	<!-- #include file="../include/banner.inc" -->
<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
	<FORM id="onDemandCouponPrompt" name="onDemandCouponPrompt" action="promptForOnDemandCoupons.asp" method="post">
		<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
		<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
		<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
		<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
		<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
		<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
		<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
		<INPUT type="hidden" name="onHold" value="0">
		<INPUT type="hidden" name="tPage" value="detail">
		<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
		<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
		<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
		<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
		<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
		<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
		<tr height=100px><td></td></tr>
		<tr>
			<td class=label colspan=2> Do you want to apply On Demand Coupons?
			</td>
		</tr>
		<tr height=10px><td></td></tr>
		<tr>
			<td align="center" width="80px">
				<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/ok.gif);" onClick= "submitForm('yes')">
			</td>
			<td align="center" width="80px">
				<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="submitForm('no')">
			</td>
		</tr>
	</form>
</table>
</BODY>
</HTML>
