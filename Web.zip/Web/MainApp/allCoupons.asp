<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<%sec_RequestAccess Request.QueryString("targetPage")%>
<%
	dim orgPage
	dim itemsStartIndex, upChargeStartIndex, patternStartIndex, colorsStartIndex
	'dim upchargeSet, colorSet, patternSet
	dim curr_LineNo
	dim selectedDept
	dim couponStartIndex
	dim actionString
	dim addOrEdit
	'dim dueDateSet
	dim deptStartIndex
	dim selItemId, selUpchargeValue, selPatternValue, selColorValue
	dim targetPage, originatingPage
	dim sInvoicenumber
	dim CorL
	dim couponAvail

	dim isPrePay
	dim prepayAmt
	dim invPrePayPercent
	dim invoicesTotal
	dim forceSigAllTimes
	dim forceSigNoClaims
	dim claimsCount
	dim signatureId
	dim trackCheckNum
	dim promptIfCredit
	dim promptIfBalance
	dim allowPUTempAccount
	dim promptScanOrder
	dim invoiceNumber
	dim oldTPage
	dim itemCntWCost


	invoiceNumber = request.querystring("invoiceNumber")
	couponAvail = 0

	CorL = Request.QueryString("CorL")
	itemCntWCost = Request.QueryString("itemCntWCost")
	actionString = Request.QueryString("userAction")
	sInvoicenumber = session("invoicelist")
	oldTPage = Request.QueryString("oldTPage")


	
	if actionString = "nextCouponsPage" then
		targetPage = Request.QueryString("tPage")
		
		if targetPage = "detail" or targetPage = "counterSale" then
			curr_LineNo = Request.Form("lineNumber")
			selectedDept = Request.Form("selectedDept")
			itemsStartIndex = Request.Form("ItemPageCount")
			upChargeStartIndex = Request.Form("upChargePageCount")
			colorsStartIndex = Request.Form("colorsPageCount")
			patternStartIndex = Request.Form("PatternPageCount")
			addOrEdit = Request.Form("addOrEdit")
			'dueDateSet = Request.Form("isDueDateSet")
			deptStartIndex = Request.Form("DeptPageCount")
			selItemId = Request.Form("selItemId")
			selUpchargeValue = Request.Form("selUpcharge")
			selColorValue = Request.Form("selColor")
			selPatternValue = Request.Form("selPattern")
			targetPage = Request.QueryString("tPage")
			originatingPage = Request.Form("originPage")
		else
			isPrePay = Request.Form("isPrePay")
			prepayAmt = Request.Form("prepayAmt")
			invPrePayPercent = Request.Form("invPrepayPercent")
			invoicesTotal = Request.Form("invoicesTotal")
			forceSigAllTimes = Request.Form("forceSigAllTimes")
			forceSigNoClaims = Request.Form("forceSigNoClaims")
			claimsCount = Request.Form("claimsCount")
			signatureId = Request.Form("PickupSignatureId")
			trackCheckNum = Request.Form("trackCheckNumber")
			promptIfCredit = Request.Form("promptIfCredit")
			promptIfBalance = Request.Form("promptIfBalance")
			allowPUTempAccount = Request.Form("allowPUTempAccount")
			promptScanOrder = Request.Form("promptScanOrder")
		end if
	else
		targetPage = Request.QueryString("targetPage")
		
		if targetPage = "detail" or targetPage = "counterSale" then
			curr_LineNo = Request.QueryString("lineNo")
			selectedDept = Request.QueryString("dept")
			itemsStartIndex = Request.QueryString("itIndex")
			upChargeStartIndex = Request.QueryString("upIndex")
			colorsStartIndex = Request.QueryString("cIndex")
			patternStartIndex = Request.QueryString("pIndex")
			addOrEdit = Request.QueryString("addOrEdit")
			'upchargeSet = Request.QueryString("upSet")
			'colorSet = Request.QueryString("cSet")
			'patternSet = Request.QueryString("patSet")
			orgPage = Request.QueryString("page")
			'dueDateSet = Request.QueryString("isDueDateSet")
			deptStartIndex = Request.QueryString("deptIndex")
			selItemId = Request.QueryString("selItemId")
			selUpchargeValue = Request.QueryString("selUp")
			selColorValue = Request.QueryString("selColor")
			selPatternValue = Request.QueryString("selPattern")
			originatingPage = Request.QueryString("originPage")
		else
			isPrePay = Request.QueryString("isPrePay")
			prepayAmt = Request.QueryString("prepayAmt")
			invPrePayPercent = Request.QueryString("invPrepayPercent")
			invoicesTotal = Request.QueryString("invoicesTotal")
			forceSigAllTimes = Request.QueryString("forceSigAllTimes")
			forceSigNoClaims = Request.QueryString("forceSigNoClaims")
			claimsCount = Request.QueryString("claimsCount")
			signatureId = Request.QueryString("PickupSignatureId")
			trackCheckNum = Request.QueryString("trackCheckNumber")
			promptIfCredit = Request.QueryString("promptIfCredit")
			promptIfBalance = Request.QueryString("promptIfBalance")
			allowPUTempAccount = Request.QueryString("allowPUTempAccount")
			promptScanOrder = Request.QueryString("promptScanOrder")
		end if
	end if
	couponStartIndex = Request.Form("couponPageCount")
	if(IsEmpty(couponStartIndex)) OR couponStartIndex =0 then
		couponStartIndex=1
	else
		couponStartIndex=Int(couponStartIndex)
	end if
		
%>
<HTML>
<HEAD>
<TITLE>All Coupons</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function nextPage() {
		document.allCoupons.couponPageCount.value = eval(eval(document.allCoupons.couponPageCount.value) + eval(1));
		document.allCoupons.action = "?userAction=nextCouponsPage";
		document.allCoupons.submit();
	}
	
	function selectCoupon(element) {
		var couponId;
		var targetPage;
		var CorL;
		var curr_LineNo;
		var isPrePay;
		
		CorL = document.allCoupons.CorL.value;
		curr_LineNo = document.allCoupons.lineNumber.value + 1;
		targetPage = document.allCoupons.tPage.value;
		couponId = element.name;
		isPrePay = document.allCoupons.isPrePay.value;
		
		switch (targetPage) {
			case "detail":
					document.allCoupons.action ="detailedInvoice.asp?userAction=addCoupon&couponId=" + couponId +
					    "&CorL=" + CorL + "&lineNo=" + curr_LineNo;
					break;
			case "counterSale":
					document.allCoupons.action ="counterSale.asp?userAction=addCoupon&couponId=" + couponId;
					break;
			case "pickup":
					document.allCoupons.action ="pickup.asp?userAction=addCoupon&couponId=" + couponId + "&isPrePay=" +
					    isPrePay + "&invoicenumber=<%=invoiceNumber%>&targetPage=<%=oldTPage%>";
					break;
					
		}
		document.allCoupons.submit();
	}
	
	function cancelCoupon() {
		var targetPage;

		targetPage = document.allCoupons.tPage.value;

		switch (targetPage) {
			case "detail":
					document.allCoupons.action ="detailedInvoice.asp";
					break;
			case "counterSale":
					document.allCoupons.action ="counterSale.asp";
					break;
			case "pickup":
					document.allCoupons.action ="pickup.asp?targetPage=<%=oldTPage%>";
					break;
					
		}
		document.allCoupons.submit();
	}
</script>

<BODY topmargin=0 leftmargin=0 onLoad="init()">
<!-- #include file="../include/banner.inc" -->

<H1><% if CorL = "C" then %>Coupons<% else %>Loyalty Discounts<% end if %>&nbsp;<%=sInvoicenumber%>&nbsp; </H1>
<FORM id="allCoupons" name="allCoupons" action="allCoupons.asp" method="post">
<center>
	<INPUT type="hidden" name="lineNumber" value="<%= curr_LineNo%>">
	<INPUT type="hidden" name="selectedDept" value="<%= selectedDept%>">
	<INPUT type="hidden" name="upChargePageCount" value="<%= upChargeStartIndex %>">
	<INPUT type="hidden" name="colorsPageCount" value="<%= colorsStartIndex %>">
	<INPUT type="hidden" name="PatternPageCount" value="<%= patternStartIndex %>">
	<INPUT type="hidden" name="ItemPageCount" value="<%= itemsStartIndex %>">
	<INPUT type="hidden" name="couponPageCount" value="<%= couponStartIndex %>">
	<INPUT type="hidden" name="addOrEdit" value="<%= addOrEdit %>">
	<INPUT type="hidden" name="DeptPageCount" value="<%= deptStartIndex %>">
	<input type="hidden" name="selItemId" id="selItemId" value="<%= selItemId%>">
	<input type="hidden" name="selUpcharge" id="selUpcharge" value="<%= selUpchargeValue%>">
	<input type="hidden" name="selColor" id="selColor" value="<%= selColorValue%>">
	<input type="hidden" name="selPattern" id="selPattern" value="<%= selPatternValue%>">
	<INPUT type="hidden" name="tPage" value="<%= targetPage %>">
	<INPUT type="hidden" name="originPage" value="<%= originatingPage %>">
	<INPUT type="hidden" name="oldTPage" value="<%= oldTPage %>">
	<INPUT type="hidden" name="CorL" value="<%= CorL %>"> <!--Shows whether discount is Coupon or Loyalty-->
	
	<INPUT type="hidden" name="isPrePay" value="<%= isPrePay%>">
	<INPUT type="hidden" name="prepayAmt" value="<%= prepayAmt%>">
	<INPUT type="hidden" name="invPrepayPercent" value="<%= invPrepayPercent %>">
	<INPUT type="hidden" name="invoicesTotal" value="<%= invoicesTotal %>">
	<INPUT type="hidden" name="forceSigAllTimes" value="<%= forceSigAllTimes %>">
	<INPUT type="hidden" name="forceSigNoClaims" value="<%= forceSigNoClaims %>">
	<INPUT type="hidden" name="claimsCount" value="<%= claimsCount %>">
	<INPUT type="hidden" name="PickupSignatureId" value="<%= PickupSignatureId %>">
	<INPUT type="hidden" name="trackCheckNumber" value="<%= trackCheckNumber %>">
	<input type="hidden" name="promptIfCredit" id="promptIfCredit" value="<%= promptIfCredit%>">
	<input type="hidden" name="promptIfBalance" id="promptIfBalance" value="<%= promptIfBalance%>">
	<input type="hidden" name="allowPUTempAccount" id="allowPUTempAccount" value="<%= allowPUTempAccount%>">
	<input type="hidden" name="promptScanOrder" id="promptScanOrder" value="<%= promptScanOrder%>">

				
	<DIV style="width:90%;">
		<%
			dim couponRst

			Set couponRst = Session("displayCoupons")

			if couponRst.recordcount > 0 then
				couponRst.movefirst
			end if

			while not(couponRst.eof or couponRst.bof)

                dim rs, query, show
                show = 1
                query = "select discountSubType, minPieceCount, itemAboveZero from discount where discountId = " & couponRst.Fields("discountId")
                set rs = getdisconnectedrecordset(query)

                if isNull(rs("minPieceCount")) then
                    show = 1
                elseif rs("discountSubType") = "Pieces" and rs("itemAboveZero") and itemCntWCost <> "" and cInt(rs("minPieceCount")) > cInt(itemCntWCost)  then
                    show = 0
                end if

            if show = 1 then
                couponAvail = 1
		%>
			<BUTTON CLASS=std STYLE="width:150px;height:75px;font-size:14px;margin:3px;vertical-align:top" name="<%= couponRst.Fields("discountId")%>" onClick="selectCoupon(this)"><%=Replace(couponRst.Fields("discountName"), "  ", "<br>")%></BUTTON>
		<%
		    end if
				couponRst.movenext
			wend
		%>
		
	
	</DIV>

	<BR><BR>

	<INPUT class=touchnoBorder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif);" onClick="cancelCoupon();">


</FORM>
</center>
<script language="javascript" type="text/javascript">
    function init() {
        <% if couponAvail = 0 then %>
            cbs_alert("No Qualifying Coupons to add.", cancelCoupon);
        <% end if %>
    }
</script>
</BODY>
</HTML>
