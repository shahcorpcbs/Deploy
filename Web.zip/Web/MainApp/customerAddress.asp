<%@ Language=VBScript %>
<% option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim customerSeq
	dim addressID
	
	dim label
	dim street1
	dim street2
	dim street3
	dim city
	dim state
	dim zip
	
	customerSeq = getReqVar("customerSeq")
	addressID = getReqVar("addressID")
	

	
	select case lcase(request.querystring("useraction"))
	case "new"
		addressID = createNewAddress(customerseq, "")
		updateAddress addressID
	case "update"
		updateAddress addressID
	case "select"
		addressID = request.querystring("addressid")
	case "delete"
		deleteAddress customerseq, addressid
		addressid = 0
	end select
	
	loadAddress addressID
	
	function deleteAddress(customerseq, addressid)
		dim query, rs
		
		query = " delete from customeraddress where "
		query = query & " customersequencenumber = " & customerseq
		query = query & " and addressid = " & addressid
		
		qryexecute query
		
		
	end function
	
	function loadAddress(addressID)
		dim query, rs
		
		if addressID <> "" then
			query = " select * from address where addressid = " & addressID
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				label = rs("label")
				
				street1 = rs("street1")
				street2 = rs("street2")
				street3 = rs("street3")
			
				city = rs("city")
				state = rs("state")
				zip = rs("zip")
			end if
		end if
	end function
	
	function updateAddress(addressID)
		dim query, rs
		
		if addressID <> "" then
		
			query = " update address set "
			query = query & " label = '" & DBStr(request.form("label")) & "'"
			query = query & ", street1 = " & DbCreateQryString(request.form("street1"))
			query = query & ", street2 = " & DbCreateQryString(request.form("street2"))
			query = query & ", street3 = " & DbCreateQryString(request.form("street3"))
			query = query & ", city = " & DbCreateQryString(request.form("city"))
			query = query & ", state = " & DbCreateQryString(request.form("state"))
			query = query & ", zip = " & DbCreateQryString(request.form("zip"))
			query = query & " where addressid = " & addressID

			qryexecute query
		end if
	end function
	
	
	function createNewAddress(customerseq, label)
		dim query, rs

		openConnection
		query = "insert into address (label) values ('" & DBStr(label) & "')"
		dbInsert query
			
		set rs = dbSelect("select @@IDENTITY as addressID")
			
		createNewAddress = rs("addressID")
		
		set rs = nothing
			
		closeConnection
		
		query = "insert into customeraddress (customersequencenumber, addressid) "
		query = query & " values (" & customerseq
		query = query & ", " & createNewAddress
		query = query & ")"
		
		qryexecute query

	end function

	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
    function getNewMapFilename(description)
		dim path
		dim query, rs

		openConnection
		
		query= "INSERT INTO GeneratedMap (Description) VALUES ('" & description & "')"
		dbInsert query

		set rs = dbSelect("select @@IDENTITY as NewID")
		getNewMapFilename = rs("NewID")

		set rs = nothing
		
		closeConnection
    end function

	function getStoreAddress(storeid)
		dim query, rs
		dim result
		
		query = "select isnull(streetaddress1, '') as streetaddress1, "
		query = query & " isnull(streetaddress2, '') as streetaddress2, "
		query = query & " isnull(city, '') as city, "
		query = query & " isnull(state, '') as state, "
		query = query & " isnull(zipcode, '') as zipcode "
		query = query & " from store where storeid = " & storeid
		
		set rs = getdisconnectedrecordset(query)
			
		getStoreAddress = ""
		
		if rs.recordcount > 0 then
			result = trim(rs("streetaddress1"))
			if trim(rs("streetaddress2")) <> "" then
				result = result & vbcrlf & trim(rs("streetaddress2"))
			end if
			result = result & vbcrlf
			result = result & trim(rs("city")) & " " & trim(rs("state")) & ", " & trim(rs("zipcode"))
		end if
		
		set rs = nothing
		
		getStoreAddress = result
	end function

    function mapAddress(address)
        dim connector
        dim mp
		dim generatedmapid
		dim path
		dim physicalpath
		
        set connector = Server.CreateObject("MapServer.Connector")
        set mp = connector.MapPointController

        mp.ClearRoute

		mp.AddRouteStop cstr(getStoreAddress(session("storeid"))), "1"
        mp.AddRouteStop cstr(address), "2"
		mp.CalculateRoute
		
		generatedmapid = getNewMapFilename("Route Map")
		
		path = "/Maps/" & generatedmapid & ".png"
		physicalpath = Request.ServerVariables("APPL_PHYSICAL_PATH") & "Maps\" & generatedmapid & ".png"

		mp.SaveMapAsGif cstr(physicalpath), 600, 500

		mapAddress = path
		
        set rs = nothing
        set mp = nothing
        set connector = nothing
    end function
	
	function validateAddress(addressid)
		dim query, rs
		
		query = " update address set validated = 1 where addressid = " & addressid
		qryexecute query
		
		goToRef
	end function
%>
<HTML>
<HEAD>
<TITLE>Customer Address</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function newAddress() {
		document.customerAddress.action = "?useraction=new";
		document.customerAddress.submit();
	}
	
	function updateAddress() {
		document.customerAddress.action = "?useraction=update";
		document.customerAddress.submit();
	}
	function selectAddressID(addressid) {
		document.customerAddress.action = "?useraction=select&addressid=" + addressid;
		document.customerAddress.submit();
	}
	function deleteAddress() {
		document.customerAddress.action = "?useraction=delete";
		document.customerAddress.submit();
	}
</SCRIPT>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Customer Address</H1>
<FORM id="customerAddress" name="customerAddress" action="" method="post">

<input type="hidden" name="addressID" value="<%=addressID%>" />
<input type="hidden" name="customerSeq" value="<%=customerSeq%>" />

<select onchange="selectAddressID(this.value)">
<%
	query = " select address.* from address inner join customeraddress on "
	query = query & " address.addressid = customeraddress.addressid "
	query = query & " where customeraddress.customersequencenumber = " & customerseq
	
	set rs = getdisconnectedrecordset(query)
	
	while not(rs.eof or rs.bof)
%>

	<option value="<%=rs("addressid")%>" <%if trim(addressid) = trim(rs("addressid")) then%>selected<%end if%>><%=rs("label")%></option>
<%
		rs.movenext
	wend
	
	set rs = nothing
%>
</select>
<input type="button" value="Delete" onclick="deleteAddress()" />
<input type="button" value="New" onclick="newAddress()" />
<input type="button" value="Update" onclick="updateAddress()" />

<table>
	<tr>
		<td valign="top">
			<table>
				<tr>
					<td colspan="3">
						Label<br />
						<input name="label" value="<%=label%>" />
						
					</td>
				</tr>
				<tr>
					<td colspan="3">
						Street<br />
						<input style="width:222px" name="street1" value="<%=street1%>" /><br />
						<input style="width:222px" name="street2" value="<%=street2%>" /><br />
						<input style="width:222px" name="street3" value="<%=street3%>" />
					</td>
				</tr>
				<tr>
					<td>
						City<br />
						<input style="width:100px" name="city" value="<%=city%>" />, 
					</td>
					<td>
						State<br />
						<input style="width:30px" name="state" value="<%=state%>" />
					</td>
					<td>
						Zip<br />
						<input style="width:80px" name="zip" value="<%=zip%>" />
					</td>
				</tr>
			</table>
		</td>
		<td valign="top">
			<table>
				<tr>
					<td>
						<input type="button" value="Map" />
						<input type="button" value="Validate" />
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

</FORM>   

</BODY>
</HTML>
