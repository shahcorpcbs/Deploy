<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../include/SystemStartup.asp"-->
<% selectDatabase request.querystring("dbname") %>

<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../external/json.asp" -->

<%

	dim query, rs
	dim result
	dim json_encoder
	dim pcs_past_due : pcs_past_due = 0
	dim pcs_due_today : pcs_due_today = 0
	dim pcs_due_later : pcs_due_later = 0
	dim store_id
	dim store_name
	dim terminal_id
	dim json_result
	dim done

	set result = server.createobject("scripting.dictionary")
	set json_encoder = new JSON

	query = " SELECT Store.name, Store.storeID "
	query = query & " FROM Store "
	query = query & " WHERE Store.storeID = (SELECT MIN(storeID) From Store) "
	set rs = getdisconnectedrecordset(query)
	
	if rs.recordcount > 0 then
		store_id = rs("storeid").Value
		store_name = rs("name").Value
	end if
	
	result.add "store_id", store_id
	result.add "store_name", store_name

	query = "select id from TwilioResponseMessage trm where (id not in (select TwilioResponseMessageId from SMSMessageHistory) " _
	    & "or (select top 1 status from SMSMessageHistory where TwilioResponseMessageId = trm.id order by datechanged desc) = 0)" _
	    & " and errorCode in (0, 11200)"
	set rs = getdisconnectedrecordset(query)
	result.add "unreadMessages", rs.recordcount
	
	query = ""
	query = query & " SELECT isnull(SUM(dbo.getTotalPieces(Ticket.ticketNumber, null)), 0) as pcs_past_due "
	query = query & " FROM Ticket "
	query = query & " WHERE Ticket.ticketStatus = 'AC' "
	query = query & " AND DATEDIFF(day, Ticket.dueDate, getdate()) >= 0 "
	query = query & " AND dbo.pivotTicketRackLocationBrief(Ticket.ticketNumber, ',') = '' "
	
	set rs = getdisconnectedrecordset(query)
	
	if rs.recordcount > 0 then
		pcs_past_due = rs("pcs_past_due")
	end if
	
	result.add "pcs_due_later", pcs_due_later
	result.add "pcs_past_due", pcs_past_due
	result.add "pcs_due_today", pcs_due_today

	json_result = json_encoder.toJSON("store", result, true, null)
	
	terminal_id = request.querystring("terminalid") 
	if terminal_id <> "" then
	
		query = " select name, description"
		query = query & " from terminal "
		query = query & " where terminalid = " & terminal_id
	
		set rs = getdisconnectedrecordset(query)
		
		
		if rs.recordcount > 0 then
			json_result = json_result & ", ""terminal"": { "
			json_result = json_result & " ""name"": """ & js_encode(rs("name")) & """, "
			json_result = json_result & " ""description"": """ & js_encode(rs("description")) & """"
			json_result = json_result & " }"
		end if

		query = " select customersequencenumber, transactionid, amount "
		query = query & " from cardpayment "
		query = query & " where terminalid = " & terminal_id
		query = query & " and success is null "
		query = query & " and amount > 0 "
		query = query & " and datediff(hour, daterequested, getdate()) <= 1 "

		json_result = json_result & ", ""open_card_payments"": ["

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			done = false
			while not done
				json_result = json_result & "{ "
				json_result = json_result & """customer_sequence_number"": " & rs("customersequencenumber") & ", "
				json_result = json_result & """transaction_id"": """ & js_encode(rs("transactionid")) & """, "
				json_result = json_result & """amount"": " & js_encode(rs("amount"))
				json_result = json_result & "}"

				rs.movenext

				if (rs.eof or rs.bof) then
					done = true
				else
					json_result = json_result & ","
				end if
			wend
		end if

		json_result = json_result & "]"

	end if
	
	response.write "{ " & json_result & " }"
	
	

	function js_encode(s)
		on error resume next
		if not isnull(s) then
			js_encode = s
			js_encode = Replace(js_encode, "\", "\\") 
			js_encode = Replace(js_encode, """", "\""")
			js_encode = Replace(js_encode, vbCr, "\r")
			js_encode = Replace(js_encode, vbLf, "\n")
		end if
	end function 
	
	
	
	
%>