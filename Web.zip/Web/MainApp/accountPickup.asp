<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<%
dim query, rs
dim accountPickupID
dim targetPage
dim customerSeq

accountPickupID = getReqVar("accountPickupID")
targetPage = getReqVar("targetPage")
customerSeq = getReqVar("customerSeq")

if accountPickupID = "" then
	accountPickupID = createNewAccountPickup("New account pickup")
end if


select case lcase(request.querystring("useraction"))
case "pickup"
	addFormTickets request.querystring("ticketnumber")
case "addtickets"
	addFormTickets request.form("invoiceData")
case "removetickets"
	removeSelectedTickets	request.form("selectedItem")
case "pickuptickets"
	pickupTickets
	goToTargetPage targetPage
case "exit"
	goToTargetPage targetPage
end select	


function goToTargetPage(targetPage)
	select case targetPage
	case "customerfunctions"
		response.redirect "customerfunctions.asp?customerseq=" & customerseq
	end select
end function


function pickupTickets()
	dim query
	
	query = " exec dbo.PostAccountPickup " & session("terminalid") & ", " & session("employeeid") & ", " & accountPickupID

	qryexecute query
end function

function removeSelectedTickets(selectedIDs)
	dim selectedID
	
	for each selectedID in selectedIDs
		response.write selectedID
		removeTicketFromAccountPickup selectedID
	next
end function

function addFormInvoices(invoiceData)
	dim invoicenumbers
	dim invoicenumber
	dim ticketnumber
	
	invoicenumbers = split(invoiceData, ",")
	
	for each invoicenumber in invoicenumbers
		ticketnumber = translateInvoiceToTicket(invoicenumber)
		if ticketnumber <> "" then
			addTicketToAccountPickup accountPickupID, ticketnumber
		end if
	next
end function

function addFormTickets(invoiceData)
	dim ticketnumbers
	dim ticketnumber
	
	ticketnumbers = split(invoiceData, ",")
	
	for each ticketnumber in ticketnumbers
		if ticketnumber <> "" then
			addTicketToAccountPickup accountPickupID, ticketnumber
		end if
	next
end function

function translateInvoiceToTicket(invoiceNumber)
	dim query, rs
	
	query = " select ticketnumber from ticket where invoicenumber = '" & DBStr(invoiceNumber) & "'"
	set rs = getdisconnectedrecordset(query)
	
	if rs.recordcount > 0 then
		translateInvoiceToTicket = rs("ticketnumber")
	end if
	
end function

function getReqVar(id)
	if Request.QueryString(id) <> "" then
		getReqVar = Request.QueryString(id)
	else
		getReqVar = Request.Form(id)
	end if
end function

function createNewAccountPickup(description)
	dim query, rs
	
	openConnection
	
	query= " insert into AccountPickup (Description) "
	query = query & " values ('" & DBStr(description)& "')"

	
	dbInsert query

	set rs = dbSelect("select @@IDENTITY as NewID")
	createNewAccountPickup = rs("NewID")

	set rs = nothing
	
	closeConnection
end function

function addTicketToAccountPickup(accountPickupID, ticketNumber)
	dim query

	query = " delete accountpickupitem where "
	query = query & " accountpickupid = " & accountpickupid
	query = query & " and ticketnumber = " & ticketnumber

	qryexecute query
	
	query = " insert into accountpickupitem (accountpickupid, ticketnumber) "
	query = query & " values (" & accountpickupid & ", " & ticketnumber & ")"

	qryexecute query
end function

function removeTicketFromAccountPickup(accountPickupItemID)
	dim query
	
	query = " delete accountpickupitem where accountpickupitemid = " & accountpickupitemid
	
	qryexecute query
end function
%>

<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT language="javascript" type="text/javascript">

	var timer = null;
	
	function resetTimeout() {
		if(timer != null) {
			clearTimeout(timer);
			timer = setTimeout("submitInvoiceData();", 1000);
		}
	}

	function captureKeyUpEvent(element) {
		if (event.keyCode == 13) {
			event.returnValue = true;
			
			switch(element.name) {
		        case "InvoiceNumber":
		            newDeliveryItem();
			}
		}
		return true;
	}
	
	function newDeliveryItem() {
		var InvoiceNumber;
		var tInvoiceNumber;
		
		InvoiceNumber = document.accountPickup.InvoiceNumber.value;
		
		  
		tInvoiceNumber = translateInvoiceNumber(InvoiceNumber);
		
		if(tInvoiceNumber != -1) {
		InvoiceNumber = tInvoiceNumber;
		}
		
	
	  if(document.accountPickup.invoiceData.value != "")
	  	document.accountPickup.invoiceData.value += ",";
	  
	  document.accountPickup.invoiceData.value += InvoiceNumber;
	  
	  if(timer != null)
	  	clearTimeout(timer);
	  
	  timer = setTimeout("submitInvoiceData();", 1000);
	  
	  resetForm();
	}

	function resetForm() {
		document.accountPickup.InvoiceNumber.value = "";
	}
	
	function submitInvoiceData() {
		document.accountPickup.action = "?useraction=addtickets";
		document.accountPickup.submit();
	}
	function removeSelectedItems() {
		document.accountPickup.action = "?useraction=removetickets";
		document.accountPickup.submit();
	}
	function pickupItems() {
		document.accountPickup.action = "?useraction=pickuptickets";
		document.accountPickup.submit();
	}
	function exit() {
		document.accountPickup.action = "?useraction=exit";
		document.accountPickup.submit();
	}
	
	
	function SetRowCheckedStatus(row, check, value) {

		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "selectedItem") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "selectedItem") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}
</SCRIPT>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="accountPickup.InvoiceNumber.focus()">
<!-- #include file="../include/banner.inc" -->
<!-- #include file="../include/store.inc" -->

<H1>Account Pickup <%=accountPickupID%></H1>

<FORM id="accountPickup" name="accountPickup" method="post" onsubmit="return false">

<INPUT type="hidden" name="invoiceData" value="">
<INPUT type="hidden" name="accountPickupID" value="<%=accountPickupID%>">
<INPUT type="hidden" name="targetPage" value="<%=targetPage%>">
<INPUT type="hidden" name="customerSeq" value="<%=customerSeq%>">

<TABLE>
	<TR>
		<TD>
			Add invoice to list:<BR />
			<INPUT name="InvoiceNumber" onKeyup="return captureKeyUpEvent(this)">
		</TD>
	</TR>
</TABLE>
			
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON onclick="pickupItems()">Pickup<BR />Invoices</BUTTON>
		<BUTTON onclick="removeSelectedItems()">Remove</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" width="100%" cellspacing="0" cellpadding="0">
<TR align="left">
	<TH>&nbsp;</TH>
	<TH>Invoice Number</TH>
	<TH>Amount</TH>
	<TH>Customer Discount</TH>
	<TH>Total</TH>
</TR>

<%
	if accountPickupID <> "" then
	
	query = " select accountpickupitemid, ticket.invoicenumber, "
	query = query & " ticket.invoicetotal, "
	query = query & " dbo.calcTicketAccountDiscount(ticket.ticketnumber) as discount, "
	query = query & " ticket.invoicetotal - dbo.calcTicketAccountDiscount(ticket.ticketnumber) as total "
	query = query & " from accountpickupitem "
	query = query & " inner join ticket on accountpickupitem.ticketnumber = ticket.ticketnumber "
	query = query & " where accountpickupid = " & accountPickupID

	set rs = getdisconnectedrecordset(query)

	while not(rs.eof or rs.bof)
%>
<TR onclick="ToggleRowChecked(this)" >
	<TD><INPUT type="checkbox" name="selectedItem" onclick="ToggleRowChecked(this.parentNode.parentNode);" value="<%=rs("accountpickupitemid")%>" /></TD>
	<TD><%=server.htmlencode(rs("invoicenumber"))%></TD>
	<TD><%=formatcurrency(rs("invoicetotal"))%></TD>
	<TD><%=formatcurrency(rs("discount"))%></TD>
	<TD><%=formatcurrency(rs("total"))%></TD>
</TR>
<%
		rs.movenext
	wend
	set rs = nothing
	
	end if
%>


</TABLE>

</FORM>
</BODY>
</HTML>
