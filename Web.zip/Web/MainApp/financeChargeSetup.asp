<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>

<HTML>
<HEAD>
<TITLE>Finance Charge Set Up</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
	function submitForm(){
		var temp = trim(document.financeChargeSetUpForm.txtfinanceCharge.value);
		if(temp.length >0){
			if(!isNum1(temp,0))	{
					show_focus("Enter valid amount.", "CBS Error", document.financeChargeSetUpForm.txtfinanceCharge);
					return;
			}
		}
		temp = cleanNumeric(document.financeChargeSetUpForm.txtMinAmount.value);
		if(temp == "")	{
				show_focus("Enter valid amount.", "CBS Error", document.financeChargeSetUpForm.txtMinAmount);
				return;
		}
		document.financeChargeSetUpForm.action = "applyFinanceCharges.asp?chargepercent="+ trim(document.financeChargeSetUpForm.txtfinanceCharge.value) + "&chargeamount=" + temp;
		document.financeChargeSetUpForm.submit();
		
	}
	function formatAmount(element){
		var temp = cleanNumeric(element.value)
		element.value = autoFormatCurrency(temp)
		
	}
	function validateDiscount(element){
		if ( ! isNum1(element.value, 0)){
			cbs_alert("Please enter a valid decimal value");
			element.focus();
		}
		if (element.value > 100){
			cbs_alert("Please enter a percentage less than 100%");
			element.focus();
		}
		if (element.value < 0){
			cbs_alert("Please enter a percentage less than 100%");
			element.focus();
		}
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Finance Charge Set Up</H1>
<FORM id="financeChargeSetUpForm" name="financeChargeSetUpForm" action="applyFinanceCharges.asp" method="Post">
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px></tr>
		<%
			dim query, rs
			dim financecharge, financeminamt
			query = "select financecharge, financeminamt from miscsetup where storeid = " & session("storeid")
			set rs = getdisconnectedrecordset(query)
			
			financecharge = "0.00"
			financeminamt = "0.00"
			
			if rs.recordcount > 0 then
				financecharge = rs("financecharge")
				financeminamt = rs("financeminamt")
			end if
			
			set rs = nothing
		%>
		<TR>
			<TD align=right class="label">Finance Charge %</TD>
			<TD>
				<INPUT id=txtfinanceCharge name=txtfinanceCharge class=text style="HEIGHT: 25px; WIDTH: 150px" value ="<%=financecharge%>" onKeyUp="validateDiscount(this)">
			</TD>
		</TR>
		<TR><TD></TD><TD class="label">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Or<TD></TR>
		<TR>
			<TD align=right class="label">Minimum Amount</TD>
			<TD>
				<INPUT id=txtMinAmount name=txtMinAmount class=text style="HEIGHT: 25px; WIDTH: 150px" value = "<%=financeminamt%>" onKeyUp="formatAmount(this)" >
			</TD>
		</TR>
		<TR><TD></TD><TD class="label">(The Greater Charge)<TD></TR>		
		<!-- buttons -->
		<TR height=20px></TR>
		<TR>
			<TD colspan=2>
				<TABLE align="center" WIDTH="250px" BORDER=0 CELLSPACING=1 CELLPADDING=5>
					<tr>
						<TD align=center width=125px>
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/Ok.gif)" onClick="submitForm()">
						</TD>
						<td>
							<INPUT class=touchnoborder id=cancel name=cancel style="background-image:url(../images/Cancel.gif)" type=button value="" onClick="history.back(-1);">
						</td>
					</tr>
				</table>
			</TD>
		</TR>
	</TABLE>
</FORM>   

</BODY>
</HTML>