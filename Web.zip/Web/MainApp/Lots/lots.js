
var Forum = {};

Ext.onReady(function(){

    Ext.QuickTips.init();

	function rendColor(value, p, record) {
		return '<span style="color:' + record.data.colorcode + '">' + value + '</span>'
	}
	function rendCapacity(value, p, record) {
		var multiplier = record.data.maxgarments / 100;
		return record.data.currentgarments + ' of ' + record.data.maxgarments;
	}
    var cm = new Ext.grid.ColumnModel([
		{ id: 'name', header: "Name", dataIndex: 'name', width: 120 },		
		{ header: "Number", dataIndex: 'number', width: 85 },
		{ header: "Color", dataIndex: "color", renderer: rendColor, width: 85 },
		{ header: "Capacity", renderer: rendCapacity, width: 100 },
		{ header: "Date Opened", dataIndex: 'dateopened', renderer: Ext.util.Format.dateRenderer('m/d/Y'), width: 100 }
		]);

	var openLots = new Ext.grid.GridPanel({
                            region:'center',
                            id:'topic-grid',
                            store: new Ext.data.Store({
						        remoteSort: true,
						
						        proxy: new Ext.data.HttpProxy({
						            url: 'actions.asp?a=getOpenLots'
						        }),
						
						        reader: new Ext.data.JsonReader(
						        {
						            root: 'rows',
						            totalProperty: 'recordcount',
						            id: 'lotid'
						        },
						        ['lotid', 'number', 'name', 'color', 'colorcode', 'maxgarments', 'currentgarments', 'dateopened'])
							}),
                            cm: cm,
                            sm: new Ext.grid.RowSelectionModel({singleSelect:true}),
                            trackMouseOver:false,
                            loadMask: {msg:'Loading Lots'},
							autoExpandColumn: 'name',
                            tbar:[
                                {
                                    text:'New Lot',
                                    handler:function(){alert('Not implemented.');}
                                },
                                {
                                    text:'Edit Lot',
                                    handler:function(){alert('Not implemented.');}
                                }
                            ]});
	
	
	var closedLotsStore = new Ext.data.Store({
						        remoteSort: true,
						
						        proxy: new Ext.data.HttpProxy({
						            url: 'actions.asp?a=getClosedLots'
						        }),
						
						        reader: new Ext.data.JsonReader(
						        {
						            root: 'rows',
						            totalProperty: 'recordcount',
						            id: 'lotid'
						        },
						        ['lotid', 'number', 'name', 'color', 'colorcode', 'maxgarments', 'currentgarments', 'dateopened'])
							});
							
	var closedLots = new Ext.grid.GridPanel({
                            region:'center',
                            id:'topic-grid',
                            store: closedLotsStore,
                            cm: cm,
                            sm: new Ext.grid.RowSelectionModel({singleSelect:true}),
                            trackMouseOver:false,
                            loadMask: {msg:'Loading Lots'},
							autoExpandColumn: 'name',
							bbar: new Ext.PagingToolbar({
							            pageSize: 25,
							            store: closedLotsStore,
							            displayInfo: true,
							            displayMsg: 'Displaying lots {0} - {1} of {2}',
							            emptyMsg: "No lots to display"
									})
                            });
							
	var lotTickets = new LotTicketGrid({
				region:'south',
				height:250,
				title:'Invoices',
				split:true,
		        id:'lotTickets'
				});
	
    var viewport = new Ext.Viewport({
        layout:'border',
        items:[
        
            new Ext.TabPanel({
                id:'main-tabs',
                activeTab:0,
                region:'center',
                margins:'0 5 0 0',
                resizeTabs:true,
                tabWidth:150,
                items: [
					{
                    id:'main-view',
                    layout:'border',
                    title:'Open Lots',
					items: openLots
                 	},
					{
                    id:'main-1',
                    layout:'border',
                    title:'Closed Lots',
					items: closedLots,
					listeners: {activate: loadClosedLots}

                 	}
				 ]
              }),

			lotTickets
         ]
    });

	function loadClosedLots() {
		closedLots.store.load();
	}
	var gsm = openLots.getSelectionModel();
	
    gsm.on('rowselect', function(sm, index, record) {
		this.loadLotTickets(record.data.lotid)
		
    }, lotTickets, {buffer:250});
	
	gsm = closedLots.getSelectionModel();
	
    gsm.on('rowselect', function(sm, index, record) {
		this.loadLotTickets(record.data.lotid)
		
    }, lotTickets, {buffer:250});
	
	openLots.store.load();
});

