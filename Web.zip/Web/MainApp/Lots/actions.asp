<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../../include/QueryDatabase.asp"-->
<!--#include file="../../include/json.asp"-->

<%
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if
	
	select case request.querystring("a")
	case "getOpenLots"
		response.write getLots(true)
	case "getClosedLots"
		response.write getLots(false)
	case "getColors"
		response.write getColors()
	case "getLotGroups"
	
	case "getLotTickets"
		response.write getLotTickets()
	end select
	
	dim query, rs

	function getColors()
		query = " select * from lotcolor "
	
		set rs = getdisconnectedrecordset(query)

		getColors = rsToJSON(rs, limit, start)
	
		set rs = nothing
	end function
	
	function getLots(showOpen)
		query = " select "
		query = query & " lot.id as lotid,"
		query = query & " lot.number,"
		query = query & " lot.name,"
		query = query & " lot.color,"
		query = query & " isnull('#' + lotcolor.hexcolor, lot.color) as colorcode,"
		query = query & " lot.maxgarments,"
		query = query & " lot.currentgarments,"
		query = query & " lot.dateopened"
		query = query & " from lot "
		query = query & " left outer join lotcolor on lot.color = lotcolor.name "
		if showOpen then query = query & " where lot.status = 'O' "
			
		set rs = getdisconnectedrecordset(query)

		if isnull(limit) then limit = 25
		
		getLots = rsToJSON(rs, limit, start)
	
		set rs = nothing
	end function
	
	
	function getLotTickets()
		dim lotID
		
		lotID = request.form("lotID")
		
		if lotID <> "" then
			
			query = "select ticket.invoicenumber, customer.customername, "
			query = query & " dbo.getTotalPieces(ticket.ticketnumber, null) as piececount, "
			query = query & " dbo.pivotTicketRackLocationBrief(ticket.ticketnumber, ', ') as racklocation, "
			query = query & " 'TODO' as employeename, '01/01/01' as datetagged, 'TODO' as tagnumbers, 'TODO' as departmentname "
			query = query & " from ticket "
			query = query & " inner join customer on ticket.customersequencenumber = customer.customersequencenumber  "
			query = query & " where ticket.lotid = " & lotID

			
			set rs = getdisconnectedrecordset(query)
		
			
			getLotTickets = rsToJSON(rs, limit, start)
		
			set rs = nothing
		
		end if
		
	
	end function
%>