



LotTicketGrid = function(config) {
	Ext.apply(this, config);
	
	this.store = new Ext.data.Store({
	    remoteSort: true,
	    proxy: new Ext.data.HttpProxy({ url: 'actions.asp?a=getLotTickets' }),
	    reader: new Ext.data.JsonReader(
			{
	            root: 'rows',
	            totalProperty: 'recordcount'
	        },
	        [
				'invoicenumber',
				'customername',
				'piececount',
				'racklocation',
				'employeename',
				'datetagged',
				'tagnumbers',
				'departmentname'
			])
	});
	
    this.columnModel = new Ext.grid.ColumnModel([
		{ header: "Invoice", dataIndex: 'invoicenumber', width: 85 },		
		{ id: "customername", header: "Customer", dataIndex: 'customername', width: 120 },
		{ header: "Pieces", dataIndex: "piececount", width: 85 },
		{ header: "Rack", dataIndex: "racklocation", width: 100 },
		{ header: "Tags", dataIndex: "tagnumbers", width: 100 },
		{ header: "Employee", dataIndex: "employeename", width: 100 },
		{ header: "Date Tagged", dataIndex: "datetagged", width: 100 }
		]);

				
    LotTicketGrid.superclass.constructor.call(this, {
		        store: this.store,
		        cm: this.columnModel,
		        sm: new Ext.grid.RowSelectionModel({singleSelect:true}),
		        trackMouseOver:false,
		        loadMask: {msg:'Loading Tickets'},
				autoExpandColumn: 'customername'
		        });
}


Ext.extend(LotTicketGrid, Ext.grid.GridPanel, {

	loadLotTickets : function(lotID) {
		this.store.load({params:{lotID: lotID}});
	}


});