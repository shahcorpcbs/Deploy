
MessageFormPanel = function(employeeID, config) {
	this.lotID = lotID;
	Ext.apply(this, config)
    MessageFormPanel.superclass.constructor.call(this, {
		url:'actions.asp?a=saveLot',
        labelAlign: 'top',
        frame:true,
        bodyStyle:'padding:5px 5px 0',
        viewConfig: {
            forceFit:true
        },

        reader : new Ext.data.JsonReader(
			{
	            root: 'rows',
	            totalProperty: 'recordcount',
	            id: 'messageid'
	        },
	        ['messageid', 'subject', 'body', {name: 'to', mapping: 'sendername'}, 'previousmessageid']
        ),

        items:
			{
				xtype:'textfield',
                fieldLabel: 'Subject',
                name: 'subject',
				allowBlank:false,
				anchor:'50%'
            },{
	            xtype:'htmleditor',
	            id:'body',
	            fieldLabel:'Body',
	            height:200,
				anchor:'98%',
				allowBlank:false
            }
        ]
    });
}

Ext.extend(MessageFormPanel, Ext.FormPanel, {
    loadLot : function(lotID) {
        this.load({url:'actions.asp?a=getLot&lotID=' + lotID, waitMsg:'Loading'});
    },
	saveLot : function() {
		var form = this.getForm();

		if(form.isValid()) {
			form.submit({
				scope: this,
				waitMsg: 'Sending',
				params: {'lotID' : this.lotID},
				failure: function(frm, act) {
					Ext.MessageBox.alert('Saving', 'Error saving lot.');
				},
				success: function(frm, act) {
					if(act.result.success != 0)
						this.destroy();
					else
						Ext.MessageBox.alert('Saving', act.result.answer)
				}
			});
		}
		else
			Ext.MessageBox.alert('Saving', 'Form not complete.')
	},
	closeLot : function() {
		this.destroy();
	}
	
	
});