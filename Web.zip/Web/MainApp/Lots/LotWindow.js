

LotWindow = new function() {

	this.colorChooser = new Ext.form.ComboBox({
		fieldLabel: 'Color',
		name:'color',
		store: new Ext.data.Store({
		    proxy: new Ext.data.HttpProxy({ url: 'actions.asp?a=getColors' }),
		    reader: new Ext.data.JsonReader(
				{
		            root: 'rows',
		            totalProperty: 'recordcount',
		            id: 'name'
		        },
		        ['name', 'hexcolor'])
		}),
		valueField: 'name',
		displayField: 'name',
		typeAhead: true,
		triggerAction: 'all',
		emptyText: 'Select a color',
		selectOnFocus: true,
		anchor:'50%'
	});
	
	this.lotGroupChooser = new Ext.form.ComboBox({
		fieldLabel: 'Lot',
		name:'lot',
		store: new Ext.data.Store({
		    proxy: new Ext.data.HttpProxy({ url: 'actions.asp?a=getLotGroups' }),
		    reader: new Ext.data.JsonReader(
				{
		            root: 'rows',
		            totalProperty: 'recordcount',
		            id: 'name'
		        },
		        ['name', 'hexcolor'])
		}),
		valueField: 'name',
		displayField: 'name',
		typeAhead: true,
		triggerAction: 'all',
		emptyText: 'Select a color',
		selectOnFocus: true,
		anchor:'50%'
	});
	
	this.form = new Ext.FormPanel() {
		
	}




}