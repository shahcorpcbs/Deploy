<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim customerseq, custEmail, custName
	dim dateBegin
	dim dateEnd
	dim cnt, searchText, includeErrors, l_emailType, includeEmp
	
	cnt = 0

	customerSeq = getReqVar("customerSeq")
	dateBegin = getReqVar("dateBegin")
	dateEnd = getReqVar("dateEnd")
	searchText = getReqVar("searchText")
	includeErrors = getReqVar("includeErrors")
	includeEmp = getReqVar("includeEmp")
	l_emailType = getReqVar("emailTypes")
	if includeErrors = "" then includeErrors = 0
	if l_emailType = "" then l_emailType = 1
	if dateBegin = "" then dateBegin = dateadd("m",-1,date())
	if dateEnd = "" then dateEnd =  dateadd("d",1,date())

	if customerseq <> "" then
	    query = "select email, customerName from customer where customerSequenceNumber = " & customerseq
	    set rs = getdisconnectedrecordset(query)
        custEmail = rs("email")
        custName = rs("customerName")
	end if

	query = " select eh.id, eh.employeeId, e.employeeName, eh.emailAddress, Message as body, case when reportText is null " _
	    & "then '' else reportText end as rt,formatType, eh.lastAttempt as messageDate, "_
	    & "c.customerName, c.customerSequenceNumber, qa.name queryName, queueStatus, errorMessage, category "_
	    & " from EmailHistory eh left join Customer c on c.customerSequenceNumber = eh.customerId "_
	    & " left join Employee e on eh.employeeId = e.employeeId left join QueryAlert qa on eh.qaId = qa.Id where 1 = 1 "

	if customerseq <> "" then
	    query = query & " and c.customerSequenceNumber = " & customerseq
	end if

	if dateBegin <> "" then
		query = query & " and datediff(day, lastAttempt, '" & dateBegin & "') <= 0 "
	end if

	if dateEnd <> "" then
		query = query & " and datediff(day, lastAttempt, '" & dateEnd & "') >= 0 "
	end if

    if searchText <> "" then
        query = query & " and LOWER(text) like '%" & dbstr(searchText) & "%' "
    end if

    if includeErrors = 0 then
        query = query & " and queueStatus = 1 "
    end if

    if includeEmp = 0 then
        query = query & " and eh.customerId is not null "
    end if

    if l_emailType = 1 then
        query = query & " and eh.qaId is not null "
    elseif l_emailType = 2 then
        query = query & " and eh.qaId is null "
    end if

	query = query & " order by messageDate desc "


	set rs = getdisconnectedrecordset(query)
	cnt = rs.recordcount

	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	function getMSVar(id)
		dim query, rs

		query = "select " & id & " from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)

		getMSVar = rs(id)

		set rs = nothing
	end function

%>
<HTML>
<HEAD>
<TITLE>Email History</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">
	var previousElement = null;
	var selectedMessage = null;
	var selectedReport = null;

	function update() {
	    var searchText = $.trim($("#searchText").val());
	    var action = "?useraction=update"
	    if (searchText.length > 0) {
	        action = action + "&searchText=" + encodeURIComponent(searchText)
	    }

	    action = action + "&includeErrors=" + ($("#chkErrors").is(":checked") ? "1" : "0");
	    action = action + "&includeEmp=" + ($("#chkIncEmp").is(":checked") ? "1" : "0");
	    action = action + "&emailTypes=" + $("#emailTypes").val();
		document.emailHistory.action = action;
		document.emailHistory.submit();
	}

	function viewCustomerFunctions(customerseq) {
		document.emailHistory.action = "customerfunctions.asp?customerseq=" + customerseq;
		document.emailHistory.submit();
	}

	function sendEmailMessage() {
	        window.open("/mainapp/sendEmailMessage2.asp?customerseq=<%=customerseq%>", "Send Email Message",
	            "status=no, height=600, width=700, center, edge=Sunken, help=No, resizable=yes, scroll=yes");
	}

	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}

		selectedMessage = element.getAttribute("fullMessage");
		selectedReport = element.getAttribute("fullReport");
		previousElement =element;
		element.className = "selected";

    }

    function viewFullMessage() {
	    if (selectedMessage != null) {
	        cbs_alert(decodeURIComponent(selectedMessage));
        }
    }

    function viewFullReport() {
	    if (selectedReport != null) {
	        cbs_alert(decodeURIComponent(selectedReport));
        }
    }

	function exit() {
        document.emailHistory.action = "/MainApp/toolsMenu.asp"
        document.emailHistory.submit();
	}

</script>

<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1 <% if customerseq <> "" then %> style="padding-bottom: 70px" <% end if %>>
    <% if customerseq <> "" then %>
        <SPAN style="float:left; padding-right: 35px">
            <table style="text-align: left; font-weight: bold">
            <tr><td>Email History</td></tr>
            <% 	if customerseq <> "" then %>
                <tr>
                    <td><%= custName %></td>
                </tr>
                <tr>
                    <td><%= custEmail %></td>
                </tr>
            <% end if %>
            </table>
        </SPAN>
    <% else %>
        Email History
    <% end if %>
    <SPAN style="float:right">
        Message Count: <%=cnt %>&nbsp;&nbsp;&nbsp;
    </SPAN>
</H1>

<FORM id="emailHistory" name="emailHistory" action="" method="post" onSubmit="return false">
<INPUT type="hidden" name="customerseq" value="<%=customerseq%>" />


<table>
    <tr>
        <td>Date range</td>
        <td>
            <INPUT name="dateBegin" value="<%=dateBegin%>" readonly onclick="javascript:show_calendar('smsHistory.dateBegin');">
            to
            <INPUT name="dateEnd" value="<%=dateEnd%>" readonly onclick="javascript:show_calendar('smsHistory.dateEnd');">
        </td>
        <td rowspan="3"><BUTTON class="cmdbar" onclick="update()">Look Up</BUTTON></td>
    </tr>
    <tr>
        <td>Messages Containing</td><td> <input type="text" size="49" id="searchText" value="<%=searchText%>"></td>
    </tr>
    <tr>
        <td>Types</td>
        <td>
            <select id="emailTypes">
                <option value="1" <% if l_emailType = 1 then%> selected <%end if %>>Notifications Only</option>
                <option value="2" <% if l_emailType = 2 then%> selected <%end if %>>Marketing Only</option>
                <option value="3" <% if l_emailType = 3 then%> selected <%end if %>>Both</option>
            </select>
        </td>
    </tr>
    <tr>
        <td>Include Errors</td>
        <td><Input type=checkbox  id="chkErrors"
        <% if includeErrors = 1 then %>
            checked
        <% end if %>
        ></td>
    </tr>
    <tr>
        <td>Include Emails Sent to Employees</td>
        <td><Input type=checkbox  id="chkIncEmp"
        <% if includeEmp = 1 then %>
            checked
        <% end if %>
        ></td>
    </tr>
</table>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON id="btnFullMessage" onclick="viewFullMessage()">View Full<BR>Message</BUTTON>
		<BUTTON id="btnFullReport" onclick="viewFullReport()">View Full<BR>Report</BUTTON>
	</SPAN>
	<% 	if customerseq <> "" then %>
        <% if getMSVar("useEmail") then %>
            <SPAN style="float:left">
                <BUTTON id="btnSendMessage" onclick="sendEmailMessage()">Send Email<BR>Message</BUTTON>
            </SPAN>
        <% end if %>
        <SPAN style="float:right">
            <BUTTON onclick="viewCustomerFunctions(customerseq.value)">Exit</BUTTON>
        </SPAN>
	<% else %>
        <SPAN style="float:right">
            <BUTTON onclick="exit()">Exit</BUTTON>
        </SPAN>
    <% end if %>
</DIV>

<div style="height: 640px; overflow: scroll">
<table class="itable" width="100%" cellspacing="0">
<tr>
    <% if customerseq = "" then %>
        <th>Customer</th>
    <% end if %>
	<th>Email Address</th>
	<th>Sent By</th>
	<th>Date Sent</th>
	<th>Category</th>
	<th>Message</th>
	<th>Report</th>
	<th>Status</th>
	<% if includeErrors = 1 then %>
	    <th>Error Message</th>
    <% end if %>
</tr>

<%
	while not(rs.eof or rs.bof)
%>
<tr onClick="selectRow(this)" fullMessage="<%=escape(rs("body"))%>" fullReport="<%=escape(rs("rt"))%>" >
    <% if customerseq = "" then %>
        <td><A HREF="/mainapp/customerfunctions.asp?customerseq=<%=rs("customerSequenceNumber")%>"><%=rs("customerName")%></A></td>
    <% end if %>
	<td><%=rs("emailAddress")%></td>
	<td>
	    <% if rs("employeeId") = 0 then%>
	        <% if rs("queryName") <> "" then %>
	            <%=rs("queryName")%>
	        <% else %>
	            Scheduler Service
	        <% end if %>
	    <% else %>
	        <%=rs("employeeName")%>
	    <% end if %>
    </td>
	<td><%=rs("messageDate")%></td>
	<td><%=rs("category")%></td>
	<td>
        <% if len(rs("body")) > 50 then %>
            <%=server.htmlencode(Left(rs("body"), 50))%>...
        <% else %>
           <%=server.htmlencode(rs("body"))%>
        <% end if %>
	</td>
	<td>
            <% if len(rs("rt")) > 50 then %>
                <%=Left(rs("rt"), 50)%>...
            <% else %>
               <%=rs("rt")%>
            <% end if %>
	</td>
    <td>
        <% if rs("queueStatus") = 0 then %>
            Queued
        <% elseif rs("queueStatus") = 1 then %>
            Sent
        <% else %>
            <span style="background-color: red">Error:
                <% if rs("queueStatus") = -1 then %>
                    Will Retry
                <% elseif rs("queueStatus") = -2 then %>
                    Won't Retry
                <% elseif rs("queueStatus") = -3 then %>
                    Blocked Due to Limit
                <% end if %>
            </span>
        <% end if %>
    </td>
	<% if includeErrors = 1 then %>
	    <td>
	        <% if rs("errorMessage") <> "" then %>
                <% if len(rs("errorMessage")) > 50 then %>
                    <%=server.htmlencode(Left(rs("errorMessage"), 50))%>...
                <% else %>
                   <%=server.htmlencode(rs("errorMessage"))%>
                <% end if %>
            <% end if %>
	    </td>
	<% end if %>
</tr>

<%
		rs.movenext
	wend
	set rs = nothing
%>
</table>
</div>

</FORM>
</BODY>
</HTML>

