<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<!--#include file="../include/services.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim l_storeid
	dim l_mode
	dim isSubmitted 
	dim l_action
	dim l_error
	dim clockOutTime
	dim clockInTime
	dim logInEmployeeId

	l_error = ""
	
	l_storeid = Session("storeid")
	isSubmitted = Request.QueryString("submitted")
	
	if isSubmitted then
		if verifyPassword() then
			updatedatabase()
			if l_error = "" then
				getLoginLogoutStatus

				select case Request.Form("h_mode")
				case "ClockOut"
					Response.Redirect("employeemenu.asp?alert=You have clocked out (" & clockOutTime & ").")
				case "ClockIn"
                    triggerSmsReport
					Response.Redirect("employeemenu.asp?alert=You have clocked in (" & clockInTime & ").")
				end select
			end if 
		end if
	end if
	sub getLoginLogoutStatus
		dim query, rs
		query = "select	clockin from employeetime where"
		query = query & " employeeid = " & Session("employeeid")
		query = query & " and clockout is null"
		query = query & " and clockin >= isnull((select max(clockout) from employeetime where employeeid = " & Session("employeeid") & "), clockin)"
		
		set rs = getdisconnectedrecordset(query)
		
		if not (rs.eof or rs.bof) then
			Session("loginDate") = rs("clockin")	
		else
			Session("loginDate") = ""
		end if
	
		set rs = nothing
	end sub
	dim actionString
	
	if trim(Request.QueryString("userAction")) <> "" then
		actionString = Request.QueryString("userAction")
	else
		actionString = Request.form("h_mode")
	end if

	function triggerSmsReport
	   dim query, rs
	   query = "select active from EmployeeReportQuery where id = 10"
	   set rs = getdisconnectedrecordset(query)

	   if rs("active") then
            Dim httpRequest, postResponse

                Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
                httpRequest.Open "POST", getMessengerFullPath("main") & "/employeeLogIn?employeeId=" & logInEmployeeId, False
                httpRequest.SetRequestHeader "Content-Type", "text/plain"
                httpRequest.Send
                postResponse = httpRequest.ResponseText
       end if
	end function

%>
<HTML>
<HEAD>
<TITLE>Clock In Clock Out</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">

	function submitForm(){
		if (trim(document.clockInForm.txtEmpId.value) == "" ) {
			cbs_alert("Please enter your password");
			document.clockInForm.txtEmpId.focus;
			}
		else {
			document.clockInForm.action = "?submitted=true";
			document.clockInForm.submit();	
		}
	}
	
	function cancelForm(){
		document.clockInForm.action = "employeemenu.asp";
		document.clockInForm.submit();
	
	}
	function setFocus(){
		document.clockInForm.txtEmpId.select();
		document.clockInForm.txtEmpId.focus();
	}
	
	function captureKeyUpEvent(element){
		
	  	if (event.keyCode == 13){
	  		event.returnValue = true;	
			submitForm();
		}
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0 onLoad="setFocus()">
<%
	dim formTitle
	if actionString="ClockIn" then
		formTitle ="Clock In"
	else
		formTitle ="Clock Out"	
	end if	
%>
<!-- #include file="../include/banner.inc" -->
<H1><%= formTitle%></H1>
<FORM id="clockInForm" name="clockInForm" action = "javascript:;" method="Post">
	<INPUT type="hidden" name="h_mode" value="<%= actionString %>">
	<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px></tr>
		<Tr>
			<TD align=center class="label" ><Font color = red><b><%=l_error%></B></font>
			</TD>
		<tr>
		<TR>
			<TD align=center class="label">Enter Your Password</TD>
		</TR>
		<TR>
			<TD align=center>
				<INPUT id=txtEmpId name=txtEmpId type="password" class=text style="HEIGHT: 25px; WIDTH: 254px" value = "<%=Request.Form("txtEmpId")%>" onKeyup = "captureKeyUpEvent(this)">
			</TD>
		</TR>
		<TR height=30px></TR>
		<TR>
			<TD>
				<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center> 
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="" style="background-image:url(../images/OK.gif)" onClick= "submitForm()">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" style="background-image:url(../images/Cancel.gif)"onclick="cancelForm()">
						</TD>
					</tr>
				</table>
			</TD>	
		</TR>
	</TABLE>
</FORM>   

</BODY>
</HTML>
<%

	function isEmployeeActive(storeID, employeePassword)
		dim query, rs

		query = " select employeeid from employee where employeestatus = 'A' and storeid = " & storeID & " and employeepassword = " & dbcreateqrystring(employeePassword)
		set rs = getdisconnectedrecordset(query)

		isEmployeeActive = rs.recordcount > 0

		set rs = nothing
	end function

	function updatedatabase()
	dim sqltxt, rs
	dim employeetimeid
	dim l_mode
	
		l_mode = Request.Form("h_mode")
		l_error = ""
		if l_mode = "ClockIn" then
			if not isEmployeeActive(l_storeid, request.form("txtEmpId")) then
				l_error = "Can not clock in an inactive employee."
			elseif  verifyCheckOut and isClockInTimeValid then 
				dbstartTrans()
				
				sqltxt = "insert employeetime (employeeid, clockin, clockout, hourlywage ) select employeeid, convert(varchar, getdate(), 100), null, hourlywage from employee where storeid = " & l_storeid  & " and employeepassword = " & dbcreateqrystring(request.form("txtEmpId"))
				qryexecutewithtrans(sqltxt)
				
				sqltxt = " select clockin, clockout from employeetime where employeetimeid = @@identity "
				set rs = dbselect(sqltxt)
				
				if rs.recordcount > 0 then
				clockOutTime = rs("clockout")
				clockInTime = rs("clockin")
				end if
				
				sqltxt = " insert into employeetimelog (logtype, employeetimeid, clockin) "
				sqltxt = sqltxt & " select 'CI', employeetimeid, clockin from employeetime "
				sqltxt = sqltxt & " where employeetimeid = @@identity "
				qryexecutewithtrans(sqltxt)
				
				dbendtrans()
			end if
		else
			if isClockInTimeValid then

      sqltxt = " select employeetimeid from employeetime where employeeid = ( select employeeid from employee where storeid = " & l_storeid  & " and employeepassword = " & dbcreateqrystring(request.form("txtEmpId")) & "  ) and  clockout is null "
			set rs = getdisconnectedrecordset(sqltxt)
			if rs.recordcount > 0 then
				employeetimeid = rs("employeetimeid")
				set rs = nothing
	
	      
	      dbstartTrans()
				
	
				
	      sqltxt = "update employeetime set clockout = convert(varchar, getdate(), 100) where employeetimeid = " & employeetimeid
				qryexecutewithtrans(sqltxt)

      			sqltxt = " select clockin, clockout from employeetime where employeetimeid = " & employeetimeid
      			set rs = dbselect(sqltxt)
      			
      			if rs.recordcount > 0 then
      				clockOutTime = rs("clockout")
      				clockInTime = rs("clockin")
      			end if
      			
				
				sqltxt = " insert into employeetimelog (logtype, employeetimeid, clockout) "
				sqltxt = sqltxt & " select 'CO', employeetimeid, clockout from employeetime "
				sqltxt = sqltxt & " where employeetimeid = " & employeetimeid
				qryexecutewithtrans(sqltxt)
				
				dbendtrans()
			else
				l_error = "You must clock in before clocking out!"
			end if
			
			end if
		end if
	end function
	
	function verifyPassword()
	dim sqltxt
	dim rsTemp
		
		sqltxt = "select * from employee where  storeid = " & l_storeid  & " and employeepassword = " & dbcreateqrystring(request.form("txtEmpId"))
		verifyPassword = 0
		set rsTemp = getDisconnectedRecordset(sqltxt)
		if rsTemp.recordcount > 0 then
			verifyPassword = 1
			logInEmployeeId = rsTemp("employeeId")
		else
			l_error = "Could not find employee with this password."
		end if
	
		rstemp.close
		set rsTemp = nothing
	end function
	
	function isClockInTimeValid()
		dim sqltxt
		dim rsTemp
		sqltxt = "select * from employeetime where employeeid = ( select employeeid from employee where storeid = " & l_storeid  & " and employeepassword = " & dbcreateqrystring(request.form("txtEmpId")) & "  ) and  convert(varchar, getdate(), 100) = convert(varchar, clockin, 100) "
		set rsTemp = getDisconnectedRecordset(sqltxt)
		isClockInTimeValid = rsTemp.recordcount = 0
		if not isClockInTimeValid then
			select case Request.Form("h_mode")
			case "ClockOut"
				l_error = l_error  & "<br>Please wait one minute before clocking out."
			case "ClockIn"
				l_error = l_error  & "<br>Please wait one minute before clocking in."
			end select
		end if
		set rsTemp = nothing
	end function
	
	
	function verifyCheckOut()
	dim sqltxt
	dim rsTemp
				
		sqltxt = "select * from employeetime  where employeeid = ( select employeeid from employee where storeid = " & l_storeid  & " and employeepassword = " & dbcreateqrystring(request.form("txtEmpId")) & "  ) and  clockout is null "
		
		verifyCheckOut = 1
		
		l_error = ""
		
		set rsTemp = getDisconnectedRecordset(sqltxt)
				
		if rsTemp.recordcount > 0 then
			verifyCheckOut = 0
			l_error = "Please clock out before clocking in."
			
		end if
	
		rstemp.close
		set rsTemp = nothing
		
	end function
%>
