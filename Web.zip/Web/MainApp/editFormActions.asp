<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/json.asp"-->

<%
	dim query, rs
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if
	
	select case lcase(request.querystring("a"))
	case "getformlist"
		response.write getFormList(session("storeid"))
	case "getform"
		response.write getForm(request.querystring("formname"))
	case "saveform"
		response.write saveForm(request.form("formname"), request.form("formlayout"))
	case "deleteform"
		response.write deleteForm(request.form("formname"))



	end select
	
	
	function getFormList(storeid)
		dim query, rs
		
		query = " select formname, type from form where [type] = 'text/html' and storeid = " & storeid
		
		set rs = getdisconnectedrecordset(query)
		
		getFormList = rsToJSON(rs, limit, start)
		
		set rs = nothing
	end function
	

	
	function getForm(formname)
		dim query, rs
		dim HelperFunctions
		dim formlayout

		query = " select formlayout from form where [type] = 'text/html' and formname = '" & formname & "'"

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
	
			set HelperFunctions = Server.CreateObject("ShahCorpComponents.HelperFunctions")
			formlayout = CStr(HelperFunctions.ASPStrConv(rs("formlayout"), 64))
	
	
			getForm = "{ "
			getForm = getForm & """recordcount"": ""1"", "
			getForm = getForm & """rows"": [{""formname"":""" & JSEncode(formname) & """,""formlayout"":""" & JSEncode(formlayout) & """}] "
			getForm = getForm & "}"
		end if

		set rs = nothing
	end function

	function deleteForm(formname)
		dim query, rs

		query = " delete from form where formname = '" & formname & "'"

		qryexecute query

		deleteForm = formResult(1, "Form deleted.")
	end function


	function saveForm(name, rtf)

		dim conn
		dim rs
		dim query
		dim result
		dim HelperFunctions

		result = 0

		set HelperFunctions = Server.CreateObject("ShahCorpComponents.HelperFunctions")
		set conn = Server.CreateObject("ADODB.Connection")
		set rs = Server.CreateObject("ADODB.Recordset")
		
		conn.Open Session("shahcorpDSN")
		
		query = "SELECT * FROM Form WHERE formName = '" & name & "' AND storeID = " & session("storeid")

		rs.Open query, conn, 3, 3

		if rs.RecordCount > 0 then
			rs.Fields("formLayout").AppendChunk = rtf & ChrB(0)
			rs.Update
			result = 1
		else
			rs.AddNew
			rs.Fields("type") = "text/html"
			rs.Fields("formName") = name
			rs.Fields("storeID") = session("storeid")
			rs.Fields("formLayout").AppendChunk = rtf & ChrB(0)
			rs.Update
			result = 1
		end if
		
		if Err.number <> 0 then 
			result = 0
			rs.Close
			conn.Close 
			set rs = nothing
			set conn = nothing
		else
			rs.Close
			conn.Close 
			set rs = nothing
			set conn = nothing
		end if


		saveForm = formResult(result, "")
	end function

	function cleanString(s)
		dim i
		dim ch
		dim result

		for i = 1 to len(s)
			ch = mid(s, i, 1)
			if asc(ch) >= 32 then
				result = result & ch
			end if
		next

		cleanString = result
	end function

	function JSEncode(s)
		s = cleanString(s)
		if not isnull(s) then
			JSEncode = s
			JSEncode = Replace(JSEncode, "\", "\\") 
			JSEncode = Replace(JSEncode, """", "\""")
			JSEncode = Replace(JSEncode, vbCr, "\r")
			JSEncode = Replace(JSEncode, vbLf, "\n")
		end if
	end function 
	
	function formResult(success, answer )
		formResult = "{ "
		formResult = formResult & "success: """ & JSEncode(success) & """, "
		formResult = formResult & "answer: """ & JSEncode(answer) & """ "
		formResult = formResult & "}"
	end function

%>