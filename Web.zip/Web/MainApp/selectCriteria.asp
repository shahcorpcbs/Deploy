<%@ Language=VBScript %>
<!--#include file="../include/querydatabase.asp" -->

<%
    dim query, rs, recSet
    dim isSubmitted
    dim criteriaID
    dim l_criteriaID

    isSubmitted = Request.QueryString("submitted")
    l_criteriaID = Request.QueryString("criteriaID")
    
	if isSubmitted then
		buildCustomerSeqCVS()
		Response.Redirect "chooseTemplate.asp"
	else
		if l_criteriaID <> "" then
			query = "select searchName, convert(varchar,msDateBegin,101) as msDateBegin, " 
			query = query & "convert(varchar,msDateEnd,101) as msDateEnd, "
			query = query & "msMoreOrLess, msValue, convert(varchar,icDateBegin,101) as icDateBegin, "
			query = query & "convert(varchar,icDateEnd,101) as icDateEnd, icMoreOrLess, icValue, eType, "
			query = query & "convert(varchar,eDateBegin,101) as eDateBegin, convert(varchar,eDateEnd,101) as eDateEnd, "
			query = query & "ciRackedOrNot, ciMoreOrLess, ciValue, convert(varchar,ciDateBegin,101) as ciDateBegin, "
			query = query & "convert(varchar,ciDateEnd,101) as ciDateEnd, rMoreOrLess, rValue, rtNumber, expired, "
			query = query & "convert(varchar,expDate,101) as expDate from marketingLettersCriteria where criteriaID = " & l_criteriaID 
			'Response.Write(query)
			set recSet = getDisconnectedRecordSet(query)
		end if	
	end if
		    
    function buildCustomerSeqCVS()
        dim  rs, query, query2
        dim criteria
      
		'Write criteria to the database
		query = "" 
        query = "update MarketingLettersCriteria set dateRan = getdate(), searchName = '" & Request.Form("sName") & "'"
        if Request.Form("msValue") <> "" and Request.Form("msDateBegin") <> "" and Request.Form("msDateEnd") <> "" then
			query = query & ", msDateBegin = convert(datetime, '" & Request.Form("msDateBegin") & "')"
			query = query & ", msDateEnd = convert(datetime, '" & Request.Form("msDateEnd") & "')"
			query = query & ", msMoreOrLess ='" & Request.Form("msMoreOrLess") & "', msValue= " & Request.Form("msValue") 
		end if
        if Request.Form("icValue") <> "" and Request.Form("icDateBegin") <> "" and Request.Form("icDateEnd") <> "" then
			query = query & ", icDateBegin = convert(datetime, '" & Request.Form("icDateBegin") & "')"
			query = query & ", icDateEnd = convert(datetime, '" & Request.Form("icDateEnd") & "')"
			query = query & ", icMoreOrLess ='" & Request.Form("icMoreOrLess") & "', icValue= " & Request.Form("icValue") 
		end if
        if Request.Form("eType") <> "" and Request.Form("eDateBegin") <> "" and Request.Form("eDateEnd") <> "" then
			query = query & ", eType = '" & Request.Form("eType") & "'"
			query = query & ", eDateBegin = convert(datetime, '" & Request.Form("eDateBegin") & "')"
			query = query & ", eDateEnd = convert(datetime, '" & Request.Form("eDateEnd") & "')"
		end if
        if Request.Form("ciValue") <> "" and Request.Form("ciDateBegin") <> "" and Request.Form("ciDateEnd") <> "" then
			query = query & ", ciDateBegin = convert(datetime, '" & Request.Form("ciDateBegin") & "')"
			query = query & ", ciDateEnd = convert(datetime, '" & Request.Form("ciDateEnd") & "')"
			query = query & ", ciRackedOrNot ='" & Request.Form("ciRackedOrNot") & "', ciMoreOrLess='" & Request.Form("ciMoreOrLess") & "', ciValue= " & Request.Form("ciValue") 
		end if
        if Request.Form("rValue") <> "" then
			query = query & ", rMoreOrLess='" & Request.Form("rMoreOrLess") & "'"
			query = query & ", rValue=" & Request.Form("rValue")
		end if				
        if Request.Form("rtNumber") <> "" then
			query = query & ", rtNumber='" & Request.Form("rtNumber") & "'"
		end if
		if Request.Form("expired") = "1" then
			query = query & ", expired='" & Request.Form("expired") & "'"
			query = query & ", expDate = convert(datetime, '" & Request.Form("expDate") & "')) "
		end if		
		query = query & " where criteriaID = " & Request.Form("critID")
		Response.Write("query: "+query)
		qryexecute query		
		
        criteria = buildCriteria()
        Response.Write("criteria:  "+criteria)

	    buildCustomerSeqCVS = ""
        
        if criteria <> "" then
            query = "delete from marketingLettersCSN"
            qryexecute query

            query = "select customersequencenumber from customer where " & criteria      
            set rs = getdisconnectedrecordset(query)

            if rs.recordcount > 0 then
                while not rs.eof
					query2 = "insert into marketingLettersCSN values(" & rs("customersequencenumber") & ")"
					qryexecute query2
                    rs.movenext
                wend
            end if
 
            set rs = nothing
            
        end if
    end function

    function Append(pre, post, divider)
        if post <> "" then
            if pre <> "" then
                Append = pre & divider & post
            else
                Append = pre & post
            end if         
        else
            Append = pre
        end if
    end function
    
    function buildCriteria()
        buildCriteria = ""
        buildCriteria = Append(buildCriteria, cri_ms(), " and ")
        buildCriteria = Append(buildCriteria, cri_ic(), " and ")
        buildCriteria = Append(buildCriteria, cri_e(), " and ")
        buildCriteria = Append(buildCriteria, cri_r(), " and ")
        buildCriteria = Append(buildCriteria, cri_ci(), " and ")
        buildCriteria = Append(buildCriteria, cri_rt(), " and ")
        buildCriteria = Append(buildCriteria, cri_exp(), " and ")
    end function
    
    function cri_ms()
        if Request.Form("msValue") <> "" and Request.Form("msDateBegin") <> "" and Request.Form("msDateEnd") <> "" then
            cri_ms = " dbo.getCustomerSales(customersequencenumber, "
            cri_ms = cri_ms & "'" & Request.Form("msDateBegin") & "', "
            cri_ms = cri_ms & "'" & Request.Form("msDateEnd") & "') "
            cri_ms = cri_ms & Request.Form("msMoreOrLess") & " "
            cri_ms = cri_ms & Request.Form("msValue") & " "
        end if
    end function
    
    function cri_ic()
        if Request.Form("icValue") <> "" and Request.Form("icDateBegin") <> "" and Request.Form("icDateEnd") <> "" then
            cri_ic = " dbo.getCustomerVisits(customersequencenumber, "
            cri_ic = cri_ic & "'" & Request.Form("icDateBegin") & "', "
            cri_ic = cri_ic & "'" & Request.Form("icDateEnd") & "') "
            cri_ic = cri_ic & Request.Form("icMoreOrLess") & " "
            cri_ic = cri_ic & Request.Form("icValue") & " "
        end if
    end function
    
    function cri_ci()
        if Request.Form("ciValue") <> "" and Request.Form("ciDateBegin") <> "" and Request.Form("ciDateEnd") <> "" then
            cri_ci = " dbo.getCustomerOpenInvoices(customersequencenumber, "
            cri_ci = cri_ci & "'" & Request.Form("ciRackedOrNot") & "', "
            cri_ci = cri_ci & "'" & Request.Form("ciDateBegin") & "', "
            cri_ci = cri_ci & "'" & Request.Form("ciDateEnd") & "') "
            cri_ci = cri_ci & Request.Form("ciMoreOrLess") & " "
            cri_ci = cri_ci & Request.Form("ciValue") & " "
        end if
    end function
    
    function cri_e()
        if Request.Form("eType") <> "" and Request.Form("eDateBegin") <> "" and Request.Form("eDateEnd") <> "" then
            cri_e = " " & Request.Form("eType") & " between "
            cri_e = cri_e & "convert(datetime, '" & Request.Form("eDateBegin") & "') and "
            cri_e = cri_e & "convert(datetime, '" & Request.Form("eDateEnd") & "') "
        end if
    end function
    
    function cri_rt()
        if Request.Form("rtNumber") = "" then
        
        elseif Request.Form("rtNumber") = "all" then
            cri_rt = " routeNumber > 0 "
        elseif Request.Form("rtNumber") >= 0 then
            cri_rt = " routeNumber = " & Request.Form("rtNumber") & " "
        end if
    end function
    
    function cri_r()
        if Request.Form("rValue") <> "" then
            cri_r = "dbo.getCustomerRating(customersequencenumber) * 100.00 "
            cri_r = cri_r & Request.Form("rMoreOrLess") & " "
            cri_r = cri_r & Request.Form("rValue") & " "
        end if
    end function
    
    function cri_exp()
		if Request.Form("expired") = "1" then
			cri_exp ="dbo.getCustomerCCExpiryDate(customersequencenumber) < "
            cri_exp = cri_exp & "convert(datetime, '" & Request.Form("expDate") & "') "
			
		end if
	end function
			
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Reuse or Update Marketing List Criteria</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">

<style>
<!--

.txtNumber {
   width:50px;
   text-align:right;
}

.txtDate {
   width:76px;
   text-align:center;
}
-->
</style>

</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">

	function selectDate(element) {

		show_calendar("updateMarketingCriteria." + element.name);
	}
	
	function submitForm() {
		if (validateForm() == true) {		
			document.updateMarketingCriteria.action = "?submitted=true";
			document.updateMarketingCriteria.submit();
		}	
	}   

	function isSpace(obj) {
		if(obj.value.indexOf(' ') != -1){
			cbsAlert("Name cannot contain a space",cbsExclamation,"Enter search name (no spaces)");
			obj.focus();
		}
	}

	function validateForm() {
		if (trim(document.updateMarketingCriteria.sName.value).length < 1){
			cbsAlert("Please enter a name to save search",cbsExclamation,"Enter search name");
			document.updateMarketingCriteria.sName.focus();
			return false;
		}
		if (trim(document.updateMarketingCriteria.rValue.value).length > 0){
			if((document.updateMarketingCriteria.rValue.value > 100) || (document.updateMarketingCriteria.rValue.value < 1)){
				cbsAlert("Please enter a value between 1 and 100",cbsExclamation,"Enter rating value");
				document.updateMarketingCriteria.rValue.focus();
				return false;
			}
			return true;
		}	 
		return true;
	}
	
	function cancelForm() {
	    document.updateMarketingCriteria.action = "managerMenu.asp";
	    document.updateMarketingCriteria.submit();
	}   
    
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/localprinter.inc" -->
<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">&nbsp;Reuse or Update Marketing List Criteria</B>
<FORM id="updateMarketingCriteria" name="updateMarketingCriteria" action="" method="Post">
	<INPUT type=hidden name=isSubmitted value=<%=isSubmitted%>>
	<INPUT type=hidden name=critID value=<%=l_criteriaID%>>
<center>
<table class=optTable cellpadding=3 style="display:block">

<tr>
    <td><b>Money Spent</b></td>

    <td>
        <select name="msMoreOrLess">
        <% if trim(recSet("msMoreOrLess")) = "<" then %>
            <option value=">=" >More</option>
            <option value="<" selected>Less</option>
        <% else %>    
            <option value=">=" selected>More</option>
            <option value="<">Less</option>
        <% end if %>    
        </select>
        than
        <input name="msValue" class=txtNumber value=<%=recSet("msValue")%>></input>
        dollars
    </td>
    
    <td>
        between <input name="msDateBegin" onclick="selectDate(this);" class=txtDate value=<%=recSet("msDateBegin")%>></input> and <input name="msDateEnd" onclick="selectDate(this);" class=txtDate value=<%=recSet("msDateEnd")%>></input>
    </td>
</tr>

<tr>
    <td><b>Invoices Out</b></td>
    <td>
        <select name="icMoreOrLess">
        <% if trim(recSet("icMoreOrLess")) = "<" then %>
            <option value=">=" >More</option>
            <option value="<" selected>Less</option>
        <% else %>    
            <option value=">=" selected>More</option>
            <option value="<">Less</option>
        <% end if %>    
        </select>
        than
        <input name="icValue" class=txtNumber value=<%=recSet("icValue")%>></input>
    </td>
    <td>
        between <input name="icDateBegin" onclick="selectDate(this);" class=txtDate value=<%=recSet("icDateBegin")%>></input> and <input name="icDateEnd" onclick="selectDate(this);" class=txtDate value=<%=recSet("icDateEnd")%>></input>
    </td>
</tr>

<tr>
    <td><b>Event</b></td>

    <td>
        <select name="eType">
        <% if isnull(recSet("eType")) then %>
            <option value="" selected ></option>
            <option value="birthdate">Birthday</option>
            <option value="createddate">First Visit</option>
            <option value="lastvisited">Last Visit</option>
		<% elseif recSet("eType") = "birthdate" then %>
            <option value=""></option>
            <option value="birthdate" selected >Birthday</option>
            <option value="createddate">First Visit</option>
            <option value="lastvisited">Last Visit</option>
		<% elseif recSet("eType") = "createddate" then %>
            <option value=""></option>
            <option value="birthdate">Birthday</option>
            <option value="createddate" selected >First Visit</option>
            <option value="lastvisited">Last Visit</option>
		<% elseif recSet("eType") = "lastvisited" then %>
            <option value=""></option>
            <option value="birthdate">Birthday</option>
            <option value="createddate">First Visit</option>
            <option value="lastvisited" selected >Last Visit</option>
        <% end if %>    
        </select>
        occurred
    </td>
    
    <td>
        between <input name="eDateBegin" onclick="selectDate(this);" class=txtDate value=<%=recSet("eDateBegin")%>></input> and <input name="eDateEnd" onclick="selectDate(this);" class=txtDate value=<%=recSet("eDateEnd")%>></input>
    </td>
</tr>

<tr>
    <td><b>Open Invoices</b></td>

    <td>
        <select name="ciRackedOrNot">
        <% if recSet("ciRackedOrNot") = "-1" then %>
            <option value="-1" selected>All</option>
            <option value="1">Racked</option>
            <option value="0">Not Racked</option>
		<% elseif recSet("ciRackedOrNot") = "1" then %>
            <option value="-1">All</option>
            <option value="1" selected>Racked</option>
            <option value="0">Not Racked</option>
		<% elseif recSet("ciRackedOrNot") = "0" then %>
            <option value="-1">All</option>
            <option value="1">Racked</option>
            <option value="0" selected>Not Racked</option>
		<% end if %> 
        </select>
        due
        <select name="ciMoreOrLess">
        <% if trim(recSet("ciMoreOrLess")) = "<" then %>
            <option value=">=" >More</option>
            <option value="<" selected>Less</option>
        <% else %>    
            <option value=">=" selected>More</option>
            <option value="<">Less</option>
        <% end if %>   
        </select>
        than
        <input name="ciValue" class=txtNumber value=<%=recSet("ciValue")%>></input>
    </td>
    
    <td>
        between <input name="ciDateBegin" onclick="selectDate(this);" class=txtDate value=<%=recSet("ciDateBegin")%>></input> and <input name="ciDateEnd" onclick="selectDate(this);" class=txtDate value=<%=recSet("ciDateEnd")%>></input>
    </td>
</tr>

<tr>
    <td><b>Rating</b></td>
    
    <td>
        <select name="rMoreOrLess">
        <% if trim(recSet("rMoreOrLess")) = "<" then %>
            <option value=">=" >More</option>
            <option value="<" selected>Less</option>
        <% else %>    
            <option value=">=" selected>More</option>
            <option value="<">Less</option>
        <% end if %>
        </select>
        than
        <input name="rValue" class=txtNumber value=<%=recSet("rValue")%>></input>
    </td>
</tr>

<tr>
    <td><b>Route</b></td>
    
    <td>
        <select name="rtNumber">
        <% if recSet("rtNumber") >= 0 then %>   
            <option value="" ></option>
            <option value="all">All</option>
			<%
			    query = "select routenumber, name from route where storeid = " & session("storeid")
			    set rs = getdisconnectedrecordset(query)
			    
			    while not(rs.eof or rs.bof)
			%>
			    <option value="<%=rs("routeNumber")%>"
			    	<%if trim(recSet("rtNumber")) = trim(rs("routeNumber")) then %>
						selected 
					<% end if %>><%=rs("name")%>
				</option>
			<%
			    rs.movenext
			    wend
			    set rs = nothing
			%>
        <% elseif recSet("rtNumber") = "all" then %>
            <option value="" ></option>
            <option value="all" selected>All</option>
			<%
			    query = "select routenumber, name from route where storeid = " & session("storeid")
			    set rs = getdisconnectedrecordset(query)
			    
			    while not(rs.eof or rs.bof)
			%>
			    <option value="<%=rs("routeNumber")%>"><%=rs("name")%></option>
			<%
			    rs.movenext
			    wend
			    set rs = nothing
			%>
        <% else %>
            <option value="" selected></option>
            <option value="all">All</option>
			<%
			    query = "select routenumber, name from route where storeid = " & session("storeid")
			    set rs = getdisconnectedrecordset(query)
			    
			    while not(rs.eof or rs.bof)
			%>
			    <option value="<%=rs("routeNumber")%>"><%=rs("name")%></option>
			<%
			    rs.movenext
			    wend
			    set rs = nothing
			%>
		<% end if %>
        </select>
    </td>
</tr>

<tr>
    <td><b>Expired Credit Cards</b></td>
    
    <td>
        <select name="expired">
        <% if isnull(recSet("expired")) then %>
            <option value="" selected></option>
            <option value="1">Expired</option>
        <% else %>    
            <option value=""></option>
            <option value="1" selected>Expired</option>
        <% end if %>    
        </select>
        before <input name="expDate" onclick="selectDate(this);" class=txtDate value=<%=recSet("expDate")%>></input>        
    </td>
</tr>

<tr>
    <td><b>Save Search as (Name)</b></td>
    
    <td>
        <input name="sName" onKeyUp="isSpace(this)" value=<%=recSet("searchName")%>></input>        
    </td>
</tr>


<tr>
	<td colspan=3 align="center">
		<input type="button" value="Cancel" onclick="cancelForm();" style="width:100px;height:50px;margin-top:40px;"></input>
		<input type="button" value="Ok" onclick="submitForm();" style="width:100px;height:50px;margin-top:40px;"></input>
	</td>
</tr>

</table>

</center>

</FORM>   
</BODY>
</HTML>