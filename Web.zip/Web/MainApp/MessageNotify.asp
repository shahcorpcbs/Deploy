<%@ Language=VBScript %>
<!--#include file="../include/QueryDatabase.asp"-->
<%
	dim query, rs
	dim accountname
	dim accountid
	dim storeguid
	dim storename
	
	acccountname = request.querystring("accountname")
	accountid = getMessageAccountID(acccountname)
	storeguid = request.querystring("storeguid")
	storename = request.querystring("storename")

	if acccountname <> "" then
		updateMessageAccountStore
	end if
	
	function getMessageAccountID(username)
		dim query, rs

		query = "select id from messageaccount where lower(username) = '" & lcase(username) & "'"
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getMessageAccountID = rs("id")
		else
			getMessageAccountID = ""
		end if

		set rs = nothing
	end function
	
	function getMessageServerURL()
		dim query, rs
		
		query = "select isnull(messageServerURL, '') as messageServerURL from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getMessageServerURL = trim(rs("messageServerURL"))
		
		set rs = nothing
	end function
	
	function updateMessageAccountStore()
		dim query, rs
		dim doupdate
		
		query = "select count(*) as cnt from messageaccountstore where messageaccountid = " & accountid & " and storeguid = '" & storeguid & "'"
		set rs = getdisconnectedrecordset(query)
		
		doupdate = rs("cnt") > 0
		set rs = nothing
		
		if doupdate then
			query = "update messageaccountstore set datelastseen = getdate() where messageaccountid = " & accountid & " and storeguid = '" & storeguid & "'"
			qryexecute query
			query = "update messageaccountstore set storename = '" & storename & "' where storeguid = '" & storeguid & "'"
		else
			query = "insert into messageaccountstore (messageaccountid, storeguid, storename)"
			query = query & " values ("
			query = query & accountid
			query = query & ", " & "'" & storeguid & "'"
			query = query & ", " & "'" & storename & "'"
			query = query & ")"
		end if
		
		qryexecute query
	end function
%>
<HTML>
<HEAD>
<SCRIPT language="javascript" type="text/javascript">
	var w1, w2, w3, w4;
	
	function viewMessage(id) {
		if(w1) w1.close();
		w1 = window.open("<%=getMessageServerURL()%>/MainApp/MessageView.asp?messageid=" + id, "MessageView", "status=no,scrollbars=no,width=600,height=600,dependent=yes");
	}
	
	function composeMessage() {
		if(w2) w2.close();
		w2 = window.open("<%=getMessageServerURL()%>/MainApp/MessageCompose.asp?fromaccount=<%=acccountname%>", "ComposeMessage", "status=no,scrollbars=no,width=600,height=600,dependent=yes");
	}
	
	function viewHistory() {
		if(w3) w3.close();
		w3 = window.open("<%=getMessageServerURL()%>/MainApp/MessageHistory.asp?accountname=<%=acccountname%>", "ViewHistory", "status=no,scrollbars=yes,width=900,height=600,dependent=yes");
	}
	
	function createTask() {
		if(w4) w4.close();
		w4 = window.open("<%=getMessageServerURL()%>/MainApp/createtask.asp?messageusername=<%=acccountname%>", "CreateTask", "status=no,scrollbars=no,width=600,height=600,dependent=yes");
	}
	
	function jumpToCustomerManagement(storeguid, customerseq, taskid) {
		parent.jumpToCustomerManagement(storeguid, customerseq, taskid);
	}

	function closePopups() {
		if(w1) w1.close();
		if(w2) w2.close();
		if(w3) w3.close();
		if(w4) w4.close();
	}
	
</SCRIPT>
</HEAD>
<BODY STYLE="color:#FFFFFF;margin:0;padding:0;background:#262771" onunload="closePopups();" onclose="closePopups();">



<%if accountid <> "" then%>
<%

	function getTaskCount()
		dim query, rs
		
		query = "select count(*) as cnt from "
		query = query & " employeetask inner join task on "
		query = query & " employeetask.taskid = task.id "
		query = query & " where employeetask.employeemessageid = '" & acccountname & "'"
		query = query & " and task.dateclosed is null"
		
		set rs = getdisconnectedrecordset(query)
		getTaskCount = rs("cnt")
		
		set rs = nothing
	end function
	
	query = "select messageitem.*, messageaccount.username as fromaccountname from messageitem inner join messageaccount on messageitem.fromaccount = messageaccount.id where toaccount = " & accountid & " and datereceived is null order by datesent desc"
	set rs = getdisconnectedrecordset(query)
%>

<table cellspacing="1" cellpadding="" border="0">

	<tr valign="top">
		<td onclick="viewHistory()" align="center">
			<div style="height:37px;width:50px;border:1px outset;cursor:pointer">
				<div style="font-size:10">Tasks</div>
				<div style="font-size:21"><%=getTaskCount()%></div>
			</div>
		</td>

		<td onclick="createTask()" align="center" >
			<div style="height:37px;width:50px;color:yellow;border:1px outset;cursor:pointer;padding-top:5px">
				<div style="font-size:10">New</div>
				<div style="font-size:10">Task</div>
			</div>
		</td>

		<td style="width:16px"></td>

		<td onclick="viewHistory()" align="center">
			<div style="height:37px;width:50px;border:1px outset;cursor:pointer">
				<div style="font-size:10">Messages</div>
				<div style="font-size:21"><%=rs.recordcount%></div>
			</div>
		</td>

		<td onclick="composeMessage()" align="center">
			<div style="height:37px;width:50px;color:yellow;border:1px outset;cursor:pointer;padding-top:5px"">
				<div style="font-size:10">New</div>
				<div style="font-size:10">Message</div>
			</div>
		</td>
				
		<td style="width:16px"></td>
		
		<td>
		<%
			dim counter
			counter = 0
			while counter < 3 and  not (rs.eof or rs.bof)
		
				response.write "<a style=""font-size:10;color:white"" href=""javascript:viewMessage(" & rs("id") & ");""> " & rs("subjecttext") & " (" & rs("fromaccountname") & ")</a><br />  "
				rs.movenext
				counter = counter + 1
			wend
		%>
		</td>
	</tr>
	
</table>

<%end if%>

</BODY>
</HTML>
