<%@ Language=VBScript %>
<!--#include file="../include/QueryDatabase.asp"-->

<%
	dim query, rs
	
	query = " delete from clientterminal where remoteaddr = '" & _
			Request.ServerVariables("REMOTE_ADDR") & "'"

			
	qryexecute query
	
	Session.Abandon
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">

<SCRIPT Language="Javascript">
	function CloseWindow() {
		setTimeout("window.close()", 500);
	}
</SCRIPT>
</HEAD>
<BODY onLoad="javascript:CloseWindow();">

<CENTER><H1>Please wait while exiting the application...</H1></CENTER>
<CENTER><H1><INPUT type="button" onclick="window.close()" value="Close Window" /></H1></CENTER>
</BODY>
</HTML>
