<%@ Language=VBScript %>
<%option explicit%>

<!-- #include file="../include/miscSetUpObject.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/modReportConstants.asp" -->
<!-- #include file="CheckSessionExpiry.asp" -->


<%
	'*******************************************************************
	'Name   : creditCardBatchSubmitReport.asp
    'Author : James Johnston
    'Created: 10Feb2004
    'Modification History
    '===================================================================
    ' Date			Changed By		Change Log
    ' ------------------------------------------------------------------
    ' 10Feb2004		Johnston		Original version
	'*******************************************************************
%>


<%
dim ObjMiscSetUp
dim storeID
dim empID
dim xChargePath
dim terminalId
dim sessionName
dim apCode
dim acctNum
dim expireDate
dim custID
dim amtPaid
dim ccZip
dim ccAddress
dim approvedHTML
dim deniedHTML
dim	payType
dim	transNum
dim fileName
dim approvedTotal
dim deniedTotal


approvedTotal = 0
deniedTotal = 0


if Not IsObject(Session("miscSetUp")) then
	initializeMiscSetUp
end if
set ObjMiscSetUp = Session("miscSetUp")
storeID = Session("storeID")
empID = Session("employeeID")
xChargePath = ObjMiscSetUp.Item("XChargePath")
xChargePath = replace(xChargePath,"\","\\")
terminalId = Session("terminalID")
sessionName = Session.SessionID
payType = "Credit Card"
transNum = "XXXXX"
fileName = Request.Form("fileName")
fileName = replace(fileName, "X:", "C:")
fileName = replace(fileName, "x:", "c:")

dim HT_TD_AUTO_WIDTH_LEFT
HT_TD_AUTO_WIDTH_LEFT = "<TD VALIGN=TOP ALIGN=LEFT STYLE=""PADDING-LEFT:4px;"">"
dim HT_TD_AUTO_WIDTH_RIGHT
HT_TD_AUTO_WIDTH_RIGHT = "<TD VALIGN=TOP ALIGN=RIGHT  STYLE=""PADDING-RIGHT:4px;"">"
dim HT_STD_FONT
HT_STD_FONT = "<FONT FACE=""Arial"" SIZE=2>"


setupHTML()

processDataFile()

closeHTML()

'removeOldFiles()



sub setupHTML()


	
    'APPROVED TABLE
    approvedHTML = "<P><TABLE width=""98%"" align=center cellspacing=""2"" cellpadding=""0"" border=""0"" style=""WIDTH: 98%"">"
        approvedHTML = approvedHTML & "<TR>"
        approvedHTML = approvedHTML & "<TD COLSPAN=0 VALIGN=BOTTOM><FONT FACE=""Arial"" SIZE=3><B>Approved Payments</B></FONT></TD>"
        approvedHTML = approvedHTML & "</TR>"
    approvedHTML = approvedHTML & "</TABLE><P>"

	approvedHTML = approvedHTML & "<TABLE NAME=""ccApproved"" ID=""ccApproved"" width=""98%"" align=center cellspacing=""2"" cellpadding=""0"" border=""1"" style=""WIDTH: 98%"">"
	
	' Write header before the first record.
	approvedHTML = approvedHTML & "<TR bgcolor = ""#BCD4D8"">"
                
		approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>Approval Code</B></FONT></TD>"
		approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>Customer Name</B></FONT></TD>"
		approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>ID</B></FONT></TD>"
		approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>Address</B></FONT></TD>"
		approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>City</B></FONT></TD>"
		approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>State</B></FONT></TD>"
		approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>Zip</B></FONT></TD>"
		approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>Phone</B></FONT></TD>"
		approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_RIGHT & HT_STD_FONT & "<B>Amount</B></FONT></TD>"
                
	approvedHTML = approvedHTML & "</TR>"
	
	

	'DENIED TABLE
    deniedHTML = "<P><TABLE width=""98%"" align=center cellspacing=""2"" cellpadding=""0"" border=""0"" style=""WIDTH: 98%"">"
        deniedHTML = deniedHTML & "<TR>"
        deniedHTML = deniedHTML & "<TD COLSPAN=0 VALIGN=BOTTOM><FONT FACE=""Arial"" SIZE=3><B>Denied Payments</B></FONT></TD>"
        deniedHTML = deniedHTML & "</TR>"
    deniedHTML = deniedHTML & "</TABLE><P>"

	deniedHTML = deniedHTML & "<TABLE NAME=""ccDenied"" ID=""ccDenied"" width=""98%"" align=center cellspacing=""2"" cellpadding=""0"" border=""1"" style=""WIDTH: 98%"">"
	
	' Write header before the first record.
	deniedHTML = deniedHTML & "<TR bgcolor = ""#BCD4D8"">"
                
		deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>Reason for Denial</B></FONT></TD>"
		deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>Customer Name</B></FONT></TD>"
		deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>ID</B></FONT></TD>"
		deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>Address</B></FONT></TD>"
		deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>City</B></FONT></TD>"
		deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>State</B></FONT></TD>"
		deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>Zip</B></FONT></TD>"
		deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & HT_STD_FONT & "<B>Phone</B></FONT></TD>"
		deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_RIGHT & HT_STD_FONT & "<B>Amount</B></FONT></TD>"
                
	deniedHTML = deniedHTML & "</TR>"

end sub


sub closeHTML()

	deniedHTML = deniedHTML & "<TR>"
			    
	deniedHTML = deniedHTML & "<TD colspan=""8""><B>Total</B></TD>"
	deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_RIGHT & deniedTotal & "</FONT></TD>"
			    
	deniedHTML = deniedHTML & "</TR>"
	
	deniedHTML = deniedHTML & "</TABLE><BR><HR><BR>"
	
	
	approvedHTML = approvedHTML & "<TR>"
			    
	approvedHTML = approvedHTML & "<TD colspan=""8""><B>Total</B></TD>"
	approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_RIGHT & approvedTotal & "</FONT></TD>"
			    
	approvedHTML = approvedHTML & "</TR>"	
			    
	approvedHTML = approvedHTML & "</TABLE><BR>"
	
end sub


sub processDataFile()

	openDataFile()
	
	
end sub


sub openDataFile()

	'OPEN data file
	Dim fsoDataFile
	dim tsDataText
	dim dataFile
	dim dataLine
	dim splitDataLine
	dim ansData
	dim trimApCode
	dim reqData
	dim splitAnsLine
	dim splitReqLine
	Dim objRs
	Dim strSQL
	dim custName
	dim custTableID
	dim custAddress1
	dim custAddress2
	dim custAddress3
	dim custCity
	dim custState
	dim custZip
	dim custPhone
	dim custAddress
	dim ccTypeID

	
	dataFile = Request.Form("fileName") + ".scb"
	dataFile = replace(dataFile, "X:", "C:")
	dataFile = replace(dataFile, "x:", "c:")

	Set fsoDataFile = CreateObject("Scripting.FileSystemObject")
	Set tsDataText = fsoDataFile.OpenTextFile(dataFile, 1)
	
	
	'Loop through file
	while tsDataText.AtEndOfStream <> true
		
		trimApCode = ""
		apCode = ""
		acctNum = ""
		expireDate = ""
		custID = ""
		amtPaid = ""
		ccZip = ""
		ccAddress = ""
		ccTypeID = ""		
		
		'read line
		dataLine = tsDataText.ReadLine
		dataLine = replace(dataLine,chr(34),"")

		'split line into data pieces, save to variables
		splitDataLine = Split(dataLine,"?")
		if ubound(splitDataLine) <> -1 then
			ansData = splitDataLine(0)	'Get returned message
				splitAnsLine = Split(splitDataLine(0),",")
				apCode = splitAnsLine(1)
				
			reqData = splitDataLine(1)
				splitReqLine = Split(splitDataLine(1),",")
				custID = splitReqLine(3)
				acctNum = splitReqLine(4)
				expireDate = splitReqLine(5)
				amtPaid = splitReqLine(6)
				ccZip = splitReqLine(7)
				ccAddress = splitReqLine(8)
				
			'Retrieve cust name and ID
			strSQL = "select customerID, customerName, billingAddress1," _
				& " billingAddress2, billingAddress3," _
				& " billingCity, billingState, billingZipCode," _
				& " dbo.formatPhone(MainAreaCode, MainPhone) as 'customerPhone'," _ 
				& " creditCardTypeID" _
				& " from CUSTOMER where" _
				& " customerSequenceNumber = " & custID
				
			Set objRs = GetDisconnectedRecordset(strSQL)
			If objRs.RecordCount > 0 Then
				custName = objRs("customerName").Value
				custTableID = objRs("customerID").Value
				custAddress1 = objRs("billingAddress1").Value
				custAddress2 = objRs("billingAddress2").Value
				custAddress3 = objRs("billingAddress3").Value
				custCity = objRs("billingCity").Value
				if isnull(custCity) then custCity = "&nbsp;"
				custState = objRs("billingState").Value
				if isnull(custState) then custState = "&nbsp;"
				custZip = objRs("billingZipCode").Value
				if isnull(custZip) then custZip = "&nbsp;"
				custPhone = objRs("customerPhone").Value
				if not isnull(custAddress1) then
					custAddress = custAddress1
					if not isnull(custAddress2) then
						custAddress = custAddress & ", " & custAddress2
						if not isnull(custAddress3) then
							custAddress = custAddress & ", " & custAddress3
						end if
					end if
				else
					custAddress = "&nbsp;"
				end if
				ccTypeID = objRs("creditCardTypeID").Value
			end if

			'Update database if approved
			if left(apCode,1) = "Y" then
			
				trimApCode = mid(apCode,2,len(apCode))
				
				'update DB
				updateDatabase trimApCode, ccTypeID
				
				
				'Format for APPROVED TABLE
				
				approvedHTML = approvedHTML & "<TR>"
			    
			    approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & trimApCode & "</FONT></TD>"
			    approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & custName & "</FONT></TD>"
			    approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & custTableID & "</FONT></TD>"
			    approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & custAddress & "</FONT></TD>"
			    approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & custCity & "</FONT></TD>"
			    approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & custState & "</FONT></TD>"
			    approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & custZip & "</FONT></TD>"
			    approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_LEFT & custPhone & "</FONT></TD>"
			    approvedHTML = approvedHTML & HT_TD_AUTO_WIDTH_RIGHT & amtPaid & "</FONT></TD>"
			    
			    approvedHTML = approvedHTML & "</TR>"			
				
				approvedTotal = approvedTotal + amtPaid

			else
				trimApCode = mid(apCode,6,len(apCode)-4)
				'move onto formatting report
				'Format for DENIED TABLE
				deniedHTML = deniedHTML & "<TR>"
			    
			    deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & trimApCode & "</FONT></TD>"
			    deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & custName & "</FONT></TD>"
			    deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & custTableID & "</FONT></TD>"
			    deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & custAddress & "</FONT></TD>"
			    deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & custCity & "</FONT></TD>"
			    deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & custState & "</FONT></TD>"
			    deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & custZip & "</FONT></TD>"
			    deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_LEFT & custPhone & "</FONT></TD>"
			    deniedHTML = deniedHTML & HT_TD_AUTO_WIDTH_RIGHT & amtPaid & "</FONT></TD>"
			    
			    deniedHTML = deniedHTML & "</TR>"
			    
			    deniedTotal = deniedTotal + amtPaid
			    				
			end if
		end if		
		
	
	wend

	
	
	'CLOSE file
	tsDataText.Close


end sub



function updateDatabase(trimApCode,ccTypeID)
	
	dim sqltxt
	dim receipt
	
	receipt = null

	sqltxt = ""
		
	sqltxt = "execute dbo.InsertPayment " & session("storeid")_
			& ", " & session("terminalid") _
			& ", " & session("employeeid") _
			& ", " & dbcreateqrystring(custID) _
			& ", " & dbcreateqrystring(payType) _
			& ", " & amtPaid _
			& ", " & dbcreateqrystring(acctNum) _
			& ", " & dbcreateqrystring(trimApCode)_
			& ", " & dbcreateqrystring(transNum)_
			& ", " & dbcreateqrystring(ccTypeID)_
			& ", " & dbcreateqrystring(expireDate)_								
			& ", " & dbcreateqrystring(receipt)
		
	dbstartTrans()

	qryexecutewithtrans(sqltxt)
		
	dbendtrans()

					
end function


sub removeOldFiles()
	
	dim fsoRemove, newName
		  
	newName = fileName + ".scb"
		  
	set fsoRemove = CreateObject("Scripting.FileSystemObject")
	
	if(fsoRemove.FileExists(newName)) then
		fsoRemove.DeleteFile(newName)
	end if

  	  
end sub


%>

<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Credit Card Batch Report</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript">

	function cancelForm()
	{
		document.creditCardBatchReport.action ="accountMgmt.asp";
		document.creditCardBatchReport.submit();
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/bettergui.inc" -->


<FORM ID="creditCardBatchReport" name="creditCardBatchReport" action="creditCardBatchSubmitReport.asp" METHOD=post>

<P>
<TABLE width="98%" align=center cellspacing="2" cellpadding="0" border="0" style="WIDTH: 98%">
	<TR>
		<TD COLSPAN=0 VALIGN=BOTTOM><FONT FACE="Arial" SIZE=3><B>Credit Card Batch Process Report</B></FONT></TD>
		<TD COLSPAN=0 VALIGN=BOTTOM ALIGN=RIGHT><FONT FACE="Arial" SIZE=2><B>Report Date: <%=FormatDateTime(Now(), vbShortDate) & " " & FormatDateTime(Now(), vbLongTime)%></B></FONT></TD>
	</TR>
</TABLE>
<BR><BR>
<%= deniedHTML%>
<%= approvedHTML%>


<BR>
<BR>
<CENTER>
		<TR><P><BR></TR>
		<TR><P><BR></TR>
		<TR><P><BR></TR>
		<TR><P><BR></TR>
		<BUTTON class=std id=Print name=Print style="width:100px;height:50px;font-size:12px" title="Print Report" onClick="focus();print();">Print</button>
		<TR><P><BR></TR>
		<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button style="BACKGROUND-IMAGE: url(../images/Cancel.gif)" onClick="cancelForm()" >

</CENTER>
</FORM>

</BODY>
</HTML>
