<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim custRs
	dim routeRef
	dim customerSeq
	dim customerPrimaryRoute
	dim addressUpdated
		
	dim deliveryId
	dim deliveryNotes
	dim deliveryAddress
	dim deliveryDays(7)
	dim deliveryRoute
	dim deliveryPaymentType
	dim deliveryPhone
	dim accountType
	
	dim addressInDelivery
	
	
	dim dateStart
	dim dateEnd
	
	dim stopOrder
	dim routeNumber

	dim mapAddress
	dim mapPointEnabled
	dim addressMapped

	deliveryPaymentType = request.form("deliveryPaymentType")

	mapPointEnabled = getMapPointEnabled()
	
	dateStart = request.form("dateStart")
	dateEnd = request.form("dateEnd")
	
	mapAddress = Request.Form("mapAddress")

	if Request.QueryString("customerSeq") <> "" then
		customerSeq = Request.QueryString("customerSeq")
	elseif Request.Form("customerSeq") <> "" then
		customerSeq = Request.Form("customerSeq")
	else
		customerSeq = session("customersequencenumber")
	end if

	deliveryId = getReqVar("deliveryId")

	if Request.QueryString("routeRef") <> "" then
		routeRef = Request.QueryString("routeRef")
	else
		routeRef = Request.Form("routeRef")
	end if

	deliveryRoute = getDeliveryRoute(deliveryID)
	


	customerPrimaryRoute = getCustomerPrimaryRoute(customerSeq)

	select case lcase(Request.QueryString("userAction"))
	case "submit"
	
		if deliveryId = "" then
			deliveryId = createDelivery()
		end if

		saveForm

		goToRef false, mapPointEnabled
	case "cancel"
		goToRef true, mapPointEnabled
	end select


	if deliveryId <> "" then
	  loadDeliveryValues deliveryId
	else
	  loadDeliveryDefaults
	end if
		
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function

	
	function getDeliveryRoute(deliveryID)
		dim query, rs

		query = " select routeid from customerdelivery where id = " & deliveryID

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			getDeliveryRoute = rs("routeid")
		end if

		set rs = nothing

	end function

  function packRouteStops(routeNumber)
    dim query
    
    query = "exec dbo.packRouteStops " & routeNumber


    qryexecute query
  end function

	function isAddressInDelivery(deliveryId)
		dim query, rs
		
		
		if deliveryId <> "" then
			query = " select ticket.ticketnumber from ticket "
			query = query & " inner join deliveryitem on "
			query = query & " ticket.ticketnumber = deliveryitem.ticketnumber "
			query = query & " inner join deliverystop on "
			query = query & " deliveryitem.deliverystopid = deliverystop.deliverystopid "
			query = query & " where ticket.ticketstatus in ('AC', 'OD') "
			query = query & " and deliveryitem.status >= 0 "
			query = query & " and deliverystop.deliveryid = " & deliveryId
			
			set rs = getdisconnectedrecordset(query)
			
			isAddressInDelivery = (rs.recordcount > 0)
			
			set rs = nothing
		else
			isAddressInDelivery = 0
		end if
	end function


	sub goToRef(cancel, mapPointEnabled)
		dim query, rs

		if cancel then
			if routeRef <> "" then
				Response.Redirect "/setup/routesetup.asp?routeNumber=" & routeRef
			else
				Response.Redirect "/mainapp/customerdeliverylist.asp"
			end if
		else
			if not addressMapped and mapAddress then
				response.redirect "/mainapp/validateDeliveryAddress.asp?customerDeliveryID=" & deliveryId & "&routeRef=" & routeRef & "&customerSeq=" & customerSeq
			else
				if routeRef <> "" then
					Response.Redirect "/setup/routesetup.asp?routeNumber=" & routeRef
				else
					Response.Redirect "/mainapp/customerdeliverylist.asp"
				end if
			end if
		end if
	end sub

	function getMapPointEnabled()
		dim query, rs
		
		query = " select enableMapPoint from miscsetup where enableMapPoint = 1 and storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
	
		getMapPointEnabled = rs.recordcount > 0
		
		set rs = nothing
	end function
	
	function isAddressValidated(deliveryId)
		dim query, rs
		
		query = " select id from customerdelivery where addressValidated = 1 "
		query = query & " and id = " & deliveryId

		set rs = getdisconnectedrecordset(query)
		
		isAddressValidated = (rs.recordcount > 0)
		
		set rs = nothing
	end function
	
	function isAddressUpdated()
		dim query, rs
		
		query = " select id from customerdelivery where deliveryaddress = " & DbQryString(Request.Form("routeAddress"))
		query = query & " and id = " & deliveryId

		set rs = getdisconnectedrecordset(query)
		
		isAddressUpdated = (rs.recordcount = 0)
		
		set rs = nothing
	end function
	
	function getCustomerPrimaryRoute(customerseq)
		dim query, rs
		
		query = " select routeNumber from customer where customersequencenumber = " & customerseq
		
		set rs = getdisconnectedrecordset(query)
		
		getCustomerPrimaryRoute = rs("routeNumber")
		
		set rs = nothing
	end function
	
	function invalidateAddress(customerdeliveryid)
		dim query, rs
		
		query = " update customerdelivery set addressmapped = 0, addressrelated = 0, addressoptimized = 0 where id = " & customerdeliveryid
		qryexecute query

	end function

	sub saveForm()
		dim query, rs

		if not mapAddress or isAddressUpdated() then
			invalidateAddress deliveryid
		end if

		if isAddressUpdated() then
			if request.form("updateOnDelivery") <> "" then
				
				updateDeliveryAddresses deliveryid
			end if
		end if
		
		query = "update customerdelivery set deliverynotes = " & DbQryString(Request.Form("routeNotes")) & ", deliveryaddress = " & DbQryString(Request.Form("routeAddress"))
		query = query & ", deliveryPhone = " & DbQryString(Request.Form("routePhone"))
		query = query & ", accountType = " & Request.Form("accountType")
		

		query = query & ", DeliverSun = " & IIf(Request.Form("daySunday") = "", "0", Request.Form("daySunday"))
		query = query & ", DeliverMon = " & IIf(Request.Form("dayMonday") = "", "0", Request.Form("dayMonday"))
		query = query & ", DeliverTue = " & IIf(Request.Form("dayTuesday") = "", "0", Request.Form("dayTuesday"))
		query = query & ", DeliverWed = " & IIf(Request.Form("dayWednesday") = "", "0", Request.Form("dayWednesday"))
		query = query & ", DeliverThu = " & IIf(Request.Form("dayThursday") = "", "0", Request.Form("dayThursday"))
		query = query & ", DeliverFri = " & IIf(Request.Form("dayFriday") = "", "0", Request.Form("dayFriday"))
		query = query & ", DeliverSat = " & IIf(Request.Form("daySaturday") = "", "0", Request.Form("daySaturday"))


		if dateStart <> "" then
      query = query & ", BeginDate = " & DbQryString(dateStart)
    else
			'nothing, default value
    end if
    
		if dateEnd <> "" then
      query = query & ", EndDate = " & DbQryString(dateEnd)
		else
		  query = query & ", EndDate = null"
		end if
		
		query = query & ", PaymentType = '" & deliveryPaymentType & "'"
		query = query & " where id = " & deliveryId

		qryexecute query
		
		moveDeliveryToPosition deliveryid, request.form("stoporder")

	end sub

	sub updateDeliveryAddresses(deliveryid)
		dim query, rs

		query = " update deliverystop set deliverystop.deliveryaddress = " & DbQryString(Request.Form("routeAddress"))
		query = query & ", deliverystop.deliveryPhone = " & DbQryString(Request.Form("routePhone"))
		query = query & " from deliverystop inner join deliveryitem "
		query = query & " on deliverystop.deliverystopid = deliveryitem.deliverystopid "
		query = query & " inner join ticket "
		query = query & " on deliveryitem.ticketnumber = ticket.ticketnumber "
		query = query & " where ticket.ticketstatus in ('AC', 'OD') "
		query = query & " and deliveryitem.status >= 0 "
		query = query & " and deliverystop.deliveryid = " & deliveryId
		
		qryexecute query
		
		moveDeliveryToPosition deliveryid, request.form("stoporder")
	end sub
	
	
	function getRouteStopRange(routenumber)
		dim query, rs
		
		query = " select MAX(stopOrder) - MIN(stopOrder) as range from "
		query = query & " customerdelivery where active = 1 and routeid = " & routenumber
		
		set rs = getdisconnectedrecordset(query)
		
		getRouteStopRange = rs("range")
		
		set rs = nothing
		
	end function
	
	sub moveDeliveryToPosition(deliveryid, stopOrder)
    dim query, rs
    dim routeNumber
    dim range
    
    query = "select routeid as routenumber, stoporder from customerdelivery where id = " & deliveryid

    set rs = getdisconnectedrecordset(query)
    
    if rs.recordcount > 0 then
      routeNumber = rs("routeNumber")
      range = getRouteStopRange(routeNumber)
      
      if clng(stopOrder) < clng(rs("stopOrder")) then
        query = " update customerdelivery set stoporder = stoporder + 1 where active = 1 and routeid = " & routeNumber & " and stoporder >= " & stopOrder
      else
        query = " update customerdelivery set stoporder = stoporder - 1 where active = 1 and routeid = " & routeNumber & " and stoporder <= " & stopOrder
      end if

      if clng(stopOrder) <> clng(rs("stopOrder")) then
        qryexecute query
  
        query = " update customerdelivery set stoporder = " & stopOrder & " where id = " & deliveryid

        qryexecute query
  
  		  packRouteStops routeNumber
		  end if
    end if
	
	end sub
	
	function createDelivery()
		dim query, rs
		dim deliveryID

		openConnection
		
		query = "insert into customerdelivery(customersequencenumber, routeid, stopOrder) "
		query = query & " select " & customerSeq & ", " & Request.Form("selectedRoute") & ", isnull(max(stopOrder) + 1, 0) "
		query = query & " from customerdelivery where routeID = " & Request.Form("selectedRoute")

		dbInsert query
		
		set rs = dbSelect("select @@IDENTITY as deliveryId")
		
		deliveryID = rs("deliveryId")
		
		closeConnection
		
		moveDeliveryToPosition deliveryid, request.form("stoporder")
		
		createDelivery = deliveryID
	end function

	function checkIfCustomerHasDelivery()
		dim query, rs
		
		query = "select count(*) as cnt from customerdelivery where customersequencenumber = " & customerSeq
		set rs = getdisconnectedrecordset(query)
		
		checkIfCustomerHasDelivery = rs("cnt") > 0
		
		set rs = nothing
	end function
	
	function getCustomerMainPhone(customerSeq)
    dim query, rs
    
    getCustomerMainPhone = ""
    
    if customerSeq <> "" then
      query = " select dbo.formatPhone(mainareacode, mainphone) as phonenumber "
      query = query & " from customer where customersequencenumber = " & customerSeq
      
      set rs = getdisconnectedrecordset(query)
      
      if rs.recordcount > 0 then
        getCustomerMainPhone = rs("phonenumber")
      end if
      
      set rs = nothing
    end if
	end function
	
	sub loadDeliveryDefaults()
		deliveryNotes = ""
		deliveryAddress = ""
		deliveryPhone = getCustomerMainPhone(customerSeq)
		deliveryDays(0) = 0
		deliveryDays(1) = 0
		deliveryDays(2) = 0
		deliveryDays(3) = 0
		deliveryDays(4) = 0
		deliveryDays(5) = 0
		deliveryDays(6) = 0
		accountType = 0
	end sub
	
	
	sub loadDeliveryValues(id)
		dim query, rs
		
		query = "select *, convert(varchar, begindate, 101) as begindate, convert(varchar, enddate, 101) as enddate from customerdelivery where id = " & id
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			deliveryNotes = rs("deliveryNotes")
			deliveryAddress = rs("deliveryAddress")
			deliveryPhone = rs("deliveryPhone")
			
			deliveryDays(0) = rs("deliverSun")
			deliveryDays(1) = rs("deliverMon")
			deliveryDays(2) = rs("deliverTue")
			deliveryDays(3) = rs("deliverWed")
			deliveryDays(4) = rs("deliverThu")
			deliveryDays(5) = rs("deliverFri")
			deliveryDays(6) = rs("deliverSat")
			
			deliveryRoute = rs("RouteID")
			
			deliveryPaymentType = rs("PaymentType")
			
			dateStart = rs("begindate")
			dateEnd = rs("enddate")
			
			stopOrder = rs("stopOrder")
			
			routeNumber = rs("routeid")

			addressMapped = rs("addressMapped")
			
			accountType = rs("accountType")
		end if
		
		set rs = nothing
	end sub
	
	function getDeliveryWeekJSArgs(rs)
		dim result
		
		result = rs("deliverySun") & "," & rs("deliveryMon") & "," & _
				rs("deliveryTue") & "," & rs("deliveryWed") & "," & _
				rs("deliveryThu") & "," & rs("deliveryFri") & "," & _
				rs("deliverySat")
		
		getDeliveryWeekJSArgs = lcase(result)
	end function
	
	function d_deliveryWeek()
		dim days
		dim opts
		dim d, o
		dim selected
		
		days = Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
		opts = Array("", "Dropoff", "Pickup", "Always Stop")
		
		Response.Write "<TABLE>"
		for d = lbound(days) to ubound(days)
			Response.Write "<TR><TD>" & days(d) & "</TD><TD>"
			
			Response.Write "<SELECT name=""day" & days(d) & """>"
			
			for o = lbound(opts) to ubound(opts)
				if o = deliveryDays(d) then
					selected = "selected"
				else
					selected = ""
				end if
				
				Response.Write "<OPTION value=""" & o & """ " & selected & ">" & opts(o) & "</OPTION>"
			next
			
			Response.Write "</SELECT>"
		next
		Response.Write "</TABLE>"
	end function
	
	
    function fullCustomerAddress(rs, t)
			dim p1, p2
			
			t = lcase(trim(t))
			
			if t = "shipping" or t = "billing" then
				p1 = ""
				p2 = ""
				
				if rs(t & "Address1") <> "" then  p1 = p1 & trim(rs(t & "Address1")) & vbcrlf end if
				if rs(t & "Address2") <> "" then  p1 = p1 & trim(rs(t & "Address2")) & vbcrlf end if
				if rs(t & "Address3") <> "" then  p1 = p1 & trim(rs(t & "Address3")) & vbcrlf end if
				
				p2 = trim(trim(rs(t & "City")) & " " & trim(rs(t & "State")))
				
				if p2 <> "" and rs(t & "Zipcode") <> "" then
				  p2 = p2 & ", " & trim(rs(t & "Zipcode"))
				else
				  p2 = p2 & trim(rs(t & "Zipcode"))
				end if
				
				fullCustomerAddress = p1 & p2
			end if
    end function
	

	function getRouteName(routeNumber)
		dim query, rs
		query = " select name from route where routenumber = " & routeNumber
		set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
			getRouteName = rs("name")
		end if
		set rs = nothing
	end function

	
	query = "select * from customer where customersequencenumber = " & customerSeq
	set custRs = getdisconnectedrecordset(query)
%>
<HTML>
<HEAD>
<TITLE>Customer Routes</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker.js"></script>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript">

	var selectedRouteValue;
	

	function submitForm(){
		document.customerDeliveryForm.action= "?userAction=submit";
		document.customerDeliveryForm.submit();
	}

	function disableAllStopOrder() {
		var i;

		for (i=0; i < document.forms[0].stopOrder.length; i++) {
			document.forms[0].stopOrder[i].disabled = true;
		}
	}
	
	function getSelectedRoute() {
    var i;
		for (i=0; i < document.forms[0].selectedRoute.length; i++) {

			if (document.forms[0].selectedRoute[i].checked) {
				return document.forms[0].selectedRoute[i].value;
			}
		}
    
	}
	
	
	function saveAndExit() {
		if(document.customerDeliveryForm.routeAddress.value == "") {
			cbs_alert("A delivery address is required to save.");
			return;
		}
		
	   submitForm();
	}
	
	function cancelForm(){
		document.customerDeliveryForm.action = "?userAction=cancel";
		document.customerDeliveryForm.submit();
	}
	
	function createDelivery(){
		document.customerDeliveryForm.action = "?userAction=createdelivery";
		document.customerDeliveryForm.submit();
	}
	
	function copyShippingAddress() {
		document.customerDeliveryForm.routeAddress.value = document.customerDeliveryForm.shippingAddress.value;
	}
	function copyBillingAddress() {
		document.customerDeliveryForm.routeAddress.value = document.customerDeliveryForm.billingAddress.value;
	}
	function promptPrimaryRoute() {
		var w = window.open("/MainApp/customerPrimaryRoute.asp?selectedroute=" + getSelectedRoute() + "&customerseq=<%=customerSeq%>", "customerPrimaryRoute", "status=no,fullscreen=no,scrollbars=no,width=300,height=200");
	}
	function primaryRouteSelected() {
		submitForm();
	}
	
	function disableDaysDropdown() {
		document.customerDeliveryForm.daySunday.style.background = "white";
		document.customerDeliveryForm.dayMonday.style.background = "white";
		document.customerDeliveryForm.dayTuesday.style.background = "white";
		document.customerDeliveryForm.dayWednesday.style.background = "white";
		document.customerDeliveryForm.dayThursday.style.background = "white";
		document.customerDeliveryForm.dayFriday.style.background = "white";
		document.customerDeliveryForm.daySaturday.style.background = "white";
	}
	
	function enableDaysDropdown(su, mo, tu, we, th, fr, sa) {
		if(su) document.customerDeliveryForm.daySunday.style.background = "lightgreen";

		if(mo) document.customerDeliveryForm.dayMonday.style.background = "lightgreen";

		if(tu) document.customerDeliveryForm.dayTuesday.style.background = "lightgreen";

		if(we) document.customerDeliveryForm.dayWednesday.style.background = "lightgreen";

		if(th) document.customerDeliveryForm.dayThursday.style.background = "lightgreen";
		
		if(fr) document.customerDeliveryForm.dayFriday.style.background = "lightgreen";
		
		if(sa) document.customerDeliveryForm.daySaturday.style.background = "lightgreen";
	}
	
	function setDaysDropdown(su, mo, tu, we, th, fr, sa) {
		disableDaysDropdown();
		enableDaysDropdown(su, mo, tu, we, th, fr, sa);
	}
	
	
	function SetRowCheckedStatus(row, check, value) {
		if(!value)
		{
			check.checked = true;
//			row.className = "selected";
			document.customerDeliveryForm.btnOK.disabled = false;
		}
		else
		{
			check.checked = false;
//			row.className = "";
			document.customerDeliveryForm.btnOK.disabled = true;
			disableDaysDropdown();
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "selectedRoute") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));

			}
			else if (childEl.name == "selectedRoute") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));

			}

			if (childEl.children[0] && childEl.children[0].name == "stopOrder") {
				enableStopOrder(childEl.children[0]);

			}
			else if (childEl.name == "stopOrder") {
				enableStopOrder(childEl);

			}

		}
	}
	
	function setDefaultRouteDays() {
	<%
		if deliveryRoute <> "" then
			query = " select * from route where routenumber = " & deliveryRoute
			set rs = getdisconnectedrecordset(query)
	%>
		setDaysDropdown(<%=getDeliveryWeekJSArgs(rs)%>);
	<%
			set rs = nothing
		end if
	%>
	}
	
	
	function enableStopOrder(element) {

    disableAllStopOrder();
    element.disabled = false;
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0 onload="setDefaultRouteDays()">

<!-- #include file="../include/banner.inc" -->
<H1>Route Membership</H1>
<FORM id="customerDeliveryForm" name="customerDeliveryForm" action="" method="Post">
<INPUT type="hidden" name="routeRef" value="<%=routeRef%>" />
<INPUT type="hidden" name="customerSeq" value="<%=customerSeq%>" />
<INPUT type="hidden" name="deliveryId" value="<%=deliveryId%>" />
<INPUT type="hidden" name="billingAddress" value="<%=fullCustomerAddress(custRs, "billing")%>" />
<INPUT type="hidden" name="shippingAddress" value="<%=fullCustomerAddress(custRs, "shipping")%>" />
<INPUT type="hidden" name="customerPrimaryRoute" value="<%=customerPrimaryRoute%>" />

<TABLE WIDTH="100%" ALIGN=center  border="0" cellspacing="0" cellpadding="0">
	<TR>
	<TD valign="top">

		<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
			<SPAN style="float:left">
				
			</SPAN>
			
			<SPAN style="float:right">
				<BUTTON onclick="cancelForm()">Cancel</BUTTON>
				<BUTTON <%if routeRef = "" and deliveryid = "" then %>disabled<%end if%> name="btnOK" onclick="saveAndExit()">Ok</BUTTON>
			</SPAN>
		</DIV>

	</TD>
	
	</TR>

	<TR>
	<TD>
		<TABLE ALIGN=center  CELLSPACING=20>

		<TR>
			<TD colspan="2" align="center">
				<H4>
					<A href="/setup/routeSetup.asp?routeNumber=<%=routeNumber%>&customerRef=<%=deliveryId%>#<%=stopOrder%>">
					<%=getRouteName(routeNumber)%> #<%=stopOrder%>
					</A>
				</H4>
			</TD>
		</TR>
	
		<TR>
			<TD>
				<%d_deliveryWeek%>
			</TD>
			<TD>
				<TABLE>
				
					<TR>
						<TD>Date Range</TD>
						<TD>
							<INPUT name=dateStart  readonly class=text style="HEIGHT: 25px; WIDTH: 100px" value="<%=dateStart%>" onClick="javascript:show_calendar('customerDeliveryForm.dateStart');">
							to
							<INPUT name=dateEnd  readonly class=text style="HEIGHT: 25px; WIDTH: 100px" value="<%=dateEnd%>" onClick="javascript:show_calendar('customerDeliveryForm.dateEnd');">
						</TD>
					</TR>
					<TR>
						<TD>Notes</TD>
						<TD align =left>
							<TEXTAREA rows="6" cols="40" name="routeNotes"><%=deliveryNotes%></TEXTAREA>
						</TD>
					</TR>
					<TR>
						<TD>Delivery Address<br>
							<INPUT type="button" value="Shipping" onclick="copyShippingAddress()" />
							<INPUT type="button" value="Billing" onclick="copyBillingAddress()" />
						</TD>
						<TD align =left>
							<TEXTAREA rows="3" cols="40" name="routeAddress"><%=deliveryAddress%></TEXTAREA>
						</TD>
					</TR>
					<% if mapPointEnabled then %>
					<TR>
						<TD>Map Address</TD>
						<TD>
							<SELECT name="mapAddress">
								<OPTION value="1" <%if addressMapped then%>selected<%end if%>>Yes</OPTION>
								<OPTION value="0" <%if not addressMapped then%>selected<%end if%>>No</OPTION>
							</SELECT>
						</TD>
					</TR>
					<% end if %>
					<TR>
						<TD>Phone Number</TD>
						<TD><INPUT name="routePhone" value="<%=deliveryPhone%>" /></TD>
					</TR>
					<% if isAddressInDelivery(deliveryId) then %>
					<TR>
						<TD>&nbsp;</TD>
						<TD>
							<SPAN style="background:yellow">
							<INPUT type="checkbox" name="updateOnDelivery" value="1" />
							
							Customer currently has at least one invoice on a delivery.  Check box to update current deliveries.
							</SPAN>
						</TD>
					</TR>
					<% end if %>

					<TR>
						<TD>Payment Method</TD>
						<TD>
							<SELECT name="deliveryPaymentType">
								<OPTION value="On Account" <%if trim(deliveryPaymentType) = "On Account" then%>selected<%end if%>>On Account (Default)</OPTION>
						<%	query = "select paymenttypename from paymenttypedomain where enabled = 1 and allowdeliverypayment = 1 order by defaultpaymenttype desc, displaysequence asc"
							set rs = getdisconnectedrecordset(query)
							
							while not(rs.eof or rs.bof)
						%>
								<OPTION value="<%=rs("paymenttypename")%>" <%if ucase(trim(deliveryPaymentType)) = ucase(trim(rs("paymenttypename"))) then%>selected<%end if%>><%= rs("paymenttypename") %></OPTION>
						<%
								rs.movenext
							wend
							
							set rs = nothing
						%>
							</SELECT>
						</TD>
					</TR>
					
					<TR>
						<TD>Account Type</TD>
						<TD>
							<SELECT name="accountType">
								<OPTION value="0" <%if trim(accountType) = "0" then%>selected<%end if%>>Home</OPTION>
								<OPTION value="1" <%if trim(accountType) = "1" then%>selected<%end if%>>Commercial</OPTION>
							</SELECT>
						</TD>
				</TABLE>
			</TD>
		</TR>
		</TABLE>
	</TD>
	</TR>

	


</TABLE>

	
	
</FORM>   

</BODY>
</HTML>


<%
	set custRs = nothing
%>
