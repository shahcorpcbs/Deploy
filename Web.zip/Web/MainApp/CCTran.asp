<%@ Language=VBScript %>
<!-- #INCLUDE FILE="../include/AdoConstants.inc" -->
<!--#include file="../include/querydatabase.asp" -->

<%
	'qry = "TranType=" & tran & "&Clerk=" & clerk & "&Receipt=" & receipt & "&ccn=" & _
            'ccn & "&ccexp=" & ccExp & SwipedCardString
    dim nl
    'nl = chr(13) & chr(10)
    nl = "<br>"
    dim tran, clerk, receipt, ccn, ccexp, amt
    dim ccstate, cczip, ccaddress
    
    tran = Request.QueryString("trtype")
    clerk = Request.QueryString("clrk")
    receipt = Request.QueryString("rcpt")
    ccn = Request.QueryString("ccn")
    ccexp = Request.QueryString("ccexp")
    amt = Request.QueryString("amt")
    
    ccstate = ""
    ccaddress = ""
    cczip = ""
    Response.ContentType = "text/html"
    Response.Write ("TranType = " & tran & nl)
    Response.Write("Clerk = " & clerk & nl)
    Response.Write("Receipt = " & receipt & nl)
    Response.Write("CCN = " & ccn & nl)
    Response.Write("ExpDate = " & ccexp & nl)
    Response.Write("Amount = " & amt & nl)
    
    if tran = "" or ccn = "" or ccexp = "" then
		Response.Write("ERROR: Credit Card Number or Expiry Date can not be blank")
		Response.Flush
		Response.End
    else
		dim oCC
		Set oCC = Server.CreateObject("CCP.CreditCard")
		if not oCC is nothing then
			dim apCode
			on error resume next
			oCC.XChargeServerLocation = Application("XChargeServerLocation")
			apCode = oCC.DoTransaction(tran, ccn, ccexp, cchn, amt,ccstate, cczip, ccaddress, receipt)
			if Err.Number <> 0 then
				Response.Write("ERROR:" & Err.Description)
			else
				Response.Write(apCode)
			end if
			Response.Flush
			Response.End
		else
			
		end if
    end if
%>