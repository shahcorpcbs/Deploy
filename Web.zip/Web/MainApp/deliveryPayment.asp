<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/messages.asp" -->

<%
	dim query, rs
	dim paymentMethod
	dim deliverystopid
	dim amounttobeapplied
	dim ccAccountNumber
	dim ccExpMonth
	dim ccExpYear
	dim customerseq
	dim deliveryid
	dim allowcredit
	
	paymentMethod = getReqVar("paymentMethod")
	deliverystopid = getReqVar("deliverystopid")
	amounttobeapplied = getReqVar("amounttobeapplied")
	customerseq = getReqVar("customerseq")
	allowcredit = getReqVar("allowcredit")
	
	deliveryid = getDeliveryIDForDeliveryStopID(deliverystopid)
	
	
	if not isPaymentMethodAllowed(paymentMethod) then
		paymentMethod = "Cash"
	end if
	
	if paymentMethod = "Credit Card" then
		readCustomerCreditCardOnFile customerseq
	end if
	
	select case lcase(request.querystring("useraction"))
	case "addpayment"
		addPayment
	
	end select
	
	function getDeliveryIDForDeliveryStopID(deliverystopid)
		dim query, rs
		
		query = " select deliveryid from deliverystop where deliverystopid = " & deliverystopid
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			getDeliveryIDForDeliveryStopID = rs("deliveryid")
		end if
		
		set rs = nothing
	end function
	
	function readCustomerCreditCardOnFile(customersequencenumber)
		dim query, rs
		
		query = " select isnull(creditcardnumber, '') as creditcardnumber, isnull(creditcardexpdate, '0000') as creditcardexpdate from customer "
		query = query & " where customersequencenumber = " & customersequencenumber
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			ccAccountNumber = rs("creditcardnumber")
			ccExpMonth = clng(left(rs("creditcardexpdate"), 2))
			ccExpYear = clng(right(rs("creditcardexpdate"), 2))
		end if
	
	end function
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function isPaymentMethodAllowed(paymentTypeName)
		dim query, rs
				
		query = "select count(*) as cnt from paymenttypedomain "
		query = query & " where enabled = 1 and allowdeliverypayment = 1 "
		query = query & " and paymentTypeName = '" & paymentTypeName & "'"
		
		set rs = getdisconnectedrecordset(query)
		
		isPaymentMethodAllowed = rs("cnt") > 0
		
		set rs = nothing
	end function
	
	function getPaymentMethods()
		dim query
		
		query = "select paymenttypename from paymenttypedomain "
		query = query & " where enabled = 1 and allowdeliverypayment = 1 "
		query = query & " order by defaultpaymenttype desc, displaysequence asc"
		
		set getPaymentMethods = getdisconnectedrecordset(query)
	end function
	
	function addLeadingZeros(value, leadingZeros)
		value = CStr(value)
		
		while len(value) < leadingZeros
			value = "0" & value
		wend
		
		addLeadingZeros = value
	end function
	
	sub d_optionRange(minValue, maxValue, selValue, leadingZeros)
		dim index
		
		for index = minValue to maxValue
			Response.Write "<OPTION value=""" & index & """"
			if index = selValue then
				Response.Write " selected"
			end if
			Response.Write ">"
			Response.Write addLeadingZeros(index, leadingZeros)
			Response.Write "</OPTION>"
		next
	end sub
	function setDeliveryStatus(deliveryid, status)
		dim query
		
		if deliveryid <> "" then
			query = " update delivery set status = " & status
			query = query & " where deliveryid = " & deliveryid
			
			qryexecute query
		end if
	end function
	sub addPayment()
		dim paymentmethod
		dim amounttobeapplied
		dim accountnumber
		dim expirationmonth
		dim expirationyear
		
		paymentmethod = request.form("paymentmethod")
		amounttobeapplied = request.form("amounttobeapplied")
		
		select case lcase(paymentmethod)
			case "credit card"
				accountnumber = request.form("accountnumber")
				expirationmonth = request.form("expirationmonth")
				expirationyear = request.form("expirationyear")
				
				addCreditCardPayment	deliverystopid, _
										paymentmethod, _
										amounttobeapplied, _
										accountnumber, _
										expirationmonth, _
										expirationyear
			case "check"
				accountnumber = request.form("accountnumber")
				
				addCheckPayment	deliverystopid, _
								paymentmethod, _
								amounttobeapplied, _
								accountnumber
			case else
				addDefaultPayment	deliverystopid, _
									paymentmethod, _
									amounttobeapplied
		end select
		
		setDeliveryStatus deliveryid, 3
	end sub
	
	sub addDefaultPayment(DeliveryStopID, PaymentMethod, AmountToBeApplied)
		dim query, rs
		
		query = " insert into deliverypayment "
		query = query & " (DeliveryStopID, PaymentMethod, AmountToBeApplied) "
		query = query & " values ( " & DeliveryStopID
		query = query & ",'" & PaymentMethod & "'"
		query = query & "," & AmountToBeApplied
		query = query & ")"

		
		qryexecute query
	end sub
	
	sub addCreditCardPayment(DeliveryStopID, PaymentMethod, AmountToBeApplied, AccountNumber, ExpirationMonth, ExpirationYear)
		dim query, rs
		
		query = " insert into deliverypayment "
		query = query & " (DeliveryStopID, PaymentMethod, AmountToBeApplied, AccountNumber, ExpirationMonth, ExpirationYear) "
		query = query & " values ( " & DeliveryStopID
		query = query & ",'" & PaymentMethod & "'"
		query = query & "," & AmountToBeApplied
		query = query & ",'" & AccountNumber & "'"
		query = query & "," & ExpirationMonth
		query = query & "," & ExpirationYear
		query = query & ")"

		
		qryexecute query
	end sub
	
	sub addCheckPayment(DeliveryStopID, PaymentMethod, AmountToBeApplied, CheckNumber)
		dim query, rs
		
		query = " insert into deliverypayment "
		query = query & " (DeliveryStopID, PaymentMethod, AmountToBeApplied, AccountNumber) "
		query = query & " values ( " & DeliveryStopID
		query = query & ",'" & PaymentMethod & "'"
		query = query & "," & AmountToBeApplied
		query = query & ",'" & CheckNumber & "'"
		query = query & ")"

		
		qryexecute query
	end sub
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">
	function changePaymentMethod(paymentMethod) {
		document.deliveryPayment.action= "?paymentMethod=" + paymentMethod;
		document.deliveryPayment.submit();
	}
	function cancelPayment() {
		window.close();
	}
	function addPayment() {
		if(document.deliveryPayment.amounttobeapplied.value > 0) {
			document.deliveryPayment.action= "?useraction=addpayment";
			document.deliveryPayment.submit();
		}
		else {
			cbs_alert("Payment must be greater then zero.");
		}
	}
	function closeAndUpdateParent() {
		opener.updateDelivery();
		window.close();
	}
	
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="<%if request.querystring("useraction") = "addpayment" then response.write "closeAndUpdateParent()" end if%>">

<FORM id="deliveryPayment" name="deliveryPayment" method="post">
<INPUT type="hidden" name="deliverystopid" value="<%=deliverystopid%>" />
<INPUT type="hidden" name="customerseq" value="<%=customerseq%>" />
<INPUT type="hidden" name="allowcredit" value="<%=allowcredit%>" />
<BR />

<TABLE align="center">
	<TR>
		<TD>Payment Type</TD>
		<TD>
			<SELECT name="paymentmethod" onchange="changePaymentMethod(this.value)">
			<%
				set rs = getPaymentMethods()
				while not (rs.eof or rs.bof)
			%>
				<OPTION value="<%=rs("paymentTypeName")%>"
				<%if trim(paymentMethod) = trim(rs("paymentTypeName")) then%>selected<%end if%>>
					<%=rs("paymentTypeName")%>
				</OPTION>
			<%	
					rs.movenext
				wend
				
				set rs = nothing
			%>
			</SELECT>
		</TD>
	</TR>
	
	<TR>
		<TD>Amount</TD>
		<TD>
			<INPUT name="amounttobeapplied" value="<%=formatnumber(amounttobeapplied, 2)%>" />
		</TD>
	</TR>

	<%if paymentMethod = "Credit Card" then%>
	<TR>
		<TD>Account Number</TD>
		<TD>
			<INPUT name="accountnumber" value="<%=ccAccountNumber%>" />
		</TD>
	</TR>
	
	<TR>
		<TD>Expiration Date</TD>
		<TD>
			<SELECT name="expirationmonth">
				<%d_optionRange 1, 12, ccExpMonth,  2%>
			</SELECT>
			
			
			<SELECT name="expirationyear">
				<%d_optionRange Year(Date()), Year(Date()) + 20, 2000 + ccExpYear, 2%>
			</SELECT>	
		</TD>
	</TR>
	<%end if%>
	
	<%if paymentMethod = "Check" then%>
	<TR>
		<TD>Check Number</TD>
		<TD>
			<INPUT name="accountnumber" />
		</TD>
	</TR>
	<%end if%>
	
	<TR>
		<TD colspan="2" align="center">
			<BR />
			<INPUT style="width:100px;height:50px" type="button" value="Cancel" onclick="cancelPayment()" />
			<INPUT style="width:100px;height:50px" type="button" value="Ok" onclick="addPayment()" />
		</TD>
	</TR>
</TABLE>

</FORM>


</BODY>

</HTML>
