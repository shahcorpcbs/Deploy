<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<%
	dim storeguid
	dim employeemessageid
	dim customerseq
	dim status
	dim query, rs	

	storeguid = getReqVar("storeguid")
	employeemessageid = getReqVar("employeemessageid")
	customerseq = getReqVar("customerseq")
	status = getReqVar("status")
	
	function getMessageQuery(storeguid, employeemessageid, customerseq, status)
		dim query, rs
		dim query_filter
		
		query = "select *, dbo.pivotTaskCustomer(task.id) as taskcustomers, "
		query = query & " dbo.pivotTaskEmployee(task.id) as taskemployees "
		query = query & " from task "
	
		if status <> "" then
			if query_filter = "" then
				query_filter = query_filter & " where "
			else
				query_filter = query_filter & " and "
			end if
			
			if status = 0 then
				query_filter = query_filter & " not (task.dateclosed is null) "
			else
				query_filter = query_filter & " task.dateclosed is null "
			end if
		end if
		
		if storeguid <> "" then
			if query_filter = "" then
				query_filter = query_filter & " where "
			else
				query_filter = query_filter & " and "
			end if
			
			query_filter = query_filter & " task.id in (select taskid from customertask where "
			query_filter = query_filter & " customertask.storeguid = '" & storeguid & "' "
			
			if customerseq <> "" then
				query_filter = query_filter & " and customersequencenumber = " & customerseq
			end if
			
			query_filter = query_filter & ")"
		end if
	
		if employeemessageid <> "" then
			if query_filter = "" then
				query_filter = query_filter & " where "
			else
				query_filter = query_filter & " and "
			end if
			
			query_filter = query_filter & " task.id in (select taskid from employeetask where "
			query_filter = query_filter & " employeemessageid = '" & employeemessageid & "') "
		end if
		
		getMessageQuery = query & " " & query_filter
	end function



	function getMessageServerURL()
		dim query, rs
		
		query = "select isnull(messageServerURL, '') as messageServerURL from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getMessageServerURL = trim(rs("messageServerURL"))
		
		set rs = nothing
	end function


	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
%>


<html>
<head>

<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">

</script>


</head>

<body STYLE="margin:0;padding:0;background:#FFF">
<!-- #include file="../include/banner.inc" -->

<form method="post" name="messagereport" style="margin:0;padding:0;" action="MessageReport.asp">

<table style="float:left">

<tr>
	<td>Employee:</td>
	<td>
		
		<select style="width:200px" name="employeemessageid" onchange="document.messagereport.submit();">
			<option value="">All</option>
		<%
			query = "select username from messageaccount where id > 0"
			set rs = getdisconnectedrecordset(query)
			
			while not(rs.eof or rs.bof)
		%>
			<option value="<%=rs("username")%>" <%if trim(employeemessageid) = trim(rs("username")) then%>selected<%end if%>><%=rs("username")%></option>
		<%
				rs.movenext
			wend
			
			set rs = nothing
		%>
		</select>
	</td>

<tr>
<tr>
	<td>Store:</td>
	<td>
		<select style="width:200px" name="storeguid" onchange="document.messagereport.submit();">
			<option value="">All</option>
		<%
			query = "select distinct storename, storeguid from messageaccountstore"
			set rs = getdisconnectedrecordset(query)
			
			while not(rs.eof or rs.bof)
		%>
			<option value="<%=rs("storeguid")%>" <%if trim(storeguid) = trim(rs("storeguid")) then%>selected<%end if%>><%=rs("storename")%></option>
		<%
				rs.movenext
			wend
			
			set rs = nothing
		%>
		</select>

		<select style="width:200px" name="customerseq" onchange="document.messagereport.submit();">
			<option value="">All</option>
		<%
			if storeguid <> "" then
			
				query = "select distinct customersequencenumber, customername from customertask"
				if storeguid <> "" then
					query = query & " where storeguid = '" & storeguid & "'"
				end if
				
				set rs = getdisconnectedrecordset(query)
				
				while not(rs.eof or rs.bof)
		%>
			<option value="<%=rs("customersequencenumber")%>" <%if trim(customerseq) = trim(rs("customersequencenumber")) then%>selected<%end if%>><%=rs("customername")%></option>
		<%
					rs.movenext
				wend
				
				set rs = nothing
			end if
		%>
		</select>
		
		Status:
		
		<select style="width:200px" name="status" onchange="document.messagereport.submit();">
			<option value="">All</option>
			<option value="1" <%if status = "1" then%>selected<%end if%>>Open</option>
			<option value="0" <%if status = "0" then%>selected<%end if%>>Closed</option>
		</select>
	<td>
</tr>
</table>


<table class="itable" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<th>Employee</th>
		<th>Note</th>
		<th>Customer</th>
	</tr>
<%
	set rs = getdisconnectedrecordset(getMessageQuery(storeguid, employeemessageid, customerseq, status))
	
	while not(rs.eof or rs.bof)
%>

	<tr>
		<td><%=rs("taskemployees")%></td>
		<td><%=rs("description")%></td>
		<td><%=rs("taskcustomers")%></td>
	</tr>

<%
		rs.movenext
	wend
	
	set rs = nothing
%>
</table>

</form>

</body>


</html>
