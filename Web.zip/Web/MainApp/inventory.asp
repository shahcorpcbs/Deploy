<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!-- #include file="../include/EmployeeSecurity.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	dim isSubmitted 
	dim rstInventory

	isSubmitted = Request.QueryString("submitted")
	
	if (isSubmitted)  then
		if Request.QueryString("useraction")= "search" then
			DoSearch()
		elseif Request.QueryString("useraction")= "reconcile" then
			ReconcilewithDatabase()
		end if
	else
		'if isobject(session("inventoryelements")) then
			set session("inventoryelements") = nothing
		'end if
		
	end if
	
	
	
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>Inventory</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">

	var timer = null;

	function resetTimeout() {
		if(timer != null) {
			clearTimeout(timer);
			timer = setTimeout("submitSearch();", 300);
		}
	}
	
	function submitSearch() {
		document.inventory.action ="?submitted=true&userAction=search"
		document.inventory.submit();
	}
	
	function doSearch() {
		if(document.inventory.invNumList.value != "")
			document.inventory.invNumList.value += "|"
		
		document.inventory.invNumList.value += document.inventory.txtInvoiceNo.value;
		document.inventory.txtInvoiceNo.value = "";
		
		if(timer != null)
			clearTimeout(timer);
		
		timer = setTimeout("submitSearch();", 300);
	}
	
	function submitForm(userSelection){
		if (userSelection == "search"){
			if (trim(document.inventory.txtInvoiceNo.value) != ""  &&
				trim(document.inventory.txtFromInvoice.value) != "" &&
				trim(document.inventory.txtToInvoice.value) != "") {
				doSearch();
			}
		}
		else if (userSelection == "reconcile" ){
				document.inventory.action ="?submitted=true&userAction=" + userSelection;
				document.inventory.submit();
			}
		else
			return false;
	}
	
	function captureOnBlur(element){
		if (element == "" ){
			document.inventory.txtInvoiceNo.focus();
			return;
		}
	}
	
	function cancelForm(){
		document.inventory.action ="toolsMenu.asp";
		document.inventory.submit();
	}	
	
	function tabOnEnter(nextControl) {
		if(event.keyCode == 13) {
			if(nextControl) {
				nextControl.focus();
			}
		}
	}
	
	function goOnEnter() {
		resetTimeout();
	
		if(event.keyCode == 13) {
			submitForm('search');
		}
	}
	
	function PrintSearchResults() {
		var ps = document.getElementById('printSelection').value;
		window.open('/mainapp/PrintInventorySearchResults.asp?' + "ps=" +ps + "&tm=" + (new Date()).getTime(), 'resultsWindow', 'left=100,top=100,height=50,width=50,toolbar=no,menubar=no,resizable=yes,scrollbars=no,status=no');
	}
</SCRIPT>
<BODY topmargin=0 leftmargin=0 
	<% if trim(Request.QueryString("useraction")) <> "" then %>
		onLoad="captureOnBlur('')" 
	<% end if %>
>
<!-- #include file="../include/banner.inc" -->

	<TABLE ALIGN=center WIDTH="800px" BORDER=0 CELLPADDING=1 >
		<FORM id="inventory" name="inventory" action="" method=post>
		<INPUT type="hidden" name="invNumList" value="">
			<tr>
				<td>
					<TABLE ALIGN=center WIDTH="100%" BORDER=0 CELLPADDING=1 >						
						<!-- search options -->
						<tr>
							<td class="label" align=right>Type of Inventory</td>
							<td class="label" height= 25>
								<input type="radio" name=searchCriteria checked value=byInvCreationDt
								<%if Request.form("searchCriteria" ) = "byInvCreationDt" then %>
									checked
								<%elseif  len(trim(Request.QueryString("useraction"))) > 0 then %>
									disabled																	
								<% end if%>
								>Partial by Invoice Creation Date
							</td>
						</tr>
						<tr>
							<td></td>
							<td class="label" height= 25>
								<input type="radio" name=searchCriteria value=byInvDueDt
								<%if Request.form("searchCriteria" ) = "byInvDueDt" then %>
									checked
								<%elseif  len(trim(Request.QueryString("useraction"))) > 0 then %>
									disabled																	
								<% end if%>
								>Partial by Invoice Due Date
							</td>
						</tr>
						<tr>
							<td></td>
							<td class="label" height= 25>
								<input type="radio" name=searchCriteria value=byInvoiceNo
								<%if Request.form("searchCriteria" ) = "byInvoiceNo" then %>
									checked
								<%elseif  len(trim(Request.QueryString("useraction"))) > 0 then %>
									disabled								
								<% end if%>
								>Partial by Invoice Number</td>							
						</tr>						
						<tr>
							<td></td>
							<td class="label" height= 25>
								<input type="radio" name=searchCriteria value=byRackNo
								<%if Request.form("searchCriteria") = "byRackNo" then %>
									checked
								<%elseif  len(trim(Request.QueryString("useraction"))) > 0 then %>
									disabled																	
								<% end if%>
								>Partial by Rack Number
							</td>
						</tr>
						<tr height=10px><td></td></tr>
						<tr>
							<td class="label" colspan=2>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;Start range
								<INPUT name=txtFromInvoice id=txtFromInvoice class=text onKeyUp="javascript:tabOnEnter(document.getElementById('txtToInvoice'));" onBlur="captureOnBlur(this.name)" style="vertical-align:top" value="<%=Request.Form("txtFromInvoice")%>" >
								<INPUT class=touch id="FromDate" name="FromDate" type=button  style="width:25px;height:25px;vertical-align:top;background-image:url(../images/Calender.gif)" onClick="javascript:show_calendar('inventory.txtFromInvoice');">&nbsp;&nbsp;&nbsp;&nbsp;
								&nbsp;&nbsp;&nbsp;End Range &nbsp

								<INPUT name=txtToInvoice ID="txtToInvoice" class=text  onKeyUp="javascript:tabOnEnter(document.getElementById('txtInvoiceNo'));" onBlur="captureOnBlur(this.name)" value="<%=Request.Form("txtToInvoice")%>" >
								<INPUT class=touch id="toDate" name="toDate" style="vertical-align=top" type=button  style="width:25px;height:25px;;vertical-align:top;background-image:url(../images/Calender.gif)" onClick="javascript:show_calendar('inventory.txtToInvoice');">
							</td>						
						</tr>						
						<tr height=10px><td></td></tr>
						<tr>
							<td class="label" align=right>Invoice Number</td>
							<td>
								<INPUT id=txtInvoiceNo name=txtInvoiceNo class=text  onKeyUp="javascript:goOnEnter();" onBlur="captureOnBlur(this.name)" >	
								<INPUT valign = top class=touch valign=top id="goSearch" name="goSearch" type=button  style="width:25px;height:25px;vertical-align:top" value="GO" onClick="submitForm('search')">
							</td>	
						</tr>
						<tr>
							<td align=left colspan=2>
								<LABEL style="vertical-align=top">&nbsp&nbsp&nbsp&nbsp&nbsp <b>Exclude Route Invoices</b>&nbsp&nbsp
								<INPUT id=excludeRoutes name=excludeRoutes type=checkbox value="1" style="vertical-align:middle"
								<%if Request.form("excludeRoutes") = "1" then %>
									checked 
								<%end if%>	>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		<tr>
			<td>
		<!-- list -->
		
		<TABLE WIDTH="100%" BORDER=0 CELLSPACING=1 CELLPADDING=5>
		<!-- header row -->
		<tr>
			<td>
				<TABLE WIDTH="800px" BORDER=0 CELLSPACING=0 CELLPADDING=5 align=center>
					<!-- heading -->
					<tr>
						<th width =120px align=left class="label">Invoice Number</th>
						<th width =100px align=left class="label">Status</th>
						<th width =140px align=left class="label">Customer Name</th>
						<th width =100px align=left class="label">Ticket Status</th>
						<th width =120px align=left class="label">Rack Location</th>
						<th width =120px align=left class="label">Details</th>
						<th width=16px></th>
					</tr>
				</table>
			</td>
		</tr>
		<!-- list -->
		<tr align=center>
			<td>
				<DIV STYLE="overflow-y:auto;height:200px; overflow-x:auto; width=820;"  align=center>
						<TABLE WIDTH="100%" style="border-color:#2F4F4F;border-style:solid;background-color:white;" BORDER=0 CELLSPACING=0>
							<tr rowspan =5>
								<td>
									<TABLE WIDTH="100%" style="background-color:white;" BORDER=0 CELLSPACING=0 CELLPADDING=5 align=center>
									<!-- to be removed while coding -->	
										<% if isobject(rstInventory) then 
												if rstInventory.recordcount > 0 then
													rstInventory.movelast
													while not rstInventory.bof 
										%>
													<tr>
														<td width = 15%  STYLE="FONT-SIZE: 12px;"><%=rstInventory("invoicenumber")%></td>
														<td width = 12.5%  STYLE="FONT-SIZE: 12px;"><%=rstInventory("Status")%></td>
														<td width = 17.5%  STYLE="FONT-SIZE: 12px;"><%=rstInventory("Customername")%></td>
														<% if rstInventory("racklocation") = "" then%>
															<td width = 12.5%  STYLE="FONT-SIZE: 12px;"><%=rstInventory("TicketStatus")%></td>
														<% else %>
															<td width = 12.5% STYLE="FONT-SIZE: 12px;">Racked</td>
														<% end if %>
														<td width = 15%  STYLE="FONT-SIZE: 12px;"><%=rstInventory("racklocation")%></td>
														<td width = 15%  STYLE="FONT-SIZE: 12px;"><%=rstInventory("details")%></td>
														<!--<td width = 16px  STYLE="FONT-SIZE: 12px;"></td>-->
													</tr>
										<%			rstInventory.moveprevious
												wend 
												end if
												'rstInventory.close
												'set rstInventory = nothing
											end if
											
										%>
										<tr height =50px><td></td></tr>
										<tr height=50px><td></td></tr>	
										<tr height =50px><td></td></tr>
										<tr height=50px><td></td></tr>
										<tr height =50px><td></td></tr>
										<tr height=50px><td></td></tr>
										<!-- till here -->	
									</table>
								</td>
							</tr>
					</table> <!-- table for border -->
				</div>
			</td>
		</tr>
		<!-- buttons -->
		<tr>
			<td>
				<TABLE WIDTH="500px" BORDER=0 CELLSPACING=0 CELLPADDING=0 align=center>
					<tr height=10px></tr>
					<tr height=150px valign=middle >
						<td align=center >
							<BUTTON CLASS=std style="width:100px;height:50px;font-size:12px" name=reconcile onclick="submitForm('reconcile')"><img src="../images/Search-Data.gif">Reconcile</button>
						</td>
						<td align=right>
							Select what to print:&nbsp&nbsp&nbsp&nbsp<br>
							<SELECT name="printSelection" ID="printSelection" size=5>
								<OPTION VALUE="0">All
								<OPTION VALUE="1">Found
								<OPTION VALUE="2">Not Found
								<OPTION VALUE="3">Out of specified range
								<OPTION VALUE="4">Not Reconciled
								<OPTION VALUE="5">Finished
								<OPTION VALUE="6">Voided
							</SELECT></td>
						<td align=center>
							<BUTTON CLASS=std style="width:100px;height:50px;font-size:12px" name=btnPrint onClick = "javascript:PrintSearchResults();"><img src="../images/print-invoice.gif">Results</button>
						</td>
					</tr>
					<tr>							
						<td align=center colspan=3>
							<INPUT class=touchnoborder id=btnOK name=btnOK type=button value="" style="background-image:url(../images/OK.gif)" onClick="cancelForm()">&nbsp&nbsp&nbsp
							<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/cancel.gif)"onClick="cancelForm()">
						</td>	
					</tr>
					</tr>
				</table>
			</td>
		<tr>
	</table>
	</td>
	</tr>
</form>
</table>
</BODY>
</HTML>
<%

	
	function DoSearch()
	dim sqltxt
	dim sCriteria
	dim sStart
	dim sEnd
	dim sInvoice
	dim rstSearch
	dim sfinished
	dim invList
	dim i
	
	
	if not isobject(Session("inventoryelements")) then
		createTempRecordset()
	elseif  Session("inventoryelements") is nothing then
		createTempRecordset()
	end if 

	set rstInventory = Session("inventoryelements")
	
	if trim(Request.Form("invNumList")) = "" then
		exit function
	end if

	sCriteria = trim(Request.Form("searchCriteria"))
	sStart = trim(Request.Form("txtFromInvoice"))
	sEnd = trim(Request.Form("txttoInvoice"))

	invList = split(Replace(Request.Form("invNumList"), " ", ""), "|")

	for i = lbound(invList) to ubound(invList)
		sInvoice = invList(i)

		if (sInvoice <> "" and sCriteria <> "" and sStart <> "" and sEnd <> "" ) then

			sqltxt = "Select invoicenumber from ticket where invoicenumber = " & dbcreateQrystring(sInvoice)
			set rstSearch = getDisconnectedRecordset(sqltxt)
	
			if not (rstSearch.recordcount  > 0 ) then
				rstInventory.AddNew()
				rstInventory.Fields("Customername") = ""
				rstInventory.Fields("rackLocation") = ""
				rstInventory.Fields("TicketStatus") = ""
				rstInventory.Fields("InvoiceNumber") = sInvoice
				rstInventory.Fields("CustomerPhone") = ""
				rstInventory.Fields("invoiceDate") = ""
				rstInventory.Fields("details") = ""
				rstInventory.Fields("status") = "Not Found"
				rstSearch.close
				set rstSearch = nothing
			else
				sqltxt = createsqlstatement()
	
				sqltxt = "exec dbo.InventorySearch " & dbcreateQryString(sInvoice) & ", " & sqltxt
				
				rstSearch.close
				set rstSearch = nothing
				
				set rstSearch = getDisconnectedRecordset(sqltxt)

				if rstSearch.recordcount > 0 then
					if rstSearch("invoiceStatus").value = "Active" then	
					rstInventory.AddNew()
					rstInventory.Fields("ticketNumber") = rstSearch("TicketNumber")
					rstInventory.Fields("Customername") = rstSearch("Customername")
					rstInventory.Fields("InvoiceNumber") = rstSearch("InvoiceNumber")
					rstInventory.Fields("rackLocation") = rstSearch("racklocation")
					rstInventory.Fields("TicketStatus") = rstSearch("TicketStatus")
					rstInventory.Fields("CustomerPhone") = rstSearch("customerPhone")
					rstInventory.Fields("invoiceDate") = rstSearch("invoiceDate")
					rstInventory.Fields("details") = rstSearch("details")
					rstInventory.Fields("status") = "Found"
					'add additional information (Vijayan)
					else
						rstInventory.AddNew()
						rstInventory.Fields("ticketNumber")	= rstSearch("TicketNumber")
						rstInventory.Fields("Customername")	= rstSearch("Customername")
						rstInventory.Fields("InvoiceNumber") = rstSearch("InvoiceNumber")
						rstInventory.Fields("rackLocation")	= rstSearch("racklocation")
						rstInventory.Fields("TicketStatus")	= rstSearch("TicketStatus")
						rstInventory.Fields("CustomerPhone") = rstSearch("customerPhone")
						rstInventory.Fields("invoiceDate") = rstSearch("invoiceDate")
						rstInventory.Fields("details") = rstSearch("details")
						rstInventory.Fields("status") =	rstSearch("invoiceStatus")
					end	if	
				else
					rstInventory.AddNew()
					rstInventory.Fields("Customername") = ""
					rstInventory.Fields("rackLocation") = ""
					rstInventory.Fields("TicketStatus") = ""
					rstInventory.Fields("InvoiceNumber") = sInvoice
					rstInventory.Fields("CustomerPhone") = ""
					rstInventory.Fields("invoiceDate") = ""
					rstInventory.Fields("details") = ""
					rstInventory.Fields("status") = "Out of Specified Range"
					'add additional information (Vijayan)
					
				end if
				
				rstSearch.close
				set rstSearch = nothing
				
			end if
		end if
	next

	set Session("inventoryelements") = rstInventory
	end function
	
	
	function createTempRecordset()
	dim rstTemp
	
		set rstTemp= Server.CreateObject("ADODB.RECORDSET")
	
		rstTemp.Fields.Append "ticketNumber",  adInteger,  , adFldMayBeNull '0
		rstTemp.Fields.Append "InvoiceNumber", adVarChar, 20, adFldMayBeNull '1
		rstTemp.Fields.Append "Status", adVarChar, 100, adFldMayBeNull '2
		rstTemp.Fields.Append "Customername", adVarChar, 100, adFldMayBeNull '3
		rstTemp.Fields.Append "TicketStatus", adVarChar, 40, adFldMayBeNull '4
		rstTemp.Fields.Append "rackLocation", adVarChar, 500, adFldMayBeNull '5
		rstTemp.Fields.Append "details", adVarChar, 500, adFldMayBeNull '6
		rstTemp.Fields.Append "customerPhone", adVarChar, 500, adFldMayBeNull '7
		rstTemp.Fields.Append "invoiceDate", adVarChar, 500, adFldMayBeNull '8
		rstTemp.CursorLocation = aduseClient
		rstTemp.open
		set rstTemp.ActiveConnection = nothing
		set Session("inventoryelements") = rstTemp
		
	end function
	
	function ReconcileWithDatabase()
	dim sqltxt
	dim sTicket
	dim rstSearch 
	
	if isobject(Session("inventoryelements")) and not Session("inventoryelements") is nothing then
		set rstInventory = Session("inventoryelements")
		if rstInventory.recordcount > 0 then
			rstInventory.moveFirst
			while not rstInventory.eof
				if not isNull(rstInventory("invoicenumber")) then
					if sTicket = "" then
						sTicket = rstInventory("invoicenumber")
					else
						sTicket = sticket & ", " & rstInventory("invoicenumber")
					end if
				end if
				rstInventory.movenext		
			wend
			sTicket = dbcreateqrystring(sTicket) 
			sqltxt  = CreateSqlStatement()
			sqltxt =  "execute dbo.reconcileInventory" & sTicket & "," & sqltxt

			
			set rstSearch = getDisconnectedRecordset(sqltxt)

			if rstSearch.recordcount > 0 then
				while not rstSearch.eof 
				rstInventory.AddNew()
				rstInventory.Fields("ticketNumber") = rstSearch("TicketNumber")
				rstInventory.Fields("Customername") = rstSearch("Customername")	
				rstInventory.Fields("InvoiceNumber") = rstSearch("InvoiceNumber")
				rstInventory.Fields("rackLocation") = rstSearch("racklocation")
				rstInventory.Fields("TicketStatus") = rstSearch("TicketStatus")
				rstInventory.Fields("CustomerPhone") = rstSearch("customerPhone")
				rstInventory.Fields("invoiceDate") = rstSearch("invoiceDate")
				rstInventory.Fields("details") = rstSearch("details")
				rstInventory.Fields("status") = "Not Reconciled"
				rstSearch.movenext
				wend
			end if
		
			set Session("inventoryelements") = rstInventory
			rstSearch.close
			set rstSearch = nothing
	
			
		end if
	
		
	end if
	
	end function

	function CreateSqlStatement()
	dim sqltxt
	dim sCriteria
	dim sStart
	dim sEnd
	dim sRoutes
	dim routeNum
	dim rstSearch
	
	sRoutes = Request.Form("excludeRoutes")
	if (sRoutes = 1) then
		routeNum = "0"
	else
		routeNum = "null"
	end if
			
	sCriteria = Request.Form("searchCriteria")
	sStart = Request.Form("txtFromInvoice")
	sEnd = Request.Form("txttoInvoice")

	if (sCriteria = "byInvoiceNo") then
	
		sqltxt = 1 & ",null, null ,"  & dbcreateqrystring(sstart) _
					& "," & dbcreateqrystring(sEnd)_
					& ", null , null, " & routeNum 
		
	elseif (sCriteria = "byInvCreationDt" ) then
	
		sqltxt = 2 & ","  & dbcreateqrystring(sstart)_
					& "," & dbcreateqrystring(sEnd)_
					& " , null, null , null , null, " & routeNum
		
	elseif  (sCriteria = "byRackNo" ) then
	
		sqltxt =  3 & ",null, null , null , null,"_
					& dbcreateqrystring(sstart) _
					& "," & dbcreateqrystring(sEnd) & ", " & routeNum
				 
	elseif  (sCriteria = "byInvDueDt") then
		
		sqltxt = 4 & ","  & dbcreateqrystring(sstart)_
					& "," & dbcreateqrystring(sEnd)_
					& " , null, null , null , null, " & routeNum 					 
		
	end if
	
	createsqlstatement  = sqltxt
	end function
	
%>