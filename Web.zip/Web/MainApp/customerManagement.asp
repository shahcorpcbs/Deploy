<%@ Language=VBScript %>
<% option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validatefunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim customerseq
	dim customername
	dim taskid
	
	customerseq = getReqVar("customerseq")
	taskid = getReqVar("taskid")
	
	if len(trim(customerseq)) = 0 then customerseq = session("customersequencenumber")
	
	session("prevcustomersequencenumber") = customerseq
	
	session("customersequencenumber") = customerseq
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function getStoreGUID()
		dim query, rs

		query = "select guid from store where storeid = " & Session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getStoreGUID = rs("guid")
		
		set rs = nothing
	end function
	
	function getMessageServerURL()
		dim query, rs
		
		query = "select isnull(messageServerURL, '') as messageServerURL from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		
		getMessageServerURL = trim(rs("messageServerURL"))
		
		set rs = nothing
	end function
	

%>
<HTML>
<HEAD>
<TITLE>Customer Notes</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript">
	function exit() {
		document.custManage.action = "/MainApp/CustomerFunctions.asp?customerseq=<%=customerseq%>";
		document.custManage.submit();
	}
	function viewCustomerStats(customerseq) {
	//	var w = window.open("customerStats.asp?customerseq=<%=customerseq%>", "Login", "status=no,fullscreen=no,scrollbars=no,height=400");
		document.custManage.action = "customerStats.asp?customerseq=<%=customerseq%>";
		document.custManage.submit();
	}
	function searchCustomer() {
		document.custManage.action = "searchresults.asp?targetPage=customermanagement&name=" + customersearch.value;
		document.custManage.submit();
	}
	function viewClaims() {
		document.custManage.action = "claimOrComments.asp";
		document.custManage.submit();
	}
	
	function captureKeyup(element){
		if (event.keyCode == 13){
			searchCustomer()
		}
	}
	
	function hideScrollBars(){
		document.body.style.overflow='hidden';
	}
	
	function viewClaim(storeguid, claimid) {
		document.custManage.action = "editClaim.asp?ref=customermanagement&claimid=" + claimid;
		document.custManage.submit();
	}
	
</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="hideScrollBars()">
<!-- #include file="../include/banner.inc" -->

<FORM name="custManage" ID="custManage" METHOD=POST  style="margin:0;padding:0">
<H1>Customer Management</H1>
	
	

	<DIV>

		<TABLE style="font-size:16;width:100%">
		<tr>
			<td colspan="5" align="center">
				Customer Search:
				<INPUT name="customersearch" style="width:300px" onkeyup="captureKeyup()">
			</tr>
		</tr>
		<tr>
<%
	query = "select customer.*, dbo.formatPhone(customer.mainareacode, customer.mainphone) as customerphone, route.name as routename, isnull(pricelist.name, '') as pricelistname from customer inner join route on customer.routenumber = route.routenumber left outer join pricelist on customer.defaultpricelistid = pricelist.pricelistid where customersequencenumber = " & customerseq
	set rs = getdisconnectedrecordset(query)
	customername = rs("customername")
%>
			<td align="left">
				<INPUT type="button" style="width:100px;height:50px" onclick="viewClaims()" value="Claims">
			</td>
			<td>
				<span style="font-size:24;text-decoration:underline"><%=Server.HTMLEncode(customername) %></span><br>
				Route:<%=rs("routename") %>
			</td>

			<td>
			    <span style="font-size:24"><%=rs("customerphone") %></span><br>
				Price Table:<%=rs("pricelistname") %>
			</td>

			<td><%=trim(rs("billingaddress1"))%><br>
				<%
					Response.write trim(rs("billingcity"))
					if len(trim(rs("billingcity"))) > 0 then
						Response.Write ", "
					end if
					Response.write trim(rs("billingstate")) & " " & trim(rs("billingzipcode"))
				%>
			</td>
			
			<td align="right">
				<INPUT type="button" style="width:100px;height:50px" onclick="exit()" value="Ok">
			</td>
		</tr>
		</TABLE>
<%

	set rs = nothing
%>


		
		
		
	</DIV>


	<IFRAME style="width:100%;height:100%;" NORESIZE SCROLLING="NO" FRAMEBORDER="0"
	SRC="<%=getMessageServerURL()%>/MainApp/srvCustomerManagement.asp?storeguid=<%=getStoreGUID()%>&customerseq=<%=customerseq%>&messageusername=<%=Session("employeeMessageAccount")%>&customername=<%=URLEncode(customername)%>&taskid=<%=taskid%>">
	</IFRAME>
</FORM>
</BODY>
</HTML>
