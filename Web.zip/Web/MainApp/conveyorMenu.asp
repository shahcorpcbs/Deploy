<%@ Language=VBScript %>
<% Option Explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/Validatefunction.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<% dim  isSubmitted
	dim l_ticketnumber
	dim s_useraction
	dim query, rs


%>

<HTML>
<HEAD>
<TITLE>Conveyor Menu</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">


	function prInvoice() {
			document.conveyorMenuForm.action="printHSInvoice.asp";
			document.conveyorMenuForm.submit();
	}

	function resendData() {
		document.conveyorMenuForm.action="?submitted=true&useraction=resendData";
		document.conveyorMenuForm.submit();
	}

	function cancelForm() {
		document.conveyorMenuForm.action="toolsmenu.asp";
		document.conveyorMenuForm.submit();
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="">
<!-- #include file="../include/banner.inc" -->

<H1>Conveyor</H1>
	<FORM id="conveyorMenuForm" name="conveyorMenuForm" action="" method="post">
	<TABLE ALIGN=center BORDER=0 CELLSPACING=0 CELLPADDING=0 >
		<tr height=300px>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=resendDataBtn onClick="resendData()">Resend Data</button></td>
			<td><BUTTON class=std style="width:200px;height:100px;font-size:12px" name=printInvoiceBtn onClick="prInvoice()">Print Invoice</button></td>
		</tr>
		<tr height=100px valign=center>
			<td colspan=2 align=center><INPUT class=touchnoBorder id=cancelButton name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="cancelForm()">
			</td>
		</tr>
		</table>
	</form>
</BODY>
</HTML>