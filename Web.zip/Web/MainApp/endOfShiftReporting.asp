<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim l_storeid
	dim isSubmitted 
	dim actionstring
	dim l_employeeid 
	l_employeeid = session("setupEmployeeid")	
	l_storeid = Session("storeid")
	isSubmitted = Request.QueryString("submitted")
	
	if isSubmitted then
		updatedatabase()
		Response.Redirect("AddNewEmployee.asp?useraction=edit")
	end if
	
	getEmployeeinfo()
%>
<HTML>
<HEAD>
<META NAME="GENERATOR" Content="Microsoft Visual Studio 6.0">
<TITLE>End of Shift Reporting</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="JavaScript" src="../script/date-picker2.js"></script>
<script language="javascript" type="text/javascript">
	function submitform(){
		document.endOfShiftReportingForm.action ="?submitted=true";
		document.endOfShiftReportingForm.submit();
	}
</script>
<BODY topmargin=0 leftmargin=0>
<!-- #include file="../include/banner.inc" -->
<B class="pageHeading">End of Shift Reporting</B>
<TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=2>
	<FORM id="endOfShiftReportingForm" name="endOfShiftReportingForm" action="" method="post">
		<tr height=50px></tr>
		<tr>
			<td colspan=5 class="label" align="center">Cash Out Reports</td>
		</tr>
		<tr height=20px></tr>
		<tr>
		<td width=150px></td>
		<td  ></td>
		<td class="label"  width=120px>From date</td>
		<td  class="label" width=120px>To date</td>
		<td  ></td>
		<td width=150px></td>
		</tr>
		<tr>
		
			<td width=150px></td>
			<td class="label">
				<input type="checkbox" name="tillReport" id="tillReport" 
				<%if  l_tillreport then  %>
					CHECKED
				<% end if %>>
				Till Report</td>
			<td ><INPUT id=txtTillReportFromDate name=txtTillReportFromDate class=text readonly style="width:100px;">&nbsp;<INPUT class=touch id=txtDate  name=txtDate  type=button value="..." style="width:25px;height:25px;background-image:url(../images/Calender.gif)" onClick="javascript:show_calendar('endOfShiftReportingForm.txtTillReportFromDate');">
			</td>
			<td><INPUT id=txtTillReportToDate name=txtTillReportToDate class=text readonly style="width:100px;">&nbsp;<INPUT class=touch id=txtDate  name=txtDate  type=button value="..." style="width:25px;height:25px;background-image:url(../images/Calender.gif)" onClick="javascript:show_calendar('endOfShiftReportingForm.txtTillReportToDate');">
			</td>
			<td align="center">
				<INPUT class=touch id=tillReportPreview name=tillReportPreview type=button value=""><br>Preview
			</td>
			<!--<td width=100px></td>-->
		</tr>
		<tr>
			<td width=150px></td>
			<td class="label">
				<input type="checkbox" name="zReport" id="zReport"
				<%if  l_zreport then  %>
					CHECKED
				<% end if %>>
				Z Report
			</td>
			<td  >
				<INPUT id=txtZReportFromDate name=txtZReportFromDate readonly class=text style="width:100px;">&nbsp;
				<INPUT class=touch id=txtDate  name=txtDate  type=button value="..." style="width:25px;height:25px;background-image:url(../images/Calender.gif)" onClick="javascript:show_calendar('endOfShiftReportingForm.txtZReportFromDate');">
			</td>
			<td  >
				<INPUT id=txtZReportToDate name=txtZReportToDate class=text readonly style="width:100px;">&nbsp;
				<INPUT class=touch id=txtDate  name=txtDate  type=button value="..." style="width:25px;height:25px;background-image:url(../images/Calender.gif)" onClick="javascript:show_calendar('endOfShiftReportingForm.txtZReportToDate');">
			</td>
			<td align="center">
				<INPUT class=touch id=zReportPreview name=zReportPreview type=button value=""><br>Preview
			</td>
		</tr>
		<tr>
			<td width=150px></td>
			<td class="label">
				<input type="checkbox" name="tillDetailReport" id="tillDetailReport"
				<%if  l_tilldetailreport then  %>
					CHECKED
				<% end if %>>
				Till Detail Report
			</td>
			<td   >
				<INPUT id=txtTillDetailReportFromDate name=txtTillDetailReportFromDate readonly class=text style="width:100px;">&nbsp;
				<INPUT class=touch id=txtDate  name=txtDate  type=button value="..." style="width:25px;height:25px;background-image:url(../images/Calender.gif)" onClick="javascript:show_calendar('endOfShiftReportingForm.txtTillDetailReportFromDate');">
			</td>
			<td  >
				<INPUT id=txtTillDetailReportToDate name=txtTillDetailReportToDate readonly class=text readonly style="width:100px;">&nbsp;
				<INPUT class=touch id=txtDate  name=txtDate  type=button value="..." style="width:25px;height:25px;background-image:url(../images/Calender.gif)" onClick="javascript:show_calendar('endOfShiftReportingForm.txtTillDetailReportToDate');">
			</td>
			<td align="center" valign = top>
				<INPUT class=touch id=tillDetailReportPreview name=tillDetailReportPreview type=button value=""><br>Preview
			</td>
		</tr>
		<tr>
			<td width=150px></td>
			<td></td>
			<td align="center" >
				<INPUT class=touchnoborder id=ok name=ok type=button value="" style="background-image:url(../images/OK.gif)" onClick="submitform()">
			</td>
			<td align="center"  > 
				<INPUT class=touchnoborder id=cancel name=cancel type=button value="" style="background-image:url(../images/Cancel.gif)" onClick="history.back(-1);">
			</td>
		</tr>
	</form>
</table>
</BODY>
</HTML>
<%
dim l_zreport
dim l_tillreport
dim l_tilldetailreport
l_zreport = 0
l_tillreport = 0
l_tilldetailreport = 0

Function getEmployeeInfo()
	dim sqltxt
	dim rstEmp
			
	sqltxt =  "SELECT [runEndOfShiftTillReport], [runEndOfShiftZReport], [runEndOfShiftTillDetailReport] FROM Employee where employeeid =  " & l_employeeid
	set rstEmp = GetDisconnectedRecordset(sqltxt)
	
	if not rstEmp.bof and not rstEmp.Eof then
		if not isnull(rstemp("runEndOfShiftZReport")) and rstemp("runEndOfShiftZReport")	then
			l_zreport = 1
		end if
		if not isnull(rstemp("runEndOfShiftTillReport")) and rstemp("runEndOfShiftTillReport")	then
			l_tillreport = 1
		end if
		if not isnull(rstemp("runEndOfShiftTillDetailReport")) and rstemp("runEndOfShiftTillDetailReport")	then
			l_tilldetailreport = 1
		end if
	end if
	
	rstEmp.close
	set rstEmp = nothing
	
	end function

function updateDatabase
dim sqltxt
sqltxt = "update employee set " _
		 & " runEndOfShiftTillReport= " & evalRequestValue(request.form("tillReport"))_
		 & " , runEndOfShiftZReport= " & evalRequestValue(request.form("zReport"))_
		 & ", runEndOfShiftTillDetailReport = " & evalRequestValue(request.form("tillDetailReport"))_
		 & " where employeeid = " & L_employeeid 
		'response.wrie sqltxt
dbstarttrans()
qryexecutewithtrans(sqltxt)
dbendtrans()
end function
%>
