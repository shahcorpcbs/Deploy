<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%

	dim query, rs

	
	function updateQueryText(userQueryID, queryText)
		dim query, rs
		
		query = "update userquery set query = '" & replace(queryText, "'", "''") & "' where userqueryid = " & userQueryID
		
		qryexecute query
	end function
	function updateQueryName(userQueryID, queryName)
		dim query, rs
		
		query = "update userquery set name = '" & replace(queryName, "'", "''") & "' where userqueryid = " & userQueryID

		qryexecute query
	end function
	function deleteQuery(userQueryID)
		dim query, rs
		
		query = "delete userquery where userqueryid = " & userQueryID

		qryexecute query
	end function
	

	function newQuery(queryName)
		dim rs
		openConnection
		dbInsert "insert into userquery (name, query) values ('" & queryName & "', '')"
		set rs = dbselect("select @@IDENTITY as rowid")
		newQuery = rs("rowid")
		set rs = nothing
		closeconnection
	end function
	
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">
	var previousElement = null;
	var selectedQuery = null;
	var selectedQueryName = null;

	function runQuery() {
		document.queryList.action = "queryparams.asp?useraction=runquery&queryname=" + selectedQueryName + "&userqueryid=" + selectedQuery;
		document.queryList.submit();
	}

	function selectRow(element) {
		var childEl;
		if (previousElement !=null){
			previousElement.className="";
		}
		selectedQuery = element.getAttribute("queryid");
		selectedQueryName = element.getAttribute("selectedQueryName");
		
		previousElement =element;
		
		element.className = "selected";
		
		queryList.btnRunQuery.disabled = false;
	}
	
	
	function exit() {
		document.queryList.action = "marketingMenu.asp";
		document.queryList.submit();
	}

</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->
<H1>Query List</H1>

<FORM name="queryList" ID="queryList" METHOD=POST  style="margin:0;padding:0"> 
<BR>
<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0">
	<SPAN style="float:left">
		<BUTTON id="btnRunQuery" onclick="runQuery()" disabled>Run</BUTTON>
	</SPAN>
	<SPAN style="float:right">
      <BUTTON onclick="exit()">Exit</BUTTON>
	</SPAN>
</DIV>	

<DIV style="height:600px; overflow:scroll">
<TABLE align="center" width="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;text-align:left" >
		<TH>Name</TH>
		<TH>Description</TH>
	</TR>
	<%
		query = " select * from userquery order by name "
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
	%>
	<TR queryid="<%=rs("userqueryid")%>" selectedQueryName="<%=Server.HTMLEncode(rs("name"))%>)" onclick="selectRow(this)">
		<TD><%=Server.HTMLEncode(rs("name"))%></TD>
		<TD><%=Server.HTMLEncode(rs("description"))%></TD>
	</TR>
	<%
			rs.movenext
		wend
		set rs = nothing
	%>
</TABLE>
</DIV>

</FORM>
</BODY>
</HTML>
