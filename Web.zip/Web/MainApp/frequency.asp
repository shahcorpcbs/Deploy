<%@ Language=VBScript %>

<!--#include file="../include/querydatabase.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim report
	report = Request.QueryString("reportName")
%>
<HTML>
<HEAD>
<TITLE>Frequency</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript">
</SCRIPT>
<BODY topmargin=0 leftmargin=0>

<!-- #include file="../include/banner.inc" -->
<H1>Frequency</H1>
<FORM id="frequencyForm" name="frequencyForm" action="" method="Post">
	<input type="hidden" name="reportName" value="<%= report%>">
	<TABLE ALIGN=center WIDTH="300px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
		<tr height=50px></tr>
		<tr height=50px>
			
			<td class="label">
				<input type="checkbox" name="daily" id="daily">Daily
			</td>
		</tr>
		<tr height=50px>
			
			<td class="label">
				<input type="checkbox" name="weekly" id="weekly">Weekly
			</td>
			<td>
				<select name="weeklyDayOfWeek" id="weeklyDayOfWeek" style="font-size:14px;">
					<option value="Sunday">Sunday
					<option value="Monday">Monday
					<option value="Tueday">Tuesday
					<option value="Wednesday">Wednesday
					<option value="Thursday">Thursday
					<option value="Friday">Friday
					<option value="Saturday">Saturday
				</select>
			</td>
		</tr>
		<tr height=50px>
			
			<td class="label">
				<input type="checkbox" name="biWeekly" id="biWeekly">Bi-Weekly
			</td>
			<td>
				<select name="biweeklyDayOfWeek" id="biweeklyDayOfWeek" style="font-size:14px;">
					<option value="Sunday">Sunday
					<option value="Monday">Monday
					<option value="Tueday">Tuesday
					<option value="Wednesday">Wednesday
					<option value="Thursday">Thursday
					<option value="Friday">Friday
					<option value="Saturday">Saturday
				</select>
			</td>
		</tr>
		<tr height=50px>
			
			<td class="label">
				<input type="checkbox" name="semiMonthly" id="semiMonthly">Semi-Monthly
			</td>
			<td>
				<select name="firstDateRange" id="firstDateRange" style="font-size:14px;width:50px;">
					<%
						for i=0 to 31
					%>
					<option value="<%= i%>"><%= i%>
					<%
						next
					%>
				</select>
			</td>
			<td>
				<select name="secondDateRange" id="secondDateRange" style="font-size:14px;width:50px;">
					<%
						for i=0 to 31
					%>
					<option value="<%= i%>"><%= i%>
					<%
						next
					%>
				</select>
			</td>
		</tr>
		<tr height=50px>
			
			<td class="label">
				<input type="checkbox" name="monthly" id="monthly">Monthly
			</td>
			<td>
				<select name="m_firstDateRange" id="m_firstDateRange" style="font-size:14px;width:50px;">
					<%
						for i=0 to 31
					%>
					<option value="<%= i%>"><%= i%>
					<%
						next
					%>
				</select>
			</td>
			<td>
				<select name="m_secondDateRange" id="m_secondDateRange" style="font-size:14px;width:50px;">
					<%
						for i=0 to 31
					%>
					<option value="<%= i%>"><%= i%>
					<%
						next
					%>
				</select>
			</td>
		</tr>
		<tr height=50px>
			
			<td class="label">
				<input type="checkbox" name="quarterly" id="quarterly">Quarterly
			</td>
		</tr>
		<TR>
			<TD colspan=3 align="center">
				<TABLE ALIGN=center WIDTH="200px" BORDER=0 CELLSPACING=1 CELLPADDING=5 >
					<tr>
						<td align=center> 
							<INPUT class=touchnoborder id=okButton name=okButton type=button value="">
						</td>
						<td align="center">
							<INPUT class=touchnoborder id=cancelButton name=cancelButton type=button value="" onClick="history.back(-1);">
						</TD>
					</tr>
				</table>
			</TD>	
		</TR>
	</table>
</form>
</BODY>
</HTML>
