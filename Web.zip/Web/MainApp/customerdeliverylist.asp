<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<%sec_RequestAccess Request.QueryString("useraction")%>
<%
	dim query, rs
	dim custRs
	dim permAcct
	dim tempAcct
	dim showClosed
	dim customerSeq
	
	showClosed = getReqVar("showClosed")
	
	if Request.QueryString("customerSeq") <> "" then
		customerSeq = Request.QueryString("customerSeq")
	elseif Request.Form("customerSeq") <> "" then
		customerSeq = Request.Form("customerSeq")
	else
		customerSeq = session("customersequencenumber")
	end if
	
	select case lcase(Request.QueryString("userAction"))
	case "new"
		newDelivery
	case "remove"
		removeDelivery Request.Form("deliveryId")
	case "edit"
		editDelivery Request.Form("deliveryId")
	case "setonaccount"
		setOnAccount
	case "submit"
		submitForm()
	case "updateroutenumber"
		updateRouteNumber customerSeq, request.querystring("routeNumber")
	end select
	
	function updateRouteNumber(customerSeq, routeNumber)
		dim query, rs
		
		query = " update customer set routeNumber = " & routeNumber
		query = query & " where customersequencenumber = " & customerSeq
		
		qryexecute query
	end function
	
  function removeDelivery(deliveryid)
  	dim query, rs2
		dim customerSeq
  	dim routeNumber
  	
  	query = "select customersequencenumber, routeid from customerdelivery where id = " & deliveryid

  	set rs = getdisconnectedrecordset(query)
  	
  	if rs.recordcount > 0 then
  		customerSeq = rs("customersequencenumber")
  		routeNumber = rs("routeID")
  		
			query = "delete customerdelivery where id = " & deliveryid
			qryexecute query
			
	  	query = "select customer.customersequencenumber from  "
	  	query = query & " customer inner join customerdelivery on customer.customersequencenumber = customerdelivery.customersequencenumber "
	  	query = query & " where customerdelivery.customersequencenumber = " & customerSeq
	  	query = query & " and customerdelivery.routeID = " & routeNumber

	  	set rs2 = getdisconnectedrecordset(query)
  	
  		if rs2.recordcount > 0 then
  			' nothing
  		else
				query = " update customer set routenumber = 0 where customersequencenumber = " & customerSeq
				qryexecute query
				
				query = " update customer set customer.routenumber = customerdelivery.routeid from "
				query = query & " customer inner join customerdelivery on customer.customersequencenumber = customerdelivery.customersequencenumber "
				query = query & " where customer.customersequencenumber = " & customerSeq
				query = query & " and datediff(day, customerdelivery.begindate, getdate()) >= 0 "
				query = query & " and (customerdelivery.enddate is null or datediff(day, getdate(), customerdelivery.enddate) <= 0) "
				query = query & " and customerdelivery.active = 1 "

				qryexecute query
  		end if
  	end if
  end function
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	sub newDelivery()
		Response.Redirect "/mainapp/quickcustomerdelivery.asp"
	end sub
	
	sub editDelivery(id)
		Response.Redirect "/mainapp/customerdelivery.asp?deliveryId=" & id
	end sub
	
	sub setOnAccount()
		Response.Redirect "/mainapp/Customerpayment.asp?targetpage=customerentry&customerseq=" & session("customersequencenumber")
	end sub	

	
	sub submitForm()
		Response.Redirect "/mainapp/CustomerEntry.asp?mode=edit"
	end sub
	
	function d_getDay(i)
		dim opts
		dim cols
		
		opts = Array("--", "D", "P", "PD", "A")
		cols = Array("lightgrey", "#9999FF", "#00CCFF", "lightgreen", "#FFFF99")
		
		d_getDay = "<SPAN style=""margin-right:1px;background:" & cols(i) & ";width:20px;text-align:center"">" & opts(i) & "</SPAN>"
	end function
	
	sub d_routeDays(rs)
		Response.Write d_getDay(rs("DeliverSun"))
		Response.Write d_getDay(rs("DeliverMon"))
		Response.Write d_getDay(rs("DeliverTue"))
		Response.Write d_getDay(rs("DeliverWed"))
		Response.Write d_getDay(rs("DeliverThu"))
		Response.Write d_getDay(rs("DeliverFri"))
		Response.Write d_getDay(rs("DeliverSat"))
	end sub
	
	query = "select * from customer where customersequencenumber = " & customerSeq

	set custRs = getdisconnectedrecordset(query)
	
	permAcct = custRs("permanentAccount")
	tempAcct = custRs("temporaryAccount")
%>
<HTML>
<HEAD>
<TITLE>Customer Routes</TITLE>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<link href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<script language="javascript" type="text/javascript">

	
	function newDelivery(){
	//	if((document.customerDeliveryListForm.onPermAccount.value == "True") || (document.customerDeliveryListForm.onTempAccount.value == "True")){
			document.customerDeliveryListForm.action= "?userAction=new";
			document.customerDeliveryListForm.submit();
			return true;
	//	}
	//	else {
	//		if(confirm("Customer is not an account customer.  Set up customer on Account?")){
	//			document.customerDeliveryListForm.action = "?userAction=setOnAccount";
	//			document.customerDeliveryListForm.submit();
	//		}
	//	}	
	}

	function removeDelivery(){
        cbs_confirm("Remove selection?", actuallyRemoveDelivery);
	}

	function actuallyRemoveDelivery() {
        clearConfirmMsg();
		document.customerDeliveryListForm.action = "?userAction=remove&deliveryId=" + selectedDelivery;
		document.customerDeliveryListForm.submit();
	}
	
	function editDelivery(){
		document.customerDeliveryListForm.action = "?userAction=edit";
		document.customerDeliveryListForm.submit();
	}
	
	function submitForm() {
		document.customerDeliveryListForm.action = "?userAction=submit";
		document.customerDeliveryListForm.submit();
	}
	
	function SetRowCheckedStatus(row, check, value) {
		if(value)
		{
			check.checked = true;
			row.className = "selected";
			document.customerDeliveryListForm.btnRemove.disabled = false;
			document.customerDeliveryListForm.btnEdit.disabled = false;
		}
		else
		{
			check.checked = false;
			row.className = "";
			document.customerDeliveryListForm.btnRemove.disabled = true;
			document.customerDeliveryListForm.btnEdit.disabled = true;
		}
	}

	var selectedDelivery;
	function ToggleRowChecked(r, id) {
		var childEl;
		var rowChildNodes = r.children;
		selectedDelivery = id;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "deliveryId") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "deliveryId") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}
	
	function updateFilter() {
        document.customerDeliveryListForm.action = "?useraction=updatefilter";
        document.customerDeliveryListForm.submit();
	}
	
	function promptPrimaryRoute() {
		var w = window.open("/MainApp/customerPrimaryRoute.asp?selectedroute=0&customerseq=<%=customerSeq%>", "customerPrimaryRoute", "status=no,fullscreen=no,scrollbars=no,width=300,height=200");
	}
	function primaryRouteSelected() {

	}
	function selectPrimaryRoute(routeNumber) {
        document.customerDeliveryListForm.action = "?useraction=updateroutenumber&routeNumber=" + routeNumber;
        document.customerDeliveryListForm.submit();
	}
	
</SCRIPT>
<BODY topmargin=0 leftmargin=0 onload = "">

<!-- #include file="../include/banner.inc" -->
<H1>Route Membership For <%=custRs("customerName")%></H1>
<FORM id="customerDeliveryListForm" name="customerDeliveryListForm" onsubmit="return false" action="" method="Post" style="margin:0">

<INPUT type=hidden name=onPermAccount value=<%=permAcct%> />
<INPUT type=hidden name=onTempAccount value=<%=tempAcct%> />
<INPUT type="hidden" name="customerSeq" value="<%=customerSeq%>" />

<CENTER>

Primary Route
<BR />
<%
	query = " select distinct route.name, route.routeNumber, customer.customerSequenceNumber from "
	query = query & " route left outer join customer on "
	query = query & " route.routeNumber = customer.routeNumber and customer.customerSequenceNumber = " & customerSeq _
        & " where activeRoute = 1"

	set rs = getdisconnectedrecordset(query)
%>

<SELECT onchange="selectPrimaryRoute(this.value)">
<%
	while not(rs.eof or rs.bof)
%>
	<OPTION value="<%=rs("routeNumber")%>" <%if not isnull(rs("customerSequenceNumber")) then%>selected<%end if%>><%=rs("name")%></OPTION>
<%
		rs.movenext
	wend
	set rs = nothing
%>
</SELECT>

<BR /><BR />
</CENTER>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="newDelivery()">New</BUTTON>
		<% if showClosed then %>
		<% else %>
		<BUTTON disabled name="btnRemove" onclick="removeDelivery()">Remove</BUTTON>
		<BUTTON disabled name="btnEdit" onclick="editDelivery()">Edit</BUTTON>
		<% end if %>
	</SPAN>
	
	<SPAN style="float:right">
		<BUTTON onclick="submitForm()">Exit</BUTTON>
		
	</SPAN>
</DIV>


<TABLE WIDTH="100%" border="0" cellspacing="0" cellpadding="0" class="itable">
	<TR style="background:#CCC;" >
		<TH>&nbsp;</TH>
		<TH>Route Name</TH>
		<TH>Notes</TH>
		<TH>Days</TH>
		<TH>Address</TH>
		<TH>Date</TH>
	</TR>

<%
	dim rowColor
	
	query = "select customerdelivery.*, "
	query = query & " convert(varchar, beginDate, 101) as beginDate, "
	query = query & " isnull(datediff(d, begindate, enddate), -1) as length, "
	query = query & " isnull(deliveryNotes, '') as deliveryNotes, "
	query = query & " isnull(deliveryAddress, '') as deliveryAddress, "
	query = query & " isnull(convert(varchar, endDate, 101), 'unspecified') as endDate, "
	query = query & " route.name as routeName "
	query = query & " from customerdelivery inner join route on "
	query = query & " customerdelivery.routeid = route.routeNumber "
	query = query & " where customersequencenumber = " & customerSeq
	
	if showClosed then
		query = query & " and active = 0"
	else
		query = query & " and active = 1"
	end if
	
	set rs = getdisconnectedrecordset(query)

	rowColor = "white"
				
	while not(rs.eof or rs.bof)
%>
	<TR style="height:30px;background:<%=rowColor%>" onclick="ToggleRowChecked(this);">
	<TD align="center"><INPUT onclick="ToggleRowChecked(this.parentNode.parentNode, '<%=rs("id")%>');" type="radio" name="deliveryId" value="<%=rs("id")%>" /></TD>
	<TD align="center" align="center"><%=rs("routeName")%></TD>
	<TD align="center"><%=replace(rs("deliveryNotes"), vbcrlf, "<br>")%></TD>
	<TD align="center"><%d_routeDays(rs)%></TD>
	<TD align="center"><%=replace(rs("deliveryAddress"), vbcrlf, "<br>")%></TD>
	<TD align="center">
	Valid <%=rs("beginDate")%> to <%=rs("endDate")%>
	<%if rs("length") >= 0 and rs("length") <= 31 then Response.Write " (" & rs("length") + 1 & " Day)" end if%>
	</TD>
	
	</TR>
<%
		if rowColor = "white" then
		    rowColor = "#EEE"
		else
		    rowColor = "white"
		end if
                    
		rs.movenext
	wend
	
	set rs = nothing
%>
</TABLE>


</FORM>   
</BODY>
</HTML>

<%	set custRs = nothing %>
