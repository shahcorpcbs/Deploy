<%@ Language=VBScript %>

<%option explicit%>

<!-- #include file="/include/querydatabase.asp" -->
<!-- #include file="/include/validatefunction.asp" -->

<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>

<%
	'Get all stores and terminals details..
	dim strStoreSQL, strTerminalSQL
	dim adoRS
	strSQL = "SELECT storeID, storeNumber, name FROM Store"
	strTerminalSQL = "SELECT terminalID, name FROM Terminal WHERE storeID = ?"
	
	if Request.Form("Store") <> "" && Request.Form("PageAction") = "GetTerminal" then
		'Get the terminials for Selected Store
	else
		'Display all stores in the list
		Set adoRS = GetDisconnectedRecordset(strStoreSQL)
		If adoRS Is Nothing Or adoRS.EOF then
			Response.Redirect "/include/error.asp"
		End If
	end if
	
%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>Home</title>
	<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">
	<script LANGUAGE="javascript">
	<!--
		function test() {}
	//-->
</script>

	
</head>

<body leftmargin="0" topmargin="0">
<table WIDTH="100%" BGCOLOR="#2F4F4F" ALIGN="center" BORDER="0" CELLSPACING="0" CELLPADDING="1">
	<tr>
		<td STYLE="color:#FFEFD5;background-color:#2F4F4F;">
		<img src="../images/banner.gif" WIDTH="402" HEIGHT="34">
		</td>
		<td STYLE="color:#FFEFD5;background-color:#2F4F4F;">&nbsp;</td>
		<td ALIGN="right" STYLE="color:#FFEFD5;background-color:#2F4F4F;cursor:hand" onClick="javascript:window.close();"><img src="../images/close.gif" WIDTH="105" HEIGHT="49"></td>
	</tr>
</table> 

<form name="TerminalHardwareForm" id="TerminalHardwareForm" method="POST">
	<select name="Store" id="Store">
		<%
		%>
		<option VALUE="<%=  %>"><%=  %>
		<%
		%>
	</select>
</form>

</body>

</html>