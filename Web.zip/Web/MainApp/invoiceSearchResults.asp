<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs



	function generateSelect(searchType, value)
		generateSelect = "SELECT sum(ss.quantity) as typecount, c.customername as customername, c.customerid, dbo.formatPhone(c.mainareacode, c.mainphone) as phone, r.name as routename, c.customerSequenceNumber as customerseq "
		generateSelect = generateSelect & " FROM Customer c INNER JOIN Route r ON c.routeNumber = r.routeNumber INNER JOIN (" & generateCustomerSubSelect(searchType, value) & ") ss ON c.customerSequenceNumber = ss.customerSequenceNumber"
		generateSelect = generateSelect & " GROUP BY c.customerSequenceNumber, c.customerid, c.customername, c.mainareacode, c.mainphone, r.name"
	end function




	function generateCustomerSubSelect(searchType, value)
		select case lcase(searchType)
			case "overdueinvoices"
				generateCustomerSubSelect = "SELECT customersequencenumber, 1 as quantity FROM Ticket WHERE (DATEDIFF(d, dueDate, GETDATE()) >= " & value & ") AND (ticketStatus = 'AC')"
			case "invoicesdue"
				generateCustomerSubSelect = "SELECT customersequencenumber, 1 as quantity FROM Ticket WHERE (DATEDIFF(d, dueDate, GETDATE()) = 0) AND (ticketStatus = 'AC')"
			case "claims"
				generateCustomerSubSelect = "SELECT customersequencenumber, 1 as quantity FROM Claim WHERE (claimStatus = 'O')"
			case "redos"
			
			case "quickinvoices"
				generateCustomerSubSelect = "SELECT customersequencenumber, 1 as quantity FROM Ticket WHERE (ticketStatus = 'AC') AND (invoiceType = 'Q')"
			case "pricechanges"
				generateCustomerSubSelect = "SELECT t.customerSequenceNumber, 1 as quantity FROM Ticket t INNER JOIN TicketLog tl ON t.ticketNumber = tl.ticketNumber WHERE (tl.logType = 'E')"
			case "department"
				generateCustomerSubSelect = "SELECT t.customerSequenceNumber, (tli.quantity * tli.packagedQuantity) as quantity FROM Ticket t INNER JOIN TicketLineItem tli ON t.ticketNumber = tli.ticketNumber WHERE (t.ticketStatus = 'AC') AND (tli.ticketLineType IN ('IT', 'AC')) AND (tli.departmentName IN (" & value & "))"
			case "departmentnotracked"
				generateCustomerSubSelect = "SELECT t.customerSequenceNumber, (tli.quantity * tli.packagedQuantity) as quantity FROM Ticket t INNER JOIN TicketLineItem tli ON t.ticketNumber = tli.ticketNumber WHERE (t.ticketStatus = 'AC') AND (tli.ticketLineType IN ('IT', 'AC')) AND (t.ticketNumber NOT IN (SELECT ticketNumber FROM RackAssignment)) AND (tli.departmentName IN ('" & value & "'))"

		end select
	end function
	

	function getSearchDescription(searchType, value)
		select case lcase(searchType)
			case "overdueinvoices"
				getSearchDescription = "Invoices Overdue " & value & " Days"
			case "invoicesdue"
				getSearchDescription = "Invoices Due Today"
			case "claims"
				getSearchDescription = "Claims"
			case "redos"
				getSearchDescription = "Redos"
			case "quickinvoices"
				getSearchDescription = "Quick Invoices"
			case "pricechanges"
				getSearchDescription = "Invoice Edits"
			case "department"
				getSearchDescription = "Invoices in Department " & value
			case "departmentnotracked"
				getSearchDescription = "Invoices Not Racked in Department " & value
		end select
	end function
	
%>
<HTML>
<HEAD>

<link href="../../script/stylesheet.css" rel="stylesheet" type="text/css">

<style type="text/css">

th {
    padding:3px;
    background:rgb(255,255,255);
    border-bottom:1px solid #CCC;
    font-weight:bold;
    color:#555555;
}


</style>


<SCRIPT LANGUAGE=javascript>
	function viewCustomer(customerseq) {
		parent.GoToCustomer(customerseq);
	}
</SCRIPT>

</HEAD>

<BODY topmargin=0 leftmargin=0 style="background:white">

<FORM id="invoiceSearchResults" name="invoiceSearchResults" action ="" method="Post">


<%
	query = generateSelect(Request.QueryString("type"), Request.QueryString("value"))

	if query <> "" then
		set rs = getdisconnectedrecordset(query)
%>
<TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
	<TR>
		<TH>Customer Name</TH>
		<TH>Phone</TH>
		<TH>Route</TH>
		<TH>Count</TH>
	</TR>
<%
		while not(rs.eof or rs.bof)

%>
	<TR style="height:30px;background:white">
		<TD style="border-bottom:1px solid #B9D3EE"><a href="javascript:viewCustomer('<%=rs("customerseq")%>')" ><%=rs("customername")%></a></TD>
		<TD style="border-bottom:1px solid #B9D3EE"><%=rs("phone")%></TD>
		<TD style="border-bottom:1px solid #B9D3EE"><%=rs("routename")%></TD>
		<TD style="border-bottom:1px solid #B9D3EE"><%=rs("typecount")%></TD>
	</TR>
<%
			rs.movenext
		wend	
%>
</TABLE>
<%
	end if
%>


</FORM>

</BODY>
</HTML>
