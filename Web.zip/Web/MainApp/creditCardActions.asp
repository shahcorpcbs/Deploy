<%@ Language=VBScript %>
<%option explicit%>

<!--#include file="../include/QueryDatabase.asp"-->
<!--#include file="../include/ValidateFunction.asp"-->

<!--#include file="../include/json.asp"-->

<!--#include file="../include/manifest.asp"-->
<%
	dim query, rs
	dim limit
	dim start
	
	if request.form("limit") <> "" then
		limit = request.form("limit")
	else
		limit = null
	end if
	
	if request.form("start") <> "" then
		start = request.form("start")
	else
		start = null
	end if
	
	
	select case lcase(request.form("transtype"))
	case "purchase"
		response.write CardPurchase()
	case "add"
		response.write AddCardOnFile()
	case "update"
		response.write UpdateCardOnFile()
	case "delete"
		response.write DeleteCardOnFile()
	end select
		
	select case lcase(request.form("transactiontype"))
	case "purchase"
		response.write completeTransaction(request.form("xcresponse"))
	case "cardpurchase"
		CardPurchase
	case "begintransaction"
		response.write beginTransaction
	case "getstatus"
		response.write getTransactionStatus
	case "closetransaction"
		response.write closeTransaction
	
	end select

	
	class XcSettings
		dim XChargeDirectoryKeyed
		dim XChargeDirectory
		dim XChargeTimeout
	end class
	
	function LoadSettings(storeid, settings)
		dim query, rs
		
		query = " select xchargepath, xchargepathkeyed, xchargetimeout from miscsetup where storeid = " & storeid
		set rs = getdisconnectedrecordset(query)
		
		LoadSettings = false
		
		if rs.recordcount > 0 then
			settings.XChargeDirectory = rs("xchargepath")
			settings.XChargeDirectoryKeyed = rs("xchargepathkeyed")
			settings.XChargeTimeout = rs("xchargetimeout")
			LoadSettings = true
		end if
	
		set rs = nothing
	end function
	
	
	function GetXcProcessor()
		dim processor
		dim settings
		
		set settings = new XcSettings
		LoadSettings session("storeid"), settings
		
		set processor = server.createobject("ShahCorpComponents.creditCardProcessing")
		processor.XChargeDirectory = settings.XChargeDirectory
		processor.XChargeTimeout = settings.XChargeTimeout
		processor.DBConnectionString = Session("shahcorpDSN")
		
		set GetXcProcessor = processor
	end function
	
	function AddCardOnFile()
		dim account
		dim expiration
		dim customerseq


		dim jsonResult
		dim result
		dim message
		dim processor
		

		account = request.form("account")
		expiration = request.form("exp")
		customerseq = request.form("customerseq")

		set processor = GetXcProcessor()

		result = processor.AddCardOnFile(customerseq, account, expiration)

		jsonResult = "{ "
		
		if result <> "" then
			jsonResult = jsonResult & "success: ""1"", "
		else
			jsonResult = jsonResult & "success: ""0"", "
		end if
		
		jsonResult = jsonResult & "accountid: """ & result & """, "
		jsonResult = jsonResult & "description: """ & processor.GetLastMessage() & """, "
		jsonResult = jsonResult & "action: ""add"" "
		jsonResult = jsonResult & "}"
		
		AddCardOnFile = jsonResult
	end function
	
	function UpdateCardOnFile()
		dim accountid
		dim expiration

		dim jsonResult
		dim result
		dim processor
		

		accountid = request.form("xcaccountid")
		expiration = request.form("exp")

		set processor = GetXcProcessor()

		result = processor.UpdateCardOnFile(accountid, expiration)

		jsonResult = "{ "
		
		if result then
			jsonResult = jsonResult & "success: ""1"", "
		else
			jsonResult = jsonResult & "success: ""0"", "
		end if
		jsonResult = jsonResult & "description: """ & processor.GetLastMessage() & """, "
		jsonResult = jsonResult & "action: ""update"" "
		jsonResult = jsonResult & "}"
		
		UpdateCardOnFile = jsonResult
	end function
	
	
	function DeleteCardOnFile()
		dim accountid

		dim jsonResult
		dim result
		dim processor
		

		accountid = request.form("xcaccountid")

		set processor = GetXcProcessor()

		result = processor.DeleteCardOnFile(accountid)

		jsonResult = "{ "
		
		if result then
			jsonResult = jsonResult & "success: ""1"", "
		else
			jsonResult = jsonResult & "success: ""0"", "
		end if
		jsonResult = jsonResult & "description: """ & processor.GetLastMessage() & """, "
		jsonResult = jsonResult & "action: ""delete"" "
		jsonResult = jsonResult & "}"
		
		DeleteCardOnFile = jsonResult
	end function
	
	function CardPurchase()
		dim clerk
		dim receipt
		dim account
		dim expiration
		dim amount
		dim cvv
		dim merchantid
		dim track

		dim jsonResult
		dim result
		dim message
		dim processor
		
		
		clerk = request.form("clerk")
		receipt = request.form("receipt")
		account = request.form("account")
		expiration = request.form("expiration")
		amount = request.form("amount")
		cvv = request.form("cvv")
		merchantid = request.form("merchantid")
		track = request.form("track")

		set processor = GetXcProcessor()

		result = processor.CardPurchase(account, expiration, track, amount, receipt)

		jsonResult = "{ "
		
		if result <> "" then
			jsonResult = jsonResult & "success: ""1"", "
		else
			jsonResult = jsonResult & "success: ""0"", "
		end if
		
		jsonResult = jsonResult & "code: """ & result & """, "
		jsonResult = jsonResult & "description: """ & processor.GetLastMessage() & """ "
		jsonResult = jsonResult & "}"
		
		CardPurchase = jsonResult
	end function
	

	function completeTransaction(xcresponse)
		dim xmlDoc
		dim resultNode
		dim approvalNode
		dim accountTypeNode
		dim amountNode
		dim result
		dim resultText
		dim approvalText
		dim accountTypeText
		dim amountText

		set xmlDoc = server.createobject("MSXML2.DOMDocument")

	    if not xmlDoc.loadXML(xcresponse) then
			result = "{ "
			result = result & "success: ""0"", "
			result = result & "result: """ & JSEncode("Invalid XML") & """ "
			result = result & "}"
	    else
			set resultNode = xmlDoc.selectSingleNode("//XCEXPRESSLINKRESULT/RESULT")
			set approvalNode = xmlDoc.selectSingleNode("//XCEXPRESSLINKRESULT/APPROVALCODE")
			set accountTypeNode = xmlDoc.selectSingleNode("//XCEXPRESSLINKRESULT/ACCOUNTTYPE")
			set amountNode = xmlDoc.selectSingleNode("//XCEXPRESSLINKRESULT/AMOUNT")
			if resultNode is nothing then resultText = "" else resultText = resultNode.text
			if approvalNode is nothing then approvalText = "" else approvalText = approvalNode.text
			if accountTypeNode is nothing then accountTypeText = "" else accountTypeText = accountTypeNode.text
			if amountNode is nothing then amountText = "" else amountText = amountNode.text

			result = "{ "
			if approvalText <> "" then
				result = result & "success: ""1"", "
			else
				result = result & "success: ""0"", "
			end if
			result = result & "result: """ & JSEncode(resultText) & """, "
			result = result & "approval: """ & JSEncode(approvalText) & """, "
			result = result & "amount: """ & JSEncode(amountText) & """, "
			result = result & "cctypename: """ & JSEncode(accountTypeText) & """, "
			result = result & "cctypeid: """ & JSEncode(getCardTypeID(accountTypeText)) & """ "
			result = result & "}"
		end if

		completeTransaction = result
	end function

	function getCardTypeID(cardTypeName)
		dim query, rs

		query = "select creditcardtypeid from creditcardtypedomain where name = '" & cardTypeName & "'"
		set rs = getdisconnectedrecordset(query)

		getCardTypeID = 0

		if rs.recordcount > 0 then
			getCardTypeID = rs("creditcardtypeid")
		end if

		set rs = nothing
	end function

	function returnResult(success, answer)
		dim result
		
		result = "{ "
		result = result & "success: """ & JSEncode(success) & """, "
		result = result & "answer: """ & JSEncode(answer) & """ "
		result = result & "}"
		
		returnResult = result
	end function

	function JSEncode(s)
		on error resume next
		if not isnull(s) then
			JSEncode = s
			JSEncode = Replace(JSEncode, "\", "\\") 
			JSEncode = Replace(JSEncode, """", "\""")
			JSEncode = Replace(JSEncode, vbCr, "\r")
			JSEncode = Replace(JSEncode, vbLf, "\n")
		end if
	end function 



%>