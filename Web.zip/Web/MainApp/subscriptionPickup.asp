<%@ Language=VBScript %>
<%option explicit%>
<%
	dim dbname
	
	dbname = request.querystring("dbname")
	if dbname = "" then dbname = "default"
%>

<!--#include file="../include/SystemStartup.asp"-->
<% selectDatabase dbname %>

<!--#include file="../include/QueryDatabase.asp"-->
<!-- #include file="../include/ValidateFunction.asp" -->

<%

        dim pickupObj

        set pickupObj = Server.CreateObject("ShahCorpComponents.pickup")
        pickupObj.initPickupObject
        pickupObj.DBConnectionString = Session("shahcorpDSN")
        pickupObj.storeId = request.querystring("storeId")
        pickupObj.initStorePaymentTypeInfo()
        pickupObj.userAction = "pickup"
        pickupObj.custSeqNumber = request.querystring("custSeqNumber")
        pickupObj.addInvoiceToPickup request.querystring("ticketNumber")

        pickupObj.addPayment request.querystring("amt"), "On Account"
        pickupObj.applyPayments 1, 1, pickupObj.constructTicketNosString() , -1




%>

