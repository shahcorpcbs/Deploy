<%@ Language=VBScript %>
<%option explicit %>
<% Server.ScriptTimeout = 900 %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->
<!--#include file="../include/services.asp" -->
<%sec_RequestAccess Request.QueryString("userAction")%>
<%
	dim query, rs
	dim showOldInDays
    dim cnt, pagenum, idx

	showOldInDays = getReqVar("days")
	pagenum = Request.QueryString("pagenum")
	if pagenum = "" then pagenum = 1

	select case lcase(request.querystring("useraction"))
	case "remove"
		removeMarkedMessages
	end select
	
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
	
	function removeMarkedMessages() 
		
		dim query, rs
		
		query = "delete emailqueue where messageID in (" & Request.form("selectedMessageID") & ")"
		qryexecute query

	end function

%>

<HTML>
<HEAD>
<TITLE>Send Email</TITLE>
<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">
</HEAD>

<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>
<SCRIPT language="javascript" type="text/javascript">

	var matchedMessageArray = null;
	var matchedIndex = 0;
	
	
	function sendEmail() {
		matchedMessageArray = $("input[name='selectedMessageID']:checked").get();
        var msgIds = "";
        for (i = 0; i < matchedMessageArray.length; i++) {
            var message = matchedMessageArray[i];
            msgIds += message.value + ",";
        }
        console.log(msgIds)

        var url = "<%=getMessengerFullPath("main")%>/sendEmailQueueMsg?" +
            "&employeeId=<%=session("employeeid")%>";
        $.ajax({
            type: "POST",
            url: url,
            data :msgIds,
            contentType: "text/plain",
            Accept: "text/plain",
            timeout: "120000",
            success: function(xhr) {
                cbs_alert("Email request sent to CBS Service");
            },
            error: function(xhr, ajaxOptions, thrownError) {
                console.log(xhr);
                cbs_alert("Error sending email request to CBS Service, make sure service is running");
            }
        });
	}
	
	function sendNextEmail() {
		if(matchedIndex >= matchedMessageArray.length) {
			return;	
		}
		else {
			var message = matchedMessageArray[matchedIndex];
			var messageID = messageID = message.value;
			
			++matchedIndex;
			
			jQuery.getJSON("sendEmailMessage.asp?messageID=" + messageID,
				function(data){
					$("input[selectedMessageID='" + messageID + "']").val(data.answer);

					if(data.success != "0") {
						$("input[selectedMessageID='" + messageID + "']").css("background-color", "lightgreen");
					}
					else {
						$("input[selectedMessageID='" + messageID + "']").css("background-color", "red");
					}
					
					setTimeout('sendNextEmail()', 100);
			});
		}
	}

	function removeEmail() {
        cbs_confirm("Remove selected messages?", doRemove)
	}

	function doRemove() {
        clearConfirmMsg();
	    document.sendemail.action = "?useraction=remove"
        document.sendemail.submit();
	}


	function exit() {
		document.sendemail.action = "marketingMenu.asp";
		document.sendemail.submit();
	}
	function SetRowCheckedStatus(row, check, value) {

		if(check.disabled)
			return;
			
		if(value)
		{
			check.checked = true;
			row.className = "selected";
		}
		else
		{
			check.checked = false;
			row.className = "";
		}
	}
	
	function ToggleRowChecked(r) {
		var childEl;
		var rowChildNodes = r.children;

		for(i=0; i<rowChildNodes.length; i++){
			childEl = rowChildNodes[i];

			if (childEl.children[0] && childEl.children[0].name == "selectedMessageID") {
				SetRowCheckedStatus(r, childEl.children[0], !(childEl.children[0].checked));
				break;
			}
			else if (childEl.name == "selectedMessageID") {
				SetRowCheckedStatus(r, childEl, !(childEl.checked));
				break;
			}
		}
	}

	function selectAllMessages() {
		var il = document.sendemail;
		var len = il.elements.length;
		var i, e;
		
		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "selectedMessageID") {
					SetRowCheckedStatus(e.parentNode.parentNode, e,  true);
		    }
		}
	}

	function deselectAllMessages() {
		var il = document.sendemail;
		var len = il.elements.length;
		var i, e;
		
		for (i = 0; i < len; i++) {
		    e = il.elements[i];
		    if (e.name == "selectedMessageID") {
					SetRowCheckedStatus(e.parentNode.parentNode, e,  false);
		    }
		}
	}
	
	function showSelectOptions() {
		btnShowSelectOptions.style.display = "none";
		selectOptions.style.display = "block";
	}
	function selectMessages(o) {
		deselectAllMessages();
		$("tr[source=" + o.value + "]").each(function(i) {
			ToggleRowChecked(this);
		});
	}

	function viewMessagesSent(days) {
		document.sendemail.action = "?useraction=view&days=" + days;
		document.sendemail.submit();
	}
	function viewEmail() {
		var messageID;

		$("input[name='selectedMessageID']:checked").each(function (i) {
			messageID = this.value;
		});

		var w = window.open("/mainapp/viewemail.asp?messageid=" + messageID, "Email", "status=no,fullscreen=no,scrollbars=yes,width=600,height=600");

	}


	function nextPage() {
		document.sendemail.action  = "?pagenum=" + (parseInt(document.sendemail.pagenum.value) + 1);
		document.sendemail.submit();
	}

	function prevPage() {
		document.sendemail.action  = "?pagenum=" + (parseInt(document.sendemail.pagenum.value) - 1);
		document.sendemail.submit();
	}

	function goToPage(pagenumber) {
		document.sendemail.action  = "?pagenum=" + pagenumber;
		document.sendemail.submit();
	}

</SCRIPT>

<BODY topmargin=0 leftmargin=0 onload="selectAllMessages()">
<!-- #include file="../include/banner.inc" -->

<FORM name="sendemail" ID="sendemail" METHOD=POST  style="margin:0;padding:0" onSubmit="return false;">
<input type=hidden name="pagenum" value="<%= pagenum%>">

<H1>Outgoing Messages</H1><BR />
<BR />

<DIV style="text-align:center;margin:10;">
Show messages
<SELECT name="showOldInDays" onchange="viewMessagesSent(this.value);">
	<OPTION value=""  <%if showOldInDays = "" then%>selected<%end if%>>Not Sent</OPTION>
	<OPTION value="0"  <%if showOldInDays = "0" then%>selected<%end if%>>Sent Today</OPTION>
	<OPTION value="7"  <%if showOldInDays = "7" then%>selected<%end if%>>Sent Within 7 Days</OPTION>
	<OPTION value="30" <%if showOldInDays = "30" then%>selected<%end if%>>Sent Within 30 Days</OPTION>
	<OPTION value="90" <%if showOldInDays = "90" then%>selected<%end if%>>Sent Within 90 Days</OPTION>
</SELECT>
</DIV>

<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">
	<SPAN style="float:left">
		<BUTTON onclick="sendEmail()" value="" >Send</BUTTON>
		<BUTTON onclick="removeEmail()" value="" >Remove</BUTTON>
		<BUTTON onclick="viewEmail()" value="">View</BUTTON>
	</SPAN>
	<SPAN name="btnShowSelectOptions" id="btnShowSelectOptions" style="float:left;">
		<BUTTON  onclick="showSelectOptions()" value="" >Select...</BUTTON>
	</SPAN>
	<SPAN style="float:right">
		<BUTTON onclick="exit()" value="" >Exit</BUTTON>
	</SPAN>
</DIV>	

<DIV name="selectOptions" id="selectOptions" class="cmdbar" style="margin-bottom:0;display:none;text-align:center">
		<BUTTON onclick="deselectAllMessages()" value="" >None</BUTTON>
		<BUTTON onclick="selectAllMessages()" value="" >All</BUTTON>

<%
	query = " select distinct [source] from emailqueue where sentdate is null and [source] is not null and [source] <> '' "
	set rs = getdisconnectedrecordset(query)
	
	while not (rs.eof or rs.bof)
%>
		<INPUT type="button" style="height:50px" onclick="selectMessages(this)" value="<%=Server.HTMLEncode(rs("source"))%>" ></INPUT>
<%
		rs.movenext
	wend
	set rs = nothing

%>
</DIV>	


<TABLE class="itable" cellspacing="0">
	<TR>
		<TH>&nbsp;</TH>
		<TH>Date Created</TH>
		<TH>To</TH>
		<TH>Subject</TH>
		<TH>Source</TH>
		<TH>Status</TH>
	</TR>
<%
	query = " select isnull('Sent ' + convert(varchar, sentdate, 101), '') as sentdate, messageid, createddate, isnull('<' + toname + '> ', '') + toaddress as toname, isnull(subjectline, '') as subjectline, isnull(source, '') as source "
	query = query & " from emailqueue "

	if showOldInDays = "" then
		query = query & " where (sentdate is null) "
	else

		query = query & " where (datediff(day, sentdate, getdate()) <= " & showOldInDays & ") "
	end if

    query = query & " order by createddate desc"
	set rs = getdisconnectedrecordset(query)
	cnt = rs.recordcount
	rs.pagesize = 40
	if cnt > 0 then
        rs.absolutepage = pagenum
    end if


	while not (rs.eof or rs.bof) and idx < rs.pagesize
%>
	<TR name="selectedMessage" onclick="ToggleRowChecked(this)" source="<%=Server.HTMLEncode(rs("source"))%>">
		<TD><INPUT name="selectedMessageID" type="checkbox" value="<%=rs("messageid")%>"  onclick="ToggleRowChecked(this.parentNode.parentNode);" /></TD>
		<TD><%=rs("createddate")%></TD>
		<TD><%=rs("toname")%></TD>
		<TD><%=rs("subjectline")%></TD>
		<TD><%=Server.HTMLEncode(rs("source"))%></TD>
		<TD><INPUT name="status" style="text-align: center; width:150px" selectedMessageID="<%=rs("messageid")%>" <%if rs("sentdate") <> "" then%>style="background-color:yellow"<%end if%>  value="<%=rs("sentdate")%>" readonly />
	</TR>
<%

    idx = idx + 1
	rs.movenext
	wend
%>
</TABLE>
<%
				if rs.pagecount > 1 then
%>
				<span style="float:left">
				<button style="height:50px;width:80px" onclick="prevPage()" <% if pagenum = 1 then %>disabled <%end if %>>Prev</button>
				<button style="height:50px;width:80px" onclick="nextPage()" <% if cInt(pagenum) = rs.pagecount then %>disabled <%end if %>>Next</button>

				Page
				<select onchange="goToPage(this.value)" >
<%
				for idx = 1 to rs.pagecount
%>
					<option value="<%=idx%>" <%if trim(idx) = trim(pagenum) then%>selected<%end if%>><%=idx%></option>
<%
				next
%>
				</select>
				of <%=rs.pagecount%>
				</span>
<%
				end if
%>
</FORM>

</BODY>
</HTML>

