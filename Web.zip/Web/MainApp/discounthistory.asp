<%@ Language=VBScript %>

<!--#include file="../include/QueryDatabase.asp"-->

<%
    dim filtertype
    dim filterdays
    dim customerseq

    dim query, rs
    
    
    filtertype = getReqVar("filtertype")
    filterdays = getReqVar("filterdays")
    customerseq = getReqVar("customerseq")
    
    if filtertype = "" then filtertype = 0
    if filterdays = "" then filterdays = 31
    
    if customerseq = "" then customerseq = 1
    
	function getReqVar(id)
		if Request.QueryString(id) <> "" then
			getReqVar = Request.QueryString(id)
		else
			getReqVar = Request.Form(id)
		end if
	end function
    
    function getFilterForSearch(filtertype, days)
        select case filtertype
        case 0
            getFilterForSearch = "ticketlineitem.ticketlinetype in ('CU', 'PR') "
        case 1
            getFilterForSearch = "ticketlineitem.ticketlinetype in ('CU') "
        case 2
            getFilterForSearch = "ticketlineitem.ticketlinetype in ('PR') "
        end select
        
        getFilterForSearch = getFilterForSearch & " and datediff(day, ticket.createddate, getdate()) <= " & days
    end function
    
    function getCustomerName(customerseq)
        dim query, rs
        
        query = "select customername from customer where customersequencenumber = " & customerseq
        set rs = getdisconnectedrecordset(query)
        
        getCustomerName = rs("customername")
        
        set rs = nothing
    end function
%>


<HTML>
<HEAD>

<LINK href="../script/stylesheet.css" rel="stylesheet" type="text/css">
<LINK href="../script/greyscale.css" rel="stylesheet" type="text/css">

<script language="javascript" type="text/javascript">

    function selectFilterType() {
        document.discountHistory.action = "?useraction=selectfilter";
        document.discountHistory.submit();
    }
    
    function selectFilterDays() {
        document.discountHistory.action = "?useraction=selectdays";
        document.discountHistory.submit();
    }
    
    function exitForm() {
        document.discountHistory.action = "/MainApp/customerdiscount.asp?targetpage=customerentry&customerseq=<%=customerseq%>"
        document.discountHistory.submit();
    }
</script>


</HEAD>

<BODY STYLE="margin:0;padding:0" onload="">
<!-- #include file="../include/banner.inc" -->


<H1>Discounts For <%=Server.HTMLEncode(getCustomerName(customerseq))%></H1>

<FORM id="discountHistory" name="discountHistory" method="post">


<INPUT type="hidden" name="customerseq" value="<%=customerseq%>">


<CENTER>
    <SELECT name="filtertype" id="filtertype" onchange="selectFilterType();">
        <OPTION value="0" <%if filtertype = "0" then%>selected<%end if%>>Coupons and Promotions</OPTION>
        <OPTION value="1" <%if filtertype = "1" then%>selected<%end if%>>Coupons Only</OPTION>
        <OPTION value="2" <%if filtertype = "2" then%>selected<%end if%>>Promotions Only</OPTION>
    </SELECT>
    
    <SELECT name="filterdays" id="filterdays" onchange="selectFilterDays();">
        <OPTION value="1" <%if filterdays = "1" then%>selected<%end if%>>Day</OPTION>
        <OPTION value="7" <%if filterdays = "7" then%>selected<%end if%>>Week</OPTION>
        <OPTION value="31" <%if filterdays = "31" then%>selected<%end if%>>Month</OPTION>
        <OPTION value="93" <%if filterdays = "93" then%>selected<%end if%>>Quarter</OPTION>
        <OPTION value="365" <%if filterdays = "365" then%>selected<%end if%>>Year</OPTION>
        <OPTION value="3650" <%if filterdays = "3650" then%>selected<%end if%>>All</OPTION>
    </SELECT>

</CENTER>


<BR>


<DIV name="cmdbar" id="cmdbar" class="cmdbar" style="margin-bottom:0;">

	
	<SPAN style="float:right">
		<BUTTON onclick="exitForm()">Exit</BUTTON>
	</SPAN>
</DIV>	

<TABLE class="itable" align=center WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0>

<TR>
    <TH align="left">Created Date</TH>
    <TH align="left">Invoice Number</TH>
    <TH align="left">Employee</TH>
    <TH align="left">Department</TH>
    <TH align="left">Type</TH>
    <TH align="left">Name</TH>
    <TH align="right">Invoice Total</TH>
    <TH align="right">Discount</TH>
    <TH align="right">Net Total</TH>
</TR>

<%
    dim totalGross
    dim totalLineItem
    dim totalNet
    
    totalGross = 0
    totalLineItem = 0
    totalNet = 0

    query = " select "
    query = query & " ticket.invoicenumber, "
    query = query & " ticketlineitem.ticketlinetype, "
    query = query & " convert(varchar, ticket.createddate, 101) as createddate, "
    query = query & " ticketlineitem.departmentname, "
    query = query & " ticketlineitem.lineitemname, "
    query = query & " ticketlineitem.lineitemtotal, "

    query = query & " ticket.totalDiscountAmount, "
    query = query & " ticket.totalGrossAmount, "
    query = query & " employee.employeename, "
    query = query & " ticket.nettotal "
    
    query = query & " from "
    query = query & " ticket inner join ticketlineitem "
    query = query & " on ticket.ticketnumber = ticketlineitem.ticketnumber "
    query = query & " inner join employee "
    query = query & " on ticketlineitem.createdByEmployeeID = employee.employeeid "
    query = query & " where ticket.customersequencenumber = " & customerseq
    query = query & " and " & getFilterForSearch(filtertype, filterdays)
    
    set rs = getdisconnectedrecordset(query)
    
    while not(rs.eof or rs.bof)
%>
    <TR>
        <TD><%=rs("createddate")%></TD>
        <TD><%=rs("invoicenumber")%></TD>
        <TD><%=rs("employeename")%></TD>

        <TD><%=rs("departmentname")%></TD>
        <TD><%if rs("ticketlinetype") = "CU" then%>Coupon<%elseif rs("ticketlinetype") = "PR" then%>Promotion<%else%>Unknown<%end if%></TD>
        <TD><%=rs("lineitemname")%></TD>

        <TD align="right"><%=formatcurrency(rs("totalGrossAmount"))%></TD>
        <TD align="right"><%=formatcurrency(rs("lineitemtotal"))%></TD>

        <TD align="right"><%=formatcurrency(rs("nettotal"))%></TD>
    </TR>
<%

        totalGross = totalGross + rs("totalGrossAmount")
        totalLineItem = totalLineItem + rs("lineitemtotal")
        totalNet = totalNet + rs("nettotal")
        
        rs.movenext
    wend
    
%>
    <TR style="background:#EEE">
        <TD colspan=6><B>Total</B></TD>

        <TD align="right"><B><%=formatcurrency(totalGross)%></B></TD>
        <TD align="right"><B><%=formatcurrency(totalLineItem)%></B></TD>

        <TD align="right"><B><%=formatcurrency(totalNet)%></B></TD>
    </TR>
<%
    
    set rs = nothing
%>

</TABLE>

</FORM>
</BODY>
</HTML>
