<html>
<head>
    <title>Error</title>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
</head>

<body bgcolor="#ffffff" text="#000000" marginheight=10 marginwidth=10 alink="#999966" vlink="#999966" link="#999966">

<blockquote><font face=arial>
We are sorry, but we are unable to process your request:
<br>
<ul>
	<font color="#ff0000" face=arial>
	<% 
		dim errorList
		dim errorstr
		dim element
		set errorList = Server.CreateObject("Scripting.Dictionary")
		set errorList = Session("errorList")
		errorstr = errorList.Keys
		for each element in errorstr %>
		<li><%=	errorList(element) %></li>
	<% next	
		set Session("errorList") = nothing
	%>
	
	</font>
</ul>
If possible, please go back and correct the problem and try again.
</blockquote></FONT>
<TABLE>
	<TR><TD align = center>
		<INPUT name=cancelButton type=button value="Back" style = "margin-left = 300px;" onclick="history.back(-1)">
	</TR></td>
	</TABLE>
</body>
</html>
		