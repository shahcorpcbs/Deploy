<%
Public Const RPT_NBR_Account_Balance = 26
Public Const RPT_NBR_AR_Ageing = 47
Public Const RPT_NBR_AR_MultiPickup_Statement = 27
Public Const RPT_NBR_AR_Statement = 25
Public Const RPT_NBR_Cash_Out = 2
Public Const RPT_NBR_Cash_Out_Z_Report = 1
Public Const RPT_NBR_Override_CashOut_Z_Report = 39
Public Const RPT_NBR_Claim_Report = 30
Public Const RPT_NBR_Coupon_Analysis_DateOut = 11
Public Const RPT_NBR_Coupon_Analysis_Created = 43
Public Const RPT_NBR_Credit_Card_Expiration_Report = 31
Public Const RPT_NBR_Daily_Report = 36
Public Const RPT_NBR_Daily_Report_Boston = 38
Public Const RPT_NBR_Delivery_List = 17
Public Const RPT_NBR_Delivery_Manifest = 18
Public Const RPT_NBR_Detail_of_Tickets_Brought_In = 20
Public Const RPT_NBR_Detailed_Report = 35
Public Const RPT_NBR_Employee_Audit_Summary = 4
Public Const RPT_NBR_Employee_Detail = 5
Public Const RPT_NBR_Employee_Sales_incoming = 12
Public Const RPT_NBR_Employee_Time = 3
Public Const RPT_NBR_Galaxie_Daily = 48
Public Const RPT_NBR_Hourly_Sales_Report = 13
Public Const RPT_NBR_Incoming_Detail_by_Creation = 7
Public Const RPT_NBR_Incoming_Detail_by_Due_Date = 8
Public Const RPT_NBR_Incoming_Summary = 6
Public Const RPT_NBR_Incoming_Summary_Riaz = 41
Public Const RPT_NBR_Invoice_Detail = 22
Public Const RPT_NBR_Invoices_Racked = 24
Public Const RPT_NBR_Item_Tracking = 16
Public Const RPT_NBR_Mailing_Label = 32
Public Const RPT_NBR_Management_Tasks = 46
Public Const RPT_NBR_Marketing_List = 33
Public Const RPT_NBR_Outgoing_Detail = 10
Public Const RPT_NBR_Outgoing_Summary = 9
Public Const RPT_NBR_Outgoing_Summary_Riaz = 42
Public Const RPT_NBR_Prepay_Invoices_With_Balance = 44
Public Const RPT_NBR_Rack_History = 23
Public Const RPT_NBR_Route_Payment_Detail = 19
Public Const RPT_NBR_Sales_Comparison = 14
Public Const RPT_NBR_Sales_Detail_by_Payment_Date = 29
Public Const RPT_NBR_Sales_Report = 15
Public Const RPT_NBR_Sales_Summary_By_Payment_Types = 28
Public Const RPT_NBR_Tickets_Need_to_be_Finished = 21
Public Const RPT_NBR_Tickets_Need_to_be_Finished_Summary = 49
Public Const RPT_NBR_Tracking_Report = 40
Public Const RPT_NBR_Sales_Discount_Details = 45
Public Const RPT_NBR_Void_Details = 50
Public Const RPT_NBR_Weekly_Sales = 51
Public Const RPT_NBR_New_Customers = 52
Public Const RPT_NBR_Employee_Tasks = 53
Public Const RPT_NBR_Commercial_Statement = 54
Public Const RPT_NBR_Suspicious_Activity = 55
Public Const RPT_NBR_Top_Customers = 56
Public Const RPT_NBR_Detailed_Invoice_byTime = 57
Public Const RPT_NBR_Hourly_IncomingOutgoing_Sales = 58
Public Const RPT_NBR_Item_Notes = 59
Public Const RPT_NBR_PromotionAnalysis_DateOut = 60
Public Const RPT_NBR_PromotionAnalysis_DateCreated = 61
Public Const RPT_NBR_CD_DailyActivity = 62
Public Const RPT_NBR_EmployeeTimeWBreaks = 63
Public Const RPT_NBR_RedoReport = 64
Public Const RPT_NBR_DetailedRacking = 65
Public Const RPT_NBR_MiscCreditsCharges = 66
Public Const RPT_NBR_PickedUpInvoices = 67
Public Const RPT_NBR_TicketsNotOnLot = 68
Public Const RPT_NBR_TaxAndSurcharge = 69
Public Const RPT_NBR_OutgoingParkAve = 70
Public Const RPT_NBR_IncomingDelRey = 71
Public Const RPT_NBR_ARStatementCR = 72
Public Const RPT_NBR_AgeingCR = 73
Public Const RPT_NBR_CustomerCode = 74
Public Const RPT_NBR_CD_DailyActivity2 = 75
Public Const RPT_NBR_HakuyoshaTracer = 76
Public Const RPT_NBR_AR_HakuyoshaHotel = 77
Public Const RPT_NBR_CD_Productivity = 78
Public Const RPT_NBR_Ext_App_Exception = 79

'	Which module is calling the report engine.
Public Const RPT_Requester_Name_Report = "RPT"
Public Const RPT_Requester_Name_Employee = "EMPLOYEE"
Public Const RPT_Requester_Name_Statement_Run = "STMT_RUN"
Public Const RPT_Requester_Name_Statement_History = "STMT_HISTORY"
Public Const RPT_Requester_Name_Schedule = "SCHEDULE"
Public Const RPT_Requester_Name_Route = "ROUTE"

' What is the format in which the report is displayed?
Public Const RPT_Report_Format_HTML = "HTML"
Public Const RPT_Report_Format_TEXT = "TEXT"

public RPT_NBR_Credit_Card_Batch_Process

RPT_NBR_Credit_Card_Batch_Process = getCCBatchReportID()

function GetReportParams( reportID, refreshCurrentReportParams, requesterName, scheduleID) 

	'On Error Resume Next
	
	dim bRecreateParams
	dim returnStatus
	
	dim storeID 
	dim employeeID
	
	bRecreateParams = True
	
	If  TypeName(Session("objRP")) <> "Nothing" And TypeName(Session("objRP")) <> "Empty" Then
		If Not Session("objRP") is nothing Then
			If refreshCurrentReportParams = False Then
				If Session("objRP").reportNumber = reportID Then
					If scheduleID < 1 Then
						bRecreateParams = False
					End If
				End If
			End If
		End If
	End If

	If bRecreateParams = True Then
		Set Session("objRP") = Nothing
		set Session("objRP") = Server.CreateObject("CBSReports.clsParams")
		
		Session("objRP").reportNumber = reportID
		Session("objRP").scheduleID = scheduleID

		Session("objRP").dbConnectString = Session("shahcorpDSN")
		Session("objRP").dBCommandTimeout = 0

		storeID = IIf(Trim(Session("storeID")) = "", 0, CLng(Session("storeID")))
		Session("objRP").storeID = storeID
		Session("objRP").sessionStoreID = storeID

		employeeID = IIf(Trim(Session("employeeID")) = "", 0, CLng(Session("employeeID")))

		Session("objRP").employeeID = 0
		Session("objRP").sessionEmployeeID = employeeID

		Session("objRP").customerSequenceNumber = 0

		'if not isNull(session("customersequencenumber")) then
		'	if Trim(session("customersequencenumber")) <> "" And isNumeric(session("customersequencenumber")) then
		'		Session("objRP").customerSequenceNumber = CLng(session("customersequencenumber"))
		'	end if
		'end if
		
		Session("objRP").currentReportFile = Server.MapPath("/") & "\ReportOutFiles\" & Session.SessionID & "_" & Session("objRP").reportNumber
		Session("objRP").currentReportExtension = ".htm"
		
		Call Session("objRP").RetrieveParams(0, true)
		
		If scheduleID > 0 Then
			Call Session("objRP").RetrieveSchedule()
		End If
				
		GetReportParams = "NEW"
		
	Else

		GetReportParams = "OLD"

	End If
	
'	Response.Write  " requesterName : " & requesterName
	
	
'	Response.End

	if Trim(requesterName) = "" then
		Session("objRP").requesterName = RPT_Requester_Name_Report
	else
		Session("objRP").requesterName = Trim(requesterName)
	end if

end function

public function UpdateSessionParams()
Dim reportDisplayASPURL
Dim reportID
Dim pickUpTime

FillParams

Session("objRP").accountStatementID = IIf(isNumeric(Request.QueryString("accountStatementID")), Request.QueryString("accountStatementID"), 0)

Session("objRP").reportAction = Request.QueryString("reportAction")

Session("objRP").reportFormat = Request.Form("reportFormat")
if Session("objRP").reportFormat = "" then
	Session("objRP").reportFormat = RPT_Report_Format_HTML
end if

reportID = IIf(Trim(Request.Form("reportID")) = "", 0, Request.Form("reportID"))
if reportID = 0 then
	reportID = IIf(Trim(Request.QueryString("reportID")) = "", 0, Request.QueryString("reportID"))
end if

Session("objRP").reportNumber = reportID
Session("objRP").customerSequenceNumber = IIf(Trim(Request.Form("customerSequenceNumber")) = "", 0, Request.Form("customerSequenceNumber"))
Session("objRP").priceListID = IIf(Trim(Request.Form("priceListID")) = "", 0, Request.Form("priceListID"))
Session("objRP").routeNumber = IIf(Trim(Request.Form("routeNumber")) = "", 0, Request.Form("routeNumber"))
Session("objRP").routeGroup = IIf(Trim(Request.Form("routeGroup")) = "", 0, Request.Form("routeGroup"))
Session("objRP").phone = IIf(Trim(Request.Form("phone")) = "", 0, Request.Form("phone"))


Session("objRP").storeID = IIf(Trim(Request.Form("storeID")) = "", 0, Request.Form("storeID"))
Session("objRP").employeeID = IIf(Trim(Request.Form("employeeID")) = "", 0, Request.Form("employeeID"))
Session("objRP").rangeStartDate = Request.Form("rangeStartDate")
Session("objRP").rangeEndDate =  Request.Form("rangeEndDate")

Session("objRP").rangeStartDateCompareTo =  Request.Form("rangeStartDateCompareTo")
Session("objRP").rangeEndDateCompareTo =  Request.Form("rangeEndDateCompareTo")

Session("objRP").rangeStartRackNumber =  Request.Form("rangeStartRackNumber")
Session("objRP").rangeEndRackNumber =  Request.Form("rangeEndRackNumber")


Session("objRP").claimStatus = Request.Form("claimStatus")
Session("objRP").DeptAndStartTime = Request.Form("deptStartDate")
Session("objRP").dayOfWeek = Request.Form("dayOfWeek")
Session("objRP").incoming = Request.Form("incoming")


If IIf(Request.Form("hourValue") = "", 0, CLng(Request.Form("hourValue"))) = 0 Then
	session("objRP").pickUpTime = empty
Else
	session("objRP").pickUpTime = Request.Form("hourValue") & ":" & iif(Request.Form("minuteValue")=0,"00",Request.Form("minuteValue"))  & iif(trim(Request.Form("amPMValue")) = "AM", "AM", "PM")
End If

If IIf(Request.Form("endhourValue") = "", 0, CLng(Request.Form("endhourValue"))) = 0 Then
	session("objRP").endTime = empty	
Else
	session("objRP").endTime = Request.Form("endhourValue") & ":" & iif(Request.Form("endminuteValue")=0,"00",Request.Form("endminuteValue"))  & iif(trim(Request.Form("endamPMValue")) = "AM", "AM", "PM")	
End If

If IIf(Request.Form("starthourValue") = "", 0, CLng(Request.Form("starthourValue"))) = 0 Then
	session("objRP").startTime = empty	
Else
	session("objRP").startTime = Request.Form("starthourValue") & ":" & iif(Request.Form("startminuteValue")=0,"00",Request.Form("startminuteValue"))  & iif(trim(Request.Form("startamPMValue")) = "AM", "AM", "PM")	
End If

'Response.Write Request.Form("hourValue") & ":" & iif(Request.Form("minuteValue")=0,"00",Request.Form("minuteValue"))  & iif(trim(Request.Form("amPMValue")) = "AM", "A.M", "P.M")

if Request.Form("includeDeptDetail") = "" then
	session("objRP").includeDeptDetail = 0
else
	session("objRP").includeDeptDetail = 1
end if

if Request.Form("includeActiveInvoices") = "" then
	session("objRP").includeActiveInvoices = 0
else
	session("objRP").includeActiveInvoices = 1
end if

if Request.Form("showZeroBalanceStatements") = "" then
	session("objRP").showZeroBalanceStatements = 0
else
	session("objRP").showZeroBalanceStatements = 1
end if	

if Request.Form("includeOutsideService") = "" then
	session("objRP").includeOutsideService = 0
else
	session("objRP").includeOutsideService = 1
end if

if Request.Form("onlyOutsideService") = "" then
	session("objRP").onlyOutsideService = 0
else
	session("objRP").onlyOutsideService = 1
end if


' Session("objRP").numberOfHours = IIf(isNumeric(Request.Form("numberOfHours")) = "", 0, CLng(Request.Form("numberOfHours")))


 Session("objRP").monthNumber = IIf(Trim(Request.Form("monthNumber")) = "", 0, clng(Request.Form("monthNumber")))

' Validate numeric parameters entered free form
Dim varNumberOfMonths
varNumberOfMonths = Trim(Request.Form("numberOfMonths"))
if (not isNull(varNumberOfMonths)) And _
   (isNumeric(varNumberOfMonths)) then
	Session("objRP").numberOfMonths = clng(varNumberOfMonths)
else
	Session("objRP").numberOfMonths = 0
end if

Dim varNumberOfHours
varNumberOfHours = Trim(Request.Form("numberOfHours"))
if (not isNull(varNumberOfHours)) And _
   (isNumeric(varNumberOfHours)) then
	Session("objRP").numberOfHours = CLng(varNumberOfHours)
else
	Session("objRP").numberOfHours = 0
end if

if Request.Form("onlyRackedInvoices") = "" then
	session("objRP").onlyRackedInvoices = 0
else
	session("objRP").onlyRackedInvoices = 1
end if

if isNumeric(Request.Form("rangeStartAmount")) then
	Session("objRP").rangeStartAmount = CCur(Request.Form("rangeStartAmount"))
end if

if isNumeric(Request.Form("rangeEndAmount")) then
	Session("objRP").rangeEndAmount = CCur(Request.Form("rangeEndAmount"))
end if

if isNumeric(Request.Form("terminalID")) then
	Session("objRP").terminalID = CLng(Request.Form("terminalID"))
end if
		
if isNumeric(Request.Form("hardwareID")) then
	Session("objRP").hardwareID = CLng(Request.Form("hardwareID"))
end if

'by rahul 01/07/2003

'Response.Write "rangeStartBirthMonth : " & Request.Form("rangeStartBirthMonth")
'Response.Write "rangeEndBirthMonth : " & Request.Form("rangeEndBirthMonth")


if isNumeric(Request.Form("rangeStartBirthMonth")) then
	Session("objRP").rangeStartBirthMonth = clng(Request.Form("rangeStartBirthMonth"))
else
	Session("objRP").rangeStartBirthMonth = 0
end if

if isNumeric(Request.Form("rangeEndBirthMonth")) then
	Session("objRP").rangeEndBirthMonth = clng(Request.Form("rangeEndBirthMonth"))
else
	Session("objRP").rangeEndBirthMonth = 0
end if


'Response.Write "start : " & Session("objRP").rangeStartBirthMonth
'Response.Write "end : " & Session("objRP").rangeEndBirthMonth


'Response.End
if isNumeric(Request.Form("rangeStartInactiveDays")) then
	Session("objRP").rangeStartInactiveDays = Cdbl(Request.Form("rangeStartInactiveDays"))
else
	Session("objRP").rangeStartInactiveDays = 0
end if

if isNumeric(Request.Form("rangeEndInactiveDays")) then
	Session("objRP").rangeEndInactiveDays = Cdbl(Request.Form("rangeEndInactiveDays"))
else
	Session("objRP").rangeEndInactiveDays = 0
end if

if isNumeric(Request.Form("elapsedDaysSinceFirstSignUp")) then
	Session("objRP").elapsedDaysSinceFirstSignUp = Cdbl(Request.Form("elapsedDaysSinceFirstSignUp"))
else
	Session("objRP").elapsedDaysSinceFirstSignUp = 0
end if


' end rahul


'Response.Write  "storeID : " & request.Form("storeID")'

'Response.Write "sart date : " & Request.Form("rangeStartDate")

'Response.Write " time  : " & Request.Form("hourValue") & Request.Form("minuteValue") & Request.Form("amPMValue")


'Response.Write "include out side services : " & Request.Form("includeOutsideService")

'Response.Write "onlyOutsideService : " & Request.Form("onlyOutsideService")
'Response.End

if _
	Session("objRP").reportNumber = RPT_NBR_Cash_Out Or _
	Session("objRP").reportNumber = RPT_NBR_Cash_Out_Z_Report Or _
	Session("objRP").reportNumber = RPT_NBR_Override_CashOut_Z_Report _
then
	if isNumeric(Request.Form("nbrOf1Cents")) then
		Session("objRP").nbrOf1Cents = CLng(Request.Form("nbrOf1Cents"))
	else
		Session("objRP").nbrOf1Cents = 0
	end if

	if isNumeric(Request.Form("nbrOf5Cents")) then
		Session("objRP").nbrOf5Cents = CLng(Request.Form("nbrOf5Cents"))
	else
		Session("objRP").nbrOf5Cents = 0
	end if
	if isNumeric(Request.Form("nbrOf10Cents")) then	
		Session("objRP").nbrOf10Cents = CLng(Request.Form("nbrOf10Cents"))
	else
		Session("objRP").nbrOf10Cents = 0
	end if
	if isNumeric(Request.Form("nbrOf25Cents")) then
		Session("objRP").nbrOf25Cents = CLng(Request.Form("nbrOf25Cents"))
	else
		Session("objRP").nbrOf25Cents = 0
	end if	
	if isNumeric(Request.Form("nbrOf1Dollars")) then
		Session("objRP").nbrOf1Dollars = CLng(Request.Form("nbrOf1Dollars"))
	else
		Session("objRP").nbrOf1Dollars = 0
	end if
	if isNumeric(Request.Form("nbrOf5Dollars")) then
		Session("objRP").nbrOf5Dollars = CLng(Request.Form("nbrOf5Dollars"))
	else
		Session("objRP").nbrOf5Dollars = 0
	end if	
	if isNumeric(Request.Form("nbrOf10Dollars")) then
		Session("objRP").nbrOf10Dollars = CLng(Request.Form("nbrOf10Dollars"))
	else
		Session("objRP").nbrOf10Dollars = 0
	end if	
	if isNumeric(Request.Form("nbrOf20Dollars")) then
		Session("objRP").nbrOf20Dollars = CLng(Request.Form("nbrOf20Dollars"))
	else
		Session("objRP").nbrOf20Dollars = 0
	end if
	if isNumeric(Request.Form("nbrOf50Dollars")) then
		Session("objRP").nbrOf50Dollars = CLng(Request.Form("nbrOf50Dollars"))
	else
		Session("objRP").nbrOf50Dollars = 0
	end if
	if isNumeric(Request.Form("nbrOf100Dollars")) then
		Session("objRP").nbrOf100Dollars = CLng(Request.Form("nbrOf100Dollars"))
	else
		Session("objRP").nbrOf100Dollars = 0
	end if

	if isNumeric(Request.Form("checkAmount")) then
		Session("objRP").checkAmount = CCur(Request.Form("checkAmount"))
	else
		Session("objRP").checkAmount = 0
	end if
	if isNumeric(Request.Form("ccAmount")) then
		Session("objRP").ccAmount = CCur(Request.Form("ccAmount"))
	else
		Session("objRP").ccAmount = 0
	end if
	if isNumeric(Request.Form("tradeAmount")) then
		Session("objRP").tradeAmount = CCur(Request.Form("tradeAmount"))
	else
		Session("objRP").tradeAmount = 0
	end if
	if isNumeric(Request.Form("couponAmount")) then
		Session("objRP").couponAmount = CCur(Request.Form("couponAmount"))
	else
		Session("objRP").couponAmount = 0
	end if		
	if isNumeric(Request.Form("endingAmount")) then
		Session("objRP").endingAmount = CCur(Request.Form("endingAmount"))
	else
		Session("objRP").endingAmount = 0
	end if		
	
end if
end function

public function CreateReportTempFile(contentToWrite)

    dim pathToWriteTempFile
	dim tempFileName

	dim objFS
	dim objFile
	
	On Error Resume Next

    pathToWriteTempFile = Server.MapPath("/") & "\ReportOutFiles\"
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & "-Function= Report File Creation. Could not get the Root directory by using Server.MapPath. There may be a set up problem with IIS."
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if
	
    tempFileName = Session.SessionID & ".htm"
    
    tempFileName = pathToWriteTempFile & tempFileName
	
    Set objFS = CreateObject("Scripting.FileSystemObject")
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & "-Function= Report File Creation. Could not perform CreateObject for Scripting.FileSystemObject. There may be a problem with the Scripting Engine Version."
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if

    Set objFile = objFS.CreateTextFile(tempFileName, True)
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & "-Function= Report File Creation. Could not create the report temporary file: " & tempFileName
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if

    objFile.WriteLine(contentToWrite)
	if err.number <> 0 then
		set errorList =  Server.CreateObject("Scripting.Dictionary")
		errorList.Add err.number, err.description & "-Function= Report File Creation. Could not write to the report temporary file: " & tempFileName & ". The disk space may be running out."
		set session("errorList") = errorList
		Response.redirect("../include/error.asp")
	end if

    objFile.Close

	set objFS   = Nothing
	set objFile = Nothing

	CreateReportTempFile = tempFileName
	
end function

public function DeleteFile(fileName)

	dim objFS
	
	On Error Resume Next

	
    Set objFS = CreateObject("Scripting.FileSystemObject")
	objFS.DeleteFile fileName
	
	set objFS   = Nothing

end function


public function getCCBatchReportID()
'Added by J.Johnston, 02Feb04
'Dynamically assigns value for CC batch process report

	dim ssql
	dim objResultSet
	dim test

	ssql = "select reportID from ReportDomain where reportName = 'Credit Card Batch Processing'"
	 
	set objResultSet = getDisconnectedRecordset(ssql)

	if not objResultSet is nothing then
		getCCBatchReportID = objResultSet.Fields("reportID").Value
	end if
	
end function





sub FillParams()
	dim key, item
	
	set Session("objRP").params = Server.CreateObject("Scripting.Dictionary")
	
	For Each key In Request.Form
	    item = Request.Form(key)
		Session("objRP").params.add key, item
	Next
end sub


%>
