<%

	function determineIfClearent()
		dim query, rs, ccProcessorDomainID

		query = "select CreditCardProcessorDomainID from miscsetup where storeid = " & session("storeid")
		set rs = getdisconnectedrecordset(query)
		ccProcessorDomainID = rs("CreditCardProcessorDomainID")

		query = " select  Description from CreditCardProcessorDomain where CreditCardProcessorDomainID = " & ccProcessorDomainID

		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			if rs("Description") = "Clearent" then
			    use_clearent = "1"
			else
                use_clearent = "0"
            end if
		end if

	end function


%>