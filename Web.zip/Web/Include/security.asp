
<%
	dim sec_DeterminingRole
	dim termLicenseType
	termLicenseType = Session("licenseType")
	if termLicenseType = "" and Session("TerminalID") <> "" then
	    getLicenseType
	end if


	function getLicenseType
        dim query, rs
        query = "select licenseType from ClientTerminal where terminalID = " & Session("TerminalID")
        set rs = getdisconnectedrecordset(query)
        if rs.recordcount > 0 then
            termLicenseType = cInt(rs("licenseType"))
        end if
        Session("licenseType") = termLicenseType
	end function

	function sec_FindPermission(Location, UserAction, EmployeeID, WriteLog)
		dim query
		dim rs

		query = "select id from SuperUserPages where lower('" & Location & "') = lower(Location)"
        set rs = getDisconnectedRecordset(query)
        if rs.recordcount > 0 then
            sec_FindPermission = false
        else
            UserAction = trim(UserAction)

            if WriteLog then
                query = "dbo.RequestAccess '" & EmployeeID & "', '" & Session("TerminalID") & "', '" & Location & "', '" & UserAction & "', 1"
            else
                query = "dbo.RequestAccess '" & EmployeeID & "', '" & Session("TerminalID") & "', '" & Location & "', '" & UserAction & "', 0"
            end if

            set rs = getDisconnectedRecordset(query)

            if not (rs.EOF or rs.BOF) then
                sec_DeterminingRole = trim(rs("DecidingTag")) & " (" & rs("Decision") & ")"
                sec_FindPermission = rs("Decision")
            else
                sec_FindPermission = false
            end if

            set rs = nothing
        end if
	end function

	function sec_IsAllowed(UserAction)
		dim EmployeeID
		dim Location
		EmployeeID = trim(Session("EmployeeID"))
		Location = trim(Request.ServerVariables("SCRIPT_NAME"))
		sec_IsAllowed = trim(EmployeeID) = "1" or sec_FindPermission(Location, UserAction, EmployeeID, false)
	end function

	sub sec_DWP(UserAction)
		dim EmployeeID
		dim Location
		EmployeeID = trim(Session("EmployeeID"))
		Location = trim(Request.ServerVariables("SCRIPT_NAME"))
		if UserAction = "opencashdrawer" then
			if not sec_FindPermission(Location, UserAction, EmployeeID, true) then
				Response.Write " disabled "
			end if	
		else	
			if not sec_FindPermission(Location, UserAction, EmployeeID, false) then
				Response.Write " disabled "
			end if
		end if	
	end sub

	sub sec_DenyAccess(msg)
		Response.Redirect "/mainapp/AccessDenied.asp?msg=" & msg
	end sub

	sub sec_RequestAccess(UserAction)
		dim EmployeeID
		dim Location
		EmployeeID = trim(Session("EmployeeID"))
		Location = trim(Request.ServerVariables("SCRIPT_NAME"))
		if not sec_FindPermission(Location, UserAction, EmployeeID, true) and trim(EmployeeID) <> "1" then
			sec_DenyAccess sec_DeterminingRole
		end if
	end sub

	sub sec_RequestAccessNoLog(UserAction)
		dim EmployeeID
		dim Location
		EmployeeID = trim(Session("EmployeeID"))
		Location = trim(Request.ServerVariables("SCRIPT_NAME"))
		if not sec_FindPermission(Location, UserAction, EmployeeID, false) and trim(EmployeeID) <> "1" then
			sec_DenyAccess sec_DeterminingRole
		end if
	end sub

	function sec_GetDefaultAccess(Location, UserAction)
		dim query, rs

		query = "select employeeid from employee where employeepassword = '' AND employeeStatus = 'A'"
		set rs = getdisconnectedrecordset(query)

		sec_GetDefaultAccess = 0

		while not(rs.eof or rs.bof)
			if sec_FindPermission(Location, UserAction, rs("employeeid"), false) then
				sec_GetDefaultAccess = trim(rs("employeeid"))
				set rs = nothing
				exit function
			end if

			rs.movenext
		wend

		set rs = nothing
	end function

	function sec_Log(UserAction, message, customerSequenceNumber)
		dim query
        dim EmployeeID
		dim Location

		EmployeeID = trim(Session("EmployeeID"))
		Location = trim(Request.ServerVariables("SCRIPT_NAME"))

		query = " insert into SecurityLog (EmployeeID, Location, Action, Result, CustomerSequenceNumber) "
		query = query & " VALUES (" & EmployeeID
		query = query & ", '" & Location & "'"
		query = query & ", '" & UserAction & "'"
		query = query & ", '" & message & "'"
		query = query & ", " & customerSequenceNumber
		query = query & ")"


		qryexecute query
	end function
%>