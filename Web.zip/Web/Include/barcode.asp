
<%

class BarcodeEncoder
	public TicketNumber
	public InvoiceNumber
	public Store
	public IsCustomerCopy
	

	private Missing(32)

    private sub Class_Initialize
    end sub

    private sub Class_Terminate
    end sub

	public sub ResetBarcode()
		TicketNumber = ""
		Store = ""
		ResetMissingGarments
	end sub

	public function LoadBarcode(barcode)
		dim storeMarker
		dim garmentMarker
		dim missingPieces
		dim i
		dim pos

		LoadBarcode = false

		ResetBarcode

		barcode = trim(barcode)

		if isnull(barcode) or barcode = "" then
			exit function
		end if

		pos = 1

		if left(barcode, 1) = "%" then
			IsCustomerCopy = true
			pos = 2
		end if

		storeMarker = instr(pos , barcode, "-")
		if storeMarker > 0 then
			Store = mid(barcode, pos, storeMarker - 1)
		else
			exit function
		end if

		garmentMarker = instr(storeMarker, barcode, ".")
		if garmentMarker > 0 then
			TicketNumber = ConvFromBase(mid(barcode, storeMarker + 1, garmentMarker - storeMarker - 1), 36)
		else
			exit function
		end if

		missingPieces = right(barcode, len(barcode) - garmentMarker)

		if missingPieces <> "" then
			missingPieces = ConvToBase(ConvFromBase(missingPieces, 36), 2)
			for i = 1 to len(missingPieces)
				if mid(missingPieces, i, 1) = "1" then
					SetMissingGarment len(missingPieces) - i
				end if
			next
		end if

		
		LoadBarcode = true
	end function

	public sub ResetMissingGarments()
		dim i

		IsCustomerCopy = false

		for i = 0 to ubound(missing)
			Missing(i) = false
		next
	end sub

	public sub SetMissingGarment(i)
		if i <= ubound(missing) then
			Missing(i) = true
		end if
	end sub


	public function IsMissingGarment(i)
		if i <= ubound(missing) then
			IsMissingGarment = Missing(i)
		end if
	end function

	private function Pow(n, i)
		dim result
		dim idx

		idx = i
		result = 1

		while idx > 0
			result = result * n
			idx = idx - 1
		wend
		
		Pow = result
	end function

	private function ConvFromBase(str, base)
		dim alphabit
		dim i
		dim ch
		dim m
		dim result

		alphabit = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

		result = 0

		for i = 1 to len(str)
			ch = mid(str, i, 1)
			m = instr(1, alphabit, ch)
			result = result + pow(base, len(str) - i) * (m - 1)
		next

		ConvFromBase = result
	end function

	private function ConvToBase(n, base)
		dim alphabit
		dim result
		
		if n = "" or base > 36 then
			exit function
		end if

		alphabit = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

		while n > 0
			result = mid(alphabit, (n mod base) + 1, 1) & result
			n = n \ base
		wend

		ConvToBase = result
	end function

	public function EncodeTicketNumber(ticketNumber)
		EncodeTicketNumber = ConvToBase(ticketNumber, 36)
	end function

	public function EncodeMissingGarments(missing)
		dim i
		dim missingDec

		for i = 0 to ubound(missing)
			if missing(i) then
				missingDec = missingDec + pow(2, i)
			end if
		next

		EncodeMissingGarments = ConvToBase(missingDec, 36)
	end function

	public function GetBarcodeText()
		if IsCustomerCopy then
			GetBarcodeText = "%" & Store & "-" & EncodeTicketNumber(TicketNumber) & "." & EncodeMissingGarments(Missing)
		else
			GetBarcodeText = Store & "-" & EncodeTicketNumber(TicketNumber) & "." & EncodeMissingGarments(Missing)
		end if
		
	end function



end class

%>
