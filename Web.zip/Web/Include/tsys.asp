﻿<!-- #include file="../include/systemsetting.asp" -->

<%
    Class TSysCardTransaction

        Private m_POSLink
        Private m_CommSetting
        Private m_LogManagement

        ' The amount to use when processing an AUTH transaction. Used to add a card-on-file. This differs between test and prod environments
        Private m_AuthorizationAmount

        Private m_MerchantID
        Private m_DeviceID
        Private m_UserID
        Private m_Password
            
        Private Sub Class_Initialize()
            InitializeStoreHardware()
            InitializeSystemSettings()

            Set m_POSLink = Server.CreateObject("POSLink.PosLink")
            Set m_POSLink.CommSetting = m_CommSetting
            Set m_POSLink.LogManagement = m_LogManagement

            ' This amount is 1.00 in the test environment. We need to change it to 0.01 when we go to prod.
            m_AuthorizationAmount = 100
        End Sub

        Private Sub InitializeStoreHardware()
            Dim sql: sql = "SELECT creditCardDeviceID, creditCardIPAddress, creditCardPort FROM dbo.StoreHardware WHERE hardwareType = 'CC' AND terminalID = " & Session("terminalID")
            Dim rs: Set rs = getDisconnectedRecordset(sql)

            If rs.RecordCount > 0 Then
                Dim cs
                Set cs = Server.CreateObject("POSLink.CommSetting")

                cs.CommType = "TCP"
                cs.DestIP = rs("creditCardIPAddress")
                cs.DestPort = rs("creditCardPort")
                cs.TimeOut = systemsetting("TSYS-TIMEOUT")
            
                Set m_CommSetting = cs

                m_DeviceID = rs("creditCardDeviceID")
            End If

        End Sub

        Private Sub InitializeSystemSettings()
            Dim sql: sql = "SELECT * FROM dbo.SystemSetting WHERE Name LIKE 'TSYS-%'"
            Dim rs: Set rs = getDisconnectedRecordset(sql)

            If rs.RecordCount > 0 Then
                While Not(rs.EOF Or rs.BOF)
                    Select Case rs("Name")
                        Case "TSYS-LOGFILEPATH"
                            Dim lm
                            Set lm = Server.CreateObject("POSLink.LogManagement")

                            lm.LogSwitchMode = 0
                            lm.LogFilePath = rs("Value")
            
                            Set m_LogManagement = lm
                        Case "TSYS-MERCHANTID"
                            m_MerchantID = rs("Value")
                        Case "TSYS-USERID"
                            m_UserID = rs("Value")
                        Case "TSYS-PASSWORD"
                            m_Password = rs("Value")
                    End Select

                    rs.MoveNext
                Wend
            End If

            rs.Close
            Set rs = Nothing
        End Sub

        Public Function ProcessSaleTransaction(amount, cardPaymentID)
            Set ProcessSaleTransaction = processCardTransaction("SALE", amount, cardPaymentID)
        End Function

        
        Public Function ProcessReturnTransaction(amount, cardPaymentID)
            Set ProcessReturnTransaction = processCardTransaction("RETURN", amount, cardPaymentID)
        End Function

    
        Private Function processCardTransaction(transactionType, amount, cardPaymentID)
            Dim payRequest
            Set payRequest = Server.CreateObject("POSLink.PaymentRequest")

            ' The TSys API expects the amount string to be passed in with no decimal points
            amount = Replace(amount, ".", "")

            payRequest.TenderType = payRequest.ParseTenderType("CREDIT")
            payRequest.TransType = payRequest.ParseTransType(transactionType)
            payRequest.ECRRefNum = cardPaymentID
            payRequest.Amount = amount

            Set m_POSLink.PaymentRequest = payRequest

            Dim processTransResult
            Set processTransResult = m_POSLink.ProcessTrans
            
            Dim result: Set result = new CardTransactionResults
            result.Success = False
            result.ResponseCode = processTransResult.Code
            result.ResponseDescription = processTransResult.Msg

            If processTransResult.Code = 1 Then
                
                Dim paymentResponse: Set paymentResponse = m_POSLink.paymentResponse

                result.ResponseCode = paymentResponse.ResultCode
                result.ResponseDescription = paymentResponse.ResultTxt

                If result.ResponseCode = "000100" Then
                    result.ResponseCode = paymentResponse.HostResponse
                    result.ResponseDescription = paymentResponse.Message
                ElseIf result.ResponseCode = "000000" Then
    
                    result.Success = True

                    Dim xmlDoc: Set xmlDoc = Server.CreateObject("MSXML2.DOMDocument.3.0")
                    xmlDoc.async = False
                    xmlDoc.loadXML "<DOC>" & paymentResponse.ExtData & "</DOC>"

                    result.Amount = formatApprovedAmount(paymentResponse.ApprovedAmount) 
                    result.ApprovalCode = paymentResponse.AuthCode
                    result.CardType = paymentResponse.CardType
                    result.CardNumber = getMaskedAccountNumber(paymentResponse.BogusAccountNum, result.CardType)
                    result.CardExpDate = xmlDoc.selectSingleNode("DOC/ExpDate").text
                    result.TransactionID = paymentResponse.RefNum
                    result.FullReceiptData = FormatPOSLinkReceiptData(paymentResponse, transactionType)
                End If
           
            End If

            Set processCardTransaction = result
        End Function

        Public Function processCardOnFileSaleTransaction(amount, alias, expirationDate)

            Dim transactionKey: transactionKey = getTransactionKey

            Dim xmlSaleResult: Set xmlSaleResult = getSaleResponse(transactionKey, amount, alias, expirationDate)
            
            Dim result: Set result = new CardTransactionResults
            result.Success = False
            result.ResponseCode = 0
            result.ResponseDescription = "TransIT Request Error"
            
            If Not xmlSaleResult Is Nothing Then
                Dim root: Set root = xmlSaleResult.selectSingleNode("SaleResponse")

                result.ResponseCode = root.selectSingleNode("responseCode").text
                result.ResponseDescription = root.selectSingleNode("responseMessage").text

                Dim success: success = root.selectSingleNode("status").text

                If success = "PASS" Then
                    result.Success = True
                
        	        result.Amount = root.selectSingleNode("processedAmount").text
	                result.ApprovalCode = root.selectSingleNode("authCode").text
                    result.CardType = getCardType(root.selectSingleNode("cardType").text)
		            result.CardNumber = getMaskedAccountNumber(root.selectSingleNode("maskedCardNumber").text, result.CardType)
		            result.CardExpDate = expirationDate ' Using the original expiration date because the one in the response is formatted MMYYYY instead of MMYY
		            result.TransactionID = root.selectSingleNode("transactionID").text
                    result.FullReceiptData = FormatTransITReceiptData(root.selectSingleNode("customerReceipt").text)
                End If
            End If

            Set processCardOnFileSaleTransaction = result
        End Function

        Public Function processCreditBatchTransaction(alias, amount, expirationDate)
            Set processCreditBatchTransaction = processCardOnFileSaleTransaction(amount, alias, expirationDate)
        End Function 

        Private Function getTransactionKey
            Dim xmlResponse
            Dim transactionKey: transactionKey = ""
        
            Dim xml: xml = "<?xml version=""1.0""?><GenerateKey><mid>" & m_MerchantID & "</mid><userID>" & m_UserID & "</userID><password>" & m_Password & "</password></GenerateKey>"
            Set xmlResponse = getXMLResponse(xml)

            If Not xmlResponse Is Nothing Then
                transactionKey = xmlResponse.selectSingleNode("GenerateKeyResponse/transactionKey").text
            End If

            getTransactionKey = transactionKey
        End Function

        Private Function getSaleResponse(transactionKey, amount, alias, expirationDate)
            Dim xmlResponse
            Dim xml: xml = "<?xml version='1.0'?><Sale>" _
                         & "<deviceID>" & m_DeviceID & "</deviceID>" _
                         & "<transactionKey>" & transactionKey & "</transactionKey>" _
                         & "<cardDataSource>PHONE</cardDataSource>" _
                         & "<transactionAmount>" & FormatNumber(amount, 2, -1, 0, 0) & "</transactionAmount>" _
                         & "<cardNumber>" & alias & "</cardNumber>" _
                         & "<expirationDate>" & expirationDate & "</expirationDate></Sale>"

            Set xmlResponse = getXMLResponse(xml)

            Set getSaleResponse = xmlResponse
        End Function

        Private Function getXMLResponse(xml)
            Dim request
            Dim xmlDoc: Set xmlDoc = Nothing

        	Set request = Server.CreateObject("MSXML2.ServerXMLHTTP")
            request.open "POST", "https://stagegw.transnox.com/servlets/TransNox_API_Server", false
            request.setRequestHeader "Content-Type", "text/xml"
			request.send xml

            If request.status = 200 Then
                Set xmlDoc = Server.CreateObject("MSXML2.DOMDocument.3.0")
                xmlDoc.async = False
                xmlDoc.loadXML request.responseXML.xml
            End If

            Set getXMLResponse = xmlDoc
        End Function

        Public Function ProcessVoidTransaction(transactionID, cardPaymentID, cardPresent)
            Dim result

            If cardPresent = True Then
                Set result = processPOSLinkVoidTransaction(transactionID, cardPaymentID)
            Else
                Set result = processTransITVoidTransaction(transactionID)
            End If


            Set ProcessVoidTransaction = result

        End Function

        Public Function processPOSLinkVoidTransaction(transactionID, cardPaymentID)
            Dim payRequest
            Set payRequest = Server.CreateObject("POSLink.PaymentRequest")

            payRequest.TenderType = payRequest.ParseTenderType("CREDIT")
            payRequest.TransType = payRequest.ParseTransType("VOID")
            payRequest.ECRRefNum = cardPaymentID
            payRequest.OrigRefNum = transactionID

            Set m_POSLink.PaymentRequest = payRequest

            Dim processTransResult
            Set processTransResult = m_POSLink.ProcessTrans
            
            Dim result: Set result = new CardTransactionResults
            result.Success = False
            result.ResponseCode = processTransResult.Code
            result.ResponseDescription = processTransResult.Msg

            If processTransResult.Code = 1 Then
                
                Dim paymentResponse: Set paymentResponse = m_POSLink.paymentResponse

                result.ResponseCode = paymentResponse.ResultCode
                result.ResponseDescription = paymentResponse.ResultTxt

                If result.ResponseCode = "000100" Then
                    result.ResponseCode = paymentResponse.HostResponse
                    result.ResponseDescription = paymentResponse.Message
                ElseIf result.ResponseCode = "000000" Then
                    result.Success = True
                    result.Amount = (-1)*formatApprovedAmount(paymentResponse.ApprovedAmount) 
                    result.TransactionID = paymentResponse.RefNum
                    result.FullReceiptData = FormatPOSLinkReceiptData(paymentResponse, transactionType)
                End If
           
            End If

            Set processPOSLinkVoidTransaction = result
        End Function

        Public Function processTransITVoidTransaction(transactionID)
            Dim transactionKey: transactionKey = getTransactionKey

            Dim xmlVoidResult
            Dim xml: xml = "<?xml version='1.0'?><Void>" _
                         & "<deviceID>" & m_DeviceID & "</deviceID>" _
                         & "<transactionKey>" & transactionKey & "</transactionKey>" _
                         & "<transactionID>" & transactionID & "</transactionID></Void>"

            Set xmlVoidResult = getXMLResponse(xml)

            Dim result: Set result = new CardTransactionResults
            result.Success = False
            result.ResponseCode = 0
            result.ResponseDescription = "TransIT Request Error"

            If Not xmlVoidResult Is Nothing Then
                Dim root: Set root = xmlVoidResult.selectSingleNode("VoidResponse")

                result.ResponseCode = root.selectSingleNode("responseCode").text
                result.ResponseDescription = root.selectSingleNode("responseMessage").text

                Dim success: success = root.selectSingleNode("status").text

                If success = "PASS" Then
                    result.Success = True
                    result.Amount = (-1)*formatApprovedAmount(root.selectSingleNode("voidedAmount").text)
                    result.TransactionID = root.selectSingleNode("transactionID").text
                    result.FullReceiptData = FormatTransITReceiptData(root.selectSingleNode("customerReceipt").text)
                End If
            End If

            Set processTransITVoidTransaction = result
        End Function

        Public Function processCreateAliasTransaction()
            ' TSYS advises that we do an auth only transaction for a penny to get a token that represents the credit card used. 
            ' Normally they advice to use a verify transaction, but they've seen issues with AMEX with that transaction type
            Dim payRequest
            Set payRequest = Server.CreateObject("POSLink.PaymentRequest")

            payRequest.TenderType = payRequest.ParseTenderType("CREDIT")
            payRequest.TransType = payRequest.ParseTransType("AUTH")
            payRequest.ECRRefNum = "N/A"
            payRequest.Amount = m_AuthorizationAmount

            Set m_POSLink.PaymentRequest = payRequest

            Dim processTransResult
            Set processTransResult = m_POSLink.ProcessTrans

            Dim result: Set result = new CardTransactionResults
            result.Success = False
            result.ResponseCode = processTransResult.Code
            result.ResponseDescription = processTransResult.Msg

            If processTransResult.Code = 1 Then
                Dim paymentResponse: Set paymentResponse = m_POSLink.paymentResponse

                result.ResponseCode = paymentResponse.ResultCode
                result.ResponseDescription = paymentResponse.ResultTxt

                If result.ResponseCode = "000100" Then
                    result.ResponseCode = paymentResponse.HostResponse
                    result.ResponseDescription = paymentResponse.Message
                ElseIf result.ResponseCode = "000000" Then
                    result.Success = True

                    Dim xmlDoc: Set xmlDoc = Server.CreateObject("MSXML2.DOMDocument.3.0")
                    xmlDoc.async = False
                    xmlDoc.loadXML "<DOC>" & paymentResponse.ExtData & "</DOC>"

			        result.CardType =   paymentResponse.CardType
                    result.CardNumber = getMaskedAccountNumber(paymentResponse.BogusAccountNum, result.CardType)
			        result.CardExpDate = xmlDoc.selectSingleNode("DOC/ExpDate").text
			        result.Alias = xmlDoc.selectSingleNode("DOC/TOKEN").text
                End If

            End If

            Set processCreateAliasTransaction = result

        End Function

        ' This method isn't really necessary since the TSYS tokens are just encrypted card numbers and aren't associated with exipriaton dates
        ' I'm putting this logic in here because the calling method expects a CardTransactionResults object and shouldn't be concerned with TSYS-specific details
        Public Function updateAliasExpirationDate()
            Dim result
            Set result = New CardTransactionResults
            
            result.Success = True
            result.ResponseCode = 1
            result.ResponseDescription = "SUCCESS"

            Set updateAliasExpirationDate = result
        End Function

        Private Function getMaskedAccountNumber(shortAccountNumber, cardType)
            Dim maskedAccountNumber
        
            If cardType = "AMEX" Then
                maskedAccountNumber = String(11, "X") & shortAccountNumber
            Else
                maskedAccountNumber = String(12, "X") & shortAccountNumber

            End If

            getMaskedAccountNumber = maskedAccountNumber
        End Function

        Private Function getCardType(cardTypeAbbreviation)
            Dim cardTypeName
            ' To date, we have only supported Visa, Mastercard, Discover, and American Express. Tsys potentially supports many more, so we will iterate over all of them here
            Select Case cardTypeAbbreviation
                Case "V"
                    cardTypeName = "Visa"
                Case "M"
                    cardTypeName = "MasterCard"
                Case "R"
                    cardTypeName = "Discover"
                Case "X"
                    cardTypeName = "American Express"
                Case "J"
                    cardTypeName = "JCB"
                Case "I"
                    cardTypeName = "Diners Club"
                Case "D"
                    cardTypeName = "Debit"
                Case "A"
                    cardTypeName = "ATM"
                Case "G"
                    cardTypeName = "Private Label"
                Case "E"
                    cardTypeName = "EBT"
                Case "U"
                    cardTypeName = "Unknown"
                Case Else
                    cardTypeName = ""
            End Select

            getCardType = cardTypeName
        End Function

        Private Function FormatPOSLinkReceiptData(paymentResponse, transactionType)
            Dim receiptData

            Dim xmlDoc: Set xmlDoc = Server.CreateObject("MSXML2.DOMDocument.3.0")
            xmlDoc.async = False
            xmlDoc.loadXML "<DOC>" & paymentResponse.ExtData & "</DOC>"

            Dim nl: nl = "\par" & Chr(13) & Chr(10)
            Dim entryMode: entryMode = xmlDoc.selectSingleNode("DOC/PLEntryMode").text

            receiptData = nl & "E2E 02"
            receiptData = receiptData & nl & formatTimestamp(paymentResponse.Timestamp)
            receiptData = receiptData & nl & "CREDIT " & transactionType & ": "
            receiptData = receiptData & nl & "Transaction #: " & paymentResponse.RefNum
            receiptData = receiptData & nl & "Card Type: " & paymentResponse.CardType
            receiptData = receiptData & nl & "Account: " & paymentResponse.BogusAccountNum
            receiptData = receiptData & nl & "Entry " & getEntryMode(entryMode)
            receiptData = receiptData & nl & "Amount: " & FormatCurrency(formatApprovedAmount(paymentResponse.ApprovedAmount))
            receiptData = receiptData & nl & "Ref. Number: 508015400141 "
            receiptData = receiptData & nl & "Auth Code: " & paymentResponse.AuthCode
            receiptData = receiptData & nl & "Reponse: " & paymentResponse.Message

            If Not xmlDoc.selectSingleNode("DOC/TC") Is Nothing Then
                receiptData = receiptData & nl & "TC: " & xmlDoc.selectSingleNode("DOC/TC").text
                receiptData = receiptData & nl & "TVR: " & xmlDoc.selectSingleNode("DOC/TVR").text
                receiptData = receiptData & nl & "AID: " & xmlDoc.selectSingleNode("DOC/AID").text
                receiptData = receiptData & nl & "TSI: " & xmlDoc.selectSingleNode("DOC/TSI").text
                receiptData = receiptData & nl & "ATC: " & xmlDoc.selectSingleNode("DOC/ATC").text
                receiptData = receiptData & nl & "APPLAB: " & xmlDoc.selectSingleNode("DOC/APPLAB").text
            End If

            receiptData = receiptData & nl & "I AGREE TO PAY ABOVE TOTAL "
            receiptData = receiptData & nl & "AMOUNT ACCORDING TO CARD ISSUER "
            receiptData = receiptData & nl & "AGREEMENT (MERCHANT AGREEMENT "
            receiptData = receiptData & nl & "IF CREDIT VOUCHER) "
            receiptData = receiptData & nl & "X.............................. "
            receiptData = receiptData & nl & "SIGNATURE "

            FormatPOSLinkReceiptData = receiptData
        End Function

        Private Function formatApprovedAmount(amount)
            formatApprovedAmount = CDbl(Left(amount, Len(amount) - 2) & "." & Right(amount, 2))
        End Function

        Private Function formatTimestamp(timestamp)
            Dim month
            Dim day
            Dim year
            Dim hour
            Dim minute
            Dim second

            year = Left(timestamp, 4)
            month = Mid(timestamp, 5, 2)
            day = Mid(timestamp, 7, 2)
            hour = Mid(timestamp, 9, 2)
            minute = Mid(timestamp, 11, 2)
            second = Right(timestamp, 2)

            formatTimestamp = month & "/" & day & "/" & year & " " & hour & ":" & minute & ":" & second
        End Function

        Private Function getEntryMode(plEntryMode)
            Dim entryMode

            Select Case plEntryMode
                Case 0
                    entryMode = "Manual"
                Case 1
                    entryMode = "Swipe"
                Case 2
                    entryMode = "Contactless"
                Case 3
                    entryMode = "Scanner"
                Case 4 
                    entryMode = "Chip"
                Case 5
                    entryMode = "Chip Fall Back Swipe"
            End Select
                
            getEntryMode = entryMode
        End Function

        Private Function FormatTransITReceiptData(receiptData)
            FormatTransITReceiptData = Replace(receiptData, "\n", "\par" & Chr(13) & Chr(10))
        End Function

    End Class

%>

