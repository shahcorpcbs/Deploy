<!-- #include file="../include/QueryDatabase.asp" -->
<%

	'******************************************************************************
	'Name   : MiscSetupObject.inc
    '==============================================================================
	' Used to retrieve misc setup values from MiscSetup table.
    '==============================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------------
    ' 1-Sep-2003	 Johnston		Added user defined track check number
    ' 3-Sep-2003	 Johnston		Added user defined prompt when user has credit   
    ' 14-Sep-2003	 Johnston		Added user defined prompt when user has balance 
    '								on account       
    ' 14-Sep-2003	 Johnston		Added user defined temp account creation at pickup
    ' 16-Sep-2003	 Johnston		Added user defined scan order at pickup
    ' 1-Jan-2004     SteveG         Changed initializeMiscSetUp to load the miscSetUp object
    '                               by itself using the column names from the miscsetup table     
	'******************************************************************************


	Function initializeMiscSetUp()
		Dim ObjMiscSetUp
		Dim ssql
		Dim storeId
		Dim objResultSet
		Dim i
			
		storeId =Session("storeID")
		
		Set ObjMiscSetUp = Server.CreateObject("Scripting.Dictionary")
		Set Session("miscSetUp") = ObjMiscSetUp
		
        ' TODO Look at pulling this into its own stored procedure to make maintenance easier
		ssql = "SELECT ms.*, RTRIM(ccpd.Description) AS creditCardProcessorDescription " _
             & "FROM MiscSetup ms JOIN CreditCardProcessorDomain ccpd ON ms.CreditCardProcessorDomainID = ccpd.CreditCardProcessorDomainID WHERE storeID = " & Clng(storeId)
		Set objResultSet = getDisconnectedRecordset(ssql)
		
		
		For i = 0 To objResultSet.Fields.Count - 1
			ObjMiscSetUp.Add objResultSet.Fields(i).Name, objResultSet.Fields(i).Value
		Next

		'Added these lines to provide alt names for the code in places that relies
		'on these names.  In the future I believe it would be best to just use the column
		'names.
		ObjMiscSetUp.Add "trackCheckNumber", objResultSet.Fields("captureCheckNumber").Value
		ObjMiscSetUp.Add "promptScanOrder", objResultSet.Fields("promptScanOrders").Value
		
		
		objResultSet.Close
		Set objResultSet = Nothing

	End Function
%>

