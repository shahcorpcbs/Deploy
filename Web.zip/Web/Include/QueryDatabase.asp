<!-- #include file="../include/AdoConstants.inc" -->
<%	Dim objConn 'declare your variable to hold your connection
	dim objcmd
	dim errorList
	dim strDsn

	strDsn = Session("shahcorpDSN")
	set errorList =  Server.CreateObject("Scripting.Dictionary")

	function getDisconnectedRecordset(ssql)
		dim objrst
		session("lastquery") = ssql
		Set objConn = Server.CreateObject("ADODB.Connection")
		Set objrst =Server.CreateObject("ADODB.Recordset")
		objConn.CommandTimeout = 6000
		objConn.Open strDsn
		objrst.CursorLocation = adUseClient
		objrst.Open ssql, objConn, adOpenStatic, adLockBatchOptimistic
		set objrst.ActiveConnection = nothing
		set getDisconnectedRecordset = objrst
		objConn.Close
		Set objConn = nothing
		set objrst = nothing
	end function

	function openConnection()
		on error resume next
		Set objConn = Server.CreateObject("ADODB.Connection")
		Set objCmd = Server.CreateObject("ADODB.Command")
		objConn.CommandTimeout = 6000
		objConn.CursorLocation = adUseClient
		objConn.Open strDsn
		if err.number <> 0 then
			errorList.Add  err.number , err.description & "-Function= OpenConnection"
		end if
	end function

	Function QryExecuteWithTrans( sSqltxt )
		on error resume next
		session("lastquery") = sSqltxt
		objcmd.CommandText = ssqltxt
		objcmd.CommandType = adcmdtext
		set objcmd.ActiveConnection= objconn
		'Response.Write ssqltxt
		objcmd.Execute
		if err.number <> 0 then
			errorList.Add err.number,err.description & "-Function= QryExecuteWithTrans" & sSqltxt

		end if
		if errorList.count > 0 then
			'Response.Write errorList.count
			dbRollbackTrans()
		end if
	End function

	function closeConnection()
	'Response.Write "closing connection"
		set objcmd = nothing
		if not objconn is nothing then
			objConn.close
		end if
		set objconn = nothing

	end function

	function DbStartTrans()
	'Response.Write "start trans"
		Openconnection()
		objConn.BeginTrans
	end function

	function DbRollbackTrans()
	on error resume next
	'Response.Write "Roll back trans"
		objConn.RollbackTrans
		CloseConnection()
		set session("errorList") = nothing
		set session("errorList") = errorList
		'Response.write "redirecting"
		Response.redirect("../include/error.asp")

	end function

	function DbEndTrans()
	'Response.Write "commit trans"
		objConn.CommitTrans
		CloseConnection()
	end function



	function  dbSelect(sSqltxt)
		dim objrst
		session("lastquery") = sSqltxt
		set objrst = Server.CreateObject("ADODB.Recordset")
		set objcmd.ActiveConnection= objconn
		objcmd.CommandText = sSqltxt
		objrst.Open objcmd,,  adOpenKeyset, adLockReadonly
		set objcmd.ActiveConnection = nothing
		set dbselect = objrst

	End function


	Function QryExecute( sSqltxt )
		on error resume next
		session("lastquery") = sSqltxt
		openconnection()
		objcmd.CommandText = ssqltxt
		set objcmd.ActiveConnection= objconn
		objcmd.Execute
		if err.number <> 0 then
			errorList.Add err.number, err.description & "-Function= QryExecute"
		end if
		Closeconnection()
	End function

	Function dbInsert( sSqltxt )
		session("lastquery") = sSqltxt
		objcmd.CommandText = ssqltxt
		set objcmd.ActiveConnection= objconn
		objcmd.Execute
	End function

	Function dbInsertWithIdentity( sSqltxt )
		dim objrst
		dbInsertWithIdentity = -1
		session("lastquery") = sSqltxt
		set objrst = Server.CreateObject("ADODB.Recordset")
		openconnection()
		objcmd.CommandText = sSqltxt
		set objcmd.ActiveConnection = objconn
		objcmd.Execute
		objcmd.CommandText = "select scope_identity() as id"
		objrst.Open objcmd,,  adOpenKeyset, adLockReadonly
		if objrst.recordcount > 0 then
			dbInsertWithIdentity = objrst("id")
		end if
		set objrst = nothing
		Closeconnection()
	End function

	Function dbTranSelect(ssql)
		Dim objRst
		session("lastquery") = ssql
		Set objRst = Server.CreateObject("ADODB.Recordset")
		objRst.CursorLocation = adUseClient
		objRst.Open ssql, objConn, adOpenStatic, adLockBatchOptimistic
		Set objRst.ActiveConnection = Nothing
		Set dbTranSelect = objRst
		Set objRst = Nothing
	End Function

	Function QryExecuteWithTransAndSelect( sSqltxt )
		on error resume next
		session("lastquery") = sSqltxt
		objcmd.CommandText = ssqltxt
		dim rst
		set rst= server.CreateObject("ADODB.recordset")
		set objcmd.ActiveConnection= objconn
		'Response.Write ssql(txt
		set rst = objcmd.Execute
		if err.number <> 0 then
			errorList.Add err.number,err.description & "-Function= QryExecuteWithTrans" & sSqltxt

		end if
		if errorList.count > 0 then
			'Response.Write errorList.count
			dbRollbackTrans()
		end if
		QryExecuteWithTransAndSelect = rst.Fields(0)
		'Response.Write rst.fields(0)
		rst.close
		set rst= nothing
	End function


	function getDisconnectedRecordsetwithTrans(ssql)
		dim objrst
		session("lastquery") = ssql
		Set objrst =Server.CreateObject("ADODB.Recordset")

		objrst.CursorLocation = adUseClient
		objrst.Open ssql, objConn, adOpenStatic, adLockBatchOptimistic
		set objrst.ActiveConnection = nothing
		set getDisconnectedRecordsetwithTrans = objrst

		set objrst = nothing
	end function

	Function URLEncode(str )
    Dim strTemp, strChar
    strTemp = ""
    strChar = ""
    Dim nTemp, nAsciiVal

    For nTemp = 1 To Len(str)
        nAsciiVal = Asc(Mid(str, nTemp, 1))
        If ((nAsciiVal < 123) And (nAsciiVal > 96)) Then
			strTemp = strTemp & Chr(nAsciiVal)
        ElseIf ((nAsciiVal < 91) And (nAsciiVal > 64)) Then
			strTemp = strTemp & Chr(nAsciiVal)
        ElseIf ((nAsciiVal < 58) And (nAsciiVal > 47)) Then
			strTemp = strTemp & Chr(nAsciiVal)
        Else
			strChar = Trim(Hex(nAsciiVal))
			If nAsciiVal < 16 Then
				strTemp = strTemp & "%0" & strChar
			'MWiemann 11/6/2003 added next 2 lines to add double apostrophe for query string
			'ElseIf strChar = 27 Then
			'	strTemp = strTemp & "%" & strChar & "%" & strChar
			Else
				strTemp = strTemp & "%" & strChar
			End If
        End If
    Next
    URLEncode = strTemp
End Function

%>