

<%

class BarcodeEncoder
	public TicketNumber
	public InvoiceNumber
	public Store
	public IsCustomerCopy
	private Missing(32)
	
	private sub Class_Initialize
	end sub
	
	private sub Class_Terminate
	end sub
	
	public sub ResetBarcode()
		TicketNumber = ""
		InvoiceNumber = ""
		Store = ""
		ResetMissingGarments
	end sub
	
	public function LoadBarcode(barcode)
		dim lstart
		
		LoadBarcode = false
	
		ResetBarcode
		
		barcode = trim(barcode)
		if mid(barcode,2,1) = "." then			
			Store = left(barcode,1)
			lstart = 3
			while mid(barcode,lstart,1) = "0" and lstart < 8
				lstart = lstart + 1
			wend
		
			InvoiceNumber = mid(barcode,lstart)
		
			LoadBarcode = true		end if	
					
	end function
	
	
	public function GetBarcodeText()
		GetBarcodeText = trim(Store) & "." & trim(InvoiceNumber)
	end function
	
	
	public sub ResetMissingGarments()
		dim i
		
		IsCustomerCopy = false
		
		for i = 0 to ubound(missing)
		Missing(i) = false
		next
	end sub
	
	public sub SetMissingGarment(i)
		if i <= ubound(missing) then
		Missing(i) = true
		end if
	end sub
	
	
	public function IsMissingGarment(i)
		if i <= ubound(missing) then
		IsMissingGarment = Missing(i)
		end if
	end function

end class

%>
