
<%
	'You must include QueryDatabase.asp before including this file in any asp.
	
	'This include file  can be used for sending / queing email messages.
	'Email address are not validated now. Caller must do this.
	
	
	Function CBSSendMail(strFromName, strFromAddress, strToName, strToAddress, _
			strCCName, strCCAddress, strBCCName, strBCCAddress, strSubject, _
			strMessage, strAttachment1, strAttachment2)
			dim strReplyToName
			strReplyToName = strFromName
			
		if len(trim(strToAddress )) = 0 then
			Err.Raise "There must be at least one recipient for the message."
		end if
		
		if len(trim(strMessage)) = 0 then
			Err.Raise "Message Body can not be empty or spaces."
		end if
		
		Dim msql, asql
		
		msql = "SET NOCOUNT ON;"
		msql = msql & "INSERT INTO EMailQueue(createdDate, fromAddress, replyToAddress, toAddress, ccAddress, bccAddress, "
		msql = msql & " fromName, replyToName, toName, ccName, " 'bccName, "
		msql = msql & " subjectLine, bodyText, attachment) VALUES ("
		
		msql = msql & "getdate()" 
		
		if Trim(strFromAddress ) <> "" then
			msql = msql & ", " & "'" & strFromAddress & "'"
		else
			msql = msql & ", " & "null"
		end if
		
		'Reply to address
		if Trim(strFromAddress ) <> "" then
			msql = msql & ", " & "'" & strFromAddress & "'"
		else
			msql = msql & ", " & "null"
		end if
		
		if Trim(strToAddress) <> "" then
			msql = msql & ", " & "'" & strToAddress & "'"
		else
			msql = msql & ", " & "null"
		end if
		
		if Trim(strCCAddress ) <> "" then
			msql = msql & ", " & "'" & strCCAddress & "'"
		else
			msql = msql & ", " & "null"
		end if
		
		if Trim(strBCCAddress ) <> "" then
			msql = msql & ", " & "'" & strBCCAddress & "'"
		else
			msql = msql & ", " & "null"
		end if
		
		if Trim(strFromName ) <> "" then
			msql = msql & ", " & "'" & SqlEncode(strFromName) & "'"
		else
			msql = msql & ", " & "null"
		end if
		
		if Trim(strReplyToName ) <> "" then
			msql = msql & ", " & "'" & SqlEncode(strReplyToName) & "'"
		else
			msql = msql & ", " & "null"
		end if
		
		if Trim(strToName ) <> "" then
			msql = msql & ", " & "'" & SqlEncode(strToName) & "'"
		else
			msql = msql & ", " & "null"
		end if
		
		if Trim(strCCName ) <> "" then
			msql = msql & ", " & "'" & SqlEncode(strCCName) & "'"
		else
			msql = msql & ", " & "null"
		end if
		
		if Trim(strSubject ) <> "" then
			msql = msql & ", " & "'" & SqlEncode(strSubject) & "'"
		else
			msql = msql & ", " & "null"
		end if
		
		if Trim(strMessage ) <> "" then
			msql = msql & ", " & "'" & SqlEncode(strMessage) & "'"
		else
			msql = msql & ", " & "null"
		end if
		
		if Trim(strAttachment1) <> ""  Or Trim(strAttachment1) <> ""  then
			msql = msql & ", " & "1"
		else
			msql = msql & ", " & "0"
		end if
		
		msql = msql & ");"
		msql = msql & "SELECT SCOPE_IDENTITY() AS messageID;"
		msql = msql & "SET NOCOUNT OFF;"
		
		dim newMessageID
		newMessageID = -1
				
		DbStartTrans()
		newMessageID = clng(QryExecuteWithTransAndSelect(msql))
		DbEndTrans()
		
		'Response.Write "New Message ID = " & newMessageID & "<BR>"
		
		if newMessageID <> -1 then
			
			if trim(strAttachment1) <> "" or trim(strAttachment1) <> "" then 
			
				Dim acn 
				Dim ars
				Dim aid
			
				Set acn = Server.CreateObject("ADODB.Connection")
				Set ars = Server.CreateObject("ADODB.Recordset")
				aid = 0
			
				acn.Open Session("shahcorpDSN")
				ars.Open "SELECT * FROM EMailAttachment WHERE 1 = 2", acn, adOpenStatic, adLockOptimistic
			
				if trim(strAttachment1) <> "" then
					ars.AddNew
					aid = aid + 1
					'attachmentID, attachmentBlob, attachmentFileName
					ars("MessageID").Value = newMessageID
					ars("attachmentID").Value = aid
					ars("attachmentBlob").AppendChunk Trim(strAttachment1)
				end if
			
				if trim(strAttachment2) <> "" then
					ars.AddNew
					aid = aid + 1
					'attachmentID, attachmentBlob, attachmentFileName
					ars("MessageID").Value = newMessageID
					ars("attachmentID").Value = aid
					ars("attachmentBlob").AppendChunk Trim(strAttachment2)
				end if
			
				on error resume next
				ars.Update
			
				'Response.Write "Updated : " & Err.Description & "<BR>"
			'	for each e in acn.Errors
			'		Response.Write e & "<BR>"
				'	next
			'	ars.Close
				acn.Close
			
				Set ars = Nothing			
				Set acn = Nothing
			end if
		end if
	End Function
	
	Function SqlEncode(arg)
		SqlEncode = Replace(arg, "'", "''")
	End Function
	
%>