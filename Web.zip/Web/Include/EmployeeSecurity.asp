<%
	dim securitySql
	dim loggedOnEmployeeID
	dim functionID
	
	functionID = Request.Form("functionID")
	if functionID = "" then
		functionID = Request.QueryString("functionID")
	end if
	loggedOnEmployeeID = Session("employeeID")
	'if functionID = "" then
	'	'Give developer an error message
	'	dim errorMessage
	'	errorMessage = "Request does not contain <B>functionID</B> variable"
	'	dim el
	'	set el = Server.CreateObject("Scripting.Dictionary")
	'	set Session("errorList") = el
	'	el.Add "Error1" , errorMessage
	'	Response.Redirect "/include/error.asp"
	'	set el = nothing
	'end if
	if functionID <> "" then
		dim mytarget
	
		mytarget = ""
	
		if Request.ServerVariables("QUERY_STRING") <> "" then
				mytarget = mytarget & "?" & Request.ServerVariables("QUERY_STRING")
		end if
	
		if loggedOnEmployeeID = "" then
			dim trg
			trg = "/MainApp/Login.asp?target=" & Request.ServerVariables("PATH_INFO")
			'if Request.ServerVariables("QUERY_STRING") <> "" then
				'trg = trg & "?" & Request.ServerVariables("QUERY_STRING")
			'end if
			trg = trg & mytarget
			Response.Redirect trg
			
		end if
	
	
		securitySql = "SELECT (AFD.securityLevel - ER.securityLevel) AS SecurityLevelDiff "
		securitySql = securitySql & " FROM ApplicationFunctionDomain AFD, EmployeeRole ER"
		securitySql = securitySql & " WHERE ER.roleID = (select roleID from Employee where employeeID = " & loggedOnEmployeeID
		securitySql = securitySql & " AND AFD.functionID = " & functionID & ")"
		'response.write securitySQL
		dim securityRs
		dim levelDiff
		set securityRs = getDisconnectedRecordset(securitySql)
		if not securityRs is nothing and not securityRs.EOF then
			securityRs.MoveFirst
			levelDiff = securityRs("SecurityLevelDiff")
			if levelDiff > 0 then
				'Not enough access to execute the requested function
				Response.Redirect "/MainApp/AccessDenied.asp"
			end if
		end if
	end if
	
%>
