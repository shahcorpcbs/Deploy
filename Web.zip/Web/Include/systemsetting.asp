<%

Function systemsetting(stringname)
	Dim query, rs
	
	query = " select [value] from systemsetting where [name] = '" & dbstr(stringname) & "'"
	Set rs = getdisconnectedrecordset(query)
	
	If rs.recordcount > 0 Then
		systemsetting = rs("value")
	End If
	
	Set rs = Nothing
End Function


Function set_systemsetting(stringname, value)
	Dim query

    query = "IF EXISTS(SELECT NULL FROM dbo.SystemSetting WHERE Name = '" & dbstr(stringname) & "') " _
          & "UPDATE dbo.SystemSetting SET Value = '" & dbstr(value) & "' WHERE Name = '" & dbstr(stringname) & "' " _
          & "ELSE " _
          & "INSERT INTO dbo.SystemSetting (Name, Value) VALUES ('" & dbstr(stringname) & "', '" & dbstr(value) & "')"

	QryExecute query
	
End Function



%>