<link rel="stylesheet" href="/style/overlay.css" type="text/css">
<script language="javascript" type="text/javascript" src="/Script/validation.js"></script>

<script type="text/javascript">
    var promptWSelChoice = null;

    function clearAlertMsg() {
        document.getElementById('alertBox').style.display = 'none';
	    parent.windowOpen = false;
    }

    function clearConfirmMsg() {
        document.getElementById('confirmBox').style.display = 'none';
	    parent.windowOpen = false;
    }

    function clearOptionMsg() {
        document.getElementById('optionBox').style.display = 'none';
	    parent.windowOpen = false;
    }

    function clearPromptMsg() {
        document.getElementById('promptBox').style.display = 'none';
	    parent.windowOpen = false;
    }

    function clearPromptWSelMsg() {
        document.getElementById('promptWSelBox').style.display = 'none';
	    parent.windowOpen = false;
    }

    function clearSmallMsg() {
        document.getElementById('smallBox').style.display = 'none';
	    parent.windowOpen = false;
    }

    function clearAnyMsg() {
        clearAlertMsg();
        clearConfirmMsg();
        clearOptionMsg();
        clearPromptMsg();
        clearPromptMsg();
        clearPromptWSelMsg();
        clearSmallMsg();
    }

	function decimalFormat() {
	    obj = document.getElementById('inputTxtLine');
		var price;

		price = obj.value;
		price = trim(price);
		if(price.length > 0) {
			price = cleanNumeric(price);
			if(price == "")	{
				show_focus("Please enter a valid amount.");
				return;
			}
		}
		obj.value = autoFormatCurrency(obj.value);
	}

	function setPromptWSelChoice(choice) {
		if(promptWSelChoice) {
			promptWSelChoice.style.background = 'white';
		}

		choice.style.background = 'red';
	    promptWSelChoice = choice;
	}


</script>
	<div id="alertBox" class="overlay" style="display: none; text-align: center">
      <h1 id="alertHeader" class="overlayHeader"></h1>
      <div onclick="clearAlertMsg()" style="text-align: right;color: white;position: absolute;font-weight: bold;width: 93%;top: 20px;font-size: 20px;text-decoration: underline;">X</div>
      <BUTTON id="alertBtn" class="overlayBtn" onclick="clearAlertMsg(); return false;">OK</BUTTON>
    </div>


	<div id="confirmBox" class="overlay" style="display: none; text-align: center">
      <h1 id="confirmHeader" class="overlayHeader"></h1>
      <div onclick="clearConfirmMsg(); " style="text-align: right;color: white;position: absolute;font-weight: bold;width: 93%;top: 20px;font-size: 20px;text-decoration: underline;">X</div>
      <BUTTON id="confirmBtn1" class="overlayBtn" onclick="clearConfirmMsg(); return false;">Yes</BUTTON>
      <BUTTON id="confirmBtn2" class="overlayBtn" onclick="clearConfirmMsg(); return false;">No</BUTTON>
    </div>

	<div id="optionBox" class="overlay" style="display: none; text-align: center">
      <h1 id="optionHeader" class="overlayHeader"></h1>
      <div onclick="clearOptionMsg()" style="text-align: right;color: white;position: absolute;font-weight: bold;width: 93%;top: 20px;font-size: 20px;text-decoration: underline;">X</div>
      <table id="optionTable" style="margin: 0 auto">
      </table>
    </div>

	<div id="promptBox" class="overlay" style="display: none; text-align: center">
      <h1 id="promptHeader" class="overlayHeader"></h1>
      <div onclick="clearPromptMsg()" style="text-align: right;color: white;position: absolute;font-weight: bold;width: 93%;top: 20px;font-size: 20px;text-decoration: underline;">X</div>
      <input id="inputTxtLine" style="width:300px;font-size:20; display: none; margin: 0 auto" onkeypress="promptKeyPress(event)" />
      <textarea id="inputTxtArea" style="width:300px; display: none; margin: 0 auto" rows="4" style="overflow:auto" ></textarea>
      <br />
      <BUTTON id="promptBtn1" class="overlayBtn" onclick="clearPromptMsg(); return false;">OK</BUTTON>
      <BUTTON id="promptBtn2" class="overlayBtn" onclick="clearPromptMsg(); return false;">Cancel</BUTTON>
    </div>

	<div id="promptWSelBox" class="overlay" style="display: none; text-align: center">
      <div onclick="clearPromptWSelMsg()" style="text-align: right;color: white;position: absolute;font-weight: bold;width: 93%;top: 20px;font-size: 20px;text-decoration: underline;">X</div>
      <h1 id="promptWSelHeader" class="overlayHeader"></h1>
      <table id="optionTable2" style="margin: 0 auto">
      </table><br /><br /><br />
      <input id="inputTxtLine2" style="width:300px;font-size:20; display: none; margin: 0 auto" onkeypress="promptWSelKeyPress(event)" />
      <textarea id="inputTxtArea2" style="width:300px; display: none; margin: 0 auto" rows="4" style="overflow:auto" ></textarea>
      <br />
      <BUTTON id="promptWSelBtn1" class="overlayBtn" onclick="clearPromptWSelMsg(); return false;">OK</BUTTON>
      <BUTTON id="promptWSelBtn2" class="overlayBtn" onclick="clearPromptWSelMsg(); return false;">Cancel</BUTTON>
    </div>


	<div id="smallBox" class="overlay" style="display: none; width: 350px; height: 200px; background-color: white; left: 45%; top:20%; text-align: center">
      <h1 id="smallHeader" class="overlayHeader" style="color: black; text-align: center; font-size: 28px"></h1>
      <BUTTON id="smallBtn" class="overlayBtn" onclick="clearSmallMsg(); return false;">OK</BUTTON>
    </div>