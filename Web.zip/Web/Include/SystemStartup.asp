<%

	function cbsInit()
		dim tempStoreID, tempTerminalID, ssql, objRst
		dim tempStoreGUID

		if trim(request.querystring("dbname")) <> "" then
			selectDatabase request.querystring("dbname")
			response.redirect "/mainapp/start3.asp"
		elseif Session("shahcorpDSN") = "" then
			selectDatabase "default"
			response.redirect "/mainapp/start3.asp"
		end if
		
		tempStoreID = Request.Cookies("storeID") 
		tempTerminalID = Request.Cookies("terminalID")
		tempStoreGUID = Request.Cookies("storeGUID")
	
		if tempStoreID = "" or tempTerminalID = "" then
			Response.Redirect "/MainApp/GetStoreTerminal.asp"
		else
			Response.Cookies("storeID") = tempStoreID
			Response.Cookies("terminalID") = tempTerminalID
	
			Response.Cookies("storeID").Expires = dateadd("yyyy", 10, now())
			Response.Cookies("terminalID").Expires = dateadd("yyyy", 10, now())
	
			Session("storeID") = tempStoreID
			Session("terminalID") = tempTerminalID
	
			ssql = "Select name, guid from Store where storeID=" & tempStoreID
			set objRst = getdisconnectedRecordset(ssql)
			if objRst.Recordcount > 0 then
				Session("storeName") = objRst.Fields("name")
	
				if trim(tempStoreGUID) = "" then
					Response.Cookies("storeGUID") = objRst("guid")
					Response.Cookies("storeGUID").Expires = dateadd("yyyy", 10, now())
				elseif trim(tempStoreGUID) <> trim(objRst("guid")) then
					Response.Redirect "/MainApp/GetStoreTerminal.asp"
				end if
			end if
			
			setPageTimeouts tempStoreID
		end if
	end function
	
	function setPageTimeouts(storeid)
		dim query, rs
		
		query = " select globalpagetimeout from miscsetup where storeid = " & storeid
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			session("timeout_global") = rs(0)
		else
			session("timeout_global") = 10
		end if
		
		query = " select location, timeout from pagetimeout where storeid = " & storeid
		set rs = getdisconnectedrecordset(query)
		
		while not(rs.eof or rs.bof)
			session("timeout_" + rs("location")) = rs("timeout")
			rs.movenext
		wend
		
		set rs = nothing
	end function
		
		
	function selectDatabase(databaseName)
		dim dbProps
		
		if databaseName = "" then databaseName = "default"

		Session("dbname") = databaseName
		Session("databaseName") = databaseName
	
		dbProps = getDatabaseProps(databaseName)
	
		Session("shahcorpDSN") = dbProps(0)
		Session("TrainingMode") = instr(databaseName, "training") > 0

		Application("shahcorpDSN") = Session("shahcorpDSN")
		Application("LicensedClients") = GetNumberOfLicensedClients(Session("shahcorpDSN"))
	end function
	
	function getDatabaseProps(name)
		dim dbprops(1)
		dim dbtool
		dim dboption
		
		set dbtool = server.createobject("ShahCorpComponents.DbTool")
		set dboption = dbtool.GetDbOption(name)

		dbprops(0) = dboption.ConnectionString
		
		getDatabaseProps = dbprops
	end function
	
	
	
	
	
	function GetNumberOfLicensedClients(DBConnectionString)
		On Error Resume Next
		
		GetNumberOfLicensedClients = 0
		
		dim oValidator
		
		Set oValidator = Server.CreateObject("CBSKeyValidator.KeyManager")
		oValidator.DBConnectionString = DBConnectionString
		
		If Err.Number = 0 Then
			GetNumberOfLicensedClients = oValidator.GetNumberOfClientLicenses()	
		End If
		
		Set oValidator = Nothing
	end function
	

%>
