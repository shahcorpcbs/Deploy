<%


	function CBS_preformScheduledActions()
		dim query, rs
		
		query = " select * from scheduledquery where datediff(second, scheduleddate, getdate()) >= 0 "
		set rs = getdisconnectedrecordset(query)
		
		
		while not (rs.eof or rs.bof)
			CBS_preformScheduledQuery rs("scheduledQueryID")
			CBS_rescheduleQuery rs("scheduledQueryID")
		
			rs.movenext
		wend
		
		set rs = nothing
	end function


	function CBS_rescheduleQuery(scheduledQueryID)
		dim maxIncrements
		dim newScheduledDate
		dim currentDate
		dim query, rs

		maxIncrements = 1000
		
		query = " select scheduleddate, isnull(interval, 0) as interval, intervalunit from scheduledquery where scheduledqueryid = " & scheduledQueryID
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			if rs("interval") > 0 then
				newScheduledDate = rs("scheduleddate")
				currentDate = Date()
				
				while datediff(rs("intervalunit"), newScheduledDate, currentDate) >= 0 and maxIncrements > 0
					newScheduledDate = dateadd(rs("intervalunit"), rs("interval"), newScheduledDate)
					maxIncrements = maxIncrements - 1
				wend
				
				if maxIncrements = 0 then
					newScheduledDate = dateadd(rs("intervalunit"), rs("interval"), currentDate)
				end if
				
				query = " update scheduledquery set "
				query = query & "  scheduleddate = '" & newScheduledDate & "'"
				query = query & ", dateran = getdate() "
				query = query & " where scheduledqueryid = " & scheduledQueryID
				
				qryexecute query
			else
			
				query = " delete from scheduledquery where scheduledqueryid = " & scheduledQueryID
				qryexecute query
			end if
		end if
		

		
		set rs = nothing
	end function
	
	function CBS_preformScheduledQuery(scheduledQueryID)
		dim query, rs
		
		query = " select * from scheduledquery where scheduledqueryid = " & scheduledQueryID
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			select case lcase(rs("destinationtype"))
			case "emailcsv"
				CBS_preformScheduledQueryTable(rs)
			case "emailtable"
				CBS_preformScheduledQueryTable(rs)
			case "emailmerge"
				CBS_preformScheduledQueryMerge(rs)
			end select
		end if
	end function

	
	function CBS_preformScheduledQueryMerge(rs)
		dim formTemplate
		dim fromAddress
		dim fromName
		dim storeID
		
		storeID = session("storeid")
		if storeID = "" then storeID = 1
		
		fromName = CBS_getStoreName(storeID)
		fromAddress = CBS_getStoreEmail(storeID)
		formTemplate = CBS_getHTMLForm(rs("formid"))
		
		CBS_QueryFormMerge rs("name"), rs("query"), formTemplate, rs("destination"), fromAddress, fromName, rs("name")
	end function
	
	function CBS_preformScheduledQueryTable(rs)
		dim query
		dim body
		dim fromAddress
		dim fromName
		dim storeID
		
		storeID = session("storeid")
		if storeID = "" then storeID = 1
		
		
		fromName = CBS_getStoreName(storeID)
		fromAddress = CBS_getStoreEmail(storeID)
		
		query = rs("query")
		
		select case lcase(rs("destinationtype"))
		case "emailtable"
			body = CBS_QueryHtmlTable(query)
		case "emailcsv"
			body = CBS_QueryCSV(query)
		end select
		
		CBS_sendEmail rs("destination"), fromAddress, fromName, rs("name"), body, rs("name")
	end function
	
	

	function CBS_getStoreEmail(storeid)
		dim query, rs

		query = "select isnull(email, '') as email from store where storeid = " & storeid
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			CBS_getStoreEmail = rs("email")
		end if
		
		set rs = nothing
	end function

	function CBS_getStoreName(storeid)
		dim query, rs

		query = "select name from store where storeid = " & storeid
		set rs = getdisconnectedrecordset(query)

		if rs.recordcount > 0 then
			CBS_getStoreName = rs("name")
		end if
		
		set rs = nothing
	end function


		
	function CBS_getHTMLForm(formID)
		dim query, rs
		
		if formID <> "" then
			query = " select html from htmlform where formid = " & formID
			set rs = getdisconnectedrecordset(query)
			
			if rs.recordcount > 0 then
				CBS_getHTMLForm = rs("html") 
			end if
		end if
	end function

	function CBS_QueryFormMerge(queryName, query, formTemplate, emailField, fromEmail, fromName, subject)
		on error resume next
		dim recordCount
		dim formParams
		dim toEmail

		if query <> "" then

			set rs = getdisconnectedrecordset(cstr(query))

			if err.number <> 0 then
				exit function
			end if
			
			if rs.state > 0 then
				recordCount = rs.recordcount
				
				if recordCount > 0 then
					set formParams = getFormParams(formTemplate)

					rs.MoveFirst

					while not (rs.eof or rs.bof)
					  toEmail = rs(trim(emailField))
					  if toEmail <> "" then
  					  		CBS_sendEmail toEmail, fromEmail, fromName, subject, transformQuery(formTemplate, formParams, rs), subject
						end if
						
					  rs.MoveNext
					wend
				end if
			end if
		end if
	end function
	
	function CBS_sendEmail(toEmail, fromEmail, fromName, subject, body, source)
		dim query, rs
		
		query = " insert into emailqueue (toAddress, fromAddress, fromName, subjectLine, bodyText, source) "
		query = query & " values ("
		query = query & "  " & DbCreateQryString(toEmail)
		query = query & ", " & DbCreateQryString(fromEmail)
		query = query & ", " & DbCreateQryString(fromName)
		query = query & ", " & DbCreateQryString(subject)
		query = query & ", " & DbCreateQryString(body)
		query = query & ", " & DbCreateQryString(source)
		query = query & ")"
		
		qryexecute query
	end function
	
	function CBS_QueryCSV(query)
		dim rs
		dim result
		
		result = ""
		
		if query <> "" then
			set rs = getdisconnectedrecordset(cstr(query))
		
			if rs.recordcount > 0 then
				rs.MoveFirst
				dim i, cellValue
			  for i = 0 to rs.Fields.Count - 1
			    result = result & """" & replace(rs.Fields(i).Name, """", """""") & """"
			    if i <> rs.Fields.Count - 1 then result = result & ","
			  next
				  
				result = result & vbcrlf

				while not (rs.eof or rs.bof)
		
				  for i = 0 to rs.Fields.Count - 1
				  	if isnull(rs.Fields(i).Value) then
				  		cellValue = ""
				  	else
				  		cellValue = rs.Fields(i).Value
				  	end if
				  	
				    result = result & """" & replace(cellValue, """", """""") & """"
				    if i <> rs.Fields.Count - 1 then result = result & ","
				  next
		
				  rs.MoveNext
				  
				  if not rs.bof then result = result & vbcrlf
				wend
			end if
		
		end if			

		CBS_QueryCSV = result
	end function
	
	function CBS_QueryHtmlTable(query)
		on error resume next
		dim recordCount
		dim result
		
		result = ""
		
		if query <> "" then

			set rs = getdisconnectedrecordset(cstr(query))
			
			if err.number <> 0 then
				result = result & "<div class=""error"">Error executing query<br>" & query & "</div>"
				exit function
			end if
			
			if rs.state > 0 then
				recordCount = rs.recordcount
				
				if recordCount > 0 then
					result = result & "<DIV id=""queryresults"" name=""queryresults"" style=""width:100%;height:625px"">"
					result = result & "<TABLE class=""itable"" cellspacing=""0"">"
		
					dim i
					
					
					result = result & "<TR>"
					
					for i = 0 to rs.Fields.Count - 1
						if left(rs.Fields(i).Name, 1) <> "_" then
							result = result & "<TH style=""text-align:left"">@@@" & Server.HTMLEncode(rs.Fields(i).Name) & "</TH>"
						end if
					next
					
					result = result & "</TR>"

					rs.MoveFirst
					
					while not (rs.eof or rs.bof)
					  result = result & "<TR>"
					
					  for i = 0 to rs.Fields.Count - 1
						if left(rs.Fields(i).Name, 1) <> "_" then
						  	if isnull(rs.Fields(i).Value) then
						  		result = result & "<TD>&nbsp;</TD>"
						  	else
						   		result = result & "<TD>" & Server.HTMLEncode(rs.Fields(i).Value) & "</TD>"
						    end if
						end if
					  next
					
					  result = result & "</TR>"

					  rs.MoveNext
					wend
					result = result & "</TABLE>"
					result = result & "</DIV>"
				else
					result = result & "<div class=""warning"">No records</div>"
				end if
			end if
		else
			result = result & "<div class=""error"">No query selected</div>"
		end if

		CBS_QueryHtmlTable = result

	end function

%>