
<%
	
	function clone(byVal str, n)
		dim i
		for i = 1 to n : clone = clone & str : next
	end function
	
	function pad_left(value, totalLength, paddingChar)
		pad_left = right(clone(paddingChar, totalLength) & value, totalLength)
	end function
	
	function json_escapequence(digit)
		json_escapequence = "\u00" + right(pad_left(hex(asc(digit)), 2, 0), 2)
	end function
	
	function json_escape(val)
		dim cDoubleQuote, cRevSolidus, cSolidus
		cDoubleQuote = &h22
		cRevSolidus = &h5C
		cSolidus = &h2F
		
		if isnull(val) then exit function
		
		dim i, currentDigit
		for i = 1 to (len(val))
			currentDigit = mid(val, i, 1)
			if asc(currentDigit) > &h00 and asc(currentDigit) < &h1F then
				currentDigit = json_escapequence(currentDigit)
			elseif asc(currentDigit) >= &hC280 and asc(currentDigit) <= &hC2BF then
				currentDigit = "\u00" + right(padLeft(hex(asc(currentDigit) - &hC200), 2, 0), 2)
			elseif asc(currentDigit) >= &hC380 and asc(currentDigit) <= &hC3BF then
				currentDigit = "\u00" + right(padLeft(hex(asc(currentDigit) - &hC2C0), 2, 0), 2)
			else
				select case asc(currentDigit)
					case cDoubleQuote: currentDigit = json_escapequence(currentDigit)
					case cRevSolidus: currentDigit = json_escapequence(currentDigit)
					case cSolidus: currentDigit = json_escapequence(currentDigit)
				end select
			end if
			json_escape = json_escape & currentDigit
		next
	end function
	
	function json_rs(rs, label)
		dim i
		dim result
		dim data_string
		dim fields_string
		
		result = "{" & vbcrlf
		if label <> "" then result = result & "label:""" & json_escape(label) & """," & vbcrlf

		for i = 0 to rs.Fields.Count - 1
			if i > 0 then fields_string = fields_string & ","
			fields_string = fields_string & """" & json_escape(rs.fields(i).name) & """"
		next
			
		result = result & """fields"":[" & fields_string & "]," & vbcrlf
		
		while not(rs.eof or rs.bof)
			if data_string <> "" then data_string = data_string & ","
			data_string = data_string & "["
			for i = 0 to rs.Fields.Count - 1
				if i > 0 then data_string = data_string & ","
				data_string = data_string & """" & json_escape(rs(i)) & """"
			next
			data_string = data_string & "]"
			
			rs.movenext
		wend
		result = result & """data"":[" & data_string & "]" & vbcrlf
		result = result & "}" & vbcrlf
		
		json_rs = result
	end function
	

	function json_col_rs_opt(rs, label, cfilter, opt)
		dim i
		dim result
		dim data_string
		dim fields_string
		dim filter_columns
		
		if rs.recordcount > 0 then
			rs.movefirst
		else
			json_col_rs_opt = "{}"
			exit function
		end if
		
		filter_columns = split(cfilter, ",")
		
		if label <> "" then
			result = "'" & json_escape(label) & "': {" & vbcrlf
		else
			result = "{" & vbcrlf
		end if
		
		if label <> "" then result = result & "label:""" & json_escape(label) & """," & vbcrlf

		for each i in filter_columns
			if i > 0 then fields_string = fields_string & ","
			fields_string = fields_string & """" & json_escape(rs.fields(cint(i)).name) & """"
		next
			
		result = result & "fields:[" & fields_string & "]," & vbcrlf
		
		while not(rs.eof or rs.bof)
			if data_string <> "" then data_string = data_string & ","
			data_string = data_string & "["
			for each i in filter_columns
				if i > 0 then data_string = data_string & ","
				data_string = data_string & """" & json_escape(rs(cint(i))) & """"
			next
			data_string = data_string & "]"
			
			rs.movenext
		wend

		result = result & "data:[" & data_string & "]" & vbcrlf

		if opt <> "" then
			result = result & ", " & opt & vbcrlf
		end if

		result = result & "}" & vbcrlf
		
		json_col_rs_opt = result
	end function
	

	function json_col_rs(rs, label, cfilter)
		json_col_rs = json_col_rs_opt(rs, label, cfilter, "")
	end function
	
%>