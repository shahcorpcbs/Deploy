<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/validateFunction.asp" -->
<!--#include file="../include/services.asp" -->
<!--#include file="../include/messages.asp" -->

<%
	dim licenseKey
	dim licenseName
	dim licenseClients
	dim licenseExpDate
	dim storeName
	dim hostID
	
	
	storeName = session("storeName")

	select case lcase(request.querystring("useraction"))
	case "submit"
		submitKey
	case "home"
		if serverFileExists("/mainapp/start3.asp") then
			response.redirect "/mainapp/start3.asp"
		else
			response.redirect "/mainapp/start.asp"
		end if
	end select
	
	getLicenseDetails
	
	
	function serverFileExists(url)
		dim fso, fsPath
		
		fsPath = Server.MapPath(url)

		set fso = server.createobject("Scripting.FileSystemObject")
		
		serverFileExists = fso.fileExists(fsPath)
		
		set fso = nothing
		
	end function
	
	function getLicenseDetails()

	    if Request.QueryString("SN") <> "" then
	        hostId = Request.QueryString("SN")
	        dim query, rs
	        query = "select * from License"
	        set rs = getdisconnectedrecordset(query)
	        if rs("fullTermCnt") <> "" and rs("boTermCnt") <> "" then
	            licenseClients = cInt(rs("fullTermCnt")) + cInt(rs("boTermCnt"))
	        end if
	        licenseKey = rs("licenseKey")
	        licenseExpDate = rs("ExpiryDate")

	    else
            dim validator

            set validator = Server.CreateObject("CBSKeyValidator.KeyManager")
            validator.DBConnectionString = Session("shahcorpDSN")

            hostID = validator.HostID

            validator.GetLicenseDetails licenseKey, licenseName, licenseExpDate

            licenseClients = validator.GetNumberOfClientLicenses()
		end if
	end function

	function submitKey()
		dim license_key
		dim license_name
		dim license_exp

		license_key = request.form("license_key")
		license_name = request.form("license_name")
		license_exp = request.form("license_exp")

		Set oValidator = Server.CreateObject("CBSKeyValidator.KeyManager")
		oValidator.DBConnectionString = Session("shahcorpDSN")

		oValidator.UpdateLicenseDetails license_key, license_name, license_exp
	end function
%>


<HTML>
<HEAD>

<script type="text/javascript" src="/external/jquery-1.7.1.min.js"></script>

<script type="text/javascript">
	var license_server_url = "http://support.shahcorp.com:8081/licensing/cbs.json";
	var license_server_url2 = "http://support.shahcorp.com/licensing/cbs.json";
	
	function error(txt) {
		alert("Error: " + txt);
	}


	function update_license(key, name, expiration) {
		$("#license_key").val(key);
		$("#license_name").val(name);
		$("#license_exp").val(expiration);
		
		$("#LicenseManagerForm").submit();
	}
	
	function request_license() {
        <% if lcase(request.querystring("Reason")) = "connection" then %>
         var url = '<%= getCommonFullPath("main") %>licenseCheck';
        <% else %>
         var url = '<%= getCommonFullPath("main") %>licenseUpdate';
         <% end if %>
            $.ajax({
                type: "GET",
                url: url,
                dataType: "text",
                timeout: "2000",
                success: function(xhr) {
		                document.LicenseManagerForm.action = "licensemanager.asp?useraction=home";
                        document.LicenseManagerForm.submit();
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    //console.log(xhr);
                    alert("Unable to connect to cbs service");
                }
            });
	}

	
	function manual_renew() {
		var license_key = null;
		
		license_key = prompt("Your host id: " + $("#host_id").val(), $("#license_key").val());
		
		if(license_key) {
			$("#license_key").val(license_key);
			$("#LicenseManagerForm").submit();
		}
	}
	
	function exit() {
		document.LicenseManagerForm.action = "licensemanager.asp?useraction=home";
		document.LicenseManagerForm.submit();
	}
	
	$(document).on("ready", function() {
		$(".action-auto-renew").on("click", request_license);
		$(".action-manual-renew").on("click", manual_renew);
		$(".action-exit").on("click", exit);
	});
</script>

<style type="text/css">
	body {
		font-family: arial,helvetica,verdana,sans-serif;
	}
	button {
		width: 140px;
		height: 50px;
		margin: 2px;
	}
	dt {
		font-weight: bold;
	}
	button.action-auto-renew {
		background-color: #6c0;
		color: #000;
		font-weight: bold;
	}
</style>

</head>
<body>

<h1>Product License Information</h1>
<hr />
<form name="LicenseManagerForm" id="LicenseManagerForm" method="post" action="LicenseManager.asp?useraction=submit">
	<input type="hidden" id="host_id" name="host_id" value="<%=server.htmlencode(hostID)%>">
	<input type="hidden" id="license_name" name="license_name" value="<%=server.htmlencode(licenseName)%>">
	<input type="hidden" id="clients" name="clients" value="<%=server.htmlencode(licenseClients)%>">
	<input type="hidden" id="store_name" name="store_name" value="<%=server.htmlencode(storeName)%>">
	<input type="hidden" id="license_exp" name="license_exp" value="">
	<input type="hidden" id="license_key" name="license_key" value="<%=server.htmlencode(licenseKey)%>">
</form>


<% if lcase(request.querystring("Reason")) = "connection" then %>
<p>Unable to connect to CBS Service. </p>
<p>
    Service must be running to use CBS. Please make sure service is started and able to be connected to and try again.
</p>


<button style="vertical-align: top" class="action-auto-renew">Recheck</button>

<% else %>
<p>Your license does not appear to be valid. It may have either expired or is not valid on this computer.</p>
<p>
	To resolve this issue first try clicking <a class="action-auto-renew" href="#">Auto Renew</a>.
	If this fails contact Shah Corp at 1-877-303-6300 for assistance.
</p>

<button style="vertical-align: top" class="action-auto-renew">Auto Renew<br />(requires internet)</button>
<button class="action-manual-renew">Manual Renew</button>
<button class="action-exit">Exit</button>

<p>
	<dl>
		<dt>Host ID</dt><dd><%=server.htmlencode(hostID)%></dd>
		<dt>License key</dt><dd><%=server.htmlencode(licenseKey)%></dd>
		<dt>License name</dt><dd><%=server.htmlencode(licenseName)%></dd>
		<dt>Store name</dt><dd><%=server.htmlencode(storeName)%></dd>
		<dt>Clients</dt><dd><%=server.htmlencode(licenseClients)%></dd>
		<dt>Expiration date</dt><dd><%=licenseExpDate%></dd>
		</dl>
	</div>
</p>

<% end if %>







</body>
</html>
