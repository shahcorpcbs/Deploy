<%
	class Param
		dim paramName
		dim paramType
		dim paramDefault
		dim startPosition
		dim endPosition
	end class

	function transformQuery(query, params, values, dateString)
		dim item
		dim result
		dim offset
		dim rside
		dim lside
		dim value

		result = query
		offset = 0

		for each item in params.items
			lside = left(result, item.startPosition + offset - 1)
			rside = mid(result, item.endPosition + offset)


			if item.paramName = "Start_Date" then
			    value = "@" & item.paramName & ":" & item.paramType & ":" & dateString
			elseif item.paramName = "End_Date" then
			    value =  "@" & item.paramName & ":" & item.paramType
			else
			    value = "@" & item.paramName & ":" & item.paramType & ":" & values(replace(item.paramName, "@", ""))
			end if

			offset = offset - (item.endPosition - item.startPosition) + len(value)
			result = lside & value & rside
		next

		transformQuery = result

	end function


	function forceValueQuery(query, params)
		dim item
		dim result
		dim offset
		dim rside
		dim lside
		dim value

		result = query
		offset = 0

		for each item in params.items
			lside = left(result, item.startPosition + offset - 1)
			rside = mid(result, item.endPosition + offset)

            if item.paramType = "date" then
                value = "12/12/2090"
            else
			    value = "1"
			end if

			offset = offset - (item.endPosition - item.startPosition) + len(value)
			result = lside & value & rside
		next

		forceValueQuery = result
	end function




	function legalIDChar(ch)
		dim legal
		dim idx

		legal = "abcdefghijklmnopqrstuvwxyz1234567890_/"
		idx = 1

		while idx <= len(legal)
			if mid(legal, idx, 1) = lcase(ch) then
				legalIDChar = true
				exit function
			end if
			idx = idx + 1
		wend

		legalIDChar = false

	end function

	function getQueryParams(query)
		dim idx
		dim idxStart
		dim paramName
		dim paramType
		dim paramDefault
		dim varPrefix
		dim typePrefix
		dim result

		varPrefix = "@"
		typePrefix = ":"

		set result = CreateObject("Scripting.Dictionary")

		idx = instr(1, query, varPrefix, 1)

		while idx > 0
			paramName = ""
			paramType = ""
			paramDefault = ""

			idxStart = idx
			idx = idx + len(varPrefix)

			while idx <= len(query) and legalIDChar(mid(query, idx, 1))
				paramName = paramName & mid(query, idx, 1)
				idx = idx + 1
			wend

			if mid(query, idx, 1) = typePrefix then
				idx = idx + len(typePrefix)
				while idx <= len(query) and legalIDChar(mid(query, idx, 1))
					paramType = paramType & mid(query, idx, 1)
					idx = idx + 1
				wend
				if mid(query, idx, 1) = typePrefix then
					idx = idx + len(typePrefix)
					while idx <= len(query) and legalIDChar(mid(query, idx, 1))
						paramDefault = paramDefault & mid(query, idx, 1)
						idx = idx + 1
					wend
				end if
			end if

			addParam result, paramName, paramType, paramDefault, idxStart, idx

			idx = instr(idx, query, varPrefix, 1)
		wend

		set getQueryParams = result
	end function

	function getSQLDropdown(query, name, default, includeAllOpt)
		dim rs
		set rs = getdisconnectedrecordset(query)

		getSQLDropdown = "<SELECT id=""" & name & """ name=""" & name & """>"
		if includeAllOpt then
			getSQLDropdown = getSQLDropdown & "<OPTION value='-1'"
			if trim(default) = "-1" then
				getSQLDropdown = getSQLDropdown & "selected"
			end if
			getSQLDropdown = getSQLDropdown & ">All</OPTION>"
		end if

		while not(rs.eof or rs.bof)
			getSQLDropdown = getSQLDropdown & "<OPTION value=""" & rs("value") & """"
			if trim(rs("value")) = trim(default) then
				getSQLDropdown = getSQLDropdown & "selected"
			end if
			getSQLDropdown = getSQLDropdown & ">"
			getSQLDropdown = getSQLDropdown & Server.HTMLEncode(rs("name"))
			getSQLDropdown = getSQLDropdown & "</OPTION>"
			rs.movenext
		wend

		getSQLDropdown = getSQLDropdown & "</SELECT>"
	end function

	function getRouteDropdown(storeID, name, default, includeAllOpt)
		dim query

		query = "select name, routenumber as [value] from route where storeid = " & storeID & " order by [value] "

		getRouteDropdown = getSQLDropdown(query, name, default, includeAllOpt)
	end function

	function getCustomerSourceDropdown(storeID, name, default)
		dim query

		query = "select name, customersourceid as [value] from customersourcedomain where storeid = " & storeID & " order by [value] "

		getCustomerSourceDropdown = getSQLDropdown(query, name, default, 0)
	end function

	function getPricelistDropdown(storeID, name, default, includeAllOpt)
		dim query

		query = "select name, pricelistid as [value] from pricelist where storeid = " & storeID

		getPricelistDropdown = getSQLDropdown(query, name, default, includeAllOpt)
	end function

	function getStoreDropdown(name, default)
		dim query

		query = "select name, storeid as [value] from store"

		getStoreDropdown = getSQLDropdown(query, name, default, 0)
	end function

	function getEmployeeDropdown(storeID, name, default)
		dim query

		query = "select employeename as [name], employeeid as [value] from employee where storeid = " & storeID
		query = query & " order by employeename "

		getEmployeeDropdown = getSQLDropdown(query, name, default, 0)
	end function

	function getBitDropdown(name, default)
		dim query

		query = "select 'No' as [name], 0 as [value] union select 'Yes' as [name], 1 as [value] "

		getBitDropdown = getSQLDropdown(query, name, default, 0)
	end function

	function getParamField(param, default, includeAllOpt)
		if default = "" then
			default = item.paramDefault
		end if

		select case param.paramType
		case "customer"
			getParamField = "<INPUT name=""" & item.paramName & """ value=""" & default & """ readonly>"
			getParamField = getParamField & "<INPUT type=""button"" value=""Search"" onclick=""customerSearch('" & item.paramName & "')"">"
		case "employee"
			getParamField = getEmployeeDropdown(session("storeid"), item.paramName, default)
		case "store"
			getParamField = getStoreDropdown(item.paramName, default)
		case "pricelist"
			getParamField = getPricelistDropdown(session("storeid"), item.paramName, default, includeAllOpt)
		case "route"
			getParamField = getRouteDropdown(session("storeid"), item.paramName, default, includeAllOpt)
		case "number"
			getParamField = "<INPUT name=""" & item.paramName & """ value=""" & default & """>"
		case "bit"
			getParamField = getBitDropdown(item.paramName, default)
		case "date"
		    dim dateDefaults

		    dateDefaults = split(default, "_")
		    if ubound(dateDefaults) = -1 then
                dateDefaults = Array(1, "", "")
		    end if

		  if item.paramName = "Start_Date" then
			getParamField = "<select onchange='showHideDates()' id='dateField'>"
			getParamField = getParamField & "<option value='1' "
			if dateDefaults(0) = 1 then
			    getParamField = getParamField & "selected"
			end if
			getParamField = getParamField & ">Today</option>"
			getParamField = getParamField & "<option value='2' "
            if dateDefaults(0) = 2 then
                getParamField = getParamField & "selected"
            end if
            getParamField = getParamField & ">Week To Date</option>"
			getParamField = getParamField & "<option value='6' "
            if dateDefaults(0) = 6 then
                getParamField = getParamField & "selected"
            end if
            getParamField = getParamField & ">Last Week</option>"
			getParamField = getParamField & "<option value='3' "
            if dateDefaults(0) = 3 then
                getParamField = getParamField & "selected"
            end if
            getParamField = getParamField & ">Month To Date</option>"
			getParamField = getParamField & "<option value='9' "
            if dateDefaults(0) = 9 then
                getParamField = getParamField & "selected"
            end if
            getParamField = getParamField & ">Current Month</option>"
			getParamField = getParamField & "<option value='7' "
            if dateDefaults(0) = 7 then
                getParamField = getParamField & "selected"
            end if
            getParamField = getParamField & ">Last Month</option>"
			getParamField = getParamField & "<option value='4' "
            if dateDefaults(0) = 4 then
                getParamField = getParamField & "selected"
            end if
            getParamField = getParamField & ">Year To Date</option>"
			getParamField = getParamField & "<option value='8' "
            if dateDefaults(0) = 8 then
                getParamField = getParamField & "selected"
            end if
            getParamField = getParamField & ">Last Year</option>"
			getParamField = getParamField & "<option value='5' "
            if dateDefaults(0) = 5 then
                getParamField = getParamField & "selected"
            end if
            getParamField = getParamField & ">Custom Range</option>"
			getParamField = getParamField & "<INPUT id='start_Date' name='start_Date' style='margin: 10px; "
			if dateDefaults(0) <> 5 then
			    getParamField = getParamField & "visibility:hidden"
			end if
			getParamField = getParamField & "' "
			if ubound(dateDefaults) = 2 then
			    getParamField = getParamField & "value='" & dateDefaults(1) & "'"
			end if
			getParamField = getParamField & "readonly onclick=""javascript:show_calendar('editEmpReportForm.start_Date');"">"
			getParamField = getParamField & "<INPUT id='end_Date' name='end_Date' "
			if ubound(dateDefaults) = 2 then
			    getParamField = getParamField & "value='" & dateDefaults(2) & "'"
			end if
			if dateDefaults(0) <> 5 then
			    getParamField = getParamField & "style='visibility:hidden' "
			end if
			    getParamField = getParamField & "readonly onclick=""javascript:show_calendar('editEmpReportForm.end_Date');""></td>"
          else
          	getParamField = "<select onchange='showHideOtherDates(""" & item.paramName & """)' id='" & item.paramName & "_sel'>"
			getParamField = getParamField & "<option value='1' "
			if dateDefaults(0) = 1 then
			    getParamField = getParamField & "selected"
			end if
			getParamField = getParamField & ">Today</option>"
			getParamField = getParamField & "<option value='3' "
            if dateDefaults(0) = 3 then
                getParamField = getParamField & "selected"
            end if
            getParamField = getParamField & ">1st of Month</option>"
			getParamField = getParamField & "<option value='5' "
            if dateDefaults(0) = 5 then
                getParamField = getParamField & "selected"
            end if
            getParamField = getParamField & ">Custom Date</option>"
			getParamField = getParamField & "<INPUT name=""" & item.paramName & """ id='" & item.paramName & "_custDate' style='margin: 10px; "
			if dateDefaults(0) <> 5 then
                getParamField = getParamField & "visibility:hidden' "
            else
                getParamField = getParamField & "' value='" & dateDefaults(1) & "'"
            end if
			getParamField = getParamField & "readonly onclick=""javascript:show_calendar('queryParams." & item.paramName & "');"">"
          end if
		case "customersource"
			getParamField = getCustomerSourceDropdown(session("storeid"), item.paramName, default)
		case else
			getParamField = "<INPUT name=""" & item.paramName & """ value=""" & default & """>"
		end select

	end function

	sub addParam(params, paramName, paramType, paramDefault, startPosition, endPosition)
		dim newParam
		dim originalName

		originalName = paramName
		while params.exists(paramName)
			paramName = paramName & "@"
		wend

		set newParam = new Param
		newParam.paramName = paramName
		newParam.paramType = paramType
		newParam.paramDefault = paramDefault
		newParam.startPosition = startPosition
		newParam.endPosition = endPosition

		params.add paramName, newParam

	end sub

%>