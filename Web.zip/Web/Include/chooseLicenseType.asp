<%@ Language=VBScript %>
<%option explicit %>
<!-- #include file="../include/querydatabase.asp" -->
<!-- #include file="../include/ValidateFunction.asp" -->
<!--#include file="../include/security.asp" -->
<!--#include file="../include/messages.asp" -->

<%

    dim fullAvail, boAvail, licenseType, allowedType
    getAvail
    getAllowed

	select case Request.QueryString("release")
	case "1"
		releaseLicense Request.QueryString("licenseType")
	case "0"
		releaseAllLicenses
	end select

	if Request.QueryString("licenseType") <> "" then
	    licenseType =  Request.QueryString("licenseType")
	    activateClient licenseType
		Response.Redirect "/mainapp/start3.asp"
	end if



		function activateClient(licenseType)
    		dim query, terminalid
    		terminalId = session("terminalid")

    		query = " insert into clientterminal (remoteaddr, terminalid, lastseen, licenseType) "
    		query = query & " values ("
    		query = query & "'" & Request.ServerVariables("REMOTE_ADDR") & "'"
    		if terminalid <> "" then
    			query = query & "," & terminalid
    		else
    			query = query & ",null"
    		end if
    		query = query & ",getdate()" & ", " & licenseType & ")"
    		qryexecute query

    		if licenseType = 1 then
    		    query = "update terminal set licenseTypes = 1 where terminalId = " & terminalId
    		    qryexecute query
            end if
    	end function


    function getAvail()
        dim query, rs, currFull, currBo
        query = "select count(*) cnt from clientterminal where licenseType = 1"
        set rs = getdisconnectedrecordset(query)
        currFull = cInt(rs("cnt"))
        query = "select count(*) cnt from clientterminal where licenseType = 2"
        set rs = getdisconnectedrecordset(query)
        currBo = cInt(rs("cnt"))

        fullAvail = cInt(Request.QueryString("fullCnt")) - currFull
        boAvail = cInt(Request.QueryString("boCnt")) - currBo

    end function


    function getAllowed()
        dim query, rs, terminalid
        terminalId = session("terminalid")

        query = "select licenseTypes from terminal where terminalId = " & terminalId
        set rs = getdisconnectedrecordset(query)
		if rs.recordcount > 0 then
		     allowedType = rs("licenseTypes")
		     'This only happens if a terminal is set to only be back office for a customer that has no back office licenses
		      if allowedType = 2 and cInt(Request.QueryString("boCnt")) = 0 then
		        allowedType = 0
		        query = "update terminal set licenseTypes = 0 where terminalId = " & terminalId
                qryexecute query
		     end if

        else
            allowedType = 0
		end if

    end function



	function releaseLicense(licenseType)
		dim query
		
		query = " delete from clientterminal " _
		    & " where licenseType = " & licenseType & " and  clientterminalid in " _
		    & " (select top 1 clientterminalid from clientterminal where licenseType = " & licenseType _
		    & " order by lastseen asc)"
		
		qryexecute query
	end function
	
	function releaseAllLicenses()
		dim query
		
		query = " delete from clientterminal "

		qryexecute query
	end function
%>

<HTML>
<HEAD>
<link href="../script/stylesheet.css" rel="stylesheet" type="text/css">


</HEAD>
<BODY topmargin=0 leftmargin=0 onLoad="init()"><!-- #include file="../include/banner.inc" -->
<script language="javascript" type="text/javascript" src="/Script/webui.js"></script>

<script language="JavaScript">
    var selectedLicType;


	function selectLicenseType(type) {
	    document.getElementById("fullBtn").disabled = true;
	    <% if Request.QueryString("boCnt") <> 0 then %>
	    document.getElementById("backBtn").disabled = true;
	    <% end if %>

	    if  ((type == 1 && <%= fullAvail %> < 1) || (type == 2 && <%= boAvail %> < 1)) {
	        selectedLicType = type;
            cbs_select("There are no licenses of this type available, do you wish to release a single license or all licenses?",
                3, 'All|Single', 'releaseLicenses')
	    }
	    else {
            document.chooseLicForm.action = "?licenseType=" + type;
            document.chooseLicForm.submit();
        }
	}

	function releaseLicenses(selectOpt) {
	    clearOptionMsg();
	    if (selectOpt != 2) {
            document.chooseLicForm.action = "?licenseType=" + selectedLicType + "&release=" + selectOpt;
            document.chooseLicForm.submit();
	    }
	}

	function init() {
	    <% if allowedType <> 0 then %>
	        selectLicenseType(<%=allowedType%>);
	    <% end if %>
	}

</script>
<FORM name="chooseLicForm" ID="chooseLicForm" METHOD="POST" ACTION="/mainapp/exit.asp"></FORM>

	<TABLE WIDTH=500 STYLE="BACKGROUND-COLOR:
	 #2F4F4F" ALIGN=center BORDER=0 CELLSPACING=1 CELLPADDING=5>
		<TR>
			<TH BGCOLOR="#2F4F4F" STYLE="COLOR: #ffffff" COLSPAN="2" >Choose License Type</TD>
		</TR>

		<TR>
			<TD STYLE="BACKGROUND-COLOR: #f7fbfc;color:#ff2222;padding-top:10px;padding-bottom:10px;text-align:center;vertical-align:middle;" COLSPAN="2" >
			Is This a Full License Terminal or a Back Office Terminal?<br />
			There are <%= fullAvail %> out of <%= Request.QueryString("fullCnt") %> full licenses available, and <%= boAvail %> of <%= Request.QueryString("boCnt") %> back office licenses available.

			</TD>
			
		</TR>
			<TD align="center">
			<input id="fullBtn" type="button" value="Full License" onclick="selectLicenseType(1)" />
			<% if Request.QueryString("boCnt") <> 0 then %>
			<input id="backBtn" type="button" value="Back Office" onclick="selectLicenseType(2)" />
			<% end if %>
			</TD>
		<TR>
			
		</TR>
	</TABLE>

</BODY>
</HTML>
