
<%

	function CBS_closeManifest(manifestid)
		dim query, rs


		query = " update manifest set [open] = 0 "
		query = query & " where parentmanifestid = " & manifestid

		qryexecute query
	end function

	function CBS_setManifestName(manifestid, name)
		dim query, rs


		query = " update manifest set name = '" & name & "'"
		query = query & " where manifestid = " & manifestid

		qryexecute query
	end function

	function CBS_setManifestType(manifestid, mtype)
		dim query, rs


		query = " update manifest set [type] = '" & mtype & "'"
		query = query & " where manifestid = " & manifestid

		qryexecute query
	end function
	
	function CBS_nameManifest(manifestid, name)
		dim query, rs


		query = " update manifest set name = '" & name & "'"
		query = query & " where manifestid = " & manifestid

		qryexecute query
	end function
	
	function CBS_inactiveManifest(manifestid)
		dim query, rs


		query = " update manifest set [active] = 0"
		query = query & " where manifestid = " & manifestid

		qryexecute query
	end function

	function CBS_createManifest(name, parentmanifestid)
		dim query, rs
		dim manifestID


		query = " insert into manifest (name, parentmanifestid) "
		query = query & " values( "
		query = query & " '" & DBStr(name) & "'"
		query = query & ", " & DbCreateQryNumeric(parentmanifestid)
		query = query & ");"
		query = query & " select scope_identity() "

		openConnection
		dbInsert query
		set rs = dbSelect("select scope_identity() as NewID")
		manifestID = rs("NewID")
		set rs = nothing
		closeConnection

		CBS_createManifest = clng(manifestID)
	end function

	function CBS_addInvoiceToManifest(manifestID, invoiceNumber, force)
		CBS_addInvoiceToManifest = CBS_addInvoiceLocationToManifestEx(manifestID, invoiceNumber, "", 1, 1, force)
	end function
	

	function CBS_removeInvoiceFromManifest(manifestID, invoiceNumber)
		dim query, rs
		dim manifestItemID
		dim iInvoiceNumber

		iInvoiceNumber = left(invoiceNumber, 20)

		query = " select manifestitemid from manifestitem "
		query = query & " where manifestid = " & manifestID
		query = query & " and invoicenumber = '" & DBStr(iInvoiceNumber) & "'"

		set rs = getdisconnectedrecordset(query)
	
		if rs.recordcount = 0 then
			CBS_removeInvoiceFromManifest = -1
		else
			query = " delete from manifestitem "
			query = query & " where manifestid = " & manifestID
			query = query & " and invoicenumber = '" & DBStr(iInvoiceNumber) & "'"

			qryexecute query
	
			CBS_removeInvoiceFromManifest = 1
		end if
	end function
	

	function CBS_rackManifest(manifestID, terminalID, employeeID)
		dim query, rs
		
		qryexecute " delete from pendingracklocations " 
		
		query = " update manifest set dateracked = getdate() "
		query = query & " where manifestid = " & manifestid

		qryexecute query
		
		query = " insert into pendingracklocations "
		query = query & " (terminalid, employeeid, invoicenumber, startracklocation, notes, errorno) "
		query = query & " select " & terminalID
		query = query & ", " & employeeID
		query = query & ", invoicenumber, location, 'From manifest', 0 from manifestitem "
		query = query & " where manifestid = " & manifestID
		query = query & " and location <> '' "
		query = query & " order by manifestitemid desc "

		qryexecute query

		query = "exec RackPendingRackLocations "
		query = query & terminalID & ", NULL, 0"

		qryexecute query
		
		qryexecute " delete from pendingracklocations " 

	end function


	function CBS_addInvoiceLocationToManifest(manifestID, invoiceNumber, location, force)
		CBS_addInvoiceLocationToManifest = CBS_addInvoiceLocationToManifestEx(manifestID, invoiceNumber, location, 1, 1, force)
	end function

	function CBS_GetInvoiceLocation(invoiceNumber)
		dim query, rs
		
		query = " select top 1 rackassignment.racklocationstart from rackassignment "
		query = query & " inner join ticket on rackassignment.ticketnumber = ticket.ticketnumber "
		query = query & " where ticket.invoicenumber = '" & invoicenumber & "'"
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			CBS_GetInvoiceLocation = rs(0)
		end if
		
		set rs = nothing
	end function

	function CBS_GetInvoiceTicketNumber(invoiceNumber)
		dim query, rs
		
		query = " select ticket.ticketnumber from ticket where ticket.invoicenumber = '" & invoicenumber & "'"
		
		set rs = getdisconnectedrecordset(query)
		
		if rs.recordcount > 0 then
			CBS_GetInvoiceTicketNumber = rs(0)
		end if
		
		set rs = nothing
	end function
	
	function updateInvoiceStatus(ManifestItemID)
		query = " UPDATE ManifestItem "
		query = query & " SET InvoiceStatus =  "
		query = query & " CASE invoiceType WHEN 'Q' THEN 'Quick' "
		query = query & " ELSE CASE onHold WHEN 1 THEN 'Held'  "
		query = query & " ELSE CASE ticketStatus "
		query = query & " WHEN 'AC' THEN 'Open' "
		query = query & " WHEN 'VO' THEN 'Voided' "
		query = query & " WHEN 'FI' THEN 'Finished' "
		query = query & " END	END	END "
		query = query & " FROM ManifestItem INNER JOIN Ticket ON ManifestItem.InvoiceNumber = Ticket.InvoiceNumber "
		query = query & " WHERE ManifestItemID = " & ManifestItemID

		qryexecute query
	
	end function

	function CBS_addInvoiceLocationToManifestEx(manifestID, invoiceNumber, location, invoiceNumberKeyed, locationKeyed, force)
		dim query, rs
		dim manifestItemID
		dim iInvoiceNumber
		dim iLocation
		dim ticketNumber
		
		if invoiceNumberKeyed = "" then invoiceNumberKeyed = 1
		if locationKeyed = "" then locationKeyed = 1
		
		iInvoiceNumber = left(invoiceNumber, 20)
		iLocation = left(location, 50)

		query = " select manifestitemid from manifestitem "
		query = query & " where manifestid = " & manifestID
		query = query & " and invoicenumber = '" & DBStr(iInvoiceNumber) & "'"

		set rs = getdisconnectedrecordset(query)
	
		if not force and rs.recordcount > 0 then
			CBS_addInvoiceLocationToManifestEx = -1
		else
			query = " insert into manifestitem (manifestid, invoicenumber, location, invoicenumberkeyed, locationkeyed, previouslocation) "
			query = query & " values(" & manifestID
			query = query & ", '" & DBStr(iInvoiceNumber) & "'"
			if iLocation <> "" then
			query = query & ", '" & DBStr(iLocation) & "'"
			else
			query = query & ", null"
			end if
			query = query & ", " & invoiceNumberKeyed
			query = query & ", " & locationKeyed
			query = query & ", '" & DBStr(CBS_GetInvoiceLocation(iInvoiceNumber)) & "'"
			query = query & ")"
	

			openConnection
			dbInsert query
			set rs = dbSelect("select scope_identity() as NewID")
			manifestItemID = rs("NewID")
			set rs = nothing
			closeConnection
	
			updateInvoiceStatus manifestItemID
			

			CBS_addInvoiceLocationToManifestEx = clng(manifestItemID)
		end if
	end function
	
	function CBS_addLocationToManifestInvoice(manifestID, invoiceNumber, location)
		dim query, rs
		dim iInvoiceNumber
		dim iLocation
		dim ticketNumber
		
		iInvoiceNumber = left(invoiceNumber, 20)
		iLocation = left(location, 50)

		query = query & " update manifestitem set location = '" & DBStr(iLocation) & "'"
		query = query & " where manifestid = " & manifestID
		query = query & " and invoicenumber = '" & DBStr(iInvoiceNumber) & "'"

		qryexecute query

			
		CBS_addLocationToManifestInvoice = 1
	end function

%>