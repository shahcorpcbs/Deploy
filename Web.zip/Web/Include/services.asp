<%
    dim servicePort
    dim useNew, custIconPath, rackingIconPath, manIconPath, routeIconPath, toolsIconPath, retailIconPath, empIconPath

    dim appQuery, appRs
    appQuery = "select * from CBSAppearance"
    set appRs = getdisconnectedrecordset(appQuery)
    useNew = appRs("useNew")
    custIconPath = appRs("custIconPath")
    rackingIconPath = appRs("rackingIconPath")
    manIconPath = appRs("manIconPath")
    routeIconPath = appRs("routeIconPath")
    toolsIconPath = appRs("toolsIconPath")
    retailIconPath = appRs("retailIconPath")
    empIconPath = appRs("empIconPath")



	function getServicePort()
		dim query, rs

		if session("storeid") <> "" then
		    query = "select cbsServicePort from miscsetup where storeid = " & session("storeid")
		else
		    query = "select cbsServicePort from miscsetup"
		end if
		set rs = getdisconnectedrecordset(query)
		servicePort = rs("cbsServicePort")
	end function

	function getGUIServicePort()
		dim query, rs

		if session("storeid") <> "" then
		    query = "select cbsGUIServicePort from miscsetup where storeid = " & session("storeid")
		else
		    query = "select cbsGUIServicePort from miscsetup"
		end if
		set rs = getdisconnectedrecordset(query)
		getGUIServicePort = rs("cbsGUIServicePort")
	end function

	function getAddressPath(folder)

        Dim path, iFirstSlash, ipAddress
        path = lcase(Request.ServerVariables("HTTP_REFERER"))
        iFirstSlash = InStr(path, "/" & folder) - 1
        if iFirstSlash <> -1 then
            ipAddress = Left(path, iFirstSlash)
        else
            ipAddress = path
        end if

        getAddressPath = ipAddress

	end function

	function getShortPath(serviceId)

		dim query, rs, path
		getServicePort
	    query = "select Location from CBSServicesIP where id = " & serviceId
        set rs = getdisconnectedrecordset(query)
        path = ":" & servicePort & "/" & rs("Location") & "/"
	    getShortPath = path
	end function

	function getMessengerShortPath()
	    getMessengerShortPath = getShortPath(1)
	end function

	function getPrinterShortPath()
	    getPrinterShortPath = getShortPath(2)
	end function

	function getClearentShortPath()
	    getClearentShortPath = getShortPath(3)
	end function

	function getDeliveryShortPath()
	    getDeliveryShortPath = getShortPath(4)
	end function

	function getDeviceShortPath()
	    getDeviceShortPath = getShortPath(5)
	end function

	function getCommonShortPath()
		getServicePort
	    getCommonShortPath = ":" & servicePort & "/rest/common/"
	end function


	function getMessengerFullPath(folder)
	    getMessengerFullPath = getAddressPath(folder) & getShortPath(1)
	end function

	function getLocalPrinterAddress(terminalId)
	    dim query, rs, printerIPAddress
	    if terminalId <> "" then
             query = "select useLocalService, remotePrintingAddress from Terminal where terminalId = " & terminalId
             set rs = getdisconnectedrecordset(query)
             if rs.recordcount > 0 then
                 if rs("useLocalService") then
                    printerIPAddress = Request.ServerVariables("HTTP_X_FORWARDED_FOR")
                    If printerIPAddress = "" Then
                      printerIPAddress = Request.ServerVariables("REMOTE_ADDR")
                    End If
                 else
                    printerIPAddress = rs("remotePrintingAddress")
                 end if
             else
                printerIPAddress = Request.ServerVariables("HTTP_X_FORWARDED_FOR")
                If printerIPAddress = "" Then
                  printerIPAddress = Request.ServerVariables("REMOTE_ADDR")
                End If
             end if
         else
                printerIPAddress = Request.ServerVariables("HTTP_X_FORWARDED_FOR")
                If printerIPAddress = "" Then
                  printerIPAddress = Request.ServerVariables("REMOTE_ADDR")
                End If
         end if

	     getLocalPrinterAddress = printerIPAddress
	end function

	function getLocalPrinterFullPath(terminalId)
	     getLocalPrinterFullPath = getLocalPrinterAddress(terminalId) & getShortPath(2)
	end function

	function getPrinterFullPath(folder)
	    getPrinterFullPath = getAddressPath(folder) & getShortPath(2)
	end function

	function getClearentFullPath(folder)
	    getClearentFullPath = getAddressPath(folder) & getShortPath(3)
	end function

	function getDeliveryFullPath(folder)
	    getDeliveryFullPath = getAddressPath(folder) & getShortPath(4)
	end function

	function getDeviceFullPath(folder)
	    getDeviceFullPath = getAddressPath(folder) & getShortPath(5)
	end function

	function getCommonFullPath(folder)
	    getCommonFullPath = getAddressPath(folder) & getCommonShortPath
	end function

	function isMessengerEnabled()
	    dim query, rs

	    query = "select active from CBSServicesIP where id = 1"
	    set rs = getdisconnectedrecordset(query)

        isMessengerEnabled = rs("active")
	end function

    function isMessageEnabledForCustomer(queryId, customerId)
        dim query, rs, result
        query = "select triggerType from QueryAlert where id = " & queryId
        set rs = getdisconnectedrecordset(query)

        if rs("triggerType") <> 0 then
            query = "select sms, email from CustomerMessageSetup where QueryId = " & queryId & " and customerId = " & customerId
            set rs = getdisconnectedrecordset(query)
            if rs.recordCount = 0 then
                query = "select sms, email from CustomerMessageSetup where QueryId = " & queryId & " and customerId = 0"
                set rs = getdisconnectedrecordset(query)
            end if

            if rs.recordCount > 0 then
                if rs("sms") then
                    result = "1"
                else
                    result = "0"
                end if
                if rs("email") then
                    result = result & "1"
                else
                    result = result & "0"
                end if
           end if
        end if
        isMessageEnabledForCustomer = result
    end function

%>