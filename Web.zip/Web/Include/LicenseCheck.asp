
<%
	Dim oKeyMgr, licenseKey, query, rs, licenseStyle, fullTermCnt, boTermCnt, daysLeft

    query = "select licenseKey from License"
    set rs = getdisconnectedrecordset(query)
    licenseKey = rs("licenseKey")

    if len(licenseKey) = 24 and Mid(licenseKey, 5, 1) = "-" and Mid(licenseKey, 10, 1) = "-" and Mid(licenseKey, 15, 1) = "-" then
        licenseStyle = 1

        Set oKeyMgr = Server.CreateObject("CBSKeyValidator.KeyManager")
        oKeyMgr.DBConnectionString = Session("shahcorpDSN")
        If oKeyMgr.IsLicensePresent() Then
            if oKeyMgr.ValidateExistingLicense() Then
                'Do nothing
            else
                'Redirect to LicenseManager.asp
                Response.Redirect "/MainApp/LicenseManager.asp?Reason=Invalid"
            end if
        Else
            'Redirect to LicenseManager.asp
            Response.Redirect "/MainApp/LicenseManager.asp?Reason=NotFound"
        End If

        Set oKeyMgr = Nothing
    else
        licenseStyle = 2
        'on error resume next
        dim path, httpRequest, postResponse

            if InStr(lcase(Request.ServerVariables("HTTP_REFERER")), "include") <> 0 then
                path = getCommonFullPath2("include") & "/licenseCheck"
            else
                path = getCommonFullPath2("mainapp") & "/licenseCheck"
            end if

        Set httpRequest = Server.CreateObject("MSXML2.ServerXMLHTTP")
        httpRequest.Open "GET", path, false
        httpRequest.Send
        postResponse = httpRequest.ResponseText

		If Err.number <> 0 Then
            Response.Redirect "/MainApp/LicenseManager.asp?Reason=Connection"
        elseif postResponse = "" then
            Response.Redirect "/MainApp/LicenseManager.asp?Reason=Invalid"
        else
            dim responseFields
            responseFields = split(postResponse, "|")

            if responseFields(0) = "3" or responseFields(0) = "4" then
                Response.Redirect "/MainApp/LicenseManager.asp?Reason=Invalid&SN=" & Server.HTMLEncode(responseFields(1))
            else
                fullTermCnt = responseFields(1)
                boTermCnt = responseFields(2)
                if responseFields(0) = "1" then
                    daysLeft = responseFields(3)
                elseif responseFields(0) = "2" then
                    'Grace period
                end if
            end if
        end if
    end if

	function getLicenseDetails(key, name, expiration)
		Dim oKeyMgr
		Set oKeyMgr = Server.CreateObject("CBSKeyValidator.KeyManager")

		getLicenseDetails = oKeyMgr.GetLicenseDetails(key, name, expiration)

	end function

	function getCommonFullPath2(folder)
        getCommonFullPath2 = getAddressPath2(folder) & getCommonShortPath2
    end function

	function getAddressPath2(folder)
            Dim path, iFirstSlash, ipAddress
            path = lcase(Request.ServerVariables("HTTP_REFERER"))
            iFirstSlash = InStr(path, "/" & folder) - 1
            if iFirstSlash <> -1 then
                ipAddress = Left(path, iFirstSlash)
            else
                ipAddress = path
            end if

            getAddressPath2 = ipAddress

    end function

	function getCommonShortPath2()
	    dim query, rs, servicePort
		query = "select cbsServicePort from miscsetup"
        set rs = getdisconnectedrecordset(query)
	    getCommonShortPath2 = ":" & rs("cbsServicePort") & "/rest/common/"
	end function

%>
