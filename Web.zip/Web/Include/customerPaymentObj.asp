<%
	'******************************************************************************
	' Name   : customerPaymentObj.asp
    '==============================================================================
	' Used to retrieve payment type, credit card, account balance,
	'  credit limit, account type, calculated account values 
	'  from Customer table.
    '=======================================================================
    ' Date           Changed By    Change Log
    ' -----------------------------------------------------------------------
    ' 5-Sep-2003	 Johnston		Added user defined prompt if account credit
    ' 20-Jan-2004	 Johnston		Added fields for other credit card info
	'*****************************************************************

	function initializeCustomerPaymentInfo()
		dim ObjCustPayment
		dim ssql
		dim storeId
		dim objResultSet
		dim custSeqNumber
		
		storeId =Session("storeID")
		custSeqNumber = Session("customersequencenumber")
		set ObjCustPayment = Server.CreateObject("Scripting.Dictionary")
		set Session("customerPayment") = ObjCustPayment
		ssql = "Select c1.PaymentTypeName, "_
				& " c1.billingAddress1, c1.billingAddress2, c1.billingAddress3, c1.billingCity, c1.billingState, c1.billingZipCode, " _
				& " isnull(isnull(c3.PaymentTermsID, c2.PaymentTermsID), c1.PaymentTermsID) as PaymentTermsID, dbo.getAccountBalance(c1.customersequencenumber, null) as AccountBalance, isnull(isnull(c3.CreditLimit, c2.CreditLimit), c1.CreditLimit) as CreditLimit, isnull(isnull(c3.permanentAccount, c2.permanentAccount), c1.permanentAccount) as permanentAccount, " _
				& " isnull(isnull(c3.temporaryAccount, c2.temporaryAccount), c1.temporaryAccount) as temporaryAccount From Customer c1 " _
				& " left outer join route r on c1.routeNumber = r.routeNumber left outer join Customer c3 on r.billingResponsibility = c3.customerSequenceNumber " _
				& " left outer join Customer c2 on c1.billingCustomerSeq = c2.customerSequenceNumber " _
				& " Where c1.customerSequenceNumber=" & custSeqNumber
		set objResultSet = getDisconnectedRecordset(ssql)
		if objResultSet.Recordcount > 0 then
			objResultSet.MoveFirst
			ObjCustPayment.Add "PaymentTypeName", objResultSet.Fields("PaymentTypeName").Value
			
			ObjCustPayment.Add "billingAddress1", objResultSet.Fields("billingAddress1").Value			
			ObjCustPayment.Add "billingAddress2", objResultSet.Fields("billingAddress2").Value			
			ObjCustPayment.Add "billingAddress3", objResultSet.Fields("billingAddress3").Value			
			ObjCustPayment.Add "billingCity", objResultSet.Fields("billingCity").Value			
			ObjCustPayment.Add "billingState", objResultSet.Fields("billingState").Value			
			ObjCustPayment.Add "billingZipCode", objResultSet.Fields("billingZipCode").Value			

			ObjCustPayment.Add "PaymentTermsID", objResultSet.Fields("PaymentTermsID").Value
			ObjCustPayment.Add "AccountBalance", objResultSet.Fields("AccountBalance").Value
			ObjCustPayment.Add "CreditLimit", objResultSet.Fields("CreditLimit").Value
			ObjCustPayment.Add "permanentAccount", objResultSet.Fields("permanentAccount").Value
			ObjCustPayment.Add "temporaryAccount", objResultSet.Fields("temporaryAccount").Value
			ObjCustPayment.Add "accountBalance", objResultSet.Fields("accountBalance").Value
		end if
		
		'Following lines added by J.Johnston, 5 Sept 2003
		'Used to capture credit balance
		dim rstTemp
		dim sqltxt
		dim l_accountbalance
	
		l_accountbalance = 0.00
	
		sqltxt = "Execute dbo.GetCustomerAccountBalance " & custSeqNumber
	
		set rstTemp = getdisconnectedrecordset(sqltxt)
	
		if rstTemp.recordcount > 0 then
			l_accountbalance =  rstTemp("accountbalance")
			if isnull(l_accountbalance) then
				l_accountbalance = 0.00
			else
				l_accountbalance= cdbl(l_accountbalance)
			end if
			ObjCustPayment.Add "creditBalance", l_accountbalance 	
		end if			
		rsttemp.close
		set rstTemp = nothing	
		'End addition by J.Johnston, 5 Sept 2003				
		
		
	end function
		
%>
