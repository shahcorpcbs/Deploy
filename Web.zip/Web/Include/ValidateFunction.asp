<%
	function checkforNull( varg)
		checkfornull = varg
		if  isnull(varg) then
			checkfornull= ""
		end if
	end function

	function DbCreateQryString(varg)
	'Response.Write varg
	DbCreateQryString = "NULL"
	if not isnull(varg) and len(trim(varg))<> 0 then
		'DbCreateQryString = "'" & varg & "'"
		'Modified the above line by Haribabu (Dec. 18, 2002)
		DbCreateQryString = "'" & Replace(varg, "'", "''") & "'"
	end if
	end function


	function DbQryString(varg)
		DbQryString = "'" & Replace(varg, "'", "''") & "'"
	end function

	function DBStr(varg)
		DBStr = Replace(varg, "'", "''")
	end function

	function evalRequestValue(varg)
	 evalRequestValue = " Null "
	 if isnull(varg) or trim(varg)= "" then
		evalRequestValue = "0"
	else
		evalRequestValue = "1"
	end if

	end function

	function DbCreateQryNumeric(varg)
	'Response.Write varg
	DbCreateQryNumeric = " NULL "
	if not isnull(varg) and trim(varg) <> "" then
		DbCreateQryNumeric =  varg
	end if
	end function

	function FormatDate1(varg)
		FormatDate1=varg
		if not isnull(varg) then
			if isdate(varg) then
				formatdate1 = formatdatetime(varg,vbshortdate)
			end if

		end if

	end function
	
	function MaskString(str, showCnt)
		dim hideCnt
		hideCnt = len(str) - showCnt
		if hideCnt < 0 then hideCnt = 0
		MaskString = String(hideCnt, "X") & right(str, showCnt)
	end function


	Function IIf(condition,value1,value2)
	'*******************************************************************
	'* Author:			Vinny Ramachandran (Yash Technologies)
	'*
	'* Purpose:			A utility function for Inline If function.
	'
	'* Date   :			June 21, 2002
	'*******************************************************************

		If condition Then IIf = value1 Else IIf = value2

	End Function


Function WordWrap(strWords, intWrapLength, strWrapText)
	'*******************************************************************
	'* Author:			Haribabu Sirandas (Yash Technologies)
	'*
	'* Purpose:			An utility function to wrap the line to a specified length.
	'
	'* Date   :			October 11, 2002
	'*******************************************************************
    Dim arrWords,  xCount
	Dim wordLength
	Dim wrappedString
    Dim intRunningLength

    on error resume next
    
	wrappedString = ""
    intRunningLength = 0

    '*** Split the words into an array using a space.
    arrWords = Split(strWords, " ")

    '*** Now start looping through the words and adding the wrap text
    For xCount = LBound(arrWords) To UBound(arrWords)

        wordLength = Len(arrWords(xCount))

        '*** Calculate the running length of the words
        If (intRunningLength + wordLength) > intWrapLength Then

			'If the word length is longer than the Wrapping length split and wrap the line
        	if wordLength > intWrapLength then
				if intRunningLength <> 0 then
        			wrappedString = wrappedString & " "
        		end if
        		do while wordLength > intWrapLength
        			wrappedString = wrappedString & mid(arrWords(xCount), 1, intWrapLength - intRunningLength) & strWrapText
        			arrWords(xCount) = mid(arrWords(xCount), intWrapLength - intRunningLength + 1)
        			wordLength = Len(arrWords(xCount))
        			intRunningLength = 0
        		loop
        		if wordLength > 0 then
           			wrappedString = wrappedString & arrWords(xCount)
            		intRunningLength = wordLength + 1
            	end if
            'If the word length is equal OR less than the Wrapping length wrap the line and append the word
			else
           		wrappedString = wrappedString & strWrapText & arrWords(xCount)
				intRunningLength = wordLength + 1
			end if
        else
        	if intRunningLength <> 0 then
        		wrappedString = wrappedString & " "
        	end if
        	wrappedString = wrappedString & arrWords(xCount)
        	intRunningLength = intRunningLength + wordLength + 1
        End If

    Next

	WordWrap = wrappedString

End Function


Function WordTrim(strWords, maxLength)
	'*******************************************************************
	'* Author:			Haribabu Sirandas (Yash Technologies)
	'*
	'* Purpose:			An utility function to trim the line to a specified length.
	'					(Do not trim the words if it exceeds the max length)
	'* Date   :			October 21, 2002
	'*******************************************************************
    Dim arrWords,  xCount
    Dim intRunningLength
	Dim endString

	Dim wordLength
	Dim trimmedString

	endString = " ..."
	trimmedString = ""
    intRunningLength = 0

    '*** Split the words into an array using a space.
    arrWords = Split(strWords, " ")

    '*** Now start looping through the words and adding the wrap text
    For xCount = LBound(arrWords) To UBound(arrWords)

        wordLength = Len(arrWords(xCount))

        '*** Calculate the running length of the words
        If (intRunningLength + wordLength) > maxLength Then
        	if intRunningLength = 0 then
        			trimmedString = mid(arrWords(xCount), 1, maxLength) & endString
			else
           		trimmedString = trimmedString & endString
           	end if
			exit for
        else
        	if intRunningLength <> 0 then
        		trimmedString = trimmedString & " "
        	end if
        	trimmedString = trimmedString & arrWords(xCount)
        	intRunningLength = intRunningLength + wordLength + 1
        End If

    Next

	WordTrim = trimmedString

End Function

%>