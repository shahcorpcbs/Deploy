
<%

	function CBS_TriggerNotification(code, employeeid, customerseq, ticketNumber)
		dim query, rs
		if ticketNumber <> "" then
			query = " exec dbo.TriggerNotification '" & code & "', " & employeeid & ", " & customerseq & ", " & ticketNumber
		else
			query = " exec dbo.TriggerNotification '" & code & "', " & employeeid & ", " & customerseq & ", null"
		end if
		
		qryexecute query
		
	end function
	
	
	
	function CBS_TriggerDailyNotifications()
	
	
	end function
	
	
	
	
	
%>