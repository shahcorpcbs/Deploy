﻿
<%
    Class CardTransactionResults
        Private m_Properties

        Private Sub Class_Initialize()
            Set m_Properties = Server.CreateObject("Scripting.Dictionary")
        End Sub

        Public Function toJson()
            toJson = rsToJsonArray(m_Properties)
        End Function

        Public Property Get Success
            Success = m_Properties("Success")
        End Property

        Public Property Let Success(ByVal value)
            m_Properties("Success") = value
        End Property


        Public Property Get ResponseCode
            ResponseCode = m_Properties("ResponseCode")
        End Property

        Public Property Let ResponseCode(ByVal value)
            m_Properties("ResponseCode") = value
        End Property


        Public Property Get ResponseDescription
            ResponseDescription = m_Properties("ResponseDescription")
        End Property

        Public Property Let ResponseDescription(ByVal value)
            m_Properties("ResponseDescription") = value
        End Property

        Public Property Get OTK
            OTK = m_Properties("OTK")
        End Property

        Public Property Let OTK(ByVal value)
            m_Properties("OTK") = value
        End Property

        Public Property Get HpfUrl
            HpfUrl = m_Properties("HpfUrl")
        End Property

        Public Property Let HpfUrl(ByVal value)
            m_Properties("HpfUrl") = value
        End Property

        Public Property Get Amount
            Amount = m_Properties("Amount")
        End Property

        Public Property Let Amount(ByVal value)
            m_Properties("Amount") = value
        End Property

        Public Property Get ApprovalCode
            ApprovalCode = m_Properties("ApprovalCode")
        End Property

        Public Property Let ApprovalCode(ByVal value)
            m_Properties("ApprovalCode") = value
        End Property

        Public Property Get CardType
            CardType = m_Properties("CardType")
        End Property

        Public Property Let CardType(ByVal value)
            m_Properties("CardType") = value
        End Property

        Public Property Get CardNumber
            CardNumber = m_Properties("CardNumber")
        End Property

        Public Property Let CardNumber(ByVal value)
            m_Properties("CardNumber") = value
        End Property

        Public Property Get CardExpDate
            CardExpDate = m_Properties("CardExpDate")
        End Property

        Public Property Let CardExpDate(ByVal value)
            m_Properties("CardExpDate") = value
        End Property

        Public Property Get TransactionID
            TransactionID = m_Properties("TransactionID")
        End Property

        Public Property Let TransactionID(ByVal value)
            m_Properties("TransactionID") = value
        End Property

        Public Property Get Alias
            Alias = m_Properties("Alias")
        End Property

        Public Property Let Alias(ByVal value)
            m_Properties("Alias") = value
        End Property

        Public Property Get CardPaymentID
            CardPaymentID = m_Properties("CardPaymentID")
        End Property

        Public Property Let CardPaymentID(ByVal value)
            m_Properties("CardPaymentID") = value
        End Property

        Public Property Get FullReceiptData
            FullReceiptData = m_Properties("FullReceiptData")
        End Property

        Public Property Let FullReceiptData(ByVal value)
            m_Properties("FullReceiptData") = value
        End Property

    End Class
%>
