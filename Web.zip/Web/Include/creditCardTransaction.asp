﻿<!-- #include file="../include/json.asp" -->
<!-- #include file="../include/CardTransactionResults.asp" -->
<!-- #include file="../MainApp/XcHpfCardTransaction.asp" -->
<!-- #include file="../include/tsys.asp" -->

<%
    Class CreditCardTransaction
        Private m_Processor

        Private Sub Class_Initialize()            
            If IsObject(Session("miscSetUp")) Then
                Dim objMiscSetup: Set objMiscSetup = Session("miscSetUp")
                m_Processor = objMiscSetup.Item("creditCardProcessorDescription")
            End If
        End Sub

        Public Function getCreditSaleUrl(amount)
            Dim url

            If m_Processor = "OpenEdge" Then
                Dim xchpf
                Dim result

                Set xchpf = New XcHpfCardTransaction
                Set result = xchpf.getCreditSaleUrl(amount)
        
                url = ""
                If result.ResponseCode <> "" Then
                    url = result.HpfUrl
                End If
            End If
    
            getCreditSaleUrl = url
        End Function

        Public Function getCreditReturnUrl(amount)
            Dim url

            If m_Processor = "OpenEdge" Then
                Dim xchpf
                Dim result

                Set xchpf = New XcHpfCardTransaction
                Set result = xchpf.getCreditReturnUrl(amount)

                url = ""
                If result.ResponseCode <> "" Then
                    url = result.HpfUrl
                End If
            End If

            getCreditReturnUrl = url
        End Function

        Public Function ProcessCreateAliasTransaction()
            Dim result: Set result = Nothing

            If m_Processor = "OpenEdge" Then
                Dim xcdtg

                Set xcdtg = New XcHpfCardTransaction
                Set result = xcdtg.getCreateAliasUrl() 

            ElseIf m_Processor = "TSYS" Then
                Dim tsys

                Set tsys = New TSysCardTransaction
                Set result = tsys.processCreateAliasTransaction()
            End If
    
            Set ProcessCreateAliasTransaction = result
        End Function


        Public Function processPickupSaleTransaction(amount)
            Dim result
            Dim cardPaymentID
        
            cardPaymentID = createPendingCardPayment(amount, Session("customerSequenceNumber"), True)

            Set result = processSaleTransaction(amount, cardPaymentID)

            If m_Processor = "TSYS" Then
                result.CardPaymentID = cardPaymentID
                processPickupCreditCardResult result
            End If

            Set processPickupSaleTransaction = result
        End Function

        Public Function processApplyPaymentSaleTransaction(amount)
            Dim result
            Dim cardPaymentID
        
            cardPaymentID = createPendingCardPayment(amount, Session("customerSequenceNumber"), True)

            Set result = processSaleTransaction(amount, cardPaymentID)

            If m_Processor = "TSYS" Then
                result.CardPaymentID = cardPaymentID
                processApplyPaymentCreditCardResult result, Session("customerSequenceNumber")
            End If

            Set processApplyPaymentSaleTransaction = result
        End Function

        Public Function processReturnPaymentTransaction(amount, customerSequenceNumber, ticketNumber, paymentNumber)
            Dim result: Set result = Nothing
            Dim cardPaymentID

            cardPaymentID = createPendingCardPayment((-1)*amount, customerSequenceNumber, True)

            If m_Processor = "OpenEdge" Then
                Dim xchpf

                Session("CardPaymentID") = cardPaymentID

                Set xchpf = New XcHpfCardTransaction
                Set result = xchpf.getCreditReturnUrl(amount)
            ElseIf m_Processor = "TSYS" Then
                Dim tsys

                Set tsys = New TSysCardTransaction
                Set result = tsys.processReturnTransaction(amount, cardPaymentID)
                result.CardPaymentID = cardPaymentID
                
                processReturnPaymentCreditCardResult ticketNumber, paymentNumber, result
            End If

            Set processReturnPaymentTransaction = result
        End Function

        Private Function processSaleTransaction(amount, cardPaymentID)
            Dim result: Set result = Nothing

            If m_Processor = "OpenEdge" Then
                Dim xchpf

                Session("CardPaymentID") = cardPaymentID

                Set xchpf = New XcHpfCardTransaction
                Set result = xchpf.getCreditSaleUrl(amount)
            ElseIf m_Processor = "TSYS" Then
                Dim tsys

                Set tsys = New TSysCardTransaction
                Set result = tsys.processSaleTransaction(amount, cardPaymentID)
                
            End If

            Set processSaleTransaction = result
        End Function

        Private Function createPendingCardPayment(amount, customerSequenceNumber, cardPresent)
            Dim sql
            Dim cardPaymentID

            Dim terminalID
            Dim employeeID

            terminalID = Session("terminalID")
            employeeID = Session("employeeID")

            Dim cardPresentBit: cardPresentBit = 1
            If cardPresent = False Then
                cardPresentBit = 0
            End If

            sql = "SET NOCOUNT ON; " _
                & "INSERT INTO dbo.CardPayment (TerminalID, Clerk, CustomerSequenceNumber, Success, Amount, CardPresent) " _
                & "VALUES (" & terminalID & ", " & employeeID & ", " & customerSequenceNumber & ", 0, " & amount & ", " & cardPresentBit & "); " _
                & "SELECT SCOPE_IDENTITY(); " _
                & "SET NOCOUNT OFF;"

            DBStartTrans()
            cardPaymentID = QryExecuteWithTransAndSelect(sql)
            DBEndTrans()
            
            createPendingCardPayment = cardPaymentID
        End Function

        Public Function getPickupCreditCardResultsResponse
            If m_Processor = "OpenEdge" Then
                Dim result
                Set result = getCreditSaleResultsResponse
                result.CardPaymentID = Session("CardPaymentID")

                processPickupCreditCardResult result
                
                ' We saved the cardPaymentID to Session in order to update the CardPayment record
                ' If we no longer have a pending response code, we need to remove it from session
                ' TODO See if we can get this back in our HPF response somehow so that we don't have to use Session
                If result.ResponseCode <> "102" Then
                    Session.Contents.Remove("CardPaymentID")
                End If

                getPickupCreditCardResultsResponse = result.toJson()
            End If

        End Function

        Public Function processPickupCardOnFileTransaction(amount, alias, expirationDate, zipCode)
            Dim result
            Dim cardPaymentID

            cardPaymentID = createPendingCardPayment(amount, Session("customerSequenceNumber"), False)

            Set result = processCardOnFileTransaction(amount, alias, expirationDate, zipCode)
            result.CardPaymentID = cardPaymentID

            processPickupCreditCardResult result

            processPickupCardOnFileTransaction = result.toJson()

        End Function

        Public Function getApplyPaymentCreditCardResultsResponse
            If m_Processor = "OpenEdge" Then
                Dim result
                Set result = getCreditSaleResultsResponse
                result.CardPaymentID = Session("CardPaymentID")

                processApplyPaymentCreditCardResult result, Session("accountCustomerSequenceNumber")

                If result.ResponseCode <> "102" Then
                    Session.Contents.Remove("CardPaymentID")
                End If

                getApplyPaymentCreditCardResultsResponse = result.toJson()
            End If

        End Function

        Public Function getReturnPaymentCreditCardResultsResponse(ticketNumber, paymentNumber)
            If m_Processor = "OpenEdge" Then
                Dim result
                Set result = getCreditSaleResultsResponse
                result.CardPaymentID = Session("CardPaymentID")

                processReturnPaymentCreditCardResult ticketNumber, paymentNumber, result

                If result.ResponseCode <> "102" Then
                    Session.Contents.Remove("CardPaymentID")
                End If

                getReturnPaymentCreditCardResultsResponse = result.toJson()
            End If
            
        End Function

        Public Function processApplyPaymentCardOnFileTransaction(amount, alias, expirationDate, zipCode)
            Dim result
            Dim cardPaymentID

            cardPaymentID = createPendingCardPayment(amount, Session("customerSequenceNumber"), False)

            Set result = processCardOnFileTransaction(amount, alias, expirationDate, zipCode)
            result.CardPaymentID = cardPaymentID

            processApplyPaymentCreditCardResult result, Session("customerSequenceNumber")

            processApplyPaymentCardOnFileTransaction = result.toJson()
        End Function

        Private Function getCreditSaleResultsResponse
            If m_Processor = "OpenEdge" Then
                Dim xchpf: Set xchpf = New XcHpfCardTransaction
                Set getCreditSaleResultsResponse = xchpf.getCreditSaleResultsResponse
            End If
            
        End Function

        Private Function processCardOnFileTransaction(amount, alias, expirationDate, zipCode)
            Dim result: Set result = Nothing

            If m_Processor = "OpenEdge" Then
                Dim xchpf: Set xchpf = New XcHpfCardTransaction
                Set result = xchpf.processCardOnFileSaleTransaction(amount, alias, zipCode)
            ElseIf m_Processor = "TSYS" Then
                Dim tsys: Set tsys = New TsysCardTransaction
                Set result = tsys.processCardOnFileSaleTransaction(amount, alias, expirationDate)
            End If

            Set processCardOnFileTransaction = result
        End Function

        Private Sub processPickupCreditCardResult(result)
            ' Apply the result to the pickupObj. Generally we do this after the calling page reloads, but we want to print a credit card receipt, and
            ' the database needs to be updated prior to receipt printing (something the pickup object does)
            If result.Success = True And result.Amount > 0 Then        
                Dim pickupObj: Set pickupObj = Session("pickupObj")
            
                If Not pickupObj Is Nothing Then
                    Dim amountPaid
                    Dim approvalCode
                    Dim cardType
                    Dim cardBrand
                    Dim cardNumber
                    Dim cardExp
                    Dim transactionID
                    Dim employeeID
                    Dim terminalID
                    Dim cardPaymentID
                    Dim receiptData

    	            amountPaid = result.Amount
	                approvalCode = result.ApprovalCode
		            cardType = result.CardType
		            cardNumber = result.CardNumber
		            cardExp = result.CardExpDate
		            transactionID = result.TransactionID
                    cardPaymentID = result.CardPaymentID
                    receiptData = result.FullReceiptData

                    employeeID = Session("employeeID")
                    terminalID = Session("terminalID")

                    UpdateCardPayment amountPaid, transactionID, cardPaymentID, receiptData


                    pickupObj.addCreditCardPayment amountPaid, "Credit Card", cardNumber, _
                                                cardExp, cardType, approvalCode, transactionID, _
                                                cardPaymentID, employeeID, terminalID, _
                                                pickupObj.constructTicketNosString(), -1
                End If

            End If

        End Sub


        Private Sub processApplyPaymentCreditCardResult(result, customerSequenceNumber)
            If result.Success = True And result.Amount > 0 Then
                Dim amountPaid
                Dim approvalCode
                Dim cardType
                Dim cardBrand
                Dim cardNumber
                Dim cardExp
                Dim transactionID
                Dim employeeID
                Dim terminalID
                Dim storeID
                Dim cardPaymentID
                Dim receiptData

        	    amountPaid = result.Amount
	            approvalCode = result.ApprovalCode
		        cardType = result.CardType
		        cardNumber = result.CardNumber
		        cardExp = result.CardExpDate
		        transactionID = result.TransactionID
                cardPaymentID = result.CardPaymentID
                receiptData = result.FullReceiptData

                storeID = Session("storeID")
                employeeID = Session("employeeID")
                terminalID = Session("terminalID")

                If IsEmpty(customerSequenceNumber) Then
                    customerSequenceNumber = Session("accountCustomerSequenceNumber")
                End If

                UpdateCardPayment amountPaid, transactionID, cardPaymentID, receiptData

                Dim sqltxt
    		    sqltxt = "EXECUTE dbo.InsertCreditCardPayment " & storeID _
				    & ", " & terminalID _
				    & ", " & employeeID _
				    & ", " & customerSequenceNumber _
				    & ", " & DbCreateQryString("Credit Card") _
				    & ", " & amountPaid _
				    & ", " & DbCreateQryString(cardNumber) _
				    & ", " & DbCreateQryString(approvalCode) _
				    & ", " & DbCreateQryString(transactionID) _
                    & ", " & cardPaymentID _
				    & ", " & DbCreateQryString(cardBrand) _
				    & ", " & DbCreateQryString(cardExp)

                DbStartTrans()
		        QryExecuteWithTrans(sqltxt)
		        DbEndTrans()

            End If

        End Sub 

        Public Sub processReturnPaymentCreditCardResult(ticketNumber, paymentNumber, result)
            If result.Success = True Then
                Dim amount
                Dim employeeID
                Dim terminalID
                Dim transactionID
                Dim cardNumber
                Dim cardExpDate
                Dim cardType
                Dim cardPaymentID
                Dim receiptData

                amount = result.Amount
                transactionID = result.TransactionID
                cardNumber = result.CardNumber
                cardExpDate = result.CardExpDate
                cardType = result.CardType
                cardPaymentID = result.CardPaymentID
                receiptData = result.FullReceiptData

                employeeID = Session("employeeID")
                terminalID = Session("terminalID")

                ' TODO We should probably modify the result.Amount value to be negative rather than changing this here, but I wrote the ReturnPayment proc to expect
                ' a positive @ReturnAmount parameter (to reflect how similar logic elsewhere in the app, and changing all of those references is a little too risky at this moment.
                ' Change this number to a negative number when the initial results response is parsed in the future.
                UpdateCardPayment (-1)*amount, transactionID, cardPaymentID, receiptData

                Dim sqlTxt
                sqlTxt = "EXECUTE dbo.ReturnPayment " _
                       & "@PaymentType = 'Credit Card', " _
                       & "@ReturnAmount = " & amount & ", "

                If ticketNumber <> "" Then
                    sqlTxt = sqlTxt & "@TicketNumber = " & ticketNumber & ", "
                ElseIf paymentNumber <> "" Then
                    sqlTxt = sqlTxt & "@PaymentNumber = " & paymentNumber & ", "
                End If

                sqlTxt = sqlTxt & "@EmployeeID = " & employeeID & ", " _
                                & "@TerminalID = " & terminalID & ", " _
                                & "@ReturnTransactionID = '" & transactionID & "', " _
                                & "@CardPaymentID = '" & cardPaymentID & "', " _
                                & "@CardNumber = '" & cardNumber & "', " _
                                & "@CreditCardExpiryDate = '" & cardExpDate & "', " _
                                & "@CreditCardType = '" & cardType & "'"

                DbStartTrans()
		        QryExecuteWithTrans(sqltxt)
		        DbEndTrans()
            
            End If
        End Sub
            
        Public Function processCreditBatchTransaction(accountNumber, amount, customerSequenceNumber, expirationDate, address, zip)
            Dim result
            Dim cardPaymentID
        
            cardPaymentID = createPendingCardPayment(amount, customerSequenceNumber, False)

            If m_Processor = "OpenEdge" Then
                Dim xchpf
                Set xchpf = New XcHpfCardTransaction
                Set result = xchpf.processCreditBatchTransaction(accountNumber, amount, address, zip)
            ElseIf m_Processor = "TSYS" Then
                Dim tsys: Set tsys = New TsysCardTransaction
                Set result = tsys.processCreditBatchTransaction(accountNumber, amount, expirationDate)
            End If
            result.CardPaymentID = cardPaymentID

            processApplyPaymentCreditCardResult result, customerSequenceNumber

            Set processCreditBatchTransaction = result
        End Function

        Public Function getCreateAliasResultsResponse()
            Dim result

            If m_Processor = "OpenEdge" Then
                Dim xchpf
            
                Set xchpf = New XcHpfCardTransaction
                Set result = xchpf.getCreateAliasResultsResponse()          
        
            End If

            Set getCreateAliasResultsResponse = result
        End Function



        Public Function updateAliasExpDate(expirationDate)
            Dim alias
            Dim result

            alias = Session("Alias")

            If m_Processor = "OpenEdge" Then
                Dim xchpf: Set xchpf = New XcHpfCardTransaction
                Set result = xchpf.updateAliasExpirationDate(alias, expirationDate)
            ElseIf m_Processor = "TSYS" Then
                Dim tsys: Set tsys = New TsysCardTransaction
                Set result = tsys.updateAliasExpirationDate()
            End If

            Set Session("Alias") = Nothing

            If result.Success = True Then
                Dim sql
                sql = "UPDATE Customer SET creditCardExpDate = '" & expirationDate & "' WHERE creditCardAlias = '" & alias & "'"
                QryExecute sql
            End If
    
            updateAliasExpDate = result.ResponseDescription
        End Function

        Public Function voidPayment(transactionID, salePaymentNumber, customerSequenceNumber, amount, cardPresent)
            Dim result

            Dim cardPaymentID: cardPaymentID = createPendingCardPayment(-1*amount, customerSequenceNumber, cardPresent)   

            Dim employeeID
            Dim terminalID

            employeeID = Session("employeeID")
            terminalID = Session("terminalID")

            If m_Processor = "OpenEdge" Then
                Dim xchpf: Set xchpf = New XcHpfCardTransaction
                Set result = xchpf.voidTransaction(transactionID)
            ElseIf m_Processor = "TSYS" Then
                Dim tsys: Set tsys = New TSysCardTransaction
                Set result = tsys.ProcessVoidTransaction(transactionID, cardPaymentID, cardPresent)
            End If

            result.CardPaymentID = cardPaymentID

            If result.Success = True Then
                
                UpdateCardPayment result.Amount, result.TransactionID, result.CardPaymentID, result.FullReceiptData

                Dim sql     
                sql = "EXECUTE dbo.VoidPayment @PaymentType = 'Credit Card', "
                sql = sql & "@SalePaymentNumber = " & salePaymentNumber & ", "
                sql = sql & "@EmployeeID = " & employeeID & ", "
                sql = sql & "@TerminalID = " & terminalID & ", "
                sql = sql & "@VoidTransactionID = '" & result.TransactionID & "', "
                sql = sql & "@CardPaymentID = " & cardPaymentID
                QryExecute sql
            End If

            voidPayment = result.toJson()
        
        End Function

        Private Function StrToBin(str)
            Dim result
            Dim tempChar
            For i = 1 to Len(str)
                tempChar = Mid(str, i, 1)
                result = result & chrB(AscB(tempChar))
            Next

            StrToBin = result
        End Function

        Private Sub UpdateCardPayment(amountPaid, transactionID, cardPaymentID, receiptData)
            dim oConn
		    dim oRs
		    dim dsnString
		    dim sSQL
		    dim oCmd

		    Set oConn = Server.CreateObject("ADODB.Connection")
		    Set oRs = Server.CreateObject("ADODB.Recordset")
		    dsnString  = Session("shahcorpDSN")
	
		    Set oCmd = Server.CreateObject("ADODB.Command")

		    oConn.Open dsnString

		    sSQL = "SELECT * FROM CardPayment WHERE CardPaymentID = " & cardPaymentID

		    oRs.Open sSQL, oConn, 3, 3
	
		    if oRs.recordCount > 0 then
		
			    oRs.Fields("AmountApplied").Value = amountPaid
                oRs.Fields("TransactionID").Value = transactionId
                oRs.Fields("Success").Value = 1
                If Not IsEmpty(receiptData) Then
                    oRs.Fields("FullReceiptData").AppendChunk = StrToBin(receiptData)
                End If
            
		        oRs.Update
	        end if
        End Sub

    End Class

    
%>