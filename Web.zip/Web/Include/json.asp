<!--#include file="../external/JSON.asp"-->

<%


	function rsToJSON(rs, limit, start)
		dim json_writer
		dim output
		

		set json_writer = new JSON
		

		if rs.recordcount = 0 then
			output = "{"
			output = output & json_writer.toJSON("recordcount", 0, true, null)
			output = output & ", "
			output = output & "rows:[]"
			output = output & "}"

		else
			rs.movefirst
			
			if not isnull(start) then
				rs.move start
			end if
	

			output = "{"
			output = output & json_writer.toJSON("recordcount", rs.recordcount, true, null)
			output = output & ", "
			output = output & json_writer.toJSON("rows", rs, true, limit)
			output = output & "}"
		end if
		

		
		rsToJSON = output
	end function
	
	function rsToJSONArray(rs)
		dim json_writer
		dim output

		set json_writer = new JSON
		
		output = output & json_writer.toJSON(empty, rs, true, null)
		
		rsToJSONArray = output
	end function
%>