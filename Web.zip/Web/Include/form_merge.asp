<%


	
	
	
	
	
	
	

	class Param
		dim paramName
		dim paramType
		dim paramDefault
		dim startPosition
		dim endPosition
		
		public function reflect()
			dim result
			set result = CreateObject("Scripting.Dictionary")
			
			result.add "name", paramName
			result.add "type", paramType
			result.add "default", paramDefault
			
			set reflect = result
		end function
	end class
	
		
	function transformQuery(query, params, values)
		dim item
		dim result
		dim offset
		dim rside
		dim lside
		dim value
		
		on error resume next
		
		result = query
		offset = 0
		
		for each item in params.items
			lside = left(result, item.startPosition + offset - 1)
			rside = mid(result, item.endPosition + offset)

			value = ""
			value = values(item.paramName)

			offset = offset - (item.endPosition - item.startPosition) + len(value)

			result = lside & value & rside
		next
		
		transformQuery = result
		
	end function
	
	sub addParam(params, paramName, paramType, paramDefault, startPosition, endPosition)
		dim newParam
		dim idx
		dim originalName
		
		originalName = paramName
		
		idx = 1
		
		while params.exists(paramName)
			idx = idx + 1
			paramName = originalName & "_" & idx
		wend
		
		set newParam = new Param

		newParam.paramName = paramName
		newParam.paramType = paramType
		newParam.paramDefault = paramDefault
		newParam.startPosition = startPosition
		newParam.endPosition = endPosition
		
		params.add paramName, newParam

	end sub
	
	function legalIDChar(ch)
		dim legal
		dim idx
		
		legal = "abcdefghijklmnopqrstuvwxyz1234567890_"
		idx = 1
		
		while idx <= len(legal)
			if mid(legal, idx, 1) = lcase(ch) then
				legalIDChar = true
				exit function
			end if
			idx = idx + 1
		wend
		
		legalIDChar = false
	end function
	
	function getFormParams(query)
		dim idx
		dim idxStart
		dim paramName
		dim varPrefix
		dim result

		varPrefix = "@@@"

		set result = CreateObject("Scripting.Dictionary")

		idx = instr(1, query, varPrefix, 1)

		while idx > 0
			paramName = ""

			idxStart = idx
			idx = idx + len(varPrefix)
			
			while idx <= len(query) and legalIDChar(mid(query, idx, 1))
				paramName = paramName & mid(query, idx, 1)
				idx = idx + 1
			wend
			
			addParam result, paramName, "", "", idxStart, idx

			idx = instr(idx, query, varPrefix, 1)
		wend

		set getFormParams = result
	end function
	
	
%>