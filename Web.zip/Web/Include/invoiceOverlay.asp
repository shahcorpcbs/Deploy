<%
    dim canAddBrand, autoChecked, defCoInput, defUpInput, defPaInput, defBrInput, rs
    set rs = getdisconnectedrecordset("select useAdvDetailScreen, addBrandsOnDI, multipleDescAutoChecked, " _
        & "defaultColorInputField, defaultPatternInputField, defaultUpchargeInputField, defaultBrandInputField from MiscSetup")
    if rs("useAdvDetailScreen") then
        canAddBrand = rs("addBrandsOnDI")
    end if
    autoChecked = rs("multipleDescAutoChecked")
    defCoInput = rs("defaultColorInputField")
    defUpInput = rs("defaultPatternInputField")
    defPaInput = rs("defaultUpchargeInputField")
    defBrInput = rs("defaultBrandInputField")

%>

<link rel="stylesheet" href="/style/overlay.css" type="text/css">
<script type="text/javascript">
    var isForced = false;

    function clearDescOL() {
        document.getElementById('descBox').style.display = 'none';
    }

    function popDesc(type, forced, itemName) {
        var width = screen.width;
        var descBox = document.getElementById('descBox');
        <% if not canAddBrand then %>
        if (width <= 1100)
            descBox.style.width = "650px";
        else if (width <= 1200)
            descBox.style.width = "750px";
        <% else %>
        if (width <= 1100)
            descBox.style.width = "750px";
        <% end if %>

        itemName = itemName.replace("&#39;", "'");


        document.getElementById("qtnTxt").value = document.getElementById("txtAmountEntered").value;
        descBox.style.display = 'block';
    	var table = document.getElementById("descTable");
    	table.innerHTML = "";
    	document.getElementById("filterTxt").value = "";
    	<% if canAddBrand then %>
    	document.getElementById('addBrandBtn').style.visibility = 'hidden'
    	<% end if %>

        isForced = forced;
        if (type === "UP") {
            document.getElementById("descHeader").innerText = (itemName ? itemName + " " : "") + "Upcharges";
            document.getElementById("doAnotherTxt").innerText = "Multiple Upcharges";
            displayUpcharge();
            if (<%= defUpInput %> == 1)
                document.getElementById("filterTxt").focus();
            else
                document.getElementById("qtnTxt").focus();

        }
        else if (type === "CO") {
            document.getElementById("descHeader").innerText = (itemName ? itemName + " " : "") + "Colors";
            document.getElementById("doAnotherTxt").innerText = "Multiple Colors";
            displayColors();
            if (<%= defCoInput %> == 1)
                document.getElementById("filterTxt").focus();
            else
                document.getElementById("qtnTxt").focus();
        }
        else if (type === "PA") {
            document.getElementById("descHeader").innerText = (itemName ? itemName + " " : "") + "Patterns";
            document.getElementById("doAnotherTxt").innerText = "Multiple Patterns";
            displayPatterns();
            if (<%= defPaInput %> == 1)
                document.getElementById("filterTxt").focus();
            else
                document.getElementById("qtnTxt").focus();
        }
        else if (type === "BR") {
            document.getElementById("descHeader").innerText = (itemName ? itemName + " " : "") + "Brands";
            document.getElementById("doAnotherTxt").innerText = "Multiple Brands";
            <% if canAddBrand then %>
    	    document.getElementById('addBrandBtn').style.visibility = 'visible'
    	    <% end if %>
            displayBrands();
            if (<%= defBrInput %> == 1)
                document.getElementById("filterTxt").focus();
            else
                document.getElementById("qtnTxt").focus();
        }

        setInterval(updateOverLay, 100);
    }

    function filterMsg(event) {
        var filterValue = document.getElementById("filterTxt").value;
    	var table = document.getElementById("descTable");
    	table.innerHTML = "";
    	if (document.getElementById("descHeader").innerText.includes("Upcharges"))
            displayUpcharge(filterValue);
    	else if (document.getElementById("descHeader").innerText.includes("Colors"))
            displayColors(filterValue);
    	else if (document.getElementById("descHeader").innerText.includes("Patterns"))
            displayPatterns(filterValue);
    	else if (document.getElementById("descHeader").innerText.includes("Brands")) {
            displayBrands(filterValue, (event.key === "Enter"));
        }
    }

    function updateQtn() {
        document.getElementById("txtAmountEntered").value = document.getElementById("qtnTxt").value;
    }

    function closeDesc() {
        document.getElementById("txtAmountEntered").value = ""
        document.getElementById('descBox').style.display = 'none';
    }


</script>

	<div id="descBox" class="overlay" style="display: none; width: <% if canAddBrand or Request.Form("screenWidth") > 1200 then %> 800px; <% else %> 600px; <% end if %> height: 600px; background-color: white; left: 22%; top:10%; text-align: center">
        <h1 id="descHeader" class="overlayHeader" style="color:black; margin-bottom: -10px"></h1>
        <INPUT class=touchNoBorder id="closeOverLay" type=button onclick="closeDesc()"
            style="position: relative; float:right; top: -85px; max-height:30px; max-width: 25px; background-size:contain; background-image:url(../images/xIcon.gif);" />
        <input id="filterTxt" placeHolder="Search" onkeyup="filterMsg(event);" autocomplete="off" style="width:170px;font-size:20; display: block; margin: 0 auto; " />
       <% if canAddBrand then %>
        <BUTTON class=small id="addBrandBtn" style="max-height:29px; max-width: 90px; display: block; margin: 0 auto;left: 130px; margin-bottom: -30px; position: relative; top: -30px"
            onclick="createBrand()">Add</button>
        <% end if %>
        <input id="qtnTxt" type="number" onkeydown="return event.keyCode !== 69 && event.keyCode !== 190" maxlength="4" onkeyup="updateQtn();" autocomplete="off" style="float: right; width:120px;font-size:20; display: block; margin: 0 auto; margin-right: -30px;position: relative; top: -30px"/>
        <label style="color: black; float: right; width:120px;font-size:20; display: block; margin: 0 auto;position: relative; top: -30px" for="qtnTxt">Quantity</label>
        <br /><br /><br />
        <label style="color: black; float:right; background-size:contain; font-size:16px; position: relative; top: -30px">
            <input type="checkbox" <% if autoChecked then %> checked <% end if %> style="height:30px; width:20px; vertical-align:middle" id="doAnotherDesc"/><span id="doAnotherTxt"></span>
        </label>
        <table id="descTable" style="margin: 0 auto; position: relative;">

        </table>
    </div>