-- // fix first dropoff pickup query
-- Migration SQL that makes the change goes here.
update QueryAlert set query = 'select distinct c.customerSequenceNumber from customer c inner join ticket t on c.customersequencenumber = t.customersequencenumber where c.customerSequenceNumber not in (select customerSequenceNumber from Ticket where dateAdd("d", -1, getDate()) > statusChangeDate and ticketStatus = ''FI'') and c.routeNumber = 0 and ticketStatus = ''FI'''
where id = -7


update QueryAlert set query = 'select distinct c.customerSequenceNumber from customer c inner join ticket t on c.customersequencenumber = t.customersequencenumber where c.customerSequenceNumber not in (select customerSequenceNumber from Ticket where dateAdd("hour", -1, getDate()) > statusChangeDate) and c.routeNumber = 0'
where id = -6

GO
-- //@UNDO
-- SQL to undo the change goes here.



