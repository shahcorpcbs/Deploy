-- // add round to nickel flag
-- Migration SQL that makes the change goes here.
alter table MiscSetup add roundToNickel bit not null default 0
GO

SET IDENTITY_INSERT [Discount] ON
insert into Discount(discountId, priceListId, discountType, discountSubtype, discountName, effectiveDate) values
        (-1, 1, 'CU', 'Amount', 'Penny Saver', current_timestamp)
SET IDENTITY_INSERT [Discount] OFF
GO
-- //@UNDO
-- SQL to undo the change goes here.


