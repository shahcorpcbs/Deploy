-- // add racked without customer report
-- Migration SQL that makes the change goes here.
insert into userquery(name,query,description)
values('Plant Unknown Racked Items','
SELECT InvoiceNumber, ScannedDate, Location from PlantManifestItem where CustomerName is null order by scannedDate desc',
       'Shows racked invoices at a plant store not connected to a customer')
GO


-- //@UNDO
-- SQL to undo the change goes here.
delete userQuery where name = 'Plant Unknown Racked Items'
GO

