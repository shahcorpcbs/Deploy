-- // delete token table
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[Unusedtokens](
    Id bigint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    Token varchar(64),
    ApiKey varchar(50)
)
GO

-- //@UNDO
-- SQL to undo the change goes here.


