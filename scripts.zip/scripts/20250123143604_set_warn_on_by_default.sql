-- // set warn on by default
-- Migration SQL that makes the change goes here.
update MiscSetup set warnRunNow = 1
GO


-- //@UNDO
-- SQL to undo the change goes here.


