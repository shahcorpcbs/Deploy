-- // update rack history report
-- Migration SQL that makes the change goes here.
USE [shahcorp]
GO
/****** Object:  StoredProcedure [dbo].[Rpt_RackHistory]    Script Date: 6/13/2024 11:23:48 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER  PROCEDURE [dbo].[Rpt_RackHistory]
(
    @storeID            int = NULL,
    @rangeStartDate datetime,
    @rangeEndDate   datetime,
    @rangeStartRackNumber  varchar(50),
    @rangeEndRackNumber    varchar(50)
)
AS
BEGIN

    /*   **********************************************************************
         Name   : Rpt_RackHistory

         Author : Vinny Ramachandran
         Created: 05-Jun-2002

         Purpose:
            Procedure to display Rack history.

            Note: Both start and end location input parameters are made mandatory.
            If requesting data for a single location, pass both start and end
            locations the same.

        Logic
            1. First get Probable Racks (alias PR) based on all input parameters
               except the End Location.
            2. From the Probable Racks, filter based on End Location. In this query
               get the Customer and Employee Information.


         Tester Code for Query Analyzer.

            EXECUTE dbo.Rpt_RackHistory
                @storeID            = NULL,
                @rangeStartDate = '07/07/2001',
                @rangeEndDate   = '02/02/2020',
                @rangeStartRackNumber  = '0',
                @rangeEndRackNumber    = 'z'

         Modification History
         =======================================================================
         Date           Changed By    Change Log
         -----------------------------------------------------------------------
         05-Jun-2002    Vinny. R      Original Version
         ********************************************************************  */

    SELECT
            PR.RackLocationStart +
            CASE
                WHEN PR.RackLocationEnd IS NULL OR RTrim(PR.RackLocationEnd) = '' THEN ''
                ELSE ' - ' + RTrim(PR.RackLocationEnd)
                END as 'rackLocation',
            PR.invoiceNumber,
            TC.customerName,
            TC.firstName,
            TC.lastName,
            dbo.formatPhone( TC.MainAreaCode, TC.MainPhone) as 'customerPhone',
            dbo.pivotTicketLineItem(PR.ticketNumber, 0) as 'departmentName',
            PR.rackedDate,
            PR.dateOut,
            E.employeeName as 'pickUpEmployee',
            dbo.getRackNumber(pr.RackLocationStart),
            PR.rackedEmployee,
            PR.dueDate
    FROM Customer TC,
         (SELECT RA.RackLocationStart,
                 RA.RackLocationEnd,
                 T.ticketNumber,
                 T.invoiceNumber,
                 T.customerSequenceNumber,
                 RA.rackedDate,
                 T.dateOut,
                 RA.pickedUpEmployeeID,
                 isnull(EMP.employeeName,'None') as rackedEmployee,
                 T.dueDate
          FROM RackAssignment RA inner join  Ticket T on RA.ticketNumber = T.ticketNumber
                                 left outer join Employee EMP on ra.rackedEmployeeID = emp.employeeID
          WHERE (RA.rackLocationStart BETWEEN @rangeStartRackNumber AND @rangeEndRackNumber)
            AND (T.storeID = @storeID OR @storeID IS NULL)
            AND (Convert(varchar, RA.rackedDate, 112) BETWEEN @rangeStartDate AND @rangeEndDate)
         ) as PR
             LEFT OUTER JOIN Employee E ON PR.pickedUpEmployeeID = E.employeeID
    WHERE (PR.customerSequenceNumber = TC.customerSequenceNumber)
      AND (PR.rackLocationEnd  >= @rangeStartRackNumber OR PR.rackLocationEnd IS NULL OR RTrim(PR.rackLocationEnd) = '')
    ORDER BY CASE dbo.isint(PR.RackLocationStart) WHEN 0 then -1 ELSE convert(int, PR.RackLocationStart) END


END  -- End of Procedure


-- //@UNDO
-- SQL to undo the change goes here.


