-- // add was held flag
-- Migration SQL that makes the change goes here.
alter table Ticket add wasHeld bit not null DEFAULT 0
GO


-- //@UNDO
-- SQL to undo the change goes here.


