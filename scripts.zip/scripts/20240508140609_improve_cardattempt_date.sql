-- // improve cardattempt date
-- Migration SQL that makes the change goes here.
DECLARE @ObjectName NVARCHAR(100)
SELECT @ObjectName = OBJECT_NAME([default_object_id]) FROM SYS.COLUMNS
WHERE [object_id] = OBJECT_ID('CardAttempt') AND [name] = 'DateRequested';
EXEC('ALTER TABLE CardAttempt DROP CONSTRAINT ' + @ObjectName)
GO

ALTER TABLE CardAttempt ALTER COLUMN DateRequested datetime not null
GO
ALTER TABLE CardAttempt add CONSTRAINT df_dr default getDate() for dateRequested
GO
-- //@UNDO
-- SQL to undo the change goes here.


