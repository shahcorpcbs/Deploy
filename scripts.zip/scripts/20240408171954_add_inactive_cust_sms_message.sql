-- // add inactive cust sms message
-- Migration SQL that makes the change goes here.
IF NOT EXISTS(
        SELECT * FROM SmsMessage WHERE Description = 'Inactive Customers Message')
    BEGIN

        INSERT INTO [dbo].[SmsMessage] (Message, Description, Subject)
        VALUES ('{storename}: This is {storename}. Haven''t seen you for a while',
                'Inactive Customers Message', '{storename}')



        insert into [dbo].[QueryAlert](Name, Query, SmsMessageId, TriggerType, Frequency, MessageTypeId, Hour, DayOfWeek, Day, groupType)
            (select 'Inactive Customers',
                    'select c.customerSequenceNumber from customer c inner join customerfields cf on c.customersequencenumber = ' +
                    'cf.customersequencenumber where twilioBlackList = 0 and cellPhone is not null and cellPhone != '''' ' +
                    'and isActive = 1 and datediff(day, cf.Last_Visit, getdate()) >= {days}',
                    id, 1, 1, 1, 0, 0, 0, 0 from SmsMessage where Description = 'Inactive Customers Message');


        declare @qaId as int;
        select @qaId = id from QueryAlert where Name = 'Inactive Customers';
        insert into QueryAlertVariable (QueryId, VariableDesc, VariableField, VariableValue) values (@qaId, 'Days Since visit', 'days', 60);

    END
GO
-- //@UNDO
-- SQL to undo the change goes here.
declare @qaId as int;
select @qaId = id from QueryAlert where Name = 'Inactive Customers';

delete QueryAlertVariable where QueryId = @qaId
delete QueryAlert where id = @qaId
delete SmsMessage where Description = 'Inactive Customers Message'
GO

