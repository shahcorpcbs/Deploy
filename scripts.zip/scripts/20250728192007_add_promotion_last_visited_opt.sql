-- // add promotion last visited opt
-- Migration SQL that makes the change goes here.
alter table Discount add visitWithinXDays smallint not null default 0
GO


-- //@UNDO
-- SQL to undo the change goes here.


