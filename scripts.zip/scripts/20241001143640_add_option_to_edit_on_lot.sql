-- // add option to edit on lot
-- Migration SQL that makes the change goes here.
alter table MiscSetup add canEditOnLot bit not null DEFAULT 0
GO


-- //@UNDO
-- SQL to undo the change goes here.


