-- // add discount item min amount
-- Migration SQL that makes the change goes here.
ALTER TABLE Discount ADD itemAboveZero bit NOT NULL DEFAULT 0;
GO


-- //@UNDO
-- SQL to undo the change goes here.


