-- // add customer inv count table
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[CustInvCnt](
    Id bigint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    custSeqNum int not null,
    lastCnt int not null,
    currCnt int not null
)
GO

insert into CustInvCnt (custSeqNum, lastCnt, currCnt) (select c.customersequencenumber, count(t.ticketnumber), count(t.ticketnumber) from customer c inner join ticket t on c.customersequencenumber = t.customersequencenumber where c.routeNumber = 0 and ticketStatus = 'FI' group by c.customerSequenceNumber)
GO

-- //@UNDO
-- SQL to undo the change goes here.
drop table CustInvCnt
GO

