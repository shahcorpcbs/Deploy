-- // add autovoid flag
-- Migration SQL that makes the change goes here.
alter table MiscSetup add autovoidUnfinished bit not null DEFAULT 1
GO

