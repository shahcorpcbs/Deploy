-- // add autovoid flag
-- Migration SQL that makes the change goes here.
alter table MiscSetup add autovoidUnfinished bit not null DEFAULT 1
GO


-- //@UNDO
-- SQL to undo the change goes here.
alter table MiscSetup drop column autovoidUnfinished;
GO