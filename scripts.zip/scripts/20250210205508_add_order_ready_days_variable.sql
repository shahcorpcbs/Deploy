-- // add order ready days variable
-- Migration SQL that makes the change goes here.
ALTER TABLE QueryAlertVariable ALTER COLUMN VariableDesc VARCHAR (40)
GO

insert into QueryAlertVariable (QueryId, VariableDesc, VariableField, VariableValue) values
    (-2, 'Don''t send if more due within x days', 'days', -2);
GO

-- //@UNDO
-- SQL to undo the change goes here.


