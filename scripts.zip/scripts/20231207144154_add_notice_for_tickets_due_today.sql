-- // add notice for tickets due today
-- Migration SQL that makes the change goes here.
if not exists (select * from QueryAlert where Name = 'Notice for Tickets Due Today')
    BEGIN

        INSERT INTO [dbo].[SmsMessage] (Message, Description, Subject)
        VALUES ('This is a notice about your items that were scheduled to be done today from {storename}. Unfortunately they will not be finished today.',
                'Notice for Tickets Due Today', '{storename}: Notice for Items Due Today');


        insert into [dbo].[QueryAlert](Name, Query, SmsMessageId, TriggerType, Frequency, MessageTypeId, Hour, DayOfWeek, Day, groupType)
            (select 'Notice for Tickets Due Today',
                    'select customerSequenceNumber from customer where twilioBlackList = 0 and cellPhone is not null and cellPhone != '''' and routeNumber = 0
        and customerSequenceNumber in (select customerSequenceNumber from ticket where CONVERT(VARCHAR, duedate, 112) = CONVERT(VARCHAR, GETDATE(), 112))',
                    id, 1, 1, 2, 0, 1, 1, 2 from SmsMessage where Description = 'Notice for Tickets Due Today');

        declare @qaId as int;
        select @qaId = id from QueryAlert where Name = 'Notice for Tickets Due Today';

        insert into CustomerMessageSetup (CustomerId, QueryId, Sms, Email)
            (select distinct customerId, @qaId, 1, 0 from CustomerMessageSetup)
    END
GO

-- //@UNDO
-- SQL to undo the change goes here.





-- //@UNDO
-- SQL to undo the change goes here.


