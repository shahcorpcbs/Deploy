-- // twilio number change
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[CustomersUnswitched](
     Id bigint NOT NULL IDENTITY(1,1) PRIMARY KEY,
     CustSeqNumber integer not null
)
GO


ALTER TABLE MiscSetup ADD newTwilioFromNumber VARCHAR(12)
GO


INSERT INTO [dbo].[SmsMessage] (Message, Description, Subject)
VALUES ('{storename}: We have updated our store phone number. Reply QUIT to opt out. Reply JOIN to receive special offers.',
        'Update Phone Alert', '')
GO

SET IDENTITY_INSERT [QueryAlert] ON
insert into [dbo].[QueryAlert](Id, Name, Query, SmsMessageId, TriggerType, Frequency, MessageTypeId, Hour, DayOfWeek, Day, GroupType)
    (select -18, 'New Store Phone Number', '', id, 3, 2, 3, 0, 0, 1, 1 from SmsMessage where Description = 'Update Phone Alert')
GO
SET IDENTITY_INSERT [QueryAlert] OFF
GO

-- //@UNDO
-- SQL to undo the change goes here.
drop table CustomersUnswitched
GO

