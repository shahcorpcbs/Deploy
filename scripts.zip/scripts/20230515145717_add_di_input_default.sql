-- // add di input default
-- Migration SQL that makes the change goes here.
alter table MiscSetup add defaultTextField smallint not null DEFAULT 0
GO


-- //@UNDO
-- SQL to undo the change goes here.


