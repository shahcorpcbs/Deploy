-- // add license fields
-- Migration SQL that makes the change goes here.
alter table License add fullTermCnt smallint
GO
alter table License add boTermCnt smallint
GO
alter table License add lastCheck date
GO

-- //@UNDO
-- SQL to undo the change goes here.


