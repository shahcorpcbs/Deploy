-- // add back office license
-- Migration SQL that makes the change goes here.
alter table ClientTerminal add licenseType smallint not null DEFAULT 1
GO


-- //@UNDO
-- SQL to undo the change goes here.
alter table ClientTerminal drop column licenseType;
GO

