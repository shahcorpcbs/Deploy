-- // add tip table
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[EmployeeTip](
                                    Id bigint NOT NULL IDENTITY(1,1) PRIMARY KEY,
                                    TipAmt smallmoney not null,
                                    CardPaymentId bigint not null,
                                    CardAttemptId bigint,
                                    TicketNumber int,
                                    LineItemNumber int,
                                    Added bit not null default 0
)
GO

insert into priceListItem (departmentId, priceListId, itemName, price, useGlobalTax, daystoProcess, useGlobalDays, discountable, vipdiscountable, vipQualified, couponable, printnotes)
    (select distinct  departmentId, priceListId, 'Tip', 0, 0, 0, 0, 0, 0, 0, 0, 0 from PriceListItem)
GO


-- //@UNDO
-- SQL to undo the change goes here.
drop table EmployeeTip
GO
delete priceListItem where itemName = 'Tip'
GO

