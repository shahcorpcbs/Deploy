-- // add term type opt
-- Migration SQL that makes the change goes here.
alter table Terminal add licenseTypes smallint not null DEFAULT 0
GO


-- //@UNDO
-- SQL to undo the change goes here.


