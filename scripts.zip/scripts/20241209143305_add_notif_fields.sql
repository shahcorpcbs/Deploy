-- // add notif fields
-- Migration SQL that makes the change goes here.
alter table DataUpdateLocalNotification add UpdateMiscChargeCnt [int] NOT NULL default 0
GO

alter table DataUpdateLocalNotification add MiscChargeSeed datetime
GO



-- //@UNDO
-- SQL to undo the change goes here.


