-- // fix overtime procedure
-- Migration SQL that makes the change goes here.
USE [shahcorp]
GO

/****** Object:  UserDefinedFunction [dbo].[getEmployeeWage]    Script Date: 2/14/2024 10:29:59 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER  FUNCTION [dbo].[getEmployeeWage]
    (
        @storeID int,
        @employeeID int,
        @beginDate datetime,
        @endDate datetime
        )

    RETURNS money

    AS
    BEGIN
        DECLARE @employeeWage money
        DECLARE @calcOvertime bit
        DECLARE @employeeRate money
        DECLARE @employeeHours money
        DECLARE @overtimeHours money
        DECLARE @whatIsOvertimeHours money

        select @calcOvertime = calcOvertime from miscsetup
        where storeid = @storeid or @storeid is null

        select @employeeRate = hourlywage from employee
        where employeeid = @employeeid
          and (storeid = @storeid or @storeid is null)


        select @employeeHours = dbo.getEmployeeHours(@storeid, @employeeID, @beginDate, @enddate)

        select @whatIsOvertimeHours = (datediff(day, @begindate, @enddate)+1) * 8

        if @calcOvertime = 0
            SET @employeeWage = @employeeHours * @employeeRate
        else
            BEGIN
                set @overtimeHours = @employeeHours - @whatIsOvertimeHours
                if @overtimeHours < 0
                    SET @employeeWage = @employeeHours * @employeeRate
                else
                    set @employeeWage = @employeeRate * @whatIsOvertimeHours + (@overtimeHours * (1.5 * @employeeRate))
            END

        Return round(@employeeWage, 2)
    END

GO
-- //@UNDO
-- SQL to undo the change goes here.


