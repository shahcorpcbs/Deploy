-- // add super user pages
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[SuperUserPages](
    Id bigint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    Location varchar(128) not null
);
GO

--insert into SuperUserPages(Location) values ('/setup/terminalPopupSetup.asp')
--insert into SuperUserPages(Location) values ('/setup/editSMSQuery.asp')
--GO


-- //@UNDO
-- SQL to undo the change goes here.
drop table [dbo].[SuperUserPages]
GO
