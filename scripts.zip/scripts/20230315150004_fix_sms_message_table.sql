-- // fix sms message table
-- Migration SQL that makes the change goes here.
alter table SmsMessage alter column emailFormId int;
GO

-- //@UNDO
-- SQL to undo the change goes here.


