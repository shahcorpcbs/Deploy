-- // ensure active route exists
-- Migration SQL that makes the change goes here.
IF NOT EXISTS(
        SELECT * FROM SYSCOLUMNS WHERE NAME = 'activeroute' and
                ID=OBJECT_ID(N'[DBO].[Route]'))
    BEGIN
        ALTER TABLE Route WITH NOCHECK ADD
            [activeroute] [bit] NOT NULL DEFAULT(1)
    END
GO


-- //@UNDO
-- SQL to undo the change goes here.


