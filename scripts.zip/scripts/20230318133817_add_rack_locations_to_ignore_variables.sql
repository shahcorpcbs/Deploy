-- // add rack locations to ignore variables
-- Migration SQL that makes the change goes here.
insert into QueryAlertVariable (QueryId, VariableDesc, VariableField, VariableValue) values
    (-2, 'Rack Locations to Ignore', 'ignore', '');
GO

ALTER TABLE QueryAlertVariable ALTER COLUMN VariableValue VARCHAR (50)
GO

-- //@UNDO
-- SQL to undo the change goes here.
delete QueryAlertVariable where QueryId = -2
GO

