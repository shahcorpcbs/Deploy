-- // add plant tables
-- Migration SQL that makes the change goes here.
alter table Store add storeType smallInt not null DEFAULT 0
GO


CREATE TABLE [dbo].[StoreConnectionHistory](
    Id bigint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    CreatedDate datetime NOT NULL,
    Direction smallInt not null,
    IPAddress VARCHAR(20) NOT NULL,
    port VARCHAR(10) NOT NULL,
    StoreName VARCHAR(50),
    StoreId int,
    ItemCnt int,
    MessageType smallint not null,
    MessageStatus smallint not null
);
GO


CREATE TABLE [dbo].[DropStoreSetup](
    Id bigint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    IPAddress VARCHAR(20) NOT NULL,
    Port VARCHAR(10) NOT NULL,
    NickName VARCHAR(50) NOT NULL,
    StoreName VARCHAR(50),
    Disabled bit not null default 0
);
GO


CREATE TABLE [dbo].[PlantStoreSetup](
    Id bigint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    IPAddress VARCHAR(20) NOT NULL,
    Port VARCHAR(10) NOT NULL,
    NickName VARCHAR(50) NOT NULL,
    StoreName VARCHAR(50),
    Disabled bit not null default 0
);
GO

CREATE TABLE [dbo].[PlantManifestItem](
    Id bigint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    TicketNumber varchar(20),
    InvoiceNumber varchar(20) not null,
    CustomerName varchar(50),
    Departments varchar(100),
    NumOfPieces int,
    CreatedDate datetime,
    DueDate datetime,
    ScannedDate datetime,
    Location varchar(30) not null,
    Status smallint not null
);
GO


CREATE TABLE [dbo].[ConnectionItemsLink](
    Id bigint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    ConnectionId int not null,
    ItemId int not null
);
GO


INSERT INTO EmployeeFunction (Location, Action, Name, Description) VALUES
('/MainApp/plantManifests.asp', '', 'Plant Setup::View Plant/Drop Store Manifests', ''),
('/MainApp/plantManifestItems.asp', '', 'Plant Setup::View Plant/Drop Manifest items', ''),
('/MainApp/connectManifest.asp', '', 'Plant Setup::Fix Store Setup', ''),
('/setup/plantSetup.asp', '', 'Plant Setup::View Plant/Drop Store Setup', ''),
('/setup/editPlantSetup.asp', '', 'Plant Setup::Edit Store Setup', '')
GO

insert into EmployeeTagSecurity(TagId, FunctionId) (select distinct tagId, ef.Id from EmployeeTagSecurity etg, EmployeeFunction ef
    where functionId = (select top(1) id from EmployeeFunction where location = '/mainapp/toolsMenu.asp') and ef.location in ('/MainApp/plantManifests.asp', '/MainApp/plantManifestItems.asp'))

insert into EmployeeTagSecurity(TagId, FunctionId) (select distinct tagId, ef.Id from EmployeeTagSecurity etg, EmployeeFunction ef
    where functionId = (select top (1) id from EmployeeFunction where location = '/setup/MainSetUp.asp') and ef.location in ('/MainApp/connectManifest.asp', '/setup/plantSetup.asp', '/setup/editPlantSetup.asp'))
GO

-- //@UNDO
-- SQL to undo the change goes here.
delete EmployeeTagSecurity where functionId in (select id from EmployeeFunction where location in ('/MainApp/plantManifests.asp','/MainApp/plantManifestItems.asp','/MainApp/connectManifest.asp', '/setup/plantSetup.asp', '/setup/editPlantSetup.asp'))
GO

delete EmployeeFunction where location in ('/MainApp/plantManifests.asp','/MainApp/plantManifestItems.asp','/MainApp/connectManifest.asp', '/setup/plantSetup.asp', '/setup/editPlantSetup.asp')
GO

drop table ConnectionItemsLink
GO
drop table PlantManifestItem
GO
drop table PlantStoreSetup
GO
drop table DropStoreSetup
GO
drop table StoreConnectionHistory
GO
