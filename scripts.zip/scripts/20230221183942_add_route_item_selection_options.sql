-- // add route item selection options
-- Migration SQL that makes the change goes here.
alter table Route add ItemInclusionOpt int not null default -1;
GO


-- //@UNDO
-- SQL to undo the change goes here.


