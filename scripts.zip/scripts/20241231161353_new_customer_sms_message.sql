-- // new customer sms message
-- Migration SQL that makes the change goes here.
INSERT INTO [dbo].[SmsMessage] (Message, Description, Subject)
VALUES ('{storename}: We want to thank you for giving us a chance to serve you',
        'New Customer', '{storename}: Thanks for coming in')
GO


insert into [dbo].[QueryAlert](Name, Query, SmsMessageId, TriggerType, Frequency, MessageTypeId, Hour, DayOfWeek, Day, groupType)
    (select 'New Customer', 'select customerSequenceNumber from customer where createdDate >= DATEADD(day, -{days}, GETDATE())',
            id, 0, 2, 2, 10, 0, 1, 2 from SmsMessage where Description = 'New Customer')


insert into QueryAlertVariable (QueryId, VariableDesc, VariableField, VariableValue)
(select id, 'Profile created in x days', 'days', 30 from QueryAlert where name = 'New Customer')
GO


insert into CustomerMessageSetup (CustomerId, QueryId, Sms, Email)
    (select distinct customerId, qa.id, 1, 0 from CustomerMessageSetup, queryAlert qa where qa.Name = 'New Customer')
GO


-- //@UNDO
-- SQL to undo the change goes here.


