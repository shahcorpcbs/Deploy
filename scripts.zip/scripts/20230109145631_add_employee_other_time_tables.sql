-- // add employee other time tables
-- Migration SQL that makes the change goes here.
if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EmployeeOtherTime]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    BEGIN
        CREATE TABLE [dbo].[EmployeeOtherTime](
                                                  [otherTimeID] [int] IDENTITY(1,1) NOT NULL,
                                                  [employeeID] [int] NOT NULL,
                                                  [TimeType] [char](1) NOT NULL,
                                                  [TimeDate] [datetime] NOT NULL,
                                                  [TimeHours] [float] NOT NULL,
                                                  [OTEligible] [bit] NOT NULL DEFAULT ((0))
        ) ON [PRIMARY]
    END
GO

if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EmployeeOtherTimeLog]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
    BEGIN
        CREATE TABLE [dbo].[EmployeeOtherTimeLog](
                                                     [ID] [int] IDENTITY(1,1) NOT NULL,
                                                     [LogDate] [datetime] NOT NULL DEFAULT (getdate()),
                                                     [LogType] [varchar](2) NOT NULL,
                                                     [OtherTimeID] [int] NOT NULL,
                                                     [timeDate] [datetime] NULL,
                                                     [timeHours] [float] NULL,
                                                     [timeType] [char](1) NOT NULL,
                                                     [otEligible] [bit] NOT NULL,
                                                     [note] [varchar](300) NULL,
                                                     [employeeID] [int] NULL
        ) ON [PRIMARY]
    END
GO

-- //@UNDO
-- SQL to undo the change goes here.
drop table EmployeeOtherTimeLog
GO
drop table EmployeeOtherTime
GO

