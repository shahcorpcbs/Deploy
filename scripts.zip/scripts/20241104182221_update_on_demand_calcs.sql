-- // update on demand calcs
-- Migration SQL that makes the change goes here.
CREATE FUNCTION dbo.getCustomerSalesWoOnAccount
(
    @customerSequenceNumber int,
    @rangeBegin datetime,
    @rangeEnd datetime
)
    RETURNS money
AS
BEGIN

    DECLARE @amount money
    DECLARE @ticketAmount money
    DECLARE @ledgerAmount money
    DECLARE @onAccountAmount money

    SELECT @ticketAmount = SUM(invoiceTotal)
    FROM Ticket
    WHERE CustomerSequenceNumber = @customerSequenceNumber
      AND NOT(DateOut IS NULL)
      AND (@rangeBegin IS NULL OR datediff(day, DateOut, @rangeBegin) <= 0)
      AND (@rangeEnd IS NULL OR datediff(day, DateOut, @rangeEnd) >= 0)

    SELECT @ledgerAmount = SUM(amountDue)
    FROM GeneralLedger
    WHERE CustomerSequenceNumber = @customerSequenceNumber
      AND refType = 'GL' and amountDue > 0
      AND (@rangeBegin IS NULL OR datediff(day, createddate, @rangeBegin) <= 0)
      AND (@rangeEnd IS NULL OR datediff(day, createddate, @rangeEnd) >= 0)

    SELECT @onAccountAmount = SUM(amountPaid)
    FROM Payment
    WHERE CustomerSequenceNumber = @customerSequenceNumber
      AND paymentTypeName = 'On Account'
      AND (@rangeBegin IS NULL OR datediff(day, createddate, @rangeBegin) <= 0)
      AND (@rangeEnd IS NULL OR datediff(day, createddate, @rangeEnd) >= 0)

    SET @amount = ISNULL(@ticketAmount, 0) + ISNULL(@ledgerAmount,0) - ISNULL(@onAccountAmount,0)

    RETURN @amount
END
GO



drop procedure dbo.GetProbableOnDemandCoupons
GO


create procedure dbo.GetProbableOnDemandCoupons
(
    @customerSequenceNumber int
)
as
begin

    select odc.*, f.formLayout from
                                   (select count(*) as cnt, max(awarded.Cri_Value) as tot
                                    from OnDemandCouponsAwarded awarded
                                    where awarded.customerSequenceNumber = @customerSequenceNumber) as awarded,
                                   OnDemandCoupon odc,
                                   Discount disc,
                                   Customer cust,
                                   Form f
    where
            cust.customerSequenceNumber = @customerSequenceNumber and
            (case odc.Cri_Target when 'VISITS' then (dbo.getCustomerVisits(cust.customersequencenumber, null, null) + 1) else dbo.getCustomerSalesWoOnAccount(cust.customersequencenumber, null, null) end) >= isnull(awarded.tot, 0.0) + odc.Cri_Required and
        (odc.Cri_Condition <> 'FIRST' OR (case odc.Cri_Target when 'VISITS' then dbo.getCustomerVisits(cust.customersequencenumber, null, null) else dbo.getCustomerSalesWoOnAccount(cust.customersequencenumber, null, null) end) <= odc.Cri_Required) and
            isnull(awarded.cnt, 0.0) < (case odc.Cri_Condition when 'FIRST' then 1 else 999999999 end) and
            cust.OnDemandQualified = 1 and
        (
                (odc.UsableByRouteCust = 1 and cust.routeNumber > 0) or
                (odc.UsableByCounterCust = 1 and cust.routeNumber = 0)
            ) and
            disc.discountID = odc.CID and
            disc.priceListID = isnull(cust.defaultPriceListID, 1) and
            f.formName = odc.formName


END  -- End of Procedure
GO


-- //@UNDO
-- SQL to undo the change goes here.


