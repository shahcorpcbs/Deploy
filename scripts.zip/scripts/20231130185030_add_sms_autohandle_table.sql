-- // add sms autohandle table
-- Migration SQL that makes the change goes here.

CREATE TABLE [dbo].[SMSAutoHandle] (
    [ID] [int] IDENTITY(1, 1) NOT NULL,
    [Handle] [smallint] NOT NULL default 1
) ON [PRIMARY]

SET IDENTITY_INSERT [dbo].[SMSAutoHandle] ON;
INSERT INTO [dbo].[SMSAutoHandle] (ID)VALUES (1);
INSERT INTO [dbo].[SMSAutoHandle] (ID)VALUES (2);
INSERT INTO [dbo].[SMSAutoHandle] (ID)VALUES (3);
INSERT INTO [dbo].[SMSAutoHandle] (ID)VALUES (4);
INSERT INTO [dbo].[SMSAutoHandle] (ID, Handle)VALUES (5, 2);
INSERT INTO [dbo].[SMSAutoHandle] (ID)VALUES (6);



SET IDENTITY_INSERT [dbo].[SMSAutoHandle] OFF;
GO
-- //@UNDO
-- SQL to undo the change goes here.

drop table SMSAutoHandle
GO
