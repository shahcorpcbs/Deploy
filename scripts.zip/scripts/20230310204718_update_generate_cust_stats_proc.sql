-- // update generate cust stats proc
-- Migration SQL that makes the change goes here.
USE [shahcorp]
GO

/****** Object:  StoredProcedure [dbo].[GenerateCustomerStats]    Script Date: 3/10/2023 1:43:47 PM ******/
DROP PROCEDURE [dbo].[GenerateCustomerStats]
GO

/****** Object:  StoredProcedure [dbo].[GenerateCustomerStats]    Script Date: 3/10/2023 1:43:47 PM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO




CREATE PROCEDURE [dbo].[GenerateCustomerStats]
    @days as int,
    @interval as int
AS
BEGIN
    DECLARE @dateRan datetime
    DECLARE @bucket int

    DELETE CustomerStats

    WHILE @days > 0
        BEGIN
            SELECT @dateRan = dateadd(day, -@days, getdate())
            SET @bucket = DATEPART(yyyy, @dateRan) * 12 + DATEPART(m, @dateRan)

            INSERT INTO CustomerStats (CustomerSequenceNumber, DateCalculated, Score, Percentile,Bucket)
            SELECT CustomerSequenceNumber, @dateRan as dateRan, dbo.scoreCustomer(CustomerSequenceNumber, @dateRan, 120) as score, 0 as percentile, @bucket
            FROM Customer
            WHERE visitCount > 0

            SET @days = @days - @interval
        END

    SELECT 1
END




GO





-- //@UNDO
-- SQL to undo the change goes here.


