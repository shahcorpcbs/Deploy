-- // add default select options
-- Migration SQL that makes the change goes here.
alter table MiscSetup add defaultColorInputField smallint not null DEFAULT 0
GO
alter table MiscSetup add defaultPatternInputField smallint not null DEFAULT 0
GO
alter table MiscSetup add defaultUpchargeInputField smallint not null DEFAULT 0
GO
alter table MiscSetup add defaultBrandInputField smallint not null DEFAULT 1
GO

-- //@UNDO
-- SQL to undo the change goes here.


