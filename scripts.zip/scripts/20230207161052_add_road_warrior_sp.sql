-- // add road warrior sp
-- Migration SQL that makes the change goes here.
USE [shahcorp]
GO
/****** Object:  UserDefinedFunction [dbo].[getInvoicesforDelivery]    Script Date: 11/1/2022 2:14:56 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[getInvoicesforDelivery]
(
    @deliveryID int
, @customerDeliveryID int
)
    RETURNS VARCHAR(300)
AS
BEGIN
    /*********************************************************
    Name: getInvoicesForDelivery
    Author: MWiemann
    Created: 05-nov-2018
    Function to return the invoices to be delivered to a
    customer via a delivery route.  Returns initial for
    department and invoice number separated by comma(,)
    */
    DECLARE @thisItem varchar(50)
    DECLARE @result varchar(300) = ''
    ;WITH cte AS
              (SELECT (SELECT ', ' + LEFT(DBO.PIVOTTICKETDEPARTMENTS(ticketnumber,null),1)+'-'+InvoiceNumber
                       FROM DELIVERYITEM
                       WHERE deliveryID = @deliveryID AND
                               customerDeliveryID = @customerDeliveryID
                       FOR XML PATH(''), Type) as Result)
     SELECT @Result = Result.value('.','varchar(500)') FROM cte;
    SELECT @Result = isnull(STUFF(@Result,1,1,''),' ')
    RETURN @RESULT
END
GO

Create procedure [dbo].[routeRunnerExport](@deliveryid int) as
begin

    select
--ds.stoporder, -- current stop order
cf.name, -- customer name
CASE
    WHEN ISNUMERIC(LEFT(LTRIM(c.shippingaddress1), CHARINDEX(' ', LTRIM(c.shippingaddress1)))) = 1
        THEN LEFT(LTRIM(c.shippingaddress1), CHARINDEX(' ', LTRIM(c.shippingaddress1)))
    ELSE ''
    END as [Building/House Number],
CASE
    WHEN ISNUMERIC(LEFT(LTRIM(c.shippingaddress1), CHARINDEX(' ', LTRIM(c.shippingaddress1)))) = 1
        THEN LTRIM(RTRIM(SUBSTRING(LTRIM(c.shippingaddress1), CHARINDEX(' ', LTRIM(c.shippingaddress1)) + 1, LEN(LTRIM(c.shippingaddress1)))))
    ELSE LTRIM(RTRIM(c.shippingaddress1))
    END + case when c.shippingaddress2 is null then '' else ' '+c.shippingaddress2 end as [Street Name],
c.shippingcity as [City],
c.shippingstate as [State/Region],
c.shippingzipcode as [Postal],
'USA' as [Country],
'' as [Color (0-1)],
cf.phone, -- customer phone
replace(replace(ds.deliverynotes, char(13), char(32)),char(10),char(32)) + ' '+ dbo.getInvoicesForDelivery(ds.deliveryid, ds.customerDeliveryID) as [Note], -- delivery notes
'' as [Latitude],
'' as [Longitude],
'' as [Service],
stoporder as [Stop Order],
c.customersequencenumber as [CustSeq]
    from deliverystop ds inner join customerfields cf on ds.customersequencenumber = cf.customersequencenumber
                         inner join customer c on ds.CustomerSequenceNumber = c.customerSequenceNumber
    where ds.deliveryid = @deliveryid
    order by stoporder
end
GO

insert into userquery(name,query,description)
values('Road Warrior Export','EXEC routeRunnerExport @deliveryId', 'Create delivery export for Road Warrior')
GO

-- //@UNDO
-- SQL to undo the change goes here.
delete userQuery where name = 'Road Warrior Export'
GO
drop procedure routeRunnerExport
GO
drop function getInvoicesforDelivery
GO

