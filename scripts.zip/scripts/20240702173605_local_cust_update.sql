-- // local cust update
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[DataUpdateLocalNotification](
     [Id] [bigint] NOT NULL IDENTITY(1,1) PRIMARY KEY,
     [DateSent] [datetime] NOT NULL,
     [Success] [bit] NOT NULL DEFAULT 0,
     [UpdateCustCnt] [int] NOT NULL default 0,
     [UpdateTicketCnt] [int] NOT NULL default 0,
     [UpdateTicketItemCnt] [int] NOT NULL default 0,
     [UpdateDiscountCnt] [int] NOT NULL default 0,
     [UpdateChargeCnt] [int] NOT NULL default 0,
     [CustSeed] [datetime],
     [TicketSeed] [datetime],
     [ChargeSeed] [datetime]
)
GO


-- //@UNDO
-- SQL to undo the change goes here.
drop table DataUpdateLocalNotification
GO