-- // update items table size
-- Migration SQL that makes the change goes here.
SET IDENTITY_INSERT SubxCustItems ON

DECLARE @ConstraintName nvarchar(200)
SELECT @ConstraintName = Name FROM SYS.sysobjects
WHERE PARENT_OBJ = OBJECT_ID('SubxCustItems')
  AND xtype = 'PK'
IF @ConstraintName IS NOT NULL
    EXEC('ALTER TABLE SubxCustItems DROP CONSTRAINT ' + @ConstraintName)

ALTER table SubxCustItems alter column id int
ALTER TABLE SubxCustItems ADD CONSTRAINT SubxCustItemsPK PRIMARY KEY (id)
SET IDENTITY_INSERT SubxCustItems OFF
GO

-- //@UNDO
-- SQL to undo the change goes here.


