-- // add sub autopickup flag
-- Migration SQL that makes the change goes here.
alter table SubXCust add autoPickup bit not null DEFAULT 0
GO


-- //@UNDO
-- SQL to undo the change goes here.


