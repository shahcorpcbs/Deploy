-- // add sub invoice tables
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[InvoiceSubDivision](
       Id bigint NOT NULL IDENTITY(1,1) PRIMARY KEY,
       TicketNumber int not null,
       SubLabel varchar(20),
       LineItemId int not null,
       pickedUp bit not null default 0,
       CONSTRAINT isd_in FOREIGN KEY([TicketNumber]) REFERENCES [dbo].[Ticket] ([TicketNumber])
)
GO



-- //@UNDO
-- SQL to undo the change goes here.
alter table InvoiceSubDivision drop constraint isd_in
GO

drop table InvoiceSubDivision
GO

