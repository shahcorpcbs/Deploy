-- // add run now warning
-- Migration SQL that makes the change goes here.
alter table MiscSetup add warnRunNow bit not null default 1
GO
alter table MiscSetup add warnCnt integer not null default 0
GO


-- //@UNDO
-- SQL to undo the change goes here.


