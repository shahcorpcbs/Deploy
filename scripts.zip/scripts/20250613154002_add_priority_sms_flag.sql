-- // add priority sms flag
-- Migration SQL that makes the change goes here.
alter table TwilioSendSmsApiCall add priority bit not null default 0
GO
alter table MiscSetup add priorityDSMS bit not null default 0
GO

-- //@UNDO
-- SQL to undo the change goes here.


