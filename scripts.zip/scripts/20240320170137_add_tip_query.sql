-- // add tip query
-- Migration SQL that makes the change goes here.
ALTER TABLE userQuery ALTER COLUMN query VARCHAR (1500)
GO

insert into userquery(name,query,description)
values('Display Employee Tips','
select e.employeeName, c.customerName, cp.DateRequested, case when TicketNumber is not null then (select invoiceNumber from Ticket where ticketNumber = et.ticketNumber) else ''No Ticket'' end as ''TicketNumber'', tipAmt as ''Tip Amount''
from EmployeeTip et, CardPayment cp, Employee e, Customer c where et.CardPaymentId = cp.CardPaymentID and e.employeeID = cp.Clerk
and c.customerSequenceNumber = cp.CustomerSequenceNumber and Added = 1 and cp.Reversed = 0 and cp.DateRequested >= ''@Begin_Date:date'' and cp.DateRequested <= ''@End_Date:date 23:59:59''
union all
select e.employeeName, ''Total'', null, '''', sum(tipAmt) from Employeetip et, Employee e, CardPayment cp where et.CardPaymentId = cp.CardPaymentID and e.employeeID = cp.Clerk
and Added = 1 and cp.Reversed = 0 and cp.DateRequested >= ''@Begin_Date:date'' and cp.DateRequested <= ''@End_Date:date 23:59:59''
 group by e.employeeName
union all
select ''Grand Total'', '''', null, '''', sum(tipAmt) from EmployeeTip et, CardPayment cp
where et.CardPaymentId = cp.CardPaymentID and Added = 1 and cp.Reversed = 0 and cp.DateRequested >= ''@Begin_Date:date'' and cp.DateRequested <= ''@End_Date:date 23:59:59''',
'Shows tips employees have earned over a time period')
GO


-- //@UNDO
-- SQL to undo the change goes here.
delete userQuery where name = 'Display Employee Tips'
GO

