-- // add sub tax
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[SubscriptionTax](
    Id smallint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    subId smallint not null,
    taxCode smallInt not null
)
GO


-- //@UNDO
-- SQL to undo the change goes here.


