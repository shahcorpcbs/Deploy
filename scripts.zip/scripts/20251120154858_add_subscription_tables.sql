-- // add subscription tables
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[Subscription](
    Id smallint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    name varchar(254) not null,
    price money not null,
    dateLastChecked datetime not null default GETDATE()
)
GO

CREATE TABLE [dbo].[SubPromotion](
    Id smallint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    name varchar(254) not null,
    type smallint not null,
    maxAmt smallint not null,
    percentOff smallint not null default 100,
    percentAfterLimit smallint not null default 0,
)
GO

CREATE TABLE [dbo].[SubPromotionxDept](
    Id smallint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    promoId smallint not null,
    departId smallint not null,
)
GO

CREATE TABLE [dbo].[SubxPromo](
    Id smallint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    subId smallint not null,
    promoId smallint not null,
)
GO

CREATE TABLE [dbo].[SubxCust](
    Id int NOT NULL IDENTITY(1,1) PRIMARY KEY,
    subId smallint not null,
    custSeqNum int not null,
    billingDay smallint not null,
    enabled bit not null default 1,
    canceled bit not null default 0
)
GO

CREATE TABLE [dbo].[SubxCustItems](
    Id smallint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    subId smallint not null,
    custSeqNum int not null,
    ticketNumber int not null,
    ticketLineItemNumber int not null,
    dateCreated datetime
)
GO


create procedure dbo.updateTicketPrice
(
    @ticketNumber int
)
as
begin
    declare @cost money
    declare @savings money

    select @cost = sum(lineItemTotal) from TicketLineItem where ticketNumber = @ticketNumber and ticketLineType
        in ('IT', 'UP', 'CO', 'PA', 'AC', 'TA', 'SU')
    
    select @savings = coalesce(sum(lineItemTotal), 0) from TicketLineItem where ticketNumber = @ticketNumber and ticketLineType
        in ('CU', 'PR', 'VI', 'RE')

    update ticket set invoiceTotal = @cost - @savings where ticketNumber = @ticketNumber;


    return 0;
end
GO
-- //@UNDO
-- SQL to undo the change goes here.


