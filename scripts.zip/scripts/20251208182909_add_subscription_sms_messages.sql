-- // add subscription sms messages
-- Migration SQL that makes the change goes here.
INSERT INTO [dbo].[SmsMessage] (Message, Description, Subject)
VALUES ('{storename}: Your monthly subscription has renewed and you have been billed.',
        'Subscription Billing', '{storename}: Subscription Renewed')
GO


insert into [dbo].[QueryAlert](Name, Query, SmsMessageId, TriggerType, Frequency, MessageTypeId, Hour, DayOfWeek, Day, groupType)
    (select 'Subscription Bill', 'select distinct customerSequenceNumber from Ticket t, ticketLineitem tli where t.ticketNumber = tli.ticketNumber  ' +
                                 'and tli.lineItemName = ''Subscription'' and cast(t.createdDate as date) = cast(GETDATE() as date) and datepart(hour, t.createdDate) < 2',
            id, 0, 2, 2, 10, 0, 1, 1 from SmsMessage where Description = 'Subscription Billing')


insert into CustomerMessageSetup (CustomerId, QueryId, Sms, Email)
    (select distinct customerId, qa.id, 1, 0 from CustomerMessageSetup, queryAlert qa where qa.Name = 'Subscription Bill')
GO



INSERT INTO [dbo].[SmsMessage] (Message, Description, Subject)
VALUES ('{storename}: You have exceeded your monthly subscription limit. {newPercentage}',
        'Subscription Overage', '{storename}: Subscription Overage')
GO


insert into [dbo].[QueryAlert](Name, Query, SmsMessageId, TriggerType, Frequency, MessageTypeId, Hour, DayOfWeek, Day, groupType)
    (select 'Subscription Overage', '', id, 0, 2, 3, 1, 0, 1, 1 from SmsMessage where Description = 'Subscription Overage')


insert into CustomerMessageSetup (CustomerId, QueryId, Sms, Email)
    (select distinct customerId, qa.id, 1, 0 from CustomerMessageSetup, queryAlert qa where qa.Name = 'Subscription Overage')
GO


-- //@UNDO
-- SQL to undo the change goes here.
delete CustomerMessageSetup where queryId in (select id from QueryAlert where name = 'Subscription Bill' or name = 'Subscription Overage')
GO
delete QueryAlert where name = 'Subscription Bill' or name = 'Subscription Overage'
GO
delete SmsMessage where  Description = 'Subscription Billing' or Description = 'Subscription Overage'
GO
