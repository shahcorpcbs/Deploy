-- // add manual finish flag
-- Migration SQL that makes the change goes here.
alter table CardAttempt add interventionRequired bit not null DEFAULT 0
GO


-- //@UNDO
-- SQL to undo the change goes here.

