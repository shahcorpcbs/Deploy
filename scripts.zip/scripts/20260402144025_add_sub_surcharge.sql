-- // add sub surcharge
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[SubscriptionSurcharge](
    Id smallint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    subId smallint not null,
    surCode smallInt not null
)
GO


-- //@UNDO
-- SQL to undo the change goes here.


