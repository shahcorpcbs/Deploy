-- // create on demand credit report
-- Migration SQL that makes the change goes here.
CREATE FUNCTION dbo.getCustPendingCredits
(
    @custSeq int
)
    RETURNS money
AS
BEGIN
    DECLARE @accountbalance MONEY

    SELECT @accountBalance = ISNULL(SUM(amountDue),0) - ISNULL(SUM(routeDiscount),0)
    FROM generalLedger gl
    WHERE gl.customersequencenumber = @custSeq
      AND ISNULL(gl.refdescription,'') <> 'Credit due to excess payment'
      AND NOT EXISTS(SELECT NULL FROM dbo.ReversePaymentTracking rpt WHERE gl.refNumber = rpt.ReversePaymentID);

    RETURN @accountBalance * -1
END
GO

CREATE FUNCTION dbo.getCustCurrODStatus
(
    @custSeq int,
    @odcId int
)
    RETURNS DECIMAL(10, 2)
AS
BEGIN
    declare @maxValue DECIMAL(10, 2)
    declare @visits int
    declare @totalSales money
    declare @result DECIMAL(10, 2)


    select @maxValue = isnull(max(cri_value), 0) from ondemandcouponsawarded where customersequencenumber = @custSeq and odcid = @odcid;
    select @visits = isnull(dbo.getCustomerVisits(@custSeq, null, null), 0), @totalSales = isnull(dbo.getCustomerSales(@custSeq, null, null), 0) from customer where customerSequenceNumber = @custSeq;


    select @result = (case when (select cri_target from ondemandcoupon where id = @odcid) = 'VISITS' then @visits - @maxValue else @totalSales - @maxValue end) from Customer where customerSequenceNumber = @custSeq;

    RETURN @result
END
GO

CREATE FUNCTION dbo.CustODCreditEarned
(
    @custSeq int,
    @odcid int
)
    RETURNS money
AS
BEGIN
    DECLARE @earned MONEY

    SELECT @earned = ISNULL(SUM(chargeAmount),0) from MiscCharge where customerSequenceNumber = @custSeq and onDemandId = @odcid;

    RETURN @earned
END
GO



insert into userquery(name,query,description)
values('On Demand Credit Report','select * from (
select c.customerName, concat(odc.cri_condition, '' '', odc.cri_required, '' '', odc.cri_target) as ''OnDemand'',
dbo.CustODCreditEarned(c.customerSequenceNumber, odc.id) as ''CreditEarned'',
dbo.getCustPendingCredits(c.customerSequenceNumber) as ''RemainingCredits'',
dbo.getCustCurrODStatus(c.customerSequenceNumber, odc.id) as ''CurrentLevel''
from onDemandCoupon odc, customer c where odc.id = ''@OnDemandId:ondemand'') as innerTable where CreditEarned > 0 or CurrentLevel > 0',
       'Shows account credits given for an on demand coupons')
GO


-- //@UNDO
-- SQL to undo the change goes here.


