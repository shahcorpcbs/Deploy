-- // fix sms query message type
-- Migration SQL that makes the change goes here.
update QueryAlert set messageTypeId = 3 where id in (-12, -2)
GO


-- //@UNDO
-- SQL to undo the change goes here.


