-- // add since active variable to query
-- Migration SQL that makes the change goes here.]

declare @qaId as int;
select @qaId = id from QueryAlert where Name = 'General Notice';
update QueryAlert set Query = 'select c.customerSequenceNumber from customer c inner join customerfields cf on c.customersequencenumber = cf.customersequencenumber where twilioBlackList = 0
and cellPhone is not null and cellPhone != '''' and isActive = 1
    and ({days} <= 0 or datediff(day, cf.Last_Visit, getdate()) <= {days})'
where id = @qaId;

insert into QueryAlertVariable (QueryId, VariableDesc, VariableField, VariableValue) values (@qaId, 'Visited with x Days', 'days', 0);
GO
-- //@UNDO
-- SQL to undo the change goes here.


