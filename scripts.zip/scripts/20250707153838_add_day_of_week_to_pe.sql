-- // add day of week to pe
-- Migration SQL that makes the change goes here.
alter table Department ADD dayOfWeek smallint NOT NULL DEFAULT 0;
GO

-- //@UNDO
-- SQL to undo the change goes here.


