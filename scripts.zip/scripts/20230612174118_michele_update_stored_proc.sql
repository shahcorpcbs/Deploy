-- // michele update stored proc
-- Migration SQL that makes the change goes here.
USE [shahcorp]
GO

/****** Object:  StoredProcedure [dbo].[RackPendingRackLocations]    Script Date: 6/11/2023 5:40:54 PM ******/
DROP PROCEDURE [dbo].[RackPendingRackLocations]
GO

/****** Object:  StoredProcedure [dbo].[RackPendingRackLocations]    Script Date: 6/11/2023 5:40:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



Create FUNCTION [dbo].[createQueryString]
(
    @String varchar(100)
)
    RETURNS varchar(150)
AS
BEGIN
    declare @queryString varchar(150)

    set @queryString = REPLACE(@String,' ', '')

    set @queryString = REPLACE(@queryString,char(44),char(39)+char(44)+char(39))

    set @queryString = char(39)+@queryString+char(39)

    return @queryString
END

GO



CREATE    PROCEDURE [dbo].[RackPendingRackLocations]
    @TerminalID int,
    @EmployeeID int,
    @ForceRacking bit
AS
BEGIN
    DECLARE @RackLocationID INT
    DECLARE @InvoiceNumber VARCHAR(128)
    DECLARE @TicketNumber INT
    DECLARE @StartRackLocation VARCHAR(128)
    DECLARE @EndRackLocation VARCHAR(128)
    DECLARE @ErrorNo INT
    DECLARE @ErrorMessage VARCHAR(128)
    DECLARE @StoreID INT
    DECLARE @RackedEmployeeID INT
    DECLARE @overridePreviousRackLocation BIT
    DECLARE @customerSeq INT
    DECLARE @EventDescription VARCHAR(200)
    DECLARE @RackLocationsToIgnore VARCHAR(150)
    DECLARE @IgnoreRackLocation BIT

    CREATE TABLE #ErrorResponse (
                                    ErrorMessage VARCHAR(128),
                                    ErrorNo int
    )


    DECLARE RackListCursor CURSOR FOR
        SELECT RackLocationID, InvoiceNumber, EmployeeID, StartRackLocation, EndRackLocation, ErrorNo, Notes
        FROM PendingRackLocations
        WHERE TerminalID = @TerminalID
          AND (EmployeeID = @EmployeeID OR @EmployeeID IS NULL)
        ORDER BY RackLocationID DESC

    SELECT @StoreID = StoreID FROM Terminal WHERE TerminalID = @TerminalID

    SELECT @overridePreviousRackLocation = overridePreviousRackLocation FROM MiscSetup WHERE StoreID = @StoreID

    SELECT @RackLocationsToIgnore = dbo.createquerystring(variablevalue) FROM queryalertvariable WHERE variabledesc = 'Rack Locations to Ignore'


    OPEN RackListCursor

    FETCH NEXT FROM RackListCursor INTO @RackLocationID, @InvoiceNumber, @RackedEmployeeID, @StartRackLocation, @EndRackLocation, @ErrorNo, @ErrorMessage
    WHILE @@FETCH_STATUS = 0
        BEGIN
            DELETE #ErrorResponse

            IF @ErrorNo = 0
                BEGIN
                    INSERT INTO #ErrorResponse EXEC CheckRackStatus @TerminalID, @InvoiceNumber, @StartRackLocation, @EndRackLocation

                    SELECT @ErrorNo = ErrorNo FROM #ErrorResponse
                    SELECT @ErrorMessage = ErrorMessage FROM #ErrorResponse
                END

            IF @ErrorNo = 0 OR (@ErrorNo = 1 AND @ForceRacking = 1)
                BEGIN
                    IF exists (Select ticketnumber from ticketlineitem where  invoicenumber = rtrim(@InvoiceNumber))
                        BEGIN
                            SELECT @TicketNumber = ticket.TicketNumber, @customerSeq = ticket.CustomerSequenceNumber
                            FROM ticket
                                     INNER JOIN ticketlineitem ON ticket.ticketnumber = ticketlineitem.ticketnumber
                            WHERE ticketlineitem.invoicenumber = rtrim(@InvoiceNumber)
                        END
                    ELSE
                        BEGIN
                            SELECT @TicketNumber = TicketNumber, @customerSeq = CustomerSequenceNumber FROM Ticket WHERE InvoiceNumber = @InvoiceNumber
                        END

                    IF NOT EXISTS(SELECT * FROM RackAssignment WHERE TicketNumber = @TicketNumber
                                                                 AND RTRIM(RackLocationStart) = RTRIM(@StartRackLocation))
                        BEGIN
                            IF @overridePreviousRackLocation = 1
                                DELETE RackAssignment WHERE TicketNumber = @TicketNumber

                            INSERT RackAssignment (Ticketnumber,RackLocationStart,RackLocationEnd,RackedEmployeeid, Rackeddate , storeid, InvoiceNumber)
                            VALUES (  @TicketNumber, @StartRackLocation, @EndRackLocation, @RackedEmployeeID, getdate(), @StoreID, @InvoiceNumber)

                            select @IgnoreRackLocation = CHARINDEX(@StartRackLocation,@RackLocationsToIgnore)

                            IF @IgnoreRackLocation = 0
                                BEGIN
                                    UPDATE TICKET
                                    SET origRackDate = getdate()
                                    where ticketnumber = @ticketnumber
                                      and origRackDate is null
                                END


                            set @EventDescription = 'Assigned to rack ' + cast(@StartRackLocation as varchar)
                            execute AddTicketEvent @ticketNumber, @employeeID, 'RACK', @StartRackLocation, @EventDescription

                            IF NOT EXISTS(SELECT ticketNumber FROM ticket WHERE ticketStatus = 'AC' and customerSequenceNumber = @customerSeq and dbo.pivotTicketRackLocationBrief(ticketNumber, ',') = '')
                                BEGIN
                                    execute TriggerNotification 'NRACKED', @EmployeeID, @customerSeq, NULL
                                END
                        END

                    DELETE PendingRackLocations
                    WHERE RackLocationID = @RackLocationID
                END
            ELSE
                BEGIN
                    UPDATE PendingRackLocations SET
                                                    Notes = @ErrorMessage,
                                                    ErrorNo = @ErrorNo
                    WHERE RackLocationID = @RackLocationID
                END

            FETCH NEXT FROM RackListCursor INTO @RackLocationID, @InvoiceNumber, @RackedEmployeeID, @StartRackLocation, @EndRackLocation, @ErrorNo, @ErrorMessage
        END


    CLOSE RackListCursor
    DEALLOCATE RackListCursor

    Delete #ErrorResponse
    Drop table #ErrorResponse
END

GO





-- //@UNDO
-- SQL to undo the change goes here.


