-- // add credit on demand
-- Migration SQL that makes the change goes here.
alter table OnDemandCoupon add type smallint not null DEFAULT 1
GO
alter table OnDemandCoupon add creditAmt money
GO

alter table MiscCharge add onDemandId smallint
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AwardCurrentOnDemandCoupons]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
    drop procedure [dbo].[AwardCurrentOnDemandCoupons]
GO


create procedure dbo.AwardCurrentOnDemandCoupons
(
    @customerSequenceNumber int
)
as
begin
    declare @odcid int

    create table #allCurrentODCID (
                                      ID int,
                                      CID int,
                                      Enabled bit,
                                      CQ bit,
                                      RQ bit,
                                      FormName varchar(64),
                                      CC varchar(16),
                                      CR decimal,
                                      CT char(16),
                                      type bit,
                                      creditAmt money,
                                      Form image
    )

    insert into #allCurrentODCID exec getProbableOnDemandCoupons @customerSequenceNumber

    Declare ListCursor CURSOR for
        select ID from #allCurrentODCID

    Open ListCursor

    fetch next from ListCursor into @odcid
    while @@FETCH_STATUS = 0
        begin
            print @customerSequenceNumber
            print @odcid
            execute AwardOnDemandCoupon @customerSequenceNumber, @odcid
            fetch next from ListCursor into @odcid

        end

    close ListCursor
    deallocate ListCursor

    drop table #allCurrentODCID


END  -- End of Procedure
GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS ON
GO

GRANT  EXECUTE  ON [dbo].[AwardCurrentOnDemandCoupons]  TO [public]
GO


-- //@UNDO
-- SQL to undo the change goes here.


