-- // add subpress notification flag
-- Migration SQL that makes the change goes here.
ALTER TABLE RackAssignment ADD suppressNotification bit NOT NULL DEFAULT 0;
GO


-- //@UNDO
-- SQL to undo the change goes here.


