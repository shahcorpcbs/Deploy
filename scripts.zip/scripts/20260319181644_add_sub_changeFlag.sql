-- // add sub changeFlag
-- Migration SQL that makes the change goes here.
alter table SubXCust add nextBilling bit not null DEFAULT 0
GO

-- //@UNDO
-- SQL to undo the change goes here.


