-- // add wsr options
-- Migration SQL that makes the change goes here.
ALTER TABLE MiscSetup ADD runWSR bit NOT NULL DEFAULT 0;
GO
ALTER TABLE MiscSetup ADD WSRTime smallint NOT NULL DEFAULT 22;
GO

-- //@UNDO
-- SQL to undo the change goes here.


