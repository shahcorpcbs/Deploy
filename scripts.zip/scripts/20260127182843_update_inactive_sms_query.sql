-- // update inactive sms query
-- Migration SQL that makes the change goes here.
insert into QueryAlertVariable (QueryId, VariableDesc, VariableField, VariableValue)
    (select id, 'Max Days Inactive', 'maxDays', 0 from QueryAlert where name = 'Inactive Customers')
GO

update QueryAlert set query = 'select c.customerSequenceNumber from customer c inner join customerfields cf on c.customersequencenumber = cf.customersequencenumber where twilioBlackList = 0 and cellPhone is not null and cellPhone != '''' and isActive = 1 and datediff(day, cf.Last_Visit, getdate()) >= {days}' +
                              ' and ({maxDays} = 0 or datediff(day, cf.Last_Visit, getdate()) < {maxDays})'
where name = 'Inactive Customers'
GO
-- //@UNDO
-- SQL to undo the change goes here.


