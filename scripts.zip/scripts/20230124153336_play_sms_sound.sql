-- // play sms sound
-- Migration SQL that makes the change goes here.
alter table MiscSetup add playSmsSound bit not null DEFAULT 0
GO


-- //@UNDO
-- SQL to undo the change goes here.
alter table MiscSetup drop column playSmsSound;
--GO

