-- // itacs setup
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[ItacsSetup](
    Id smallint NOT NULL IDENTITY(1,1) PRIMARY KEY,
    enabled bit not null default 0,
    runEvery smallint not null default 15,
    localPath varchar(254),
    remotePath varchar(254)
)
GO

insert into ItacsSetup(enabled, runEvery) values (0, 15)
GO


-- //@UNDO
-- SQL to undo the change goes here.
drop table ItacsSetup
GO

