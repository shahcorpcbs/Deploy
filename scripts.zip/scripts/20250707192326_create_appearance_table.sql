-- // create appearance table
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[CBSAppearance](
    useNew bit not null default 0,
    useNewPLI bit not null default 0,
    custIconPath varchar(254) not null,
    rackingIconPath varchar(254) not null,
    manIconPath varchar(254) not null,
    routeIconPath varchar(254) not null,
    toolsIconPath varchar(254) not null,
    retailIconPath varchar(254) not null,
    empIconPath varchar(254) not null
)
GO

insert into CBSAppearance (useNew, useNewPLI, custIconPath, rackingIconPath, manIconPath, routeIconPath, toolsIconPath, retailIconPath, empIconPath)
values (0, 0,'/redesign/start_customerfunctions.jpg', '/redesign/start_racking.jpg', '/redesign/start_manager.jpg',
     '/redesign/start_routes.jpg', '/redesign/start_tools.jpg', '/redesign/start_countersales.jpg', '/redesign/start_employee.jpg')
GO




