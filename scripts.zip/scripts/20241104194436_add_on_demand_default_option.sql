-- // add on demand default option
-- Migration SQL that makes the change goes here.
alter table MiscSetup add ondQualifiedDefault bit not null default 1
GO


-- //@UNDO
-- SQL to undo the change goes here.


