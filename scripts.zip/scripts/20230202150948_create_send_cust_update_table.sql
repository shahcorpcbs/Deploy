-- // create send cust update table
-- Migration SQL that makes the change goes here.
CREATE TABLE [dbo].[DataUpdateNotification](
[Id] [bigint] NOT NULL IDENTITY(1,1) PRIMARY KEY,
[DateSent] [datetime] NOT NULL,
[Success] [bit] NOT NULL DEFAULT 0,
[UpdateCustCnt] [int] NOT NULL default 0,
[UpdateTicketCnt] [int] NOT NULL default 0,
[UpdateTicketItemCnt] [int] NOT NULL default 0,
[UpdateDiscountCnt] [int] NOT NULL default 0,
[UpdateChargeCnt] [int] NOT NULL default 0,
[CustSeed] [datetime],
[TicketSeed] [datetime],
[ChargeSeed] [datetime]
);
GO

insert into CustFieldWatch (Field, SendNotification) values ('firstName', 1)
GO
insert into CustFieldWatch (Field, SendNotification) values ('lastName', 1)
GO
insert into CustFieldWatch (Field, SendNotification) values ('email', 1)
GO
insert into CustFieldWatch (Field, SendNotification) values ('routeNumber', 1)
GO
insert into CustFieldWatch (Field, SendNotification) values ('customerSourceID', 1)
GO

-- //@UNDO
-- SQL to undo the change goes here.
delete CustFieldWatch where SendNotification = 1
GO

drop table DataUpdateNotification
GO

