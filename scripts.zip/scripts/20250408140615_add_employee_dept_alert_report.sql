-- // add employee dept alert report
-- Migration SQL that makes the change goes here.
SET IDENTITY_INSERT [EmployeeReportQuery] ON

insert into [dbo].[EmployeeReportQuery](Id, Name, QueryDesc, Active, Frequency, Hour, DayOfWeek, Day, RunWhen)
values (10, 'Dept Employee Clock In', 'Time the first employee of a department clocks in',
        0, 0, 0, 0, 0, 1);
GO

SET IDENTITY_INSERT [EmployeeReportQuery] OFF
GO


-- //@UNDO
-- SQL to undo the change goes here.
delete EmployeeReportQuery where id = 10
GO

