-- // add cust change field table
-- Migration SQL that makes the change goes here.
USE [shahcorp];
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
CREATE TABLE [dbo].[CustFieldChgTracker](
[Id] [bigint] NOT NULL IDENTITY(1,1) PRIMARY KEY,
[CustomerSeqNum] [int] not null,
[Field] [varchar](64) not null,
[OldValue] [varchar](64) not null,
[NewValue] [varchar](64) not null,
[EmployeeId] [int] not null,
[DateChanged] [datetime] NOT NULL DEFAULT(getdate())
);
GO


CREATE TABLE [dbo].[CustFieldWatch](
[Id] [bigint] NOT NULL IDENTITY(1,1) PRIMARY KEY,
[Field] [varchar](64) not null,
[SendNotification] [bit] NOT NULL DEFAULT 0
);
GO

insert into CustFieldWatch (Field) values ('cellPhone')
GO


insert into userquery(name,query,description)
values('Cell Phones Updated','
select c.customerName, ct.DateChanged, e.employeename ''Employee'', ct.OldValue ''Old Cell Phone'', ct.NewValue ''New Cell Phone'' from customer c,
CustFieldChgTracker ct, Employee e where ct.EmployeeId = e.employeeID and ct.CustomerSeqNum = c.customerSequenceNumber and ct.Field = ''cellPhone''
and DateChanged >= ''@Begin_Date:date''',
       'Shows when customers have their cell phone updated and by who')
GO

-- //@UNDO
-- SQL to undo the change goes here.
delete UserQuery where name = 'Cell Phones Updated'
GO

drop table CustFieldChgTracker
GO

drop table CustFieldWatch
GO

