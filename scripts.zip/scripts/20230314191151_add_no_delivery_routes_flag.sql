-- // add no delivery routes flag
-- Migration SQL that makes the change goes here.
alter table MiscSetup add sendReadyMsgForNonDelRoutes bit not null DEFAULT 0
GO


-- //@UNDO
-- SQL to undo the change goes here.
alter table MiscSetup drop column sendReadyMsgForNonDelRoutes;
GO


