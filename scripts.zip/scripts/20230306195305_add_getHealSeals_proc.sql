-- // add getHealSeals proc
-- Migration SQL that makes the change goes here.

IF NOT EXISTS(SELECT * FROM SYSCOLUMNS WHERE NAME = 'active' and ID=OBJECT_ID(N'[dbo].[ValidHeatSealRanges]'))
    BEGIN
        ALTER TABLE dbo.ValidHeatSealRanges
            ADD active bit default 1 not null;
    END
GO


IF NOT EXISTS(SELECT * FROM SYSCOLUMNS WHERE NAME = 'position' and ID=OBJECT_ID(N'[dbo].[ValidHeatSealRanges]'))
    BEGIN
        ALTER TABLE dbo.ValidHeatSealRanges
            ADD position int;
    END
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[GetNewHeatSeals]') and type = 'P')
    BEGIN
        DROP PROCEDURE [dbo].[GetNewHeatSeals]
    END
GO


    CREATE PROCEDURE [dbo].[GetNewHeatSeals]
    (
        @count int
    )
    AS
    BEGIN
        DECLARE @hsRangeID INT
        DECLARE @position INT

        SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
        BEGIN TRAN

            SELECT TOP 1
                    @hsRangeID = hsRangeID,
                    @position = isnull(position, starths)
            FROM ValidHeatSealRanges
            WHERE active = 1
              AND dbo.isInt(starths) = 1
              AND isnull(position, starths) + @count <= endhs
            ORDER BY isnull(position, starths)

            IF @position IS NOT NULL
                BEGIN
                    UPDATE ValidHeatSealRanges
                    SET position = @position + @count
                    WHERE hsRangeID = @hsRangeID
                END

        COMMIT TRAN

        IF @position IS NOT NULL
            BEGIN
                SELECT right('00000000' + convert(varchar, @position + Inc.val), 8) as heatseal
                FROM
                    (SELECT ROW_NUMBER() OVER (order by name) - 1 as val FROM SYS.OBJECTS) AS Inc
                WHERE Inc.val < @count
            END
    END


GO


-- //@UNDO
-- SQL to undo the change goes here.


