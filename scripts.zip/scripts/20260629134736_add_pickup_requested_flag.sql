-- // add pickup requested flag
-- Migration SQL that makes the change goes here.
alter table DeliveryStop add pickupRequested bit not null DEFAULT 0
GO


-- //@UNDO
-- SQL to undo the change goes here.


