-- // add prepay popup
-- Migration SQL that makes the change goes here.
ALTER TABLE MiscSetup ADD prepayPopupOnDetailPage bit NOT NULL DEFAULT 0;
GO

-- //@UNDO
-- SQL to undo the change goes here.


