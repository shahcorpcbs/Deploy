-- // fix on demand proc
-- Migration SQL that makes the change goes here.
alter table CardPayment alter column RawAnswer varchar(5000)
GO


-- //@UNDO
-- SQL to undo the change goes here.


