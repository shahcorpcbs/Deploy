-- // add sms time limits
-- Migration SQL that makes the change goes here.
alter table MiscSetup add smsLimitTime bit not null DEFAULT 0
GO

alter table MiscSetup add smsALimitHour smallint not null default 12
GO
alter table MiscSetup add smsALimitMin smallint not null default 0
GO
alter table MiscSetup add smsALimitAM varchar(2) default 'AM'
GO
alter table MiscSetup add smsBLimitHour smallint not null default 12
GO
alter table MiscSetup add smsBLimitMin smallint not null default 0
GO
alter table MiscSetup add smsBLimitAM varchar(2) default 'AM'
GO


-- //@UNDO
-- SQL to undo the change goes here.


